import type { ReactNode } from "react";
import { useEffect, useState } from "react";
import { Compass, Download, FolderOpen, Home, Settings2, X } from "lucide-react";
import type { Lang, Screen } from "../core";

export const copy = (lang: Lang, ar: string, en: string) => lang === "ar" ? ar : en;

export function Brand({ compact = false }: { compact?: boolean }) {
  return <div className="flex items-center gap-2.5">
    <div className={`brand-glyph flex shrink-0 items-center justify-center rounded-2xl font-[Outfit] font-semibold text-white ${compact ? "h-9 w-9 text-base" : "h-11 w-11 text-xl"}`}>
      JO
    </div>
    <div>
      <div className={`font-[Outfit] font-semibold leading-none tracking-tight ${compact ? "text-[16px]" : "text-[21px]"}`}>
        𝒥𝒪 <span className="text-gradient">DON</span>
      </div>
      <div className="mt-1 text-[9px] tracking-[0.14em] faint">PRIVATE MEDIA STUDIO</div>
    </div>
  </div>;
}

export function YouTubeMark({ size = 30 }: { size?: number }) {
  return <span className="inline-flex shrink-0 items-center justify-center rounded-[9px] bg-[#ff334e]" style={{ width: size, height: size * 0.7 }} aria-hidden>
    <svg width={size * .38} height={size * .38} viewBox="0 0 20 20" fill="white"><path d="M4 2.9v14.2L17 10z" /></svg>
  </span>;
}

export function Header({ title, eyebrow, action }: { title: string; eyebrow?: string; action?: ReactNode }) {
  return <header className="flex items-center justify-between gap-3">
    <div className="min-w-0">
      {eyebrow && <div className="mb-1 text-[10px] font-medium" style={{ color: "var(--accent2)" }}>{eyebrow}</div>}
      <h2 className="text-[23px] font-semibold leading-tight tracking-tight">{title}</h2>
    </div>
    {action}
  </header>;
}

export function GlyphButton({ label, children, onClick, className = "" }: { label: string; children: ReactNode; onClick: () => void; className?: string }) {
  return <button type="button" aria-label={label} onClick={onClick}
    className={`press glass-soft flex h-9 w-9 shrink-0 items-center justify-center rounded-[12px] text-[var(--text-2)] hover:text-[var(--text-1)] ${className}`}>
    {children}
  </button>;
}

export function AccentButton({ children, onClick, className = "", secondary = false, disabled = false }: { children: ReactNode; onClick: () => void; className?: string; secondary?: boolean; disabled?: boolean }) {
  return <button type="button" onClick={onClick} disabled={disabled}
    className={`press flex items-center justify-center gap-2 rounded-[15px] px-4 py-2.5 text-[12px] font-semibold disabled:cursor-not-allowed disabled:opacity-45 ${secondary ? "glass-soft text-[var(--text-1)]" : "btn-primary"} ${className}`}>
    {children}
  </button>;
}

export function Chip({ children, tone = "accent", className = "" }: { children: ReactNode; tone?: "accent" | "success" | "muted" | "warning"; className?: string }) {
  const colors = {
    accent: "var(--accent2)", success: "var(--success)", warning: "var(--warning)", muted: "var(--text-2)",
  };
  return <span className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[9px] font-medium ${className}`}
    style={{ color: colors[tone], borderColor: `color-mix(in srgb, ${colors[tone]} 25%, transparent)`, background: `color-mix(in srgb, ${colors[tone]} 10%, transparent)` }}>
    {children}
  </span>;
}

export function Sheet({ title, subtitle, onClose, children }: { title: string; subtitle?: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  return <div className="absolute inset-0 z-[90] flex flex-col justify-end">
    <button aria-label="Close sheet" onClick={onClose} className="fade-enter absolute inset-0 bg-black/65 backdrop-blur-[6px]" />
    <div className="sheet-enter glass-deep relative flex max-h-[86%] min-h-[100px] flex-col overflow-hidden rounded-t-[32px]">
      <div className="mx-auto mt-3 h-1 w-10 shrink-0 rounded-full bg-white/25" />
      <div className="flex shrink-0 items-start justify-between gap-2 border-b border-white/10 px-5 pb-3 pt-3">
        <div className="min-w-0"><div className="text-[16px] font-semibold">{title}</div>{subtitle && <div className="mt-0.5 truncate text-[10px] muted">{subtitle}</div>}</div>
        <GlyphButton label="Close" onClick={onClose}><X size={15} /></GlyphButton>
      </div>
      <div className="no-scrollbar min-h-0 overflow-y-auto px-5 pb-6 pt-3">{children}</div>
    </div>
  </div>;
}

const navigation: { id: Screen; ar: string; en: string; icon: typeof Home | null }[] = [
  { id: "home", ar: "الرئيسية", en: "Home", icon: Home },
  { id: "downloads", ar: "التحميلات", en: "Downloads", icon: Download },
  { id: "youtube", ar: "YouTube", en: "YouTube", icon: null },
  { id: "browser", ar: "المتصفح", en: "Browser", icon: Compass },
  { id: "files", ar: "المكتبة", en: "Library", icon: FolderOpen },
  { id: "settings", ar: "الإعدادات", en: "Settings", icon: Settings2 },
];

export function Dock({ screen, lang, onNavigate, active }: { screen: Screen; lang: Lang; onNavigate: (next: Screen) => void; active: number }) {
  return <div className="absolute inset-x-0 bottom-0 z-50 px-3 pb-3">
    <div className="pointer-events-none absolute inset-x-0 -top-4 bottom-0" style={{ background: "linear-gradient(to top, var(--bg-deep), transparent)" }} />
    <div className="glass-deep relative grid grid-cols-6 gap-0.5 rounded-[25px] p-1.5">
      {navigation.map(({ id, ar, en, icon: Icon }) => {
        const selected = screen === id;
        return <button key={id} type="button" onClick={() => onNavigate(id)} aria-label={lang === "ar" ? ar : en}
          className={`press relative flex min-w-0 flex-col items-center gap-1 rounded-[17px] py-2 ${selected ? "accent-soft" : ""}`}>
          <div className="relative flex h-[20px] items-center justify-center">
            {Icon ? <Icon size={18} strokeWidth={selected ? 2.4 : 1.9} style={{ color: selected ? "var(--accent2)" : "var(--text-3)" }} />
              : <YouTubeMark size={21} />}
            {id === "downloads" && active > 0 && <span className="absolute -right-2 -top-1 rounded-full bg-[var(--accent2)] px-1 text-[8px] font-bold text-white">{active}</span>}
          </div>
          <span className="truncate text-[8px]" style={{ color: selected ? "var(--text-1)" : "var(--text-3)" }}>{lang === "ar" ? ar : en}</span>
          {selected && <span className="absolute bottom-0 h-[2px] w-4 rounded-full accent-gradient" />}
        </button>;
      })}
    </div>
  </div>;
}

export function ClockStatus() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => { const timer = window.setInterval(() => setNow(new Date()), 30000); return () => clearInterval(timer); }, []);
  return <div dir="ltr" className="relative z-[60] flex h-[42px] shrink-0 items-end justify-between px-7 pb-1 text-[11px] font-semibold text-[var(--text-1)]">
    <span>{now.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}</span>
    <div className="flex items-end gap-1"><span className="text-[8px]">▂▄▆</span><span className="text-[11px]">◕</span><span className="text-[11px]">▰</span></div>
  </div>;
}