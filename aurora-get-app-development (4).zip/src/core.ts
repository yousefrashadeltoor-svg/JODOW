import { photos } from "./assets/photos";

export type Lang = "ar" | "en";
export type ThemeId = "aurora" | "ocean" | "sunset" | "emerald" | "neon" | "mono";
export type Screen = "home" | "downloads" | "youtube" | "browser" | "files" | "settings" | "tools" | "player";
export type MediaKind = "video" | "audio" | "image" | "file";
export type VideoTab = "home" | "shorts" | "following" | "profile";

export const themes: { id: ThemeId; ar: string; en: string; photo: string }[] = [
  { id: "aurora", ar: "أورورا", en: "Aurora", photo: photos.aurora },
  { id: "ocean", ar: "محيط", en: "Ocean", photo: photos.ocean },
  { id: "sunset", ar: "غروب", en: "Sunset", photo: photos.sunset },
  { id: "emerald", ar: "زمرد", en: "Emerald", photo: photos.emerald },
  { id: "neon", ar: "نيون", en: "Neon", photo: photos.neon },
  { id: "mono", ar: "رمادي", en: "Mono", photo: photos.mono },
];

export type ProfileVideo = {
  id: string;
  title: string;
  channelId: string;
  channel: string;
  thumbnail: string;
  viewedAt: number;
};

export type LocalProfile = {
  displayName: string;
  following: Record<string, string>;
  liked: string[];
  watchLater: string[];
  history: ProfileVideo[];
  recentSearches: string[];
};

export type LocalPrefs = {
  version: 1;
  theme: ThemeId;
  appearance: "dark" | "light";
  lang: Lang;
  profile: LocalProfile;
};

export const emptyProfile = (): LocalProfile => ({
  displayName: "ملفي الشخصي",
  following: {},
  liked: [],
  watchLater: [],
  history: [],
  recentSearches: [],
});

export const defaultPrefs = (): LocalPrefs => ({
  version: 1,
  theme: "aurora",
  appearance: "dark",
  lang: "ar",
  profile: emptyProfile(),
});

const STORAGE_KEY = "jo-don-local-profile-v1";

export function loadPrefs(): LocalPrefs {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultPrefs();
    const value = JSON.parse(raw) as Partial<LocalPrefs>;
    const defaults = defaultPrefs();
    if (value.version !== 1) return defaults;
    return {
      ...defaults,
      ...value,
      theme: themes.some((t) => t.id === value.theme) ? value.theme! : "aurora",
      appearance: value.appearance === "light" ? "light" : "dark",
      lang: value.lang === "en" ? "en" : "ar",
      profile: {
        ...defaults.profile,
        ...value.profile,
        following: value.profile?.following ?? {},
        liked: Array.isArray(value.profile?.liked) ? value.profile!.liked : [],
        watchLater: Array.isArray(value.profile?.watchLater) ? value.profile!.watchLater : [],
        history: Array.isArray(value.profile?.history) ? value.profile!.history : [],
        recentSearches: Array.isArray(value.profile?.recentSearches) ? value.profile!.recentSearches : [],
      },
    };
  } catch {
    return defaultPrefs();
  }
}

export function savePrefs(value: LocalPrefs) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(value));
  } catch {
    // Private-browsing storage may be unavailable. The current session still works.
  }
}

export function formatBytes(bytes: number | null, approximate = false): string {
  if (bytes === null || bytes <= 0 || !Number.isFinite(bytes)) return approximate ? "≈ غير معروف" : "غير معروف";
  const sign = approximate ? "≈ " : "";
  const mib = bytes / 1048576;
  if (mib >= 1024) return `${sign}${(mib / 1024).toFixed(2)} GiB`;
  if (mib >= 1) return `${sign}${mib.toFixed(1)} MiB`;
  return `${sign}${Math.round(bytes / 1024)} KiB`;
}

export function kindFromFile(file: File): MediaKind {
  if (file.type.startsWith("video/")) return "video";
  if (file.type.startsWith("audio/")) return "audio";
  if (file.type.startsWith("image/")) return "image";
  return "file";
}
