import { useState } from "react";
import { ChevronLeft, Download, FolderOpen, Smartphone, Trash2, UserRound, X } from "lucide-react";
import type { LocalPrefs, VideoTab } from "../core";
import { AccentButton, Chip, copy, YouTubeMark } from "../components/Design";

type Props = {
  prefs: LocalPrefs;
  setPrefs: React.Dispatch<React.SetStateAction<LocalPrefs>>;
  notify: (message: string) => void;
  onExport: () => void;
  onImport: () => void;
};

const tabs: { id: VideoTab; ar: string; en: string }[] = [
  { id: "home", ar: "الرئيسية", en: "Home" },
  { id: "shorts", ar: "Shorts", en: "Shorts" },
  { id: "following", ar: "الاشتراكات", en: "Subscriptions" },
  { id: "profile", ar: "أنت", en: "You" },
];

/**
 * The native YouTube client (NewPipe Extractor + Media3) only exists in the Android app:
 * browsers forbid cross-origin requests to YouTube, and this preview never fabricates videos.
 * What does work here is the local profile, which shares its JSON format with the app.
 */
export function YouTubePanel({ prefs, setPrefs, notify, onExport, onImport }: Props) {
  const { lang, profile } = prefs;
  const [section, setSection] = useState<VideoTab>("home");
  const [name, setName] = useState(profile.displayName);
  const edit = (change: (p: LocalPrefs["profile"]) => LocalPrefs["profile"]) =>
    setPrefs((current) => ({ ...current, profile: change(current.profile) }));
  const follows = Object.entries(profile.following);

  return <div className="min-h-full px-4 pb-5 pt-1">
    <div className="mb-3 flex items-center justify-between">
      <div className="flex items-center gap-2"><YouTubeMark size={34} /><span className="font-[Outfit] text-[20px] font-semibold tracking-tight">YouTube</span></div>
      <Chip tone="muted"><Smartphone size={10} />{copy(lang, "يعمل داخل APK", "Runs in the APK")}</Chip>
    </div>
    <div className="no-scrollbar flex gap-1.5 overflow-x-auto pb-1">
      {tabs.map((tab) => <button key={tab.id} onClick={() => setSection(tab.id)}
        className={`press shrink-0 rounded-full border px-3.5 py-1.5 text-[10px] font-medium ${section === tab.id ? "border-white/20 text-white accent-gradient" : "glass-soft muted"}`}>
        {copy(lang, tab.ar, tab.en)}
      </button>)}
    </div>

    {section === "profile" ? <div className="stagger mt-4 space-y-3">
      <div className="flex items-center gap-3">
        <div className="brand-glyph flex h-12 w-12 shrink-0 items-center justify-center rounded-[17px] text-white"><UserRound size={21} /></div>
        <div className="min-w-0 flex-1">
          <input value={name} onChange={(event) => setName(event.target.value.slice(0, 40))}
            onBlur={() => edit((p) => ({ ...p, displayName: name.trim() || "ملفي الشخصي" }))}
            aria-label={copy(lang, "اسم الملف الشخصي", "Profile name")}
            className="w-full bg-transparent text-[15px] font-semibold outline-none" />
          <div className="text-[10px] muted">{copy(lang, "ملف محلي · بلا تسجيل دخول", "Local profile · no sign-in")}</div>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-2 text-center">
        {[[profile.history.length, copy(lang, "في السجل", "history")], [follows.length, copy(lang, "اشتراك", "subscriptions")], [profile.watchLater.length, copy(lang, "لاحقًا", "watch later")]].map(([value, label]) =>
          <div key={String(label)} className="glass-soft rounded-[15px] py-2.5"><div className="font-[Outfit] text-[17px] font-semibold">{value}</div><div className="text-[9px] muted">{label}</div></div>)}
      </div>
      <div className="flex gap-2">
        <AccentButton secondary onClick={onExport} className="flex-1"><Download size={14} />{copy(lang, "تصدير JSON", "Export JSON")}</AccentButton>
        <AccentButton secondary onClick={onImport} className="flex-1"><FolderOpen size={14} />{copy(lang, "استيراد", "Import")}</AccentButton>
      </div>
      {profile.history.length > 0 && <div>
        <div className="mb-1 flex items-center justify-between"><h3 className="text-[12px] font-semibold">{copy(lang, "السجل", "History")}</h3>
          <button onClick={() => { edit((p) => ({ ...p, history: [] })); notify(copy(lang, "مُسح السجل", "History cleared")); }} className="flex items-center gap-1 text-[10px] text-[var(--danger)]"><Trash2 size={11} />{copy(lang, "مسح", "Clear")}</button></div>
        {profile.history.slice(0, 12).map((item) => <div key={item.id} className="truncate border-b border-white/10 py-2 text-[10px] muted">{item.title}</div>)}
      </div>}
    </div> : section === "following" && follows.length > 0 ? <div className="mt-4 space-y-2">
      {follows.map(([id, channel]) => <div key={id} className="glass-soft flex items-center justify-between rounded-[15px] px-3 py-2.5 text-[11px]">
        <span className="min-w-0 truncate">{channel}</span>
        <button aria-label={copy(lang, "إلغاء الاشتراك", "Unsubscribe")} onClick={() => edit((p) => { const next = { ...p.following }; delete next[id]; return { ...p, following: next }; })}><X size={13} className="faint" /></button>
      </div>)}
    </div> : <div className="mt-9 text-center">
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-[22px] bg-[#ff0033]/12"><YouTubeMark size={38} /></div>
      <h3 className="mt-4 text-[15px] font-semibold">{copy(lang, "عميل يوتيوب أصلي داخل التطبيق", "A native YouTube client lives in the app")}</h3>
      <p className="mx-auto mt-2 max-w-[292px] text-[11px] leading-6 muted">
        {copy(lang,
          "في تطبيق Android تعمل هذه الصفحة بمحرك NewPipe المفتوح ومشغل Media3: خلاصات، بحث باقتراحات فورية، Shorts، قنوات، اشتراكات محلية، وتحميل تحت كل فيديو — بلا مفتاح API ولا تسجيل دخول ولا WebView.",
          "On Android this page runs on the open NewPipe engine and a Media3 player: feeds, live search suggestions, Shorts, channels, local subscriptions and a download button under every video — no API key, sign-in or WebView.")}
      </p>
      <p className="mx-auto mt-3 max-w-[292px] rounded-[14px] border border-white/10 bg-white/[.04] p-3 text-[10px] leading-5 faint">
        {copy(lang,
          "المتصفحات تمنع أي صفحة ويب من مخاطبة يوتيوب مباشرة (CORS)، ولذلك لا تعرض هذه المعاينة فيديوهات مصطنعة. ملفك الشخصي هنا حقيقي ويُستورد في التطبيق كما هو.",
          "Browsers block web pages from calling YouTube directly (CORS), so this preview shows no made-up videos. Your profile here is real and imports into the app unchanged.")}
      </p>
      <AccentButton secondary onClick={() => setSection("profile")} className="mx-auto mt-4">{copy(lang, "ملفي المحلي", "My local profile")}<ChevronLeft size={13} /></AccentButton>
    </div>}
  </div>;
}
