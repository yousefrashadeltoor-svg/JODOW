import { useEffect, useRef, useState } from "react";
import { ArrowLeft, Check, ChevronDown, Clock3, File, Film, FolderOpen, Image as ImageIcon, Maximize2, Music2, Pause, Play, Plus, Repeat, Scissors, Search, Volume2, Waves, Zap } from "lucide-react";
import type { Lang, MediaKind } from "../core";
import { formatBytes, kindFromFile } from "../core";
import { AccentButton, Chip, copy, Header } from "../components/Design";

export type LocalMedia = { id: string; file: File; url: string; kind: MediaKind };

export function localMedia(files: File[]): LocalMedia[] {
  return files.map((file) => ({ id: `${Date.now()}-${crypto.randomUUID()}`, file, url: URL.createObjectURL(file), kind: kindFromFile(file) }));
}

export function LocalLibrary({ lang, items, onImport, onOpen }: { lang: Lang; items: LocalMedia[]; onImport: () => void; onOpen: (item: LocalMedia) => void }) {
  const [filter, setFilter] = useState<"all" | MediaKind>("all");
  const [query, setQuery] = useState("");
  const visible = items.filter((item) => (filter === "all" || item.kind === filter) && item.file.name.toLowerCase().includes(query.toLowerCase()));
  const groups: { id: "all" | MediaKind; ar: string; en: string }[] = [
    { id: "all", ar: "الكل", en: "All" }, { id: "video", ar: "فيديو", en: "Video" },
    { id: "audio", ar: "الموسيقى", en: "Music" }, { id: "image", ar: "صور", en: "Images" },
    { id: "file", ar: "ملفات", en: "Files" },
  ];
  const icon = (kind: MediaKind) => kind === "video" ? <Film size={17} /> : kind === "audio" ? <Music2 size={17} /> : kind === "image" ? <ImageIcon size={17} /> : <File size={17} />;
  return <div className="px-4 pb-5 pt-1">
    <Header eyebrow={copy(lang, "مكتبة جهازك · تعمل بدون إنترنت", "Your local library · works offline")} title={copy(lang, "مكتبة الملفات", "File library")} />
    <div className="mt-4 flex gap-2"><AccentButton onClick={onImport} className="flex-1"><Plus size={15} />{copy(lang, "افتح ملفات من جهازك", "Open files from device")}</AccentButton></div>
    <div className="glass-soft mt-3 flex items-center gap-2 rounded-[14px] px-3 py-2.5"><Search size={14} className="faint" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={copy(lang, "ابحث في الملفات المفتوحة", "Search opened files")} className="min-w-0 flex-1 bg-transparent text-[11px] outline-none placeholder:text-[var(--text-3)]" /></div>
    <div className="no-scrollbar mt-3 flex gap-1.5 overflow-x-auto">{groups.map((group) => <button key={group.id} onClick={() => setFilter(group.id)} className={`press shrink-0 rounded-full border px-3 py-1.5 text-[10px] ${filter === group.id ? "text-white accent-gradient border-white/20" : "glass-soft muted"}`}>{copy(lang, group.ar, group.en)}</button>)}</div>
    <div className="mt-4 flex items-center justify-between"><h3 className="text-[12px] font-semibold">{copy(lang, "الملفات المتاحة", "Available files")}</h3><span className="text-[10px] faint">{visible.length}</span></div>
    {visible.length ? <div className="stagger mt-2 space-y-2">{visible.map((item) => <button key={item.id} onClick={() => onOpen(item)} className="press glass-soft flex w-full items-center gap-3 rounded-[17px] p-2.5 text-start">
      <div className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-[12px] accent-soft" style={{ color: "var(--accent2)" }}>{item.kind === "image" ? <img src={item.url} alt="" className="h-full w-full object-cover" /> : icon(item.kind)}</div>
      <div className="min-w-0 flex-1"><div className="truncate text-[11px] font-medium" dir="auto">{item.file.name}</div><div className="mt-1 text-[9px] faint">{formatBytes(item.file.size)} · {item.file.type || copy(lang, "ملف", "File")}</div></div>
      <Play size={14} className="faint" />
    </button>)}</div> : <div className="mt-12 flex flex-col items-center text-center"><div className="orb h-20 w-20 opacity-80" /><h3 className="mt-5 text-[14px] font-semibold">{copy(lang, "لا ملفات هنا بعد", "Your library is ready")}</h3><p className="mt-1 max-w-[270px] text-[10px] leading-5 muted">{copy(lang, "افتح ملفاتك من جهازك لتشغيلها أو قصها دون رفعها لأي خادم. ملفات جلسة الويب لا تبقى بعد إغلاقها.", "Open your media to play or trim it without uploading. Files opened in this web session do not persist after closing.")}</p><AccentButton secondary onClick={onImport} className="mt-4"><FolderOpen size={14} />{copy(lang, "فتح ملفات", "Open files")}</AccentButton></div>}
    {items.length > 0 && <p className="mt-5 text-center text-[9px] faint">{copy(lang, "أحجام حقيقية من ملفات جهازك؛ لا بيانات افتراضية.", "Real file sizes from your device; no sample data.")}</p>}
  </div>;
}

type CaptureElement = (HTMLVideoElement | HTMLAudioElement) & { captureStream?: () => MediaStream };

export function LocalPlayer({ item, playlist, lang, onBack, onNext, notify }: { item: LocalMedia; playlist: LocalMedia[]; lang: Lang; onBack: () => void; onNext: (item: LocalMedia) => void; notify: (text: string) => void }) {
  const video = useRef<HTMLVideoElement>(null);
  const audio = useRef<HTMLAudioElement>(null);
  const element = () => item.kind === "video" ? video.current : audio.current;
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [rate, setRate] = useState(1);
  const [repeatMode, setRepeatMode] = useState<"off" | "one" | "all">("off");
  const [audioOnly, setAudioOnly] = useState(item.kind === "audio");
  const [sleepUntil, setSleepUntil] = useState<number | null>(null);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [showTrim, setShowTrim] = useState(false);
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(0);
  const [exporting, setExporting] = useState(false);

  useEffect(() => { setPlaying(false); setCurrentTime(0); setDuration(0); setTrimStart(0); setTrimEnd(0); setAudioOnly(item.kind === "audio"); }, [item.id, item.kind]);
  useEffect(() => {
    if (sleepUntil === null) return;
    const timer = window.setInterval(() => {
      const next = Math.max(0, Math.ceil((sleepUntil - Date.now()) / 1000));
      setSecondsLeft(next);
      if (next === 0) { element()?.pause(); setSleepUntil(null); notify(copy(lang, "انتهى مؤقت النوم وتوقف التشغيل", "Sleep timer finished")); }
    }, 500);
    return () => window.clearInterval(timer);
  }, [sleepUntil, item.id, lang, notify]);

  const time = (seconds: number) => `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(Math.floor(seconds % 60)).padStart(2, "0")}`;
  const play = () => { const media = element(); if (!media) return; if (media.paused) void media.play().catch(() => notify(copy(lang, "تعذر تشغيل هذا الترميز", "This codec cannot be played"))); else media.pause(); };
  const ended = () => {
    if (repeatMode === "one") { const media = element(); if (media) { media.currentTime = 0; void media.play(); } return; }
    if (repeatMode === "all" && playlist.length > 1) { const idx = playlist.findIndex((candidate) => candidate.id === item.id); onNext(playlist[(idx + 1) % playlist.length]); return; }
    setPlaying(false);
  };

  const captureTrim = async () => {
    const media = element() as CaptureElement | null;
    if (!media || exporting || trimEnd - trimStart < 0.5) return;
    if (!media.captureStream || !window.MediaRecorder) {
      notify(copy(lang, "التصدير غير مدعوم في هذا المتصفح؛ القص الحقيقي متاح في APK", "This browser cannot export clips; use the APK for real trimming."));
      return;
    }
    const mime = item.kind === "video" ? "video/webm" : "audio/webm";
    if (!MediaRecorder.isTypeSupported(mime)) { notify(copy(lang, "ترميز WebM غير مدعوم هنا", "WebM encoding is unavailable here")); return; }
    setExporting(true);
    try {
      media.pause();
      media.currentTime = trimStart;
      await new Promise<void>((resolve) => media.addEventListener("seeked", () => resolve(), { once: true }));
      await media.play();
      const recorder = new MediaRecorder(media.captureStream(), { mimeType: mime });
      const chunks: Blob[] = [];
      recorder.ondataavailable = (event) => { if (event.data.size) chunks.push(event.data); };
      const done = new Promise<Blob>((resolve, reject) => {
        recorder.onerror = () => reject(new Error("Recording failed"));
        recorder.onstop = () => resolve(new Blob(chunks, { type: mime }));
      });
      recorder.start(250);
      await new Promise((resolve) => window.setTimeout(resolve, ((trimEnd - trimStart) / media.playbackRate) * 1000));
      recorder.stop();
      media.pause();
      const blob = await done;
      if (!blob.size) throw new Error("The clip was empty");
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a"); anchor.href = url; anchor.download = `${item.file.name.replace(/\.[^.]+$/, "")}-clip.webm`; anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 60000);
      notify(copy(lang, "صُدّر المقطع الحقيقي إلى جهازك", "Actual clip exported to your device"));
    } catch (issue) { notify(issue instanceof Error ? issue.message : String(issue)); }
    finally { setExporting(false); }
  };

  return <div className="px-4 pb-5 pt-1">
    <button onClick={onBack} className="press mb-3 flex items-center gap-1 text-[11px] muted"><ArrowLeft size={15} className={lang === "ar" ? "rotate-180" : ""} />{copy(lang, "العودة إلى المكتبة", "Back to library")}</button>
    <Header title={copy(lang, "المشغل المحلي", "Local player")} eyebrow={copy(lang, "ملف حقيقي · يعمل دون إنترنت", "Real file · fully offline")} />
    <div className="relative mt-3 overflow-hidden rounded-[23px] bg-black/35">
      {item.kind === "video" ? <video ref={video} src={item.url} playsInline className={`aspect-video w-full object-contain ${audioOnly ? "opacity-0" : ""}`}
        onLoadedMetadata={(event) => { setDuration(event.currentTarget.duration); setTrimEnd(event.currentTarget.duration); }}
        onTimeUpdate={(event) => setCurrentTime(event.currentTarget.currentTime)} onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onEnded={ended} />
        : item.kind === "audio" ? <div className="flex aspect-square items-center justify-center"><div className="orb h-40 w-40" /><audio ref={audio} src={item.url}
            onLoadedMetadata={(event) => { setDuration(event.currentTarget.duration); setTrimEnd(event.currentTarget.duration); }}
            onTimeUpdate={(event) => setCurrentTime(event.currentTarget.currentTime)} onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onEnded={ended} /></div>
          : item.kind === "image" ? <img src={item.url} alt={item.file.name} className="max-h-[350px] w-full object-contain" /> : <div className="flex aspect-video items-center justify-center"><File size={45} className="faint" /></div>}
      {audioOnly && item.kind === "video" && <div className="pointer-events-none absolute inset-0 flex items-center justify-center"><div className="orb h-24 w-24" /></div>}
    </div>
    <h3 className="mt-3 break-words text-[13px] font-semibold">{item.file.name}</h3>
    <p className="mt-1 text-[9px] muted">{formatBytes(item.file.size)} · {item.file.type || copy(lang, "ملف محلي", "Local file")}</p>
    {(item.kind === "video" || item.kind === "audio") && <>
      <div className="mt-4 flex items-center gap-2"><span className="font-[Outfit] text-[10px] muted">{time(currentTime)}</span><input type="range" min={0} max={duration || 1} value={Math.min(currentTime, duration || 1)} step={0.1}
        onChange={(event) => { if (element()) element()!.currentTime = Number(event.target.value); }} className="range-aurora min-w-0 flex-1" aria-label="Seek" /><span className="font-[Outfit] text-[10px] muted">{time(duration)}</span></div>
      <div className="mt-2 flex items-center justify-center gap-2"><AccentButton secondary onClick={() => { if (element()) element()!.currentTime = Math.max(0, currentTime - 10); }} className="px-3 py-2">−10s</AccentButton><AccentButton onClick={play} className="min-w-32"><span>{playing ? <Pause size={15} fill="currentColor" /> : <Play size={15} fill="currentColor" />}</span>{playing ? copy(lang, "إيقاف", "Pause") : copy(lang, "تشغيل", "Play")}</AccentButton><AccentButton secondary onClick={() => { if (element()) element()!.currentTime = Math.min(duration, currentTime + 10); }} className="px-3 py-2">+10s</AccentButton></div>
      <div className="no-scrollbar mt-3 flex gap-1.5 overflow-x-auto"><AccentButton secondary onClick={() => { const speeds = [.75, 1, 1.25, 1.5, 2]; const next = speeds[(speeds.indexOf(rate) + 1) % speeds.length]; setRate(next); if (element()) element()!.playbackRate = next; }} className="shrink-0 py-2">{rate}×</AccentButton>
        <AccentButton secondary onClick={() => setRepeatMode((previous) => previous === "off" ? "one" : previous === "one" ? "all" : "off")} className="shrink-0 py-2"><Repeat size={13} />{repeatMode === "off" ? copy(lang, "بلا تكرار", "No repeat") : repeatMode === "one" ? copy(lang, "تكرار 1", "Repeat one") : copy(lang, "تكرار الكل", "Repeat all")}</AccentButton>
        <AccentButton secondary onClick={() => setAudioOnly(!audioOnly)} className="shrink-0 py-2"><Volume2 size={13} />{copy(lang, "صوت فقط", "Audio only")}</AccentButton></div>
      <div className="no-scrollbar mt-2 flex gap-1.5 overflow-x-auto"><AccentButton secondary onClick={() => { const cycle = sleepUntil === null ? 15 : Math.ceil((sleepUntil - Date.now()) / 60000) <= 15 ? 30 : Math.ceil((sleepUntil - Date.now()) / 60000) <= 30 ? 60 : 0; setSleepUntil(cycle ? Date.now() + cycle * 60000 : null); }} className="shrink-0 py-2"><Clock3 size={13} />{sleepUntil ? `${Math.ceil(secondsLeft / 60)} ${copy(lang, "د", "min")}` : copy(lang, "مؤقت النوم", "Sleep timer")}</AccentButton>
        <AccentButton secondary onClick={() => setShowTrim(!showTrim)} className="shrink-0 py-2"><Scissors size={13} />{copy(lang, "قص مرئي", "Visual trim")}</AccentButton>
        {item.kind === "video" && <AccentButton secondary onClick={() => { const media = video.current; if (media && "requestPictureInPicture" in media) void media.requestPictureInPicture().catch(() => notify(copy(lang, "النافذة العائمة غير متاحة", "PiP unavailable"))); }} className="shrink-0 py-2"><Maximize2 size={13} />PiP</AccentButton>}
        {item.kind === "audio" && <AccentButton secondary onClick={() => notify(copy(lang, "تعيين نغمة الرنين متاح في APK عبر MediaStore", "Set as ringtone in the APK via MediaStore"))} className="shrink-0 py-2"><Waves size={13} />{copy(lang, "نغمة رنين", "Ringtone")}</AccentButton>}</div>
      {showTrim && <div className="glass-soft mt-3 rounded-[18px] p-3"><div className="text-[11px] font-semibold">{copy(lang, "حدد نقطتي القص بالسحب", "Drag the two clip handles")}</div>
        <div className="mt-2 flex items-center justify-between text-[9px] muted"><span>{time(trimStart)}</span><span>{time(trimEnd)}</span></div>
        <label className="mt-1 block text-[9px] faint">{copy(lang, "البداية", "Start")}</label><input type="range" min={0} max={Math.max(0, trimEnd - .5)} step={.1} value={trimStart} onChange={(event) => setTrimStart(Number(event.target.value))} className="range-aurora w-full" />
        <label className="mt-1 block text-[9px] faint">{copy(lang, "النهاية", "End")}</label><input type="range" min={Math.min(duration, trimStart + .5)} max={duration || 1} step={.1} value={trimEnd} onChange={(event) => setTrimEnd(Number(event.target.value))} className="range-aurora w-full" />
        <p className="my-2 text-[9px] leading-4 muted">{copy(lang, "التصدير الحقيقي يعمل بالزمن الحقيقي باستخدام MediaRecorder إن دعمه المتصفح؛ لا يُعدل الأصل.", "Real export records with MediaRecorder in real time where supported; originals remain untouched.")}</p>
        <AccentButton onClick={() => void captureTrim()} disabled={exporting || duration < 1} className="w-full"><Scissors size={13} />{exporting ? copy(lang, "يُصدّر المقطع...", "Exporting clip...") : copy(lang, "تصدير المقطع WebM", "Export WebM clip")}</AccentButton>
      </div>}
    </>}
    {item.kind === "file" && <AccentButton secondary onClick={() => { const anchor = document.createElement("a"); anchor.href = item.url; anchor.download = item.file.name; anchor.click(); }} className="mt-4"><File size={14} />{copy(lang, "حفظ نسخة", "Save copy")}</AccentButton>}
  </div>;
}

export function ToolsPanel({ lang, items, onOpenPlayer, notify }: { lang: Lang; items: LocalMedia[]; onOpenPlayer: (item: LocalMedia) => void; notify: (text: string) => void }) {
  const [tab, setTab] = useState<"compress" | "trim">("compress");
  const [image, setImage] = useState<File | null>(null);
  const [before, setBefore] = useState<string | null>(null);
  const [after, setAfter] = useState<string | null>(null);
  const [afterBlob, setAfterBlob] = useState<Blob | null>(null);
  const [split, setSplit] = useState(50);
  const [busy, setBusy] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => () => { if (before) URL.revokeObjectURL(before); if (after) URL.revokeObjectURL(after); }, [before, after]);

  const select = (file: File | undefined) => {
    if (!file) return;
    setImage(file); setBefore(URL.createObjectURL(file)); setAfter(null); setAfterBlob(null);
  };

  const compress = async () => {
    if (!image) return;
    setBusy(true);
    try {
      const bitmap = await createImageBitmap(image);
      const canvas = document.createElement("canvas"); canvas.width = bitmap.width; canvas.height = bitmap.height;
      canvas.getContext("2d")?.drawImage(bitmap, 0, 0);
      bitmap.close();
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/webp", .92));
      if (!blob) throw new Error(copy(lang, "تعذر ترميز الصورة", "Could not encode the image"));
      if (blob.size >= image.size) { notify(copy(lang, "لم يصغر الملف؛ لم يُعرض ملف أكبر", "The result was not smaller; no larger output saved")); return; }
      setAfterBlob(blob); setAfter(URL.createObjectURL(blob));
      notify(copy(lang, `وفّرت ${formatBytes(image.size - blob.size)} من الملف الحقيقي`, `Saved ${formatBytes(image.size - blob.size)} from the real file`));
    } catch (issue) { notify(issue instanceof Error ? issue.message : String(issue)); }
    finally { setBusy(false); }
  };

  const save = () => {
    if (!afterBlob || !image) return;
    const url = URL.createObjectURL(afterBlob);
    const anchor = document.createElement("a"); anchor.href = url; anchor.download = `${image.name.replace(/\.[^.]+$/, "")}-compressed.webp`; anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 60000);
  };

  return <div className="px-4 pb-5 pt-1">
    <Header eyebrow={copy(lang, "استوديو على جهازك · دون رفع", "On-device studio · no uploads")} title={copy(lang, "حوّل. اضغط. وفّر.", "Convert. Compress. Save.")} />
    <div className="glass-soft mt-4 flex gap-1 rounded-[16px] p-1"><button onClick={() => setTab("compress")} className={`press flex-1 rounded-[12px] py-2 text-[11px] font-semibold ${tab === "compress" ? "btn-primary" : "muted"}`}><Zap size={13} className="me-1 inline" />{copy(lang, "الضاغط", "Compressor")}</button>
      <button onClick={() => setTab("trim")} className={`press flex-1 rounded-[12px] py-2 text-[11px] font-semibold ${tab === "trim" ? "btn-primary" : "muted"}`}><Scissors size={13} className="me-1 inline" />{copy(lang, "القص المرئي", "Visual trim")}</button></div>
    {tab === "compress" ? <div className="mt-4 space-y-3">
      <input ref={input} type="file" accept="image/*" className="hidden" onChange={(event) => select(event.target.files?.[0])} />
      <AccentButton secondary onClick={() => input.current?.click()} className="w-full"><ImageIcon size={16} />{copy(lang, "اختر صورة حقيقية من جهازك", "Choose a real image")}</AccentButton>
      {image ? <>
        <div className="glass-soft rounded-[17px] p-3"><div className="truncate text-[11px] font-medium">{image.name}</div><div className="mt-1 text-[10px] muted">{image.type} · {image.size.toLocaleString("en-US")} bytes</div></div>
        {before && <div className="relative overflow-hidden rounded-[19px] bg-black/30"><img src={before} alt="Before" className="h-[185px] w-full object-cover" />
          {after && <img src={after} alt="After" className="absolute inset-0 h-[185px] w-full object-cover" style={{ clipPath: `inset(0 ${100 - split}% 0 0)` }} />}
          {after && <div className="absolute inset-y-0 w-0.5 bg-white shadow-lg" style={{ insetInlineStart: `${split}%` }} />}
          {after && <input type="range" aria-label="Compare images" min={0} max={100} value={split} onChange={(event) => setSplit(Number(event.target.value))} className="absolute inset-0 h-full w-full cursor-ew-resize opacity-0" />}</div>}
        {afterBlob && <div className="glass-soft flex items-center justify-between rounded-[15px] px-3 py-2.5"><div className="text-[10px] muted">{formatBytes(image.size)} → {formatBytes(afterBlob.size)}</div><Chip tone="success"><Check size={10} />−{Math.round((1 - afterBlob.size / image.size) * 100)}%</Chip></div>}
        <AccentButton onClick={() => void compress()} disabled={busy} className="w-full"><Zap size={14} />{busy ? copy(lang, "تتم المعالجة...", "Processing...") : copy(lang, "ضغط شفاف بصريًا · WebP", "Visually transparent WebP")}</AccentButton>
        {afterBlob && <AccentButton secondary onClick={save} className="w-full">{copy(lang, "حفظ الناتج الأصغر", "Save smaller result")}</AccentButton>}
        <p className="text-[9px] leading-5 faint">{copy(lang, "وضع Lossless WebP الحقيقي متاح في Android 11+ داخل APK. معاينة المقارنة هنا تستخدم الملف الناتج فعلًا.", "True lossless WebP is available on Android 11+ in the APK. This comparison uses the actual output file.")}</p>
      </> : <p className="mt-8 text-center text-[11px] leading-6 muted">{copy(lang, "لا صورة افتراضية. اختر ملفًا وابدأ المعالجة الحقيقية.", "No sample image. Select a file for real processing.")}</p>}
    </div> : <div className="mt-4"><p className="text-[11px] leading-6 muted">{copy(lang, "افتح أغنية أو فيديو في المشغل، ثم اسحب نقطتي البداية والنهاية وصدّر مقطعًا حقيقيًا؛ لن يُمس الأصل.", "Open a video or song, drag the start and end handles, and export a real clip. Originals stay untouched.")}</p>
      <div className="mt-3 space-y-2">{items.filter((item) => item.kind === "video" || item.kind === "audio").map((item) => <button key={item.id} onClick={() => onOpenPlayer(item)} className="press glass-soft flex w-full items-center gap-2 rounded-[15px] p-3 text-start"><Scissors size={15} style={{ color: "var(--accent2)" }} /><span className="min-w-0 flex-1 truncate text-[11px]">{item.file.name}</span><ChevronDown size={13} className="faint" /></button>)}</div>
      {!items.some((item) => item.kind === "audio" || item.kind === "video") && <p className="mt-6 text-center text-[10px] faint">{copy(lang, "افتح وسائط من المكتبة أولًا.", "Open media in your library first.")}</p>}
    </div>}
  </div>;
}