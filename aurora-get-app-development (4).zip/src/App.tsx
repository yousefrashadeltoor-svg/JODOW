import { useEffect, useRef, useState } from "react";
import type { CSSProperties } from "react";
import { ArrowUpRight, Check, CircleAlert, ClipboardPaste, Compass, Download, File as FileIcon, Film, FolderOpen, Globe, Image as ImageIcon, Info, Link2, LoaderCircle, Moon, Music2, Plus, Search, Settings2, ShieldCheck, Wifi, X, Zap } from "lucide-react";
import type { Lang, LocalPrefs, MediaKind, Screen } from "./core";
import { defaultPrefs, formatBytes, loadPrefs, savePrefs, themes } from "./core";
import { AccentButton, Brand, Chip, ClockStatus, copy, Dock, GlyphButton, Header, Sheet, YouTubeMark } from "./components/Design";
import { YouTubePanel } from "./screens/YouTubePanel";
import { LocalLibrary, LocalPlayer, ToolsPanel, localMedia } from "./screens/LocalMedia";
import type { LocalMedia } from "./screens/LocalMedia";

type Analysis = { url: string; domain: string; name: string; type: MediaKind; mime: string; bytes: number | null };
type Transfer = { id: string; url: string; name: string; kind: MediaKind; received: number; total: number | null; speed: number;
  status: "running" | "done" | "cancelled" | "failed"; error?: string };

const typeInfo: Record<MediaKind, { ar: string; en: string; icon: typeof Film }> = {
  video: { ar: "فيديو", en: "Video", icon: Film },
  audio: { ar: "صوت", en: "Audio", icon: Music2 },
  image: { ar: "صورة", en: "Image", icon: ImageIcon },
  file: { ar: "ملف", en: "File", icon: FileIcon },
};

function domainOf(url: string) { try { return new URL(url).hostname; } catch { return ""; } }
function isYouTube(url: string) { const host = domainOf(url); return /(^|\.)(youtube\.com|youtu\.be)$/.test(host); }
function contentName(disposition: string | null, url: string) {
  const explicit = disposition?.match(/filename\*?=(?:UTF-8'')?"?([^";]+)/i)?.[1];
  try { return decodeURIComponent(explicit || new URL(url).pathname.split("/").filter(Boolean).at(-1) || "download"); }
  catch { return explicit || "download"; }
}
function mediaKind(mime: string): MediaKind {
  if (mime.startsWith("video/")) return "video";
  if (mime.startsWith("audio/")) return "audio";
  if (mime.startsWith("image/")) return "image";
  return "file";
}

export default function App() {
  const [prefs, setPrefs] = useState<LocalPrefs>(loadPrefs);
  const [screen, setScreen] = useState<Screen>("home");
  const [previous, setPrevious] = useState<Screen>("files");
  const [url, setUrl] = useState("");
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzeError, setAnalyzeError] = useState("");
  const [jobs, setJobs] = useState<Transfer[]>([]);
  const [items, setItems] = useState<LocalMedia[]>([]);
  const [selected, setSelected] = useState<LocalMedia | null>(null);
  const [notice, setNotice] = useState("");
  const [aboutOpen, setAboutOpen] = useState(false);
  const [browserUrl, setBrowserUrl] = useState("");
  const importRef = useRef<HTMLInputElement>(null);
  const profileRef = useRef<HTMLInputElement>(null);
  const pending = useRef<Record<string, AbortController>>({});
  const analyzer = useRef<AbortController | null>(null);
  const prefsRef = useRef(prefs);
  prefsRef.current = prefs;
  const { lang, theme, appearance } = prefs;
  const tr = (ar: string, en: string) => copy(lang, ar, en);
  const active = jobs.filter((job) => job.status === "running").length;

  useEffect(() => { savePrefs(prefs); document.documentElement.lang = prefs.lang; document.documentElement.dir = prefs.lang === "ar" ? "rtl" : "ltr"; }, [prefs]);
  useEffect(() => { if (!notice) return; const timer = window.setTimeout(() => setNotice(""), 4300); return () => window.clearTimeout(timer); }, [notice]);
  useEffect(() => () => { analyzer.current?.abort(); Object.values(pending.current).forEach((controller) => controller.abort()); }, []);

  const navigate = (next: Screen) => { if (screen !== "player") setPrevious(screen); setScreen(next); };
  const importLocal = (files: FileList | null) => {
    if (!files?.length) return;
    const added = localMedia(Array.from(files));
    setItems((existing) => [...existing, ...added]);
    setNotice(tr(`${added.length} ملف حقيقي أُضيف إلى المكتبة`, `${added.length} real file(s) added to the library`));
    if (importRef.current) importRef.current.value = "";
  };
  const openPlayer = (item: LocalMedia) => { setSelected(item); setPrevious(screen); setScreen("player"); };

  const analyze = async (value = url) => {
    analyzer.current?.abort();
    const controller = new AbortController(); analyzer.current = controller;
    setAnalysis(null); setAnalyzeError("");
    let normalized: URL;
    try { normalized = new URL(value.trim()); if (normalized.protocol !== "https:") throw Error("HTTPS required"); }
    catch { setAnalyzeError(tr("اكتب رابطًا صحيحًا يبدأ بـ https://", "Enter a valid https:// link")); return; }
    setUrl(normalized.toString());
    if (isYouTube(normalized.toString())) {
      setAnalyzeError(tr("تحليل صيغ YouTube وتشغيله وتنزيل المحتوى المصرّح به يعمل داخل تطبيق Android بمحرك NewPipe وyt-dlp؛ المتصفح يمنع ذلك (CORS).",
        "YouTube extraction, playback and permitted downloads run inside the Android app (NewPipe + yt-dlp); browsers block it (CORS)."));
      return;
    }
    setAnalyzing(true);
    try {
      const response = await fetch(normalized.toString(), { method: "HEAD", signal: controller.signal, mode: "cors" });
      if (!response.ok) throw Error(`HTTP ${response.status}`);
      const mime = response.headers.get("Content-Type")?.split(";")[0].toLowerCase() || "";
      if (mime.startsWith("text/html")) {
        setAnalyzeError(tr("هذا الرابط صفحة ويب. صيّاد WebView الحقيقي متاح داخل APK فقط؛ لا نخترع ملفات في معاينة الويب.",
          "This is a web page. The actual WebView sniffer is in the APK; this preview does not invent media."));
        return;
      }
      const contentLength = Number(response.headers.get("Content-Length"));
      setAnalysis({ url: normalized.toString(), domain: normalized.hostname,
        name: contentName(response.headers.get("Content-Disposition"), normalized.toString()),
        type: mediaKind(mime), mime: mime || tr("نوع غير مُعلن", "Type not declared"),
        bytes: Number.isFinite(contentLength) && contentLength > 0 ? contentLength : null });
    } catch (issue) {
      if (controller.signal.aborted) return;
      setAnalyzeError(tr("تعذر تحليل الرابط من المتصفح بسبب CORS أو الشبكة. أرسله إلى تطبيق Android للتحليل الكامل. ",
        "Browser CORS or network access blocked this probe. Use the Android app for full analysis. ") + (issue instanceof Error ? issue.message : String(issue)));
    } finally { if (!controller.signal.aborted) setAnalyzing(false); }
  };

  const transfer = async (source: Analysis) => {
    if (source.bytes !== null && source.bytes > 512 * 1024 * 1024) {
      setNotice(tr("معاينة الويب لا تحتفظ بملفات أكبر من 512 MiB في الذاكرة؛ استخدم APK", "The web preview caps in-memory files at 512 MiB. Use the APK."));
      return;
    }
    const id = crypto.randomUUID();
    const controller = new AbortController(); pending.current[id] = controller;
    setJobs((current) => [{ id, url: source.url, name: source.name, kind: source.type, received: 0, total: source.bytes, speed: 0, status: "running" }, ...current]);
    try {
      const response = await fetch(source.url, { signal: controller.signal, mode: "cors" });
      if (!response.ok || !response.body) throw Error(`HTTP ${response.status} or streaming unavailable`);
      const declared = Number(response.headers.get("Content-Length"));
      const total = Number.isFinite(declared) && declared > 0 ? declared : null;
      const reader = response.body.getReader();
      const chunks: BlobPart[] = [];
      let received = 0; let lastBytes = 0; let lastTime = performance.now();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength) as ArrayBuffer); received += value.byteLength;
        if (received > 512 * 1024 * 1024) throw Error("Preview memory limit reached. Use Android APK.");
        const now = performance.now();
        if (now - lastTime > 180) {
          const speed = (received - lastBytes) * 1000 / (now - lastTime);
          setJobs((current) => current.map((job) => job.id === id ? { ...job, received, total, speed } : job));
          lastTime = now; lastBytes = received;
        }
      }
      const blob = new Blob(chunks, { type: source.mime || "application/octet-stream" });
      if (total !== null && total !== blob.size) throw Error("Response size mismatch; the incomplete file was discarded.");
      const file = new File([blob], source.name, { type: source.mime });
      setItems((existing) => [...existing, ...localMedia([file])]);
      setJobs((current) => current.map((job) => job.id === id ? { ...job, received: blob.size, total: blob.size, status: "done", speed: 0 } : job));
      const anchor = document.createElement("a"); const objectUrl = URL.createObjectURL(blob);
      anchor.href = objectUrl; anchor.download = source.name; anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
      setNotice(tr("اكتمل تنزيل الملف الحقيقي وحُفظ في المكتبة", "Real file downloaded and added to the library"));
    } catch (issue) {
      const canceled = controller.signal.aborted;
      setJobs((current) => current.map((job) => job.id === id ? {
        ...job, status: canceled ? "cancelled" : "failed", speed: 0,
        error: canceled ? undefined : issue instanceof Error ? issue.message : String(issue),
      } : job));
    } finally { delete pending.current[id]; }
  };

  const exportProfile = () => {
    const data = JSON.stringify(prefsRef.current, null, 2);
    const blob = new Blob([data], { type: "application/json" }); const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement("a"); anchor.href = objectUrl; anchor.download = "jo-don-local-profile.json"; anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
    setNotice(tr("تم تصدير ملفك المحلي", "Local profile exported"));
  };
  const importProfile = async (file: File | undefined) => {
    if (!file) return;
    try {
      const data = JSON.parse(await file.text()) as LocalPrefs;
      if (data.version !== 1 || !data.profile || !Array.isArray(data.profile.history) || typeof data.profile.following !== "object") throw Error("Unsupported profile format");
      const allowed = themes.some((item) => item.id === data.theme) ? data.theme : "aurora";
      setPrefs({ ...defaultPrefs(), ...data, theme: allowed,
        appearance: data.appearance === "light" ? "light" : "dark", lang: data.lang === "en" ? "en" : "ar",
        profile: { ...defaultPrefs().profile, ...data.profile, history: data.profile.history.slice(0, 300) } });
      setNotice(tr("تم استيراد الحساب المحلي والثيم", "Local profile and theme imported"));
    } catch (issue) { setNotice(tr("ملف غير صالح: ", "Invalid profile: ") + (issue instanceof Error ? issue.message : String(issue))); }
    if (profileRef.current) profileRef.current.value = "";
  };

  const desktopStyle = { "--theme-photo": `url("${themes.find((entry) => entry.id === theme)?.photo}")`, "--device-glow": "var(--accent2)" } as CSSProperties;
  return <div className="showcase app-root app-bg relative h-dvh overflow-hidden" dir={lang === "ar" ? "rtl" : "ltr"} data-theme={theme} data-appearance={appearance} style={desktopStyle}>
    <div className="showcase-photo" aria-hidden />
    <div className="aurora-field" aria-hidden><span className="aurora-blob b1" /><span className="aurora-blob b2" /><span className="aurora-blob b3" /></div>
    <input ref={importRef} type="file" multiple className="hidden" onChange={(event) => importLocal(event.target.files)} />
    <input ref={profileRef} type="file" accept="application/json" className="hidden" onChange={(event) => void importProfile(event.target.files?.[0])} />
    <div className="relative z-10 mx-auto flex h-full w-full max-w-[1240px] items-center justify-between gap-10 px-0 lg:px-10">
      <aside className="hidden max-w-[490px] flex-1 flex-col lg:flex">
        <Brand />
        <p className="mt-8 text-[12px] tracking-[0.18em]" style={{ color: "var(--accent2)" }}>A PRIVATE MEDIA UNIVERSE</p>
        <h1 className="mt-3 text-[53px] font-bold leading-[1.18] tracking-tight text-[var(--text-1)]">
          {tr("عالمك. ملفاتك.", "Your media.")}<br /><span className="text-gradient">{tr("حريتك.", "Your way.")}</span>
        </h1>
        <p className="mt-4 max-w-[410px] text-[13px] leading-7 muted">
          {tr("تصفّح الفيديوهات بواجهة أصلية، احفظ تفضيلاتك على جهازك، وشغّل ملفاتك حتى دون إنترنت. لا بيانات افتراضية، ولا خادم يراقبك.",
            "Browse a native video catalog, keep preferences on your device, and play your files offline. No fabricated data or tracking server.")}
        </p>
        <div className="mt-6 flex flex-wrap gap-2"><AccentButton onClick={() => navigate("youtube")}><YouTubeMark size={22} />{tr("استكشف YouTube", "Explore YouTube")}</AccentButton>
          <AccentButton secondary onClick={() => importRef.current?.click()}><FolderOpen size={14} />{tr("افتح ملفاتك", "Open your files")}</AccentButton></div>
        <div className="mt-9 flex flex-wrap items-center gap-4 text-[10px] muted"><span className="flex items-center gap-2"><ShieldCheck size={14} style={{ color: "var(--success)" }} />{tr("محلي بالكامل", "Local-first")}</span><span className="flex items-center gap-2"><Wifi size={14} style={{ color: "var(--accent2)" }} />{tr("تصفح عند الطلب", "Online when needed")}</span></div>
        <p className="mt-10 max-w-[430px] text-[9px] leading-5 faint">{tr("هذه معاينة ويب تتعامل مع ملفاتك المحلية فعليًا؛ عميل يوتيوب الأصلي والتحميل المجزّأ والمشغل الكامل موجودة في تطبيق Android داخل JP PROJ. المسؤولية على المستخدم في احترام حقوق النشر.",
          "This web preview works with your real local files; the native YouTube client, segmented downloads and full player live in the Android app (JP PROJ). Respect copyright.")}</p>
      </aside>

      <div className="device" role="application" aria-label="JO DON app preview">
        <div className="island" />
        <div className="device-screen app-root app-bg" data-theme={theme} data-appearance={appearance} dir={lang === "ar" ? "rtl" : "ltr"} style={desktopStyle}>
          <div className="device-wallpaper" aria-hidden />
          <ClockStatus />
          <main key={screen} className="phone-scroll no-scrollbar screen-enter relative min-h-0 flex-1 overflow-y-auto pb-[106px]">
            {screen === "home" && <div className="px-4 pb-5 pt-2">
              <div className="flex items-center justify-between"><Brand compact /><GlyphButton label={tr("الإعدادات", "Settings")} onClick={() => navigate("settings")}><Settings2 size={15} /></GlyphButton></div>
              <div className="relative mt-8"><span className="text-[10px] font-medium muted">{tr("مساحتك الخاصة، بلا حدود", "Your private space, without limits")}</span>
                <h1 className="mt-1 text-[33px] font-bold leading-[1.2] tracking-tight"><span className="text-gradient">𝒥𝒪 DON</span></h1>
                <p className="mt-2 max-w-[300px] text-[11px] leading-6 muted">{tr("رابط واحد يفتح لك كل الإمكانيات، وملفاتك تظل ملكًا لك.", "One link opens the possibilities. Your files stay yours.")}</p>
              </div>
              <div className="glow-shell calm mt-6"><div className="rounded-[27px] bg-[var(--bg-top)] p-3.5"><div className="mb-2 flex items-center gap-1.5 text-[10px] font-medium muted"><Link2 size={13} style={{ color: "var(--accent2)" }} />{tr("الصق رابطك", "Paste a link")}</div>
                <div className="glass-soft flex items-center gap-2 rounded-[15px] px-3 py-2.5"><Search size={15} className="shrink-0 faint" /><input dir="ltr" value={url} onChange={(event) => { setUrl(event.target.value); setAnalysis(null); setAnalyzeError(""); analyzer.current?.abort(); }}
                  onKeyDown={(event) => { if (event.key === "Enter") void analyze(); }} placeholder="https://..." className="min-w-0 flex-1 bg-transparent text-[11px] outline-none placeholder:text-[var(--text-3)]" />
                  {url && <button onClick={() => { setUrl(""); setAnalysis(null); setAnalyzeError(""); }} aria-label="Clear"><X size={13} className="faint" /></button>}</div>
                <div className="mt-2 flex gap-2"><AccentButton onClick={() => void analyze()} disabled={analyzing} className="flex-1">{analyzing ? <LoaderCircle size={14} className="spin-slow" /> : <Zap size={14} />}{analyzing ? tr("جارٍ الفحص الحقيقي...", "Checking real source...") : tr("تحليل الرابط", "Analyze link")}</AccentButton>
                  <GlyphButton label={tr("لصق", "Paste")} onClick={() => navigator.clipboard ? void navigator.clipboard.readText().then((text) => { setUrl(text); setAnalysis(null); }).catch(() => setNotice(tr("الحافظة غير متاحة", "Clipboard unavailable"))) : setNotice(tr("الحافظة غير متاحة", "Clipboard unavailable"))}><ClipboardPaste size={15} /></GlyphButton></div>
                <p className="mt-2 text-[9px] faint">{tr("الفحص هنا عبر HEAD الحقيقي؛ التحليل الشامل داخل APK", "Real HEAD probe here; full extraction in the APK")}</p>
              </div></div>
              {analyzeError && <div className="mt-3 flex items-start gap-2 rounded-[17px] border border-[#ffd284]/20 bg-[#ffd284]/5 p-3 text-[10px] leading-5 text-[var(--warning)]"><Info size={14} className="mt-0.5 shrink-0" />{analyzeError}</div>}
              {analysis && <div className="glass mt-3 rounded-[23px] p-3.5"><div className="flex items-center gap-2"><div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl accent-soft"><Globe size={15} style={{ color: "var(--accent2)" }} /></div><div className="min-w-0 flex-1"><div className="truncate text-[11px] font-semibold" dir="ltr">{analysis.domain}</div><div className="truncate text-[9px] muted" dir="ltr">{analysis.name}</div></div><Chip tone={analysis.bytes === null ? "warning" : "success"}>{analysis.bytes === null ? tr("غير مؤكد", "Unknown size") : tr("مؤكد", "Exact")}</Chip></div>
                {analysis.type === "image" && <img src={analysis.url} alt={analysis.name} className="mt-3 max-h-[140px] w-full rounded-[14px] object-contain" />}
                <div className="mt-3 flex items-center justify-between border-t border-white/10 pt-2.5"><div><div className="text-[11px] font-semibold">{tr(typeInfo[analysis.type].ar, typeInfo[analysis.type].en)} · {formatBytes(analysis.bytes)}</div><div className="mt-0.5 text-[9px] faint">{analysis.mime}</div></div><AccentButton onClick={() => void transfer(analysis)}><Download size={13} />{tr("تحميل", "Download")}</AccentButton></div>
                <p className="mt-2 text-[9px] faint">{tr("يظهر النوع فقط إذا أعلنه المصدر في استجابة حقيقية. لا أحجام تقديرية مخترعة.", "Content type comes from a real response; no invented formats or sizes.")}</p></div>}
              {!analysis && !analyzeError && <div className="mt-5 flex flex-col items-center rounded-[24px] py-5 text-center"><div className="orb h-20 w-20" /><h2 className="mt-5 text-[14px] font-semibold">{tr("جاهز عندما تكون جاهزًا", "Ready when you are")}</h2><p className="mt-1 max-w-[270px] text-[10px] leading-5 muted">{tr("افتح ملفًا محليًا أو أدخل رابطًا حقيقيًا. لا فيديوهات ولا تحميلات تجريبية.", "Open a local file or enter a real link. No sample videos or pretend downloads.")}</p></div>}
              <div className="mt-4"><h2 className="mb-2 text-[12px] font-semibold">{tr("انتقل مباشرة", "Jump into")}</h2><div className="grid grid-cols-3 gap-2"><button onClick={() => navigate("youtube")} className="press glass-soft flex flex-col items-center gap-2 rounded-[17px] py-3"><YouTubeMark size={26} /><span className="text-[10px]">YouTube</span></button><button onClick={() => importRef.current?.click()} className="press glass-soft flex flex-col items-center gap-2 rounded-[17px] py-3"><Music2 size={17} style={{ color: "var(--accent2)" }} /><span className="text-[10px]">{tr("موسيقاي", "My music")}</span></button><button onClick={() => navigate("tools")} className="press glass-soft flex flex-col items-center gap-2 rounded-[17px] py-3"><Zap size={17} style={{ color: "var(--accent3)" }} /><span className="text-[10px]">{tr("الأدوات", "Tools")}</span></button></div></div>
              {jobs.length > 0 && <div className="mt-4"><div className="mb-2 flex items-center justify-between"><h2 className="text-[12px] font-semibold">{tr("آخر التحميلات", "Recent downloads")}</h2><button onClick={() => navigate("downloads")} className="text-[10px]" style={{ color: "var(--accent2)" }}>{tr("عرض الكل", "View all")}</button></div>{jobs.slice(0, 2).map((job) => <TransferRow key={job.id} job={job} lang={lang} />)}</div>}
              <p className="mt-5 text-center text-[9px] faint">{tr("المسؤولية على المستخدم في احترام حقوق النشر · لا تجاوز DRM", "Respect copyright · no DRM bypass")}</p>
            </div>}
            {screen === "downloads" && <div className="px-4 pb-5 pt-1"><Header eyebrow={tr("سرعة مُقاسة من البايتات الفعلية", "Speed from actual transferred bytes")} title={tr("مدير التحميلات", "Downloads")} action={<GlyphButton label={tr("رابط جديد", "New link")} onClick={() => navigate("home")}><Plus size={16} /></GlyphButton>} />
              <div className="glass mt-4 rounded-[22px] p-3.5"><div className="text-[10px] muted">{tr("النقل الجاري من المتصفح", "Browser transfers now")}</div><div className="mt-1 font-[Outfit] text-[27px] font-semibold">{formatBytes(jobs.filter((job) => job.status === "running").reduce((total, job) => total + job.speed, 0))}<span className="ms-1 text-[11px] muted">/s</span></div><p className="mt-1 text-[9px] faint">{tr("التحميل المجزّأ والاستئناف بعد إغلاق التطبيق متاحان في APK، وليس في المتصفح.", "Segmented downloads and resume after app close are Android features, not browser features.")}</p></div>
              {jobs.length ? <div className="stagger mt-4 space-y-2.5">{jobs.map((job) => <TransferRow key={job.id} job={job} lang={lang} onCancel={() => { pending.current[job.id]?.abort(); setJobs((current) => current.map((item) => item.id === job.id ? { ...item, status: "cancelled" } : item)); }} onRetry={() => { const current = analysis?.url === job.url ? analysis : { url: job.url, domain: domainOf(job.url), name: job.name, type: job.kind, mime: "application/octet-stream", bytes: job.total }; void transfer(current); }} />)}</div> : <div className="mt-14 text-center"><div className="mx-auto flex h-16 w-16 items-center justify-center rounded-[20px] accent-soft"><Download size={24} style={{ color: "var(--accent2)" }} /></div><h3 className="mt-4 text-[14px] font-semibold">{tr("لا تحميلات بعد", "No downloads yet")}</h3><p className="mt-2 text-[10px] muted">{tr("لن نعرض تقدمًا وهميًا. يبدأ العداد عند نقل بيانات حقيقية فقط.", "No simulated progress. Counters move only with real bytes.")}</p><AccentButton onClick={() => navigate("home")} className="mx-auto mt-4">{tr("أضف رابطًا", "Add a link")}</AccentButton></div>}</div>}
            {screen === "youtube" && <YouTubePanel prefs={prefs} setPrefs={setPrefs} notify={setNotice} onExport={exportProfile} onImport={() => profileRef.current?.click()} />}
            {screen === "browser" && <div className="px-4 pb-5 pt-1"><Header eyebrow={tr("فتح مواقع حقيقية دون محاكاة", "Real sites, no simulation")} title={tr("المتصفح", "Browser")} action={<Compass size={18} style={{ color: "var(--accent2)" }} />} />
              <div className="mt-5 flex gap-2"><div className="glass-soft flex min-w-0 flex-1 items-center gap-2 rounded-[15px] px-3"><Globe size={15} className="faint" /><input value={browserUrl} onChange={(event) => setBrowserUrl(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") { try { const target = new URL(browserUrl.startsWith("http") ? browserUrl : `https://${browserUrl}`); window.open(target.toString(), "_blank", "noopener,noreferrer"); } catch { setNotice(tr("عنوان غير صحيح", "Invalid address")); } } }} placeholder="https://..." dir="ltr" className="min-w-0 flex-1 bg-transparent py-2.5 text-[11px] outline-none" /></div><AccentButton onClick={() => { try { const target = new URL(browserUrl.startsWith("http") ? browserUrl : `https://${browserUrl}`); window.open(target.toString(), "_blank", "noopener,noreferrer"); } catch { setNotice(tr("عنوان غير صحيح", "Invalid address")); } }} className="px-3"><ArrowUpRight size={16} /></AccentButton></div>
              <div className="mt-9 rounded-[24px] border border-white/10 bg-white/[.04] p-5 text-center"><div className="mx-auto flex h-14 w-14 items-center justify-center rounded-[19px] accent-soft"><Compass size={24} style={{ color: "var(--accent2)" }} /></div><h3 className="mt-4 text-[14px] font-semibold">{tr("متصفح Android الفعلي في APK", "The real Android browser lives in the APK")}</h3><p className="mt-2 text-[10px] leading-6 muted">{tr("في الويب لا يمكن اعتراض طلبات مواقع أخرى أو نقل Cookies بسبب عزل المتصفح. زر فتح الموقع هنا حقيقي؛ WebView والصيّاد وتحويل الكوكيز متاحة في تطبيق Android.", "Web browsers cannot intercept other sites or transfer their cookies due to isolation. This Open button works; WebView sniffing and cookie hand-off are Android-only.")}</p></div>
              <p className="mt-4 text-center text-[9px] faint">{tr("لا نعرض نتائج اصطياد وهمية أو تحديات Cloudflare محلولة بلا حدوثها.", "No pretend sniffing results or fake Cloudflare clearances.")}</p></div>}
            {screen === "files" && <LocalLibrary lang={lang} items={items} onImport={() => importRef.current?.click()} onOpen={openPlayer} />}
            {screen === "player" && selected && <LocalPlayer item={selected} playlist={items.filter((entry) => entry.kind === selected.kind)} lang={lang} onBack={() => navigate(previous === "player" ? "files" : previous)} onNext={setSelected} notify={setNotice} />}
            {screen === "tools" && <ToolsPanel lang={lang} items={items} onOpenPlayer={openPlayer} notify={setNotice} />}
            {screen === "settings" && <div className="px-4 pb-6 pt-1"><Header eyebrow={tr("كل شيء يبقى على جهازك", "Everything stays on your device")} title={tr("الإعدادات", "Settings")} action={<GlyphButton label="Info" onClick={() => setAboutOpen(true)}><Info size={15} /></GlyphButton>} />
              <div className="mt-4"><h3 className="text-[12px] font-semibold">{tr("اختر عالمك", "Choose your world")}</h3><p className="mt-1 text-[10px] muted">{tr("كل ثيم بصورة واقعية وألوان وحركة تخصه في جميع الشاشات.", "Real photography, palette and motion across every screen.")}</p><div className="mt-3 grid grid-cols-3 gap-2">{themes.map((item) => <button key={item.id} onClick={() => setPrefs((current) => ({ ...current, theme: item.id }))} aria-label={copy(lang, item.ar, item.en)} className={`press relative aspect-[1.25] overflow-hidden rounded-[15px] border-2 ${theme === item.id ? "border-[var(--accent2)]" : "border-white/10"}`}><img src={item.photo} alt="" className="h-full w-full object-cover" /><span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent px-1.5 pb-1 pt-5 text-[10px] font-medium text-white">{copy(lang, item.ar, item.en)}</span>{theme === item.id && <span className="absolute end-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-white text-black"><Check size={10} /></span>}</button>)}</div></div>
              <div className="glass-soft mt-4 space-y-3 rounded-[19px] p-3"><div className="flex items-center justify-between"><span className="flex items-center gap-2 text-[11px]"><Moon size={14} style={{ color: "var(--accent2)" }} />{tr("الوضع الفاتح", "Light mode")}</span><button onClick={() => setPrefs((current) => ({ ...current, appearance: current.appearance === "dark" ? "light" : "dark" }))} role="switch" aria-checked={appearance === "light"} className={`toggle-preview ${appearance === "light" ? "on" : ""}`}><span /></button></div><div className="h-px bg-white/10" /><div className="flex items-center justify-between"><span className="flex items-center gap-2 text-[11px]"><Globe size={14} style={{ color: "var(--accent2)" }} />{tr("اللغة", "Language")}</span><div className="flex rounded-full border border-white/10 p-0.5">{(["ar", "en"] as Lang[]).map((value) => <button key={value} onClick={() => setPrefs((current) => ({ ...current, lang: value }))} className={`rounded-full px-2 py-1 text-[9px] ${lang === value ? "accent-soft text-[var(--text-1)]" : "faint"}`}>{value === "ar" ? "العربية" : "English"}</button>)}</div></div></div>
              <div className="glass-soft mt-3 rounded-[19px] p-3"><div className="text-[11px] font-semibold">{tr("ملفك الشخصي المحلي", "Your local profile")}</div><p className="mt-1 text-[9px] leading-5 muted">{tr("تصدير واستيراد سجل المشاهدة والاشتراكات والثيم والإعدادات كملف JSON.", "Export and import history, subscriptions, theme and settings as JSON.")}</p><div className="mt-3 flex gap-2"><AccentButton secondary onClick={exportProfile} className="flex-1"><Download size={13} />{tr("تصدير", "Export")}</AccentButton><AccentButton secondary onClick={() => profileRef.current?.click()} className="flex-1"><FolderOpen size={13} />{tr("استيراد", "Import")}</AccentButton></div></div>
              <div className="mt-4"><AccentButton onClick={() => navigate("youtube")} className="w-full"><YouTubeMark size={20} />{tr("صفحة YouTube والملف المحلي", "YouTube page & local profile")}</AccentButton></div>
              <div className="glass-soft mt-3 rounded-[18px] p-3"><div className="flex items-center gap-2 text-[11px] font-semibold"><ShieldCheck size={15} style={{ color: "var(--success)" }} />{tr("خصوصية حقيقية", "Real privacy")}</div><p className="mt-1 text-[9px] leading-5 muted">{tr("تعمل الواجهة بلا شبكة؛ الاتصال مطلوب فقط لتصفح يوتيوب داخل التطبيق أو نقل رابط حقيقي. لا Firebase ولا تحليلات ولا قاعدة بيانات.", "The UI works offline; network is used only for YouTube data and actual transfers. No Firebase, analytics or database.")}</p></div>
              <p className="mt-4 text-[9px] leading-5 text-[var(--warning)]">{tr("المسؤولية على المستخدم في احترام حقوق النشر. لا تجاوز DRM أو Paywalls.", "Respect copyright. No DRM or paywall bypass.")}</p>
            </div>}
          </main>
          {screen !== "player" && <Dock screen={screen} lang={lang} onNavigate={navigate} active={active} />}
          {notice && <div className="toast-enter pointer-events-none absolute inset-x-4 bottom-[94px] z-[95] flex justify-center"><div className="glass-deep pointer-events-auto flex w-full items-center gap-2.5 rounded-[17px] px-3 py-2.5 text-[10px]"><Check size={14} className="shrink-0" style={{ color: "var(--success)" }} /><span className="flex-1 leading-4">{notice}</span><button onClick={() => setNotice("")} aria-label="Dismiss"><X size={12} /></button></div></div>}
          {aboutOpen && <Sheet title="𝒥𝒪 DON" subtitle={tr("تطبيق Android وواجهة ويب محلية", "Android app and local web preview")} onClose={() => setAboutOpen(false)}><p className="text-[11px] leading-6 muted">{tr("المشروع الأصلي في JP PROJ. تلتزم معاينة الويب بعرض بيانات حقيقية فقط؛ بعض إمكانيات Android غير ممكنة داخل المتصفح بسبب قيود النظام وCORS.", "The native project is in JP PROJ. This preview shows only real data; some Android features cannot run in a browser due to OS and CORS restrictions.")}</p></Sheet>}
        </div>
      </div>
    </div>
  </div>;
}

function TransferRow({ job, lang, onCancel, onRetry }: { job: Transfer; lang: Lang; onCancel?: () => void; onRetry?: () => void }) {
  const Icon = typeInfo[job.kind].icon;
  return <div className="glass-soft rounded-[18px] p-2.5"><div className="flex items-center gap-2.5"><div className="accent-soft flex h-9 w-9 shrink-0 items-center justify-center rounded-[11px]"><Icon size={15} style={{ color: "var(--accent2)" }} /></div><div className="min-w-0 flex-1"><div className="truncate text-[10px] font-semibold" dir="ltr">{job.name}</div><div className="mt-0.5 text-[9px] muted">{job.status === "running" ? copy(lang, "جارٍ النقل الحقيقي", "Transferring real bytes") : job.status === "done" ? copy(lang, "مكتمل", "Completed") : job.status === "cancelled" ? copy(lang, "أُلغي", "Cancelled") : copy(lang, "فشل", "Failed")}</div></div>{job.status === "running" && onCancel && <GlyphButton label={copy(lang, "إلغاء", "Cancel")} onClick={onCancel}><X size={13} /></GlyphButton>}{job.status === "failed" && onRetry && <AccentButton onClick={onRetry} className="px-2 py-1.5 text-[9px]">{copy(lang, "إعادة", "Retry")}</AccentButton>}</div>
    {job.status === "running" && job.total !== null && <div className="progress-track mt-2 h-1 rounded-full"><div className="progress-fill h-full rounded-full" style={{ width: `${Math.min(100, job.received * 100 / job.total)}%` }} /></div>}
    <div className="mt-1.5 flex items-center justify-between text-[8px] faint"><span>{formatBytes(job.received)}{job.total !== null ? ` / ${formatBytes(job.total)}` : ""}</span><span>{job.status === "running" ? `${formatBytes(job.speed)}/s` : job.status === "done" ? "100%" : ""}</span></div>
    {job.error && <div className="mt-1 flex gap-1 text-[9px] text-[var(--danger)]"><CircleAlert size={11} className="shrink-0" />{job.error}</div>}
  </div>;
}