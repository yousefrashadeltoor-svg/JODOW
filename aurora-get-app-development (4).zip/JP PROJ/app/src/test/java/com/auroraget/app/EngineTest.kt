package com.auroraget.app

import com.auroraget.app.data.rangeWindows
import com.auroraget.app.engine.YouTubeEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineTest {
    @Test fun rangesCoverFileExactlyOnce() {
        for ((total, parts) in listOf(1L to 8, 17L to 8, 1_000_003L to 16, 148_372_910L to 32)) {
            val windows = rangeWindows(total, parts)
            assertEquals(0L, windows.first().first)
            assertEquals(total - 1, windows.last().last)
            windows.zipWithNext().forEach { (a, b) -> assertEquals(a.last + 1, b.first) }
            assertEquals(total, windows.sumOf { it.last - it.first + 1 })
        }
    }

    /** Live check against YouTube through NewPipe Extractor (needs network). */
    @Test fun liveYouTubeBrowsing() = runBlocking {
        val engine = YouTubeEngine()
        val suggestions = engine.suggest("lofi")
        println("LIVE suggestions=${suggestions.size} ${suggestions.take(3)}")
        val page = engine.search("big buck bunny")
        println("LIVE search items=${page.items.size} hasNext=${page.next != null} first=${page.items.firstOrNull()?.title}")
        assertTrue(page.items.isNotEmpty())
        val more = page.next?.invoke()
        println("LIVE page2 items=${more?.items?.size}")
        val kiosks = runCatching { engine.kiosks() }.getOrElse { println("LIVE kiosks error ${it.message}"); emptyList() }
        println("LIVE kiosks=$kiosks")
        kiosks.firstOrNull()?.let { id -> println("LIVE kiosk[$id] items=" + runCatching { engine.kiosk(id).items.size }.getOrElse { e -> "ERR ${e.message}" }) }
        val first = page.items.first()
        val stream = runCatching { engine.stream(first.url) }
        stream.onSuccess { s ->
            println("LIVE stream title=${s.title} hls=${s.hlsUrl.isNotBlank()} dash=${s.dashUrl.isNotBlank()} muxed=${s.muxed.size} videoOnly=${s.videoOnly.size} audio=${s.audio.size} related=${s.related.size} sizes=${s.videoOnly.count { it.bytes != null }}")
        }.onFailure { println("LIVE stream ERROR ${it.javaClass.simpleName}: ${it.message}") }
        val channel = runCatching { engine.channel(first.channelUrl) }
        channel.onSuccess { c -> println("LIVE channel=${c.name} subs=${c.subscribers} videos=${c.videos().items.size} shortsTab=${c.shorts != null}") }
            .onFailure { println("LIVE channel ERROR ${it.message}") }
        println("LIVE comments=" + runCatching { engine.comments(first.url).size }.getOrElse { "ERR ${it.message}" })
    }
}
