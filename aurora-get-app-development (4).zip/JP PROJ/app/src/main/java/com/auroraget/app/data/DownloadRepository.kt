package com.auroraget.app.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.auroraget.app.MainActivity
import com.auroraget.app.R
import com.auroraget.app.engine.ExtractorEngine
import com.auroraget.app.engine.LinkAnalyzer
import com.auroraget.app.engine.NetworkClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Response
import java.io.File
import java.io.RandomAccessFile
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicBoolean
import java.nio.ByteBuffer
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import okhttp3.Call
import androidx.core.app.ServiceCompat
import android.content.pm.ServiceInfo

const val DOWNLOAD_CHANNEL_ID = "jo_don_downloads"
private const val START = "com.auroraget.app.START"
private const val PAUSE = "com.auroraget.app.PAUSE"
private const val RESUME = "com.auroraget.app.RESUME"
private const val CANCEL = "com.auroraget.app.CANCEL"

data class DownloadRequest(
    val url: String,
    val name: String,
    val site: String,
    val type: ContentType,
    val quality: String,
    val totalBytes: Long,
    val approx: Boolean,
    val headers: Map<String, String> = emptyMap(),
    val formatId: String? = null,
    val requiresExtractor: Boolean = false,
    val needsMerge: Boolean = false,
)

data class DownloadProgress(
    val bytesPerSecond: Long = 0L,
    val activeConnections: Int = 0,
)

/** Byte ranges never overlap and cover [0, total - 1] exactly. */
fun rangeWindows(total: Long, requested: Int): List<LongRange> {
    require(total > 0)
    val count = requested.coerceIn(1, 32).coerceAtMost(total.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
    val base = total / count
    val extra = total % count
    var start = 0L
    return List(count) { index ->
        val length = base + if (index < extra) 1 else 0
        val range = start..(start + length - 1)
        start += length
        range
    }
}

class DownloadRepository(
    private val context: Context,
    private val store: LocalStore,
    private val analyzer: LinkAnalyzer,
    private val extractor: ExtractorEngine,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val active = ConcurrentHashMap<String, Job>()
    private val calls = ConcurrentHashMap<String, MutableSet<Call>>()
    fun hasActive(): Boolean = active.isNotEmpty()
    private val mutableSpeeds = MutableStateFlow<Map<String, DownloadProgress>>(emptyMap())
    val speeds = mutableSpeeds.asStateFlow()
    val allDownloads = store.state.map { it.downloads.sortedWith(compareByDescending<DownloadEntity> { it.priority }.thenByDescending { it.createdAt }) }

    fun outputDir(type: ContentType): File {
        val root = File(context.getExternalFilesDir(null) ?: context.filesDir, "JO_DON")
        return File(root, type.name.lowercase()).apply { mkdirs() }
    }

    suspend fun enqueue(request: DownloadRequest, connectionTarget: Int = 16): String {
        require(request.url.startsWith("https://")) { "HTTPS is required" }
        val id = UUID.randomUUID().toString()
        val name = request.name.substringAfterLast('/').replace(Regex("[\\\\/:*?\"<>|]"), "_").take(120).ifBlank { "download_$id" }
        val probe = if (request.requiresExtractor) null else analyzer.probeSize(request.url, request.headers)
        val total = probe?.bytes ?: request.totalBytes
        val count = if (probe?.acceptsRanges == true && total >= 16L * 1024 * 1024) {
            connectionTarget.coerceIn(8, 32).coerceAtMost((total / (2 * 1024 * 1024)).toInt().coerceAtLeast(1))
        } else 1
        val dir = outputDir(request.type)
        val output = File(dir, "${id.take(8)}_$name")
        val download = DownloadEntity(
            id = id, url = request.url, name = name, site = request.site,
            type = request.type, quality = request.quality, totalBytes = total,
            approx = if (probe?.bytes != null) false else request.approx,
            connections = count, etag = probe?.etag,
            lastModified = probe?.lastModified, acceptsRanges = probe?.acceptsRanges == true,
            headers = request.headers, formatId = request.formatId,
            requiresExtractor = request.requiresExtractor,
            needsMerge = request.needsMerge,
            outputPath = output.absolutePath,
        )
        store.update { state ->
            state.copy(
                downloads = listOf(download) + state.downloads,
                segments = state.segments + if (count > 1) rangeWindows(total, count).mapIndexed { index, window ->
                    SegmentEntity(id, index, window.first, window.last)
                } else emptyList(),
            )
        }
        start(id)
        return id
    }

    fun start(id: String) {
        if (store.state.value.settings.wifiOnly) {
            val cm = context.getSystemService(ConnectivityManager::class.java)
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) != true) {
                scope.launch { change(id) { it.copy(status = DownloadStatus.QUEUED, error = "Wi-Fi required") } }
                return
            }
        }
        ContextCompat.startForegroundService(context,
            Intent(context, DownloadForegroundService::class.java).setAction(START).putExtra("id", id))
    }

    fun resumeUnfinished() {
        store.state.value.downloads.filter { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.QUEUED }
            .forEach { start(it.id) }
    }

    fun pause(id: String) {
        active.remove(id)?.cancel()
        calls.remove(id)?.forEach { it.cancel() }
        runCatching { extractor.cancel(id) }
        scope.launch { change(id) { it.copy(status = DownloadStatus.PAUSED) } }
        mutableSpeeds.value = mutableSpeeds.value - id
    }

    fun cancel(id: String) {
        active.remove(id)?.cancel()
        calls.remove(id)?.forEach { it.cancel() }
        runCatching { extractor.cancel(id) }
        scope.launch {
            val item = store.state.value.downloads.firstOrNull { it.id == id }
            item?.outputPath?.let { File(it).takeIf(File::exists)?.delete() }
            store.update { it.copy(
                downloads = it.downloads.filterNot { item -> item.id == id },
                segments = it.segments.filterNot { segment -> segment.downloadId == id },
            ) }
        }
        mutableSpeeds.value = mutableSpeeds.value - id
    }

    private suspend fun change(id: String, update: (DownloadEntity) -> DownloadEntity) {
        store.update { it.copy(downloads = it.downloads.map { entry -> if (entry.id == id) update(entry) else entry }) }
    }

    fun launchWorker(id: String, onProgress: (DownloadEntity) -> Unit) {
        if (active[id]?.isActive == true) return
        active[id] = scope.launch {
            try {
                val item = store.state.value.downloads.firstOrNull { it.id == id } ?: return@launch
                change(id) { it.copy(status = DownloadStatus.DOWNLOADING, error = null) }
                if (item.requiresExtractor) runExtractor(item, onProgress)
                else runHttp(item, onProgress)
            } catch (_: CancellationException) {
                // Pause preserves every persisted segment offset.
            } catch (error: Exception) {
                // A cancelled socket surfaces as IOException after pause(); that is not a failure.
                if (isActive) change(id) { it.copy(status = DownloadStatus.FAILED, error = error.message) }
            } finally {
                active.remove(id)
                mutableSpeeds.value = mutableSpeeds.value - id
                store.state.value.downloads.firstOrNull { it.id == id }?.let(onProgress)
            }
        }
    }

    private suspend fun runExtractor(item: DownloadEntity, onProgress: (DownloadEntity) -> Unit) =
        withContext(Dispatchers.IO) {
            val file = File(item.outputPath)
            val done = extractor.download(item.url, item.formatId ?: "best", file, item.id,
                merge = item.needsMerge) { percentage ->
                // The callback comes from yt-dlp: never show a fabricated byte count.
                scope.launch {
                    val total = item.totalBytes
                    if (total > 0) change(item.id) { it.copy(downloadedBytes = (total * percentage / 100).toLong()) }
                    store.state.value.downloads.firstOrNull { it.id == item.id }?.let(onProgress)
                }
            }
            change(item.id) { it.copy(status = DownloadStatus.COMPLETED, downloadedBytes = done.length(),
                totalBytes = done.length(), approx = false, outputPath = done.absolutePath) }
        }

    private suspend fun runHttp(item: DownloadEntity, onProgress: (DownloadEntity) -> Unit) {
        val file = File(item.outputPath)
        file.parentFile?.mkdirs()
        val fresh = analyzer.probeSize(item.url, item.headers)
        if (item.downloadedBytes > 0 && (
                    (item.etag != null && fresh.etag != null && item.etag != fresh.etag) ||
                    (item.lastModified != null && fresh.lastModified != null && item.lastModified != fresh.lastModified))) {
            error("Source changed (ETag / Last-Modified). A new download is required.")
        }
        if (item.acceptsRanges && fresh.acceptsRanges && item.totalBytes > 0 && item.connections > 1) {
            val windows = store.state.value.segments.filter { it.downloadId == item.id }
            val written = ConcurrentHashMap<Int, Long>().apply { windows.forEach { put(it.segmentIndex, it.written) } }
            val moved = AtomicLong(0)
            val lastFlush = AtomicLong(SystemClock.elapsedRealtime())
            val flushing = AtomicBoolean(false)
            val workers = AtomicInteger(0)
            val openCalls = calls.getOrPut(item.id) { ConcurrentHashMap.newKeySet() }
            RandomAccessFile(file, "rw").use { raf ->
                if (raf.length() < item.totalBytes) raf.setLength(item.totalBytes)
                val channel = raf.channel
                // One batched, durable checkpoint for all segments (at most once per second).
                suspend fun flush() {
                    channel.force(false)
                    val now = SystemClock.elapsedRealtime()
                    val period = (now - lastFlush.getAndSet(now)).coerceAtLeast(1)
                    val bytes = moved.getAndSet(0)
                    store.update { snapshot ->
                        val segments = snapshot.segments.map { s ->
                            if (s.downloadId != item.id) s else {
                                val done = written[s.segmentIndex] ?: s.written
                                s.copy(written = done, completed = done >= s.end - s.start + 1)
                            }
                        }
                        val total = segments.filter { it.downloadId == item.id }.sumOf { it.written }
                        snapshot.copy(segments = segments, downloads = snapshot.downloads.map { d ->
                            if (d.id == item.id) d.copy(downloadedBytes = total) else d
                        })
                    }
                    mutableSpeeds.value = mutableSpeeds.value + (item.id to DownloadProgress(bytes * 1000 / period, workers.get()))
                    store.state.value.downloads.firstOrNull { it.id == item.id }?.let(onProgress)
                }
                try {
                    coroutineScope {
                        windows.map { window -> async(Dispatchers.IO) {
                            val size = window.end - window.start + 1
                            var done = written[window.segmentIndex] ?: 0L
                            if (done >= size) return@async
                            val offset = window.start + done
                            val headers = item.headers + mapOf("Range" to "bytes=$offset-${window.end}") +
                                listOfNotNull(item.etag?.let { "If-Range" to it },
                                    if (item.etag == null) item.lastModified?.let { "If-Range" to it } else null).toMap()
                            val call = NetworkClient.client.newCall(NetworkClient.requestBuilder(item.url, headers).get().build())
                            openCalls += call
                            workers.incrementAndGet()
                            try {
                                call.execute().use { response ->
                                    verifyPartial(response, offset, window.end, item.totalBytes)
                                    val input = response.body?.byteStream() ?: error("Empty server response")
                                    val buffer = ByteArray(256 * 1024)
                                    while (true) {
                                        ensureActive()
                                        val read = input.read(buffer)
                                        if (read < 0) break
                                        if (done + read > size) error("Range exceeds segment boundary")
                                        val chunk = ByteBuffer.wrap(buffer, 0, read)
                                        var at = window.start + done
                                        while (chunk.hasRemaining()) at += channel.write(chunk, at)
                                        done += read
                                        written[window.segmentIndex] = done
                                        moved.addAndGet(read.toLong())
                                        if (SystemClock.elapsedRealtime() - lastFlush.get() >= 1000 && flushing.compareAndSet(false, true)) {
                                            try { flush() } finally { flushing.set(false) }
                                        }
                                    }
                                    if (done != size) error("Server ended range early")
                                }
                            } finally {
                                openCalls -= call
                                workers.decrementAndGet()
                            }
                        } }.awaitAll()
                    }
                } finally {
                    withContext(NonCancellable) { flush() }
                }
            }
            calls.remove(item.id)
            val final = store.state.value.segments.filter { it.downloadId == item.id }
            if (final.any { !it.completed }) error("One or more segments are incomplete")
            if (file.length() != item.totalBytes) error("File size mismatch")
        } else {
            streamSingle(item, file, allowResume = fresh.acceptsRanges && item.connections == 1, onProgress)
        }
        change(item.id) { it.copy(status = DownloadStatus.COMPLETED, downloadedBytes = file.length(),
            totalBytes = file.length(), approx = false, outputPath = file.absolutePath) }
    }

    private suspend fun persistSegment(updated: SegmentEntity, id: String) {
        store.update { snapshot ->
            val segments = snapshot.segments.map { if (it.downloadId == id && it.segmentIndex == updated.segmentIndex) updated else it }
            snapshot.copy(segments = segments, downloads = snapshot.downloads.map { entry ->
                if (entry.id == id) entry.copy(downloadedBytes = segments.filter { it.downloadId == id }.sumOf { it.written }) else entry
            })
        }
    }

    private suspend fun streamSingle(item: DownloadEntity, file: File, allowResume: Boolean,
                                     onProgress: (DownloadEntity) -> Unit) =
        withContext(Dispatchers.IO) {
            // Without a verified 206 response, restarting from zero is safer than corrupting the file.
            val resume = if (allowResume && file.exists()) file.length() else 0L
            val headers = item.headers + if (resume > 0) mapOf("Range" to "bytes=$resume-") +
                listOfNotNull(item.etag?.let { "If-Range" to it },
                    if (item.etag == null) item.lastModified?.let { "If-Range" to it } else null).toMap() else emptyMap()
            NetworkClient.client.newCall(NetworkClient.requestBuilder(item.url, headers).get().build()).execute().use { response ->
                if (response.code !in 200..299) error("HTTP ${response.code}")
                val from = if (resume > 0 && response.code == 206) resume else 0L
                val input = response.body?.byteStream() ?: error("Empty response")
                RandomAccessFile(file, "rw").use { output ->
                    output.seek(from)
                    if (from == 0L) output.setLength(0)
                    var bytes = from
                    var window = 0L
                    var tick = SystemClock.elapsedRealtime()
                    val buffer = ByteArray(256 * 1024)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        output.write(buffer, 0, read)
                        bytes += read
                        window += read
                        val now = SystemClock.elapsedRealtime()
                        if (now - tick >= 750) {
                            output.fd.sync()
                            val speed = window * 1000 / (now - tick).coerceAtLeast(1)
                            mutableSpeeds.value = mutableSpeeds.value + (item.id to DownloadProgress(speed, 1))
                            change(item.id) { it.copy(downloadedBytes = bytes, totalBytes =
                                if (it.totalBytes == 0L) response.body?.contentLength()?.takeIf { length -> length > 0 } ?: 0 else it.totalBytes) }
                            store.state.value.downloads.firstOrNull { it.id == item.id }?.let(onProgress)
                            window = 0
                            tick = now
                        }
                    }
                }
            }
        }

    private fun verifyPartial(response: Response, start: Long, end: Long, total: Long) {
        if (response.code != 206) error("Server ignored byte ranges: HTTP ${response.code}")
        val expected = "bytes $start-$end/$total"
        if (response.header("Content-Range") != expected) error("Unexpected Content-Range")
    }

    fun ensureChannel() {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(DOWNLOAD_CHANNEL_ID,
            context.getString(R.string.download_channel_name), NotificationManager.IMPORTANCE_LOW))
    }
}

/** A true dataSync foreground service, not a detached WorkManager placeholder. */
class DownloadForegroundService : Service() {
    private val repo get() = org.koin.core.context.GlobalContext.get().get<DownloadRepository>()

    override fun onCreate() {
        super.onCreate()
        repo.ensureChannel()
        ServiceCompat.startForeground(this, 901, notification(null, null),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra("id")
        when (intent?.action) {
            PAUSE -> id?.let(repo::pause)
            CANCEL -> id?.let(repo::cancel)
            RESUME, START -> id?.let { repo.launchWorker(it) { entry ->
                getSystemService(NotificationManager::class.java).notify(entry.id.hashCode(), notification(entry.id, entry))
                if (!repo.hasActive()) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
            } }
        }
        if (intent?.action != START && intent?.action != RESUME && !repo.hasActive()) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        return START_STICKY
    }

    private fun notification(id: String?, item: DownloadEntity?): android.app.Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = NotificationCompat.Builder(this, DOWNLOAD_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_aurora).setContentTitle(item?.name ?: "𝒥𝒪 DON")
            .setContentText(item?.let { "${it.status} · ${formatBytes(it.downloadedBytes)} / ${formatBytes(it.totalBytes, it.approx)}" }
                ?: "مدير التحميلات يعمل")
            .setOnlyAlertOnce(true).setOngoing(item?.status == DownloadStatus.DOWNLOADING)
            .setContentIntent(open)
        if (item != null) {
            val known = item.totalBytes > 0
            builder.setProgress(100, if (known) (item.downloadedBytes * 100 / item.totalBytes).toInt().coerceIn(0, 100) else 0, !known)
            if (id != null) {
                builder.addAction(0, "إيقاف", action(id, PAUSE))
                builder.addAction(0, "استئناف", action(id, RESUME))
                builder.addAction(0, "إلغاء", action(id, CANCEL))
            }
        }
        return builder.build()
    }

    private fun action(id: String, command: String): PendingIntent = PendingIntent.getService(this,
        (id + command).hashCode(), Intent(this, DownloadForegroundService::class.java)
            .setAction(command).putExtra("id", id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    override fun onBind(intent: Intent?): IBinder? = null
}

class DownloadActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val repo = org.koin.core.context.GlobalContext.get().get<DownloadRepository>()
        val id = intent.getStringExtra("id") ?: return
        when (intent.action) {
            PAUSE -> repo.pause(id)
            RESUME -> repo.start(id)
            CANCEL -> repo.cancel(id)
        }
    }
}