package com.auroraget.app.ui.screens

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Rational
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.drm.DrmSessionManagerProvider
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import androidx.media3.session.MediaController
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.auroraget.app.data.ContentType
import com.auroraget.app.data.DownloadEntity
import com.auroraget.app.data.DownloadStatus
import com.auroraget.app.data.LocalStore
import com.auroraget.app.engine.NetworkClient
import com.auroraget.app.ui.components.AuroraButton
import com.auroraget.app.ui.components.AuroraGlass
import com.auroraget.app.ui.components.AuroraTag
import com.auroraget.app.ui.components.Glyph
import com.auroraget.app.ui.components.Ic
import com.auroraget.app.ui.components.tap
import com.auroraget.app.ui.theme.AuroraShapes
import com.auroraget.app.ui.theme.AuroraType
import com.auroraget.app.ui.theme.LocalAuroraColors
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.koin.core.context.GlobalContext
import java.io.File
import java.nio.ByteBuffer
import java.util.Locale

data class LocalTrack(val uri: Uri, val title: String, val audio: Boolean, val artist: String? = null)

private const val MERGE_PREFIX = "jo-merge:"

/** Builds an item the playback service can resolve (optionally video + separate audio). */
fun playableItem(
    uri: Uri, title: String, artist: String? = null, artwork: Uri? = null,
    separateAudio: String? = null, mime: String? = null, id: String = uri.toString(),
): MediaItem = MediaItem.Builder()
    .setMediaId(id)
    .setUri(uri)
    .setMimeType(mime)
    .setRequestMetadata(
        MediaItem.RequestMetadata.Builder().setMediaUri(uri).setExtras(Bundle().apply {
            separateAudio?.let { putString("audio", it) }
            mime?.let { putString("mime", it) }
        }).build()
    )
    .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).setArtworkUri(artwork).build())
    .build()

/**
 * One Media3 session for local files and network streams. It keeps playing in the
 * background with system/lock-screen controls and can merge separate video+audio URLs.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class LocalPlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(NetworkClient.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(25_000)
        val base = DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http))
        val merging = object : MediaSource.Factory {
            override fun setDrmSessionManagerProvider(provider: DrmSessionManagerProvider): MediaSource.Factory {
                base.setDrmSessionManagerProvider(provider); return this
            }
            override fun setLoadErrorHandlingPolicy(policy: LoadErrorHandlingPolicy): MediaSource.Factory {
                base.setLoadErrorHandlingPolicy(policy); return this
            }
            override fun getSupportedTypes(): IntArray = base.supportedTypes
            override fun createMediaSource(item: MediaItem): MediaSource {
                val key = item.localConfiguration?.customCacheKey
                if (key != null && key.startsWith(MERGE_PREFIX)) {
                    val video = base.createMediaSource(item.buildUpon().setCustomCacheKey(null).build())
                    val audio = base.createMediaSource(MediaItem.fromUri(key.removePrefix(MERGE_PREFIX)))
                    return MergingMediaSource(video, audio)
                }
                return base.createMediaSource(item)
            }
        }
        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(merging)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        session = MediaSession.Builder(this, player).setCallback(object : MediaSession.Callback {
            override fun onAddMediaItems(
                mediaSession: MediaSession, controller: MediaSession.ControllerInfo, mediaItems: MutableList<MediaItem>,
            ): ListenableFuture<MutableList<MediaItem>> = Futures.immediateFuture(mediaItems.map { item ->
                val extras = item.requestMetadata.extras
                item.buildUpon()
                    .setUri(item.localConfiguration?.uri ?: item.requestMetadata.mediaUri)
                    .setMimeType(extras?.getString("mime"))
                    .setCustomCacheKey(extras?.getString("audio")?.let { MERGE_PREFIX + it })
                    .build()
            }.toMutableList())
        }).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = session?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.let { it.player.release(); it.release() }
        session = null
        super.onDestroy()
    }
}

@Composable
fun rememberPlaybackController(): MediaController? {
    val context = LocalContext.current.applicationContext
    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(Unit) {
        val future = MediaController.Builder(
            context, SessionToken(context, ComponentName(context, LocalPlaybackService::class.java))
        ).buildAsync()
        future.addListener({ runCatching { controller = future.get() } }, ContextCompat.getMainExecutor(context))
        onDispose { controller = null; MediaController.releaseFuture(future) }
    }
    return controller
}

/** Decorative motion that only moves while something is actually playing. */
@Composable
fun PulseBars(playing: Boolean, modifier: Modifier = Modifier, bars: Int = 28) {
    val c = LocalAuroraColors.current
    val transition = rememberInfiniteTransition(label = "bars")
    val phase by transition.animateFloat(0f, (2 * Math.PI).toFloat(),
        infiniteRepeatable(tween(c.themeId.motionDuration / 3), RepeatMode.Restart), label = "phase")
    Canvas(modifier) {
        val slot = size.width / bars
        for (i in 0 until bars) {
            val wave = if (playing) (kotlin.math.sin(phase + i * 0.55f) * 0.5f + 0.5f) * (0.35f + 0.65f * kotlin.math.abs(kotlin.math.sin(i * 1.7f))) else 0.08f
            val h = (size.height * (0.12f + 0.88f * wave)).coerceAtLeast(3f)
            drawRoundRect(
                brush = Brush.verticalGradient(c.accents),
                topLeft = Offset(i * slot + slot * 0.2f, (size.height - h) / 2),
                size = Size(slot * 0.6f, h), cornerRadius = CornerRadius(slot),
            )
        }
    }
}

@Composable
fun SeekLine(value: Float, onSeek: (Float) -> Unit, modifier: Modifier = Modifier, buffered: Float = 0f) {
    val c = LocalAuroraColors.current
    var dragging by remember { mutableStateOf<Float?>(null) }
    Canvas(modifier.height(26.dp)
        .pointerInput(Unit) { detectTapGestures { onSeek((it.x / size.width).coerceIn(0f, 1f)) } }
        .pointerInput(Unit) {
            detectHorizontalDragGestures(
                onDragStart = { dragging = (it.x / size.width).coerceIn(0f, 1f) },
                onDragEnd = { dragging?.let(onSeek); dragging = null },
                onDragCancel = { dragging = null },
            ) { change, _ -> dragging = (change.position.x / size.width).coerceIn(0f, 1f) }
        }) {
        val shown = (dragging ?: value).coerceIn(0f, 1f)
        val center = size.height / 2
        val thick = 4.dp.toPx()
        val radius = CornerRadius(thick)
        drawRoundRect(c.lineStrong, Offset(0f, center - thick / 2), Size(size.width, thick), radius)
        if (buffered > 0f) drawRoundRect(c.textTertiary.copy(alpha = .55f), Offset(0f, center - thick / 2),
            Size(size.width * buffered.coerceIn(0f, 1f), thick), radius)
        drawRoundRect(Brush.horizontalGradient(c.accents), Offset(0f, center - thick / 2), Size(size.width * shown, thick), radius)
        drawCircle(Color.White, if (dragging != null) 8.dp.toPx() else 6.dp.toPx(), Offset(size.width * shown, center))
    }
}

fun clock(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return if (total >= 3600) String.format(Locale.US, "%d:%02d:%02d", total / 3600, total / 60 % 60, total % 60)
    else String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
}

/** Video + music player for files on the device. Works with no connection. */
@Composable
fun LocalPlayerScreen(queue: List<LocalTrack>, startIndex: Int, onBack: () -> Unit) {
    val c = LocalAuroraColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val controller = rememberPlaybackController()
    val store = remember { GlobalContext.get().get<LocalStore>() }
    var index by remember { mutableIntStateOf(startIndex.coerceIn(0, queue.lastIndex.coerceAtLeast(0))) }
    val track = queue.getOrNull(index) ?: return
    var message by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    var elapsed by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var rate by remember { mutableFloatStateOf(1f) }
    var repeat by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var shuffle by remember { mutableStateOf(false) }
    var audioOnly by remember { mutableStateOf(false) }
    var sleepJob by remember { mutableStateOf<Job?>(null) }
    var sleepEnd by remember { mutableLongStateOf(0L) }
    var sleepLeft by remember { mutableLongStateOf(0L) }
    var trimOpen by remember { mutableStateOf(false) }
    var trimStart by remember { mutableFloatStateOf(0f) }
    var trimEnd by remember { mutableFloatStateOf(1f) }
    var working by remember { mutableStateOf(false) }

    DisposableEffect(controller) {
        val player = controller ?: return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                index = player.currentMediaItemIndex.coerceIn(0, queue.lastIndex)
                trimOpen = false
            }
            override fun onPlayerError(error: PlaybackException) {
                message = "تعذر تشغيل هذا الملف: ${error.errorCodeName}"
            }
        }
        player.addListener(listener)
        player.setMediaItems(queue.map { playableItem(it.uri, it.title, it.artist) }, index, 0L)
        player.repeatMode = repeat
        player.shuffleModeEnabled = false
        player.setPlaybackSpeed(1f)
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false).build()
        player.prepare()
        player.play()
        onDispose {
            player.removeListener(listener)
            // Music keeps playing in the background; a video stops when its screen closes.
            if (queue.getOrNull(player.currentMediaItemIndex)?.audio != true) player.pause()
        }
    }

    LaunchedEffect(controller) {
        while (true) {
            controller?.let {
                elapsed = it.currentPosition.coerceAtLeast(0L)
                duration = it.duration.takeIf { d -> d > 0 } ?: 0L
            }
            if (sleepEnd > 0L) sleepLeft = (sleepEnd - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
            delay(250L)
        }
    }

    val artwork by produceState<Bitmap?>(initialValue = null, track.uri) {
        value = withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, track.uri)
                retriever.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
            } catch (_: Exception) { null } finally { runCatching { retriever.release() } }
        }
    }

    fun setTimer(minutes: Int) {
        sleepJob?.cancel()
        if (minutes == 0) { sleepEnd = 0L; sleepLeft = 0L; return }
        sleepEnd = SystemClock.elapsedRealtime() + minutes * 60_000L
        sleepJob = scope.launch { delay(minutes * 60_000L); controller?.pause(); sleepEnd = 0L }
    }

    suspend fun saveClip(): File? {
        if (duration <= 0) return null
        return runCatching {
            withContext(Dispatchers.IO) { trimToMp4(context, track.uri, (duration * trimStart).toLong(), (duration * trimEnd).toLong()) }
        }.onSuccess { out ->
            store.update { snapshot -> snapshot.copy(downloads = listOf(DownloadEntity(
                id = java.util.UUID.randomUUID().toString(), url = out.toURI().toString(), name = out.name, site = "local",
                type = if (track.audio) ContentType.AUDIO else ContentType.VIDEO, quality = "قص بدون إعادة ترميز",
                totalBytes = out.length(), approx = false, downloadedBytes = out.length(),
                status = DownloadStatus.COMPLETED, outputPath = out.absolutePath,
            )) + snapshot.downloads) }
        }.onFailure { message = "تعذر قص هذا الترميز بدون إعادة ترميز: ${it.message}" }.getOrNull()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(AuroraShapes.icon).background(c.glassStrong).tap(onClick = onBack),
                contentAlignment = Alignment.Center) { Glyph(Ic.BACK, c.textPrimary) }
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Txt(if (track.audio) "مشغل الموسيقى" else "مشغل الفيديو", style = AuroraType.heading)
                Txt("ملف محلي · يعمل بدون اتصال · ${index + 1}/${queue.size}", style = AuroraType.caption, color = c.textSecondary)
            }
            AuroraTag(if (track.audio) "AUDIO" else "VIDEO", color = c.accent2)
        }

        AuroraGlass(Modifier.fillMaxWidth(), radius = 24.dp) {
            Box(
                Modifier.fillMaxWidth().aspectRatio(if (track.audio) 1.25f else 16f / 9f)
                    .background(Brush.linearGradient(c.accents.map { it.copy(alpha = .22f) }))
                    .pointerInput(controller) {
                        detectTapGestures(onDoubleTap = { at ->
                            val player = controller ?: return@detectTapGestures
                            player.seekTo((player.currentPosition + if (at.x > size.width / 2) 10_000 else -10_000).coerceAtLeast(0))
                        }, onTap = { controller?.let { if (it.isPlaying) it.pause() else it.play() } })
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (!track.audio && !audioOnly) {
                    AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
                        PlayerView(ctx).apply { useController = false; player = controller }
                    }, update = { it.player = controller })
                } else {
                    artwork?.let {
                        Image(it.asImageBitmap(), contentDescription = track.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .35f)))
                    }
                    PulseBars(playing, Modifier.fillMaxWidth(.78f).height(if (track.audio) 120.dp else 70.dp))
                }
            }
        }

        Txt(track.title, style = AuroraType.heading, maxLines = 2)
        track.artist?.let { Txt(it, style = AuroraType.caption, color = c.textSecondary, maxLines = 1) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Txt(clock(elapsed), style = AuroraType.mono, color = c.textSecondary)
            Spacer(Modifier.width(8.dp))
            SeekLine(if (duration > 0) elapsed.toFloat() / duration else 0f,
                onSeek = { ratio -> controller?.seekTo((duration * ratio).toLong()) }, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Txt(clock(duration), style = AuroraType.mono, color = c.textSecondary)
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(AuroraShapes.chip).background(if (shuffle) c.accentSoft else Color.Transparent)
                .tap { shuffle = !shuffle; controller?.shuffleModeEnabled = shuffle }, contentAlignment = Alignment.Center) {
                Glyph(Ic.SHUFFLE, if (shuffle) c.accent2 else c.textSecondary)
            }
            Box(Modifier.size(46.dp).tap { controller?.let { if (it.currentPosition > 4000 || !it.hasPreviousMediaItem()) it.seekTo(0) else it.seekToPreviousMediaItem() } },
                contentAlignment = Alignment.Center) { Glyph(Ic.PREV, c.textPrimary, size = 24.dp) }
            Box(Modifier.size(66.dp).clip(AuroraShapes.chip).background(Brush.linearGradient(c.accents))
                .tap { controller?.let { if (it.isPlaying) it.pause() else { if (it.playbackState == Player.STATE_ENDED) it.seekTo(0); it.play() } } },
                contentAlignment = Alignment.Center) { Glyph(if (playing) Ic.PAUSE else Ic.PLAY, Color.White, size = 26.dp) }
            Box(Modifier.size(46.dp).tap { controller?.let { if (it.hasNextMediaItem()) it.seekToNextMediaItem() } },
                contentAlignment = Alignment.Center) { Glyph(Ic.NEXT, if (queue.size > 1) c.textPrimary else c.textTertiary, size = 24.dp) }
            Box(Modifier.size(46.dp).clip(AuroraShapes.chip).background(if (repeat != Player.REPEAT_MODE_OFF) c.accentSoft else Color.Transparent).tap {
                repeat = when (repeat) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }
                controller?.repeatMode = repeat
            }, contentAlignment = Alignment.Center) {
                Glyph(Ic.REPEAT, if (repeat != Player.REPEAT_MODE_OFF) c.accent2 else c.textSecondary)
                if (repeat == Player.REPEAT_MODE_ONE) Txt("1", style = AuroraType.caption, color = c.accent2)
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AuroraButton("السرعة ${rate}x", Modifier.weight(1f), primary = false) {
                val speeds = listOf(.5f, .75f, 1f, 1.25f, 1.5f, 2f)
                rate = speeds[(speeds.indexOf(rate) + 1) % speeds.size]
                controller?.setPlaybackSpeed(rate)
            }
            AuroraButton(if (sleepEnd > 0) "نوم ${sleepLeft / 60_000 + 1}د" else "مؤقت النوم", Modifier.weight(1f), primary = false) {
                val left = if (sleepEnd > 0) (sleepEnd - SystemClock.elapsedRealtime()) / 60_000 else -1
                setTimer(when { left < 0 -> 15; left < 15 -> 30; left < 30 -> 60; else -> 0 })
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AuroraButton("قص مرئي", Modifier.weight(1f), primary = trimOpen) { trimStart = 0f; trimEnd = 1f; trimOpen = !trimOpen }
            if (track.audio) AuroraButton("نغمة رنين", Modifier.weight(1f), primary = false) {
                if (!Settings.System.canWrite(context)) {
                    message = "اسمح بتعديل إعدادات النظام ثم اضغط مجددًا لتعيين النغمة."
                    runCatching { context.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))) }
                } else scope.launch {
                    runCatching { withContext(Dispatchers.IO) { installRingtone(context, track.uri, track.title) } }
                        .onSuccess { message = "تم تعيين الملف نغمةَ رنين للجهاز." }
                        .onFailure { message = "تعذر تعيين النغمة: ${it.message}" }
                }
            } else {
                AuroraButton(if (audioOnly) "إظهار الفيديو" else "صوت فقط", Modifier.weight(1f), primary = audioOnly) {
                    audioOnly = !audioOnly
                    controller?.let { it.trackSelectionParameters = it.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, audioOnly).build() }
                }
                AuroraButton("نافذة عائمة", Modifier.weight(1f), primary = false) {
                    if (Build.VERSION.SDK_INT >= 26) runCatching {
                        (context as? Activity)?.enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
                    }
                }
            }
        }
        if (message.isNotBlank()) Txt(message, style = AuroraType.caption, color = c.warning)

        if (trimOpen) {
            AuroraGlass(Modifier.fillMaxWidth(), radius = 18.dp) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Txt("اسحب المقبضين لتحديد بداية ونهاية المقطع", style = AuroraType.label)
                    TrimLine(trimStart, trimEnd, if (duration > 0) elapsed.toFloat() / duration else 0f,
                        onStart = { trimStart = it; controller?.seekTo((duration * it).toLong()) },
                        onEnd = { trimEnd = it; controller?.seekTo((duration * it).toLong()) })
                    Row {
                        Txt(clock((duration * trimStart).toLong()), style = AuroraType.mono, color = c.accent1)
                        Spacer(Modifier.weight(1f))
                        Txt("المدة ${clock((duration * (trimEnd - trimStart)).toLong())}", style = AuroraType.caption, color = c.textSecondary)
                        Spacer(Modifier.weight(1f))
                        Txt(clock((duration * trimEnd).toLong()), style = AuroraType.mono, color = c.accent3)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        AuroraButton("معاينة", Modifier.weight(.8f), primary = false) {
                            controller?.let { it.seekTo((duration * trimStart).toLong()); it.play() }
                        }
                        AuroraButton(if (working) "جارٍ الحفظ…" else "حفظ المقطع", Modifier.weight(1f)) {
                            if (working) return@AuroraButton
                            working = true
                            scope.launch {
                                if (saveClip() != null) { message = "حُفظ المقطع ملفًا جديدًا في المكتبة (يبدأ عند أقرب إطار مفتاحي)."; trimOpen = false }
                                working = false
                            }
                        }
                        if (track.audio) AuroraButton("قص كنغمة", Modifier.weight(1f), primary = false) {
                            if (working) return@AuroraButton
                            if (!Settings.System.canWrite(context)) {
                                message = "اسمح بتعديل إعدادات النظام ثم أعد المحاولة."
                                runCatching { context.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))) }
                                return@AuroraButton
                            }
                            working = true
                            scope.launch {
                                saveClip()?.let { clip ->
                                    runCatching { withContext(Dispatchers.IO) { installRingtone(context, Uri.fromFile(clip), track.title, "audio/mp4", "m4a") } }
                                        .onSuccess { message = "تم قص المقطع وتعيينه نغمة رنين."; trimOpen = false }
                                        .onFailure { message = "تعذر تعيين النغمة: ${it.message}" }
                                }
                                working = false
                            }
                        }
                    }
                }
            }
        }

        if (queue.size > 1) {
            Txt("قائمة التشغيل", style = AuroraType.heading)
            queue.take(200).forEachIndexed { i, item ->
                Row(
                    Modifier.fillMaxWidth().clip(AuroraShapes.icon)
                        .background(if (i == index) c.accentSoft else Color.Transparent)
                        .tap { controller?.let { it.seekTo(i, 0L); it.play() } }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Glyph(if (i == index && playing) Ic.PAUSE else if (item.audio) Ic.MUSIC else Ic.PLAY,
                        if (i == index) c.accent2 else c.textTertiary, size = 15.dp)
                    Spacer(Modifier.width(9.dp))
                    Txt(item.title, style = AuroraType.label, color = if (i == index) c.textPrimary else c.textSecondary,
                        maxLines = 1, modifier = Modifier.weight(1f))
                }
            }
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun TrimLine(start: Float, end: Float, playhead: Float, onStart: (Float) -> Unit, onEnd: (Float) -> Unit) {
    val c = LocalAuroraColors.current
    var draggingStart by remember { mutableStateOf(true) }
    val startNow by androidx.compose.runtime.rememberUpdatedState(start)
    val endNow by androidx.compose.runtime.rememberUpdatedState(end)
    Canvas(Modifier.fillMaxWidth().height(54.dp).pointerInput(Unit) {
        detectDragGestures(onDragStart = { at ->
            val x = at.x / size.width
            draggingStart = kotlin.math.abs(x - startNow) <= kotlin.math.abs(x - endNow)
        }, onDrag = { change, _ ->
            val fraction = (change.position.x / size.width).coerceIn(0f, 1f)
            if (draggingStart) onStart(fraction.coerceAtMost(endNow - .01f).coerceAtLeast(0f))
            else onEnd(fraction.coerceAtLeast(startNow + .01f).coerceAtMost(1f))
            change.consume()
        })
    }) {
        val radius = CornerRadius(10.dp.toPx())
        drawRoundRect(c.glassStrong, size = size, cornerRadius = radius)
        val bars = 48
        val slot = size.width / bars
        for (i in 0 until bars) {
            val inside = (i + .5f) / bars in start..end
            val h = size.height * (0.25f + 0.55f * kotlin.math.abs(kotlin.math.sin(i * 0.9f) * kotlin.math.cos(i * 0.37f)))
            drawRoundRect(if (inside) c.accent2 else c.textTertiary.copy(alpha = .4f),
                Offset(i * slot + slot * .25f, (size.height - h) / 2), Size(slot * .5f, h), CornerRadius(slot))
        }
        drawRect(Color.Black.copy(alpha = .45f), Offset.Zero, Size(size.width * start, size.height))
        drawRect(Color.Black.copy(alpha = .45f), Offset(size.width * end, 0f), Size(size.width * (1 - end), size.height))
        val handle = 5.dp.toPx()
        drawRoundRect(c.accent1, Offset(size.width * start - handle / 2, 0f), Size(handle, size.height), CornerRadius(handle))
        drawRoundRect(c.accent3, Offset(size.width * end - handle / 2, 0f), Size(handle, size.height), CornerRadius(handle))
        if (playhead in start..end) drawLine(Color.White, Offset(size.width * playhead, 4f), Offset(size.width * playhead, size.height - 4f), 2f)
    }
}

/** Real stream-copy trim (no re-encode). Unsupported codecs fail without touching the source. */
fun trimToMp4(context: Context, uri: Uri, fromMs: Long, toMs: Long): File {
    require(toMs - fromMs >= 500L) { "المقطع أقصر من نصف ثانية" }
    val output = File(context.getExternalFilesDir(null) ?: context.filesDir,
        "JO_DON/edited/clip_${System.currentTimeMillis()}.mp4").apply { parentFile?.mkdirs() }
    val extractor = MediaExtractor()
    var muxer: MediaMuxer? = null
    try {
        if (uri.scheme == "file") extractor.setDataSource(uri.path!!) else extractor.setDataSource(context, uri, null)
        muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val mapping = mutableMapOf<Int, Int>()
        var bufferSize = 1 shl 20
        for (index in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(index)
            val mime = format.getString(android.media.MediaFormat.KEY_MIME).orEmpty()
            if (mime.startsWith("audio/") || mime.startsWith("video/")) {
                mapping[index] = muxer.addTrack(format)
                extractor.selectTrack(index)
                if (format.containsKey(android.media.MediaFormat.KEY_MAX_INPUT_SIZE))
                    bufferSize = maxOf(bufferSize, format.getInteger(android.media.MediaFormat.KEY_MAX_INPUT_SIZE))
            }
        }
        require(mapping.isNotEmpty()) { "لا يحتوي الملف مسارات صوت أو فيديو" }
        muxer.start()
        val startUs = fromMs * 1000
        val endUs = toMs * 1000
        extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        val origin = extractor.sampleTime.coerceAtLeast(0)
        val buffer = ByteBuffer.allocateDirect(bufferSize)
        val info = MediaCodec.BufferInfo()
        var wrote = false
        while (true) {
            val trackIndex = extractor.sampleTrackIndex
            val time = extractor.sampleTime
            if (trackIndex < 0 || time < 0 || time > endUs) break
            if (trackIndex in mapping) {
                buffer.clear()
                val bytes = extractor.readSampleData(buffer, 0)
                if (bytes < 0) break
                val flags = if (extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                info.set(0, bytes, time - origin, flags)
                muxer.writeSampleData(mapping.getValue(trackIndex), buffer, info)
                wrote = true
            }
            extractor.advance()
        }
        require(wrote) { "لم يحتوِ المقطع المحدد أي بيانات" }
        muxer.stop()
        return output
    } catch (error: Exception) {
        output.delete()
        throw error
    } finally {
        extractor.release()
        runCatching { muxer?.release() }
    }
}

/** Copies the real audio into the system ringtone collection and sets it as default. */
fun installRingtone(context: Context, source: Uri, title: String, mimeHint: String? = null, extensionHint: String? = null): Uri {
    check(Settings.System.canWrite(context)) { "لم يُمنح إذن تعديل إعدادات النظام" }
    val mime = mimeHint ?: context.contentResolver.getType(source)
        ?: android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(source.lastPathSegment?.substringAfterLast('.', "")?.lowercase())
        ?: "audio/mpeg"
    val extension = extensionHint ?: android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "mp3"
    val name = title.substringBeforeLast('.').replace(Regex("[\\\\/:*?\"<>|]"), "_").take(60).ifBlank { "ringtone" }
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.$extension")
        put(MediaStore.MediaColumns.TITLE, name)
        put(MediaStore.MediaColumns.MIME_TYPE, mime)
        put(MediaStore.Audio.Media.IS_RINGTONE, true)
        put(MediaStore.Audio.Media.IS_MUSIC, false)
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_RINGTONES + "/JO_DON")
        else {
            val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_RINGTONES), "JO_DON").apply { mkdirs() }
            put(MediaStore.MediaColumns.DATA, File(dir, "$name-${System.currentTimeMillis()}.$extension").absolutePath)
        }
    }
    val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val target = context.contentResolver.insert(collection, values) ?: error("تعذر إنشاء ملف النغمة")
    try {
        val input = if (source.scheme == "file") File(source.path!!).inputStream() else context.contentResolver.openInputStream(source)
        (input ?: error("تعذر قراءة الملف الصوتي")).use { stream ->
            (context.contentResolver.openOutputStream(target) ?: error("تعذر الكتابة")).use { stream.copyTo(it) }
        }
        RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_RINGTONE, target)
        return target
    } catch (error: Exception) {
        context.contentResolver.delete(target, null, null)
        throw error
    }
}
