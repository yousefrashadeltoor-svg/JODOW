package com.auroraget.app.data

import kotlinx.serialization.Serializable
import java.util.Locale

@Serializable
enum class ContentType(val ar: String, val en: String) {
    VIDEO("فيديو", "Video"), AUDIO("صوت", "Audio"),
    IMAGE("صور", "Images"), FILE("ملفات", "Files")
}

@Serializable
enum class DownloadStatus { QUEUED, DOWNLOADING, PAUSED, COMPLETED, FAILED }

@Serializable
data class MediaFormat(
    val id: String,
    val type: ContentType,
    val quality: String,
    val container: String,
    val codec: String = "",
    val detail: String = "",
    val bytes: Long? = null,
    val approx: Boolean = false,
    val best: Boolean = false,
    val needsMerge: Boolean = false,
    val directUrl: String? = null,
) {
    val displaySize: String get() = bytes?.let { formatBytes(it, approx) } ?: "حجم غير معروف"
}

@Serializable
data class AnalyzedSource(
    val url: String,
    val site: String,
    val domain: String,
    val title: String,
    val filename: String,
    val thumbnail: String?,
    val channel: String?,
    val durationSeconds: Int?,
    val counts: Map<ContentType, Int>,
    val formats: Map<ContentType, List<MediaFormat>>,
    val exactSizeBytes: Long?,
    val approxSize: Boolean,
    val analyzedAtMillis: Long = System.currentTimeMillis(),
)

data class SizeProbe(
    val bytes: Long?, val approx: Boolean, val etag: String?,
    val lastModified: String?, val acceptsRanges: Boolean,
)

@Serializable
data class DownloadEntity(
    val id: String,
    val url: String,
    val name: String,
    val site: String,
    val type: ContentType,
    val quality: String,
    val totalBytes: Long,
    val approx: Boolean,
    val downloadedBytes: Long = 0,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val connections: Int = 1,
    val priority: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val etag: String? = null,
    val lastModified: String? = null,
    val acceptsRanges: Boolean = false,
    val headers: Map<String, String> = emptyMap(),
    val error: String? = null,
    val outputPath: String = "",
    val formatId: String? = null,
    val requiresExtractor: Boolean = false,
    val needsMerge: Boolean = false,
)

@Serializable
data class SegmentEntity(
    val downloadId: String, val segmentIndex: Int, val start: Long,
    val end: Long, val written: Long = 0, val completed: Boolean = false,
)

@Serializable
data class HistoryEntry(
    val videoId: String, val title: String, val channelId: String,
    val channelTitle: String, val thumbnail: String,
    val viewedAt: Long = System.currentTimeMillis(),
    val positionMs: Long = 0,
)

@Serializable
data class LocalProfile(
    val displayName: String = "ملفي الشخصي",
    val following: Map<String, String> = emptyMap(),
    val watchLater: Set<String> = emptySet(),
    val liked: Set<String> = emptySet(),
    val history: List<HistoryEntry> = emptyList(),
    val recentSearches: List<String> = emptyList(),
    val importedUris: List<String> = emptyList(),
    val watchLaterItems: List<HistoryEntry> = emptyList(),
    val likedItems: List<HistoryEntry> = emptyList(),
)

@Serializable
data class AppSettings(
    val themeId: String = "aurora", val light: Boolean = false,
    val arabic: Boolean = true, val connections: Int = 16,
    val wifiOnly: Boolean = false, val autoResume: Boolean = true,
    val adblock: Boolean = true, val onboardingSeen: Boolean = false,
)

@Serializable
data class LocalState(
    val version: Int = 1, val settings: AppSettings = AppSettings(),
    val profile: LocalProfile = LocalProfile(),
    val downloads: List<DownloadEntity> = emptyList(),
    val segments: List<SegmentEntity> = emptyList(),
)

fun formatBytes(bytes: Long, approx: Boolean = false): String {
    if (bytes <= 0L) return if (approx) "≈ غير معروف" else "غير معروف"
    val mib = bytes / 1_048_576.0
    val prefix = if (approx) "≈ " else ""
    return when {
        mib >= 1024 -> prefix + String.format(Locale.US, "%.2f GiB", mib / 1024)
        mib >= 1 -> prefix + String.format(Locale.US, "%.1f MiB", mib)
        else -> prefix + String.format(Locale.US, "%.0f KiB", bytes / 1024.0)
    }
}

fun exactBytes(bytes: Long): String = String.format(Locale.US, "%,d bytes", bytes)