package com.auroraget.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.offset
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.auroraget.app.ui.theme.AuroraShapes
import com.auroraget.app.ui.theme.AuroraType
import com.auroraget.app.ui.theme.LocalAuroraColors

/* ── Glass surfaces ─────────────────────────────────────────────────────── */

@Composable
fun AuroraGlass(
    modifier: Modifier = Modifier,
    radius: Dp = 26.dp,
    strong: Boolean = false,
    content: @Composable BoxScope.() -> Unit,
) {
    val c = LocalAuroraColors.current
    val shape = RoundedCornerShape(radius)
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(
                        if (strong) c.glassStrong else c.glass,
                        c.glass.copy(alpha = if (c.isLight) 0.55f else 0.03f),
                    )
                )
            )
            .border(1.dp, c.line, shape)
            .drawWithCache {
                val specular = Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.28f), Color.Transparent))
                onDrawWithContent {
                    drawContent()
                    drawLine(specular, Offset(12f, 1f), Offset(size.width - 12f, 1f), strokeWidth = 1.2f)
                }
            },
        content = content,
    )
}

@Composable
fun AuroraTag(
    text: String,
    color: Color = LocalAuroraColors.current.accent2,
    filled: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val c = LocalAuroraColors.current
    Box(
        modifier = modifier
            .clip(AuroraShapes.chip)
            .background(if (filled) color.copy(alpha = 0.16f) else Color.Transparent)
            .border(1.dp, if (filled) color.copy(alpha = 0.32f) else c.line, AuroraShapes.chip)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        BasicText(text, style = AuroraType.caption.copy(color = color, fontSize = 9.5.sp))
    }
}

@Composable
fun AuroraButton(
    text: String,
    modifier: Modifier = Modifier,
    primary: Boolean = true,
    enabled: Boolean = true,
    icon: (@Composable () -> Unit)? = null,
    onClick: () -> Unit,
) {
    val c = LocalAuroraColors.current
    val shape = AuroraShapes.button
    Row(
        modifier = modifier
            .height(44.dp)
            .clip(shape)
            .then(
                if (primary) Modifier.background(Brush.horizontalGradient(c.accents))
                else Modifier.background(c.glass).border(1.dp, c.line, shape)
            )
            .tap(enabled, onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) {
            icon()
            Spacer(Modifier.width(7.dp))
        }
        BasicText(
            text,
            style = AuroraType.label.copy(
                color = if (primary) Color.White else c.textPrimary,
                fontSize = 12.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun AuroraToggle(on: Boolean, onChange: (Boolean) -> Unit, label: String) {
    val c = LocalAuroraColors.current
    val transition = rememberInfiniteTransition(label = "toggle")
    val glow by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing)),
        label = "toggleGlow",
    )
    Box(
        Modifier
            .size(width = 44.dp, height = 26.dp)
            .clip(AuroraShapes.chip)
            .background(if (on) Brush.horizontalGradient(c.accents) else SolidColor(c.glassStrong))
            .border(1.dp, c.line, AuroraShapes.chip)
            .semantics { contentDescription = label }
            .toggleable(value = on, role = Role.Switch, onValueChange = onChange)
            .padding(3.dp),
        contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart,
    ) {
        Box(
            Modifier
                .size(20.dp)
                .clip(AuroraShapes.chip)
                .background(if (on) Color.White else c.textTertiary.copy(alpha = glow))
        )
    }
}

@Composable
fun AuroraProgress(value: Float, modifier: Modifier = Modifier, color: Color? = null) {
    val c = LocalAuroraColors.current
    val transition = rememberInfiniteTransition(label = "progress")
    val shift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "progressShift",
    )
    Canvas(modifier = modifier.fillMaxWidth().height(5.dp)) {
        drawRoundRect(color = c.line, cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2))
        val w = size.width * value.coerceIn(0f, 1f)
        if (w > 0f) {
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = color?.let { listOf(it, it) } ?: c.accents,
                    startX = shift * size.width - size.width,
                    endX = shift * size.width + size.width,
                ),
                size = Size(w, size.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2),
            )
        }
    }
}

@Composable
fun AuroraRing(progress: Float, size: Dp = 44.dp, label: String? = null) {
    val c = LocalAuroraColors.current
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 4.dp.toPx()
            drawArc(
                color = c.line,
                startAngle = -90f, sweepAngle = 360f, useCenter = false,
                topLeft = Offset(stroke / 2, stroke / 2),
                size = Size(this.size.width - stroke, this.size.height - stroke),
                style = Stroke(stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round),
            )
            drawArc(
                brush = Brush.sweepGradient(c.accents),
                startAngle = -90f, sweepAngle = 360f * progress.coerceIn(0f, 1f), useCenter = false,
                topLeft = Offset(stroke / 2, stroke / 2),
                size = Size(this.size.width - stroke, this.size.height - stroke),
                style = Stroke(stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round),
            )
        }
        BasicText(label ?: "${(progress * 100).toInt()}%", style = AuroraType.caption.copy(color = c.textPrimary, fontSize = 9.sp))
    }
}

@Composable
fun GradientTitle(text: String, modifier: Modifier = Modifier, style: TextStyle = AuroraType.display) {
    val c = LocalAuroraColors.current
    val brush = Brush.horizontalGradient(c.accents)
    androidx.compose.foundation.text.BasicText(
        text = text,
        modifier = modifier,
        style = style.copy(brush = brush),
        maxLines = 2,
    )
}

/* ── Gemini-style glow paste field ──────────────────────────────────────── */

@Composable
fun GlowPasteField(
    url: String,
    analyzing: Boolean,
    onUrlChange: (String) -> Unit,
    onAnalyze: () -> Unit,
    onPaste: () -> Unit,
    onBrowser: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = LocalAuroraColors.current
    val rotate = rememberInfiniteTransition(label = "glow")
    val angle by rotate.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (analyzing) c.themeId.motionDuration / 3 else c.themeId.motionDuration, easing = LinearEasing)),
        label = "glowAngle",
    )
    val shape = RoundedCornerShape(28.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .drawBehind {
                drawRoundRect(brush = Brush.sweepGradient(listOf(Color.Transparent, c.accent1, c.accent2, c.accent3, Color.Transparent)))
            }
            .drawBehind {
                rotate(angle) {
                    drawRoundRect(
                        brush = Brush.sweepGradient(c.accents + c.accent1),
                        style = Stroke(width = 2.2f)
                    )
                }
            }
            .padding(2.dp)
            .clip(shape)
            .background(if (c.isLight) c.glassStrong else Color(0xF20D1220))
            .border(1.dp, c.line, shape)
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                BasicText("رابط جديد", style = AuroraType.caption.copy(color = c.textSecondary))
                Spacer(Modifier.weight(1f))
                AuroraTag("خصوصية كاملة · محلي", color = c.success, filled = true)
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(AuroraShapes.field)
                    .background(c.field)
                    .border(1.dp, c.line, AuroraShapes.field)
                    .padding(horizontal = 10.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val focus = LocalFocusManager.current
                BasicTextField(
                    value = url,
                    onValueChange = onUrlChange,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = AuroraType.label.copy(color = c.textPrimary, fontSize = 11.sp),
                    cursorBrush = SolidColor(c.accent2),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { focus.clearFocus(); onAnalyze() }),
                    decorationBox = { inner ->
                        Box {
                            if (url.isEmpty()) {
                                BasicText("الصق رابط الفيديو أو الملف هنا…", style = AuroraType.caption.copy(color = c.textTertiary))
                            }
                            inner()
                        }
                    },
                )
                AuroraTag("URL", color = c.textSecondary)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    AuroraButton(
                        text = if (analyzing) "جاري التحليل…" else "تحليل الرابط",
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onAnalyze,
                    )
                }
                AuroraIconButton("لصق", onPaste)
                AuroraIconButton("متصفح", onBrowser)
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                BasicText(
                    if (analyzing) "تهيئة المحرك ثم قراءة الترويسات…" else "يدعم YouTube وTikTok و1800+ موقع",
                    style = AuroraType.caption.copy(color = c.textTertiary, fontSize = 8.5.sp),
                )
                Spacer(Modifier.weight(1f))
                AuroraTag(if (analyzing) "IO · Parallel" else "Ready", color = if (analyzing) c.accent2 else c.success)
            }
        }
    }
}

/** Small glass icon button; icons are drawn, so no icon font or Material dependency. */
@Composable
fun AuroraIconButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = LocalAuroraColors.current
    val icon = when (label) {
        "لصق" -> Ic.COPY; "متصفح" -> Ic.GLOBE; "إغلاق", "×" -> Ic.CLOSE; "+" -> Ic.PLUS
        "↻" -> Ic.REPEAT; "رجوع" -> Ic.BACK; "تقدم" -> Ic.FORWARD; else -> null
    }
    Box(
        modifier = modifier.size(42.dp).clip(AuroraShapes.icon).background(c.glassStrong)
            .border(1.dp, c.line, AuroraShapes.icon).semantics { contentDescription = label }.tap(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (icon != null) Glyph(icon, c.textSecondary, size = 18.dp)
        else BasicText(label.take(2), style = AuroraType.label.copy(color = c.textSecondary, fontSize = 13.sp))
    }
}

/* ── Sheet & dock ───────────────────────────────────────────────────────── */

@Composable
fun AuroraSheet(
    title: String,
    subtitle: String? = null,
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    val c = LocalAuroraColors.current
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.6f))
                .tap(onClick = onDismiss)
        )
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .clip(AuroraShapes.sheet)
                .background(if (c.isLight) c.glassStrong else Color(0xFF0A0E18))
                .border(1.dp, c.line, AuroraShapes.sheet)
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(horizontal = 18.dp, vertical = 12.dp),
        ) {
            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .size(width = 40.dp, height = 4.dp)
                    .clip(AuroraShapes.chip)
                    .background(c.lineStrong)
            )
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    BasicText(title, style = AuroraType.heading.copy(color = c.textPrimary))
                    if (subtitle != null) {
                        BasicText(subtitle, style = AuroraType.caption.copy(color = c.textSecondary), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                AuroraIconButton("إغلاق", onDismiss)
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun AuroraDock(
    items: List<Pair<String, Ic>>,
    selected: Int,
    onSelect: (Int) -> Unit,
    badge: Int = 0,
) {
    val c = LocalAuroraColors.current
    Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().clip(AuroraShapes.dock)
                .background(if (c.isLight) c.glassStrong else Color(0xEE0A0E18))
                .border(1.dp, c.line, AuroraShapes.dock).padding(horizontal = 6.dp, vertical = 7.dp),
        ) {
            items.forEachIndexed { i, item ->
                val active = selected == i
                val glow by animateFloatAsState(if (active) 1f else 0f, spring(dampingRatio = .7f, stiffness = 380f), label = "dock")
                Column(
                    modifier = Modifier.weight(1f).clip(AuroraShapes.icon)
                        .background(c.accent2.copy(alpha = (if (c.isLight) .16f else .22f) * glow))
                        .semantics { contentDescription = item.first }.tap { onSelect(i) }.padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    Box {
                        if (item.second == Ic.YOUTUBE) Glyph(Ic.YOUTUBE, Color(0xFFFF0033), size = 20.dp)
                        else Glyph(item.second, if (active) c.accent2 else c.textTertiary, size = 19.dp)
                        if (i == 1 && badge > 0) Box(
                            Modifier.align(Alignment.TopEnd).offset(x = 9.dp, y = (-5).dp).clip(AuroraShapes.chip)
                                .background(c.accent3).padding(horizontal = 4.dp)
                        ) { BasicText("$badge", style = AuroraType.caption.copy(color = Color.White, fontSize = 8.sp)) }
                    }
                    BasicText(item.first, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = AuroraType.caption.copy(color = if (active) c.textPrimary else c.textTertiary, fontSize = 8.5.sp))
                }
            }
        }
    }
}

@Composable
fun StatTile(label: String, value: String, hint: String? = null,
             accent: Color = LocalAuroraColors.current.accent2, modifier: Modifier = Modifier) {
    val c = LocalAuroraColors.current
    AuroraGlass(modifier, radius = 16.dp) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            BasicText(label, style = AuroraType.caption.copy(color = c.textTertiary, fontSize = 8.5.sp))
            BasicText(value, style = AuroraType.heading.copy(color = c.textPrimary, fontSize = 17.sp))
            if (hint != null) BasicText(hint, style = AuroraType.caption.copy(color = accent, fontSize = 8.sp))
        }
    }
}

@Composable
fun ScreenHeader(eyebrow: String, title: String, accent: Color = LocalAuroraColors.current.accent2) {
    val c = LocalAuroraColors.current
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        BasicText(eyebrow, style = AuroraType.caption.copy(color = accent, fontSize = 9.5.sp))
        BasicText(title, style = AuroraType.title.copy(color = c.textPrimary))
    }
}

/* ── Interaction + drawn icon set ───────────────────────────────────────── */

/** Spring press-scale click without any Material ripple. Always invokes the latest lambda. */
fun Modifier.tap(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.955f else 1f, spring(dampingRatio = 0.55f, stiffness = 650f), label = "press")
    this.graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(interactionSource = source, indication = null, enabled = enabled, role = Role.Button, onClick = onClick)
}

enum class Ic {
    HOME, DOWNLOAD, PLAY, PAUSE, GLOBE, FOLDER, GEAR, SEARCH, CLOSE, BACK, FORWARD, DOWN, HEART, COPY, SHARE,
    FULLSCREEN, NEXT, PREV, CLOCK, REPEAT, SHUFFLE, MUSIC, USER, BOLT, STACK, PLUS, CHECK, PIP, MORE, BOOKMARK, YOUTUBE
}

@Composable
fun Glyph(icon: Ic, tint: Color, modifier: Modifier = Modifier, size: Dp = 20.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val flip = layoutDirection == LayoutDirection.Rtl && (icon == Ic.BACK || icon == Ic.FORWARD)
        val stroke = Stroke(w * .09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun x(v: Float) = (if (flip) 1f - v else v) * w
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
            drawLine(tint, Offset(x(x1), y1 * w), Offset(x(x2), y2 * w), w * .09f, StrokeCap.Round)
        fun poly(vararg p: Float, close: Boolean = false, fill: Boolean = false) {
            val path = Path()
            path.moveTo(x(p[0]), p[1] * w)
            var i = 2
            while (i < p.size) { path.lineTo(x(p[i]), p[i + 1] * w); i += 2 }
            if (close) path.close()
            drawPath(path, tint, style = if (fill) Fill else stroke)
        }
        fun box(l: Float, t: Float, bw: Float, bh: Float, r: Float, filled: Boolean = false) =
            drawRoundRect(tint, Offset(w * l, w * t), Size(w * bw, w * bh), CornerRadius(w * r), style = if (filled) Fill else stroke)
        when (icon) {
            Ic.HOME -> { poly(.12f, .5f, .5f, .14f, .88f, .5f); poly(.24f, .42f, .24f, .86f, .76f, .86f, .76f, .42f) }
            Ic.DOWNLOAD -> { line(.5f, .12f, .5f, .62f); poly(.28f, .42f, .5f, .64f, .72f, .42f); line(.18f, .86f, .82f, .86f) }
            Ic.PLAY -> poly(.26f, .14f, .86f, .5f, .26f, .86f, close = true, fill = true)
            Ic.PAUSE -> { box(.22f, .16f, .2f, .68f, .05f, true); box(.58f, .16f, .2f, .68f, .05f, true) }
            Ic.GLOBE -> { drawCircle(tint, w * .38f, style = stroke); drawOval(tint, Offset(w * .33f, w * .12f), Size(w * .34f, w * .76f), style = stroke); line(.12f, .5f, .88f, .5f) }
            Ic.FOLDER -> poly(.1f, .8f, .1f, .22f, .4f, .22f, .5f, .34f, .9f, .34f, .9f, .8f, close = true)
            Ic.GEAR -> {
                drawCircle(tint, w * .12f, style = stroke); drawCircle(tint, w * .29f, style = stroke)
                for (k in 0 until 8) {
                    val a = k * Math.PI / 4; val cs = kotlin.math.cos(a).toFloat(); val sn = kotlin.math.sin(a).toFloat()
                    drawLine(tint, Offset(w * (.5f + cs * .32f), w * (.5f + sn * .32f)), Offset(w * (.5f + cs * .42f), w * (.5f + sn * .42f)), w * .11f, StrokeCap.Round)
                }
            }
            Ic.SEARCH -> { drawCircle(tint, w * .27f, Offset(w * .43f, w * .43f), style = stroke); drawLine(tint, Offset(w * .63f, w * .63f), Offset(w * .86f, w * .86f), w * .09f, StrokeCap.Round) }
            Ic.CLOSE -> { line(.22f, .22f, .78f, .78f); line(.78f, .22f, .22f, .78f) }
            Ic.BACK -> poly(.62f, .18f, .3f, .5f, .62f, .82f)
            Ic.FORWARD -> poly(.38f, .18f, .7f, .5f, .38f, .82f)
            Ic.DOWN -> poly(.2f, .36f, .5f, .66f, .8f, .36f)
            Ic.HEART -> {
                val path = Path()
                path.moveTo(w * .5f, w * .84f)
                path.cubicTo(w * .08f, w * .56f, w * .1f, w * .18f, w * .34f, w * .18f)
                path.cubicTo(w * .43f, w * .18f, w * .5f, w * .25f, w * .5f, w * .31f)
                path.cubicTo(w * .5f, w * .25f, w * .57f, w * .18f, w * .66f, w * .18f)
                path.cubicTo(w * .9f, w * .18f, w * .92f, w * .56f, w * .5f, w * .84f)
                path.close()
                drawPath(path, tint, style = stroke)
            }
            Ic.COPY -> { box(.3f, .28f, .56f, .6f, .08f); poly(.7f, .14f, .16f, .14f, .16f, .72f) }
            Ic.SHARE -> { line(.5f, .62f, .5f, .14f); poly(.3f, .32f, .5f, .12f, .7f, .32f); poly(.2f, .52f, .2f, .86f, .8f, .86f, .8f, .52f) }
            Ic.FULLSCREEN -> { poly(.14f, .38f, .14f, .14f, .38f, .14f); poly(.62f, .14f, .86f, .14f, .86f, .38f); poly(.86f, .62f, .86f, .86f, .62f, .86f); poly(.38f, .86f, .14f, .86f, .14f, .62f) }
            Ic.NEXT -> { poly(.18f, .18f, .64f, .5f, .18f, .82f, close = true, fill = true); line(.8f, .18f, .8f, .82f) }
            Ic.PREV -> { poly(.82f, .18f, .36f, .5f, .82f, .82f, close = true, fill = true); line(.2f, .18f, .2f, .82f) }
            Ic.CLOCK -> { drawCircle(tint, w * .38f, style = stroke); poly(.5f, .28f, .5f, .52f, .66f, .62f) }
            Ic.REPEAT -> { poly(.2f, .46f, .2f, .3f, .78f, .3f); poly(.66f, .16f, .8f, .3f, .66f, .44f); poly(.8f, .54f, .8f, .7f, .22f, .7f); poly(.34f, .56f, .2f, .7f, .34f, .84f) }
            Ic.SHUFFLE -> { poly(.12f, .3f, .3f, .3f, .7f, .72f, .88f, .72f); poly(.12f, .72f, .3f, .72f, .42f, .58f); poly(.58f, .42f, .7f, .3f, .88f, .3f); poly(.78f, .2f, .88f, .3f, .78f, .4f); poly(.78f, .62f, .88f, .72f, .78f, .82f) }
            Ic.MUSIC -> { line(.4f, .2f, .4f, .72f); line(.4f, .2f, .8f, .12f); line(.8f, .12f, .8f, .62f); drawCircle(tint, w * .11f, Offset(w * .29f, w * .74f)); drawCircle(tint, w * .11f, Offset(w * .69f, w * .64f)) }
            Ic.USER -> { drawCircle(tint, w * .17f, Offset(w * .5f, w * .32f), style = stroke); drawArc(tint, 180f, 180f, false, Offset(w * .18f, w * .58f), Size(w * .64f, w * .6f), style = stroke) }
            Ic.BOLT -> poly(.58f, .08f, .22f, .56f, .48f, .56f, .42f, .92f, .78f, .44f, .52f, .44f, close = true)
            Ic.STACK -> { box(.12f, .4f, .76f, .46f, .08f); line(.24f, .26f, .76f, .26f); line(.34f, .13f, .66f, .13f) }
            Ic.PLUS -> { line(.5f, .18f, .5f, .82f); line(.18f, .5f, .82f, .5f) }
            Ic.CHECK -> poly(.18f, .52f, .42f, .76f, .84f, .26f)
            Ic.PIP -> { box(.1f, .18f, .8f, .64f, .08f); box(.48f, .48f, .32f, .24f, .04f, true) }
            Ic.MORE -> for (k in 0..2) drawCircle(tint, w * .07f, Offset(w * .5f, w * (.22f + k * .28f)))
            Ic.BOOKMARK -> poly(.26f, .12f, .74f, .12f, .74f, .88f, .5f, .68f, .26f, .88f, close = true)
            Ic.YOUTUBE -> {
                drawRoundRect(tint, Offset(0f, w * .15f), Size(w, w * .7f), CornerRadius(w * .2f))
                val play = Path(); play.moveTo(w * .4f, w * .34f); play.lineTo(w * .68f, w * .5f); play.lineTo(w * .4f, w * .66f); play.close()
                drawPath(play, Color.White)
            }
        }
    }
}
