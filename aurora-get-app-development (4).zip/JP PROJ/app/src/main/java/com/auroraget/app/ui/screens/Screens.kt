package com.auroraget.app.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.auroraget.app.data.AnalyzedSource
import com.auroraget.app.data.ContentType
import com.auroraget.app.data.DownloadEntity
import com.auroraget.app.data.DownloadRequest
import com.auroraget.app.data.DownloadProgress
import com.auroraget.app.data.DownloadStatus
import com.auroraget.app.data.MediaFormat
import com.auroraget.app.data.formatBytes
import com.auroraget.app.data.exactBytes
import coil3.compose.AsyncImage
import com.auroraget.app.engine.MediaEngine
import com.auroraget.app.ui.components.AuroraButton
import com.auroraget.app.ui.components.tap
import com.auroraget.app.ui.components.Glyph
import com.auroraget.app.ui.components.Ic
import com.auroraget.app.ui.components.AuroraGlass
import com.auroraget.app.ui.components.AuroraIconButton
import com.auroraget.app.ui.components.AuroraProgress
import com.auroraget.app.ui.components.AuroraRing
import com.auroraget.app.ui.components.AuroraTag
import com.auroraget.app.ui.components.AuroraToggle
import com.auroraget.app.ui.components.GlowPasteField
import com.auroraget.app.ui.components.GradientTitle
import com.auroraget.app.ui.components.ScreenHeader
import com.auroraget.app.ui.components.StatTile
import com.auroraget.app.ui.theme.AuroraShapes
import com.auroraget.app.ui.theme.AuroraThemeId
import com.auroraget.app.ui.theme.AuroraType
import com.auroraget.app.ui.theme.LocalAuroraColors
import kotlinx.coroutines.launch

/* Shared text primitive: foundation-only, Arabic-first. */
@Composable
fun Txt(
    text: String,
    style: androidx.compose.ui.text.TextStyle = AuroraType.body,
    color: Color = LocalAuroraColors.current.textPrimary,
    maxLines: Int = Int.MAX_VALUE,
    modifier: Modifier = Modifier,
) {
    BasicText(
        text = text,
        modifier = modifier,
        style = style.copy(color = color),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}

@Composable
fun ScreenShell(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) { content() }
    }
}

/* ── Home ───────────────────────────────────────────────────────────────── */

@Composable
fun HomeScreen(
    langArabic: Boolean,
    url: String,
    analyzing: Boolean,
    stage: Int,
    statusText: String,
    source: AnalyzedSource?,
    downloads: List<DownloadEntity>,
    onUrlChange: (String) -> Unit,
    onAnalyze: () -> Unit,
    onPaste: () -> Unit,
    onBrowser: () -> Unit,
    onType: (ContentType) -> Unit,
    onOpenDownloads: () -> Unit,
    onTools: () -> Unit,
    onYouTube: () -> Unit,
) {
    val c = LocalAuroraColors.current
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
        item {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    GradientTitle("𝒥𝒪 DON", style = AuroraType.display)
                    Txt(
                        if (langArabic) "حمّل ما تحبه، بطريقتك." else "Save what you love, your way.",
                        style = AuroraType.caption,
                        color = c.textSecondary,
                    )
                }
                AuroraTag("Aurora Glass", color = c.accent2, filled = true)
            }
        }
        item {
            GlowPasteField(
                url = url,
                analyzing = analyzing,
                onUrlChange = onUrlChange,
                onAnalyze = onAnalyze,
                onPaste = onPaste,
                onBrowser = onBrowser,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                AuroraButton("YouTube", Modifier.weight(1f), primary = false) { onYouTube() }
                AuroraButton(if (langArabic) "المتصفح" else "Browser", Modifier.weight(1f), primary = false) { onBrowser() }
                AuroraButton(if (langArabic) "الأدوات" else "Tools", Modifier.weight(1f), primary = false) { onTools() }
            }
        }
        if (analyzing) {
            item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AuroraRing((stage + 1) / 4f, 32.dp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Txt(if (langArabic) "جاري التحليل بالتوازي…" else "Analyzing in parallel…", style = AuroraType.label, color = c.textPrimary)
                                Txt("Stage $stage/3 · IO", style = AuroraType.caption, color = c.textTertiary)
                            }
                        }
                        AuroraProgress((stage + 1) / 4f)
                        Txt("HEAD → Range → Native → yt-dlp → Jsoup/WebView", style = AuroraType.caption, color = c.textTertiary)
                    }
                }
            }
        }
        when {
            source != null -> item { SourceCard(source, langArabic, onType) }
            !analyzing -> item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(32.dp))
                                .background(Brush.linearGradient(c.accents))
                        )
                        Spacer(Modifier.height(10.dp))
                        Txt(
                            if (langArabic) "ألصق رابطًا أو استخدم المتصفح الداخلي" else "Paste a link or use the in-app browser",
                            style = AuroraType.label,
                            color = c.textPrimary,
                        )
                        Spacer(Modifier.height(4.dp))
                        Txt(
                            if (langArabic) "ندعم أكثر من 1800 موقع، مع حجم حقيقي مؤكد أو تقريبي بوضوح." else "1800+ sites with clearly marked exact or approximate sizes.",
                            style = AuroraType.caption,
                            color = c.textSecondary,
                        )
                    }
                }
            }
        }
        if (statusText.isNotBlank()) {
            item { Txt(statusText, style = AuroraType.caption, color = c.accent2) }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Txt(if (langArabic) "آخر التحميلات" else "Recent downloads", style = AuroraType.heading)
                Spacer(Modifier.weight(1f))
                Box(Modifier.tap { onOpenDownloads() }) {
                    Txt(if (langArabic) "الكل" else "All", style = AuroraType.label, color = c.accent2)
                }
            }
        }
        items(downloads.take(3)) { item ->
            AuroraGlass(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Txt(item.name, style = AuroraType.label, modifier = Modifier.weight(1f), maxLines = 1)
                        AuroraTag(item.quality, color = c.accent2)
                    }
                    AuroraProgress(if (item.totalBytes > 0) item.downloadedBytes.toFloat() / item.totalBytes else 0f)
                    Row {
                        Txt("${formatBytes(item.downloadedBytes)} / ${formatBytes(item.totalBytes)}", style = AuroraType.mono, color = c.textTertiary)
                        Spacer(Modifier.weight(1f))
                        Txt(item.status.name.lowercase(), style = AuroraType.caption, color = c.textSecondary)
                    }
                }
            }
        }
        item {
            Txt(
                "المسؤولية على المستخدم في احترام حقوق النشر · لا DRM ولا Paywalls.",
                style = AuroraType.caption,
                color = c.textTertiary,
            )
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SourceCard(source: AnalyzedSource, langArabic: Boolean, onType: (ContentType) -> Unit) {
    val c = LocalAuroraColors.current
    var revealBytes by remember(source.url) { mutableStateOf(false) }
    AuroraGlass(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AuroraTag(source.site, color = c.accent2, filled = true)
                Spacer(Modifier.width(6.dp))
                Txt(source.domain, style = AuroraType.caption, color = c.textTertiary, maxLines = 1, modifier = Modifier.weight(1f))
                AuroraTag(if (source.exactSizeBytes != null && !source.approxSize) "حجم مؤكد" else "تم التحليل",
                    color = if (source.approxSize) c.warning else c.success)
            }
            source.thumbnail?.takeIf { it.startsWith("https://") }?.let { picture ->
                AsyncImage(model = picture, contentDescription = source.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(137.dp).clip(AuroraShapes.tile))
            }
            Txt(source.title, style = AuroraType.heading, maxLines = 2)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(source.filename, style = AuroraType.caption, color = c.textSecondary, maxLines = 1, modifier = Modifier.weight(1f))
                val size = source.exactSizeBytes
                AuroraTag(
                    if (size != null) if (revealBytes) exactBytes(size) else formatBytes(size, source.approxSize) else "الحجم غير معروف",
                    color = if (source.approxSize) c.warning else c.success,
                    filled = true,
                    modifier = Modifier.pointerInput(size) { detectTapGestures(onLongPress = { revealBytes = !revealBytes }) },
                )
            }
            Txt(
                if (source.exactSizeBytes == null) "لم يُعلن المصدر حجمًا مؤكدًا لهذا الملف"
                else if (!source.approxSize) "حجم مؤكد — اضغط طويلًا لعرض البايت الدقيق" else "≈ حجم تقريبي (filesize_approx) وليس مؤكدًا",
                style = AuroraType.caption,
                color = if (source.approxSize) c.warning else c.success,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                ContentType.values().forEach { type ->
                    val count = source.counts[type] ?: 0
                    if (count > 0) {
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(AuroraShapes.tile)
                                .background(c.accentSoft)
                                .border(1.dp, c.line, AuroraShapes.tile)
                                .tap { onType(type) }
                                .padding(vertical = 9.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Txt(if (langArabic) type.ar else type.en, style = AuroraType.label, maxLines = 1)
                            Txt("$count", style = AuroraType.caption, color = c.textSecondary)
                        }
                    }
                }
            }
        }
    }
}

/* ── Downloads ──────────────────────────────────────────────────────────── */

@Composable
fun DownloadsScreen(
    downloads: List<DownloadEntity>,
    speeds: Map<String, DownloadProgress>,
    langArabic: Boolean,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onRemove: (String) -> Unit,
    onAdd: () -> Unit,
) {
    val c = LocalAuroraColors.current
    var filter by remember { mutableStateOf<DownloadStatus?>(null) }
    val visible = downloads.filter { filter == null || it.status == filter }
    val active = downloads.filter { it.status == DownloadStatus.DOWNLOADING }
    val speed = speeds.values.sumOf { it.bytesPerSecond } / 1_048_576.0
    ScreenShell {
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScreenHeader("محرك مجزأ · ${active.sumOf { it.connections }} اتصالًا", "مدير التحميلات")
            Spacer(Modifier.weight(1f))
            AuroraIconButton("+", onAdd)
        }
        Spacer(Modifier.height(10.dp))
        AuroraGlass(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt("السرعة الإجمالية الآن", style = AuroraType.caption, color = c.textTertiary)
                    Txt("%.1f MB/s".format(speed), style = AuroraType.title)
                    Txt("HTTP/2 · ${active.size} نشط", style = AuroraType.caption, color = c.success)
                }
                StatTile("نشط", "${active.size}", "من ${downloads.size}")
            }
        }
        Spacer(Modifier.height(9.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AuroraButton("إيقاف الكل", Modifier.weight(1f), primary = false, onClick = { active.forEach { onPause(it.id) } })
            AuroraButton("استئناف", Modifier.weight(1f), primary = false, onClick = { downloads.filter { it.status == DownloadStatus.PAUSED }.forEach { onResume(it.id) } })
            AuroraButton("رابط +", Modifier.weight(0.7f), onClick = onAdd)
        }
        Spacer(Modifier.height(9.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
            listOf<Pair<String, DownloadStatus?>>(
                "الكل" to null,
                "جارٍ" to DownloadStatus.DOWNLOADING,
                "متوقف" to DownloadStatus.PAUSED,
                "فاشل" to DownloadStatus.FAILED,
                "مكتمل" to DownloadStatus.COMPLETED,
            ).forEach { (label, status) ->
                val selected = filter == status
                Box(
                    Modifier
                        .weight(1f)
                        .clip(AuroraShapes.chip)
                        .background(if (selected) c.accentSoft else c.glass)
                        .border(1.dp, if (selected) c.lineStrong else c.line, AuroraShapes.chip)
                        .tap { filter = status }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Txt(label, style = AuroraType.caption, color = if (selected) c.textPrimary else c.textSecondary, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(visible, key = { it.id }) { item ->
                DownloadRow(item, speeds[item.id], onPause, onResume, onRemove)
            }
            if (visible.isEmpty()) {
                item {
                    AuroraGlass(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Txt("لا توجد عناصر في هذا التصفية", style = AuroraType.label, color = c.textSecondary)
                            Spacer(Modifier.height(4.dp))
                            Txt("الإيقاف والاستئناف محفوظان محليًا بملف JSON مع ETag.", style = AuroraType.caption, color = c.textTertiary)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

@Composable
private fun DownloadRow(
    item: DownloadEntity,
    live: DownloadProgress?,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onRemove: (String) -> Unit,
) {
    val c = LocalAuroraColors.current
    val progress = if (item.totalBytes > 0) item.downloadedBytes.toFloat() / item.totalBytes else 0f
    AuroraGlass(Modifier.fillMaxWidth(), radius = 20.dp) {
        Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt(item.name, style = AuroraType.label, maxLines = 1)
                    Txt("${item.site} · ${item.quality}", style = AuroraType.caption, color = c.textTertiary, maxLines = 1)
                }
                AuroraRing(progress, 34.dp)
            }
            AuroraProgress(progress)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(
                    formatBytes(item.totalBytes, item.approx),
                    style = AuroraType.mono,
                    color = if (item.approx) c.warning else c.success,
                )
                Spacer(Modifier.width(6.dp))
                Txt(if (live != null) "${live.activeConnections} اتصالًا · ${formatBytes(live.bytesPerSecond)}/s" else "—",
                    style = AuroraType.caption, color = c.textTertiary)
                Spacer(Modifier.weight(1f))
                when (item.status) {
                    DownloadStatus.DOWNLOADING -> AuroraButton("إيقاف", primary = false, onClick = { onPause(item.id) })
                    DownloadStatus.PAUSED, DownloadStatus.FAILED -> AuroraButton("استئناف", primary = false, onClick = { onResume(item.id) })
                    DownloadStatus.COMPLETED -> AuroraTag("مكتمل", color = c.success, filled = true)
                    DownloadStatus.QUEUED -> AuroraTag("بالانتظار", color = c.textSecondary)
                }
                Spacer(Modifier.width(5.dp))
                AuroraIconButton("×", onClick = { onRemove(item.id) }, modifier = Modifier.size(34.dp))
            }
        }
    }
}

/* ── Tools (converter + compressor) ─────────────────────────────────────── */

@Composable
fun ToolsScreen(onPlay: (android.net.Uri, String, Boolean) -> Unit, isArabic: Boolean = true) {
    val c = LocalAuroraColors.current
    var mode by remember { mutableStateOf(0) }
    var lossless by remember { mutableStateOf(true) }
    var result by remember { mutableStateOf("") }
    val context = LocalContext.current
    val store = remember { org.koin.core.context.GlobalContext.get().get<com.auroraget.app.data.LocalStore>() }
    val scope = rememberCoroutineScope()
    var selectedImage by remember { mutableStateOf<android.net.Uri?>(null) }
    var output by remember { mutableStateOf<java.io.File?>(null) }
    var beforeSize by remember { mutableStateOf(0L) }
    var working by remember { mutableStateOf(false) }
    var comparison by remember { mutableStateOf(.5f) }
    var pendingLossless by remember { mutableStateOf(true) }
    val imagePicker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri: android.net.Uri? ->
        if (uri != null) { selectedImage = uri; output = null; result = "" }
    }
    val mediaPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri: android.net.Uri? ->
        if (uri != null) {
            val type = context.contentResolver.getType(uri).orEmpty()
            onPlay(uri, uri.lastPathSegment?.substringAfterLast('/') ?: "ملف محلي", type.startsWith("audio/"))
        }
    }
    val before by produceState<android.graphics.Bitmap?>(null, selectedImage) {
        value = withContext(Dispatchers.IO) {
            selectedImage?.let { uri -> runCatching {
                context.contentResolver.openInputStream(uri)?.use(android.graphics.BitmapFactory::decodeStream)
            }.getOrNull() }
        }
    }
    val after by produceState<android.graphics.Bitmap?>(null, output) {
        value = withContext(Dispatchers.IO) { output?.let { android.graphics.BitmapFactory.decodeFile(it.absolutePath) } }
    }

    ScreenShell {
        Spacer(Modifier.height(8.dp))
        ScreenHeader("استوديو محلي بالكامل · دون خادم", "ملفاتك، بطريقتك.")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AuroraButton("ضغط الصور", Modifier.weight(1f), primary = mode == 0) { mode = 0 }
            AuroraButton("قص مرئي", Modifier.weight(1f), primary = mode == 1) { mode = 1 }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.weight(1f)) {
            item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Txt(if (mode == 0) "ضغط حقيقي للصورة المختارة" else "قص ملفات محلية حقيقي", style = AuroraType.heading)
                        if (mode == 0) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                AuroraButton("Lossless WebP", Modifier.weight(1f), primary = lossless) { lossless = true }
                                AuroraButton("شفاف بصريًا", Modifier.weight(1f), primary = !lossless) { lossless = false }
                            }
                            Txt("حفظ نسخة جديدة فقط؛ إذا لم ينقص الحجم، لن يُعرض ناتج أكبر.",
                                style = AuroraType.caption, color = c.textSecondary)
                            AuroraButton("اختر صورة من جهازك", Modifier.fillMaxWidth(), primary = false) {
                                imagePicker.launch(arrayOf("image/*"))
                            }
                            if (selectedImage != null) {
                                Txt("الصورة المختارة: ${selectedImage?.lastPathSegment.orEmpty().takeLast(65)}",
                                    style = AuroraType.caption, color = c.textSecondary, maxLines = 1)
                                if (before != null) {
                                    Box(Modifier.fillMaxWidth().height(165.dp).clip(AuroraShapes.tile)) {
                                        Canvas(Modifier.fillMaxSize().pointerInput(output) {
                                            detectDragGestures(onDrag = { change, _ ->
                                                comparison = (change.position.x / size.width).coerceIn(0f, 1f)
                                            })
                                        }) {
                                            val dimension = IntSize(size.width.toInt(), size.height.toInt())
                                            drawImage(before!!.asImageBitmap(), dstSize = dimension)
                                            if (after != null) clipRect(right = size.width * comparison) {
                                                drawImage(after!!.asImageBitmap(), dstSize = dimension)
                                            }
                                            if (after != null) drawLine(Color.White,
                                                Offset(size.width * comparison, 0f),
                                                Offset(size.width * comparison, size.height), 3f)
                                        }
                                    }
                                    if (output != null && beforeSize > 0) {
                                        Txt("قبل: ${com.auroraget.app.data.exactBytes(beforeSize)}   ←   بعد: ${com.auroraget.app.data.exactBytes(output!!.length())}",
                                            style = AuroraType.caption, color = c.success)
                                    }
                                }
                                AuroraButton(if (working) "يتم الضغط الآن" else "اضغط واحفظ نسخة جديدة",
                                    Modifier.fillMaxWidth()) {
                                    if (working) return@AuroraButton
                                    working = true
                                    val input = selectedImage ?: return@AuroraButton
                                    scope.launch {
                                        val compressed = withContext(Dispatchers.IO) { compressPickedImage(context, input, lossless) }
                                        output = compressed?.first
                                        beforeSize = compressed?.second ?: 0L
                                        if (compressed != null) {
                                            val file = compressed.first
                                            store.update { state -> state.copy(downloads = listOf(DownloadEntity(
                                                id = java.util.UUID.randomUUID().toString(), url = file.toURI().toString(),
                                                name = file.name, site = "local", type = ContentType.IMAGE,
                                                quality = if (lossless) "WebP Lossless" else "WebP 92",
                                                totalBytes = file.length(), approx = false,
                                                downloadedBytes = file.length(), status = DownloadStatus.COMPLETED,
                                                outputPath = file.absolutePath,
                                            )) + state.downloads) }
                                            result = "تم حفظ صورة أصغر في مكتبتك: ${formatBytes(beforeSize - file.length())} توفير."
                                        } else result = if (lossless && android.os.Build.VERSION.SDK_INT < 30)
                                            "ضغط WebP lossless يحتاج Android 11 أو أحدث. لم تُمس الصورة الأصلية."
                                            else "لم ينقص الحجم فعليًا. لم يُحفظ ملف أكبر."
                                        working = false
                                    }
                                }
                            }
                        } else {
                            Txt("اختر فيديو أو أغنية، ثم اسحب طرفي الشريط داخل المشغل لتحديد المقطع واحفظ MP4 جديدًا بدون إعادة ترميز.",
                                style = AuroraType.body, color = c.textSecondary)
                            AuroraButton("اختر ملف فيديو أو صوت", Modifier.fillMaxWidth()) {
                                mediaPicker.launch(arrayOf("video/*", "audio/*"))
                            }
                            Txt("المقطع يبدأ عند أقرب إطار مفتاح صالح. التشفيرات غير المتوافقة تُرفض دون تغيير الأصل.",
                                style = AuroraType.caption, color = c.warning)
                        }
                    }
                }
            }
            item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Txt("لا عمليات افتراضية", style = AuroraType.heading)
                        Txt(
                            "كل رقم يُقرأ من ملف حقيقي. لا يُستبدل الأصل ولا يُعرض توفير لم يحدث. تحويل الفيديو المتقدم يتطلب تنفيذ ترميز مناسب للترميز المحدد.",
                            style = AuroraType.caption,
                            color = c.textSecondary,
                        )
                        if (result.isNotBlank()) Txt(result, style = AuroraType.label, color = c.accent2)
                    }
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

/* ── Files ──────────────────────────────────────────────────────────────── */

@Composable
fun FilesScreen(downloads: List<DownloadEntity>, onOpen: (DownloadEntity) -> Unit,
                onPlay: (DownloadEntity) -> Unit,
                onPlayUri: (android.net.Uri, String, Boolean) -> Unit,
                onOpenUri: (android.net.Uri) -> Unit,
                onPlayQueue: (List<LocalTrack>, Int) -> Unit) {
    val c = LocalAuroraColors.current
    val context = LocalContext.current
    val store = remember { org.koin.core.context.GlobalContext.get().get<com.auroraget.app.data.LocalStore>() }
    val local by store.state.collectAsState()
    val scope = rememberCoroutineScope()
    var filter by remember { mutableStateOf<ContentType?>(null) }
    var search by remember { mutableStateOf("") }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments()
    ) { picked: List<android.net.Uri> ->
        if (picked.isNotEmpty()) scope.launch {
            picked.forEach { uri ->
                runCatching { context.contentResolver.takePersistableUriPermission(uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            }
            store.update { state -> state.copy(profile = state.profile.copy(importedUris =
                (state.profile.importedUris + picked.map { it.toString() }).distinct())) }
        }
    }
    var deviceAudio by remember { mutableStateOf<List<LocalTrack>>(emptyList()) }
    var scanNote by remember { mutableStateOf("") }
    val audioPermission = if (android.os.Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_AUDIO
        else android.Manifest.permission.READ_EXTERNAL_STORAGE
    val scanLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) scope.launch {
            deviceAudio = withContext(Dispatchers.IO) { runCatching { scanDeviceAudio(context) }.getOrDefault(emptyList()) }
            scanNote = "عُثر على ${deviceAudio.size} ملفًا صوتيًا على الجهاز"
        } else scanNote = "لم يُمنح إذن قراءة ملفات الموسيقى."
    }
    val completed = downloads.filter { it.status == DownloadStatus.COMPLETED }
    val visible = completed.filter { (filter == null || it.type == filter) && it.name.contains(search, true) }
    val imported = local.profile.importedUris.mapNotNull { raw ->
        runCatching {
            val uri = android.net.Uri.parse(raw)
            val mime = context.contentResolver.getType(uri).orEmpty()
            val type = when {
                mime.startsWith("video/") -> ContentType.VIDEO
                mime.startsWith("audio/") -> ContentType.AUDIO
                mime.startsWith("image/") -> ContentType.IMAGE
                else -> ContentType.FILE
            }
            val cursor = context.contentResolver.query(uri,
                arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE),
                null, null, null)
            val info = cursor?.use {
                if (!it.moveToFirst()) null else {
                    val display = it.getString(0)
                    val size = if (it.isNull(1)) 0L else it.getLong(1)
                    display to size
                }
            }
            Triple(uri, info?.first ?: uri.lastPathSegment.orEmpty(), (info?.second ?: 0L) to type)
        }.getOrNull()
    }.filter { (uri, name, pair) -> (filter == null || pair.second == filter) && name.contains(search, true) }
    ScreenShell {
        Spacer(Modifier.height(8.dp))
        ScreenHeader("مكتبة محلية · Scoped Storage", "مكتبة الملفات")
        Spacer(Modifier.height(10.dp))
        AuroraGlass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row {
                    StatTile("مكتمل", "${completed.size}", "ملفات محلية", modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(6.dp))
                    StatTile("الحجم", formatBytes(completed.sumOf { it.totalBytes }), "JO_DON/", modifier = Modifier.weight(1f))
                }
                Txt("تنظيم تلقائي: /Aurora/{type}/{site}/{date} · منع التكرار عبر Hash", style = AuroraType.caption, color = c.textTertiary)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            AuroraButton("استيراد من الجهاز", Modifier.weight(1f)) {
                picker.launch(arrayOf("audio/*", "video/*", "image/*", "application/*"))
            }
            AuroraButton("موسيقى الجهاز", Modifier.weight(.8f), primary = false) {
                filter = ContentType.AUDIO
                scanLauncher.launch(audioPermission)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
            listOf(null, ContentType.VIDEO, ContentType.AUDIO, ContentType.IMAGE, ContentType.FILE).forEach { type ->
                AuroraTag(if (type == null) "الكل" else type.ar, color = if (filter == type) c.accent2 else c.textSecondary,
                    filled = filter == type,
                    modifier = Modifier.tap { filter = type })
            }
        }
        Spacer(Modifier.height(8.dp))
        androidx.compose.foundation.text.BasicTextField(value = search, onValueChange = { search = it },
            textStyle = AuroraType.label.copy(color = c.textPrimary), singleLine = true,
            modifier = Modifier.fillMaxWidth().clip(AuroraShapes.field)
                .background(c.field).padding(9.dp),
            decorationBox = { inner -> Box {
                if (search.isEmpty()) Txt("ابحث في ملفاتك المحلية...", style = AuroraType.caption, color = c.textTertiary)
                inner()
            } })
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.weight(1f)) {
            if (scanNote.isNotBlank()) item { Txt(scanNote, style = AuroraType.caption, color = c.accent2) }
            if (deviceAudio.isNotEmpty() && (filter == null || filter == ContentType.AUDIO)) {
                val tracks = deviceAudio.filter { it.title.contains(search, true) || it.artist.orEmpty().contains(search, true) }
                item { AuroraButton("تشغيل الكل (${tracks.size})", Modifier.fillMaxWidth()) { if (tracks.isNotEmpty()) onPlayQueue(tracks, 0) } }
                items(tracks.size) { i ->
                    val song = tracks[i]
                    Row(Modifier.fillMaxWidth().clip(AuroraShapes.icon).tap { onPlayQueue(tracks, i) }.padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).clip(AuroraShapes.icon).background(c.accentSoft), contentAlignment = Alignment.Center) {
                            Glyph(Ic.MUSIC, c.accent2, size = 17.dp)
                        }
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Txt(song.title, style = AuroraType.label, maxLines = 1)
                            Txt(song.artist ?: "فنان غير معروف", style = AuroraType.caption, color = c.textTertiary, maxLines = 1)
                        }
                    }
                }
            }
            items(imported, key = { it.first.toString() }) { (uri, name, info) ->
                AuroraGlass(Modifier.fillMaxWidth(), radius = 18.dp) {
                    Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).clip(AuroraShapes.icon).background(c.accentSoft),
                            contentAlignment = Alignment.Center) {
                            Glyph(if (info.second == ContentType.AUDIO) Ic.MUSIC else Ic.PLAY, c.accent2, size = 16.dp)
                        }
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Txt(name, style = AuroraType.label, maxLines = 1)
                            Txt("${formatBytes(info.first)} · ${info.second.ar} · ملف الجهاز",
                                style = AuroraType.caption, color = c.textTertiary)
                        }
                        AuroraButton("فتح", primary = false) {
                            if (info.second == ContentType.AUDIO || info.second == ContentType.VIDEO)
                                onPlayUri(uri, name, info.second == ContentType.AUDIO)
                            else onOpenUri(uri)
                        }
                    }
                }
            }
            items(visible, key = { it.id }) { item ->
                AuroraGlass(Modifier.fillMaxWidth(), radius = 18.dp) {
                    Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(38.dp).clip(AuroraShapes.icon).background(c.accentSoft),
                            contentAlignment = Alignment.Center,
                        ) { Glyph(when (item.type) { ContentType.AUDIO -> Ic.MUSIC; ContentType.VIDEO -> Ic.PLAY; else -> Ic.FOLDER }, c.accent2, size = 16.dp) }
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Txt(item.name, style = AuroraType.label, maxLines = 1)
                            Txt(
                                "${formatBytes(item.totalBytes)} · ${item.quality}",
                                style = AuroraType.caption,
                                color = c.textTertiary,
                            )
                        }
                        AuroraButton("فتح", primary = false) {
                            if (item.type == ContentType.VIDEO || item.type == ContentType.AUDIO) onPlay(item) else onOpen(item)
                        }
                    }
                }
            }
            if (visible.isEmpty() && imported.isEmpty()) {
                item { Txt("لا ملفات مطابقة بعد. استورد ملفًا من جهازك أو انتظر اكتمال التحميل.",
                    style = AuroraType.caption, color = c.textSecondary) }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

/* ── Settings ───────────────────────────────────────────────────────────── */

@Composable
fun SettingsScreen(
    settings: com.auroraget.app.data.AppSettings,
    onTheme: (AuroraThemeId) -> Unit,
    onLight: (Boolean) -> Unit,
    onArabic: (Boolean) -> Unit,
    onConnections: (Int) -> Unit,
    onWifi: (Boolean) -> Unit,
    onAdblock: (Boolean) -> Unit,
    onAutoResume: (Boolean) -> Unit,
    onUpdate: () -> Unit,
    updateStatus: String,
    onTools: () -> Unit,
    onYouTube: () -> Unit,
) {
    val c = LocalAuroraColors.current
    val arabic = settings.arabic
    fun tr(ar: String, en: String) = if (arabic) ar else en
    ScreenShell {
        Spacer(Modifier.height(8.dp))
        ScreenHeader(tr("محلي بالكامل · بلا خادم أو قاعدة بيانات", "Local only · no backend or database"),
            tr("الإعدادات", "Settings"))
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
            item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Txt(tr("المظهر والثيمات", "Appearance & themes"), style = AuroraType.heading)
                        Txt(tr("صورة واقعية وألوان وحركة مخصصة لكل ثيم في جميع الشاشات.",
                            "Real photography, colors and motion for every theme and screen."),
                            style = AuroraType.caption, color = c.textSecondary)
                        AuroraThemeId.entries.chunked(3).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                                row.forEach { entry ->
                                    val selected = settings.themeId == entry.id
                                    Column(Modifier.weight(1f).tap { onTheme(entry) },
                                        horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(Modifier.fillMaxWidth().height(61.dp)
                                            .clip(AuroraShapes.icon)
                                            .border(if (selected) 2.dp else 1.dp,
                                                if (selected) c.accent2 else c.line, AuroraShapes.icon)) {
                                            Image(painterResource(entry.photoRes), contentDescription = entry.labelAr,
                                                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(AuroraShapes.icon))
                                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                                                listOf(Color.Transparent, Color.Black.copy(alpha = .68f)))))
                                            Txt(if (arabic) entry.labelAr else entry.labelEn,
                                                style = AuroraType.caption, color = Color.White,
                                                maxLines = 1, modifier = Modifier.align(Alignment.BottomCenter).padding(5.dp))
                                        }
                                    }
                                }
                            }
                        }
                        SettingRow(tr("الوضع الفاتح", "Light mode"), settings.light, onLight)
                        SettingRow(tr("العربية RTL", "Arabic RTL"), settings.arabic, onArabic)
                    }
                }
            }
            item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Txt(tr("التحميل والشبكة", "Download & network"), style = AuroraType.heading)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Txt(tr("اتصالات متوازية", "Parallel connections") + ": ${settings.connections}",
                                style = AuroraType.label, modifier = Modifier.weight(1f))
                            AuroraButton("8–32", primary = false) {
                                onConnections(when (settings.connections) { 8 -> 16; 16 -> 24; 24 -> 32; else -> 8 })
                            }
                        }
                        AuroraProgress(settings.connections / 32f)
                        SettingRow(tr("Wi-Fi فقط", "Wi-Fi only"), settings.wifiOnly, onWifi)
                        SettingRow(tr("استئناف عند فتح التطبيق", "Resume when app opens"), settings.autoResume, onAutoResume)
                        SettingRow(tr("حظر نطاقات الإعلانات المعروفة", "Block known ad domains"), settings.adblock, onAdblock)
                        Txt(tr("يكتشف المحرك دعم Range ويتراجع لاتصال واحد عند غيابه. السرعة المعروضة من البايتات الفعلية.",
                            "Range-aware download; one connection fallback. Speed uses actual transferred bytes."),
                            style = AuroraType.caption, color = c.textTertiary)
                    }
                }
            }
            item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Txt("yt-dlp · FFmpeg · aria2c", style = AuroraType.heading)
                        Txt(tr("تحديث المستخرِج عند الطلب. تنزيل الوسائط مسموح به فقط لمن يملك الحقوق.",
                            "Update the extractor on demand; download only media you are allowed to save."),
                            style = AuroraType.caption, color = c.textSecondary)
                        AuroraButton(tr("فحص وتحديث المستخرِج", "Check & update extractor")) { onUpdate() }
                        if (updateStatus.isNotBlank()) Txt(updateStatus, style = AuroraType.caption,
                            color = if (updateStatus.startsWith("فشل")) c.warning else c.success)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    AuroraButton(tr("صفحة YouTube", "YouTube catalog"), Modifier.weight(1f), primary = false) { onYouTube() }
                    AuroraButton(tr("أدوات الوسائط", "Media tools"), Modifier.weight(1f), primary = false) { onTools() }
                }
            }
            item {
                Txt(tr("المسؤولية على المستخدم في احترام حقوق النشر. لا DRM ولا Paywalls. ملف التعريف يُصدّر JSON من تبويب YouTube ← حسابي.",
                    "Respect copyright. No DRM or paywall bypass. Export your JSON profile in YouTube → Profile."),
                    style = AuroraType.caption, color = c.warning)
            }
            item { Spacer(Modifier.height(96.dp)) }
        }
    }
}

@Composable
private fun SettingRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Txt(label, style = AuroraType.label, modifier = Modifier.weight(1f))
        AuroraToggle(value, onChange, label)
    }
}

/* Exposed helper so the Activity can run lossless image compression from UI. */
fun compressPickedImage(context: Context, uri: android.net.Uri, lossless: Boolean): Pair<java.io.File, Long>? {
    val dir = java.io.File(context.cacheDir, "aurora_compress").apply { mkdirs() }
    val input = java.io.File(dir, "source_${System.currentTimeMillis()}")
    val copied = runCatching {
        context.contentResolver.openInputStream(uri)?.use { inputStream -> input.outputStream().use { inputStream.copyTo(it) } }
    }.getOrNull() ?: return null
    if (copied <= 0) return null
    val output = java.io.File(context.getExternalFilesDir(null) ?: context.filesDir,
        "JO_DON/compressed/compressed_${System.currentTimeMillis()}.webp")
    output.parentFile?.mkdirs()
    val result = MediaEngine.compressImage(input, output, lossless)
    input.delete()
    return result?.let { it to copied }
}

/** Reads the device music collection through MediaStore (needs the audio permission). */
fun scanDeviceAudio(context: Context): List<LocalTrack> {
    val found = mutableListOf<LocalTrack>()
    val collection = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    context.contentResolver.query(
        collection,
        arrayOf(android.provider.MediaStore.Audio.Media._ID, android.provider.MediaStore.Audio.Media.TITLE, android.provider.MediaStore.Audio.Media.ARTIST),
        "${android.provider.MediaStore.Audio.Media.IS_MUSIC} != 0", null,
        "${android.provider.MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC",
    )?.use { cursor ->
        while (cursor.moveToNext()) {
            val uri = android.content.ContentUris.withAppendedId(collection, cursor.getLong(0))
            found += LocalTrack(uri, cursor.getString(1) ?: "بدون عنوان", true, cursor.getString(2)?.takeUnless { it == "<unknown>" })
        }
    }
    return found
}
