package com.auroraget.app.ui.theme

import com.auroraget.app.R
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Aurora Glass design system.
 *
 * Deliberately contains no Material imports: only Compose foundation/ui types.
 * Typography uses the platform font family with an Arabic-first fallback chain
 * (IBM Plex Sans Arabic / Readex Pro can be dropped into res/font without code
 * changes). Dynamic Material You colour is never used.
 */
enum class AuroraThemeId(val id: String, val labelAr: String, val labelEn: String) {
    AURORA("aurora", "أورورا", "Aurora"),
    OCEAN("ocean", "محيط", "Ocean"),
    SUNSET("sunset", "غروب", "Sunset"),
    EMERALD("emerald", "زمرد", "Emerald"),
    NEON("neon", "نيون", "Neon"),
    MONO("mono", "رمادي", "Mono");

    val palette: List<Color>
        get() = when (this) {
            AURORA -> listOf(Color(0xFF4A8CFF), Color(0xFFA478E8), Color(0xFFEF7380))
            OCEAN -> listOf(Color(0xFF2EE6D6), Color(0xFF3AA8FF), Color(0xFF7B7DFF))
            SUNSET -> listOf(Color(0xFFFFB35C), Color(0xFFFF7A7A), Color(0xFFE765C9))
            EMERALD -> listOf(Color(0xFF53E6A5), Color(0xFF2EC7C2), Color(0xFF84D9FF))
            NEON -> listOf(Color(0xFFA3FF4E), Color(0xFF39F5D2), Color(0xFFFF5FD2))
            MONO -> listOf(Color(0xFFF0F2F8), Color(0xFFB9C0D4), Color(0xFF818AA3))
        }

    val photoRes: Int get() = when (this) {
        AURORA -> R.drawable.theme_aurora
        OCEAN -> R.drawable.theme_ocean
        SUNSET -> R.drawable.theme_sunset
        EMERALD -> R.drawable.theme_emerald
        NEON -> R.drawable.theme_neon
        MONO -> R.drawable.theme_mono
    }

    val motionDuration: Int get() = when (this) {
        AURORA -> 6200
        OCEAN -> 8800
        SUNSET -> 7300
        EMERALD -> 9400
        NEON -> 3000
        MONO -> 12000
    }
}

data class AuroraColors(
    val accent1: Color,
    val accent2: Color,
    val accent3: Color,
    val background: Color,
    val backgroundTop: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val glass: Color,
    val glassStrong: Color,
    val line: Color,
    val lineStrong: Color,
    val field: Color,
    val success: Color,
    val warning: Color,
    val danger: Color,
    val isLight: Boolean,
    val themeId: AuroraThemeId,
) {
    val accents: List<Color> get() = listOf(accent1, accent2, accent3)
    val accentSoft: Color get() = accent2.copy(alpha = if (isLight) 0.16f else 0.22f)
}

fun auroraColors(theme: AuroraThemeId, light: Boolean): AuroraColors {
    val palette = theme.palette
    return if (light) {
        AuroraColors(
            accent1 = palette[0], accent2 = palette[1], accent3 = palette[2],
            background = Color(0xFFE9EDF7), backgroundTop = Color(0xFFF7F8FD),
            textPrimary = Color(0xFF13182A), textSecondary = Color(0xFF525C73),
            textTertiary = Color(0xFF7D8599),
            glass = Color(0xB3FFFFFF), glassStrong = Color(0xEAFFFFFF),
            line = Color(0x17121830), lineStrong = Color(0x29121830),
            field = Color(0xCCFFFFFF),
            success = Color(0xFF159A6C), warning = Color(0xFF9A6A00), danger = Color(0xFFC9364A),
            isLight = true, themeId = theme,
        )
    } else {
        AuroraColors(
            accent1 = palette[0], accent2 = palette[1], accent3 = palette[2],
            background = Color(0xFF05070E), backgroundTop = Color(0xFF0C1020),
            textPrimary = Color(0xFFF5F7FD), textSecondary = Color(0xFFA7AEC2),
            textTertiary = Color(0xFF737C92),
            glass = Color(0x0BFFFFFF), glassStrong = Color(0x1FFFFFFF),
            line = Color(0x1AFFFFFF), lineStrong = Color(0x2EFFFFFF),
            field = Color(0x14FFFFFF),
            success = Color(0xFF5EE1B0), warning = Color(0xFFFFD284), danger = Color(0xFFFF8291),
            isLight = false, themeId = theme,
        )
    }
}

val LocalAuroraColors = staticCompositionLocalOf { auroraColors(AuroraThemeId.AURORA, false) }

object AuroraType {
    private val family = FontFamily(
        Font(R.font.ibm_plex_sans_arabic_regular, FontWeight.Normal),
        Font(R.font.ibm_plex_sans_arabic_medium, FontWeight.Medium),
        Font(R.font.ibm_plex_sans_arabic_semibold, FontWeight.SemiBold),
        Font(R.font.ibm_plex_sans_arabic_bold, FontWeight.Bold),
    )
    val brand = TextStyle(fontFamily = FontFamily(Font(R.font.outfit_semibold, FontWeight.SemiBold)), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
    val display = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 36.sp, letterSpacing = (-0.6).sp)
    val title = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 21.sp, lineHeight = 29.sp, letterSpacing = (-0.3).sp)
    val heading = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 24.sp)
    val body = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 21.sp)
    val label = TextStyle(fontFamily = family, fontWeight = FontWeight.Medium, fontSize = 11.5.sp, lineHeight = 17.sp)
    val caption = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 10.sp, lineHeight = 15.sp)
    val mono = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium, fontSize = 10.sp, lineHeight = 15.sp)
}

object AuroraShapes {
    val card = RoundedCornerShape(26.dp)
    val sheet = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
    val field = RoundedCornerShape(16.dp)
    val button = RoundedCornerShape(14.dp)
    val chip = RoundedCornerShape(999.dp)
    val tile = RoundedCornerShape(18.dp)
    val icon = RoundedCornerShape(12.dp)
    val dock = RoundedCornerShape(26.dp)
}

@Composable
fun AuroraTheme(
    theme: AuroraThemeId,
    light: Boolean,
    content: @Composable () -> Unit,
) {
    val colors = auroraColors(theme, light)
    CompositionLocalProvider(LocalAuroraColors provides colors, content = content)
}

@Composable
fun auroraColors(): AuroraColors = LocalAuroraColors.current
