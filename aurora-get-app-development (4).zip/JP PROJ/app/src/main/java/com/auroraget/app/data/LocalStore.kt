package com.auroraget.app.data

import android.content.Context
import android.net.Uri
import android.util.AtomicFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/** One atomic JSON document. There is no application database and no server. */
class LocalStore(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = false }
    private val file = AtomicFile(File(context.filesDir, "jo_don_state.json"))
    private val mutex = Mutex()
    private val mutableState = MutableStateFlow(readOrEmpty())
    val state = mutableState.asStateFlow()

    private fun readOrEmpty(): LocalState = runCatching {
        file.openRead().bufferedReader(Charsets.UTF_8).use { json.decodeFromString<LocalState>(it.readText()) }
    }.getOrDefault(LocalState())

    suspend fun update(transform: (LocalState) -> LocalState): LocalState = mutex.withLock {
        withContext(Dispatchers.IO) {
            val next = transform(mutableState.value)
            val bytes = json.encodeToString(next).toByteArray(Charsets.UTF_8)
            val stream = file.startWrite()
            try {
                stream.write(bytes)
                file.finishWrite(stream)
            } catch (error: Exception) {
                file.failWrite(stream)
                throw error
            }
            mutableState.value = next
            next
        }
    }

    suspend fun exportProfile(uri: Uri) = withContext(Dispatchers.IO) {
        val snapshot = state.value
        // Never export cookies, media, or the separately encrypted API credential.
        val portable = LocalState(settings = snapshot.settings, profile = snapshot.profile)
        context.contentResolver.openOutputStream(uri, "wt")?.use {
            it.write(json.encodeToString(portable).toByteArray(Charsets.UTF_8))
        } ?: error("Cannot open export document")
    }

    suspend fun importProfile(uri: Uri) = withContext(Dispatchers.IO) {
        val data = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use {
            json.decodeFromString<LocalState>(it.readText())
        } ?: error("Cannot read import document")
        require(data.version == 1) { "Unsupported profile version" }
        update { it.copy(profile = data.profile, settings = data.settings) }
    }

    suspend fun resetHistory() = update { it.copy(profile = it.profile.copy(history = emptyList())) }
}