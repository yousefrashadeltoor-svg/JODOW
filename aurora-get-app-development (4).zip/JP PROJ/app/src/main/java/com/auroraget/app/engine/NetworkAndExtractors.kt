package com.auroraget.app.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import com.auroraget.app.data.AnalyzedSource
import com.auroraget.app.data.ContentType
import com.auroraget.app.data.MediaFormat
import com.auroraget.app.data.SizeProbe
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

private const val TAG = "JODonExtractor"

object NetworkClient {
    private val stored = mutableMapOf<String, MutableMap<String, Cookie>>()
    val cookies = object : CookieJar {
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            synchronized(stored) {
                val current = stored.getOrPut(url.host) { mutableMapOf() }
                cookies.forEach { current[it.name] = it }
            }
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> = synchronized(stored) {
            stored[url.host]?.values?.filter { it.expiresAt > System.currentTimeMillis() }.orEmpty()
        }
    }

    val client: OkHttpClient = OkHttpClient.Builder()
        .cookieJar(cookies)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    const val USER_AGENT = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    fun requestBuilder(url: String, headers: Map<String, String> = emptyMap()): Request.Builder =
        Request.Builder().url(url).header("User-Agent", USER_AGENT).apply {
            headers.forEach { (name, value) -> header(name, value) }
        }
}

/** Public upstream wrapper API, not a reflective or simulated extractor. */
class ExtractorEngine(private val context: Context) {
    @Volatile private var ready = false

    @Synchronized fun init() {
        if (ready) return
        YoutubeDL.getInstance().init(context.applicationContext)
        FFmpeg.getInstance().init(context.applicationContext)
        Aria2c.getInstance().init(context.applicationContext)
        ready = true
    }

    fun dumpJson(url: String): String {
        init()
        val request = YoutubeDLRequest(url)
        request.addOption("--dump-single-json")
        request.addOption("--skip-download")
        request.addOption("--no-playlist")
        request.addOption("--no-warnings")
        return YoutubeDL.getInstance().execute(request).out.trim()
    }

    /** Executes the bundled yt-dlp binary; the callback carries its real progress. */
    fun download(
        url: String,
        formatId: String,
        destination: File,
        processId: String,
        merge: Boolean,
        onProgress: (Float) -> Unit,
    ): File {
        init()
        val folder = destination.parentFile ?: error("No output folder")
        folder.mkdirs()
        val base = destination.nameWithoutExtension
        val request = YoutubeDLRequest(url)
        if (formatId.startsWith("audio:")) {
            request.addOption("--format", "bestaudio/best")
            request.addOption("--extract-audio")
            request.addOption("--audio-format", formatId.substringAfter(':'))
            request.addOption("--audio-quality", "0")
        } else {
            request.addOption("--format", when {
                formatId == "best" -> "bestvideo*+bestaudio/best"
                merge -> "$formatId+bestaudio/$formatId/best"
                else -> "$formatId/best"
            })
            if (merge || formatId == "best") request.addOption("--merge-output-format", "mp4")
        }
        request.addOption("--no-playlist")
        request.addOption("--no-part")
        request.addOption("--newline")
        // '%' in a title must be escaped or yt-dlp treats it as a template field.
        request.addOption("-o", File(folder, base.replace("%", "%%") + ".%(ext)s").absolutePath)
        request.addOption("--downloader", "libaria2c.so")
        request.addOption("--downloader-args", "aria2c:-x16 -s16 -k1M")
        YoutubeDL.getInstance().execute(request, processId, { percent, _, _ ->
            onProgress(percent.coerceIn(0f, 100f))
        })
        return folder.listFiles()?.filter { it.isFile && it.nameWithoutExtension == base && it.length() > 0 }
            ?.maxByOrNull { it.lastModified() } ?: error("yt-dlp finished without an output file")
    }

    /** Direct playable URL(s) resolved by yt-dlp; used as a playback fallback. */
    fun playableUrls(url: String, maxHeight: Int): List<String> {
        init()
        val request = YoutubeDLRequest(url)
        request.addOption("--format", "best[height<=$maxHeight][protocol^=http]/best[protocol^=http]/best")
        request.addOption("--get-url")
        request.addOption("--no-playlist")
        request.addOption("--no-warnings")
        return YoutubeDL.getInstance().execute(request).out.lines().map { it.trim() }.filter { it.startsWith("http") }
    }

    fun cancel(processId: String) {
        if (ready) YoutubeDL.getInstance().destroyProcessById(processId)
    }

    fun update() {
        init()
        YoutubeDL.getInstance().updateYoutubeDL(context.applicationContext)
    }

    fun parseFormats(raw: String): Map<ContentType, List<MediaFormat>> {
        val root = Json.parseToJsonElement(raw).jsonObject
        val videos = mutableListOf<MediaFormat>()
        val audios = mutableListOf<MediaFormat>()
        val images = mutableListOf<MediaFormat>()
        val files = mutableListOf<MediaFormat>()

        root["formats"]?.jsonArray?.forEach { element ->
            val item = element.jsonObject
            val id = item.string("format_id") ?: return@forEach
            val videoCodec = item.string("vcodec")
            val audioCodec = item.string("acodec")
            val ext = item.string("ext")?.uppercase() ?: "BIN"
            val exact = item["filesize"]?.jsonPrimitive?.longOrNull
            val approx = item["filesize_approx"]?.jsonPrimitive?.longOrNull
            val bytes = exact ?: approx
            val height = item["height"]?.jsonPrimitive?.longOrNull
            val fps = item["fps"]?.jsonPrimitive?.longOrNull
            val bitrate = item["abr"]?.jsonPrimitive?.doubleOrNull
                ?: item["tbr"]?.jsonPrimitive?.doubleOrNull
            val base = MediaFormat(
                id = id,
                type = ContentType.FILE,
                quality = "Original",
                container = ext,
                codec = videoCodec ?: audioCodec ?: "",
                detail = bitrate?.let { "%.0f kbps".format(it) } ?: "",
                bytes = bytes,
                approx = exact == null,
                directUrl = item.string("url"),
            )
            when {
                videoCodec != null && videoCodec != "none" -> videos += base.copy(
                    type = ContentType.VIDEO,
                    quality = height?.let { "${it}p${fps?.let { n -> " · ${n}fps" } ?: ""}" } ?: "Video",
                    needsMerge = audioCodec == null || audioCodec == "none",
                )
                audioCodec != null && audioCodec != "none" -> audios += base.copy(
                    type = ContentType.AUDIO,
                    quality = bitrate?.let { "${it.toInt()} kbps" } ?: "Audio",
                    codec = audioCodec,
                )
            }
        }

        root["thumbnails"]?.jsonArray?.forEachIndexed { index, element ->
            val image = element.jsonObject
            val url = image.string("url") ?: return@forEachIndexed
            images += MediaFormat(
                id = "image_$index", type = ContentType.IMAGE,
                quality = "${image.string("width") ?: "?"} × ${image.string("height") ?: "?"}",
                container = url.substringBefore('?').substringAfterLast('.', "JPG").uppercase(),
                directUrl = url,
            )
        }

        root["subtitles"]?.jsonObject?.forEach { (language, entries) ->
            entries.jsonArray.forEach { element ->
                val subtitle = element.jsonObject
                val url = subtitle.string("url") ?: return@forEach
                files += MediaFormat(
                    id = "subtitle_${language}_${files.size}", type = ContentType.FILE,
                    quality = "$language · subtitles", container = subtitle.string("ext")?.uppercase() ?: "VTT",
                    directUrl = url,
                )
            }
        }

        return buildMap {
            if (videos.isNotEmpty()) put(ContentType.VIDEO, videos.sortedByDescending {
                it.quality.substringBefore('p').toIntOrNull() ?: 0
            }.mapIndexed { index, f -> f.copy(best = index == 0) })
            if (audios.isNotEmpty()) put(ContentType.AUDIO, audios.sortedByDescending {
                it.detail.substringBefore(' ').toIntOrNull() ?: 0
            }.mapIndexed { index, f -> f.copy(best = index == 0) })
            if (images.isNotEmpty()) put(ContentType.IMAGE, images)
            if (files.isNotEmpty()) put(ContentType.FILE, files)
        }
    }
}

internal fun JsonObject.string(name: String): String? =
    (get(name) as? JsonPrimitive)?.content?.takeUnless { it == "null" || it.isBlank() }

class LinkAnalyzer(private val extractor: ExtractorEngine) {
    private val cache = object : LinkedHashMap<String, AnalyzedSource>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, AnalyzedSource>?) = size > 20
    }

    suspend fun analyze(rawUrl: String, onStage: (Int) -> Unit = {}): Result<AnalyzedSource> =
        withContext(Dispatchers.IO) {
            runCatching {
                val normalized = rawUrl.trim().let { if (it.startsWith("http")) it else "https://$it" }
                val url = normalized.toHttpUrlOrNull()?.toString() ?: error("رابط غير صالح")
                synchronized(cache) {
                    cache[url]?.takeIf { System.currentTimeMillis() - it.analyzedAtMillis < 3_600_000 }
                }?.let { return@withContext Result.success(it) }
                onStage(0)
                coroutineScope {
                    val probe = async { probeSize(url) }
                    val title = async {
                        runCatching {
                            NetworkClient.client.newCall(NetworkClient.requestBuilder(url).get().build()).execute().use { response ->
                                val mime = response.header("Content-Type").orEmpty()
                                if (mime.contains("html", true)) {
                                    // A bounded read avoids accidentally buffering a huge media response.
                                    val html = response.body?.source()?.let { source ->
                                        source.request(128 * 1024L)
                                        source.buffer.clone().readUtf8(minOf(source.buffer.size, 128 * 1024L))
                                    }.orEmpty()
                                    val doc = Jsoup.parse(html, url)
                                    Pair(doc.selectFirst("meta[property=og:title]")?.attr("content") ?: doc.title(),
                                        doc.selectFirst("meta[property=og:image]")?.attr("content"))
                                } else Pair("", null)
                            }
                        }.getOrDefault(Pair("", null))
                    }
                    val domain = url.toHttpUrlOrNull()?.host.orEmpty()
                    val head = probe.await()
                    onStage(1)
                    val html = title.await()
                    val extension = url.substringBefore('?').substringAfterLast('.', "").lowercase()
                    val isManifest = extension == "m3u8" || extension == "mpd"
                    val directType = when (extension) {
                        "mp4", "mkv", "webm", "mov", "m3u8", "mpd" -> ContentType.VIDEO
                        "mp3", "m4a", "flac", "wav", "opus", "ogg" -> ContentType.AUDIO
                        "png", "jpg", "jpeg", "webp", "avif", "gif" -> ContentType.IMAGE
                        "zip", "pdf", "apk", "iso", "txt", "json" -> ContentType.FILE
                        else -> null
                    }
                    val raw = if (directType == null) runCatching { extractor.dumpJson(url) }
                        .onFailure { Log.w(TAG, "yt-dlp could not extract: ${it.message}") }.getOrNull() else null
                    val root = raw?.let { runCatching { Json.parseToJsonElement(it).jsonObject }.getOrNull() }
                    val formats = when {
                        root != null -> extractor.parseFormats(raw)
                        directType != null -> mapOf(directType to listOf(MediaFormat(
                            id = "direct", type = directType, quality = "المصدر الأصلي",
                            container = if (isManifest) "MP4" else extension.uppercase(),
                            bytes = if (isManifest) null else head.bytes,
                            approx = isManifest || head.bytes == null, best = true,
                            directUrl = if (isManifest) null else url,
                        )))
                        else -> emptyMap()
                    }
                    onStage(3)
                    val titleText = root?.string("title") ?: html.first.takeIf { it.isNotBlank() }
                        ?: url.substringBefore('?').substringAfterLast('/').ifBlank { domain }
                    val best = formats[ContentType.VIDEO]?.firstOrNull { it.best }
                        ?: formats.values.flatten().firstOrNull()
                    val contentSize = best?.bytes ?: if (isManifest) null else head.bytes
                    val approximate = if (best?.bytes != null) best.approx else true
                    val source = AnalyzedSource(
                        url = url, site = root?.string("extractor_key") ?: domain.substringBefore('.'),
                        domain = domain, title = titleText,
                        filename = titleText.replace(Regex("[\\\\/:*?\"<>|]"), "-").take(90) +
                            ".${best?.container?.lowercase() ?: extension.ifBlank { "bin" }}",
                        thumbnail = root?.string("thumbnail") ?: html.second,
                        channel = root?.string("uploader"),
                        durationSeconds = root?.get("duration")?.jsonPrimitive?.longOrNull?.toInt(),
                        counts = formats.mapValues { it.value.size }, formats = formats,
                        exactSizeBytes = contentSize, approxSize = approximate,
                    )
                    synchronized(cache) { cache[url] = source }
                    source
                }
            }
        }

    suspend fun probeSize(url: String, headers: Map<String, String> = emptyMap()): SizeProbe =
        withContext(Dispatchers.IO) {
            val head = runCatching {
                NetworkClient.client.newCall(NetworkClient.requestBuilder(url, headers).head().build()).execute().use { response ->
                    val size = response.header("Content-Length")?.toLongOrNull()?.takeIf { it > 0 }
                    SizeProbe(size, size == null, response.header("ETag"), response.header("Last-Modified"),
                        response.header("Accept-Ranges")?.equals("bytes", true) == true)
                }
            }.getOrNull()
            if (head?.bytes != null && head.acceptsRanges) return@withContext head
            runCatching {
                NetworkClient.client.newCall(NetworkClient.requestBuilder(url, headers)
                    .header("Range", "bytes=0-0").get().build()).execute().use { response ->
                    val total = response.header("Content-Range")?.substringAfter('/')?.toLongOrNull()
                    SizeProbe(total ?: head?.bytes, total == null && head?.bytes == null,
                        response.header("ETag") ?: head?.etag,
                        response.header("Last-Modified") ?: head?.lastModified,
                        response.code == 206 && total != null)
                }
            }.getOrElse { head ?: SizeProbe(null, true, null, null, false) }
        }
}

object MediaEngine {
    /** Actual pixel-preserving WebP lossless on API 30+; never overwrites input. */
    fun compressImage(source: File, target: File, lossless: Boolean): File? = runCatching {
        val bitmap = BitmapFactory.decodeFile(source.absolutePath) ?: return null
        val format = if (lossless && android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSLESS
            else if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY
            else Bitmap.CompressFormat.WEBP
        if (lossless && android.os.Build.VERSION.SDK_INT < 30) {
            bitmap.recycle()
            return null
        }
        FileOutputStream(target).use { bitmap.compress(format, if (lossless) 100 else 92, it) }
        bitmap.recycle()
        if (target.length() in 1 until source.length()) target else { target.delete(); null }
    }.getOrNull()
}