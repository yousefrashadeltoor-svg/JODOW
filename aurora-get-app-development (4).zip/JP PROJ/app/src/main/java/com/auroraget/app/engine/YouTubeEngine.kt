package com.auroraget.app.engine

import com.auroraget.app.data.LocalProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabInfo
import org.schabi.newpipe.extractor.comments.CommentsInfo
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.kiosk.KioskInfo
import org.schabi.newpipe.extractor.linkhandler.ListLinkHandler
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType
import java.util.Locale

data class YtItem(
    val url: String,
    val title: String,
    val channel: String,
    val channelUrl: String,
    val thumbnail: String,
    val durationSec: Long,
    val views: Long,
    val uploaded: String,
    val short: Boolean,
    val live: Boolean,
)

/** One page of real results plus a closure that fetches the following page. */
class FeedPage(val items: List<YtItem>, val next: (suspend () -> FeedPage)?)

data class YtFormat(
    val itag: Int,
    val label: String,
    val container: String,
    val codec: String,
    val url: String,
    val bytes: Long?,
    val height: Int,
    val bitrateKbps: Int,
    val videoOnly: Boolean,
)

data class YtComment(val author: String, val text: String, val likes: Int, val date: String)

data class YtStream(
    val url: String,
    val title: String,
    val description: String,
    val channel: String,
    val channelUrl: String,
    val channelAvatar: String,
    val subscribers: Long,
    val views: Long,
    val likes: Long,
    val uploaded: String,
    val durationSec: Long,
    val thumbnail: String,
    val live: Boolean,
    val hlsUrl: String,
    val dashUrl: String,
    val muxed: List<YtFormat>,
    val videoOnly: List<YtFormat>,
    val audio: List<YtFormat>,
    val related: List<YtItem>,
)

class YtChannel(
    val url: String,
    val name: String,
    val avatar: String,
    val banner: String,
    val subscribers: Long,
    val description: String,
    val videos: suspend () -> FeedPage,
    val shorts: (suspend () -> FeedPage)?,
)

/**
 * Native YouTube browsing through the open-source NewPipe Extractor.
 * No API key, no Google account, no WebView and no intermediary server:
 * every call goes straight from the device to YouTube.
 */
class YouTubeEngine {
    private val service get() = ServiceList.YouTube
    @Volatile private var ready = false

    private fun ensure() {
        if (ready) return
        synchronized(this) {
            if (ready) return
            val locale = Locale.getDefault()
            NewPipe.init(
                OkDownloader,
                Localization.fromLocale(locale),
                ContentCountry(locale.country.ifBlank { "US" }),
            )
            ready = true
        }
    }

    private suspend fun <T> io(block: () -> T): T = withContext(Dispatchers.IO) { ensure(); block() }

    private fun InfoItem.toItem(): YtItem? {
        val stream = this as? StreamInfoItem ?: return null
        return YtItem(
            url = stream.url,
            title = stream.name.orEmpty(),
            channel = stream.uploaderName.orEmpty(),
            channelUrl = stream.uploaderUrl.orEmpty(),
            thumbnail = stream.thumbnails.maxByOrNull { it.height }?.url.orEmpty(),
            durationSec = stream.duration,
            views = stream.viewCount,
            uploaded = stream.textualUploadDate.orEmpty(),
            short = stream.isShortFormContent,
            live = stream.streamType == StreamType.LIVE_STREAM,
        )
    }

    /* ── Kiosks (YouTube's public charts) ─────────────────────────────── */

    suspend fun kiosks(): List<String> = io {
        val list = service.kioskList
        val default = list.defaultKioskId
        listOf(default) + list.availableKiosks.filter { it != default }
    }

    suspend fun kiosk(id: String): FeedPage = io {
        val url = service.kioskList.getListLinkHandlerFactoryByType(id).fromId(id).url
        val info = KioskInfo.getInfo(service, url)
        FeedPage(info.relatedItems.mapNotNull { it.toItem() }, kioskNext(url, info.nextPage))
    }

    private fun kioskNext(url: String, page: Page?): (suspend () -> FeedPage)? =
        if (!Page.isValid(page)) null else ({
            io {
                val more = KioskInfo.getMoreItems(service, url, page)
                FeedPage(more.items.mapNotNull { it.toItem() }, kioskNext(url, more.nextPage))
            }
        })

    /* ── Search ───────────────────────────────────────────────────────── */

    suspend fun suggest(query: String): List<String> =
        if (query.isBlank()) emptyList() else io { service.suggestionExtractor.suggestionList(query) }

    suspend fun search(query: String): FeedPage = io {
        val handler = service.searchQHFactory.fromQuery(query, listOf("videos"), "")
        val info = SearchInfo.getInfo(service, handler)
        FeedPage(info.relatedItems.mapNotNull { it.toItem() }, searchNext(handler, info.nextPage))
    }

    private fun searchNext(handler: SearchQueryHandler, page: Page?): (suspend () -> FeedPage)? =
        if (!Page.isValid(page)) null else ({
            io {
                val more = SearchInfo.getMoreItems(service, handler, page)
                FeedPage(more.items.mapNotNull { it.toItem() }, searchNext(handler, more.nextPage))
            }
        })

    /* ── Channels ─────────────────────────────────────────────────────── */

    private fun tabFeed(tab: ListLinkHandler): suspend () -> FeedPage = {
        io {
            val info = ChannelTabInfo.getInfo(service, tab)
            FeedPage(info.relatedItems.mapNotNull { it.toItem() }, tabNext(tab, info.nextPage))
        }
    }

    private fun tabNext(tab: ListLinkHandler, page: Page?): (suspend () -> FeedPage)? =
        if (!Page.isValid(page)) null else ({
            io {
                val more = ChannelTabInfo.getMoreItems(service, tab, page!!)
                FeedPage(more.items.mapNotNull { it.toItem() }, tabNext(tab, more.nextPage))
            }
        })

    suspend fun channel(url: String): YtChannel = io {
        val info = ChannelInfo.getInfo(service, url)
        val videos = info.tabs.firstOrNull { "videos" in it.contentFilters }
        val shorts = info.tabs.firstOrNull { "shorts" in it.contentFilters }
        YtChannel(
            url = info.url,
            name = info.name.orEmpty(),
            avatar = info.avatars.maxByOrNull { it.height }?.url.orEmpty(),
            banner = info.banners.maxByOrNull { it.height }?.url.orEmpty(),
            subscribers = info.subscriberCount,
            description = info.description.orEmpty(),
            videos = videos?.let { tabFeed(it) } ?: { FeedPage(emptyList(), null) },
            shorts = shorts?.let { tabFeed(it) },
        )
    }

    private suspend fun channelFirstPage(url: String, shorts: Boolean): List<YtItem> {
        val channel = channel(url)
        val source = if (shorts) channel.shorts ?: return emptyList() else channel.videos
        return source().items.map { if (it.channel.isBlank()) it.copy(channel = channel.name, channelUrl = channel.url) else it }
    }

    /* ── Personal feeds, computed on the device from the local profile ── */

    /** Runs sources in order; each call to `next` advances to the following source. */
    private suspend fun chain(sources: List<suspend () -> FeedPage>, start: Int = 0): FeedPage {
        var failure: Throwable? = null
        for (index in start until sources.size) {
            val page = try { sources[index]() } catch (error: Throwable) { failure = error; null }
            if (page != null && page.items.isNotEmpty()) {
                val inner = page.next
                return FeedPage(page.items, when {
                    inner != null -> ({ chain(listOf(inner) + sources.drop(index + 1)) })
                    index + 1 < sources.size -> ({ chain(sources, index + 1) })
                    else -> null
                })
            }
        }
        failure?.let { throw it }
        return FeedPage(emptyList(), null)
    }

    /** Recommendations: related videos of what you watched, mixed with channels you follow. */
    suspend fun forYou(profile: LocalProfile): FeedPage {
        val seeds = profile.history.take(14).map { it.videoId }
        val follows = profile.following.keys.shuffled().take(8)
        val sources = mutableListOf<suspend () -> FeedPage>()
        val longest = maxOf(seeds.size, follows.size)
        for (i in 0 until longest) {
            seeds.getOrNull(i)?.let { seed ->
                sources += { FeedPage(io { StreamInfo.getInfo(service, seed) }.relatedItems.mapNotNull { it.toItem() }.filterNot { it.short }, null) }
            }
            follows.getOrNull(i)?.let { channelUrl ->
                sources += { FeedPage(channelFirstPage(channelUrl, shorts = false).take(8), null) }
            }
        }
        profile.recentSearches.take(3).forEach { query -> sources += { FeedPage(search(query).items, null) } }
        sources += { val ids = kiosks(); kiosk(ids.first()) }
        return chain(sources)
    }

    suspend fun subscriptions(profile: LocalProfile): FeedPage {
        val groups = profile.following.keys.toList().chunked(4)
        if (groups.isEmpty()) return FeedPage(emptyList(), null)
        val sources = groups.map { group ->
            suspend {
                val lists = coroutineScope {
                    group.map { url -> async { runCatching { channelFirstPage(url, shorts = false).take(6) }.getOrDefault(emptyList()) } }.awaitAll()
                }
                val merged = mutableListOf<YtItem>()
                for (row in 0 until 6) lists.forEach { list -> list.getOrNull(row)?.let(merged::add) }
                FeedPage(merged, null)
            }
        }
        return chain(sources)
    }

    /** Short-form feed: Shorts tabs of followed channels, then short-form search results. */
    suspend fun shorts(profile: LocalProfile): FeedPage {
        val sources = mutableListOf<suspend () -> FeedPage>()
        profile.following.keys.shuffled().take(6).forEach { url ->
            sources += { FeedPage(channelFirstPage(url, shorts = true), null) }
        }
        val topics = profile.recentSearches.take(3).map { "$it #shorts" } + "#shorts"
        topics.forEach { topic ->
            sources += {
                val page = search(topic)
                filterShorts(page)
            }
        }
        return chain(sources)
    }

    private fun filterShorts(page: FeedPage): FeedPage = FeedPage(
        page.items.filter { it.short || (it.durationSec in 1..61 && !it.live) },
        page.next?.let { next -> ({ filterShorts(next()) }) },
    )

    /* ── Watch page ───────────────────────────────────────────────────── */

    suspend fun stream(url: String): YtStream = io {
        val info = StreamInfo.getInfo(service, url)
        fun height(resolution: String?) = resolution?.substringBefore('p')?.filter(Char::isDigit)?.toIntOrNull() ?: 0
        val muxed = info.videoStreams.filter { it.isUrl }.map {
            YtFormat(it.itag, it.resolution.orEmpty(), it.format?.suffix ?: "mp4", it.codec.orEmpty(), it.content,
                it.itagItem?.contentLength?.takeIf { size -> size > 0 }, height(it.resolution), it.bitrate / 1000, false)
        }.sortedByDescending { it.height }
        val videoOnly = info.videoOnlyStreams.filter { it.isUrl }.map {
            YtFormat(it.itag, it.resolution.orEmpty(), it.format?.suffix ?: "mp4", it.codec.orEmpty(), it.content,
                it.itagItem?.contentLength?.takeIf { size -> size > 0 }, height(it.resolution), it.bitrate / 1000, true)
        }.sortedWith(compareByDescending<YtFormat> { it.height }.thenByDescending { it.bitrateKbps })
        val audio = info.audioStreams.filter { it.isUrl }.map {
            YtFormat(it.itag, "${it.averageBitrate.coerceAtLeast(0)} kbps", it.format?.suffix ?: "m4a", it.codec.orEmpty(), it.content,
                it.itagItem?.contentLength?.takeIf { size -> size > 0 }, 0, it.averageBitrate, false)
        }.sortedByDescending { it.bitrateKbps }
        YtStream(
            url = info.url,
            title = info.name.orEmpty(),
            description = info.description?.content.orEmpty(),
            channel = info.uploaderName.orEmpty(),
            channelUrl = info.uploaderUrl.orEmpty(),
            channelAvatar = info.uploaderAvatars.maxByOrNull { it.height }?.url.orEmpty(),
            subscribers = info.uploaderSubscriberCount,
            views = info.viewCount,
            likes = info.likeCount,
            uploaded = info.textualUploadDate.orEmpty(),
            durationSec = info.duration,
            thumbnail = info.thumbnails.maxByOrNull { it.height }?.url.orEmpty(),
            live = info.streamType == StreamType.LIVE_STREAM,
            hlsUrl = info.hlsUrl.orEmpty(),
            dashUrl = info.dashMpdUrl.orEmpty(),
            muxed = muxed,
            videoOnly = videoOnly,
            audio = audio,
            related = info.relatedItems.mapNotNull { it.toItem() },
        )
    }

    suspend fun comments(url: String): List<YtComment> = io {
        CommentsInfo.getInfo(service, url).relatedItems.map {
            YtComment(it.uploaderName.orEmpty(), it.commentText?.content.orEmpty(), it.likeCount, it.textualUploadDate.orEmpty())
        }
    }
}

/** OkHttp transport for the extractor. */
private object OkDownloader : Downloader() {
    private const val AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"

    override fun execute(request: Request): Response {
        val payload = request.dataToSend()
        val method = request.httpMethod()
        val body = when {
            payload != null -> payload.toRequestBody()
            method == "POST" || method == "PUT" -> ByteArray(0).toRequestBody()
            else -> null
        }
        val builder = okhttp3.Request.Builder().url(request.url()).method(method, body).header("User-Agent", AGENT)
        request.headers().forEach { (name, values) ->
            builder.removeHeader(name)
            values.forEach { builder.addHeader(name, it) }
        }
        NetworkClient.client.newCall(builder.build()).execute().use { response ->
            if (response.code == 429) throw ReCaptchaException("YouTube rate limit (HTTP 429)", request.url())
            return Response(
                response.code, response.message, response.headers.toMultimap(),
                response.body?.string(), response.request.url.toString(),
            )
        }
    }
}
