package com.auroraget.app.ui.screens

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import com.auroraget.app.data.ContentType
import com.auroraget.app.data.DownloadRequest
import com.auroraget.app.data.HistoryEntry
import com.auroraget.app.data.LocalProfile
import com.auroraget.app.data.LocalStore
import com.auroraget.app.data.formatBytes
import com.auroraget.app.engine.ExtractorEngine
import com.auroraget.app.engine.FeedPage
import com.auroraget.app.engine.YouTubeEngine
import com.auroraget.app.engine.YtChannel
import com.auroraget.app.engine.YtComment
import com.auroraget.app.engine.YtFormat
import com.auroraget.app.engine.YtItem
import com.auroraget.app.engine.YtStream
import com.auroraget.app.ui.components.AuroraButton
import com.auroraget.app.ui.components.AuroraSheet
import com.auroraget.app.ui.components.Glyph
import com.auroraget.app.ui.components.Ic
import com.auroraget.app.ui.components.tap
import com.auroraget.app.ui.theme.AuroraShapes
import com.auroraget.app.ui.theme.AuroraType
import com.auroraget.app.ui.theme.LocalAuroraColors
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.koin.core.context.GlobalContext
import java.util.Locale

private enum class YtTab(val ar: String, val en: String, val icon: Ic) {
    HOME("الرئيسية", "Home", Ic.HOME), SHORTS("Shorts", "Shorts", Ic.BOLT),
    SUBS("الاشتراكات", "Subscriptions", Ic.STACK), YOU("أنت", "You", Ic.USER)
}

private class PlaySource(val adaptive: Boolean, val resolve: suspend () -> MediaItem?)

/** Holds one paged list of real results. */
private class Feed {
    var items by mutableStateOf<List<YtItem>>(emptyList())
    var loading by mutableStateOf(false)
    var loadingMore by mutableStateOf(false)
    var error by mutableStateOf("")
    var hasMore by mutableStateOf(false)
    var stalled by mutableStateOf(false)
    private var next: (suspend () -> FeedPage)? = null
    private var generation = 0

    suspend fun load(source: suspend () -> FeedPage) {
        val mine = ++generation
        loading = true; error = ""; items = emptyList(); next = null; hasMore = false; stalled = false
        try {
            val page = source()
            if (mine == generation) { items = page.items.distinctBy { it.url }; next = page.next; hasMore = next != null }
        } catch (cancel: CancellationException) { throw cancel
        } catch (failure: Throwable) { if (mine == generation) error = friendly(failure)
        } finally { if (mine == generation) loading = false }
    }

    suspend fun more(force: Boolean = false) {
        val fetch = next ?: return
        if (loadingMore || loading || (stalled && !force)) return
        val mine = generation
        loadingMore = true; stalled = false
        try {
            val page = fetch()
            if (mine == generation) { items = (items + page.items).distinctBy { it.url }; next = page.next; hasMore = next != null }
        } catch (cancel: CancellationException) { throw cancel
        } catch (failure: Throwable) { if (mine == generation) stalled = true
        } finally { loadingMore = false }
    }
}

private fun friendly(error: Throwable): String = when (error) {
    is java.net.UnknownHostException, is java.net.ConnectException, is java.net.SocketTimeoutException ->
        "لا يوجد اتصال بالإنترنت. تصفح يوتيوب يحتاج شبكة، وبقية التطبيق يعمل بدونها."
    is org.schabi.newpipe.extractor.exceptions.SignInConfirmNotBotException ->
        "يوتيوب حظر المشاهدة المجهولة مؤقتًا من عنوان الشبكة هذا. جرّب شبكة أخرى (بيانات الهاتف مثلًا) أو أوقف VPN ثم أعد المحاولة."
    is org.schabi.newpipe.extractor.exceptions.ReCaptchaException -> "يوتيوب يحدّ الطلبات مؤقتًا من هذه الشبكة (429). حاول بعد قليل."
    is org.schabi.newpipe.extractor.exceptions.ContentNotAvailableException -> "هذا المحتوى غير متاح: ${error.message.orEmpty()}"
    else -> error.message?.take(180) ?: error.javaClass.simpleName
}

private fun count(value: Long, arabic: Boolean): String = when {
    value < 0 -> ""
    value >= 1_000_000_000 -> String.format(Locale.US, "%.1f", value / 1e9) + if (arabic) " مليار" else "B"
    value >= 1_000_000 -> String.format(Locale.US, "%.1f", value / 1e6) + if (arabic) " مليون" else "M"
    value >= 1_000 -> String.format(Locale.US, "%.1f", value / 1e3) + if (arabic) " ألف" else "K"
    else -> value.toString()
}

private fun durationLabel(seconds: Long): String = if (seconds <= 0) "" else clock(seconds * 1000)

@Composable
fun YtLogo(width: Dp = 30.dp) {
    Canvas(Modifier.size(width, width * 0.7f)) {
        drawRoundRect(Color(0xFFFF0033), cornerRadius = CornerRadius(size.height * .28f))
        val play = Path().apply {
            moveTo(size.width * .4f, size.height * .27f); lineTo(size.width * .69f, size.height * .5f)
            lineTo(size.width * .4f, size.height * .73f); close()
        }
        drawPath(play, Color.White)
    }
}

@Composable
private fun Spinner(size: Dp = 34.dp, color: Color = Color.White) {
    val turn by rememberInfiniteTransition(label = "spin").animateFloat(0f, 360f,
        infiniteRepeatable(tween(850, easing = LinearEasing)), label = "angle")
    Canvas(Modifier.size(size)) {
        drawArc(color, turn, 270f, false, style = Stroke(this.size.width * .1f, cap = StrokeCap.Round))
    }
}

@Composable
private fun Pill(icon: Ic?, label: String, active: Boolean = false, onClick: () -> Unit) {
    val c = LocalAuroraColors.current
    Row(
        Modifier.clip(AuroraShapes.chip).background(if (active) c.accentSoft else c.glassStrong)
            .border(1.dp, if (active) c.accent2.copy(alpha = .5f) else c.line, AuroraShapes.chip)
            .tap(onClick = onClick).padding(horizontal = 13.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) { Glyph(icon, if (active) c.accent2 else c.textPrimary, size = 15.dp); Spacer(Modifier.width(6.dp)) }
        Txt(label, style = AuroraType.label, color = if (active) c.accent2 else c.textPrimary, maxLines = 1)
    }
}

@Composable
private fun Avatar(url: String, name: String, size: Dp) {
    val c = LocalAuroraColors.current
    Box(Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(c.accents)), contentAlignment = Alignment.Center) {
        Txt(name.trim().take(1).uppercase(), style = AuroraType.label.copy(fontSize = (size.value * .42f).sp), color = Color.White)
        if (url.isNotBlank()) AsyncImage(model = url, contentDescription = name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
    }
}

@Composable
private fun Thumb(item: YtItem, modifier: Modifier) {
    val c = LocalAuroraColors.current
    Box(modifier.clip(RoundedCornerShape(14.dp)).background(c.glassStrong)) {
        AsyncImage(model = item.thumbnail, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        val badge = if (item.live) "مباشر" else durationLabel(item.durationSec)
        if (badge.isNotBlank()) Box(
            Modifier.align(Alignment.BottomEnd).padding(6.dp).clip(RoundedCornerShape(5.dp))
                .background(if (item.live) Color(0xFFE5173F) else Color.Black.copy(alpha = .78f)).padding(horizontal = 5.dp, vertical = 2.dp)
        ) { Txt(badge, style = AuroraType.caption.copy(fontWeight = FontWeight.SemiBold), color = Color.White) }
    }
}

private fun meta(item: YtItem, arabic: Boolean): String = listOf(
    item.channel, count(item.views, arabic).takeIf { it.isNotBlank() }?.let { "$it ${if (arabic) "مشاهدة" else "views"}" }.orEmpty(), item.uploaded,
).filter { it.isNotBlank() }.joinToString(" · ")

@Composable
private fun VideoCard(item: YtItem, arabic: Boolean, onOpen: () -> Unit, onChannel: () -> Unit, onMore: () -> Unit) {
    val c = LocalAuroraColors.current
    Column(Modifier.fillMaxWidth().tap(onClick = onOpen)) {
        Thumb(item, Modifier.fillMaxWidth().aspectRatio(16f / 9f))
        Row(Modifier.padding(top = 9.dp, bottom = 4.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.tap(onClick = onChannel)) { Avatar("", item.channel, 36.dp) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Txt(item.title, style = AuroraType.label.copy(fontSize = 13.5.sp, lineHeight = 19.sp), maxLines = 2)
                Spacer(Modifier.height(2.dp))
                Txt(meta(item, arabic), style = AuroraType.caption, color = c.textSecondary, maxLines = 2)
            }
            Box(Modifier.size(34.dp).tap(onClick = onMore), contentAlignment = Alignment.Center) { Glyph(Ic.MORE, c.textSecondary, size = 18.dp) }
        }
    }
}

@Composable
private fun VideoRow(item: YtItem, arabic: Boolean, onOpen: () -> Unit, onMore: (() -> Unit)? = null) {
    val c = LocalAuroraColors.current
    Row(Modifier.fillMaxWidth().tap(onClick = onOpen), verticalAlignment = Alignment.Top) {
        Thumb(item, Modifier.width(158.dp).aspectRatio(16f / 9f))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Txt(item.title, style = AuroraType.label.copy(lineHeight = 17.sp), maxLines = 3)
            Spacer(Modifier.height(3.dp))
            Txt(meta(item, arabic), style = AuroraType.caption, color = c.textSecondary, maxLines = 2)
        }
        if (onMore != null) Box(Modifier.size(30.dp).tap(onClick = onMore), contentAlignment = Alignment.Center) { Glyph(Ic.MORE, c.textSecondary, size = 16.dp) }
    }
}

private fun entryOf(item: YtItem, position: Long = 0) =
    HistoryEntry(item.url, item.title, item.channelUrl, item.channel, item.thumbnail, positionMs = position)

private fun HistoryEntry.asItem() = YtItem(videoId, title, channelTitle, channelId, thumbnail, 0, -1, "", false, false)

private fun safeName(title: String) = title.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), " ").trim().take(80).ifBlank { "video" }

/**
 * A native YouTube client: feeds, search with live suggestions, Shorts, channels,
 * local subscriptions and a Media3 player. No WebView, no API key, no Google login.
 */
@Composable
fun YouTubeScreen(
    arabic: Boolean,
    onExit: () -> Unit,
    onDownload: suspend (DownloadRequest) -> Result<String>,
) {
    val c = LocalAuroraColors.current
    val context = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val koin = remember { GlobalContext.get() }
    val store = remember { koin.get<LocalStore>() }
    val engine = remember { koin.get<YouTubeEngine>() }
    val ytdlp = remember { koin.get<ExtractorEngine>() }
    val local by store.state.collectAsState()
    val profile = local.profile
    val controller = rememberPlaybackController()
    fun tr(ar: String, en: String) = if (arabic) ar else en

    var tab by remember { mutableStateOf(YtTab.HOME) }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }
    var remote by remember { mutableStateOf<List<String>>(emptyList()) }
    var kiosks by remember { mutableStateOf<List<String>>(emptyList()) }
    var kiosk by remember { mutableStateOf<String?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    val feed = remember { Feed() }
    val shortsFeed = remember { Feed() }
    val channelFeed = remember { Feed() }
    var channelUrl by remember { mutableStateOf<String?>(null) }
    var channel by remember { mutableStateOf<YtChannel?>(null) }
    var channelShorts by remember { mutableStateOf(false) }
    var channelError by remember { mutableStateOf("") }
    var toast by remember { mutableStateOf("") }
    var menuFor by remember { mutableStateOf<YtItem?>(null) }

    // Player state
    var nowItem by remember { mutableStateOf<YtItem?>(null) }
    var details by remember { mutableStateOf<YtStream?>(null) }
    var playError by remember { mutableStateOf("") }
    var streamIssue by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var shortsMode by remember { mutableStateOf(false) }
    var sources by remember { mutableStateOf<List<PlaySource>>(emptyList()) }
    var sourceIndex by remember { mutableIntStateOf(0) }
    var openJob by remember { mutableStateOf<Job?>(null) }
    var playing by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var bufferedTo by remember { mutableLongStateOf(0L) }
    var maxHeight by remember { mutableIntStateOf(0) }
    var speed by remember { mutableFloatStateOf(1f) }
    var audioOnly by remember { mutableStateOf(false) }
    var repeatOne by remember { mutableStateOf(false) }
    var autoplay by remember { mutableStateOf(true) }
    var fullscreen by remember { mutableStateOf(false) }
    var inPip by remember { mutableStateOf(false) }
    var controls by remember { mutableStateOf(true) }
    var controlsStamp by remember { mutableLongStateOf(0L) }
    var sleepEnd by remember { mutableLongStateOf(0L) }
    var sleepJob by remember { mutableStateOf<Job?>(null) }
    var sheet by remember { mutableStateOf("") } // "", "download", "quality"
    var descriptionOpen by remember { mutableStateOf(false) }
    var comments by remember { mutableStateOf<List<YtComment>?>(null) }
    var commentsLoading by remember { mutableStateOf(false) }

    suspend fun editProfile(change: (LocalProfile) -> LocalProfile) { store.update { it.copy(profile = change(it.profile)) } }
    fun say(text: String) { toast = text }

    fun copyLink(url: String) {
        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("YouTube", url))
        say(tr("نُسخ رابط الفيديو", "Video link copied"))
    }
    fun share(url: String) {
        runCatching { context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url), null)) }
    }
    fun toggleFollow(url: String, name: String) = scope.launch {
        if (url.isBlank()) return@launch
        editProfile { p -> p.copy(following = if (url in p.following) p.following - url else p.following + (url to name)) }
    }
    fun toggleSaved(item: YtItem) = scope.launch {
        editProfile { p -> p.copy(watchLaterItems = if (p.watchLaterItems.any { it.videoId == item.url }) p.watchLaterItems.filterNot { it.videoId == item.url } else listOf(entryOf(item)) + p.watchLaterItems) }
    }
    fun toggleLiked(item: YtItem) = scope.launch {
        editProfile { p -> p.copy(likedItems = if (p.likedItems.any { it.videoId == item.url }) p.likedItems.filterNot { it.videoId == item.url } else listOf(entryOf(item)) + p.likedItems) }
    }

    fun buildSources(d: YtStream): List<PlaySource> = buildList {
        val art = d.thumbnail.takeIf { it.isNotBlank() }?.let(Uri::parse)
        if (d.hlsUrl.isNotBlank()) add(PlaySource(true) { playableItem(Uri.parse(d.hlsUrl), d.title, d.channel, art, mime = MimeTypes.APPLICATION_M3U8, id = d.url) })
        if (d.dashUrl.isNotBlank()) add(PlaySource(true) { playableItem(Uri.parse(d.dashUrl), d.title, d.channel, art, mime = MimeTypes.APPLICATION_MPD, id = d.url) })
        val cap = if (maxHeight > 0) maxHeight else 1080
        val fitting = d.videoOnly.filter { it.height in 1..cap }
        val top = fitting.maxOfOrNull { it.height }
        val video = fitting.filter { it.height == top }.let { same -> same.firstOrNull { it.codec.startsWith("avc") } ?: same.firstOrNull { it.codec.startsWith("vp") } ?: same.firstOrNull() }
        val sound = d.audio.firstOrNull { it.container == "m4a" } ?: d.audio.firstOrNull()
        if (video != null && sound != null) add(PlaySource(false) { playableItem(Uri.parse(video.url), d.title, d.channel, art, separateAudio = sound.url, id = d.url) })
        (d.muxed.firstOrNull { it.height <= cap } ?: d.muxed.lastOrNull())?.let { muxed ->
            add(PlaySource(false) { playableItem(Uri.parse(muxed.url), d.title, d.channel, art, id = d.url) })
        }
        if (sound != null) add(PlaySource(false) { playableItem(Uri.parse(sound.url), d.title, d.channel, art, id = d.url) })
        add(PlaySource(false) {
            val direct = withContext(Dispatchers.IO) { runCatching { ytdlp.playableUrls(d.url, cap) }.getOrDefault(emptyList()) }.firstOrNull()
            direct?.let { playableItem(Uri.parse(it), d.title, d.channel, art, mime = if (".m3u8" in it) MimeTypes.APPLICATION_M3U8 else null, id = d.url) }
        })
    }

    suspend fun playFrom(start: Int, at: Long) {
        val player = controller ?: return
        var index = start
        while (index < sources.size) {
            val item = runCatching { sources[index].resolve() }.getOrNull()
            if (item != null) {
                sourceIndex = index
                player.setMediaItem(item, at.coerceAtLeast(0L))
                player.repeatMode = if (repeatOne || shortsMode) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                player.setPlaybackSpeed(speed)
                player.prepare(); player.play()
                return
            }
            index++
        }
        playError = tr("تعذر تشغيل هذا الفيديو من كل المصادر المتاحة حاليًا.", "No playable source is available right now.") +
            if (streamIssue.isNotBlank()) "\n$streamIssue" else ""
    }

    fun rememberPosition() {
        val item = nowItem ?: return
        val at = controller?.currentPosition ?: return
        val total = controller?.duration ?: 0L
        if (shortsMode || at < 5_000) return
        val keep = if (total > 0 && at > total - 10_000) 0L else at
        scope.launch { editProfile { p -> p.copy(history = p.history.map { if (it.videoId == item.url) it.copy(positionMs = keep) else it }) } }
    }

    fun open(item: YtItem, asShort: Boolean = false) {
        rememberPosition()
        openJob?.cancel()
        nowItem = item; details = null; playError = ""; comments = null; descriptionOpen = false
        shortsMode = asShort; expanded = !asShort; controls = true; position = 0; duration = 0; bufferedTo = 0
        controller?.let { it.stop(); it.clearMediaItems() }
        openJob = scope.launch {
            val resume = if (asShort) 0L else store.state.value.profile.history.firstOrNull { it.videoId == item.url }?.positionMs ?: 0L
            editProfile { p -> p.copy(history = (listOf(entryOf(item, resume)) + p.history.filterNot { it.videoId == item.url }).take(400)) }
            val loaded = runCatching { engine.stream(item.url) }
            streamIssue = loaded.exceptionOrNull()?.takeIf { it !is CancellationException }?.let(::friendly).orEmpty()
            val d = loaded.getOrElse {
                if (it is CancellationException) throw it
                // The page parser failed: keep going with yt-dlp so playback still works.
                YtStream(item.url, item.title, "", item.channel, item.channelUrl, "", -1, item.views, -1, item.uploaded,
                    item.durationSec, item.thumbnail, item.live, "", "", emptyList(), emptyList(), emptyList(), emptyList())
            }
            details = d
            sources = buildSources(d)
            playFrom(0, resume)
        }
    }

    fun close() {
        rememberPosition()
        openJob?.cancel()
        controller?.let { it.stop(); it.clearMediaItems() }
        nowItem = null; details = null; expanded = false; fullscreen = false; shortsMode = false
    }

    fun applyQuality(height: Int) {
        maxHeight = height
        val player = controller ?: return
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setMaxVideoSize(Int.MAX_VALUE, if (height > 0) height else Int.MAX_VALUE).build()
        val d = details ?: return
        if (sources.getOrNull(sourceIndex)?.adaptive != true) {
            val at = player.currentPosition
            sources = buildSources(d)
            scope.launch { playFrom(0, at) }
        }
    }

    // Player events
    DisposableEffect(controller) {
        val player = controller ?: return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_ENDED && !shortsMode && !repeatOne && autoplay) {
                    details?.related?.firstOrNull { !it.short && it.url != nowItem?.url }?.let { open(it) }
                }
            }
            override fun onPlayerError(error: PlaybackException) {
                val at = player.currentPosition
                scope.launch { playFrom(sourceIndex + 1, at) }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            if (!audioOnly || shortsMode) player.pause()
        }
    }
    LaunchedEffect(controller) {
        while (true) {
            controller?.let {
                position = it.currentPosition.coerceAtLeast(0L)
                duration = it.duration.takeIf { d -> d > 0 } ?: 0L
                bufferedTo = it.bufferedPosition
            }
            delay(300L)
        }
    }
    LaunchedEffect(controls, controlsStamp, playing) { if (controls && playing) { delay(3500); controls = false } }
    LaunchedEffect(toast) { if (toast.isNotBlank()) { delay(2600); toast = "" } }

    // Fullscreen + picture-in-picture
    DisposableEffect(fullscreen) {
        val activity = context as? Activity
        val insets = activity?.let { WindowCompat.getInsetsController(it.window, view) }
        if (fullscreen) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            insets?.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            insets?.show(WindowInsetsCompat.Type.systemBars())
        }
    }
    DisposableEffect(Unit) {
        val activity = context as? ComponentActivity
        val listener = androidx.core.util.Consumer<androidx.core.app.PictureInPictureModeChangedInfo> { inPip = it.isInPictureInPictureMode }
        activity?.addOnPictureInPictureModeChangedListener(listener)
        onDispose { activity?.removeOnPictureInPictureModeChangedListener(listener) }
    }

    // Feeds
    LaunchedEffect(Unit) { kiosks = runCatching { engine.kiosks() }.getOrDefault(emptyList()) }
    LaunchedEffect(tab, query, kiosk, refresh) {
        when (tab) {
            YtTab.HOME -> feed.load {
                val q = query; val k = kiosk
                when { q.isNotBlank() -> engine.search(q); k != null -> engine.kiosk(k); else -> engine.forYou(store.state.value.profile) }
            }
            YtTab.SUBS -> feed.load { engine.subscriptions(store.state.value.profile) }
            YtTab.SHORTS -> if (shortsFeed.items.isEmpty()) shortsFeed.load { engine.shorts(store.state.value.profile) }
            YtTab.YOU -> Unit
        }
    }
    LaunchedEffect(tab) { if (tab != YtTab.SHORTS && shortsMode) close() }
    LaunchedEffect(channelUrl, channelShorts) {
        val url = channelUrl ?: run { channel = null; return@LaunchedEffect }
        channelError = ""
        val info = channel ?: runCatching { engine.channel(url) }.onFailure { channelError = friendly(it) }.getOrNull()
        channel = info
        if (info != null) channelFeed.load { (if (channelShorts) info.shorts ?: info.videos else info.videos)() }
    }
    LaunchedEffect(typed, searching) {
        if (!searching) return@LaunchedEffect
        delay(180)
        remote = runCatching { engine.suggest(typed.trim()) }.getOrDefault(emptyList())
    }

    fun submit(text: String) {
        val value = text.trim()
        if (value.isBlank()) return
        searching = false; typed = value; query = value; kiosk = null; tab = YtTab.HOME; channelUrl = null
        scope.launch { editProfile { p -> p.copy(recentSearches = (listOf(value) + p.recentSearches.filterNot { it == value }).take(30)) } }
    }

    BackHandler {
        when {
            fullscreen -> fullscreen = false
            sheet.isNotBlank() -> sheet = ""
            menuFor != null -> menuFor = null
            expanded -> expanded = false
            searching -> searching = false
            channelUrl != null -> channelUrl = null
            query.isNotBlank() -> { query = ""; typed = "" }
            tab != YtTab.HOME -> tab = YtTab.HOME
            else -> onExit()
        }
    }

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch { runCatching { store.exportProfile(uri) }.onSuccess { say(tr("تم تصدير ملفك الشخصي", "Profile exported")) }.onFailure { say(it.message.orEmpty()) } }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { runCatching { store.importProfile(uri) }.onSuccess { say(tr("تم الاستيراد", "Profile imported")); refresh++ }.onFailure { say(tr("ملف غير صالح", "Invalid file")) } }
    }

    /* ── Player surface with YouTube-style controls ─────────────────────── */
    @Composable
    fun PlayerBox(modifier: Modifier, mini: Boolean = false) {
        Box(modifier.background(Color.Black), contentAlignment = Alignment.Center) {
            val item = nowItem
            if (audioOnly && item != null) {
                AsyncImage(model = item.thumbnail, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)))
                if (!mini) PulseBars(playing, Modifier.fillMaxWidth(.7f).height(64.dp))
            } else {
                AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
                    PlayerView(ctx).apply { useController = false; player = controller; setKeepContentOnPlayerReset(true) }
                }, update = { it.player = controller })
            }
            if (playError.isNotBlank() && !mini) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(18.dp)) {
                    Txt(playError, style = AuroraType.label, color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    AuroraButton(tr("إعادة المحاولة", "Retry")) { nowItem?.let { open(it) } }
                }
            } else if (details == null || buffering) Spinner(if (mini) 20.dp else 38.dp)
            if (mini) { Box(Modifier.fillMaxSize().tap { expanded = true }); return@Box }
            if (inPip) return@Box

            Box(Modifier.fillMaxSize().pointerInput(controller) {
                detectTapGestures(
                    onDoubleTap = { at ->
                        val player = controller ?: return@detectTapGestures
                        val forward = at.x > size.width / 2
                        player.seekTo((player.currentPosition + if (forward) 10_000 else -10_000).coerceAtLeast(0))
                        say(if (forward) "+10" else "−10")
                    },
                    onTap = { controls = !controls; controlsStamp = SystemClock.elapsedRealtime() },
                )
            })
            androidx.compose.animation.AnimatedVisibility(visible = controls, enter = fadeIn(), exit = fadeOut()) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .42f))) {
                    Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).tap { if (fullscreen) fullscreen = false else expanded = false }, contentAlignment = Alignment.Center) { Glyph(Ic.DOWN, Color.White) }
                        Spacer(Modifier.weight(1f))
                        Box(Modifier.clip(AuroraShapes.chip).tap { sheet = "quality" }.padding(horizontal = 10.dp, vertical = 7.dp)) {
                            Txt(if (maxHeight > 0) "${maxHeight}p" else tr("تلقائي", "Auto"), style = AuroraType.label, color = Color.White)
                        }
                        Box(Modifier.clip(AuroraShapes.chip).tap {
                            val speeds = listOf(.5f, .75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
                            speed = speeds[(speeds.indexOf(speed) + 1) % speeds.size]; controller?.setPlaybackSpeed(speed)
                            controlsStamp = SystemClock.elapsedRealtime()
                        }.padding(horizontal = 10.dp, vertical = 7.dp)) { Txt("${speed}x", style = AuroraType.label, color = Color.White) }
                        Box(Modifier.size(38.dp).tap {
                            audioOnly = !audioOnly
                            controller?.let { it.trackSelectionParameters = it.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, audioOnly).build() }
                            say(if (audioOnly) tr("وضع الأغنية: يستمر الصوت في الخلفية", "Song mode: audio keeps playing in background") else tr("عاد الفيديو", "Video restored"))
                        }, contentAlignment = Alignment.Center) { Glyph(Ic.MUSIC, if (audioOnly) c.accent2 else Color.White) }
                        Box(Modifier.size(38.dp).tap {
                            if (Build.VERSION.SDK_INT >= 26) runCatching {
                                (context as? Activity)?.enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
                            }
                        }, contentAlignment = Alignment.Center) { Glyph(Ic.PIP, Color.White) }
                    }
                    Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(34.dp)) {
                        Box(Modifier.size(46.dp).tap { controller?.let { it.seekTo((it.currentPosition - 10_000).coerceAtLeast(0)) }; controlsStamp = SystemClock.elapsedRealtime() },
                            contentAlignment = Alignment.Center) { Glyph(Ic.PREV, Color.White, size = 24.dp) }
                        Box(Modifier.size(62.dp).clip(CircleShape).background(Color.Black.copy(alpha = .45f)).tap {
                            controller?.let { if (it.isPlaying) it.pause() else { if (it.playbackState == Player.STATE_ENDED) it.seekTo(0); it.play() } }
                            controlsStamp = SystemClock.elapsedRealtime()
                        }, contentAlignment = Alignment.Center) { Glyph(if (playing) Ic.PAUSE else Ic.PLAY, Color.White, size = 28.dp) }
                        Box(Modifier.size(46.dp).tap { controller?.let { it.seekTo(it.currentPosition + 10_000) }; controlsStamp = SystemClock.elapsedRealtime() },
                            contentAlignment = Alignment.Center) { Glyph(Ic.NEXT, Color.White, size = 24.dp) }
                    }
                    Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Txt("${clock(position)} / ${clock(duration)}", style = AuroraType.mono, color = Color.White)
                        Spacer(Modifier.width(8.dp))
                        SeekLine(if (duration > 0) position.toFloat() / duration else 0f, modifier = Modifier.weight(1f),
                            buffered = if (duration > 0) bufferedTo.toFloat() / duration else 0f,
                            onSeek = { controller?.seekTo((duration * it).toLong()); controlsStamp = SystemClock.elapsedRealtime() })
                        Spacer(Modifier.width(4.dp))
                        Box(Modifier.size(38.dp).tap { fullscreen = !fullscreen }, contentAlignment = Alignment.Center) { Glyph(Ic.FULLSCREEN, Color.White) }
                    }
                }
            }
        }
    }

    @Composable
    fun FeedList(source: Feed, header: @Composable () -> Unit, emptyText: String, rows: Boolean = false, top: Dp = 0.dp) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = top, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(if (rows) 12.dp else 18.dp)) {
            item { header() }
            if (source.loading) items(4) {
                Column { Box(Modifier.fillMaxWidth().aspectRatio(if (rows) 3.4f else 16f / 9f).clip(RoundedCornerShape(14.dp)).background(c.glassStrong))
                    Spacer(Modifier.height(8.dp)); Box(Modifier.fillMaxWidth(.7f).height(12.dp).clip(AuroraShapes.chip).background(c.glassStrong)) }
            }
            if (source.error.isNotBlank()) item {
                Column(Modifier.fillMaxWidth().padding(vertical = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Txt(source.error, style = AuroraType.body, color = c.textSecondary)
                    Spacer(Modifier.height(10.dp))
                    AuroraButton(tr("إعادة المحاولة", "Retry"), primary = false) { refresh++ }
                }
            }
            if (!source.loading && source.error.isBlank() && source.items.isEmpty()) item {
                Txt(emptyText, style = AuroraType.body, color = c.textSecondary, modifier = Modifier.padding(vertical = 30.dp))
            }
            items(source.items, key = { it.url }) { item ->
                if (rows) VideoRow(item, arabic, onOpen = { open(item) }, onMore = { menuFor = item })
                else VideoCard(item, arabic, onOpen = { open(item) }, onChannel = { if (item.channelUrl.isNotBlank()) { channelShorts = false; channel = null; channelUrl = item.channelUrl } }, onMore = { menuFor = item })
            }
            if (source.hasMore) item {
                LaunchedEffect(source.items.size) { source.more() }
                Box(Modifier.fillMaxWidth().padding(14.dp), contentAlignment = Alignment.Center) {
                    if (source.stalled) AuroraButton(tr("تحميل المزيد", "Load more"), primary = false) { scope.launch { source.more(force = true) } }
                    else Spinner(24.dp, c.accent2)
                }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(c.background)) {
        if ((fullscreen || inPip) && nowItem != null && !shortsMode) { PlayerBox(Modifier.fillMaxSize()); return@Box }

        Column(Modifier.fillMaxSize()) {
            // Top bar
            if (tab != YtTab.SHORTS) Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                YtLogo(32.dp); Spacer(Modifier.width(7.dp))
                Txt("YouTube", style = AuroraType.brand.copy(fontSize = 20.sp, letterSpacing = (-0.6).sp))
                Spacer(Modifier.weight(1f))
                Box(Modifier.size(40.dp).tap { typed = query; searching = true }, contentAlignment = Alignment.Center) { Glyph(Ic.SEARCH, c.textPrimary) }
                Box(Modifier.size(40.dp).tap(onClick = onExit), contentAlignment = Alignment.Center) { Glyph(Ic.CLOSE, c.textSecondary) }
            }
            Box(Modifier.weight(1f)) {
                when (tab) {
                    YtTab.HOME -> FeedList(feed, emptyText = tr("لا توجد نتائج.", "No results."), rows = query.isNotBlank(), header = {
                        if (query.isNotBlank()) Row(verticalAlignment = Alignment.CenterVertically) {
                            Txt(tr("نتائج: ", "Results: ") + query, style = AuroraType.heading, modifier = Modifier.weight(1f), maxLines = 1)
                            Pill(Ic.CLOSE, tr("مسح", "Clear")) { query = ""; typed = "" }
                        } else LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            item { Pill(null, tr("لك", "For you"), active = kiosk == null) { kiosk = null } }
                            items(kiosks) { id -> Pill(null, kioskLabel(id, arabic), active = kiosk == id) { kiosk = id } }
                        }
                    })
                    YtTab.SUBS -> FeedList(feed, emptyText = if (profile.following.isEmpty()) tr("لم تشترك في أي قناة بعد. افتح فيديو واضغط «اشتراك» — الاشتراكات محفوظة على جهازك فقط.", "No subscriptions yet. They are stored only on this device.") else tr("لا جديد.", "Nothing new."), header = {
                        if (profile.following.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(profile.following.toList()) { (url, name) ->
                                Column(Modifier.width(64.dp).tap { channelShorts = false; channel = null; channelUrl = url }, horizontalAlignment = Alignment.CenterHorizontally) {
                                    Avatar("", name, 52.dp); Spacer(Modifier.height(4.dp))
                                    Txt(name, style = AuroraType.caption, color = c.textSecondary, maxLines = 1)
                                }
                            }
                        }
                    })
                    YtTab.SHORTS -> {
                        val pager = rememberPagerState(pageCount = { shortsFeed.items.size })
                        LaunchedEffect(pager.settledPage, shortsFeed.items.size) {
                            val item = shortsFeed.items.getOrNull(pager.settledPage) ?: return@LaunchedEffect
                            if (nowItem?.url != item.url || !shortsMode) open(item, asShort = true)
                            if (pager.settledPage >= shortsFeed.items.size - 3) shortsFeed.more()
                        }
                        if (shortsFeed.items.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            if (shortsFeed.loading) Spinner(34.dp, c.accent2)
                            else Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                                Txt(shortsFeed.error.ifBlank { tr("لا مقاطع قصيرة متاحة الآن.", "No Shorts available right now.") }, style = AuroraType.body, color = c.textSecondary)
                                Spacer(Modifier.height(10.dp))
                                AuroraButton(tr("إعادة المحاولة", "Retry"), primary = false) { scope.launch { shortsFeed.load { engine.shorts(store.state.value.profile) } } }
                            }
                        } else VerticalPager(state = pager, modifier = Modifier.fillMaxSize(), key = { shortsFeed.items[it].url }) { page ->
                            val item = shortsFeed.items[page]
                            val active = pager.settledPage == page && nowItem?.url == item.url
                            Box(Modifier.fillMaxSize().background(Color.Black)) {
                                AsyncImage(model = item.thumbnail, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                                if (active) AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
                                    PlayerView(ctx).apply { useController = false; resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM; player = controller }
                                }, update = { it.player = controller })
                                Box(Modifier.fillMaxSize().tap { controller?.let { if (it.isPlaying) it.pause() else it.play() } })
                                if (active && (details == null || buffering)) Box(Modifier.align(Alignment.Center)) { Spinner() }
                                if (active && !playing && details != null && !buffering) Box(Modifier.align(Alignment.Center).size(70.dp).clip(CircleShape).background(Color.Black.copy(alpha = .45f)), contentAlignment = Alignment.Center) { Glyph(Ic.PLAY, Color.White, size = 30.dp) }
                                Box(Modifier.fillMaxWidth().height(210.dp).align(Alignment.BottomCenter).background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .8f)))))
                                Column(Modifier.align(Alignment.BottomStart).padding(start = 14.dp, end = 76.dp, bottom = 18.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.tap { if (item.channelUrl.isNotBlank()) { channelShorts = true; channel = null; channelUrl = item.channelUrl } }) {
                                        Avatar("", item.channel, 32.dp); Spacer(Modifier.width(8.dp))
                                        Txt(item.channel, style = AuroraType.label, color = Color.White, maxLines = 1)
                                    }
                                    Spacer(Modifier.height(7.dp))
                                    Txt(item.title, style = AuroraType.label, color = Color.White, maxLines = 2)
                                }
                                Column(Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    val liked = profile.likedItems.any { it.videoId == item.url }
                                    ShortAction(Ic.HEART, tr("أعجبني", "Like"), liked) { toggleLiked(item) }
                                    ShortAction(Ic.DOWNLOAD, tr("تحميل", "Save"), false) { if (details != null) sheet = "download" }
                                    ShortAction(Ic.COPY, tr("نسخ", "Copy"), false) { copyLink(item.url) }
                                    ShortAction(Ic.SHARE, tr("مشاركة", "Share"), false) { share(item.url) }
                                }
                                if (active && duration > 0) Box(Modifier.align(Alignment.BottomStart).fillMaxWidth(position.toFloat() / duration).height(2.dp).background(Color.White))
                            }
                        }
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Txt("Shorts", style = AuroraType.heading, color = Color.White); Spacer(Modifier.weight(1f))
                            Box(Modifier.size(40.dp).tap { typed = ""; searching = true }, contentAlignment = Alignment.Center) { Glyph(Ic.SEARCH, Color.White) }
                        }
                    }
                    YtTab.YOU -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        item {
                            var name by remember(profile.displayName) { mutableStateOf(profile.displayName) }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Avatar("", profile.displayName, 62.dp); Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    BasicTextField(name, { name = it.take(40) }, singleLine = true, textStyle = AuroraType.title.copy(color = c.textPrimary), cursorBrush = SolidColor(c.accent2),
                                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                        keyboardActions = KeyboardActions(onDone = { scope.launch { editProfile { it.copy(displayName = name.trim().ifBlank { "ملفي الشخصي" }) } }; say(tr("حُفظ الاسم", "Name saved")) }))
                                    Txt(tr("ملف محلي على جهازك · بلا تسجيل دخول", "Local profile · no sign-in"), style = AuroraType.caption, color = c.textSecondary)
                                }
                            }
                        }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Pill(Ic.DOWNLOAD, tr("تصدير", "Export")) { exporter.launch("jo-don-profile.json") }
                                Pill(Ic.FOLDER, tr("استيراد", "Import")) { importer.launch(arrayOf("application/json", "*/*")) }
                                Pill(Ic.CLOSE, tr("مسح السجل", "Clear history")) { scope.launch { editProfile { it.copy(history = emptyList(), recentSearches = emptyList()) } } }
                            }
                        }
                        fun section(title: String, list: List<HistoryEntry>, emptyHint: String) {
                            item { Txt("$title (${list.size})", style = AuroraType.heading) }
                            if (list.isEmpty()) item { Txt(emptyHint, style = AuroraType.caption, color = c.textSecondary) }
                            else item {
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    items(list.take(40), key = { it.videoId }) { entry ->
                                        Column(Modifier.width(168.dp).tap { open(entry.asItem()) }) {
                                            Thumb(entry.asItem(), Modifier.fillMaxWidth().aspectRatio(16f / 9f))
                                            Spacer(Modifier.height(5.dp))
                                            Txt(entry.title, style = AuroraType.caption.copy(fontSize = 11.sp), maxLines = 2)
                                            Txt(entry.channelTitle, style = AuroraType.caption, color = c.textTertiary, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                        section(tr("السجل", "History"), profile.history, tr("ما تشاهده يظهر هنا ويغذّي اقتراحاتك محليًا.", "What you watch appears here and feeds local recommendations."))
                        section(tr("للمشاهدة لاحقًا", "Watch later"), profile.watchLaterItems, tr("احفظ فيديو من قائمة ⋯", "Save a video from the ⋯ menu."))
                        section(tr("فيديوهات أعجبتني", "Liked videos"), profile.likedItems, tr("إعجاباتك محلية ولا تُرسل إلى يوتيوب.", "Likes stay on this device."))
                        item { Txt(tr("الاشتراكات", "Subscriptions") + " (${profile.following.size})", style = AuroraType.heading) }
                        items(profile.following.toList(), key = { it.first }) { (url, name) ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().tap { channelShorts = false; channel = null; channelUrl = url }) {
                                Avatar("", name, 38.dp); Spacer(Modifier.width(10.dp))
                                Txt(name, style = AuroraType.label, modifier = Modifier.weight(1f), maxLines = 1)
                                Pill(null, tr("إلغاء", "Unsubscribe")) { toggleFollow(url, name) }
                            }
                        }
                        item { Txt(tr("الاقتراحات تُحسب على جهازك من سجلّك واشتراكاتك وبحثك. لا حساب Google ولا خادم.", "Recommendations are computed on-device from your history, subscriptions and searches."), style = AuroraType.caption, color = c.textTertiary) }
                    }
                }

                // Channel page
                if (channelUrl != null) Box(Modifier.fillMaxSize().background(c.background)) {
                    val info = channel
                    FeedList(channelFeed, emptyText = channelError.ifBlank { tr("لا فيديوهات.", "No videos.") }, header = {
                        Column {
                            if (info?.banner?.isNotBlank() == true) AsyncImage(model = info.banner, contentDescription = null, contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxWidth().height(86.dp).clip(RoundedCornerShape(14.dp)))
                            Spacer(Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(38.dp).tap { channelUrl = null }, contentAlignment = Alignment.Center) { Glyph(Ic.BACK, c.textPrimary) }
                                Avatar(info?.avatar.orEmpty(), info?.name ?: "…", 54.dp); Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Txt(info?.name ?: tr("جارٍ التحميل…", "Loading…"), style = AuroraType.heading, maxLines = 1)
                                    if (info != null && info.subscribers >= 0) Txt(count(info.subscribers, arabic) + tr(" مشترك", " subscribers"), style = AuroraType.caption, color = c.textSecondary)
                                }
                                if (info != null) {
                                    val followed = info.url in profile.following || channelUrl in profile.following
                                    AuroraButton(if (followed) tr("مشترك ✓", "Subscribed") else tr("اشتراك", "Subscribe"), primary = !followed) { toggleFollow(channelUrl ?: info.url, info.name) }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Pill(null, tr("الفيديوهات", "Videos"), active = !channelShorts) { channelShorts = false }
                                if (info?.shorts != null) Pill(null, "Shorts", active = channelShorts) { channelShorts = true }
                            }
                        }
                    }, rows = false)
                }

                // Mini player
                if (nowItem != null && !expanded && !shortsMode) Row(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(8.dp).clip(RoundedCornerShape(16.dp))
                        .background(c.backgroundTop).border(1.dp, c.line, RoundedCornerShape(16.dp)).tap { expanded = true },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    PlayerBox(Modifier.width(118.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp)), mini = true)
                    Column(Modifier.weight(1f).padding(horizontal = 9.dp)) {
                        Txt(nowItem?.title.orEmpty(), style = AuroraType.label, maxLines = 1)
                        Txt(nowItem?.channel.orEmpty(), style = AuroraType.caption, color = c.textSecondary, maxLines = 1)
                    }
                    Box(Modifier.size(40.dp).tap { controller?.let { if (it.isPlaying) it.pause() else it.play() } }, contentAlignment = Alignment.Center) { Glyph(if (playing) Ic.PAUSE else Ic.PLAY, c.textPrimary) }
                    Box(Modifier.size(40.dp).tap { close() }, contentAlignment = Alignment.Center) { Glyph(Ic.CLOSE, c.textSecondary) }
                }
            }
            // YouTube-style bottom navigation
            Row(Modifier.fillMaxWidth().background(c.backgroundTop).padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                YtTab.entries.forEach { entry ->
                    val active = tab == entry
                    Column(Modifier.weight(1f).tap { channelUrl = null; if (tab == entry) refresh++ else tab = entry }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Glyph(entry.icon, if (active) c.textPrimary else c.textTertiary, size = 22.dp)
                        Spacer(Modifier.height(2.dp))
                        Txt(if (arabic) entry.ar else entry.en, style = AuroraType.caption.copy(fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal),
                            color = if (active) c.textPrimary else c.textTertiary, maxLines = 1)
                    }
                }
            }
        }

        // Watch page
        val current = nowItem
        if (current != null && expanded && !shortsMode) Column(Modifier.fillMaxSize().background(c.background)) {
            PlayerBox(Modifier.fillMaxWidth().aspectRatio(16f / 9f))
            val d = details
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Txt(d?.title ?: current.title, style = AuroraType.heading.copy(lineHeight = 23.sp), maxLines = 3)
                    Spacer(Modifier.height(3.dp))
                    Txt(listOf(count(d?.views ?: current.views, arabic).takeIf { it.isNotBlank() }?.let { it + tr(" مشاهدة", " views") }.orEmpty(), d?.uploaded ?: current.uploaded)
                        .filter { it.isNotBlank() }.joinToString(" · "), style = AuroraType.caption, color = c.textSecondary)
                }
                item {
                    val channelLink = d?.channelUrl?.ifBlank { current.channelUrl } ?: current.channelUrl
                    val followed = channelLink in profile.following
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Row(Modifier.weight(1f).tap { if (channelLink.isNotBlank()) { expanded = false; channelShorts = false; channel = null; channelUrl = channelLink } }, verticalAlignment = Alignment.CenterVertically) {
                            Avatar(d?.channelAvatar.orEmpty(), d?.channel ?: current.channel, 40.dp); Spacer(Modifier.width(10.dp))
                            Column {
                                Txt(d?.channel ?: current.channel, style = AuroraType.label, maxLines = 1)
                                if (d != null && d.subscribers >= 0) Txt(count(d.subscribers, arabic) + tr(" مشترك", " subscribers"), style = AuroraType.caption, color = c.textSecondary)
                            }
                        }
                        AuroraButton(if (followed) tr("مشترك ✓", "Subscribed") else tr("اشتراك", "Subscribe"), primary = !followed) { toggleFollow(channelLink, d?.channel ?: current.channel) }
                    }
                }
                item {
                    val liked = profile.likedItems.any { it.videoId == current.url }
                    val saved = profile.watchLaterItems.any { it.videoId == current.url }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { Pill(Ic.HEART, if (d != null && d.likes >= 0) count(d.likes, arabic) else tr("أعجبني", "Like"), liked) { toggleLiked(current) } }
                        item { Pill(Ic.DOWNLOAD, tr("تحميل", "Download")) { if (d != null) sheet = "download" else say(tr("لحظة، تُجلب الصيغ…", "Loading formats…")) } }
                        item { Pill(Ic.COPY, tr("نسخ الرابط", "Copy link")) { copyLink(current.url) } }
                        item { Pill(Ic.SHARE, tr("مشاركة", "Share")) { share(current.url) } }
                        item { Pill(Ic.BOOKMARK, tr("حفظ", "Save"), saved) { toggleSaved(current) } }
                        item { Pill(Ic.REPEAT, tr("تكرار", "Loop"), repeatOne) { repeatOne = !repeatOne; controller?.repeatMode = if (repeatOne) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF } }
                        item { Pill(Ic.NEXT, tr("تشغيل تلقائي", "Autoplay"), autoplay) { autoplay = !autoplay } }
                        item {
                            val left = if (sleepEnd > 0) ((sleepEnd - SystemClock.elapsedRealtime()) / 60_000 + 1).coerceAtLeast(1) else 0
                            Pill(Ic.CLOCK, if (left > 0) tr("نوم $left د", "Sleep ${left}m") else tr("مؤقت نوم", "Sleep timer"), left > 0) {
                                sleepJob?.cancel()
                                val minutes = when { sleepEnd == 0L -> 15; left <= 15 -> 30; left <= 30 -> 60; else -> 0 }
                                if (minutes == 0) sleepEnd = 0 else {
                                    sleepEnd = SystemClock.elapsedRealtime() + minutes * 60_000L
                                    sleepJob = scope.launch { delay(minutes * 60_000L); controller?.pause(); sleepEnd = 0 }
                                }
                            }
                        }
                    }
                }
                if (d != null && d.description.isNotBlank()) item {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.glassStrong).tap { descriptionOpen = !descriptionOpen }.padding(12.dp)) {
                        Txt(tr("الوصف", "Description"), style = AuroraType.label)
                        Spacer(Modifier.height(4.dp))
                        Txt(plainText(d.description), style = AuroraType.caption.copy(fontSize = 11.5.sp, lineHeight = 18.sp), color = c.textSecondary, maxLines = if (descriptionOpen) 200 else 3)
                    }
                }
                item {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.glassStrong).padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().tap {
                            if (comments == null && !commentsLoading) { commentsLoading = true; scope.launch { comments = runCatching { engine.comments(current.url) }.getOrDefault(emptyList()); commentsLoading = false } }
                        }) {
                            Txt(tr("التعليقات", "Comments"), style = AuroraType.label, modifier = Modifier.weight(1f))
                            if (commentsLoading) Spinner(16.dp, c.accent2) else if (comments == null) Txt(tr("عرض", "Show"), style = AuroraType.caption, color = c.accent2)
                        }
                        comments?.let { list ->
                            if (list.isEmpty()) Txt(tr("لا تعليقات متاحة.", "No comments available."), style = AuroraType.caption, color = c.textSecondary)
                            list.take(30).forEach { comment ->
                                Spacer(Modifier.height(9.dp))
                                Txt("${comment.author} · ${comment.date}", style = AuroraType.caption, color = c.textTertiary, maxLines = 1)
                                Txt(plainText(comment.text), style = AuroraType.caption.copy(fontSize = 11.5.sp, lineHeight = 17.sp), maxLines = 8)
                            }
                        }
                    }
                }
                if (d == null) item { Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) { Spinner(26.dp, c.accent2) } }
                items(d?.related.orEmpty().filterNot { it.short }.distinctBy { it.url }, key = { it.url }) { item -> VideoRow(item, arabic, onOpen = { open(item) }, onMore = { menuFor = item }) }
            }
        }

        // Search overlay with live suggestions
        if (searching) Column(Modifier.fillMaxSize().background(c.background).padding(horizontal = 12.dp, vertical = 8.dp)) {
            val focus = remember { FocusRequester() }
            LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).tap { searching = false }, contentAlignment = Alignment.Center) { Glyph(Ic.BACK, c.textPrimary) }
                BasicTextField(typed, { typed = it }, singleLine = true, textStyle = AuroraType.body.copy(color = c.textPrimary), cursorBrush = SolidColor(c.accent2),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { submit(typed) }),
                    modifier = Modifier.weight(1f).focusRequester(focus).clip(AuroraShapes.chip).background(c.glassStrong).padding(horizontal = 14.dp, vertical = 10.dp),
                    decorationBox = { inner -> Box { if (typed.isEmpty()) Txt(tr("ابحث في YouTube", "Search YouTube"), style = AuroraType.body, color = c.textTertiary); inner() } })
                if (typed.isNotEmpty()) Box(Modifier.size(40.dp).tap { typed = "" }, contentAlignment = Alignment.Center) { Glyph(Ic.CLOSE, c.textSecondary) }
            }
            val recent = profile.recentSearches.filter { typed.isBlank() || it.contains(typed.trim(), true) }.take(if (typed.isBlank()) 12 else 3)
            LazyColumn(Modifier.weight(1f)) {
                items(recent, key = { "r$it" }) { text ->
                    Row(Modifier.fillMaxWidth().tap { submit(text) }.padding(vertical = 11.dp, horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Glyph(Ic.CLOCK, c.textTertiary, size = 17.dp); Spacer(Modifier.width(12.dp))
                        Txt(text, style = AuroraType.body, modifier = Modifier.weight(1f), maxLines = 1)
                        Box(Modifier.size(30.dp).tap { scope.launch { editProfile { p -> p.copy(recentSearches = p.recentSearches - text) } } }, contentAlignment = Alignment.Center) { Glyph(Ic.CLOSE, c.textTertiary, size = 13.dp) }
                    }
                }
                items(remote.filterNot { it in recent }.distinct(), key = { "s$it" }) { text ->
                    Row(Modifier.fillMaxWidth().tap { submit(text) }.padding(vertical = 11.dp, horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Glyph(Ic.SEARCH, c.textTertiary, size = 17.dp); Spacer(Modifier.width(12.dp))
                        Txt(text, style = AuroraType.body, modifier = Modifier.weight(1f), maxLines = 1)
                        Box(Modifier.size(30.dp).tap { typed = text }, contentAlignment = Alignment.Center) { Glyph(Ic.SHARE, c.textTertiary, size = 14.dp) }
                    }
                }
            }
        }

        // Quick actions for a list item
        menuFor?.let { item ->
            AuroraSheet(title = item.title, subtitle = item.channel, onDismiss = { menuFor = null }) {
                val saved = profile.watchLaterItems.any { it.videoId == item.url }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AuroraButton(tr("تشغيل وتحميل", "Play & download options"), Modifier.fillMaxWidth()) { menuFor = null; open(item) }
                    AuroraButton(if (saved) tr("إزالة من «لاحقًا»", "Remove from Watch later") else tr("حفظ للمشاهدة لاحقًا", "Save to Watch later"), Modifier.fillMaxWidth(), primary = false) { toggleSaved(item); menuFor = null }
                    AuroraButton(tr("نسخ الرابط", "Copy link"), Modifier.fillMaxWidth(), primary = false) { copyLink(item.url); menuFor = null }
                    AuroraButton(tr("مشاركة", "Share"), Modifier.fillMaxWidth(), primary = false) { share(item.url); menuFor = null }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }

        // Quality + download sheets
        val d = details
        if (sheet == "quality" && d != null) AuroraSheet(title = tr("جودة التشغيل", "Playback quality"), onDismiss = { sheet = "" }) {
            val heights = (d.videoOnly.map { it.height } + d.muxed.map { it.height }).filter { it > 0 }.distinct().sortedDescending().ifEmpty { listOf(1080, 720, 480, 360, 240, 144) }
            LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                item { AuroraButton(tr("تلقائي (حسب الشبكة)", "Auto (network adaptive)"), Modifier.fillMaxWidth(), primary = maxHeight == 0) { applyQuality(0); sheet = "" } }
                items(heights) { h -> AuroraButton("${h}p", Modifier.fillMaxWidth(), primary = maxHeight == h) { applyQuality(h); sheet = "" } }
                item { Spacer(Modifier.height(10.dp)) }
            }
        }
        if (sheet == "download" && d != null) AuroraSheet(title = tr("تحميل", "Download"), subtitle = d.title, onDismiss = { sheet = "" }) {
            fun queue(type: ContentType, quality: String, extension: String, formatId: String, merge: Boolean, bytes: Long?) {
                sheet = ""
                scope.launch {
                    onDownload(DownloadRequest(url = d.url, name = "${safeName(d.title)}.$extension", site = "youtube.com", type = type, quality = quality,
                        totalBytes = bytes ?: 0, approx = true, formatId = formatId, requiresExtractor = true, needsMerge = merge))
                        .onSuccess { say(tr("بدأ التحميل — تابعه من «التحميلات»", "Download started — see Downloads")) }
                        .onFailure { say(tr("لم يبدأ التحميل: ", "Could not start: ") + it.message.orEmpty()) }
                }
            }
            @Composable
            fun FormatRow(label: String, detail: String, size: Long?, onClick: () -> Unit) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(c.glassStrong).tap(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Txt(label, style = AuroraType.label)
                        Txt(detail, style = AuroraType.caption, color = c.textSecondary, maxLines = 1)
                    }
                    Txt(size?.let { formatBytes(it) } ?: tr("الحجم غير معلن", "size not declared"), style = AuroraType.mono, color = if (size != null) c.success else c.textTertiary)
                    Spacer(Modifier.width(8.dp)); Glyph(Ic.DOWNLOAD, c.accent2, size = 17.dp)
                }
            }
            val bestAudio = d.audio.firstOrNull()
            val videos = d.videoOnly.groupBy { it.height }.toSortedMap(compareByDescending<Int> { it }).values.map { same -> same.firstOrNull { it.codec.startsWith("avc") } ?: same.first() }
            LazyColumn(Modifier.heightIn(max = 430.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                item { Txt(tr("فيديو (يُدمج مع أفضل صوت تلقائيًا)", "Video (auto-merged with best audio)"), style = AuroraType.caption, color = c.accent2) }
                item { FormatRow(tr("أفضل جودة متاحة", "Best available"), "MP4 · bestvideo+bestaudio", null) { queue(ContentType.VIDEO, "Best", "mp4", "best", true, null) } }
                items(videos) { f: YtFormat ->
                    val total = if (f.bytes != null && bestAudio?.bytes != null) f.bytes + bestAudio.bytes else null
                    FormatRow(f.label, "${f.container.uppercase()} · ${f.codec.substringBefore('.')} · itag ${f.itag}", total) { queue(ContentType.VIDEO, f.label, "mp4", f.itag.toString(), true, total) }
                }
                items(d.muxed) { f -> FormatRow("${f.label} · ${tr("ملف واحد", "single file")}", "${f.container.uppercase()} · itag ${f.itag}", f.bytes) { queue(ContentType.VIDEO, f.label, f.container, f.itag.toString(), false, f.bytes) } }
                item { Txt(tr("صوت فقط", "Audio only"), style = AuroraType.caption, color = c.accent2) }
                item { FormatRow("MP3", tr("تحويل عبر FFmpeg", "converted with FFmpeg"), null) { queue(ContentType.AUDIO, "MP3", "mp3", "audio:mp3", false, null) } }
                items(d.audio) { f -> FormatRow(f.label, "${f.container.uppercase()} · ${f.codec.substringBefore('.')} · itag ${f.itag}", f.bytes) { queue(ContentType.AUDIO, f.label, f.container, f.itag.toString(), false, f.bytes) } }
                item { Txt(tr("حمّل فقط ما تملك حق تنزيله. لا تجاوز لـ DRM.", "Download only what you have the right to save. No DRM bypass."), style = AuroraType.caption, color = c.textTertiary); Spacer(Modifier.height(10.dp)) }
            }
        }

        if (toast.isNotBlank()) Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 86.dp).clip(AuroraShapes.chip).background(Color(0xF0202330)).padding(horizontal = 16.dp, vertical = 9.dp)) {
            Txt(toast, style = AuroraType.label, color = Color.White)
        }
    }
}

@Composable
private fun ShortAction(icon: Ic, label: String, active: Boolean, onClick: () -> Unit) {
    Column(Modifier.tap(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(Color.Black.copy(alpha = .42f)), contentAlignment = Alignment.Center) {
            Glyph(icon, if (active) Color(0xFFFF4D6D) else Color.White, size = 21.dp)
        }
        Spacer(Modifier.height(3.dp))
        Txt(label, style = AuroraType.caption, color = Color.White, maxLines = 1)
    }
}

private fun kioskLabel(id: String, arabic: Boolean): String {
    if (!arabic) return id.replace('_', ' ').replaceFirstChar { it.uppercase() }
    val key = id.lowercase()
    return when {
        "live" in key -> "بث مباشر"
        "gaming" in key -> "ألعاب"
        "music" in key -> "موسيقى"
        "movie" in key || "show" in key -> "أفلام وعروض"
        "podcast" in key -> "بودكاست"
        "trending" in key -> "الرائج"
        else -> id.replace('_', ' ')
    }
}

private fun plainText(html: String): String =
    if ('<' !in html) html else android.text.Html.fromHtml(html.replace("\n", "<br>"), android.text.Html.FROM_HTML_MODE_COMPACT).toString().trim()
