package com.auroraget.app

import android.app.Application
import com.auroraget.app.data.DownloadRepository
import com.auroraget.app.di.appModule
import com.auroraget.app.engine.ExtractorEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import org.koin.java.KoinJavaComponent.getKoin

class AuroraApplication : Application() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@AuroraApplication)
            modules(appModule)
        }
        scope.launch {
            runCatching { getKoin().get<DownloadRepository>().ensureChannel() }
            // Keep the bundled yt-dlp current: at most one silent check per day, only when online.
            runCatching {
                val prefs = getSharedPreferences("jo_don_engine", MODE_PRIVATE)
                if (System.currentTimeMillis() - prefs.getLong("ytdlp_checked", 0L) > 24 * 3_600_000L) {
                    getKoin().get<ExtractorEngine>().update()
                    prefs.edit().putLong("ytdlp_checked", System.currentTimeMillis()).apply()
                }
            }
        }
    }
}
