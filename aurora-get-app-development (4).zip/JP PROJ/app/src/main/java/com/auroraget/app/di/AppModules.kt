package com.auroraget.app.di

import android.content.Context
import com.auroraget.app.data.DownloadRepository
import com.auroraget.app.data.LocalStore
import com.auroraget.app.engine.YouTubeEngine
import com.auroraget.app.engine.ExtractorEngine
import com.auroraget.app.engine.LinkAnalyzer
import org.koin.dsl.module

val appModule = module {
    single { LocalStore(get<Context>()) }
    single { YouTubeEngine() }
    single { ExtractorEngine(get<Context>()) }
    single { LinkAnalyzer(get<ExtractorEngine>()) }
    single { DownloadRepository(get<Context>(), get<LocalStore>(), get<LinkAnalyzer>(), get<ExtractorEngine>()) }
}
