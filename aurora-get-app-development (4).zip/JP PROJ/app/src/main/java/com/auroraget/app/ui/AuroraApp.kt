package com.auroraget.app.ui

import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.auroraget.app.data.AnalyzedSource
import com.auroraget.app.data.ContentType
import com.auroraget.app.data.DownloadEntity
import com.auroraget.app.data.DownloadRequest
import com.auroraget.app.data.MediaFormat
import com.auroraget.app.data.formatBytes
import com.auroraget.app.data.DownloadRepository
import com.auroraget.app.data.LocalStore
import com.auroraget.app.engine.LinkAnalyzer
import com.auroraget.app.ui.components.AuroraButton
import com.auroraget.app.ui.components.tap
import com.auroraget.app.ui.components.Glyph
import com.auroraget.app.ui.components.Ic
import com.auroraget.app.ui.components.AuroraDock
import com.auroraget.app.ui.components.AuroraGlass
import com.auroraget.app.ui.components.AuroraSheet
import com.auroraget.app.ui.components.AuroraTag
import com.auroraget.app.ui.components.GradientTitle
import com.auroraget.app.ui.screens.BrowserScreen
import com.auroraget.app.ui.screens.DownloadsScreen
import com.auroraget.app.ui.screens.FilesScreen
import com.auroraget.app.ui.screens.HomeScreen
import com.auroraget.app.ui.screens.SettingsScreen
import com.auroraget.app.ui.screens.ToolsScreen
import com.auroraget.app.ui.screens.YouTubeScreen
import com.auroraget.app.ui.screens.LocalPlayerScreen
import com.auroraget.app.ui.screens.LocalTrack
import com.auroraget.app.data.DownloadStatus
import androidx.activity.compose.BackHandler
import com.auroraget.app.ui.screens.Txt
import com.auroraget.app.ui.theme.AuroraShapes
import com.auroraget.app.ui.theme.AuroraThemeId
import com.auroraget.app.ui.theme.AuroraType
import com.auroraget.app.ui.theme.LocalAuroraColors
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.CancellationException
import org.koin.core.context.GlobalContext
import java.io.File

private val dockItems = listOf(
    "الرئيسية" to Ic.HOME, "التحميلات" to Ic.DOWNLOAD, "YouTube" to Ic.YOUTUBE,
    "المتصفح" to Ic.GLOBE, "المكتبة" to Ic.FOLDER, "الإعدادات" to Ic.GEAR,
)
private val dockItemsEn = listOf(
    "Home" to Ic.HOME, "Downloads" to Ic.DOWNLOAD, "YouTube" to Ic.YOUTUBE,
    "Browser" to Ic.GLOBE, "Library" to Ic.FOLDER, "Settings" to Ic.GEAR,
)

@Composable
fun AuroraApp(
    sharedLink: String? = null,
    shortcut: String? = null,
) {
    val c = LocalAuroraColors.current
    val context = LocalContext.current
    val koin = remember { GlobalContext.get() }
    val repository = remember { koin.get<DownloadRepository>() }
    val analyzer = remember { koin.get<LinkAnalyzer>() }
    val store = remember { koin.get<LocalStore>() }
    val extractor = remember { koin.get<com.auroraget.app.engine.ExtractorEngine>() }
    val local by store.state.collectAsState()
    val settings = local.settings
    val theme = AuroraThemeId.entries.firstOrNull { it.id == settings.themeId } ?: AuroraThemeId.AURORA
    val downloads by repository.allDownloads.collectAsState(initial = emptyList())
    val speeds by repository.speeds.collectAsState()

    var tab by remember { mutableStateOf(if (shortcut == "downloads") 1 else 0) }
    var url by remember { mutableStateOf(sharedLink.orEmpty()) }
    var analyzing by remember { mutableStateOf(false) }
    var stage by remember { mutableStateOf(0) }
    var source by remember { mutableStateOf<AnalyzedSource?>(null) }
    var sheetType by remember { mutableStateOf<ContentType?>(null) }
    var statusText by remember { mutableStateOf("") }
    var updateStatus by remember { mutableStateOf("") }
    var analysisJob by remember { mutableStateOf<Job?>(null) }
    var playerQueue by remember { mutableStateOf(listOf<LocalTrack>()) }
    var playerIndex by remember { mutableStateOf(0) }
    var playerBack by remember { mutableStateOf(4) }
    var step by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        if (settings.autoResume) repository.resumeUnfinished()
    }
    BackHandler(enabled = tab != 0 && tab != 2) { tab = if (tab == 7) playerBack else 0 }

    LaunchedEffect(sharedLink) {
        if (!sharedLink.isNullOrBlank()) {
            url = sharedLink
            tab = 0
        }
    }

    fun analyzeLink() {
        if (url.isBlank()) return
        analysisJob?.cancel()
        val request = url.trim()
        analyzing = true
        stage = 0
        source = null
        statusText = ""
        analysisJob = scope.launch {
            val result = analyzer.analyze(request) { stage = it }
            if (url.trim() != request) return@launch
            result.onSuccess { source = it }
                .onFailure { if (it !is CancellationException) statusText = it.message ?: "فشل التحليل" }
            analyzing = false
        }
    }

    LaunchedEffect(url) {
        if (url.startsWith("https://") && url.contains('.') && url != source?.url) {
            delay(150)
            analyzeLink()
        }
    }

    fun queue(format: MediaFormat) {
        val currentSource = source ?: return
        scope.launch {
            val direct = format.directUrl?.takeIf { !format.needsMerge &&
                (format.id == "direct" || format.type == ContentType.IMAGE || format.type == ContentType.FILE) }
            runCatching { repository.enqueue(
                DownloadRequest(
                    url = direct ?: currentSource.url,
                    name = currentSource.filename.substringBeforeLast('.') + "." +
                        (if (format.needsMerge) "mp4" else format.container.lowercase()),
                    site = currentSource.domain,
                    type = format.type,
                    quality = "${format.quality} · ${format.container}",
                    totalBytes = format.bytes ?: 0,
                    approx = format.approx,
                    headers = emptyMap(),
                    formatId = if (direct == null) format.id else null,
                    requiresExtractor = direct == null,
                    needsMerge = format.needsMerge,
                ),
                connectionTarget = settings.connections,
            ) }.onSuccess {
                statusText = "بدأ التحميل الفعلي — ${format.displaySize}"
                sheetType = null
                tab = 1
            }.onFailure { statusText = "لم يبدأ التحميل: ${it.message}" }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.backgroundTop, c.background)))
    ) {
        Image(painterResource(theme.photoRes), contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(if (settings.light) .16f else .32f))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(
            c.backgroundTop.copy(alpha = .72f), c.background.copy(alpha = .83f),
            c.background.copy(alpha = .98f)))))
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars)) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeScreen(
                        langArabic = settings.arabic,
                        url = url,
                        analyzing = analyzing,
                        stage = stage,
                        statusText = statusText,
                        source = source,
                        downloads = downloads,
                        onUrlChange = {
                            analysisJob?.cancel()
                            url = it
                            source = null
                            analyzing = false
                        },
                        onAnalyze = { analyzeLink() },
                        onPaste = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val copied = clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                            if (copied.isNotBlank()) { url = copied; statusText = "نُسخ الرابط من الحافظة." }
                            else statusText = "الحافظة فارغة."
                        },
                        onBrowser = { tab = 3 },
                        onType = { sheetType = it },
                        onOpenDownloads = { tab = 1 },
                        onTools = { tab = 6 },
                        onYouTube = { tab = 2 },
                    )
                    1 -> DownloadsScreen(
                        downloads = downloads,
                        speeds = speeds,
                        langArabic = settings.arabic,
                        onPause = { repository.pause(it) },
                        onResume = { repository.start(it) },
                        onRemove = { repository.cancel(it) },
                        onAdd = { tab = 0 },
                    )
                    2 -> YouTubeScreen(
                        arabic = settings.arabic,
                        onExit = { tab = 0 },
                        onDownload = { request -> runCatching { repository.enqueue(request, settings.connections) } },
                    )
                    3 -> BrowserScreen(
                        startUrl = "about:blank",
                        langArabic = settings.arabic,
                        onDownload = { request ->
                            scope.launch {
                                runCatching { repository.enqueue(request, settings.connections) }
                                    .onSuccess { tab = 1; statusText = "أُرسل ${request.name} لمحرك التحميل." }
                                    .onFailure { statusText = "فشل البدء: ${it.message}" }
                            }
                        },
                    )
                    4 -> FilesScreen(
                        downloads = downloads,
                        onOpen = { item -> openFile(context, item) },
                        onPlay = { item ->
                            val same = downloads.filter { it.status == DownloadStatus.COMPLETED && it.type == item.type }
                            playerQueue = same.map { LocalTrack(Uri.fromFile(File(it.outputPath)), it.name, it.type == ContentType.AUDIO) }
                            playerIndex = same.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
                            playerBack = 4; tab = 7
                        },
                        onPlayUri = { media, title, audio ->
                            playerQueue = listOf(LocalTrack(media, title, audio)); playerIndex = 0
                            playerBack = 4; tab = 7
                        },
                        onOpenUri = { media ->
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, media)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                                .onFailure { statusText = it.message.orEmpty() }
                        },
                        onPlayQueue = { list, index -> playerQueue = list; playerIndex = index; playerBack = 4; tab = 7 },
                    )
                    5 -> SettingsScreen(
                        settings = settings,
                        onTheme = { selected -> scope.launch { store.update { it.copy(settings = it.settings.copy(themeId = selected.id)) } } },
                        onLight = { selected -> scope.launch { store.update { it.copy(settings = it.settings.copy(light = selected)) } } },
                        onArabic = { selected -> scope.launch { store.update { it.copy(settings = it.settings.copy(arabic = selected)) } } },
                        onConnections = { count -> scope.launch { store.update { it.copy(settings = it.settings.copy(connections = count)) } } },
                        onWifi = { selected -> scope.launch { store.update { it.copy(settings = it.settings.copy(wifiOnly = selected)) } } },
                        onAdblock = { selected -> scope.launch { store.update { it.copy(settings = it.settings.copy(adblock = selected)) } } },
                        onAutoResume = { selected -> scope.launch { store.update { it.copy(settings = it.settings.copy(autoResume = selected)) } } },
                        onUpdate = {
                            updateStatus = "يتم فحص الإصدار عبر الشبكة..."
                            scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                runCatching { extractor.update() }
                                    .onSuccess { updateStatus = "اكتمل تحديث yt-dlp." }
                                    .onFailure { updateStatus = "فشل التحديث: ${it.message}" }
                            }
                        },
                        updateStatus = updateStatus,
                        onTools = { tab = 6 },
                        onYouTube = { tab = 2 },
                    )
                    6 -> ToolsScreen(isArabic = settings.arabic, onPlay = { media, title, audio ->
                        playerQueue = listOf(LocalTrack(media, title, audio)); playerIndex = 0
                        playerBack = 6; tab = 7
                    })
                    7 -> if (playerQueue.isNotEmpty()) LocalPlayerScreen(playerQueue, playerIndex, onBack = { tab = playerBack })
                }
            }
            if (tab != 7 && tab != 2) AuroraDock(
                items = if (settings.arabic) dockItems else dockItemsEn,
                selected = tab,
                onSelect = { tab = it },
                badge = downloads.count { it.status == DownloadStatus.DOWNLOADING },
            )
            Spacer(Modifier.height(8.dp).navigationBarsPadding())
        }

        if (!settings.onboardingSeen) {
            Onboarding(step = step, onNext = {
                if (step >= 2) {
                    scope.launch { store.update { it.copy(settings = it.settings.copy(onboardingSeen = true)) } }
                } else step += 1
            }, onSkip = { scope.launch { store.update { it.copy(settings = it.settings.copy(onboardingSeen = true)) } } })
        }

        val activeType = sheetType
        if (activeType != null && source != null) {
            val formats = source?.formats?.get(activeType).orEmpty()
            AuroraSheet(
                title = "${activeType.ar} · ${formats.size}",
                subtitle = source?.title,
                onDismiss = { sheetType = null },
            ) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth().height(360.dp)) {
                    items(formats) { format ->
                        AuroraGlass(Modifier.fillMaxWidth(), radius = 16.dp) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Txt(format.quality, style = AuroraType.label, modifier = Modifier.weight(1f), maxLines = 1)
                                    if (format.best) AuroraTag("موصى به", color = c.accent2, filled = true)
                                }
                                Txt(
                                    "${format.container} · ${format.codec} · ${format.detail}",
                                    style = AuroraType.caption,
                                    color = c.textSecondary,
                                    maxLines = 1,
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Txt(
                                        format.displaySize,
                                        style = AuroraType.mono,
                                        color = if (format.approx) c.warning else c.success,
                                    )
                                    if (format.approx) {
                                        Spacer(Modifier.size(4.dp))
                                        AuroraTag("≈ تقديري", color = c.warning)
                                    }
                                    if (format.needsMerge) {
                                        Spacer(Modifier.size(4.dp))
                                        AuroraTag("دمج تلقائي", color = c.accent3)
                                    }
                                    Spacer(Modifier.weight(1f))
                                    AuroraButton("تحميل") { queue(format) }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                AuroraButton(
                    "تحميل الأفضل تلقائيًا",
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    val best = formats.firstOrNull { it.best } ?: formats.firstOrNull()
                    if (best != null) queue(best)
                }
            }
        }
    }
}

@Composable
private fun Onboarding(step: Int, onNext: () -> Unit, onSkip: () -> Unit) {
    val c = LocalAuroraColors.current
    val slides = listOf(
        Triple("𝒥𝒪 DON", "كل ما تحبه، في مكان واحد.", "ألصق أي رابط ودع المحرك يتولى الباقي — فيديو، صوت، صور وملفات."),
        Triple("Four smart chips", "اختر نوعك، واحصل على الجودة.", "الأزرار تظهر فقط عند وجود محتوى فعلي، مع الحجم المؤكد أو التقريبي."),
        Triple("Privacy first", "لا سحابة. لا تتبع.", "ملف شخصي محلي، وثيمات مصوّرة، وتنزيلات تحفظ حالتها في ملف JSON خاص بك."),
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.backgroundTop, c.background)))
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                AuroraTag("Aurora Glass", color = c.accent2, filled = true)
                Spacer(Modifier.weight(1f))
                Box(Modifier.tap { onSkip() }) { Txt("تخطي ✕", style = AuroraType.caption, color = c.textSecondary) }
            }
            Spacer(Modifier.height(28.dp))
            Box(
                Modifier
                    .size(148.dp)
                    .clip(AuroraShapes.chip)
                    .background(Brush.linearGradient(c.accents))
            )
            Spacer(Modifier.height(22.dp))
            Txt(slides[step].second, style = AuroraType.display, color = c.textPrimary)
            Spacer(Modifier.height(8.dp))
            Txt(slides[step].third, style = AuroraType.body, color = c.textSecondary)
            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                repeat(3) { i ->
                    Box(
                        Modifier
                            .size(width = if (i == step) 22.dp else 7.dp, height = 3.dp)
                            .clip(AuroraShapes.chip)
                            .background(if (i == step) c.accent2 else c.lineStrong)
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            AuroraButton(if (step == 2) "ابدأ الآن" else "التالي", Modifier.fillMaxWidth(), onClick = onNext)
            Spacer(Modifier.height(8.dp))
            Txt("${step + 1} / 3 · واجهة عربية RTL كاملة", style = AuroraType.caption, color = c.textTertiary)
            Spacer(Modifier.height(10.dp))
        }
    }
}

private fun openFile(context: android.content.Context, item: DownloadEntity) {
    val file = File(item.outputPath.ifBlank { File(context.getExternalFilesDir(null), "Aurora/Files/${item.name}").absolutePath })
    if (!file.exists()) return
    val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, context.contentResolver.getType(uri) ?: "*/*")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    runCatching { context.startActivity(intent) }
}

private fun playFile(context: android.content.Context, item: DownloadEntity) = openFile(context, item)
