package com.auroraget.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import com.auroraget.app.ui.AuroraApp
import com.auroraget.app.ui.theme.AuroraTheme
import com.auroraget.app.ui.theme.AuroraThemeId
import com.auroraget.app.data.LocalStore
import org.koin.core.context.GlobalContext

class MainActivity : ComponentActivity() {
    private var sharedLink by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            val ask = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }
            window.decorView.post { runCatching { ask.launch(android.Manifest.permission.POST_NOTIFICATIONS) } }
        }
        sharedLink = extractSharedLink()
        val shortcut = intent?.getStringExtra("shortcut")
        val localStore = GlobalContext.get().get<LocalStore>()
        setContent {
            val local by localStore.state.collectAsState()
            val theme = AuroraThemeId.entries.firstOrNull { it.id == local.settings.themeId } ?: AuroraThemeId.AURORA
            AuroraTheme(theme = theme, light = local.settings.light) {
                CompositionLocalProvider(LocalLayoutDirection provides
                    if (local.settings.arabic) LayoutDirection.Rtl else LayoutDirection.Ltr) {
                    AuroraApp(
                        sharedLink = sharedLink,
                        shortcut = shortcut,
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        sharedLink = extractSharedLink()
    }

    private fun extractSharedLink(): String? {
        val intent = intent ?: return null
        return when (intent.action) {
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> intent.dataString
            else -> null
        }
    }
}
