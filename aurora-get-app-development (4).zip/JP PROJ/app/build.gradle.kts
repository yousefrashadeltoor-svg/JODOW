import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.net.URI

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "com.auroraget.app"
    compileSdk = 35
    buildToolsVersion = "35.0.0"

    defaultConfig {
        applicationId = "com.jodon.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        // -PjoAbi=arm64-v8a builds a single-ABI APK (smaller, faster to build).
        val abis = (project.findProperty("joAbi") as String?)?.split(",")
            ?: listOf("arm64-v8a", "armeabi-v7a", "x86_64")
        ndk { abiFilters += abis }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlin {
        compilerOptions {
            jvmTarget.set(JvmTarget.JVM_17)
            freeCompilerArgs.add("-opt-in=kotlinx.coroutines.ExperimentalCoroutinesApi")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources.excludes += setOf(
            "/META-INF/{AL2.0,LGPL2.1}",
            "META-INF/DEPENDENCIES",
            "META-INF/LICENSE*",
            "META-INF/NOTICE*"
        )
        jniLibs.useLegacyPackaging = true
    }

    testOptions { unitTests.all { it.testLogging { showStandardStreams = true } } }

    lint {
        abortOnError = false
        checkReleaseBuilds = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime)

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.foundation)
    implementation(libs.compose.ui)
    implementation(libs.compose.graphics)

    implementation(libs.koin.core)
    implementation(libs.koin.android)
    implementation(libs.koin.compose)

    implementation(libs.okhttp)
    implementation(libs.jsoup)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.kotlinx.coroutines.android)

    implementation(libs.coil.compose)
    implementation(libs.coil.network.okhttp)

    implementation(libs.media3.exoplayer)
    implementation(libs.media3.exoplayer.hls)
    implementation(libs.media3.exoplayer.dash)
    implementation(libs.media3.ui)
    implementation(libs.media3.session)


    implementation(libs.youtubedl.library)
    implementation(libs.youtubedl.ffmpeg)
    implementation(libs.youtubedl.aria2c)

    implementation(libs.newpipe.extractor)
    coreLibraryDesugaring(libs.desugar.nio)
    testImplementation("junit:junit:4.13.2")
}

/*
 * Theme photographs (Pexels licence) and open fonts (SIL OFL) are binary files.
 * If they are missing from the checkout they are fetched once before the first build,
 * after which the app itself never needs the network to render its interface.
 */
val bundledAssets = mapOf(
    "src/main/res/drawable-nodpi/theme_aurora.jpg" to "https://images.pexels.com/photos/15487406/pexels-photo-15487406.jpeg?auto=compress&cs=tinysrgb&w=1000&h=650&fit=crop",
    "src/main/res/drawable-nodpi/theme_ocean.jpg" to "https://images.pexels.com/photos/17598831/pexels-photo-17598831.jpeg?auto=compress&cs=tinysrgb&w=1000&h=650&fit=crop",
    "src/main/res/drawable-nodpi/theme_sunset.jpg" to "https://images.pexels.com/photos/27454939/pexels-photo-27454939.jpeg?auto=compress&cs=tinysrgb&w=1000&h=650&fit=crop",
    "src/main/res/drawable-nodpi/theme_emerald.jpg" to "https://images.pexels.com/photos/32414014/pexels-photo-32414014.jpeg?auto=compress&cs=tinysrgb&w=1000&h=650&fit=crop",
    "src/main/res/drawable-nodpi/theme_mono.jpg" to "https://images.pexels.com/photos/15958894/pexels-photo-15958894.jpeg?auto=compress&cs=tinysrgb&w=1000&h=650&fit=crop",
    "src/main/res/drawable-nodpi/theme_neon.jpg" to "https://images.pexels.com/photos/9498496/pexels-photo-9498496.jpeg?auto=compress&cs=tinysrgb&w=1000&h=650&fit=crop",
    "src/main/res/font/ibm_plex_sans_arabic_regular.ttf" to "https://fonts.gstatic.com/s/ibmplexsansarabic/v15/Qw3CZRtWPQCuHme67tEYUIx3Kh0PHR9N6bs6.ttf",
    "src/main/res/font/ibm_plex_sans_arabic_medium.ttf" to "https://fonts.gstatic.com/s/ibmplexsansarabic/v15/Qw3NZRtWPQCuHme67tEYUIx3Kh0PHR9N6YPO_9CT.ttf",
    "src/main/res/font/ibm_plex_sans_arabic_semibold.ttf" to "https://fonts.gstatic.com/s/ibmplexsansarabic/v15/Qw3NZRtWPQCuHme67tEYUIx3Kh0PHR9N6YPi-NCT.ttf",
    "src/main/res/font/ibm_plex_sans_arabic_bold.ttf" to "https://fonts.gstatic.com/s/ibmplexsansarabic/v15/Qw3NZRtWPQCuHme67tEYUIx3Kh0PHR9N6YOG-dCT.ttf",
    "src/main/res/font/outfit_semibold.ttf" to "https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4e6yC4E.ttf",
)

val fetchBundledAssets by tasks.registering {
    val root = layout.projectDirectory
    val wanted = bundledAssets
    outputs.files(wanted.keys.map { root.file(it) })
    doLast {
        wanted.forEach { (path, url) ->
            val target = root.file(path).asFile
            if (!target.exists() || target.length() == 0L) {
                target.parentFile.mkdirs()
                val connection = URI(url).toURL().openConnection()
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (JO-DON build)")
                connection.getInputStream().use { input -> target.outputStream().use { input.copyTo(it) } }
                logger.lifecycle("fetched ${target.name}")
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(fetchBundledAssets) }
