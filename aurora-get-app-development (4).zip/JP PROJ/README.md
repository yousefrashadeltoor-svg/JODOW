# 𝒥𝒪 DON — Android

تطبيق Android أصلي (Kotlin + Jetpack Compose Foundation فقط، بلا Material وبلا Firebase وبلا خادم وبلا قاعدة بيانات).
كل الحالة تُحفظ في ملف JSON واحد على الجهاز (`LocalStore`).

## البناء والتثبيت

```bash
# يحتاج JDK 17 و Android SDK (platform 35 + build-tools 35.0.0)
./gradlew :app:assembleDebug            # كل المعماريات
./gradlew :app:assembleDebug -PjoAbi=arm64-v8a   # APK أصغر لهواتف arm64
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

- أول بناء يجلب تلقائيًا صور الثيمات الست والخطوط (مهمة `fetchBundledAssets`) إن لم تكن موجودة، ثم تُضمَّن داخل الـAPK؛ التطبيق نفسه لا يحتاج شبكة لعرض واجهته.
- إن كان `gradle/wrapper/gradle-wrapper.jar` مفقودًا: افتح المشروع في Android Studio أو نفّذ `gradle wrapper --gradle-version 8.10.2`.
- على جهاز بذاكرة أقل من 4GB:
  `./gradlew assembleDebug -Dorg.gradle.jvmargs="-Xmx1150m -XX:MaxMetaspaceSize=420m" -Pkotlin.compiler.execution.strategy=in-process --max-workers=1`
- بدون حاسوب: ارفع المجلد إلى GitHub وسيبني `.github/workflows/android.yml` ملف APK وتجده في Artifacts.

## الخريطة

| المسار | المحتوى |
|---|---|
| `engine/YouTubeEngine.kt` | تصفح يوتيوب عبر NewPipe Extractor: خلاصات، بحث واقتراحات، قنوات، Shorts، تعليقات، صيغ البث |
| `engine/NetworkAndExtractors.kt` | OkHttp، محلل الروابط، yt-dlp + FFmpeg + aria2c |
| `data/DownloadRepository.kt` | تحميل مجزّأ (8–32 اتصالًا) عبر `FileChannel`، استئناف بـ ETag/If-Range، خدمة أمامية وإشعارات |
| `data/LocalStore.kt` | الحالة المحلية وتصدير/استيراد الملف الشخصي JSON |
| `ui/screens/YouTubeScreen.kt` | واجهة يوتيوب الأصلية والمشغل والمشغل المصغّر وورقة التحميل |
| `ui/screens/LocalPlayerScreen.kt` | خدمة Media3، مشغل الفيديو والموسيقى، القص المرئي، نغمة الرنين |
| `ui/screens/Screens.kt` | الرئيسية، التحميلات، المكتبة، الأدوات، الإعدادات |
| `ui/components/Glass.kt`, `ui/theme/` | نظام التصميم، الأيقونات المرسومة، الثيمات الست |

## ما تم التحقق منه وما لم يتم

تم فعليًا في بيئة البناء:
- `assembleDebug` ينجح وينتج APK موقّعًا بمفتاح debug (‎~75MB لـ arm64-v8a)، والحزمة `com.jodon.app`.
- لا توجد أصناف Material أو Room أو Firebase داخل ملفات dex.
- اختبار حي عبر `EngineTest`: اقتراحات البحث، البحث مع الصفحة التالية، قوائم Kiosk، صفحة قناة، التعليقات — كلها أعادت بيانات حقيقية من يوتيوب.
- اختبار تقسيم الأجزاء (`rangeWindows`).

لم يتم التحقق منه:
- **لم يُشغَّل الـAPK على هاتف أو محاكي** (غير متاح في بيئة البناء). الواجهة والمشغل والخدمات مُصرَّفة ومفحوصة ككود فقط.
- **استخراج روابط البث (التشغيل والتحميل من يوتيوب) لم يكتمل هنا**: يوتيوب ردّ على عنوان الخادم بـ «Sign in to confirm you're not a bot». هذا الحظر شائع على عناوين مراكز البيانات، لكن نجاحه على شبكتك يجب أن تجرّبه بنفسك.
- بناء release (R8 + توقيع بمفتاحك) لم يُجرَّب.

## حدود معروفة

- ليست «تجربة يوتيوب الأصلية 100%»: لا حساب Google، والاشتراكات والإعجابات والسجل محلية، والاقتراحات تُحسب على الجهاز من سجلّك واشتراكاتك وبحثك، وخلاصة Shorts تُجمع من تبويبات Shorts للقنوات المشترَك بها ومن نتائج البحث القصيرة.
- يوتيوب يغيّر واجهاته باستمرار؛ عند تعطل الاستخراج حدّث `newpipe` في `gradle/libs.versions.toml`، ويحدّث التطبيق yt-dlp تلقائيًا مرة يوميًا.
- المتصفح الداخلي يعتمد WebView بطبيعته (هو متصفح)، وحجب الإعلانات فيه قائمة نطاقات أساسية وليس adblock-rust.
- غير منفَّذ من المواصفة الأولى: Cronet/HTTP3، Work-Stealing، القبو المشفّر بالبصمة، Widget و Quick Settings Tile، Torrent، ماسح QR، ضغط الفيديو مع VMAF، محوّل الصيغ العام (المتاح: MP3 عبر yt-dlp، ضغط الصور WebP، قص بلا إعادة ترميز).
- القص يبدأ عند أقرب إطار مفتاحي، وبعض الترميزات (مثل MP3 داخل MP4) قد يرفضها `MediaMuxer` برسالة واضحة دون مسّ الأصل.

## حقوق النشر

حمّل فقط ما تملك حق تنزيله. لا يوجد أي تجاوز لـ DRM أو Paywalls. تنزيل محتوى يوتيوب قد يخالف شروط خدمته، والمسؤولية على المستخدم.
