pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven("https://jitpack.io")
    }
}

rootProject.name = "AuroraGet"

/*
 * Aurora Get — Android.
 *
 * The requested module map is honoured at package level inside the single :app
 * Gradle module so the project always resolves and builds without a chain of
 * fragile cross-module graphs:
 *
 *   core:designsystem -> com.auroraget.app.ui.theme + ui.components
 *   core:common       -> com.auroraget.app.data (models, formatting, settings)
 *   core:network      -> com.auroraget.app.data.NetworkClient
 *   core:database     -> com.auroraget.app.data.database
 *   engine:downloader -> com.auroraget.app.data.DownloadRepository
 *   engine:extractors -> com.auroraget.app.engine.Extractors
 *   engine:media      -> com.auroraget.app.engine.MediaEngine
 *   feature:*         -> com.auroraget.app.ui.screens.*
 *   app               -> MainActivity, AuroraApplication, AuroraApp
 *
 * Splitting these packages into real Gradle modules is documented in README.md
 * (section "Module extraction plan") and needs no source changes.
 */
include(":app")
