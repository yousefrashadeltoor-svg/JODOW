package com.jodon.core.designsystem

import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.RuntimeShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.sin

enum class JoDonGlyph {
    HOME, YOUTUBE, SHORTS, DOWNLOAD, PLAYER, MUSIC, BROWSER, TOOLS, LIBRARY, SETTINGS,
    SPARKLES, LINK, CLIPBOARD, CLOSE, CHECK, PAUSE, PLAY, STOP, RETRY, FOLDER, VIDEO,
    IMAGE, FILE, SHIELD, LOCK, WIFI, BOLT, CLOCK, EDIT, SHARE, COPY, MORE, TRASH,
    REFRESH, COMPRESS, CONVERT, FINGERPRINT, PLUS, SCAN, MERGE, INFO, ARROW_LEFT,
    ARROW_RIGHT, MOON, SUN, SEARCH, USER, HEART, SCISSORS, BELL_RING, REPEAT, TIMER,
    WAVEFORM, SLIDERS
}

private const val MESH_AGSL = """
uniform float phase;
uniform float width;
uniform float height;
uniform vec3 colorA;
uniform vec3 colorB;
uniform vec3 colorC;
half4 main(float2 coord) {
    float2 uv = coord / float2(max(width, 1.0), max(height, 1.0));
    float2 p1 = float2(0.22 + 0.18 * sin(phase * 6.2831), 0.18 + 0.14 * cos(phase * 6.2831));
    float2 p2 = float2(0.82 - 0.16 * cos(phase * 6.2831), 0.58 + 0.18 * sin(phase * 6.2831));
    float2 p3 = float2(0.45, 0.90 - 0.12 * cos(phase * 4.2));
    float a = 0.40 / (0.18 + distance(uv, p1));
    float b = 0.36 / (0.20 + distance(uv, p2));
    float c = 0.25 / (0.24 + distance(uv, p3));
    vec3 col = (colorA * a + colorB * b + colorC * c) * 0.22;
    return half4(col, 1.0);
}
"""

@Composable
fun MeshBackground() {
    val theme = JoDonDesign.theme
    val transition = rememberInfiniteTransition(label = "mesh")
    val phase by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(theme.motion.meshPeriodMs, easing = LinearEasing), RepeatMode.Reverse),
        label = "meshPhase"
    )
    val shader = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) RuntimeShader(MESH_AGSL) else null
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(theme.background)
            .drawWithCache {
                onDrawBehind {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && shader != null) {
                        shader.setFloatUniform("phase", phase)
                        shader.setFloatUniform("width", size.width)
                        shader.setFloatUniform("height", size.height)
                        shader.setFloatUniform("colorA", theme.accent1.red, theme.accent1.green, theme.accent1.blue)
                        shader.setFloatUniform("colorB", theme.accent2.red, theme.accent2.green, theme.accent2.blue)
                        shader.setFloatUniform("colorC", theme.accent3.red, theme.accent3.green, theme.accent3.blue)
                        drawRect(ShaderBrush(shader))
                    } else {
                        drawCircle(
                            Brush.radialGradient(listOf(theme.accent1.copy(alpha = 0.26f), Color.Transparent)),
                            radius = size.maxDimension * 0.55f,
                            center = Offset(size.width * (0.2f + 0.2f * phase), size.height * 0.15f)
                        )
                        drawCircle(
                            Brush.radialGradient(listOf(theme.accent2.copy(alpha = 0.22f), Color.Transparent)),
                            radius = size.maxDimension * 0.52f,
                            center = Offset(size.width * (0.85f - 0.2f * phase), size.height * 0.65f)
                        )
                    }
                }
            }
    )
}

@Composable
fun Modifier.jodonPress(onClick: () -> Unit, haptics: Boolean = true): Modifier {
    val motion = JoDonDesign.theme.motion
    var pressed by remember { mutableStateOf(false) }
    val scaleVal by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(dampingRatio = motion.springDamping, stiffness = motion.springStiffness * 2f),
        label = "press"
    )
    val view = LocalView.current
    return this
        .scale(scaleVal)
        .pointerInput(onClick) {
            detectTapGestures(
                onPress = {
                    pressed = true
                    if (haptics) view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    tryAwaitRelease()
                    pressed = false
                },
                onTap = { onClick() }
            )
        }
}

@Composable
fun Modifier.jodonGlass(shape: RoundedCornerShape = JoDonDesign.shapes.large): Modifier {
    val theme = JoDonDesign.theme
    return this
        .clip(shape)
        .background(theme.glassBrush, shape)
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(alpha = 0.30f), theme.border, Color.White.copy(alpha = 0.06f))),
            shape
        )
}

@Composable
fun Modifier.sweepGlow(active: Boolean): Modifier {
    val theme = JoDonDesign.theme
    val transition = rememberInfiniteTransition(label = "sweep")
    val phase by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(if (active) theme.motion.glowPeriodMs else theme.motion.glowPeriodMs * 2, easing = LinearEasing)),
        label = "sweepPhase"
    )
    return this.drawWithCache {
        onDrawBehind {
            drawRoundRect(
                brush = Brush.sweepGradient(
                    listOf(theme.accent1, theme.accent2, theme.accent3, theme.accent1),
                    center = Offset(size.width * phase, size.height * 0.5f)
                ),
                cornerRadius = CornerRadius(theme.cardCornerDp.dp.toPx()),
                alpha = if (active) 0.42f else 0.14f,
                style = Stroke(width = 2.5.dp.toPx())
            )
        }
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape = JoDonDesign.shapes.large,
    content: @Composable BoxScope.() -> Unit
) {
    Box(modifier = modifier.jodonGlass(shape).padding(14.dp), content = content)
}

@Composable
fun JoDonIcon(
    glyph: JoDonGlyph,
    contentDescription: String? = null,
    modifier: Modifier = Modifier.size(18.dp),
    tint: Color = JoDonDesign.theme.text
) {
    Canvas(modifier.semantics { if (contentDescription != null) this.contentDescription = contentDescription }) {
        val s = size.minDimension / 24f
        val st = Stroke(width = 1.8f * s, cap = StrokeCap.Round)
        fun ln(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(tint, Offset(x1 * s, y1 * s), Offset(x2 * s, y2 * s), st.width, StrokeCap.Round)
        fun circ(x: Float, y: Float, r: Float) = drawCircle(tint, r * s, Offset(x * s, y * s), style = st)
        fun rrect(x: Float, y: Float, w: Float, h: Float, rad: Float = 3f) =
            drawRoundRect(tint, Offset(x * s, y * s), Size(w * s, h * s), CornerRadius(rad * s), style = st)
        fun poly(pts: List<Pair<Float, Float>>, fill: Boolean = false) {
            val p = Path().apply {
                pts.forEachIndexed { i, (x, y) -> if (i == 0) moveTo(x * s, y * s) else lineTo(x * s, y * s) }
                close()
            }
            if (fill) drawPath(p, tint) else drawPath(p, tint, style = st)
        }
        when (glyph) {
            JoDonGlyph.YOUTUBE -> {
                drawRoundRect(Color(0xFFFF0033), Offset(2f * s, 5f * s), Size(20f * s, 14f * s), CornerRadius(4.5f * s))
                val tri = Path().apply { moveTo(10f * s, 8.5f * s); lineTo(16f * s, 12f * s); lineTo(10f * s, 15.5f * s); close() }
                drawPath(tri, Color.White)
            }
            JoDonGlyph.SHORTS -> {
                rrect(6f, 3f, 12f, 18f, 4f)
                poly(listOf(10f to 8.5f, 15.5f to 12f, 10f to 15.5f), fill = true)
            }
            JoDonGlyph.HOME -> { poly(listOf(3.5f to 10.5f, 12f to 3.5f, 20.5f to 10.5f)); rrect(6f, 10f, 12f, 10.5f, 2f) }
            JoDonGlyph.DOWNLOAD -> { ln(12f, 3.5f, 12f, 15f); ln(7.5f, 10.5f, 12f, 15f); ln(16.5f, 10.5f, 12f, 15f); ln(4.5f, 19.5f, 19.5f, 19.5f) }
            JoDonGlyph.PLAYER, JoDonGlyph.PLAY -> poly(listOf(7.5f to 5f, 19f to 12f, 7.5f to 19f), fill = true)
            JoDonGlyph.PAUSE -> { rrect(6.5f, 5f, 3.8f, 14f, 1.5f); rrect(13.7f, 5f, 3.8f, 14f, 1.5f) }
            JoDonGlyph.STOP -> rrect(6f, 6f, 12f, 12f, 2.5f)
            JoDonGlyph.MUSIC -> { ln(9f, 18f, 9f, 6f); ln(9f, 6f, 19f, 4.5f); ln(19f, 4.5f, 19f, 16f); circ(6.2f, 18f, 2.6f); circ(16.2f, 16f, 2.6f) }
            JoDonGlyph.BROWSER -> { circ(12f, 12f, 8.5f); ln(3.5f, 12f, 20.5f, 12f); ln(12f, 3.5f, 12f, 20.5f) }
            JoDonGlyph.TOOLS, JoDonGlyph.SLIDERS -> { ln(4f, 7f, 20f, 7f); ln(4f, 17f, 20f, 17f); circ(9f, 7f, 2.3f); circ(15f, 17f, 2.3f) }
            JoDonGlyph.LIBRARY, JoDonGlyph.FOLDER -> rrect(3.5f, 5.5f, 17f, 14f, 3f)
            JoDonGlyph.SETTINGS -> { circ(12f, 12f, 3.2f); circ(12f, 12f, 8.2f) }
            JoDonGlyph.SEARCH -> { circ(10.5f, 10.5f, 6.2f); ln(15.2f, 15.2f, 20f, 20f) }
            JoDonGlyph.USER -> { circ(12f, 8f, 3.8f); rrect(5f, 14f, 14f, 6.5f, 3.2f) }
            JoDonGlyph.HEART -> { circ(9f, 9.5f, 3.5f); circ(15f, 9.5f, 3.5f); poly(listOf(5.8f to 11f, 18.2f to 11f, 12f to 19.5f)) }
            JoDonGlyph.SCISSORS -> { circ(6.5f, 7.5f, 2.6f); circ(6.5f, 16.5f, 2.6f); ln(8.8f, 9f, 19.5f, 18f); ln(8.8f, 15f, 19.5f, 6f) }
            JoDonGlyph.BELL_RING -> { rrect(6f, 6f, 12f, 10f, 5f); ln(4f, 16f, 20f, 16f); circ(12f, 18.8f, 1.5f) }
            JoDonGlyph.REPEAT -> { rrect(4.5f, 6.5f, 15f, 11f, 4f); ln(15f, 4f, 18f, 6.5f) }
            JoDonGlyph.TIMER, JoDonGlyph.CLOCK -> { circ(12f, 12.5f, 8f); ln(12f, 8f, 12f, 12.5f); ln(12f, 12.5f, 15.5f, 14.5f) }
            JoDonGlyph.WAVEFORM -> { ln(4f, 12f, 4f, 12f); ln(8f, 7f, 8f, 17f); ln(12f, 4f, 12f, 20f); ln(16f, 8f, 16f, 16f); ln(20f, 10f, 20f, 14f) }
            JoDonGlyph.COPY -> { rrect(8f, 8f, 11.5f, 11.5f, 2.5f); rrect(4.5f, 4.5f, 11.5f, 11.5f, 2.5f) }
            JoDonGlyph.SHARE -> { circ(18f, 5.5f, 2.3f); circ(6f, 12f, 2.3f); circ(18f, 18.5f, 2.3f); ln(8.2f, 10.8f, 15.8f, 6.6f); ln(8.2f, 13.2f, 15.8f, 17.4f) }
            JoDonGlyph.LINK -> { ln(9f, 15f, 15f, 9f); circ(8.5f, 15.5f, 3.8f); circ(15.5f, 8.5f, 3.8f) }
            JoDonGlyph.CLIPBOARD -> { rrect(6f, 4.5f, 12f, 16f, 2.8f); ln(9.5f, 10.5f, 14.5f, 10.5f); ln(9.5f, 14.5f, 13f, 14.5f) }
            JoDonGlyph.CLOSE -> { ln(6f, 6f, 18f, 18f); ln(18f, 6f, 6f, 18f) }
            JoDonGlyph.CHECK -> { ln(5f, 12.5f, 9.5f, 17f); ln(9.5f, 17f, 19f, 7.5f) }
            JoDonGlyph.PLUS -> { ln(12f, 5f, 12f, 19f); ln(5f, 12f, 19f, 12f) }
            JoDonGlyph.SPARKLES -> poly(listOf(12f to 3f, 14f to 9f, 20f to 11f, 14f to 13f, 12f to 19f, 10f to 13f, 4f to 11f, 10f to 9f))
            JoDonGlyph.VIDEO -> { rrect(3f, 5.5f, 13f, 13f, 3f); poly(listOf(16f to 10.5f, 21f to 7.5f, 21f to 16.5f)) }
            JoDonGlyph.IMAGE -> { rrect(3.5f, 4.5f, 17f, 15f, 3f); circ(8.5f, 9.5f, 1.6f); ln(4.5f, 17f, 10f, 12.5f); ln(10f, 12.5f, 19.5f, 17f) }
            JoDonGlyph.FILE -> { rrect(5.5f, 3.5f, 13f, 17f, 2.5f); ln(8.5f, 11f, 15.5f, 11f); ln(8.5f, 15f, 13.5f, 15f) }
            JoDonGlyph.SHIELD -> poly(listOf(12f to 3f, 19.5f to 6f, 19.5f to 12f, 12f to 21f, 4.5f to 12f, 4.5f to 6f))
            JoDonGlyph.LOCK -> { rrect(5f, 10.5f, 14f, 9.5f, 3f); circ(12f, 8f, 3.2f) }
            JoDonGlyph.FINGERPRINT -> { circ(12f, 11f, 6.5f); circ(12f, 11.5f, 3.5f); ln(12f, 11.5f, 12f, 20f) }
            JoDonGlyph.ARROW_LEFT -> { ln(19f, 12f, 5f, 12f); ln(11f, 6f, 5f, 12f); ln(11f, 18f, 5f, 12f) }
            JoDonGlyph.ARROW_RIGHT -> { ln(5f, 12f, 19f, 12f); ln(13f, 6f, 19f, 12f); ln(13f, 18f, 19f, 12f) }
            else -> circ(12f, 12f, 7f)
        }
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, glyph: JoDonGlyph? = null) {
    val theme = JoDonDesign.theme
    Row(
        modifier = modifier
            .clip(JoDonDesign.shapes.medium)
            .background(theme.auroraBrush)
            .border(1.dp, Color.White.copy(alpha = 0.25f), JoDonDesign.shapes.medium)
            .jodonPress(onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (glyph != null) {
            JoDonIcon(glyph, null, Modifier.size(16.dp), Color.White)
            Spacer(Modifier.width(8.dp))
        }
        BasicText(text, style = JoDonDesign.typography.label.copy(color = Color.White))
    }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, glyph: JoDonGlyph? = null) {
    val theme = JoDonDesign.theme
    Row(
        modifier = modifier
            .clip(JoDonDesign.shapes.medium)
            .background(theme.glass)
            .border(1.dp, theme.border, JoDonDesign.shapes.medium)
            .jodonPress(onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (glyph != null) {
            JoDonIcon(glyph, null, Modifier.size(15.dp), theme.accent1)
            Spacer(Modifier.width(6.dp))
        }
        BasicText(text, style = JoDonDesign.typography.caption.copy(color = theme.text))
    }
}

@Composable
fun IconBtn(glyph: JoDonGlyph, desc: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val theme = JoDonDesign.theme
    Box(
        modifier
            .size(36.dp)
            .clip(JoDonDesign.shapes.small)
            .background(theme.glass)
            .border(1.dp, theme.border, JoDonDesign.shapes.small)
            .jodonPress(onClick),
        contentAlignment = Alignment.Center
    ) {
        JoDonIcon(glyph, desc, Modifier.size(17.dp), theme.text)
    }
}

@Composable
fun PillChip(text: String, active: Boolean = false, onClick: (() -> Unit)? = null, modifier: Modifier = Modifier) {
    val theme = JoDonDesign.theme
    val mod = modifier
        .clip(JoDonDesign.shapes.pill)
        .background(if (active) theme.auroraBrush else Brush.linearGradient(listOf(theme.glass, theme.glass)))
        .border(1.dp, if (active) Color.Transparent else theme.border, JoDonDesign.shapes.pill)
        .then(if (onClick != null) Modifier.jodonPress(onClick) else Modifier)
        .padding(horizontal = 12.dp, vertical = 6.dp)
    Box(mod, contentAlignment = Alignment.Center) {
        BasicText(text, style = JoDonDesign.typography.caption.copy(color = if (active) Color.White else theme.text))
    }
}

@Composable
fun JoDonToggle(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val theme = JoDonDesign.theme
    val frac by animateFloatAsState(if (checked) 1f else 0f, spring(stiffness = theme.motion.springStiffness), label = "toggle")
    Box(
        Modifier
            .size(42.dp, 24.dp)
            .clip(JoDonDesign.shapes.pill)
            .background(if (checked) theme.auroraBrush else Brush.linearGradient(listOf(theme.glass, theme.glass)))
            .border(1.dp, theme.border, JoDonDesign.shapes.pill)
            .jodonPress({ onCheckedChange(!checked) })
    ) {
        Box(
            Modifier
                .offset(x = (3 + 18 * frac).dp)
                .size(16.dp)
                .clip(JoDonDesign.shapes.pill)
                .background(Color.White)
                .align(Alignment.CenterStart)
        )
    }
}

@Composable
fun ProgressBar(progress: Float, modifier: Modifier = Modifier) {
    val theme = JoDonDesign.theme
    Box(modifier.height(7.dp).clip(JoDonDesign.shapes.pill).background(theme.glass)) {
        Box(
            Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .height(7.dp)
                .clip(JoDonDesign.shapes.pill)
                .background(theme.auroraBrush)
        )
    }
}

@Composable
fun JoDonSlider(value: Float, onValueChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val theme = JoDonDesign.theme
    val clamped = value.coerceIn(0f, 1f)
    Canvas(
        modifier
            .height(28.dp)
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, _ ->
                    onValueChange((change.position.x / size.width.coerceAtLeast(1)).coerceIn(0f, 1f))
                }
            }
    ) {
        val y = size.height / 2f
        drawLine(theme.glassStrong, Offset(0f, y), Offset(size.width, y), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)
        drawLine(theme.accent1, Offset(0f, y), Offset(size.width * clamped, y), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)
        drawCircle(Color.White, radius = 8.dp.toPx(), center = Offset(size.width * clamped, y))
        drawCircle(theme.accent2, radius = 8.dp.toPx(), center = Offset(size.width * clamped, y), style = Stroke(2.5.dp.toPx()))
    }
}

/**
 * Interactive tactile dual-handle visual waveform trimmer (NO number typing required).
 * Users drag the Start Handle, End Handle, or Playhead directly over the real audio waveform.
 */
@Composable
fun VisualWaveformTrimmer(
    amplitudes: List<Float>,
    startFraction: Float,
    endFraction: Float,
    playheadFraction: Float,
    onRangeChange: (Float, Float) -> Unit,
    onScrub: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = JoDonDesign.theme
    val view = LocalView.current
    var dragTarget by remember { mutableStateOf(0) } // 1 = start, 2 = end, 3 = playhead
    Canvas(
        modifier
            .fillMaxWidth()
            .height(92.dp)
            .clip(JoDonDesign.shapes.medium)
            .background(theme.surface)
            .border(1.dp, theme.border, JoDonDesign.shapes.medium)
            .pointerInput(startFraction, endFraction) {
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        val f = (offset.x / size.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                        dragTarget = when {
                            kotlin.math.abs(f - startFraction) < 0.07f -> 1
                            kotlin.math.abs(f - endFraction) < 0.07f -> 2
                            else -> 3
                        }
                        view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    }
                ) { change, _ ->
                    val f = (change.position.x / size.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                    when (dragTarget) {
                        1 -> onRangeChange(f.coerceAtMost(endFraction - 0.03f), endFraction)
                        2 -> onRangeChange(startFraction, f.coerceAtLeast(startFraction + 0.03f))
                        else -> onScrub(f.coerceIn(startFraction, endFraction))
                    }
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val sx = w * startFraction
        val ex = w * endFraction
        // Selected active region highlight
        drawRect(theme.accent1.copy(alpha = 0.16f), topLeft = Offset(sx, 0f), size = Size((ex - sx).coerceAtLeast(2f), h))
        val bars = if (amplitudes.isEmpty()) List(64) { i -> 0.25f + 0.5f * kotlin.math.abs(sin(i * 0.35f)) } else amplitudes
        val step = w / bars.size.coerceAtLeast(1)
        bars.forEachIndexed { i, amp ->
            val x = i * step + step / 2f
            val inside = x in sx..ex
            val barH = (amp.coerceIn(0.08f, 1f) * (h * 0.72f))
            drawLine(
                color = if (inside) theme.accent1 else theme.muted.copy(alpha = 0.32f),
                start = Offset(x, (h - barH) / 2f),
                end = Offset(x, (h + barH) / 2f),
                strokeWidth = (step * 0.58f).coerceAtLeast(2f),
                cap = StrokeCap.Round
            )
        }
        // Playhead
        val px = w * playheadFraction.coerceIn(0f, 1f)
        drawLine(Color.White, Offset(px, 4f), Offset(px, h - 4f), strokeWidth = 2.dp.toPx())
        // Left & Right tactile handles
        drawRoundRect(theme.accent2, Offset(sx - 6.dp.toPx(), 0f), Size(12.dp.toPx(), h), CornerRadius(6.dp.toPx()))
        drawRoundRect(theme.accent3, Offset(ex - 6.dp.toPx(), 0f), Size(12.dp.toPx(), h), CornerRadius(6.dp.toPx()))
    }
}

/** Realistic Photograph Theme Card in Theme Picker. */
@Composable
fun ThemePhotoCard(
    spec: JoDonThemeSpec,
    selected: Boolean,
    isArabic: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier
            .fillMaxWidth()
            .height(112.dp)
            .clip(JoDonDesign.shapes.large)
            .border(
                width = if (selected) 2.5.dp else 1.dp,
                brush = if (selected) spec.auroraBrush else Brush.linearGradient(listOf(spec.border, spec.border)),
                shape = JoDonDesign.shapes.large
            )
            .jodonPress(onSelect)
    ) {
        Image(
            painter = painterResource(spec.previewRes),
            contentDescription = if (isArabic) spec.nameAr else spec.nameEn,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC060810))))
        )
        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BasicText(
                    if (isArabic) spec.nameAr else spec.nameEn,
                    style = JoDonDesign.typography.title.copy(color = Color.White)
                )
                if (selected) {
                    Spacer(Modifier.width(8.dp))
                    PillChip(if (isArabic) "مفعّل" else "Active", active = true)
                }
            }
            BasicText(
                if (isArabic) spec.descAr else spec.descEn,
                style = JoDonDesign.typography.caption.copy(color = Color(0xDDE2E8F0))
            )
        }
    }
}

@Composable
fun GradientTitle(text: String, style: TextStyle = JoDonDesign.typography.headline) {
    BasicText(text = text, style = style.copy(brush = JoDonDesign.theme.auroraBrush))
}

@Composable
fun GlassBottomSheet(
    visible: Boolean,
    title: String,
    onDismiss: () -> Unit,
    content: @Composable () -> Unit
) {
    val theme = JoDonDesign.theme
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible = visible, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.6f))
                    .pointerInput(Unit) { detectTapGestures { onDismiss() } }
            )
        }
        AnimatedVisibility(
            visible = visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = theme.motion.springDamping, stiffness = theme.motion.springStiffness)) { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .jodonGlass(JoDonDesign.shapes.sheet)
                    .background(theme.surface.copy(alpha = 0.88f))
                    .padding(18.dp)
            ) {
                Box(
                    Modifier
                        .size(44.dp, 4.dp)
                        .clip(JoDonDesign.shapes.pill)
                        .background(theme.border)
                        .align(Alignment.CenterHorizontally)
                )
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BasicText(title, Modifier.weight(1f), style = JoDonDesign.typography.title)
                    IconBtn(JoDonGlyph.CLOSE, "Close", onDismiss)
                }
                Spacer(Modifier.height(12.dp))
                content()
            }
        }
    }
}

data class DockDestination(val id: String, val label: String, val glyph: JoDonGlyph)

@Composable
fun FloatingDock(
    items: List<DockDestination>,
    selectedId: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = JoDonDesign.theme
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(66.dp)
            .jodonGlass(JoDonDesign.shapes.squircle)
            .background(theme.surface.copy(alpha = 0.72f))
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { item ->
            val selected = item.id == selectedId
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(JoDonDesign.shapes.medium)
                    .background(if (selected) theme.accent1.copy(alpha = 0.22f) else Color.Transparent)
                    .jodonPress({ onSelect(item.id) })
                    .padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                JoDonIcon(
                    item.glyph,
                    item.label,
                    Modifier.size(20.dp),
                    if (selected) theme.accent1 else theme.muted
                )
                Spacer(Modifier.height(2.dp))
                BasicText(
                    item.label,
                    style = JoDonDesign.typography.caption.copy(
                        color = if (selected) theme.text else theme.muted,
                        textAlign = TextAlign.Center
                    )
                )
            }
        }
    }
}
