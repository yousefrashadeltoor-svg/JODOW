package com.jodon.core.designsystem

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Immutable
data class JoDonMotionSpec(
    val springStiffness: Float,
    val springDamping: Float,
    val glowPeriodMs: Int,
    val meshPeriodMs: Int,
    val transitionDurationMs: Int
)

@Immutable
data class JoDonThemeSpec(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val descAr: String,
    val descEn: String,
    @DrawableRes val previewRes: Int,
    val background: Color,
    val surface: Color,
    val glass: Color,
    val glassStrong: Color,
    val border: Color,
    val text: Color,
    val muted: Color,
    val accent1: Color,
    val accent2: Color,
    val accent3: Color,
    val accent4: Color,
    val success: Color,
    val warning: Color,
    val danger: Color,
    val cardCornerDp: Int,
    val motion: JoDonMotionSpec
) {
    val auroraBrush: Brush get() = Brush.linearGradient(listOf(accent1, accent2, accent3))
    val glassBrush: Brush get() = Brush.linearGradient(listOf(glassStrong, glass, glass.copy(alpha = glass.alpha * 0.65f)))
}

@Immutable
data class JoDonShapes(
    val small: RoundedCornerShape,
    val medium: RoundedCornerShape,
    val large: RoundedCornerShape,
    val squircle: RoundedCornerShape,
    val sheet: RoundedCornerShape,
    val pill: RoundedCornerShape = RoundedCornerShape(50)
)

@Immutable
data class JoDonTypography(
    val display: TextStyle,
    val headline: TextStyle,
    val title: TextStyle,
    val body: TextStyle,
    val label: TextStyle,
    val caption: TextStyle,
    val numeric: TextStyle
)

object JoDonThemes {
    fun all(light: Boolean = false, animScale: Float = 1f): List<JoDonThemeSpec> = listOf(
        buildTheme(
            id = "aurora",
            nameAr = "أورورا القطب",
            nameEn = "Arctic Aurora",
            descAr = "شفق قطبي متموج بفيزياء ناعمة وتوهج زجاجي عميق",
            descEn = "Flowing polar ribbons with silky spring physics & deep glass",
            previewRes = R.drawable.theme_aurora,
            darkBg = Color(0xFF070912), darkSurface = Color(0xFF121728),
            a1 = Color(0xFF4285F4), a2 = Color(0xFF9B72CB), a3 = Color(0xFFD96570), a4 = Color(0xFF45D6C5),
            cornerDp = 28, light = light,
            motion = JoDonMotionSpec(Spring.StiffnessMediumLow, Spring.DampingRatioLowBouncy, (4800 / animScale).toInt().coerceAtLeast(1200), 9000, 380)
        ),
        buildTheme(
            id = "sahara",
            nameAr = "غسق الصحراء الذهبي",
            nameEn = "Sahara Golden Dusk",
            descAr = "كثبان العنبر والذهب مع زجاج دافئ وحركة انسيابية هادئة",
            descEn = "Warm amber dunes, gilded borders & calm desert motion",
            previewRes = R.drawable.theme_sahara,
            darkBg = Color(0xFF120C08), darkSurface = Color(0xFF211610),
            a1 = Color(0xFFF59E0B), a2 = Color(0xFFEC4899), a3 = Color(0xFFFBBF24), a4 = Color(0xFFFB7185),
            cornerDp = 26, light = light,
            motion = JoDonMotionSpec(Spring.StiffnessLow, Spring.DampingRatioNoBouncy, (6200 / animScale).toInt().coerceAtLeast(1500), 11000, 440)
        ),
        buildTheme(
            id = "ocean",
            nameAr = "أعماق المحيط المضيئة",
            nameEn = "Bioluminescent Ocean",
            descAr = "أمواج السيان الكهربائي والياقوت الأزرق بحواف بلورية",
            descEn = "Electric cyan waves & sapphire crystal glass reflections",
            previewRes = R.drawable.theme_ocean,
            darkBg = Color(0xFF040D17), darkSurface = Color(0xFF0B1C2E),
            a1 = Color(0xFF06B6D4), a2 = Color(0xFF3B82F6), a3 = Color(0xFF6366F1), a4 = Color(0xFF2DD4BF),
            cornerDp = 30, light = light,
            motion = JoDonMotionSpec(Spring.StiffnessMedium, Spring.DampingRatioLowBouncy, (4200 / animScale).toInt().coerceAtLeast(1200), 7500, 340)
        ),
        buildTheme(
            id = "sakura",
            nameAr = "ليالي الساكورا القرمزية",
            nameEn = "Crimson Sakura Nocturne",
            descAr = "أزهار الكرز الليلية تحت المطر مع استجابة نابضة فورية",
            descEn = "Rain-kissed Kyoto blossoms with snappy tactile bounce",
            previewRes = R.drawable.theme_sakura,
            darkBg = Color(0xFF130811), darkSurface = Color(0xFF241120),
            a1 = Color(0xFFF43F5E), a2 = Color(0xFFD946EF), a3 = Color(0xFFFB7185), a4 = Color(0xFFA855F7),
            cornerDp = 32, light = light,
            motion = JoDonMotionSpec(Spring.StiffnessMedium, Spring.DampingRatioMediumBouncy, (3800 / animScale).toInt().coerceAtLeast(1100), 8000, 320)
        ),
        buildTheme(
            id = "emerald",
            nameAr = "ضباب الغابة الزمردية",
            nameEn = "Emerald Mist Canopy",
            descAr = "أشعة الصباح عبر الضباب الزمردي بتوازن بصري مريح للعين",
            descEn = "Sunbeams over mossy jade mist with soothing organic motion",
            previewRes = R.drawable.theme_emerald,
            darkBg = Color(0xFF05110D), darkSurface = Color(0xFF0D221A),
            a1 = Color(0xFF10B981), a2 = Color(0xFF14B8A6), a3 = Color(0xFF84CC16), a4 = Color(0xFF34D399),
            cornerDp = 24, light = light,
            motion = JoDonMotionSpec(Spring.StiffnessLow, Spring.DampingRatioLowBouncy, (5600 / animScale).toInt().coerceAtLeast(1400), 10500, 400)
        ),
        buildTheme(
            id = "obsidian",
            nameAr = "تيتانيوم أوبسيديان AMOLED",
            nameEn = "Obsidian Titanium AMOLED",
            descAr = "سواد مطلق #000000 لتوفير البطارية مع معدن التيتانيوم المصقول",
            descEn = "True #000000 pitch-black AMOLED with crisp titanium precision",
            previewRes = R.drawable.theme_obsidian,
            darkBg = Color(0xFF000000), darkSurface = Color(0xFF0E1015),
            a1 = Color(0xFFE2E8F0), a2 = Color(0xFF94A3B8), a3 = Color(0xFF38BDF8), a4 = Color(0xFFF8FAFC),
            cornerDp = 22, light = light,
            motion = JoDonMotionSpec(Spring.StiffnessHigh, Spring.DampingRatioNoBouncy, (7000 / animScale).toInt().coerceAtLeast(1800), 12000, 240)
        )
    )

    fun resolve(id: String, light: Boolean, animScale: Float = 1f): JoDonThemeSpec =
        all(light, animScale).firstOrNull { it.id == id } ?: all(light, animScale).first()

    private fun buildTheme(
        id: String, nameAr: String, nameEn: String, descAr: String, descEn: String,
        @DrawableRes previewRes: Int, darkBg: Color, darkSurface: Color,
        a1: Color, a2: Color, a3: Color, a4: Color,
        cornerDp: Int, light: Boolean, motion: JoDonMotionSpec
    ): JoDonThemeSpec = JoDonThemeSpec(
        id = id, nameAr = nameAr, nameEn = nameEn, descAr = descAr, descEn = descEn,
        previewRes = previewRes,
        background = if (light) Color(0xFFF2F5FB) else darkBg,
        surface = if (light) Color(0xFFFFFFFF) else darkSurface,
        glass = if (light) Color(0xB8FFFFFF) else Color(0x18FFFFFF),
        glassStrong = if (light) Color(0xE0FFFFFF) else Color(0x29FFFFFF),
        border = if (light) Color(0x241B2A4E) else Color(0x30FFFFFF),
        text = if (light) Color(0xFF10172A) else Color(0xFFF4F6FF),
        muted = if (light) Color(0xFF56617F) else Color(0xFF95A0BE),
        accent1 = a1, accent2 = a2, accent3 = a3, accent4 = a4,
        success = Color(0xFF34D399), warning = Color(0xFFFBBF24), danger = Color(0xFFFB7185),
        cardCornerDp = cornerDp,
        motion = motion
    )
}

fun buildTypography(scale: Float, textColor: Color): JoDonTypography {
    val family = FontFamily.SansSerif
    fun style(sz: Int, weight: FontWeight, lh: Int) = TextStyle(
        fontFamily = family, fontWeight = weight,
        fontSize = (sz * scale).sp, lineHeight = (lh * scale).sp, color = textColor
    )
    return JoDonTypography(
        display = style(28, FontWeight.ExtraBold, 36),
        headline = style(21, FontWeight.ExtraBold, 28),
        title = style(15, FontWeight.Bold, 22),
        body = style(13, FontWeight.Normal, 20),
        label = style(12, FontWeight.SemiBold, 17),
        caption = style(10, FontWeight.Medium, 15),
        numeric = style(11, FontWeight.SemiBold, 16).copy(fontFamily = FontFamily.Monospace)
    )
}

val LocalJoDonTheme = staticCompositionLocalOf { JoDonThemes.resolve("aurora", false) }
val LocalJoDonShapes = staticCompositionLocalOf {
    JoDonShapes(
        small = RoundedCornerShape(14.dp),
        medium = RoundedCornerShape(20.dp),
        large = RoundedCornerShape(26.dp),
        squircle = RoundedCornerShape(30.dp),
        sheet = RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp)
    )
}
val LocalJoDonTypography = staticCompositionLocalOf { buildTypography(1f, Color.White) }

object JoDonDesign {
    val theme: JoDonThemeSpec @Composable get() = LocalJoDonTheme.current
    val shapes: JoDonShapes @Composable get() = LocalJoDonShapes.current
    val typography: JoDonTypography @Composable get() = LocalJoDonTypography.current
}

@Composable
fun JoDonTheme(
    themeId: String = "aurora",
    light: Boolean = false,
    fontScale: Float = 1f,
    animationScale: Float = 1f,
    content: @Composable () -> Unit
) {
    val spec = JoDonThemes.resolve(themeId, light, animationScale.coerceAtLeast(0.4f))
    val base = spec.cardCornerDp
    val shapes = JoDonShapes(
        small = RoundedCornerShape((base - 12).coerceAtLeast(10).dp),
        medium = RoundedCornerShape((base - 6).coerceAtLeast(14).dp),
        large = RoundedCornerShape(base.dp),
        squircle = RoundedCornerShape((base + 4).dp),
        sheet = RoundedCornerShape(topStart = (base + 6).dp, topEnd = (base + 6).dp)
    )
    CompositionLocalProvider(
        LocalJoDonTheme provides spec,
        LocalJoDonShapes provides shapes,
        LocalJoDonTypography provides buildTypography(fontScale, spec.text),
        content = content
    )
}
