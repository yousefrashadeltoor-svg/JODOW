package com.jodon.core.common

import androidx.compose.runtime.Immutable
import kotlinx.serialization.Serializable
import java.util.Locale

enum class MediaKind { VIDEO, AUDIO, IMAGE, DOCUMENT, ARCHIVE, APK, SUBTITLE, OTHER }
enum class DownloadStatus { QUEUED, ACTIVE, PAUSED, COMPLETED, FAILED, CANCELLED, SCHEDULED }
enum class RepeatModeType { OFF, ALL, ONE, AB_LOOP }
enum class VisualizerMode { SPECTRUM_BARS, LIQUID_WAVE, ORBIT_PULSE, PARTICLES, OFF }
enum class SizeSource {
    HEAD_CONTENT_LENGTH, RANGE_CONTENT_RANGE, MULTI_RANGE_PROBE,
    HLS_DASH_SEGMENTS, YTDLP_FILESIZE, YTDLP_FILESIZE_APPROX, LOCAL_FILE
}

@Immutable
@Serializable
data class SizeInfo(
    val bytes: Long,
    val exact: Boolean,
    val source: SizeSource
) {
    fun display(): String = (if (exact) "" else "≈ ") + humanBytes(bytes)
    fun exactDisplay(): String = String.format(Locale.US, "%,d bytes (%s)", bytes, humanBytes(bytes))
    operator fun plus(other: SizeInfo): SizeInfo = SizeInfo(
        bytes = bytes + other.bytes,
        exact = exact && other.exact,
        source = if (exact && other.exact) SizeSource.HEAD_CONTENT_LENGTH else SizeSource.YTDLP_FILESIZE_APPROX
    )
}

fun humanBytes(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    if (bytes < 1024L) return "$bytes B"
    val units = arrayOf("KiB", "MiB", "GiB", "TiB")
    var value = bytes.toDouble() / 1024.0
    var index = 0
    while (value >= 1024.0 && index < units.size - 1) {
        value /= 1024.0
        index++
    }
    return String.format(Locale.US, "%.2f %s", value, units[index])
}

fun formatDuration(seconds: Long): String {
    if (seconds <= 0L) return "0:00"
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return if (hrs > 0) String.format(Locale.US, "%d:%02d:%02d", hrs, mins, secs)
    else String.format(Locale.US, "%d:%02d", mins, secs)
}

@Immutable
@Serializable
data class MediaFormat(
    val id: String,
    val url: String,
    val kind: MediaKind,
    val label: String,
    val quality: String,
    val container: String,
    val codec: String,
    val fps: Int? = null,
    val bitrateKbps: Int? = null,
    val size: SizeInfo,
    val headers: Map<String, String> = emptyMap(),
    val needsMerge: Boolean = false,
    val bestAudio: MediaFormat? = null
) {
    fun resolvedSize(): SizeInfo = if (needsMerge && bestAudio != null) size + bestAudio.size else size
}

@Immutable
@Serializable
data class AnalysisResult(
    val url: String,
    val domain: String,
    val siteName: String = "",
    val faviconUrl: String = "",
    val title: String = "",
    val fileName: String = "",
    val thumbnailUrl: String = "",
    val durationSeconds: Long? = null,
    val uploader: String = "",
    val publishDate: String = "",
    val formats: List<MediaFormat> = emptyList(),
    val subtitles: List<MediaFormat> = emptyList(),
    val completedStages: Set<Int> = emptySet(),
    val directPage: Boolean = false
) {
    fun countFor(kind: MediaKind): Int = formats.count { it.kind == kind }
}

@Immutable
@Serializable
data class SegmentState(
    val taskId: String,
    val index: Int,
    val start: Long,
    val end: Long,
    val written: Long,
    val etag: String? = null,
    val lastModified: String? = null
)

@Immutable
@Serializable
data class DownloadTask(
    val id: String,
    val url: String,
    val fileName: String,
    val targetPath: String = "",
    val kind: MediaKind,
    val status: DownloadStatus,
    val priority: Int = 0,
    val loadedBytes: Long = 0,
    val totalBytes: Long = 0,
    val sizeExact: Boolean = true,
    val connections: Int = 16,
    val speedBps: Long = 0,
    val etaSeconds: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val scheduledAt: Long? = null,
    val headers: Map<String, String> = emptyMap(),
    val etag: String? = null,
    val lastModified: String? = null,
    val error: String? = null,
    val speedHistory: List<Long> = emptyList(),
    val mergeAudioUrl: String? = null
) {
    val progress: Float get() = if (totalBytes <= 0L) 0f else (loadedBytes.toFloat() / totalBytes).coerceIn(0f, 1f)
    fun displaySize(): String = (if (sizeExact) "" else "≈ ") + humanBytes(totalBytes)
}

@Immutable
@Serializable
data class YouTubeVideoItem(
    val videoId: String,
    val title: String,
    val channelId: String,
    val channelName: String,
    val channelAvatar: String = "",
    val thumbnailUrl: String,
    val durationSeconds: Long = 0L,
    val viewCountText: String = "",
    val publishedText: String = "",
    val isShort: Boolean = false,
    val tags: List<String> = emptyList()
) {
    val watchUrl: String get() = if (isShort) "https://www.youtube.com/shorts/$videoId" else "https://www.youtube.com/watch?v=$videoId"
}

@Immutable
@Serializable
data class FollowedChannel(
    val channelId: String,
    val name: String,
    val avatarUrl: String = "",
    val subscriberText: String = "",
    val followedAt: Long = System.currentTimeMillis()
)

@Immutable
@Serializable
data class LocalYouTubePlaylist(
    val id: String,
    val title: String,
    val videos: List<YouTubeVideoItem> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
)

@Immutable
@Serializable
data class LocalYouTubeProfileBundle(
    val displayName: String = "JoDon User",
    val handle: String = "@jodon_local",
    val bio: String = "",
    val avatarUri: String = "",
    val historyPaused: Boolean = false,
    val followedChannels: List<FollowedChannel> = emptyList(),
    val watchHistory: List<YouTubeVideoItem> = emptyList(),
    val likedVideos: List<YouTubeVideoItem> = emptyList(),
    val watchLater: List<YouTubeVideoItem> = emptyList(),
    val playlists: List<LocalYouTubePlaylist> = emptyList(),
    val searchHistory: List<String> = emptyList(),
    val topicWeights: Map<String, Double> = emptyMap(),
    val channelWeights: Map<String, Double> = emptyMap()
)

@Immutable
@Serializable
data class LocalMediaItem(
    val uriString: String,
    val path: String = "",
    val title: String,
    val artist: String = "",
    val album: String = "",
    val folderName: String = "",
    val durationMs: Long = 0L,
    val sizeBytes: Long = 0L,
    val isVideo: Boolean = false,
    val width: Int = 0,
    val height: Int = 0,
    val dateModifiedSec: Long = 0L
)

@Immutable
@Serializable
data class LocalMusicPlaylist(
    val id: String,
    val name: String,
    val trackUris: List<String> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
)

@Immutable
@Serializable
data class AppSettings(
    val themeId: String = "aurora",
    val lightTheme: Boolean = false,
    val animationScale: Float = 1f,
    val languageTag: String = "ar",
    val maxConnections: Int = 24,
    val maxConcurrentDownloads: Int = 4,
    val wifiOnly: Boolean = false,
    val chargingOnly: Boolean = false,
    val stopOnLowBattery: Boolean = true,
    val http3Enabled: Boolean = true,
    val dnsOverHttps: Boolean = true,
    val speedLimitKbps: Int = 0,
    val adBlockEnabled: Boolean = true,
    val ytdlpAutoUpdate: Boolean = true,
    val fontScale: Float = 1f,
    val highContrast: Boolean = false,
    val visualizerMode: VisualizerMode = VisualizerMode.SPECTRUM_BARS,
    val onboardingCompleted: Boolean = true
)
