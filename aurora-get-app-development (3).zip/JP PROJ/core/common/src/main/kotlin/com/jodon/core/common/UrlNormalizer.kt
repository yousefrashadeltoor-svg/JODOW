package com.jodon.core.common

import java.io.File
import java.net.URI
import java.net.URLDecoder
import java.security.MessageDigest
import java.util.Locale

object UrlNormalizer {
    private val trackingParams = setOf(
        "utm_source", "utm_medium", "utm_campaign", "utm_term",
        "utm_content", "fbclid", "gclid", "igshid", "spm", "si", "feature"
    )

    fun clean(raw: String): String {
        val trimmed = raw.trim().removeSurrounding("\"").trim()
        val match = Regex("https?://[^\\s<>\"']+").find(trimmed)?.value ?: trimmed
        return match.trimEnd(',', '.', ';', ')', ']')
    }

    fun normalize(raw: String): String {
        val cleaned = clean(raw)
        if (cleaned.isBlank()) return ""
        if (cleaned.startsWith("magnet:", true)) return cleaned
        val withScheme = if (cleaned.startsWith("http://", true) || cleaned.startsWith("https://", true)) cleaned else "https://$cleaned"
        return try {
            val uri = URI(withScheme)
            val keptQuery = (uri.rawQuery ?: "").split("&")
                .filter { it.isNotBlank() && it.substringBefore("=").lowercase(Locale.ROOT) !in trackingParams }
                .joinToString("&")
            val query = if (keptQuery.isBlank()) "" else "?$keptQuery"
            val portPart = if (uri.port > 0 && uri.port !in setOf(80, 443)) ":${uri.port}" else ""
            "${uri.scheme?.lowercase(Locale.ROOT) ?: "https"}://${uri.host?.lowercase(Locale.ROOT).orEmpty()}$portPart${uri.rawPath ?: "/"}$query"
        } catch (_: Exception) {
            withScheme
        }
    }

    fun domain(url: String): String = try {
        (URI(normalize(url)).host ?: "").removePrefix("www.")
    } catch (_: Exception) {
        ""
    }

    fun siteName(url: String): String =
        domain(url).substringBefore('.').replaceFirstChar { it.titlecase(Locale.ROOT) }

    fun fileName(url: String): String = try {
        val path = URI(url).path ?: ""
        URLDecoder.decode(path.substringAfterLast('/'), "UTF-8").ifBlank { "jodon_media" }
    } catch (_: Exception) {
        "jodon_media"
    }

    fun sanitizeFileName(name: String): String = name
        .replace(Regex("[\\\\/:*?\"<>|\\x00-\\x1F]"), "_")
        .trim()
        .take(160)
        .ifBlank { "jodon_media" }

    fun extension(url: String): String =
        fileName(url).substringAfterLast('.', "").lowercase(Locale.ROOT)

    fun kindOf(contentType: String?, url: String): MediaKind {
        val type = contentType?.substringBefore(';')?.lowercase(Locale.ROOT).orEmpty()
        val ext = extension(url)
        return when {
            type.startsWith("video/") || ext in setOf("mp4", "mkv", "webm", "mov", "avi", "m3u8", "mpd", "ts") -> MediaKind.VIDEO
            type.startsWith("audio/") || ext in setOf("mp3", "m4a", "aac", "opus", "ogg", "flac", "wav") -> MediaKind.AUDIO
            type.startsWith("image/") || ext in setOf("jpg", "jpeg", "png", "webp", "avif", "gif") -> MediaKind.IMAGE
            ext in setOf("srt", "vtt", "ass", "ssa") || type.contains("subtitle") -> MediaKind.SUBTITLE
            ext in setOf("zip", "rar", "7z", "tar", "gz", "zst") -> MediaKind.ARCHIVE
            ext == "apk" -> MediaKind.APK
            ext in setOf("pdf", "doc", "docx", "txt", "epub", "json", "xml") -> MediaKind.DOCUMENT
            else -> MediaKind.OTHER
        }
    }

    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered(512 * 1024).use { stream ->
            val buf = ByteArray(512 * 1024)
            while (true) {
                val read = stream.read(buf)
                if (read < 0) break
                digest.update(buf, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
