package com.jodon.core.storage

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.core.util.AtomicFile
import com.jodon.core.common.AnalysisResult
import com.jodon.core.common.AppSettings
import com.jodon.core.common.DownloadTask
import com.jodon.core.common.FollowedChannel
import com.jodon.core.common.LocalMusicPlaylist
import com.jodon.core.common.LocalYouTubePlaylist
import com.jodon.core.common.LocalYouTubeProfileBundle
import com.jodon.core.common.SegmentState
import com.jodon.core.common.YouTubeVideoItem
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.KSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import java.io.File
import java.security.KeyStore
import java.util.Locale
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Pure crash-safe local file persistence without SQLite, Room, or any backend server.
 * Uses AndroidX AtomicFile (write to backup + fsync + atomic rename).
 */
class AtomicJsonCell<T>(
    private val file: File,
    private val serializer: KSerializer<T>,
    private val defaultValue: T,
    private val json: Json
) {
    private val mutex = Mutex()
    private val atomicFile = AtomicFile(file)

    fun readBlocking(): T {
        if (!file.exists()) return defaultValue
        return runCatching {
            val raw = String(atomicFile.readFully(), Charsets.UTF_8)
            json.decodeFromString(serializer, raw)
        }.getOrDefault(defaultValue)
    }

    suspend fun write(value: T) = withContext(Dispatchers.IO) {
        mutex.withLock {
            file.parentFile?.mkdirs()
            val encoded = json.encodeToString(serializer, value).toByteArray(Charsets.UTF_8)
            val out = atomicFile.startWrite()
            try {
                out.write(encoded)
                atomicFile.finishWrite(out)
            } catch (error: Throwable) {
                atomicFile.failWrite(out)
                throw error
            }
        }
    }
}

@Singleton
class SettingsStore @Inject constructor(
    @ApplicationContext context: Context,
    json: Json
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val cell = AtomicJsonCell(
        File(context.filesDir, "jodon_store/settings.json"),
        AppSettings.serializer(),
        AppSettings(),
        json
    )
    private val _settings = MutableStateFlow(cell.readBlocking())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    suspend fun update(next: AppSettings) {
        _settings.value = next
        cell.write(next)
    }

    fun updateAsync(transform: (AppSettings) -> AppSettings) {
        val next = transform(_settings.value)
        _settings.value = next
        scope.launch { cell.write(next) }
    }

    fun exportJson(json: Json): String = json.encodeToString(AppSettings.serializer(), _settings.value)
}

@Singleton
class DownloadsFileStore @Inject constructor(
    @ApplicationContext context: Context,
    private val json: Json
) {
    private val dir = File(context.filesDir, "jodon_store")
    private val segmentsDir = File(dir, "segments").apply { mkdirs() }
    private val tasksCell = AtomicJsonCell(
        File(dir, "downloads.json"),
        ListSerializer(DownloadTask.serializer()),
        emptyList(),
        json
    )
    private val segmentMutex = Mutex()

    fun loadTasksBlocking(): List<DownloadTask> = tasksCell.readBlocking()
    suspend fun saveTasks(tasks: List<DownloadTask>) = tasksCell.write(tasks)

    suspend fun loadSegments(taskId: String): List<SegmentState> = withContext(Dispatchers.IO) {
        segmentMutex.withLock {
            val file = File(segmentsDir, "$taskId.json")
            if (!file.exists()) return@withLock emptyList()
            runCatching {
                json.decodeFromString(ListSerializer(SegmentState.serializer()), file.readText())
            }.getOrDefault(emptyList())
        }
    }

    suspend fun saveSegment(segment: SegmentState) = withContext(Dispatchers.IO) {
        segmentMutex.withLock {
            val file = File(segmentsDir, "${segment.taskId}.json")
            val current = if (file.exists()) {
                runCatching {
                    json.decodeFromString(ListSerializer(SegmentState.serializer()), file.readText())
                }.getOrDefault(emptyList())
            } else emptyList()
            val merged = (current.filterNot { it.index == segment.index } + segment).sortedBy { it.index }
            val atomic = AtomicFile(file)
            val out = atomic.startWrite()
            try {
                out.write(json.encodeToString(ListSerializer(SegmentState.serializer()), merged).toByteArray())
                atomic.finishWrite(out)
            } catch (e: Throwable) {
                atomic.failWrite(out)
            }
        }
    }

    suspend fun clearSegments(taskId: String) = withContext(Dispatchers.IO) {
        segmentMutex.withLock { File(segmentsDir, "$taskId.json").delete() }
    }
}

@Serializable
data class CachedAnalysisEntry(val result: AnalysisResult, val expiresAt: Long)

@Singleton
class AnalysisCacheStore @Inject constructor(
    @ApplicationContext context: Context,
    json: Json
) {
    private val cell = AtomicJsonCell(
        File(context.filesDir, "jodon_store/analysis_cache.json"),
        MapSerializer(String.serializer(), CachedAnalysisEntry.serializer()),
        emptyMap(),
        json
    )
    private val memory = LinkedHashMap<String, CachedAnalysisEntry>(32, 0.75f, true)

    init {
        val now = System.currentTimeMillis()
        cell.readBlocking().filterValues { it.expiresAt > now }.forEach { (k, v) -> memory[k] = v }
    }

    suspend fun get(url: String): AnalysisResult? {
        val now = System.currentTimeMillis()
        val entry = synchronized(memory) { memory[url] } ?: return null
        if (entry.expiresAt < now) {
            synchronized(memory) { memory.remove(url) }
            return null
        }
        return entry.result
    }

    suspend fun put(url: String, result: AnalysisResult, ttlMs: Long = 600_000L) {
        val entry = CachedAnalysisEntry(result, System.currentTimeMillis() + ttlMs)
        val snapshot = synchronized(memory) {
            memory[url] = entry
            while (memory.size > 40) {
                val eldest = memory.entries.firstOrNull()?.key ?: break
                memory.remove(eldest)
            }
            memory.toMap()
        }
        cell.write(snapshot)
    }
}

@Singleton
class YouTubeLocalStore @Inject constructor(
    @ApplicationContext context: Context,
    private val json: Json
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val cell = AtomicJsonCell(
        File(context.filesDir, "jodon_store/youtube_profile.json"),
        LocalYouTubeProfileBundle.serializer(),
        LocalYouTubeProfileBundle(),
        json
    )
    private val _bundle = MutableStateFlow(cell.readBlocking())
    val bundle: StateFlow<LocalYouTubeProfileBundle> = _bundle.asStateFlow()

    private fun commit(transform: (LocalYouTubeProfileBundle) -> LocalYouTubeProfileBundle) {
        val updated = transform(_bundle.value)
        _bundle.value = updated
        scope.launch { cell.write(updated) }
    }

    fun updateProfile(displayName: String, handle: String, bio: String, avatarUri: String) = commit {
        it.copy(
            displayName = displayName.trim().ifBlank { "JoDon User" },
            handle = if (handle.startsWith("@")) handle.trim() else "@${handle.trim()}",
            bio = bio.trim(),
            avatarUri = avatarUri
        )
    }

    fun isFollowing(channelId: String): Boolean =
        _bundle.value.followedChannels.any { it.channelId == channelId }

    fun toggleFollow(channel: FollowedChannel) = commit { current ->
        val exists = current.followedChannels.any { it.channelId == channel.channelId }
        val updatedList = if (exists) current.followedChannels.filterNot { it.channelId == channel.channelId }
        else listOf(channel) + current.followedChannels
        val updatedWeights = current.channelWeights.toMutableMap().apply {
            if (exists) remove(channel.name) else put(channel.name, (this[channel.name] ?: 0.0) + 5.0)
        }
        current.copy(followedChannels = updatedList, channelWeights = updatedWeights)
    }

    fun recordWatch(video: YouTubeVideoItem) = commit { current ->
        if (current.historyPaused) return@commit current
        val words = video.title.split(Regex("[^\\p{L}\\p{N}]+"))
            .map { it.lowercase(Locale.ROOT) }
            .filter { it.length >= 4 }
            .take(6)
        val nextTopics = current.topicWeights.toMutableMap()
        (words + video.tags).forEach { token ->
            nextTopics[token] = (nextTopics[token] ?: 0.0) + 1.5
        }
        val nextChannels = current.channelWeights.toMutableMap()
        if (video.channelName.isNotBlank()) {
            nextChannels[video.channelName] = (nextChannels[video.channelName] ?: 0.0) + 2.5
        }
        val dedupHistory = listOf(video) + current.watchHistory.filterNot { it.videoId == video.videoId }
        current.copy(
            watchHistory = dedupHistory.take(300),
            topicWeights = nextTopics,
            channelWeights = nextChannels
        )
    }

    fun recordSearch(query: String) = commit { current ->
        val q = query.trim()
        if (q.isBlank()) return@commit current
        val nextTopics = current.topicWeights.toMutableMap().apply {
            put(q.lowercase(Locale.ROOT), (this[q.lowercase(Locale.ROOT)] ?: 0.0) + 2.0)
        }
        current.copy(
            searchHistory = (listOf(q) + current.searchHistory.filterNot { it.equals(q, true) }).take(50),
            topicWeights = nextTopics
        )
    }

    fun toggleLike(video: YouTubeVideoItem) = commit { current ->
        val liked = current.likedVideos.any { it.videoId == video.videoId }
        val nextLikes = if (liked) current.likedVideos.filterNot { it.videoId == video.videoId }
        else listOf(video) + current.likedVideos
        current.copy(likedVideos = nextLikes)
    }

    fun toggleWatchLater(video: YouTubeVideoItem) = commit { current ->
        val exists = current.watchLater.any { it.videoId == video.videoId }
        current.copy(
            watchLater = if (exists) current.watchLater.filterNot { it.videoId == video.videoId }
            else listOf(video) + current.watchLater
        )
    }

    fun createPlaylist(title: String) = commit { current ->
        val clean = title.trim().ifBlank { return@commit current }
        current.copy(playlists = listOf(LocalYouTubePlaylist(UUID.randomUUID().toString(), clean)) + current.playlists)
    }

    fun addVideoToPlaylist(playlistId: String, video: YouTubeVideoItem) = commit { current ->
        current.copy(playlists = current.playlists.map { pl ->
            if (pl.id != playlistId) pl else pl.copy(videos = (listOf(video) + pl.videos.filterNot { it.videoId == video.videoId }))
        })
    }

    fun togglePauseHistory() = commit { it.copy(historyPaused = !it.historyPaused) }
    fun clearHistory() = commit { it.copy(watchHistory = emptyList(), searchHistory = emptyList()) }

    /** Personalized recommendation queries ordered by affinity weight + followed channels. */
    fun personalizedSeedQueries(): List<String> {
        val b = _bundle.value
        val followedNames = b.followedChannels.take(6).map { it.name }
        val topTopics = b.topicWeights.entries.sortedByDescending { it.value }.take(8).map { it.key }
        val topChannels = b.channelWeights.entries.sortedByDescending { it.value }.take(4).map { it.key }
        return (followedNames + topChannels + topTopics).distinct().filter { it.isNotBlank() }
    }

    fun exportJson(): String = json.encodeToString(LocalYouTubeProfileBundle.serializer(), _bundle.value)

    fun importJson(rawJson: String): Boolean = runCatching {
        val imported = json.decodeFromString(LocalYouTubeProfileBundle.serializer(), rawJson)
        _bundle.value = imported
        scope.launch { cell.write(imported) }
        true
    }.getOrDefault(false)
}

@Serializable
data class MusicLibraryState(
    val favoriteUris: Set<String> = emptySet(),
    val playlists: List<LocalMusicPlaylist> = emptyList(),
    val eqBandLevelsMb: List<Int> = listOf(0, 0, 0, 0, 0),
    val bassBoostStrength: Int = 0
)

@Singleton
class MusicLibraryStore @Inject constructor(
    @ApplicationContext context: Context,
    json: Json
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val cell = AtomicJsonCell(
        File(context.filesDir, "jodon_store/music_library.json"),
        MusicLibraryState.serializer(),
        MusicLibraryState(),
        json
    )
    private val _state = MutableStateFlow(cell.readBlocking())
    val state: StateFlow<MusicLibraryState> = _state.asStateFlow()

    private fun commit(transform: (MusicLibraryState) -> MusicLibraryState) {
        val next = transform(_state.value)
        _state.value = next
        scope.launch { cell.write(next) }
    }

    fun toggleFavorite(uri: String) = commit { s ->
        val next = if (uri in s.favoriteUris) s.favoriteUris - uri else s.favoriteUris + uri
        s.copy(favoriteUris = next)
    }

    fun createPlaylist(name: String) = commit { s ->
        val clean = name.trim().ifBlank { return@commit s }
        s.copy(playlists = listOf(LocalMusicPlaylist(UUID.randomUUID().toString(), clean)) + s.playlists)
    }

    fun addTrackToPlaylist(playlistId: String, uri: String) = commit { s ->
        s.copy(playlists = s.playlists.map { pl ->
            if (pl.id != playlistId) pl else pl.copy(trackUris = (pl.trackUris + uri).distinct())
        })
    }

    fun saveAudioFx(bands: List<Int>, bass: Int) = commit {
        it.copy(eqBandLevelsMb = bands, bassBoostStrength = bass)
    }
}

/** Hardware Keystore AES-256-GCM encryption for Private Vault files & Browser cookies. */
@Singleton
class EncryptedVaultStore @Inject constructor(@ApplicationContext private val context: Context) {
    private val keyAlias = "jodon_master_aes256"
    private val vaultDir = File(context.filesDir, "jodon_vault").apply { mkdirs() }
    private val cookiePrefs = context.getSharedPreferences("jodon_cookies_enc", Context.MODE_PRIVATE)

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(
                keyAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encryptToVault(source: File): File {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, secretKey()) }
        val out = File(vaultDir, "${source.name}.vault")
        val plain = source.readBytes()
        val encrypted = cipher.doFinal(plain)
        out.writeBytes(cipher.iv + encrypted)
        return out
    }

    fun decryptFromVault(vaultFile: File, targetDir: File): File {
        val raw = vaultFile.readBytes()
        val iv = raw.copyOfRange(0, 12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        }
        val out = File(targetDir, vaultFile.name.removeSuffix(".vault"))
        out.writeBytes(cipher.doFinal(raw.copyOfRange(12, raw.size)))
        return out
    }

    fun listVaultFiles(): List<File> =
        vaultDir.listFiles()?.filter { it.name.endsWith(".vault") }?.sortedByDescending { it.lastModified() }.orEmpty()

    fun saveCookie(host: String, cookieHeader: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, secretKey()) }
        val payload = cipher.iv + cipher.doFinal(cookieHeader.toByteArray(Charsets.UTF_8))
        cookiePrefs.edit().putString(host, Base64.encodeToString(payload, Base64.NO_WRAP)).apply()
    }

    fun readCookie(host: String): String? {
        val rawStr = cookiePrefs.getString(host, null) ?: return null
        return runCatching {
            val raw = Base64.decode(rawStr, Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply {
                init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            }
            String(cipher.doFinal(raw.copyOfRange(12, raw.size)), Charsets.UTF_8)
        }.getOrNull()
    }
}
