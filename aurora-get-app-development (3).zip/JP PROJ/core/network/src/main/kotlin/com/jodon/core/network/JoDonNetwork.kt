package com.jodon.core.network

import android.content.Context
import com.jodon.core.common.SizeInfo
import com.jodon.core.common.SizeSource
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Cache
import okhttp3.Call
import okhttp3.Callback
import okhttp3.ConnectionPool
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.Dns
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.IOException
import java.net.InetAddress
import java.net.URI
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

@Singleton
class JoDonCookieJar @Inject constructor() : CookieJar {
    private val store = ConcurrentHashMap<String, MutableMap<String, Cookie>>()
    @Volatile var lastUserAgent: String = ""
        private set

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        val bucket = store.getOrPut(url.host) { ConcurrentHashMap() }
        cookies.forEach { bucket[it.name] = it }
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        val now = System.currentTimeMillis()
        val bucket = store[url.host] ?: return emptyList()
        bucket.entries.removeIf { it.value.expiresAt < now }
        return bucket.values.filter { it.matches(url) }
    }

    fun importWebViewCookies(host: String, pairs: Map<String, String>, userAgent: String) {
        val bucket = store.getOrPut(host) { ConcurrentHashMap() }
        pairs.forEach { (name, value) ->
            bucket[name] = Cookie.Builder()
                .name(name)
                .value(value)
                .domain(host.removePrefix("."))
                .path("/")
                .secure()
                .expiresAt(System.currentTimeMillis() + TimeUnit.HOURS.toMillis(12))
                .build()
        }
        if (userAgent.isNotBlank()) lastUserAgent = userAgent
    }

    fun cookieHeader(url: HttpUrl): String =
        loadForRequest(url).joinToString("; ") { "${it.name}=${it.value}" }
}

@Singleton
class CachingDns @Inject constructor() : Dns {
    private val cache = ConcurrentHashMap<String, List<InetAddress>>()
    override fun lookup(hostname: String): List<InetAddress> {
        cache[hostname]?.let { return it }
        val resolved = InetAddress.getAllByName(hostname).toList()
        if (resolved.isNotEmpty()) cache[hostname] = resolved
        return resolved
    }
    fun warm(host: String) { runCatching { lookup(host) } }
}

@Singleton
class PreconnectManager @Inject constructor(
    private val client: OkHttpClient,
    private val dns: CachingDns
) {
    fun warm(url: String) {
        val host = runCatching { URI(url).host.orEmpty() }.getOrNull()?.takeIf { it.isNotBlank() } ?: return
        dns.warm(host)
        client.newCall(Request.Builder().url(url).head().build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = Unit
            override fun onResponse(call: Call, response: Response) { response.close() }
        })
    }
}

@Singleton
class SizeResolver @Inject constructor(private val client: OkHttpClient) {

    suspend fun resolve(
        url: String,
        headers: Map<String, String> = emptyMap(),
        ytdlpExact: Long? = null,
        ytdlpApprox: Long? = null
    ): SizeInfo? = withContext(Dispatchers.IO) {
        headSize(url, headers)?.let { return@withContext it }
        rangeSize(url, headers)?.let { return@withContext it }
        if (url.contains(".m3u8", true) || url.contains(".mpd", true)) {
            streamingSize(url, headers)?.let { return@withContext it }
        }
        ytdlpExact?.takeIf { it > 0 }?.let { return@withContext SizeInfo(it, true, SizeSource.YTDLP_FILESIZE) }
        ytdlpApprox?.takeIf { it > 0 }?.let { return@withContext SizeInfo(it, false, SizeSource.YTDLP_FILESIZE_APPROX) }
        null
    }

    suspend fun headSize(url: String, headers: Map<String, String> = emptyMap()): SizeInfo? {
        val res = execute(Request.Builder().url(url).head().applyHeaders(headers).build()) ?: return null
        return res.use {
            val len = it.header("Content-Length")?.toLongOrNull()
            if (it.isSuccessful && len != null && len > 0L) SizeInfo(len, true, SizeSource.HEAD_CONTENT_LENGTH) else null
        }
    }

    suspend fun rangeSize(url: String, headers: Map<String, String> = emptyMap()): SizeInfo? {
        val req = Request.Builder().url(url).get().header("Range", "bytes=0-0").applyHeaders(headers).build()
        val res = execute(req) ?: return null
        return res.use {
            val total = it.header("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
                ?: it.header("Content-Length")?.toLongOrNull()
            if (total != null && total > 1L) SizeInfo(total, true, SizeSource.RANGE_CONTENT_RANGE) else null
        }
    }

    suspend fun streamingSize(playlistUrl: String, headers: Map<String, String> = emptyMap()): SizeInfo? = coroutineScope {
        val res = execute(Request.Builder().url(playlistUrl).get().applyHeaders(headers).build()) ?: return@coroutineScope null
        val body = res.use { if (it.isSuccessful) it.body?.string().orEmpty() else return@coroutineScope null }
        val base = playlistUrl.substringBeforeLast('/') + "/"
        val segs = body.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .map { if (it.startsWith("http", true)) it else base + it }
            .distinct()
            .toList()
        if (segs.isEmpty()) return@coroutineScope null
        val sizes = segs.chunked(24).flatMap { chunk ->
            chunk.map { seg -> async(Dispatchers.IO) { headSize(seg, headers)?.bytes } }.awaitAll()
        }
        if (sizes.any { it == null }) return@coroutineScope null
        SizeInfo(sizes.filterNotNull().sum(), true, SizeSource.HLS_DASH_SEGMENTS)
    }

    private fun Request.Builder.applyHeaders(headers: Map<String, String>): Request.Builder {
        headers.forEach { (k, v) -> header(k, v) }
        return this
    }

    private suspend fun execute(request: Request): Response? = suspendCancellableCoroutine { cont ->
        val call = client.newCall(request)
        cont.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { if (cont.isActive) cont.resume(null) }
            override fun onResponse(call: Call, response: Response) { if (cont.isActive) cont.resume(response) }
        })
    }
}

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    @Provides
    @Singleton
    fun provideOkHttpClient(
        @ApplicationContext context: Context,
        cookieJar: JoDonCookieJar,
        dns: CachingDns
    ): OkHttpClient = OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .dns(dns)
        .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
        .connectionPool(ConnectionPool(32, 5, TimeUnit.MINUTES))
        .cache(Cache(File(context.cacheDir, "jodon_http_cache"), 64L * 1024 * 1024))
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
}
