pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven(url = "https://jitpack.io")
    }
}
rootProject.name = "JoDon"
include(":app")
include(":core:common", ":core:designsystem", ":core:network", ":core:storage")
include(":engine:downloader", ":engine:extractors", ":engine:media")
include(
    ":feature:home",
    ":feature:analyzer",
    ":feature:youtube",
    ":feature:downloads",
    ":feature:browser",
    ":feature:converter",
    ":feature:compressor",
    ":feature:player",
    ":feature:files",
    ":feature:settings"
)
