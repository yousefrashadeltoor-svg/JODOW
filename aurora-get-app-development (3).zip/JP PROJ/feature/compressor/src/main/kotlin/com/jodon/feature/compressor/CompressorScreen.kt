package com.jodon.feature.compressor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jodon.core.common.humanBytes
import com.jodon.core.designsystem.GhostButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.GradientTitle
import com.jodon.core.designsystem.JoDonDesign
import com.jodon.core.designsystem.JoDonGlyph
import com.jodon.core.designsystem.MeshBackground
import com.jodon.core.designsystem.PillChip
import com.jodon.core.designsystem.PrimaryButton
import com.jodon.engine.media.NativeMediaToolkit
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import javax.inject.Inject

data class RealCompressionState(
    val lossless: Boolean = true,
    val beforeBytes: Long = 0L,
    val afterBytes: Long = 0L,
    val outputPath: String? = null,
    val message: String? = null,
    val running: Boolean = false
)

@HiltViewModel
class CompressorViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val toolkit: NativeMediaToolkit
) : ViewModel() {
    private val _state = MutableStateFlow(RealCompressionState())
    val state: StateFlow<RealCompressionState> = _state.asStateFlow()

    fun setLossless(lossless: Boolean) { _state.value = _state.value.copy(lossless = lossless) }

    fun compressRealUri(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            _state.value = _state.value.copy(running = true, message = null)
            val mime = context.contentResolver.getType(uri).orEmpty()
            val tempIn = File(context.cacheDir, "comp_in_${System.currentTimeMillis()}")
            context.contentResolver.openInputStream(uri)?.use { inp ->
                tempIn.outputStream().use { inp.copyTo(it) }
            }
            val before = tempIn.length()
            if (before <= 0L) {
                tempIn.delete()
                _state.value = _state.value.copy(running = false, message = "Empty or unreadable file")
                return@launch
            }
            val outDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "JoDon/Compressed").apply { mkdirs() }
            val lossless = _state.value.lossless

            val outFile: File
            if (mime.startsWith("image/")) {
                outFile = File(outDir, "compressed_${System.currentTimeMillis()}.webp")
                val bmp = BitmapFactory.decodeFile(tempIn.absolutePath)
                if (bmp != null) {
                    outFile.outputStream().use { out ->
                        @Suppress("DEPRECATION")
                        val fmt = if (android.os.Build.VERSION.SDK_INT >= 30) {
                            if (lossless) Bitmap.CompressFormat.WEBP_LOSSLESS else Bitmap.CompressFormat.WEBP_LOSSY
                        } else Bitmap.CompressFormat.WEBP
                        bmp.compress(fmt, if (lossless) 100 else 86, out)
                    }
                    bmp.recycle()
                }
            } else if (mime.startsWith("video/")) {
                outFile = File(outDir, "compressed_${System.currentTimeMillis()}.mp4")
                val crf = if (lossless) "20" else "27"
                toolkit.executeBundledFfmpeg(listOf("-y", "-i", tempIn.absolutePath, "-c:v", "libx264", "-crf", crf, "-c:a", "copy", outFile.absolutePath))
            } else {
                outFile = File(outDir, "compressed_${System.currentTimeMillis()}.zip")
                ZipOutputStream(outFile.outputStream()).use { zos ->
                    zos.setLevel(Deflater.BEST_COMPRESSION)
                    zos.putNextEntry(ZipEntry("data"))
                    tempIn.inputStream().use { it.copyTo(zos, 256 * 1024) }
                    zos.closeEntry()
                }
            }
            tempIn.delete()
            val after = if (outFile.exists()) outFile.length() else before
            if (!outFile.exists() || after >= before) {
                outFile.delete()
                _state.value = _state.value.copy(
                    running = false,
                    beforeBytes = before,
                    afterBytes = before,
                    outputPath = null,
                    message = "File is already optimally compressed; kept original untouched."
                )
            } else {
                val pct = ((before - after) * 100.0 / before)
                _state.value = _state.value.copy(
                    running = false,
                    beforeBytes = before,
                    afterBytes = after,
                    outputPath = outFile.absolutePath,
                    message = String.format("Saved %.1f%% → %s", pct, outFile.name)
                )
            }
        }
    }
}

@Composable
fun CompressorScreen(
    isArabic: Boolean,
    vm: CompressorViewModel = hiltViewModel()
) {
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    val state by vm.state.collectAsState()
    val theme = JoDonDesign.theme
    var pickedUri by remember { mutableStateOf<Uri?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) pickedUri = u
    }

    Box(Modifier.fillMaxSize()) {
        MeshBackground()
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                GradientTitle(L("أداة تصغير الحجم الذكية", "Smart Lossless & Transparent Compressor"))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillChip(L("🟢 بدون فقد (Lossless)", "🟢 Lossless"), state.lossless, { vm.setLossless(true) }, Modifier.weight(1f))
                    PillChip(L("🟡 شفاف بصرياً", "🟡 Transparent"), !state.lossless, { vm.setLossless(false) }, Modifier.weight(1f))
                }
            }

            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        BasicText(
                            pickedUri?.lastPathSegment ?: L("اختر ملفاً حقيقياً من هاتفك لقياس وضغط حجمه", "Select a real file from your device"),
                            style = JoDonDesign.typography.label
                        )
                        GhostButton(L("اختيار ملف", "Pick File"), { picker.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth(), JoDonGlyph.FOLDER)
                        PrimaryButton(
                            text = if (state.running) L("جارٍ الضغط...", "Compressing...") else L("ضغط وحفظ نسخة جديدة", "Compress to New File"),
                            glyph = JoDonGlyph.COMPRESS,
                            onClick = { pickedUri?.let(vm::compressRealUri) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            if (state.beforeBytes > 0L) {
                item {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            BasicText("${L("الحجم قبل", "Before")}: ${humanBytes(state.beforeBytes)} (${state.beforeBytes} B)", style = JoDonDesign.typography.numeric)
                            BasicText("${L("الحجم بعد", "After")}: ${humanBytes(state.afterBytes)} (${state.afterBytes} B)", style = JoDonDesign.typography.numeric.copy(color = theme.success))
                            state.message?.let { BasicText(it, style = JoDonDesign.typography.label) }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(96.dp)) }
        }
    }
}
