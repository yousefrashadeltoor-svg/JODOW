package com.jodon.feature.downloads

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import com.jodon.core.common.DownloadStatus
import com.jodon.core.common.DownloadTask
import com.jodon.core.common.humanBytes
import com.jodon.core.designsystem.GhostButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.GradientTitle
import com.jodon.core.designsystem.IconBtn
import com.jodon.core.designsystem.JoDonDesign
import com.jodon.core.designsystem.JoDonGlyph
import com.jodon.core.designsystem.MeshBackground
import com.jodon.core.designsystem.PillChip
import com.jodon.core.designsystem.ProgressBar
import com.jodon.engine.downloader.DownloadQueue
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class DownloadsViewModel @Inject constructor(val queue: DownloadQueue) : ViewModel()

@Composable
fun DownloadsScreen(
    isArabic: Boolean,
    vm: DownloadsViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    val tasks by vm.queue.tasks.collectAsState()
    val theme = JoDonDesign.theme
    var tab by remember { mutableStateOf("all") }

    val filtered = tasks.filter { t ->
        when (tab) {
            "active" -> t.status == DownloadStatus.ACTIVE
            "queued" -> t.status == DownloadStatus.QUEUED || t.status == DownloadStatus.PAUSED
            "done" -> t.status == DownloadStatus.COMPLETED
            "failed" -> t.status == DownloadStatus.FAILED
            else -> true
        }
    }
    val totalSpeed = tasks.filter { it.status == DownloadStatus.ACTIVE }.sumOf { it.speedBps }

    Box(Modifier.fillMaxSize()) {
        MeshBackground()
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                GradientTitle(L("مدير التحميلات الفائق", "Hyper Download Manager"))
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            BasicText(L("السرعة الكلية الحالية", "Aggregate Speed"), style = JoDonDesign.typography.caption.copy(color = theme.muted))
                            BasicText("${humanBytes(totalSpeed)}/s", style = JoDonDesign.typography.headline)
                        }
                        PillChip("${tasks.count { it.status == DownloadStatus.ACTIVE }} ${L("نشط", "Active")}", active = true)
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        "all" to L("الكل", "All"),
                        "active" to L("جارٍ", "Active"),
                        "queued" to L("مؤقت", "Paused"),
                        "done" to L("مكتمل", "Done"),
                        "failed" to L("فاشل", "Failed")
                    ).forEach { (k, label) ->
                        PillChip(label, tab == k, { tab = k })
                    }
                }
            }

            if (filtered.isEmpty()) {
                item {
                    GlassCard(Modifier.fillMaxWidth()) {
                        BasicText(
                            L("لا توجد عناصر تحميل حالياً. ألصق أي رابط في الرئيسية أو حمّل مباشرة من منصة يوتيوب المدمجة.", "No downloads in this tab yet. Paste a link on Home or download from the YouTube tab."),
                            style = JoDonDesign.typography.body.copy(color = theme.muted)
                        )
                    }
                }
            }

            items(filtered, key = { it.id }) { task ->
                DownloadTaskCard(task, isArabic, vm.queue, context)
            }
            item { Spacer(Modifier.height(96.dp)) }
        }
    }
}

@Composable
private fun DownloadTaskCard(task: DownloadTask, isArabic: Boolean, queue: DownloadQueue, context: Context) {
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    val theme = JoDonDesign.theme
    GlassCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    BasicText(task.fileName, style = JoDonDesign.typography.label)
                    BasicText(
                        "${humanBytes(task.loadedBytes)} / ${task.displaySize()} · ${humanBytes(task.speedBps)}/s · ${task.connections} conn",
                        style = JoDonDesign.typography.numeric.copy(color = theme.muted)
                    )
                }
                SparklineCanvas(task.speedHistory, Modifier.width(68.dp).height(24.dp))
            }
            ProgressBar(task.progress, Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                when (task.status) {
                    DownloadStatus.ACTIVE -> GhostButton(L("إيقاف", "Pause"), { queue.pause(task.id) }, glyph = JoDonGlyph.PAUSE)
                    DownloadStatus.PAUSED, DownloadStatus.QUEUED -> GhostButton(L("استكمال", "Resume"), { queue.resume(task.id) }, glyph = JoDonGlyph.PLAY)
                    DownloadStatus.FAILED -> GhostButton(L("إعادة", "Retry"), { queue.retry(task.id) }, glyph = JoDonGlyph.REFRESH)
                    else -> Unit
                }
                GhostButton(L("نسخ الرابط", "Copy Link"), {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Download URL", task.url))
                }, glyph = JoDonGlyph.COPY)
                Spacer(Modifier.weight(1f))
                IconBtn(JoDonGlyph.TRASH, "Delete", { queue.delete(task.id) })
            }
            task.error?.let { err ->
                BasicText(err, style = JoDonDesign.typography.caption.copy(color = theme.danger))
            }
        }
    }
}

@Composable
private fun SparklineCanvas(points: List<Long>, modifier: Modifier = Modifier) {
    val theme = JoDonDesign.theme
    Canvas(modifier) {
        if (points.size < 2) return@Canvas
        val maxVal = points.maxOrNull()?.coerceAtLeast(1L) ?: 1L
        val step = size.width / (points.size - 1)
        val path = Path()
        points.forEachIndexed { idx, v ->
            val x = idx * step
            val y = size.height - (v.toFloat() / maxVal) * (size.height - 4f) - 2f
            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, theme.accent4, style = Stroke(2.dp.toPx()))
    }
}
