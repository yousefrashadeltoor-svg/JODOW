package com.jodon.feature.browser

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jodon.core.common.DownloadStatus
import com.jodon.core.common.DownloadTask
import com.jodon.core.common.UrlNormalizer
import com.jodon.core.common.humanBytes
import com.jodon.core.designsystem.GlassBottomSheet
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.IconBtn
import com.jodon.core.designsystem.JoDonDesign
import com.jodon.core.designsystem.JoDonGlyph
import com.jodon.core.designsystem.MeshBackground
import com.jodon.core.designsystem.PillChip
import com.jodon.core.designsystem.PrimaryButton
import com.jodon.core.designsystem.jodonGlass
import com.jodon.core.network.JoDonCookieJar
import com.jodon.core.network.SizeResolver
import com.jodon.core.storage.EncryptedVaultStore
import com.jodon.engine.downloader.DownloadQueue
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.URI
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject

data class SniffedMedia(
    val url: String,
    val fileName: String,
    val mimeType: String,
    val bytes: Long,
    val exact: Boolean,
    val headers: Map<String, String>
)

private const val JS_SNIFFER_HOOK = """
(function() {
  if (window.__jodonHooked) return;
  window.__jodonHooked = true;
  function send(u) { if (u && u.startsWith('http')) window.JoDonBridge.onMedia(u); }
  const origFetch = window.fetch;
  window.fetch = function(input) {
    try { send(typeof input === 'string' ? input : input.url); } catch(e) {}
    return origFetch.apply(this, arguments);
  };
  const origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(m, u) {
    try { send(u); } catch(e) {}
    return origOpen.apply(this, arguments);
  };
  document.querySelectorAll('video, audio, source').forEach(function(el) { if (el.src) send(el.src); });
})();
"""

@HiltViewModel
class BrowserViewModel @Inject constructor(
    private val sizeResolver: SizeResolver,
    private val cookieJar: JoDonCookieJar,
    private val encryptedStore: EncryptedVaultStore,
    private val queue: DownloadQueue
) : ViewModel() {
    private val _sniffed = MutableStateFlow<List<SniffedMedia>>(emptyList())
    val sniffed: StateFlow<List<SniffedMedia>> = _sniffed.asStateFlow()
    val blockedAds = AtomicInteger(0)

    private val adHosts = listOf("doubleclick.net", "googlesyndication.com", "adservice.google", "popads.net", "/ads/", "/popunder")
    private val mediaExtRegex = Regex("\\.(m3u8|mpd|mp4|webm|mkv|mp3|m4a|aac|opus|ogg|flac|wav|zip|apk|pdf)(\\?.*)?$", RegexOption.IGNORE_CASE)

    fun isAdRequest(url: String): Boolean {
        val hit = adHosts.any { url.contains(it, true) }
        if (hit) blockedAds.incrementAndGet()
        return hit
    }

    fun isLikelyMedia(url: String, acceptHeader: String?): Boolean =
        mediaExtRegex.containsMatchIn(url) || acceptHeader?.contains("video/") == true || acceptHeader?.contains("audio/") == true

    fun onDiscovered(mediaUrl: String, pageUrl: String, userAgent: String) {
        if (!mediaUrl.startsWith("http", true) || _sniffed.value.any { it.url == mediaUrl }) return
        val cookies = CookieManager.getInstance().getCookie(pageUrl).orEmpty()
        val headers = buildMap {
            if (cookies.isNotBlank()) put("Cookie", cookies)
            if (userAgent.isNotBlank()) put("User-Agent", userAgent)
            if (pageUrl.isNotBlank()) put("Referer", pageUrl)
        }
        val baseItem = SniffedMedia(
            url = mediaUrl,
            fileName = UrlNormalizer.sanitizeFileName(UrlNormalizer.fileName(mediaUrl)),
            mimeType = UrlNormalizer.extension(mediaUrl),
            bytes = 0L,
            exact = false,
            headers = headers
        )
        _sniffed.value = listOf(baseItem) + _sniffed.value
        viewModelScope.launch {
            val sz = sizeResolver.resolve(mediaUrl, headers)
            if (sz != null) {
                _sniffed.value = _sniffed.value.map {
                    if (it.url == mediaUrl) it.copy(bytes = sz.bytes, exact = sz.exact) else it
                }
            }
        }
    }

    fun syncClearanceCookies(pageUrl: String, userAgent: String) {
        val host = runCatching { URI(pageUrl).host.orEmpty() }.getOrDefault("")
        if (host.isBlank()) return
        val raw = CookieManager.getInstance().getCookie(pageUrl).orEmpty()
        if (raw.isBlank()) return
        encryptedStore.saveCookie(host, raw)
        val map = raw.split(';').mapNotNull { part ->
            val kv = part.trim().split('=', limit = 2)
            if (kv.size == 2) kv[0] to kv[1] else null
        }.toMap()
        cookieJar.importWebViewCookies(host, map, userAgent)
    }

    fun downloadSniffed(item: SniffedMedia) {
        queue.enqueue(
            DownloadTask(
                id = UUID.randomUUID().toString(),
                url = item.url,
                fileName = item.fileName,
                kind = UrlNormalizer.kindOf(item.mimeType, item.url),
                status = DownloadStatus.QUEUED,
                totalBytes = item.bytes,
                sizeExact = item.exact,
                connections = 16,
                headers = item.headers
            )
        )
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SnifferBrowserScreen(
    isArabic: Boolean,
    vm: BrowserViewModel = hiltViewModel()
) {
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    val sniffed by vm.sniffed.collectAsState()
    val theme = JoDonDesign.theme
    var addressInput by remember { mutableStateOf("") }
    var activeUrl by remember { mutableStateOf("") }
    var desktopMode by remember { mutableStateOf(false) }
    var showSheet by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        MeshBackground()
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp)) {
            Row(
                Modifier.fillMaxWidth().jodonGlass(JoDonDesign.shapes.pill).padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = addressInput,
                    onValueChange = { addressInput = it },
                    textStyle = JoDonDesign.typography.numeric.copy(color = theme.text),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        if (addressInput.isEmpty()) BasicText(L("أدخل رابط الموقع لاصطياد الوسائط...", "Enter URL to sniff media..."), style = JoDonDesign.typography.caption.copy(color = theme.muted))
                        inner()
                    }
                )
                PillChip(L("انتقال", "Go"), active = true, onClick = {
                    if (addressInput.isNotBlank()) activeUrl = UrlNormalizer.normalize(addressInput)
                })
                Spacer(Modifier.width(6.dp))
                PillChip("🛡 ${vm.blockedAds.get()}", onClick = { desktopMode = !desktopMode })
            }
            Spacer(Modifier.height(8.dp))
            if (activeUrl.isBlank()) {
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        BasicText(L("متصفح اصطياد الوسائط مع حجب الإعلانات", "Media Sniffer Browser + AdBlock"), style = JoDonDesign.typography.title)
                        BasicText(
                            L("أدخل رابط أي صفحة تحتوي فيديو أو صوت غير مباشر؛ يلتقط المتصفح روابط m3u8 / mp4 / mp3 مع الكوكيز والـ Referer ويحمّلها بمحرك 𝒥𝒪 DON المجزأ.", "Open any page to intercept HLS/DASH/MP4/MP3 streams with cookies & headers and hand them to the segmented engine."),
                            style = JoDonDesign.typography.body.copy(color = theme.muted)
                        )
                    }
                }
            } else {
                AndroidView(
                    modifier = Modifier.weight(1f).fillMaxWidth().clip(JoDonDesign.shapes.large),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            val ua = settings.userAgentString
                            addJavascriptInterface(object {
                                @JavascriptInterface
                                fun onMedia(u: String) { vm.onDiscovered(u, activeUrl, ua) }
                            }, "JoDonBridge")
                            webViewClient = object : WebViewClient() {
                                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                                    val reqUrl = request.url.toString()
                                    if (vm.isAdRequest(reqUrl)) {
                                        return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                                    }
                                    if (vm.isLikelyMedia(reqUrl, request.requestHeaders["Accept"])) {
                                        vm.onDiscovered(reqUrl, activeUrl, ua)
                                    }
                                    return super.shouldInterceptRequest(view, request)
                                }

                                override fun onPageFinished(view: WebView, url: String) {
                                    view.evaluateJavascript(JS_SNIFFER_HOOK, null)
                                    vm.syncClearanceCookies(url, view.settings.userAgentString)
                                }
                            }
                            setDownloadListener(DownloadListener { dlUrl, userAgent, _, _, _ ->
                                vm.onDiscovered(dlUrl, activeUrl, userAgent)
                            })
                            loadUrl(activeUrl)
                        }
                    },
                    update = { view ->
                        view.settings.userAgentString = if (desktopMode)
                            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36"
                        else WebSettings.getDefaultUserAgent(view.context)
                        if (view.url != activeUrl) view.loadUrl(activeUrl)
                    }
                )
            }
            Spacer(Modifier.height(84.dp))
        }

        if (sniffed.isNotEmpty()) {
            PrimaryButton(
                text = "${sniffed.size} ${L("ملفات مكتشفة", "Captured Media")}",
                glyph = JoDonGlyph.SCAN,
                onClick = { showSheet = true },
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = 92.dp)
            )
        }

        if (showSheet) {
            GlassBottomSheet(true, L("الوسائط المصطادة", "Sniffed Streams"), { showSheet = false }) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(sniffed, key = { it.url }) { item ->
                        GlassCard(Modifier.fillMaxWidth(), JoDonDesign.shapes.medium) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    BasicText(item.fileName, style = JoDonDesign.typography.label)
                                    BasicText(
                                        if (item.bytes > 0) "${if (item.exact) "" else "≈ "}${humanBytes(item.bytes)}" else item.mimeType.uppercase(),
                                        style = JoDonDesign.typography.numeric.copy(color = theme.accent1)
                                    )
                                }
                                IconBtn(JoDonGlyph.DOWNLOAD, "Download", {
                                    vm.downloadSniffed(item)
                                    showSheet = false
                                })
                            }
                        }
                    }
                }
            }
        }
    }
}
