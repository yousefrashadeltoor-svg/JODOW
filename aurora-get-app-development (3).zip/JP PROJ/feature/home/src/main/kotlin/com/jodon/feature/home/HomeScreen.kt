package com.jodon.feature.home

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import coil3.compose.AsyncImage
import com.jodon.core.common.DownloadStatus
import com.jodon.core.common.DownloadTask
import com.jodon.core.common.MediaFormat
import com.jodon.core.common.MediaKind
import com.jodon.core.common.UrlNormalizer
import com.jodon.core.designsystem.GhostButton
import com.jodon.core.designsystem.GlassBottomSheet
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.GradientTitle
import com.jodon.core.designsystem.IconBtn
import com.jodon.core.designsystem.JoDonDesign
import com.jodon.core.designsystem.JoDonGlyph
import com.jodon.core.designsystem.JoDonIcon
import com.jodon.core.designsystem.MeshBackground
import com.jodon.core.designsystem.PillChip
import com.jodon.core.designsystem.PrimaryButton
import com.jodon.core.designsystem.ProgressBar
import com.jodon.core.designsystem.jodonPress
import com.jodon.core.designsystem.sweepGlow
import com.jodon.engine.downloader.DownloadQueue
import com.jodon.feature.analyzer.AnalyzerViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.UUID
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    val queue: DownloadQueue
) : ViewModel() {
    fun enqueueFormat(format: MediaFormat, baseTitle: String) {
        val sz = format.resolvedSize()
        val ext = format.container.lowercase().ifBlank { "mp4" }
        queue.enqueue(
            DownloadTask(
                id = UUID.randomUUID().toString(),
                url = format.url,
                fileName = UrlNormalizer.sanitizeFileName("$baseTitle.$ext"),
                kind = format.kind,
                status = DownloadStatus.QUEUED,
                totalBytes = sz.bytes,
                sizeExact = sz.exact,
                connections = 24,
                headers = format.headers,
                mergeAudioUrl = format.bestAudio?.url
            )
        )
    }
}

@Composable
fun HomeScreen(
    isArabic: Boolean,
    initialSharedUrl: String? = null,
    onOpenYouTube: () -> Unit,
    onOpenBrowser: () -> Unit,
    onOpenDownloads: () -> Unit,
    analyzer: AnalyzerViewModel = hiltViewModel(),
    homeVm: HomeViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    val state by analyzer.state.collectAsState()
    val tasks by homeVm.queue.tasks.collectAsState()
    var inputText by remember(initialSharedUrl) { mutableStateOf(initialSharedUrl.orEmpty()) }
    var activeKindSheet by remember { mutableStateOf<MediaKind?>(null) }
    var customFileName by remember { mutableStateOf("") }
    var toastText by remember { mutableStateOf<String?>(null) }

    val theme = JoDonDesign.theme
    Box(Modifier.fillMaxSize()) {
        MeshBackground()
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(Modifier.height(8.dp))
                GradientTitle(L("𝒥𝒪 DON — التحميل الفائق", "𝒥𝒪 DON — Hyper Downloader"))
                BasicText(
                    L("بدون سحابة أو قاعدة بيانات · خصوصية محلية 100%", "Zero cloud, zero database · 100% local privacy"),
                    style = JoDonDesign.typography.caption.copy(color = theme.muted)
                )
            }

            item {
                GlassCard(Modifier.fillMaxWidth().sweepGlow(state.analyzing)) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            JoDonIcon(JoDonGlyph.LINK, null, Modifier.size(16.dp), theme.accent1)
                            Spacer(Modifier.width(8.dp))
                            BasicText(L("ألصق أي رابط للتحليل الفوري", "Paste any URL for instant analysis"), Modifier.weight(1f), style = JoDonDesign.typography.label)
                            if (inputText.isNotBlank()) {
                                IconBtn(JoDonGlyph.CLOSE, "Clear", { inputText = ""; analyzer.clear() })
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        BasicTextField(
                            value = inputText,
                            onValueChange = {
                                inputText = it
                                analyzer.submitUrl(it)
                            },
                            textStyle = JoDonDesign.typography.numeric.copy(color = theme.text),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(JoDonDesign.shapes.medium)
                                .background(theme.surface.copy(alpha = 0.65f))
                                .border(1.dp, theme.border, JoDonDesign.shapes.medium)
                                .padding(12.dp),
                            decorationBox = { inner ->
                                if (inputText.isEmpty()) {
                                    BasicText("https://...", style = JoDonDesign.typography.caption.copy(color = theme.muted))
                                }
                                inner()
                            }
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GhostButton(
                                text = L("لصق من الحافظة", "Paste"),
                                glyph = JoDonGlyph.CLIPBOARD,
                                onClick = {
                                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = cm.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
                                    if (clip.isNotBlank()) {
                                        inputText = clip
                                        analyzer.submitUrl(clip)
                                    }
                                }
                            )
                            PrimaryButton(
                                text = if (state.analyzing) L("جارٍ التحليل...", "Analyzing...") else L("تحليل الرابط", "Analyze"),
                                glyph = JoDonGlyph.SPARKLES,
                                onClick = { analyzer.submitUrl(inputText) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Quick launch strip for YouTube Hub & Sniffer Browser
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GlassCard(Modifier.weight(1f).jodonPress(onOpenYouTube)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            JoDonIcon(JoDonGlyph.YOUTUBE, "YouTube", Modifier.size(24.dp))
                            Spacer(Modifier.width(8.dp))
                            Column {
                                BasicText(L("منصة يوتيوب", "YouTube Hub"), style = JoDonDesign.typography.label)
                                BasicText(L("شورتس + حساب محلي", "Shorts + Local Profile"), style = JoDonDesign.typography.caption.copy(color = theme.muted))
                            }
                        }
                    }
                    GlassCard(Modifier.weight(1f).jodonPress(onOpenBrowser)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            JoDonIcon(JoDonGlyph.BROWSER, "Browser", Modifier.size(22.dp), theme.accent2)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                BasicText(L("متصفح الاصطياد", "Media Sniffer"), style = JoDonDesign.typography.label)
                                BasicText(L("حجب إعلانات + كوكيز", "AdBlock + Cookies"), style = JoDonDesign.typography.caption.copy(color = theme.muted))
                            }
                        }
                    }
                }
            }

            state.result?.let { res ->
                item {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                PillChip(res.siteName.ifBlank { res.domain }, active = true)
                                Spacer(Modifier.width(8.dp))
                                BasicText(res.domain, Modifier.weight(1f), style = JoDonDesign.typography.caption.copy(color = theme.muted))
                                IconBtn(JoDonGlyph.COPY, "Copy URL", {
                                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    cm.setPrimaryClip(ClipData.newPlainText("URL", res.url))
                                    toastText = L("تم نسخ الرابط", "Link copied")
                                })
                            }
                            if (res.thumbnailUrl.isNotBlank()) {
                                Spacer(Modifier.height(10.dp))
                                AsyncImage(
                                    model = res.thumbnailUrl,
                                    contentDescription = res.title,
                                    modifier = Modifier.fillMaxWidth().height(160.dp).clip(JoDonDesign.shapes.medium)
                                )
                            }
                            Spacer(Modifier.height(10.dp))
                            BasicText(res.title.ifBlank { res.fileName }, style = JoDonDesign.typography.title)
                            Spacer(Modifier.height(8.dp))
                            BasicTextField(
                                value = customFileName.ifBlank { res.fileName },
                                onValueChange = { customFileName = it },
                                textStyle = JoDonDesign.typography.numeric.copy(color = theme.text),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(JoDonDesign.shapes.small)
                                    .background(theme.glass)
                                    .padding(10.dp)
                            )
                        }
                    }
                }

                // Smart 4 Buttons: rendered ONLY when formats of that kind actually exist
                val smartKinds = listOf(
                    Triple(MediaKind.VIDEO, L("فيديو", "Video"), JoDonGlyph.VIDEO),
                    Triple(MediaKind.AUDIO, L("صوت", "Audio"), JoDonGlyph.MUSIC),
                    Triple(MediaKind.IMAGE, L("صور", "Images"), JoDonGlyph.IMAGE),
                    Triple(MediaKind.SUBTITLE, L("ملفات وترجمات", "Files & Subs"), JoDonGlyph.FILE)
                ).filter { (kind, _, _) -> res.countFor(kind) > 0 }

                if (smartKinds.isNotEmpty()) {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            smartKinds.forEach { (kind, label, glyph) ->
                                GlassCard(
                                    modifier = Modifier.weight(1f).jodonPress({ activeKindSheet = kind }),
                                    shape = JoDonDesign.shapes.medium
                                ) {
                                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                        JoDonIcon(glyph, label, Modifier.size(22.dp), theme.accent1)
                                        Spacer(Modifier.height(6.dp))
                                        BasicText("$label (${res.countFor(kind)})", style = JoDonDesign.typography.caption)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (tasks.isNotEmpty()) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BasicText(L("التحميلات الجارية والأخيرة", "Active & Recent Downloads"), Modifier.weight(1f), style = JoDonDesign.typography.title)
                        PillChip(L("فتح المدير", "Manager"), onClick = onOpenDownloads)
                    }
                }
                items(tasks.take(5), key = { it.id }) { task ->
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column {
                            BasicText(task.fileName, style = JoDonDesign.typography.label)
                            Spacer(Modifier.height(6.dp))
                            ProgressBar(task.progress, Modifier.fillMaxWidth())
                            Spacer(Modifier.height(4.dp))
                            BasicText(
                                "${task.status.name} · ${task.displaySize()}",
                                style = JoDonDesign.typography.caption.copy(color = theme.muted)
                            )
                        }
                    }
                }
            }

            item {
                BasicText(
                    L("المسؤولية على المستخدم في احترام حقوق النشر · لا تجاوز DRM ولا Paywalls", "Users are responsible for respecting copyright · No DRM or paywall bypass"),
                    style = JoDonDesign.typography.caption.copy(color = theme.muted)
                )
                Spacer(Modifier.height(96.dp))
            }
        }

        toastText?.let { msg ->
            GlassCard(Modifier.align(Alignment.BottomCenter).padding(bottom = 92.dp)) {
                BasicText(msg, style = JoDonDesign.typography.label)
            }
        }

        activeKindSheet?.let { kind ->
            val list = state.result?.formats?.filter { it.kind == kind }.orEmpty()
            GlassBottomSheet(
                visible = true,
                title = L("اختر الصيغة والجودة", "Select Format & Quality"),
                onDismiss = { activeKindSheet = null }
            ) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list, key = { it.id }) { fmt ->
                        val sz = fmt.resolvedSize()
                        GlassCard(Modifier.fillMaxWidth(), JoDonDesign.shapes.medium) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    BasicText("${fmt.quality} · ${fmt.container} · ${fmt.codec}", style = JoDonDesign.typography.label)
                                    BasicText(
                                        sz.display() + (if (fmt.needsMerge) L(" · دمج صوت تلقائي", " · Auto Audio Mux") else ""),
                                        style = JoDonDesign.typography.numeric.copy(color = if (sz.exact) theme.success else theme.warning)
                                    )
                                }
                                PrimaryButton(
                                    text = L("تحميل", "Download"),
                                    glyph = JoDonGlyph.DOWNLOAD,
                                    onClick = {
                                        homeVm.enqueueFormat(fmt, customFileName.ifBlank { state.result?.fileName ?: "jodon_media" })
                                        activeKindSheet = null
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
