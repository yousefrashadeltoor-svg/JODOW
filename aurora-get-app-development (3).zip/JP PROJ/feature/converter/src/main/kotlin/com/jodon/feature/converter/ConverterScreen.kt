package com.jodon.feature.converter

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jodon.core.designsystem.GhostButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.GradientTitle
import com.jodon.core.designsystem.JoDonDesign
import com.jodon.core.designsystem.JoDonGlyph
import com.jodon.core.designsystem.MeshBackground
import com.jodon.core.designsystem.PillChip
import com.jodon.core.designsystem.PrimaryButton
import com.jodon.engine.media.NativeMediaToolkit
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class ConverterViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val toolkit: NativeMediaToolkit
) : ViewModel() {
    private val _status = MutableStateFlow<String?>(null)
    val status: StateFlow<String?> = _status.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    fun convertUri(sourceUri: Uri, targetFormat: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _busy.value = true
            val inCache = File(context.cacheDir, "conv_in_${System.currentTimeMillis()}")
            runCatching {
                context.contentResolver.openInputStream(sourceUri)?.use { inp ->
                    inCache.outputStream().use { inp.copyTo(it) }
                }
            }
            val outDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "JoDon/Converted").apply { mkdirs() }
            val outFile = File(outDir, "converted_${System.currentTimeMillis()}.${targetFormat.lowercase()}")

            val res = if (targetFormat.uppercase() in setOf("M4A", "AAC")) {
                toolkit.trimMedia(sourceUri, 0L, Long.MAX_VALUE / 2000L, audioOnly = true, outputFile = outFile)
            } else {
                toolkit.executeBundledFfmpeg(listOf("-y", "-i", inCache.absolutePath, outFile.absolutePath))
            }
            inCache.delete()
            _busy.value = false
            _status.value = if (res.success) "Saved: ${outFile.absolutePath}" else res.message
        }
    }
}

@Composable
fun ConverterScreen(
    isArabic: Boolean,
    vm: ConverterViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    val status by vm.status.collectAsState()
    val busy by vm.busy.collectAsState()
    val theme = JoDonDesign.theme

    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var pickedName by remember { mutableStateOf("") }
    var format by remember { mutableStateOf("M4A") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            pickedUri = u
            pickedName = u.lastPathSegment ?: "Selected File"
        }
    }

    Box(Modifier.fillMaxSize()) {
        MeshBackground()
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                GradientTitle(L("محوّل الصيغ واستخراج الصوت", "Format Converter & Audio Extractor"))
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        BasicText(
                            if (pickedUri != null) pickedName else L("اختر ملف فيديو أو صوت من جهازك للتحويل الفعلي", "Pick a real video or audio file from your device"),
                            style = JoDonDesign.typography.label
                        )
                        GhostButton(
                            text = L("اختيار ملف من الجهاز", "Choose Local File"),
                            glyph = JoDonGlyph.FOLDER,
                            onClick = { picker.launch(arrayOf("video/*", "audio/*", "image/*")) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        BasicText(L("الصيغة الهدف", "Target Format"), style = JoDonDesign.typography.label)
                        val formats = listOf("M4A", "MP3", "OPUS", "FLAC", "WAV", "MP4", "MKV", "WEBM", "WEBP")
                        formats.chunked(3).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                row.forEach { f ->
                                    PillChip(f, format == f, { format = f }, Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }

            item {
                PrimaryButton(
                    text = if (busy) L("جارٍ المعالجة الفعلية...", "Converting...") else L("تحويل وحفظ نسخة جديدة", "Convert & Save New File"),
                    glyph = JoDonGlyph.CONVERT,
                    onClick = { pickedUri?.let { vm.convertUri(it, format) } },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            status?.let { msg ->
                item {
                    GlassCard(Modifier.fillMaxWidth()) {
                        BasicText(msg, style = JoDonDesign.typography.caption.copy(color = theme.accent1))
                    }
                }
            }
            item { Spacer(Modifier.height(96.dp)) }
        }
    }
}
