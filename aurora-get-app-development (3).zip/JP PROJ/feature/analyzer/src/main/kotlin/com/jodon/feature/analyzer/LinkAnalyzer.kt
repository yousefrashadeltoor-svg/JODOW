package com.jodon.feature.analyzer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jodon.core.common.AnalysisResult
import com.jodon.core.common.MediaFormat
import com.jodon.core.common.UrlNormalizer
import com.jodon.core.network.JoDonCookieJar
import com.jodon.core.network.PreconnectManager
import com.jodon.core.network.SizeResolver
import com.jodon.core.storage.AnalysisCacheStore
import com.jodon.engine.extractors.NativeExtractors
import com.jodon.engine.extractors.YtDlpExtractor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.channelFlow
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.debounce
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import java.util.Collections
import javax.inject.Inject
import javax.inject.Singleton

data class AnalysisState(
    val url: String = "",
    val result: AnalysisResult? = null,
    val activeStage: Int = -1,
    val analyzing: Boolean = false,
    val error: String? = null
)

fun mergeResults(a: AnalysisResult, b: AnalysisResult): AnalysisResult = a.copy(
    siteName = b.siteName.ifBlank { a.siteName },
    faviconUrl = b.faviconUrl.ifBlank { a.faviconUrl },
    title = b.title.ifBlank { a.title },
    fileName = b.fileName.ifBlank { a.fileName },
    thumbnailUrl = b.thumbnailUrl.ifBlank { a.thumbnailUrl },
    durationSeconds = b.durationSeconds ?: a.durationSeconds,
    uploader = b.uploader.ifBlank { a.uploader },
    publishDate = b.publishDate.ifBlank { a.publishDate },
    formats = (a.formats + b.formats).distinctBy { it.id },
    subtitles = (a.subtitles + b.subtitles).distinctBy { it.id },
    completedStages = a.completedStages + b.completedStages,
    directPage = b.directPage && a.formats.isEmpty()
)

@Singleton
class AnalyzerPipeline @Inject constructor(
    private val native: NativeExtractors,
    private val ytdlp: YtDlpExtractor,
    private val sizeResolver: SizeResolver,
    private val preconnect: PreconnectManager,
    private val cookieJar: JoDonCookieJar,
    private val cache: AnalysisCacheStore
) {
    @OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
    fun observe(rawFlow: Flow<String>): Flow<AnalysisState> =
        rawFlow
            .map { UrlNormalizer.normalize(it) }
            .distinctUntilChanged()
            .debounce(150)
            .flatMapLatest { url -> runPipeline(url) }

    private fun runPipeline(url: String): Flow<AnalysisState> = channelFlow {
        if (url.isBlank()) {
            send(AnalysisState())
            return@channelFlow
        }
        val base = AnalysisResult(
            url = url,
            domain = UrlNormalizer.domain(url),
            siteName = UrlNormalizer.siteName(url),
            fileName = UrlNormalizer.sanitizeFileName(UrlNormalizer.fileName(url)),
            completedStages = setOf(0)
        )
        send(AnalysisState(url, base, 0, true))

        cache.get(url)?.let { hit ->
            send(AnalysisState(url, hit, 4, false))
            return@channelFlow
        }

        preconnect.warm(url)
        val headers = buildHeaders(url)
        val collected = Collections.synchronizedList(mutableListOf(base))

        coroutineScope {
            val s1 = async(Dispatchers.IO) {
                val sz = sizeResolver.headSize(url, headers) ?: sizeResolver.rangeSize(url, headers)
                val fmt = sz?.let {
                    MediaFormat(
                        id = "head-0", url = url, kind = UrlNormalizer.kindOf(null, url),
                        label = "Direct", quality = UrlNormalizer.extension(url).uppercase().ifBlank { "FILE" },
                        container = UrlNormalizer.extension(url).uppercase().ifBlank { "BIN" },
                        codec = "HTTP Stream", size = it, headers = headers
                    )
                }
                base.copy(formats = listOfNotNull(fmt), completedStages = setOf(0, 1))
            }
            val s2 = async(Dispatchers.IO) { runCatching { native.extract(url, headers) }.getOrNull() }
            val s3 = async(Dispatchers.IO) { runCatching { ytdlp.extract(url) }.getOrNull() }

            listOf(1 to s1, 2 to s2, 3 to s3).map { (stageIdx, job) ->
                async(Dispatchers.IO) {
                    val res = job.await() ?: return@async
                    val combined = synchronized(collected) {
                        collected.add(res)
                        collected.reduce(::mergeResults)
                    }
                    send(AnalysisState(url, combined, stageIdx, true))
                }
            }.awaitAll()
        }

        val finalRes = synchronized(collected) { collected.reduce(::mergeResults) }
        if (finalRes.formats.isNotEmpty()) cache.put(url, finalRes)
        send(AnalysisState(url, finalRes, 4, false, if (finalRes.formats.isEmpty()) "No downloadable media detected" else null))
    }.flowOn(Dispatchers.Default)

    private fun buildHeaders(url: String): Map<String, String> {
        val http = url.toHttpUrlOrNull() ?: return emptyMap()
        return buildMap {
            val c = cookieJar.cookieHeader(http)
            if (c.isNotBlank()) put("Cookie", c)
            if (cookieJar.lastUserAgent.isNotBlank()) put("User-Agent", cookieJar.lastUserAgent)
            put("Referer", "${http.scheme}://${http.host}/")
        }
    }
}

@HiltViewModel
class AnalyzerViewModel @Inject constructor(
    private val pipeline: AnalyzerPipeline
) : ViewModel() {
    private val queryFlow = MutableSharedFlow<String>(replay = 1)
    private val _state = MutableStateFlow(AnalysisState())
    val state: StateFlow<AnalysisState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            pipeline.observe(queryFlow).collect { _state.value = it }
        }
    }

    fun submitUrl(raw: String) {
        _state.value = _state.value.copy(url = raw, error = null)
        viewModelScope.launch { queryFlow.emit(raw) }
    }

    fun clear() {
        _state.value = AnalysisState()
        viewModelScope.launch { queryFlow.emit("") }
    }
}
