package com.jodon.feature.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.pm.PackageManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.jodon.core.common.LocalMediaItem
import com.jodon.core.common.RepeatModeType
import com.jodon.core.common.VisualizerMode
import com.jodon.core.common.formatDuration
import com.jodon.core.designsystem.GhostButton
import com.jodon.core.designsystem.GlassBottomSheet
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.IconBtn
import com.jodon.core.designsystem.JoDonDesign
import com.jodon.core.designsystem.JoDonGlyph
import com.jodon.core.designsystem.JoDonIcon
import com.jodon.core.designsystem.JoDonSlider
import com.jodon.core.designsystem.MeshBackground
import com.jodon.core.designsystem.PillChip
import com.jodon.core.designsystem.PrimaryButton
import com.jodon.core.designsystem.VisualWaveformTrimmer
import com.jodon.engine.media.NativeMediaToolkit
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject
import kotlin.math.cos
import kotlin.math.sin

class JoDonPlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this).build()
        mediaSession = MediaSession.Builder(this, player).build()
    }
    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession
    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }
}

data class PlayerUiState(
    val queue: List<LocalMediaItem> = emptyList(),
    val currentIndex: Int = 0,
    val playAsSongMode: Boolean = false,
    val repeatMode: RepeatModeType = RepeatModeType.OFF,
    val shuffleEnabled: Boolean = false,
    val loopAMs: Long? = null,
    val loopBMs: Long? = null,
    val sleepTimerRemainingSec: Long? = null,
    val sleepStopAtEndOfTrack: Boolean = false,
    val playbackSpeed: Float = 1f,
    val playbackPitch: Float = 1f,
    val visualizerMode: VisualizerMode = VisualizerMode.SPECTRUM_BARS,
    val screenLocked: Boolean = false,
    val waveformPeaks: List<Float> = emptyList(),
    val trimStartFrac: Float = 0.1f,
    val trimEndFrac: Float = 0.85f,
    val statusMessage: String? = null
) {
    val currentItem: LocalMediaItem? get() = queue.getOrNull(currentIndex)
}

@HiltViewModel
class LuxuryPlayerViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    val mediaToolkit: NativeMediaToolkit
) : ViewModel() {
    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    fun loadQueue(items: List<LocalMediaItem>, startIndex: Int = 0, asSong: Boolean = false) {
        if (items.isEmpty()) return
        val idx = startIndex.coerceIn(items.indices)
        val target = items[idx]
        _state.value = _state.value.copy(
            queue = items,
            currentIndex = idx,
            playAsSongMode = asSong || !target.isVideo,
            loopAMs = null,
            loopBMs = null,
            trimStartFrac = 0.08f,
            trimEndFrac = 0.92f
        )
        decodeWaveform(Uri.parse(target.uriString))
    }

    private fun decodeWaveform(uri: Uri) {
        viewModelScope.launch {
            val peaks = mediaToolkit.extractWaveform(uri)
            _state.value = _state.value.copy(waveformPeaks = peaks)
        }
    }

    fun selectTrack(index: Int) {
        val q = _state.value.queue
        if (index !in q.indices) return
        _state.value = _state.value.copy(currentIndex = index, loopAMs = null, loopBMs = null)
        decodeWaveform(Uri.parse(q[index].uriString))
    }

    fun nextTrack() {
        val q = _state.value.queue
        if (q.isEmpty()) return
        val next = if (_state.value.shuffleEnabled) q.indices.random() else (_state.value.currentIndex + 1) % q.size
        selectTrack(next)
    }

    fun prevTrack() {
        val q = _state.value.queue
        if (q.isEmpty()) return
        val prev = (_state.value.currentIndex - 1 + q.size) % q.size
        selectTrack(prev)
    }

    fun toggleSongMode() { _state.value = _state.value.copy(playAsSongMode = !_state.value.playAsSongMode) }
    fun toggleLock() { _state.value = _state.value.copy(screenLocked = !_state.value.screenLocked) }
    fun toggleShuffle() { _state.value = _state.value.copy(shuffleEnabled = !_state.value.shuffleEnabled) }

    fun cycleRepeatMode() {
        val next = when (_state.value.repeatMode) {
            RepeatModeType.OFF -> RepeatModeType.ALL
            RepeatModeType.ALL -> RepeatModeType.ONE
            RepeatModeType.ONE -> RepeatModeType.AB_LOOP
            RepeatModeType.AB_LOOP -> RepeatModeType.OFF
        }
        _state.value = _state.value.copy(repeatMode = next)
    }

    fun setAbPoint(posMs: Long) {
        val s = _state.value
        if (s.loopAMs == null || s.loopBMs != null) {
            _state.value = s.copy(loopAMs = posMs, loopBMs = null, repeatMode = RepeatModeType.AB_LOOP)
        } else if (posMs > s.loopAMs) {
            _state.value = s.copy(loopBMs = posMs, repeatMode = RepeatModeType.AB_LOOP)
        }
    }

    fun setSpeedAndPitch(speed: Float, pitch: Float) {
        _state.value = _state.value.copy(playbackSpeed = speed.coerceIn(0.25f, 3f), playbackPitch = pitch.coerceIn(0.5f, 2f))
    }

    fun cycleVisualizer() {
        val modes = VisualizerMode.entries
        val next = modes[(_state.value.visualizerMode.ordinal + 1) % modes.size]
        _state.value = _state.value.copy(visualizerMode = next)
    }

    fun startSleepTimer(minutes: Int?, stopAtEnd: Boolean = false) {
        _state.value = _state.value.copy(
            sleepTimerRemainingSec = minutes?.let { it * 60L },
            sleepStopAtEndOfTrack = stopAtEnd
        )
    }

    fun tickSleepTimer(): Boolean {
        val rem = _state.value.sleepTimerRemainingSec ?: return false
        if (rem <= 1L) {
            _state.value = _state.value.copy(sleepTimerRemainingSec = null)
            return true
        }
        _state.value = _state.value.copy(sleepTimerRemainingSec = rem - 1L)
        return false
    }

    fun updateTrimHandles(startF: Float, endF: Float) {
        _state.value = _state.value.copy(trimStartFrac = startF, trimEndFrac = endF)
    }

    fun exportVisualTrim(durationMs: Long, audioOnly: Boolean, isArabic: Boolean) {
        val cur = _state.value.currentItem ?: return
        val startMs = (_state.value.trimStartFrac * durationMs).toLong()
        val endMs = (_state.value.trimEndFrac * durationMs).toLong()
        viewModelScope.launch {
            val outDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "JoDon/Trimmed").apply { mkdirs() }
            val ext = if (audioOnly) "m4a" else "mp4"
            val outFile = File(outDir, "${cur.title.take(40)}_cut_${System.currentTimeMillis()}.$ext")
            val res = mediaToolkit.trimMedia(Uri.parse(cur.uriString), startMs, endMs, audioOnly, outFile)
            _state.value = _state.value.copy(
                statusMessage = if (res.success) {
                    if (isArabic) "تم حفظ المقطع المقصوص: ${outFile.name}" else "Saved cut: ${outFile.name}"
                } else res.message
            )
        }
    }

    fun applyTrimAsRingtone(durationMs: Long, isArabic: Boolean) {
        val cur = _state.value.currentItem ?: return
        if (!mediaToolkit.canWriteSystemSettings()) {
            context.startActivity(mediaToolkit.requestWriteSettingsIntent())
            _state.value = _state.value.copy(
                statusMessage = if (isArabic) "يرجى منح إذن تعديل إعدادات النظام ثم الضغط مجدداً لتعيين النغمة"
                else "Grant Modify System Settings permission then tap again"
            )
            return
        }
        val startMs = (_state.value.trimStartFrac * durationMs).toLong()
        val endMs = (_state.value.trimEndFrac * durationMs).toLong()
        viewModelScope.launch {
            val res = mediaToolkit.trimAndSetRingtone(Uri.parse(cur.uriString), startMs, endMs, cur.title)
            _state.value = _state.value.copy(
                statusMessage = if (res.success) {
                    if (isArabic) "تم قص المقطع وتعيينه كنغمة رنين للهاتف بنجاح!" else "Set as phone ringtone!"
                } else res.message
            )
        }
    }
}

@Composable
fun LuxuryPlayerScreen(
    isArabic: Boolean,
    vm: LuxuryPlayerViewModel = hiltViewModel(),
    onPickFilesRequest: () -> Unit = {}
) {
    val context = LocalContext.current
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    val ui by vm.state.collectAsState()
    val theme = JoDonDesign.theme
    val current = ui.currentItem

    var playing by remember { mutableStateOf(true) }
    var posMs by remember { mutableLongStateOf(0L) }
    var durMs by remember { mutableLongStateOf(1L) }
    var activeSheet by remember { mutableStateOf<String?>(null) } // trim, eq, sleep
    var fftMagnitudes by remember { mutableStateOf(FloatArray(48) { 0.1f }) }
    var resizeMode by remember { mutableStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var eqBands by remember { mutableStateOf(listOf(0.5f, 0.5f, 0.5f, 0.5f, 0.5f)) }
    var bassLevel by remember { mutableFloatStateOf(0f) }

    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = true
        }
    }

    // Attach MediaItem when current track changes
    LaunchedEffect(current?.uriString) {
        if (current != null) {
            player.setMediaItem(MediaItem.fromUri(current.uriString))
            player.prepare()
            player.playWhenReady = true
            playing = true
        }
    }

    // Sync speed, pitch & repeat mode
    LaunchedEffect(ui.playbackSpeed, ui.playbackPitch, ui.repeatMode) {
        player.playbackParameters = PlaybackParameters(ui.playbackSpeed, ui.playbackPitch)
        player.repeatMode = when (ui.repeatMode) {
            RepeatModeType.ONE -> Player.REPEAT_MODE_ONE
            RepeatModeType.ALL -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
    }

    // Track end listener (Sleep at end of track + auto-advance)
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    if (ui.sleepStopAtEndOfTrack) {
                        player.pause()
                        playing = false
                        vm.startSleepTimer(null, false)
                    } else if (ui.repeatMode != RepeatModeType.ONE) {
                        vm.nextTrack()
                    }
                }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    // Attach hardware Visualizer + Equalizer + BassBoost when audioSessionId is active
    DisposableEffect(player, eqBands, bassLevel) {
        val sessionId = player.audioSessionId
        var visualizer: Visualizer? = null
        var equalizer: Equalizer? = null
        var bassBoost: BassBoost? = null
        runCatching {
            if (sessionId != 0) {
                equalizer = Equalizer(0, sessionId).apply {
                    enabled = true
                    val range = bandLevelRange
                    val minMb = range[0]
                    val maxMb = range[1]
                    for (b in 0 until minOf(numberOfBands.toInt(), 5)) {
                        val level = (minMb + (maxMb - minMb) * eqBands[b]).toInt().toShort()
                        setBandLevel(b.toShort(), level)
                    }
                }
                bassBoost = BassBoost(0, sessionId).apply {
                    enabled = true
                    setStrength((bassLevel * 1000).toInt().toShort())
                }
                visualizer = Visualizer(sessionId).apply {
                    captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(512)
                    setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) = Unit
                        override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                            if (fft == null) return
                            val bins = FloatArray(48)
                            for (i in bins.indices) {
                                val idx = (i * 2 + 2).coerceAtMost(fft.size - 2)
                                val re = fft[idx].toFloat()
                                val im = fft[idx + 1].toFloat()
                                bins[i] = (kotlin.math.hypot(re, im) / 96f).coerceIn(0.05f, 1f)
                            }
                            fftMagnitudes = bins
                        }
                    }, Visualizer.getMaxCaptureRate() / 2, false, true)
                    enabled = true
                }
            }
        }
        onDispose {
            runCatching { visualizer?.release() }
            runCatching { equalizer?.release() }
            runCatching { bassBoost?.release() }
        }
    }

    // Progress + A-B loop + Sleep timer fade-out coroutine
    LaunchedEffect(player) {
        var tickAcc = 0
        while (isActive) {
            posMs = player.currentPosition.coerceAtLeast(0L)
            durMs = player.duration.takeIf { it > 0L } ?: 1L
            playing = player.isPlaying
            if (ui.repeatMode == RepeatModeType.AB_LOOP && ui.loopAMs != null && ui.loopBMs != null) {
                if (posMs >= ui.loopBMs!!) player.seekTo(ui.loopAMs!!)
            }
            tickAcc += 200
            if (tickAcc >= 1000) {
                tickAcc = 0
                val rem = ui.sleepTimerRemainingSec
                if (rem != null && rem <= 10L) {
                    player.volume = (rem / 10f).coerceIn(0.05f, 1f)
                } else {
                    player.volume = 1f
                }
                if (vm.tickSleepTimer()) {
                    player.pause()
                    player.volume = 1f
                }
            }
            delay(200)
        }
    }

    Box(Modifier.fillMaxSize()) {
        MeshBackground()
        if (current == null) {
            Column(
                Modifier.fillMaxSize().padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                JoDonIcon(JoDonGlyph.PLAYER, null, Modifier.size(56.dp), theme.accent1)
                Spacer(Modifier.height(16.dp))
                BasicText(L("المشغل الفاخر للفيديو والموسيقى", "Luxury Video & Music Player"), style = JoDonDesign.typography.headline)
                Spacer(Modifier.height(8.dp))
                BasicText(
                    L("اختر أي فيديو أو أغنية محلية من مكتبتك للاستمتاع بالقص المرئي اليدوي، النغمات، مؤقت النوم، والمؤثرات الصوتية والبصرية.", "Pick any local video or song from your device library to play, trim visually, set as ringtone, or apply live visualizers."),
                    style = JoDonDesign.typography.body.copy(color = theme.muted)
                )
                Spacer(Modifier.height(18.dp))
                PrimaryButton(L("فتح ملفات الجهاز والموسيقى", "Browse Local Videos & Music"), onPickFilesRequest, glyph = JoDonGlyph.FOLDER)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PillChip(
                            text = if (ui.playAsSongMode) L("وضع الأغنية الصوتية", "Song Mode") else L("وضع الفيديو", "Video Mode"),
                            active = true,
                            onClick = vm::toggleSongMode
                        )
                        Spacer(Modifier.width(8.dp))
                        ui.sleepTimerRemainingSec?.let { sec ->
                            PillChip("⏱ ${formatDuration(sec)}", active = true, onClick = { activeSheet = "sleep" })
                        }
                        Spacer(Modifier.weight(1f))
                        IconBtn(JoDonGlyph.LOCK, "Lock Controls", vm::toggleLock)
                        Spacer(Modifier.width(6.dp))
                        if (!ui.playAsSongMode && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            IconBtn(JoDonGlyph.VIDEO, "PiP", {
                                if (context.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
                                    (context as? Activity)?.enterPictureInPictureMode(PictureInPictureParams.Builder().build())
                                }
                            })
                        }
                    }
                }

                // Video Surface OR Luxury Song Visualizer Stage
                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(250.dp)
                            .clip(JoDonDesign.shapes.large)
                            .background(theme.surface)
                            .border(1.dp, theme.border, JoDonDesign.shapes.large)
                            .pointerInput(ui.screenLocked) {
                                if (!ui.screenLocked) {
                                    detectTapGestures(
                                        onDoubleTap = { offset ->
                                            val delta = if (offset.x < size.width / 2f) -10_000L else 10_000L
                                            player.seekTo((player.currentPosition + delta).coerceIn(0L, durMs))
                                        }
                                    )
                                }
                            }
                            .pointerInput(ui.screenLocked) {
                                if (!ui.screenLocked) {
                                    detectVerticalDragGestures { change, dragAmount ->
                                        if (change.position.x < size.width / 2f) {
                                            val win = (context as? Activity)?.window ?: return@detectVerticalDragGestures
                                            val lp = win.attributes
                                            val curB = if (lp.screenBrightness < 0) 0.5f else lp.screenBrightness
                                            lp.screenBrightness = (curB - dragAmount / 600f).coerceIn(0.05f, 1f)
                                            win.attributes = lp
                                        }
                                    }
                                }
                            }
                    ) {
                        if (!ui.playAsSongMode && current.isVideo) {
                            AndroidView(
                                modifier = Modifier.fillMaxSize(),
                                factory = { ctx ->
                                    PlayerView(ctx).apply {
                                        this.player = player
                                        useController = false
                                        this.resizeMode = resizeMode
                                    }
                                },
                                update = { view ->
                                    view.player = player
                                    view.resizeMode = resizeMode
                                }
                            )
                        } else {
                            AudioVisualizerStage(
                                mode = ui.visualizerMode,
                                bins = fftMagnitudes,
                                modifier = Modifier.fillMaxSize()
                            )
                            Column(
                                Modifier.align(Alignment.Center).padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                JoDonIcon(JoDonGlyph.MUSIC, null, Modifier.size(44.dp), Color.White)
                                Spacer(Modifier.height(8.dp))
                                PillChip(
                                    text = L("تبديل التأثير البصري", "Switch Visualizer") + " · ${ui.visualizerMode.name}",
                                    onClick = vm::cycleVisualizer
                                )
                            }
                        }
                    }
                }

                // Track Info & Seekbar with A-B markers
                item {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column {
                            BasicText(current.title, style = JoDonDesign.typography.title)
                            BasicText(
                                listOf(current.artist.ifBlank { L("ملف محلي", "Local Media") }, current.album).filter { it.isNotBlank() }.joinToString(" · "),
                                style = JoDonDesign.typography.caption.copy(color = theme.muted)
                            )
                            Spacer(Modifier.height(10.dp))
                            JoDonSlider(
                                value = (posMs.toFloat() / durMs.coerceAtLeast(1L)).coerceIn(0f, 1f),
                                onValueChange = { frac -> if (!ui.screenLocked) player.seekTo((frac * durMs).toLong()) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                BasicText(formatDuration(posMs / 1000L), style = JoDonDesign.typography.numeric)
                                if (ui.loopAMs != null) {
                                    BasicText(
                                        "A:${formatDuration(ui.loopAMs!! / 1000)} - B:${ui.loopBMs?.let { formatDuration(it / 1000) } ?: "..."}",
                                        style = JoDonDesign.typography.numeric.copy(color = theme.accent2)
                                    )
                                }
                                BasicText(formatDuration(durMs / 1000L), style = JoDonDesign.typography.numeric)
                            }
                            Spacer(Modifier.height(10.dp))
                            if (!ui.screenLocked) {
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    PillChip(
                                        text = when (ui.repeatMode) {
                                            RepeatModeType.OFF -> L("تكرار: إيقاف", "Repeat: Off")
                                            RepeatModeType.ALL -> L("تكرار الكل", "Repeat All")
                                            RepeatModeType.ONE -> L("تكرار المقطع", "Repeat One")
                                            RepeatModeType.AB_LOOP -> "A–B Loop"
                                        },
                                        active = ui.repeatMode != RepeatModeType.OFF,
                                        onClick = vm::cycleRepeatMode
                                    )
                                    IconBtn(JoDonGlyph.ARROW_LEFT, "Prev", vm::prevTrack)
                                    PrimaryButton(
                                        text = if (playing) L("إيقاف مؤقت", "Pause") else L("تشغيل", "Play"),
                                        glyph = if (playing) JoDonGlyph.PAUSE else JoDonGlyph.PLAY,
                                        onClick = { if (player.isPlaying) player.pause() else player.play() }
                                    )
                                    IconBtn(JoDonGlyph.ARROW_RIGHT, "Next", vm::nextTrack)
                                    PillChip(
                                        text = if (ui.shuffleEnabled) L("خلط ✓", "Shuffle ✓") else L("خلط", "Shuffle"),
                                        active = ui.shuffleEnabled,
                                        onClick = vm::toggleShuffle
                                    )
                                }
                            }
                        }
                    }
                }

                // Pro Tools Grid: Play as Song, Visual Manual Trimmer, Ringtone, Sleep Timer, A-B Loop, Audio FX
                item {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            BasicText(L("أدوات الاستوديو والتحكم الفاخر", "Studio & Pro Media Controls"), style = JoDonDesign.typography.label)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                GhostButton(
                                    text = L("القص المرئي اليدوي + نغمة رنين", "Visual Trimmer & Ringtone"),
                                    glyph = JoDonGlyph.SCISSORS,
                                    onClick = { activeSheet = "trim" },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                GhostButton(
                                    text = if (ui.playAsSongMode) L("إظهار الفيديو", "Video View") else L("تشغيل كأغنية", "Play as Song"),
                                    glyph = JoDonGlyph.MUSIC,
                                    onClick = vm::toggleSongMode,
                                    modifier = Modifier.weight(1f)
                                )
                                GhostButton(
                                    text = L("نقطة A–B", "Set A–B"),
                                    glyph = JoDonGlyph.REPEAT,
                                    onClick = { vm.setAbPoint(posMs) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                GhostButton(
                                    text = L("مؤقت النوم", "Sleep Timer"),
                                    glyph = JoDonGlyph.TIMER,
                                    onClick = { activeSheet = "sleep" },
                                    modifier = Modifier.weight(1f)
                                )
                                GhostButton(
                                    text = L("معادل الصوت والسرعة", "EQ & Speed"),
                                    glyph = JoDonGlyph.SLIDERS,
                                    onClick = { activeSheet = "eq" },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (!ui.playAsSongMode && current.isVideo) {
                                GhostButton(
                                    text = L("تغيير أبعاد الشاشة (Fit / Fill / Zoom)", "Cycle Aspect Ratio"),
                                    glyph = JoDonGlyph.VIDEO,
                                    onClick = {
                                        resizeMode = when (resizeMode) {
                                            AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                            AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                ui.statusMessage?.let { msg ->
                    item {
                        GlassCard(Modifier.fillMaxWidth()) {
                            BasicText(msg, style = JoDonDesign.typography.label.copy(color = theme.success))
                        }
                    }
                }

                item { Spacer(Modifier.height(96.dp)) }
            }
        }

        // Visual Manual Trimmer & Ringtone Sheet (NO number typing — tactile drag handles!)
        if (activeSheet == "trim" && current != null) {
            val startSec = (ui.trimStartFrac * durMs / 1000L).toLong()
            val endSec = (ui.trimEndFrac * durMs / 1000L).toLong()
            GlassBottomSheet(
                visible = true,
                title = L("القص المرئي اليدوي وصانع نغمات الرنين", "Visual Manual Trimmer & Ringtone Studio"),
                onDismiss = { activeSheet = null }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    BasicText(
                        L("اسحب المقبضين الأيمن والأيسر بإصبعك مباشرة فوق الموجة الصوتية لتحديد المقطع بدقة:", "Drag the left and right handles directly over the audio waveform:"),
                        style = JoDonDesign.typography.caption.copy(color = theme.muted)
                    )
                    VisualWaveformTrimmer(
                        amplitudes = ui.waveformPeaks,
                        startFraction = ui.trimStartFrac,
                        endFraction = ui.trimEndFrac,
                        playheadFraction = (posMs.toFloat() / durMs.coerceAtLeast(1L)).coerceIn(0f, 1f),
                        onRangeChange = { s, e ->
                            vm.updateTrimHandles(s, e)
                            player.seekTo((s * durMs).toLong())
                        },
                        onScrub = { p -> player.seekTo((p * durMs).toLong()) }
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        PillChip("${L("البداية", "Start")}: ${formatDuration(startSec)}", active = true)
                        PillChip("${L("المدة", "Length")}: ${formatDuration((endSec - startSec).coerceAtLeast(0L))}")
                        PillChip("${L("النهاية", "End")}: ${formatDuration(endSec)}", active = true)
                    }
                    GhostButton(
                        text = L("معاينة المقطع المحدد", "Preview Selected Cut"),
                        glyph = JoDonGlyph.PLAY,
                        onClick = { player.seekTo((ui.trimStartFrac * durMs).toLong()); player.play() },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PrimaryButton(
                            text = L("حفظ كفيديو مقصوص", "Save Video Cut"),
                            glyph = JoDonGlyph.SCISSORS,
                            onClick = { vm.exportVisualTrim(durMs, audioOnly = false, isArabic = isArabic); activeSheet = null },
                            modifier = Modifier.weight(1f)
                        )
                        PrimaryButton(
                            text = L("حفظ كمقطع صوتي", "Save Audio Cut"),
                            glyph = JoDonGlyph.MUSIC,
                            onClick = { vm.exportVisualTrim(durMs, audioOnly = true, isArabic = isArabic); activeSheet = null },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    PrimaryButton(
                        text = L("تعيين المقطع المحدد كنغمة رنين للهاتف", "Set Trimmed Cut as Phone Ringtone"),
                        glyph = JoDonGlyph.BELL_RING,
                        onClick = { vm.applyTrimAsRingtone(durMs, isArabic); activeSheet = null },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Sleep Timer Sheet
        if (activeSheet == "sleep") {
            GlassBottomSheet(
                visible = true,
                title = L("مؤقت النوم الذكي (مع خفوت تدريجي للصوت)", "Smart Sleep Timer (Smooth Fade-out)"),
                onDismiss = { activeSheet = null }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 15, 30, 45, 60).forEach { mins ->
                            PillChip("${mins}m", onClick = { vm.startSleepTimer(mins); activeSheet = null }, modifier = Modifier.weight(1f))
                        }
                    }
                    PrimaryButton(
                        text = L("إيقاف عند انتهاء المقطع الحالي", "Stop at End of Current Track"),
                        glyph = JoDonGlyph.TIMER,
                        onClick = { vm.startSleepTimer(null, stopAtEnd = true); activeSheet = null },
                        modifier = Modifier.fillMaxWidth()
                    )
                    GhostButton(
                        text = L("إلغاء مؤقت النوم", "Cancel Sleep Timer"),
                        onClick = { vm.startSleepTimer(null, false); activeSheet = null },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // 5-Band Equalizer + Bass Boost + Speed & Pitch Sheet
        if (activeSheet == "eq") {
            GlassBottomSheet(
                visible = true,
                title = L("معادل الصوت والسرعة والطبقة", "5-Band Equalizer, Bass & Pitch"),
                onDismiss = { activeSheet = null }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("60Hz", "230Hz", "910Hz", "3.6kHz", "14kHz").forEachIndexed { idx, freq ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            BasicText(freq, Modifier.width(56.dp), style = JoDonDesign.typography.numeric)
                            JoDonSlider(
                                value = eqBands[idx],
                                onValueChange = { v -> eqBands = eqBands.toMutableList().also { it[idx] = v } },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BasicText("Bass", Modifier.width(56.dp), style = JoDonDesign.typography.label)
                        JoDonSlider(bassLevel, { bassLevel = it }, Modifier.weight(1f))
                    }
                    BasicText("${L("السرعة", "Speed")}: ${String.format("%.2fx", ui.playbackSpeed)} · ${L("الطبقة", "Pitch")}: ${String.format("%.2fx", ui.playbackPitch)}", style = JoDonDesign.typography.numeric)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PillChip("1.0x Normal", onClick = { vm.setSpeedAndPitch(1f, 1f) })
                        PillChip("1.25x Nightcore", onClick = { vm.setSpeedAndPitch(1.25f, 1.2f) })
                        PillChip("0.85x Slowed", onClick = { vm.setSpeedAndPitch(0.85f, 0.88f) })
                        PillChip("2.0x Fast", onClick = { vm.setSpeedAndPitch(2f, 1f) })
                    }
                }
            }
        }
    }
}

@Composable
private fun AudioVisualizerStage(mode: VisualizerMode, bins: FloatArray, modifier: Modifier = Modifier) {
    val theme = JoDonDesign.theme
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        when (mode) {
            VisualizerMode.SPECTRUM_BARS -> {
                val step = w / bins.size
                bins.forEachIndexed { i, v ->
                    val bh = v * h * 0.78f
                    drawLine(
                        brush = Brush.verticalGradient(listOf(theme.accent1, theme.accent2, theme.accent3)),
                        start = Offset(i * step + step / 2f, h - 16f),
                        end = Offset(i * step + step / 2f, (h - 16f - bh).coerceAtLeast(12f)),
                        strokeWidth = (step * 0.65f).coerceAtLeast(3f),
                        cap = StrokeCap.Round
                    )
                }
            }
            VisualizerMode.LIQUID_WAVE -> {
                val path = Path()
                bins.forEachIndexed { i, v ->
                    val x = (i.toFloat() / (bins.size - 1)) * w
                    val y = h * 0.5f + sin(i * 0.4f) * v * h * 0.36f
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, theme.auroraBrush, style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round))
            }
            VisualizerMode.ORBIT_PULSE -> {
                val cx = w / 2f
                val cy = h / 2f
                val baseR = size.minDimension * 0.24f
                val avg = bins.average().toFloat()
                drawCircle(theme.accent2.copy(alpha = 0.25f), radius = baseR * (1f + avg * 0.8f), center = Offset(cx, cy))
                bins.forEachIndexed { i, v ->
                    val angle = (i.toFloat() / bins.size) * 6.28318f
                    val r1 = baseR
                    val r2 = baseR + v * baseR * 0.9f
                    drawLine(
                        theme.accent1,
                        Offset(cx + cos(angle) * r1, cy + sin(angle) * r1),
                        Offset(cx + cos(angle) * r2, cy + sin(angle) * r2),
                        strokeWidth = 3.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }
            VisualizerMode.PARTICLES -> {
                bins.forEachIndexed { i, v ->
                    val x = ((i * 73) % 100) / 100f * w
                    val y = h - (v * h * 0.85f)
                    drawCircle(theme.accent4.copy(alpha = 0.7f), radius = (3f + v * 10f), center = Offset(x, y))
                }
            }
            VisualizerMode.OFF -> Unit
        }
    }
}
