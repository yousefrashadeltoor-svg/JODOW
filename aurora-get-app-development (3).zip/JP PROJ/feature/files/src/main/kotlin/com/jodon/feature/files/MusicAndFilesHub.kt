package com.jodon.feature.files

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jodon.core.common.LocalMediaItem
import com.jodon.core.common.formatDuration
import com.jodon.core.common.humanBytes
import com.jodon.core.designsystem.GhostButton
import com.jodon.core.designsystem.GlassBottomSheet
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.GradientTitle
import com.jodon.core.designsystem.IconBtn
import com.jodon.core.designsystem.JoDonDesign
import com.jodon.core.designsystem.JoDonGlyph
import com.jodon.core.designsystem.JoDonIcon
import com.jodon.core.designsystem.MeshBackground
import com.jodon.core.designsystem.PillChip
import com.jodon.core.designsystem.PrimaryButton
import com.jodon.core.designsystem.jodonGlass
import com.jodon.core.designsystem.jodonPress
import com.jodon.core.storage.EncryptedVaultStore
import com.jodon.core.storage.MusicLibraryStore
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

enum class MediaHubSection { SONGS, VIDEOS, ALBUMS, ARTISTS, FOLDERS, PLAYLISTS, VAULT }

@HiltViewModel
class MusicAndFilesViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    val musicStore: MusicLibraryStore,
    val vaultStore: EncryptedVaultStore
) : ViewModel() {
    private val _songs = MutableStateFlow<List<LocalMediaItem>>(emptyList())
    val songs: StateFlow<List<LocalMediaItem>> = _songs.asStateFlow()

    private val _videos = MutableStateFlow<List<LocalMediaItem>>(emptyList())
    val videos: StateFlow<List<LocalMediaItem>> = _videos.asStateFlow()

    private val _vaultUnlocked = MutableStateFlow(false)
    val vaultUnlocked: StateFlow<Boolean> = _vaultUnlocked.asStateFlow()

    fun scanDeviceMedia() {
        viewModelScope.launch {
            _songs.value = queryAudioMedia()
            _videos.value = queryVideoMedia()
        }
    }

    fun addPickedUri(uriStr: String, name: String, isVideo: Boolean) {
        val item = LocalMediaItem(
            uriString = uriStr,
            title = name,
            artist = "Imported File",
            folderName = "Picked",
            isVideo = isVideo
        )
        if (isVideo) _videos.value = listOf(item) + _videos.value
        else _songs.value = listOf(item) + _songs.value
    }

    fun markVaultUnlocked(unlocked: Boolean) { _vaultUnlocked.value = unlocked }

    private suspend fun queryAudioMedia(): List<LocalMediaItem> = withContext(Dispatchers.IO) {
        val results = mutableListOf<LocalMediaItem>()
        runCatching {
            val proj = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Audio.Media.DATE_MODIFIED
            )
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                proj,
                "${MediaStore.Audio.Media.DURATION} >= 3000",
                null,
                "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val tCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val arCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val alCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val dCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val fCol = c.getColumnIndex(MediaStore.Audio.Media.BUCKET_DISPLAY_NAME)
                val mCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    results += LocalMediaItem(
                        uriString = uri.toString(),
                        title = c.getString(tCol).orEmpty().ifBlank { "Track $id" },
                        artist = c.getString(arCol).orEmpty().takeIf { it != "<unknown>" }.orEmpty(),
                        album = c.getString(alCol).orEmpty(),
                        folderName = if (fCol >= 0) c.getString(fCol).orEmpty() else "Music",
                        durationMs = c.getLong(dCol),
                        sizeBytes = c.getLong(sCol),
                        isVideo = false,
                        dateModifiedSec = c.getLong(mCol)
                    )
                }
            }
        }
        // Also include downloaded audio files in app's JoDon directory
        val appDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "JoDon")
        appDir.walkTopDown().filter { it.isFile && it.extension.lowercase() in setOf("mp3", "m4a", "opus", "flac", "wav", "ogg") }.forEach { f ->
            results += LocalMediaItem(
                uriString = android.net.Uri.fromFile(f).toString(),
                path = f.absolutePath,
                title = f.nameWithoutExtension,
                artist = "𝒥𝒪 DON Downloads",
                folderName = f.parentFile?.name ?: "JoDon",
                sizeBytes = f.length(),
                isVideo = false
            )
        }
        results.distinctBy { it.uriString }
    }

    private suspend fun queryVideoMedia(): List<LocalMediaItem> = withContext(Dispatchers.IO) {
        val results = mutableListOf<LocalMediaItem>()
        runCatching {
            val proj = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.TITLE,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.WIDTH,
                MediaStore.Video.Media.HEIGHT,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME
            )
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                proj,
                null,
                null,
                "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val tCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val dCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val wCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val hCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val fCol = c.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    results += LocalMediaItem(
                        uriString = uri.toString(),
                        title = c.getString(tCol).orEmpty().ifBlank { "Video $id" },
                        folderName = if (fCol >= 0) c.getString(fCol).orEmpty() else "Movies",
                        durationMs = c.getLong(dCol),
                        sizeBytes = c.getLong(sCol),
                        isVideo = true,
                        width = c.getInt(wCol),
                        height = c.getInt(hCol)
                    )
                }
            }
        }
        val appDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "JoDon")
        appDir.walkTopDown().filter { it.isFile && it.extension.lowercase() in setOf("mp4", "mkv", "webm", "mov") }.forEach { f ->
            results += LocalMediaItem(
                uriString = android.net.Uri.fromFile(f).toString(),
                path = f.absolutePath,
                title = f.nameWithoutExtension,
                folderName = f.parentFile?.name ?: "JoDon",
                sizeBytes = f.length(),
                isVideo = true
            )
        }
        results.distinctBy { it.uriString }
    }
}

@Composable
fun MusicAndFilesScreen(
    isArabic: Boolean,
    onPlayQueue: (List<LocalMediaItem>, Int, Boolean) -> Unit,
    vm: MusicAndFilesViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    val songs by vm.songs.collectAsState()
    val videos by vm.videos.collectAsState()
    val musicState by vm.musicStore.state.collectAsState()
    val vaultUnlocked by vm.vaultUnlocked.collectAsState()
    val theme = JoDonDesign.theme

    var section by remember { mutableStateOf(MediaHubSection.SONGS) }
    var search by remember { mutableStateOf("") }
    var newPlaylistDialog by remember { mutableStateOf(false) }
    var playlistName by remember { mutableStateOf("") }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.scanDeviceMedia()
    }
    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { u ->
            val mime = context.contentResolver.getType(u).orEmpty()
            vm.addPickedUri(u.toString(), u.lastPathSegment ?: "Local Media", mime.startsWith("video/"))
        }
    }

    LaunchedEffect(Unit) {
        vm.scanDeviceMedia()
    }

    val realTotalBytes = remember(songs, videos) { (songs + videos).sumOf { it.sizeBytes } }

    Box(Modifier.fillMaxSize()) {
        MeshBackground()
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                GradientTitle(L("استوديو الموسيقى والملفات المحلية", "Music Pages & Local Media Hub"))
                BasicText(
                    "${songs.size} ${L("أغنية", "Songs")} · ${videos.size} ${L("فيديو", "Videos")} · ${humanBytes(realTotalBytes)}",
                    style = JoDonDesign.typography.caption.copy(color = theme.muted)
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GhostButton(
                        text = L("فحص ملفات الجهاز", "Scan Device Media"),
                        glyph = JoDonGlyph.REFRESH,
                        onClick = {
                            val perms = if (android.os.Build.VERSION.SDK_INT >= 33) {
                                arrayOf(android.Manifest.permission.READ_MEDIA_AUDIO, android.Manifest.permission.READ_MEDIA_VIDEO)
                            } else {
                                arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                            }
                            permLauncher.launch(perms)
                        },
                        modifier = Modifier.weight(1f)
                    )
                    PrimaryButton(
                        text = L("اختيار ملفات", "Open Files"),
                        glyph = JoDonGlyph.FOLDER,
                        onClick = { docPicker.launch(arrayOf("audio/*", "video/*")) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Dedicated Music & Media Pages Selector
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val tabs = listOf(
                        MediaHubSection.SONGS to L("الأغاني", "Songs"),
                        MediaHubSection.VIDEOS to L("الفيديوهات", "Videos"),
                        MediaHubSection.ALBUMS to L("الألبومات", "Albums"),
                        MediaHubSection.ARTISTS to L("الفنانون", "Artists"),
                        MediaHubSection.FOLDERS to L("المجلدات", "Folders"),
                        MediaHubSection.PLAYLISTS to L("قوائم التشغيل", "Playlists"),
                        MediaHubSection.VAULT to L("القبو المشفر", "Private Vault")
                    )
                    itemsIndexed(tabs) { _, (sec, label) ->
                        PillChip(label, section == sec, { section = sec })
                    }
                }
            }

            item {
                BasicTextField(
                    value = search,
                    onValueChange = { search = it },
                    textStyle = JoDonDesign.typography.body.copy(color = theme.text),
                    modifier = Modifier.fillMaxWidth().jodonGlass(JoDonDesign.shapes.pill).padding(horizontal = 14.dp, vertical = 10.dp),
                    decorationBox = { inner ->
                        if (search.isEmpty()) BasicText(L("ابحث في أغانيك وفيديوهاتك...", "Filter local songs & videos..."), style = JoDonDesign.typography.caption.copy(color = theme.muted))
                        inner()
                    }
                )
            }

            when (section) {
                MediaHubSection.SONGS -> {
                    val filtered = songs.filter { search.isBlank() || it.title.contains(search, true) || it.artist.contains(search, true) }
                    itemsIndexed(filtered, key = { _, it -> it.uriString }) { idx, track ->
                        val fav = track.uriString in musicState.favoriteUris
                        GlassCard(Modifier.fillMaxWidth().jodonPress({ onPlayQueue(filtered, idx, true) }), JoDonDesign.shapes.medium) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                JoDonIcon(JoDonGlyph.MUSIC, null, Modifier.size(22.dp), theme.accent1)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    BasicText(track.title, style = JoDonDesign.typography.label)
                                    BasicText(
                                        listOf(track.artist.ifBlank { L("فنان غير معروف", "Unknown Artist") }, formatDuration(track.durationMs / 1000L), humanBytes(track.sizeBytes)).joinToString(" · "),
                                        style = JoDonDesign.typography.caption.copy(color = theme.muted)
                                    )
                                }
                                IconBtn(JoDonGlyph.HEART, "Favorite", { vm.musicStore.toggleFavorite(track.uriString) })
                                if (fav) {
                                    Spacer(Modifier.width(4.dp))
                                    BasicText("♥", style = JoDonDesign.typography.label.copy(color = theme.accent3))
                                }
                            }
                        }
                    }
                }
                MediaHubSection.VIDEOS -> {
                    val filtered = videos.filter { search.isBlank() || it.title.contains(search, true) }
                    itemsIndexed(filtered, key = { _, it -> it.uriString }) { idx, vid ->
                        GlassCard(Modifier.fillMaxWidth(), JoDonDesign.shapes.medium) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.jodonPress({ onPlayQueue(filtered, idx, false) })) {
                                    JoDonIcon(JoDonGlyph.VIDEO, null, Modifier.size(24.dp), theme.accent2)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        BasicText(vid.title, style = JoDonDesign.typography.label)
                                        BasicText("${formatDuration(vid.durationMs / 1000L)} · ${humanBytes(vid.sizeBytes)}", style = JoDonDesign.typography.caption.copy(color = theme.muted))
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    PrimaryButton(L("تشغيل الفيديو", "Play Video"), { onPlayQueue(filtered, idx, false) }, Modifier.weight(1f), JoDonGlyph.PLAY)
                                    GhostButton(L("تشغيل كأغنية", "Play as Song"), { onPlayQueue(filtered, idx, true) }, Modifier.weight(1f), JoDonGlyph.MUSIC)
                                }
                            }
                        }
                    }
                }
                MediaHubSection.ALBUMS -> {
                    val grouped = songs.groupBy { it.album.ifBlank { L("ألبوم عام", "Single") } }.entries.toList()
                    itemsIndexed(grouped) { _, (albumName, tracks) ->
                        GlassCard(Modifier.fillMaxWidth().jodonPress({ onPlayQueue(tracks, 0, true) }), JoDonDesign.shapes.medium) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    BasicText(albumName, style = JoDonDesign.typography.title)
                                    BasicText("${tracks.size} ${L("مقاطع صوتية", "tracks")}", style = JoDonDesign.typography.caption.copy(color = theme.muted))
                                }
                                JoDonIcon(JoDonGlyph.PLAY, null, Modifier.size(18.dp), theme.accent1)
                            }
                        }
                    }
                }
                MediaHubSection.ARTISTS -> {
                    val grouped = songs.groupBy { it.artist.ifBlank { L("فنان محلي", "Local Artist") } }.entries.toList()
                    itemsIndexed(grouped) { _, (artistName, tracks) ->
                        GlassCard(Modifier.fillMaxWidth().jodonPress({ onPlayQueue(tracks, 0, true) }), JoDonDesign.shapes.medium) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    BasicText(artistName, style = JoDonDesign.typography.title)
                                    BasicText("${tracks.size} ${L("أغاني", "songs")}", style = JoDonDesign.typography.caption.copy(color = theme.muted))
                                }
                                JoDonIcon(JoDonGlyph.PLAY, null, Modifier.size(18.dp), theme.accent1)
                            }
                        }
                    }
                }
                MediaHubSection.FOLDERS -> {
                    val grouped = (songs + videos).groupBy { it.folderName.ifBlank { "Root" } }.entries.toList()
                    itemsIndexed(grouped) { _, (folder, items) ->
                        GlassCard(Modifier.fillMaxWidth().jodonPress({ onPlayQueue(items, 0, false) }), JoDonDesign.shapes.medium) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                JoDonIcon(JoDonGlyph.FOLDER, null, Modifier.size(20.dp), theme.accent4)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    BasicText(folder, style = JoDonDesign.typography.label)
                                    BasicText("${items.size} ${L("عنصر", "items")}", style = JoDonDesign.typography.caption.copy(color = theme.muted))
                                }
                            }
                        }
                    }
                }
                MediaHubSection.PLAYLISTS -> {
                    item {
                        PrimaryButton(L("إنشاء قائمة تشغيل موسيقية جديدة", "Create New Music Playlist"), { newPlaylistDialog = true }, Modifier.fillMaxWidth(), JoDonGlyph.PLUS)
                    }
                    val favTracks = songs.filter { it.uriString in musicState.favoriteUris }
                    item {
                        GlassCard(Modifier.fillMaxWidth().jodonPress({ if (favTracks.isNotEmpty()) onPlayQueue(favTracks, 0, true) })) {
                            BasicText("${L("المفضلة ♥", "Favorites ♥")} (${favTracks.size})", style = JoDonDesign.typography.title)
                        }
                    }
                    itemsIndexed(musicState.playlists) { _, pl ->
                        val plTracks = songs.filter { it.uriString in pl.trackUris }
                        GlassCard(Modifier.fillMaxWidth().jodonPress({ if (plTracks.isNotEmpty()) onPlayQueue(plTracks, 0, true) })) {
                            BasicText("${pl.name} (${plTracks.size})", style = JoDonDesign.typography.title)
                        }
                    }
                }
                MediaHubSection.VAULT -> {
                    item {
                        GlassCard(Modifier.fillMaxWidth()) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                BasicText(L("القبو الخاص المشفر بـ AES-256 والبصمة", "AES-256 Biometric Private Vault"), style = JoDonDesign.typography.title)
                                if (!vaultUnlocked) {
                                    PrimaryButton(L("فتح القبو بالبصمة", "Unlock Vault"), {
                                        unlockBiometrics(context) { vm.markVaultUnlocked(true) }
                                    }, Modifier.fillMaxWidth(), JoDonGlyph.FINGERPRINT)
                                } else {
                                    val vaultFiles = vm.vaultStore.listVaultFiles()
                                    BasicText("${vaultFiles.size} ${L("ملفات مشفرة محلياً", "encrypted files")}", style = JoDonDesign.typography.caption)
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(96.dp)) }
        }

        if (newPlaylistDialog) {
            GlassBottomSheet(true, L("قائمة تشغيل جديدة", "New Playlist"), { newPlaylistDialog = false }) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    BasicTextField(
                        value = playlistName,
                        onValueChange = { playlistName = it },
                        textStyle = JoDonDesign.typography.body.copy(color = theme.text),
                        modifier = Modifier.fillMaxWidth().jodonGlass(JoDonDesign.shapes.small).padding(12.dp)
                    )
                    PrimaryButton(L("إنشاء", "Create"), {
                        vm.musicStore.createPlaylist(playlistName)
                        playlistName = ""
                        newPlaylistDialog = false
                    }, Modifier.fillMaxWidth())
                }
            }
        }
    }
}

private fun unlockBiometrics(context: Context, onSuccess: () -> Unit) {
    val activity = context as? FragmentActivity ?: run { onSuccess(); return }
    val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            onSuccess()
        }
    })
    prompt.authenticate(
        BiometricPrompt.PromptInfo.Builder()
            .setTitle("𝒥𝒪 DON Private Vault")
            .setNegativeButtonText("Cancel")
            .build()
    )
}
