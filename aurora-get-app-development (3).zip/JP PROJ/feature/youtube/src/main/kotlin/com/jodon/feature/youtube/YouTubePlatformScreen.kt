package com.jodon.feature.youtube

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import com.jodon.core.common.DownloadStatus
import com.jodon.core.common.DownloadTask
import com.jodon.core.common.FollowedChannel
import com.jodon.core.common.LocalYouTubeProfileBundle
import com.jodon.core.common.MediaKind
import com.jodon.core.common.UrlNormalizer
import com.jodon.core.common.YouTubeVideoItem
import com.jodon.core.common.formatDuration
import com.jodon.core.designsystem.GhostButton
import com.jodon.core.designsystem.GlassBottomSheet
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.IconBtn
import com.jodon.core.designsystem.JoDonDesign
import com.jodon.core.designsystem.JoDonGlyph
import com.jodon.core.designsystem.JoDonIcon
import com.jodon.core.designsystem.JoDonToggle
import com.jodon.core.designsystem.MeshBackground
import com.jodon.core.designsystem.PillChip
import com.jodon.core.designsystem.PrimaryButton
import com.jodon.core.designsystem.jodonPress
import com.jodon.core.storage.YouTubeLocalStore
import com.jodon.engine.downloader.DownloadQueue
import com.jodon.engine.extractors.YouTubeInnertubeClient
import com.jodon.engine.extractors.YtDlpExtractor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

enum class YouTubeSubTab { HOME, SHORTS, SUBSCRIPTIONS, ACCOUNT }

data class YouTubeUiState(
    val subTab: YouTubeSubTab = YouTubeSubTab.HOME,
    val selectedTopic: String = "for_you",
    val searchQuery: String = "",
    val suggestions: List<String> = emptyList(),
    val homeFeed: List<YouTubeVideoItem> = emptyList(),
    val shortsFeed: List<YouTubeVideoItem> = emptyList(),
    val subsFeed: List<YouTubeVideoItem> = emptyList(),
    val searchResults: List<YouTubeVideoItem> = emptyList(),
    val activeVideo: YouTubeVideoItem? = null,
    val activeStreamUrl: String? = null,
    val playAsAudioOnly: Boolean = false,
    val loading: Boolean = false,
    val errorBanner: String? = null
)

@HiltViewModel
class YouTubePlatformViewModel @Inject constructor(
    private val innertube: YouTubeInnertubeClient,
    private val ytdlp: YtDlpExtractor,
    val localStore: YouTubeLocalStore,
    private val downloadQueue: DownloadQueue
) : ViewModel() {
    private val _ui = MutableStateFlow(YouTubeUiState())
    val ui: StateFlow<YouTubeUiState> = _ui.asStateFlow()
    private var homeContinuation: String? = null
    private var searchContinuation: String? = null
    private var seedCursor = 0
    private var suggestJob: Job? = null

    init {
        loadMoreHome(reset = true)
    }

    fun selectSubTab(tab: YouTubeSubTab) {
        _ui.value = _ui.value.copy(subTab = tab)
        when (tab) {
            YouTubeSubTab.SHORTS -> if (_ui.value.shortsFeed.isEmpty()) loadMoreShorts()
            YouTubeSubTab.SUBSCRIPTIONS -> refreshSubscriptionsFeed()
            else -> Unit
        }
    }

    fun selectTopic(topic: String) {
        _ui.value = _ui.value.copy(selectedTopic = topic, homeFeed = emptyList())
        homeContinuation = null
        loadMoreHome(reset = true)
    }

    /** Infinite personalized home feed blending local affinity weights + followed channels. */
    fun loadMoreHome(reset: Boolean = false) {
        if (_ui.value.loading) return
        viewModelScope.launch {
            _ui.value = _ui.value.copy(loading = true, errorBanner = null)
            val seeds = localStore.personalizedSeedQueries()
            val topic = _ui.value.selectedTopic
            val query = when {
                topic != "for_you" -> topic
                seeds.isNotEmpty() -> seeds[seedCursor++ % seeds.size]
                else -> "4K documentary music science technology"
            }
            val page = innertube.search(
                query = query,
                continuation = if (reset) null else homeContinuation
            )
            homeContinuation = page.continuation
            val combined = if (reset) page.items else (_ui.value.homeFeed + page.items).distinctBy { it.videoId }
            _ui.value = _ui.value.copy(
                homeFeed = combined,
                loading = false,
                errorBanner = if (combined.isEmpty()) "Check internet connection to browse YouTube" else null
            )
        }
    }

    fun loadMoreShorts() {
        viewModelScope.launch {
            val seeds = localStore.personalizedSeedQueries()
            val baseQuery = seeds.firstOrNull() ?: "trending shorts"
            val page = innertube.search(query = baseQuery, shortsOnly = true)
            _ui.value = _ui.value.copy(shortsFeed = (_ui.value.shortsFeed + page.items).distinctBy { it.videoId })
        }
    }

    fun refreshSubscriptionsFeed() {
        viewModelScope.launch {
            val channels = localStore.bundle.value.followedChannels
            if (channels.isEmpty()) {
                _ui.value = _ui.value.copy(subsFeed = emptyList())
                return@launch
            }
            _ui.value = _ui.value.copy(loading = true)
            val gathered = mutableListOf<YouTubeVideoItem>()
            channels.take(8).forEach { ch ->
                gathered += innertube.fetchChannelVideos(ch.channelId.ifBlank { ch.name })
            }
            _ui.value = _ui.value.copy(subsFeed = gathered.distinctBy { it.videoId }, loading = false)
        }
    }

    fun onSearchInput(text: String) {
        _ui.value = _ui.value.copy(searchQuery = text)
        suggestJob?.cancel()
        if (text.isBlank()) {
            _ui.value = _ui.value.copy(suggestions = emptyList(), searchResults = emptyList())
            return
        }
        suggestJob = viewModelScope.launch {
            delay(180)
            _ui.value = _ui.value.copy(suggestions = innertube.suggest(text))
        }
    }

    fun executeSearch(query: String, append: Boolean = false) {
        val q = query.trim()
        if (q.isBlank()) return
        localStore.recordSearch(q)
        viewModelScope.launch {
            _ui.value = _ui.value.copy(searchQuery = q, suggestions = emptyList(), loading = true)
            val page = innertube.search(q, continuation = if (append) searchContinuation else null)
            searchContinuation = page.continuation
            _ui.value = _ui.value.copy(
                searchResults = if (append) (_ui.value.searchResults + page.items).distinctBy { it.videoId } else page.items,
                loading = false
            )
        }
    }

    fun openVideo(video: YouTubeVideoItem, audioOnly: Boolean = false) {
        localStore.recordWatch(video)
        _ui.value = _ui.value.copy(activeVideo = video, activeStreamUrl = null, playAsAudioOnly = audioOnly)
        viewModelScope.launch {
            val resolved = ytdlp.resolvePlayableStream(video.watchUrl, audioOnly = audioOnly)
            _ui.value = _ui.value.copy(activeStreamUrl = resolved?.first)
        }
    }

    fun closePlayer() {
        _ui.value = _ui.value.copy(activeVideo = null, activeStreamUrl = null)
    }

    fun downloadVideo(video: YouTubeVideoItem, audioOnly: Boolean) {
        viewModelScope.launch {
            val stream = ytdlp.resolvePlayableStream(video.watchUrl, audioOnly = audioOnly)
            val directUrl = stream?.first ?: return@launch
            val ext = if (audioOnly) "m4a" else "mp4"
            downloadQueue.enqueue(
                DownloadTask(
                    id = UUID.randomUUID().toString(),
                    url = directUrl,
                    fileName = UrlNormalizer.sanitizeFileName("${video.title}.$ext"),
                    kind = if (audioOnly) MediaKind.AUDIO else MediaKind.VIDEO,
                    status = DownloadStatus.QUEUED,
                    connections = 24,
                    headers = stream.second
                )
            )
        }
    }
}

@Composable
fun YouTubePlatformScreen(
    isArabic: Boolean,
    vm: YouTubePlatformViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    val ui by vm.ui.collectAsState()
    val profile by vm.localStore.bundle.collectAsState()
    val theme = JoDonDesign.theme
    var feedback by remember { mutableStateOf<String?>(null) }
    var downloadTarget by remember { mutableStateOf<YouTubeVideoItem?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(vm.localStore.exportJson().toByteArray(Charsets.UTF_8))
            }
            feedback = L("تم تصدير ملفك الشخصي المحلي بنجاح", "Local profile exported")
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
            val ok = vm.localStore.importJson(raw)
            feedback = if (ok) L("تم استيراد الحساب والاشتراكات والسجل", "Profile & subscriptions imported")
            else L("ملف غير صالح", "Invalid JSON file")
        }
    }

    fun copyUrl(url: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("YouTube Link", url))
        feedback = L("تم نسخ رابط الفيديو", "Video link copied")
    }

    Box(Modifier.fillMaxSize()) {
        MeshBackground()
        Column(Modifier.fillMaxSize()) {
            // Official-style YouTube Platform Header
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    JoDonIcon(JoDonGlyph.YOUTUBE, "YouTube", Modifier.size(28.dp))
                    Spacer(Modifier.width(8.dp))
                    BasicText("YouTube", style = JoDonDesign.typography.headline)
                    Spacer(Modifier.width(6.dp))
                    PillChip(L("محلي حر", "Local Native"), active = true)
                    Spacer(Modifier.weight(1f))
                    PillChip(
                        text = L("شورتس", "Shorts"),
                        active = ui.subTab == YouTubeSubTab.SHORTS,
                        onClick = { vm.selectSubTab(YouTubeSubTab.SHORTS) }
                    )
                    Spacer(Modifier.width(6.dp))
                    PillChip(
                        text = L("حسابي", "My Profile"),
                        active = ui.subTab == YouTubeSubTab.ACCOUNT,
                        onClick = { vm.selectSubTab(YouTubeSubTab.ACCOUNT) }
                    )
                }
                Spacer(Modifier.height(8.dp))
                // Search Bar with Live Autocomplete Suggestions
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(JoDonDesign.shapes.pill)
                        .background(theme.glassStrong)
                        .border(1.dp, theme.border, JoDonDesign.shapes.pill)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    JoDonIcon(JoDonGlyph.SEARCH, null, Modifier.size(16.dp), theme.muted)
                    Spacer(Modifier.width(8.dp))
                    BasicTextField(
                        value = ui.searchQuery,
                        onValueChange = vm::onSearchInput,
                        textStyle = JoDonDesign.typography.body.copy(color = theme.text),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            if (ui.searchQuery.isEmpty()) {
                                BasicText(L("ابحث في يوتيوب بدقة...", "Search YouTube..."), style = JoDonDesign.typography.caption.copy(color = theme.muted))
                            }
                            inner()
                        }
                    )
                    if (ui.searchQuery.isNotBlank()) {
                        PillChip(L("بحث", "Go"), active = true, onClick = { vm.executeSearch(ui.searchQuery) })
                    }
                }
                // Live Search Suggestions Dropdown
                if (ui.suggestions.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    GlassCard(Modifier.fillMaxWidth(), JoDonDesign.shapes.medium) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            ui.suggestions.take(6).forEach { suggestion ->
                                Row(
                                    Modifier.fillMaxWidth().jodonPress({ vm.executeSearch(suggestion) }).padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    JoDonIcon(JoDonGlyph.SEARCH, null, Modifier.size(14.dp), theme.accent1)
                                    Spacer(Modifier.width(8.dp))
                                    BasicText(suggestion, style = JoDonDesign.typography.body)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                // Sub-navigation pills
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillChip(L("الرئيسية", "Home"), ui.subTab == YouTubeSubTab.HOME, { vm.selectSubTab(YouTubeSubTab.HOME) })
                    PillChip(L("شورتس", "Shorts"), ui.subTab == YouTubeSubTab.SHORTS, { vm.selectSubTab(YouTubeSubTab.SHORTS) })
                    PillChip("${L("الاشتراكات", "Subscriptions")} (${profile.followedChannels.size})", ui.subTab == YouTubeSubTab.SUBSCRIPTIONS, { vm.selectSubTab(YouTubeSubTab.SUBSCRIPTIONS) })
                    PillChip(L("حسابي", "My Account"), ui.subTab == YouTubeSubTab.ACCOUNT, { vm.selectSubTab(YouTubeSubTab.ACCOUNT) })
                }
            }

            // Active Inline Native ExoPlayer Watch View (Video or Song Mode)
            ui.activeVideo?.let { active ->
                GlassCard(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)) {
                    Column {
                        if (!ui.playAsAudioOnly && ui.activeStreamUrl != null) {
                            InlineExoVideo(streamUrl = ui.activeStreamUrl!!, modifier = Modifier.fillMaxWidth().height(200.dp))
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(active.thumbnailUrl, active.title, Modifier.size(64.dp).clip(JoDonDesign.shapes.small), contentScale = ContentScale.Crop)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    BasicText(
                                        if (ui.activeStreamUrl == null) L("جارٍ استخراج البث المباشر...", "Extracting stream...")
                                        else L("وضع التشغيل كأغنية نشط", "Playing as Song"),
                                        style = JoDonDesign.typography.caption.copy(color = theme.accent1)
                                    )
                                    BasicText(active.title, style = JoDonDesign.typography.label)
                                }
                                if (ui.playAsAudioOnly && ui.activeStreamUrl != null) {
                                    InlineAudioOnlyExo(ui.activeStreamUrl!!)
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GhostButton(
                                text = if (ui.playAsAudioOnly) L("وضع الفيديو", "Video Mode") else L("تشغيل كأغنية", "Play as Song"),
                                glyph = JoDonGlyph.MUSIC,
                                onClick = { vm.openVideo(active, audioOnly = !ui.playAsAudioOnly) }
                            )
                            GhostButton(L("تحميل", "Download"), { downloadTarget = active }, glyph = JoDonGlyph.DOWNLOAD)
                            GhostButton(L("نسخ الرابط", "Copy Link"), { copyUrl(active.watchUrl) }, glyph = JoDonGlyph.COPY)
                            IconBtn(JoDonGlyph.CLOSE, "Close", vm::closePlayer)
                        }
                    }
                }
            }

            // Main Body by SubTab
            when {
                ui.searchResults.isNotEmpty() && ui.searchQuery.isNotBlank() -> {
                    VideoFeedList(
                        videos = ui.searchResults,
                        profile = profile,
                        isArabic = isArabic,
                        onPlay = { vm.openVideo(it, false) },
                        onPlayAudio = { vm.openVideo(it, true) },
                        onDownload = { downloadTarget = it },
                        onCopy = { copyUrl(it.watchUrl) },
                        onToggleFollow = { vm.localStore.toggleFollow(FollowedChannel(it.channelId, it.channelName, it.channelAvatar)) },
                        onToggleLike = { vm.localStore.toggleLike(it) },
                        onLoadMore = { vm.executeSearch(ui.searchQuery, append = true) }
                    )
                }
                ui.subTab == YouTubeSubTab.HOME -> {
                    val dynamicTopics = listOf(
                        "for_you" to L("مقترح لك", "For You"),
                        "music" to L("موسيقى", "Music"),
                        "technology" to L("تقنية", "Tech"),
                        "documentary" to L("وثائقيات", "Docs"),
                        "gaming" to L("ألعاب", "Gaming")
                    ) + profile.topicWeights.keys.take(5).map { it to "#$it" }
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(dynamicTopics) { (key, label) ->
                            PillChip(label, ui.selectedTopic == key, { vm.selectTopic(key) })
                        }
                    }
                    VideoFeedList(
                        videos = ui.homeFeed,
                        profile = profile,
                        isArabic = isArabic,
                        onPlay = { vm.openVideo(it, false) },
                        onPlayAudio = { vm.openVideo(it, true) },
                        onDownload = { downloadTarget = it },
                        onCopy = { copyUrl(it.watchUrl) },
                        onToggleFollow = { vm.localStore.toggleFollow(FollowedChannel(it.channelId, it.channelName, it.channelAvatar)) },
                        onToggleLike = { vm.localStore.toggleLike(it) },
                        onLoadMore = { vm.loadMoreHome(reset = false) }
                    )
                }
                ui.subTab == YouTubeSubTab.SHORTS -> {
                    ShortsVerticalFeed(
                        shorts = ui.shortsFeed,
                        profile = profile,
                        isArabic = isArabic,
                        onDownload = { downloadTarget = it },
                        onCopy = { copyUrl(it.watchUrl) },
                        onFollow = { vm.localStore.toggleFollow(FollowedChannel(it.channelId, it.channelName, it.channelAvatar)) },
                        onLike = { vm.localStore.toggleLike(it) },
                        onLoadMore = vm::loadMoreShorts
                    )
                }
                ui.subTab == YouTubeSubTab.SUBSCRIPTIONS -> {
                    if (profile.followedChannels.isEmpty()) {
                        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                            BasicText(
                                L("لم تتابع أي قناة بعد. اضغط «متابعة» تحت أي فيديو لبناء خلاصتك المحلية الخاصة بدون حساب رسمي!", "Follow any channel locally to see its latest uploads here — no official login required."),
                                style = JoDonDesign.typography.body.copy(color = theme.muted)
                            )
                        }
                    } else {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(profile.followedChannels, key = { it.channelId }) { ch ->
                                PillChip("${ch.name} ✕", active = true, onClick = { vm.localStore.toggleFollow(ch) })
                            }
                        }
                        VideoFeedList(
                            videos = ui.subsFeed,
                            profile = profile,
                            isArabic = isArabic,
                            onPlay = { vm.openVideo(it, false) },
                            onPlayAudio = { vm.openVideo(it, true) },
                            onDownload = { downloadTarget = it },
                            onCopy = { copyUrl(it.watchUrl) },
                            onToggleFollow = { vm.localStore.toggleFollow(FollowedChannel(it.channelId, it.channelName, it.channelAvatar)) },
                            onToggleLike = { vm.localStore.toggleLike(it) },
                            onLoadMore = {}
                        )
                    }
                }
                ui.subTab == YouTubeSubTab.ACCOUNT -> {
                    LocalAccountView(
                        profile = profile,
                        isArabic = isArabic,
                        onSaveProfile = vm.localStore::updateProfile,
                        onExport = { exportLauncher.launch("jodon_youtube_profile.json") },
                        onImport = { importLauncher.launch(arrayOf("application/json", "*/*")) },
                        onTogglePauseHistory = vm.localStore::togglePauseHistory,
                        onClearHistory = vm.localStore::clearHistory,
                        onUnfollow = vm.localStore::toggleFollow,
                        onPlayVideo = { vm.openVideo(it, false) },
                        onDownload = { downloadTarget = it },
                        onCopy = { copyUrl(it.watchUrl) }
                    )
                }
            }
        }

        feedback?.let { msg ->
            GlassCard(Modifier.align(Alignment.BottomCenter).padding(bottom = 92.dp)) {
                BasicText(msg, style = JoDonDesign.typography.label)
            }
        }

        downloadTarget?.let { target ->
            GlassBottomSheet(
                visible = true,
                title = L("تحميل من يوتيوب", "Download YouTube Media"),
                onDismiss = { downloadTarget = null }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    BasicText(target.title, style = JoDonDesign.typography.label)
                    PrimaryButton(
                        text = L("تحميل كفيديو بأعلى جودة (MP4)", "Download Best Video (MP4)"),
                        glyph = JoDonGlyph.VIDEO,
                        onClick = { vm.downloadVideo(target, audioOnly = false); downloadTarget = null },
                        modifier = Modifier.fillMaxWidth()
                    )
                    PrimaryButton(
                        text = L("تحميل كأغنية صوتية (M4A)", "Download as Audio Song (M4A)"),
                        glyph = JoDonGlyph.MUSIC,
                        onClick = { vm.downloadVideo(target, audioOnly = true); downloadTarget = null },
                        modifier = Modifier.fillMaxWidth()
                    )
                    GhostButton(
                        text = L("نسخ رابط الفيديو المباشر", "Copy Video Link"),
                        glyph = JoDonGlyph.COPY,
                        onClick = { copyUrl(target.watchUrl); downloadTarget = null },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun VideoFeedList(
    videos: List<YouTubeVideoItem>,
    profile: LocalYouTubeProfileBundle,
    isArabic: Boolean,
    onPlay: (YouTubeVideoItem) -> Unit,
    onPlayAudio: (YouTubeVideoItem) -> Unit,
    onDownload: (YouTubeVideoItem) -> Unit,
    onCopy: (YouTubeVideoItem) -> Unit,
    onToggleFollow: (YouTubeVideoItem) -> Unit,
    onToggleLike: (YouTubeVideoItem) -> Unit,
    onLoadMore: () -> Unit
) {
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    val theme = JoDonDesign.theme
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        itemsIndexed(videos, key = { _, v -> v.videoId }) { index, video ->
            if (index >= videos.size - 3) {
                LaunchedEffect(videos.size) { onLoadMore() }
            }
            val following = profile.followedChannels.any { it.channelId == video.channelId }
            val liked = profile.likedVideos.any { it.videoId == video.videoId }
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    Box(Modifier.fillMaxWidth().height(188.dp).clip(JoDonDesign.shapes.medium).jodonPress({ onPlay(video) })) {
                        AsyncImage(
                            model = video.thumbnailUrl,
                            contentDescription = video.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        if (video.durationSeconds > 0L) {
                            Box(
                                Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(8.dp)
                                    .clip(JoDonDesign.shapes.small)
                                    .background(Color(0xCC000000))
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                BasicText(formatDuration(video.durationSeconds), style = JoDonDesign.typography.numeric.copy(color = Color.White))
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    BasicText(video.title, style = JoDonDesign.typography.title)
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            BasicText(video.channelName, style = JoDonDesign.typography.label.copy(color = theme.accent1))
                            BasicText(
                                listOf(video.viewCountText, video.publishedText).filter { it.isNotBlank() }.joinToString(" · "),
                                style = JoDonDesign.typography.caption.copy(color = theme.muted)
                            )
                        }
                        PillChip(
                            text = if (following) L("متابَع ✓", "Following ✓") else L("+ متابعة", "+ Follow"),
                            active = following,
                            onClick = { onToggleFollow(video) }
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    // Action bar underneath EVERY video: Download, Copy Link, Play as Song, Like
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PrimaryButton(
                            text = L("تحميل", "Download"),
                            glyph = JoDonGlyph.DOWNLOAD,
                            onClick = { onDownload(video) },
                            modifier = Modifier.weight(1f)
                        )
                        GhostButton(
                            text = L("نسخ الرابط", "Copy"),
                            glyph = JoDonGlyph.COPY,
                            onClick = { onCopy(video) }
                        )
                        GhostButton(
                            text = L("كأغنية", "Song"),
                            glyph = JoDonGlyph.MUSIC,
                            onClick = { onPlayAudio(video) }
                        )
                        IconBtn(
                            glyph = JoDonGlyph.HEART,
                            desc = "Like",
                            onClick = { onToggleLike(video) }
                        )
                    }
                    if (liked) {
                        Spacer(Modifier.height(4.dp))
                        BasicText(L("في قائمة الإعجابات المحلية ♥", "Saved in Local Likes ♥"), style = JoDonDesign.typography.caption.copy(color = theme.accent3))
                    }
                }
            }
        }
        item { Spacer(Modifier.height(96.dp)) }
    }
}

@Composable
private fun ShortsVerticalFeed(
    shorts: List<YouTubeVideoItem>,
    profile: LocalYouTubeProfileBundle,
    isArabic: Boolean,
    onDownload: (YouTubeVideoItem) -> Unit,
    onCopy: (YouTubeVideoItem) -> Unit,
    onFollow: (YouTubeVideoItem) -> Unit,
    onLike: (YouTubeVideoItem) -> Unit,
    onLoadMore: () -> Unit
) {
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    if (shorts.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            PrimaryButton(L("تحميل مقاطع شورتس", "Load Shorts"), onLoadMore, glyph = JoDonGlyph.SHORTS)
        }
        return
    }
    val pagerState = rememberPagerState(pageCount = { shorts.size })
    LaunchedEffect(pagerState.currentPage) {
        if (pagerState.currentPage >= shorts.size - 2) onLoadMore()
    }
    VerticalPager(state = pagerState, modifier = Modifier.fillMaxSize().padding(bottom = 84.dp)) { page ->
        val item = shorts[page]
        val following = profile.followedChannels.any { it.channelId == item.channelId }
        Box(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 6.dp).clip(JoDonDesign.shapes.large)) {
            AsyncImage(
                model = item.thumbnailUrl,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD05070E)))))
            Column(Modifier.align(Alignment.BottomStart).padding(16.dp).fillMaxWidth(0.78f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BasicText(item.channelName, style = JoDonDesign.typography.title.copy(color = Color.White))
                    Spacer(Modifier.width(8.dp))
                    PillChip(if (following) L("متابَع", "Following") else L("متابعة", "Follow"), following, { onFollow(item) })
                }
                Spacer(Modifier.height(6.dp))
                BasicText(item.title, style = JoDonDesign.typography.body.copy(color = Color.White))
            }
            Column(
                Modifier.align(Alignment.BottomEnd).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                IconBtn(JoDonGlyph.HEART, "Like", { onLike(item) })
                IconBtn(JoDonGlyph.DOWNLOAD, "Download", { onDownload(item) })
                IconBtn(JoDonGlyph.COPY, "Copy Link", { onCopy(item) })
            }
        }
    }
}

@Composable
private fun LocalAccountView(
    profile: LocalYouTubeProfileBundle,
    isArabic: Boolean,
    onSaveProfile: (String, String, String, String) -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit,
    onTogglePauseHistory: () -> Unit,
    onClearHistory: () -> Unit,
    onUnfollow: (FollowedChannel) -> Unit,
    onPlayVideo: (YouTubeVideoItem) -> Unit,
    onDownload: (YouTubeVideoItem) -> Unit,
    onCopy: (YouTubeVideoItem) -> Unit
) {
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    val theme = JoDonDesign.theme
    var name by remember(profile.displayName) { mutableStateOf(profile.displayName) }
    var handle by remember(profile.handle) { mutableStateOf(profile.handle) }
    var bio by remember(profile.bio) { mutableStateOf(profile.bio) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        JoDonIcon(JoDonGlyph.USER, null, Modifier.size(32.dp), theme.accent1)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            BasicText(L("ملفك الشخصي المحلي المستقل", "Standalone Local Profile"), style = JoDonDesign.typography.title)
                            BasicText(L("لا يحتاج تسجيل دخول رسمي · محفوظ محلياً فقط", "No official Google login · 100% local"), style = JoDonDesign.typography.caption.copy(color = theme.muted))
                        }
                    }
                    BasicTextField(
                        value = name,
                        onValueChange = { name = it },
                        textStyle = JoDonDesign.typography.body.copy(color = theme.text),
                        modifier = Modifier.fillMaxWidth().clip(JoDonDesign.shapes.small).background(theme.glass).padding(10.dp)
                    )
                    BasicTextField(
                        value = handle,
                        onValueChange = { handle = it },
                        textStyle = JoDonDesign.typography.numeric.copy(color = theme.accent1),
                        modifier = Modifier.fillMaxWidth().clip(JoDonDesign.shapes.small).background(theme.glass).padding(10.dp)
                    )
                    BasicTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        textStyle = JoDonDesign.typography.caption.copy(color = theme.text),
                        modifier = Modifier.fillMaxWidth().clip(JoDonDesign.shapes.small).background(theme.glass).padding(10.dp),
                        decorationBox = { inner ->
                            if (bio.isEmpty()) BasicText(L("نبذة شخصية محلية...", "Local bio..."), style = JoDonDesign.typography.caption.copy(color = theme.muted))
                            inner()
                        }
                    )
                    PrimaryButton(L("حفظ التعديلات المحلية", "Save Local Profile"), { onSaveProfile(name, handle, bio, profile.avatarUri) }, Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GhostButton(L("تصدير الملف (JSON)", "Export Profile JSON"), onExport, Modifier.weight(1f), JoDonGlyph.SHARE)
                        GhostButton(L("استيراد ملف (JSON)", "Import Profile JSON"), onImport, Modifier.weight(1f), JoDonGlyph.FOLDER)
                    }
                }
            }
        }

        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BasicText(L("إيقاف سجل المشاهدة مؤقتاً", "Pause Watch History"), Modifier.weight(1f), style = JoDonDesign.typography.body)
                        JoDonToggle(profile.historyPaused, { onTogglePauseHistory() })
                    }
                    GhostButton(L("مسح سجل المشاهدة والبحث", "Clear Watch & Search History"), onClearHistory, Modifier.fillMaxWidth())
                }
            }
        }

        if (profile.followedChannels.isNotEmpty()) {
            item { BasicText("${L("القنوات المتابَعة", "Followed Channels")} (${profile.followedChannels.size})", style = JoDonDesign.typography.title) }
            items(profile.followedChannels, key = { it.channelId }) { ch ->
                GlassCard(Modifier.fillMaxWidth(), JoDonDesign.shapes.medium) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BasicText(ch.name, Modifier.weight(1f), style = JoDonDesign.typography.label)
                        GhostButton(L("إلغاء المتابعة", "Unfollow"), { onUnfollow(ch) })
                    }
                }
            }
        }

        if (profile.watchHistory.isNotEmpty()) {
            item { BasicText("${L("سجل المشاهدة المحلي", "Local Watch History")} (${profile.watchHistory.size})", style = JoDonDesign.typography.title) }
            items(profile.watchHistory.take(15), key = { "hist-${it.videoId}" }) { v ->
                GlassCard(Modifier.fillMaxWidth(), JoDonDesign.shapes.medium) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).jodonPress({ onPlayVideo(v) })) {
                            BasicText(v.title, style = JoDonDesign.typography.label)
                            BasicText(v.channelName, style = JoDonDesign.typography.caption.copy(color = theme.muted))
                        }
                        IconBtn(JoDonGlyph.DOWNLOAD, "Download", { onDownload(v) })
                        Spacer(Modifier.width(6.dp))
                        IconBtn(JoDonGlyph.COPY, "Copy", { onCopy(v.watchUrl) })
                    }
                }
            }
        }
        item { Spacer(Modifier.height(96.dp)) }
    }
}

@Composable
private fun InlineExoVideo(streamUrl: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val player = remember(streamUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(streamUrl))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        modifier = modifier.clip(JoDonDesign.shapes.medium),
        factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
        update = { it.player = player }
    )
}

@Composable
private fun InlineAudioOnlyExo(streamUrl: String) {
    val context = LocalContext.current
    val player = remember(streamUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(streamUrl))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
}
