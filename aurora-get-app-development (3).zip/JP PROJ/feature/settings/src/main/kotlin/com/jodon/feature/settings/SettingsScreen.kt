package com.jodon.feature.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import com.jodon.core.common.AppSettings
import com.jodon.core.designsystem.GhostButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.GradientTitle
import com.jodon.core.designsystem.JoDonDesign
import com.jodon.core.designsystem.JoDonGlyph
import com.jodon.core.designsystem.JoDonSlider
import com.jodon.core.designsystem.JoDonThemes
import com.jodon.core.designsystem.JoDonToggle
import com.jodon.core.designsystem.MeshBackground
import com.jodon.core.designsystem.ThemePhotoCard
import com.jodon.core.storage.SettingsStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.serialization.json.Json
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    val store: SettingsStore,
    private val json: Json
) : ViewModel() {
    fun exportJson(): String = store.exportJson(json)
    fun importJson(raw: String) {
        runCatching {
            val parsed = json.decodeFromString(AppSettings.serializer(), raw)
            store.updateAsync { parsed }
        }
    }
}

@Composable
fun SettingsScreen(
    isArabic: Boolean,
    vm: SettingsViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    val settings by vm.store.settings.collectAsState()
    val allThemes = JoDonThemes.all(settings.lightTheme, settings.animationScale)

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            context.contentResolver.openOutputStream(uri)?.use { it.write(vm.exportJson().toByteArray(Charsets.UTF_8)) }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val txt = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
            vm.importJson(txt)
        }
    }

    Box(Modifier.fillMaxSize()) {
        MeshBackground()
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                GradientTitle(L("الثيمات الحية والإعدادات الشاملة", "Live Theme Studio & Settings"))
                BasicText(
                    L("كل ثيم يتحكم بالكامل في الألوان، تدرجات الزجاج، الحواف، وسرعة وفيزياء الأنيميشن في جميع الشاشات:", "Each theme transforms colors, glass refraction, corner geometry, and animation physics app-wide:"),
                    style = JoDonDesign.typography.caption.copy(color = JoDonDesign.theme.muted)
                )
            }

            // Realistic Photograph Cards for Every Theme
            items(allThemes, key = { it.id }) { spec ->
                ThemePhotoCard(
                    spec = spec,
                    selected = settings.themeId == spec.id,
                    isArabic = isArabic,
                    onSelect = { vm.store.updateAsync { it.copy(themeId = spec.id) } }
                )
            }

            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SettingSwitchRow(L("الوضع النهاري المضيء", "Light Glass Mode"), settings.lightTheme) { v ->
                            vm.store.updateAsync { it.copy(lightTheme = v) }
                        }
                        SettingSwitchRow(L("واجهة عربية كاملة (RTL)", "Arabic RTL Interface"), settings.languageTag == "ar") { v ->
                            vm.store.updateAsync { it.copy(languageTag = if (v) "ar" else "en") }
                        }
                        BasicText("${L("سرعة الأنيميشن والنبض", "Animation & Glow Speed")}: ${String.format("%.1fx", settings.animationScale)}", style = JoDonDesign.typography.numeric)
                        JoDonSlider(
                            value = ((settings.animationScale - 0.5f) / 1.5f).coerceIn(0f, 1f),
                            onValueChange = { f -> vm.store.updateAsync { it.copy(animationScale = 0.5f + f * 1.5f) } },
                            modifier = Modifier.fillMaxWidth()
                        )
                        BasicText("${L("الاتصالات المتوازية للتحميل", "Parallel Download Connections")}: ${settings.maxConnections} / 32", style = JoDonDesign.typography.numeric)
                        JoDonSlider(
                            value = ((settings.maxConnections - 8) / 24f).coerceIn(0f, 1f),
                            onValueChange = { f -> vm.store.updateAsync { it.copy(maxConnections = (8 + f * 24).toInt().coerceIn(8, 32)) } },
                            modifier = Modifier.fillMaxWidth()
                        )
                        SettingSwitchRow(L("حجب الإعلانات والمتتبعات", "AdBlock & Anti-Tracker"), settings.adBlockEnabled) { v ->
                            vm.store.updateAsync { it.copy(adBlockEnabled = v) }
                        }
                        SettingSwitchRow(L("تحديث محرك yt-dlp تلقائياً", "Auto-update yt-dlp Engine"), settings.ytdlpAutoUpdate) { v ->
                            vm.store.updateAsync { it.copy(ytdlpAutoUpdate = v) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GhostButton(L("تصدير الإعدادات", "Export JSON"), { exportLauncher.launch("jodon_settings.json") }, Modifier.weight(1f), JoDonGlyph.SHARE)
                            GhostButton(L("استيراد الإعدادات", "Import JSON"), { importLauncher.launch(arrayOf("application/json", "*/*")) }, Modifier.weight(1f), JoDonGlyph.FOLDER)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(96.dp)) }
        }
    }
}

@Composable
private fun SettingSwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        BasicText(label, Modifier.weight(1f), style = JoDonDesign.typography.body)
        JoDonToggle(checked, onChange)
    }
}
