package com.jodon.engine.downloader

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SegmentPlannerTest {
    @Test fun `segments cover exact byte total without gaps or overlaps`() {
        val total = 104_857_600L
        val plans = SegmentPlanner.plan(total, 24, true)
        assertEquals(24, plans.size)
        assertEquals(0L, plans.first().start)
        assertEquals(total, plans.last().endExclusive)
        assertEquals(total, plans.sumOf { it.length })
        plans.zipWithNext().forEach { (a, b) -> assertEquals(a.endExclusive, b.start) }
    }

    @Test fun `work stealing halves unwritten tail cleanly`() {
        val slow = SegmentPlan(0, 0L, 10_000_000L)
        val res = SegmentPlanner.steal(mapOf(0 to (slow to 2_000_000L)), 8)!!
        assertEquals(6_000_000L, res.first.endExclusive)
        assertEquals(6_000_000L, res.second.start)
        assertEquals(10_000_000L, res.second.endExclusive)
        assertTrue(res.second.length > 0L)
    }
}
