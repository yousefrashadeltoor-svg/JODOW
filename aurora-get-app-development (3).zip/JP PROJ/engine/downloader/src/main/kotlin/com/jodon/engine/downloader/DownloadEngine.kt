package com.jodon.engine.downloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.jodon.core.common.DownloadStatus
import com.jodon.core.common.DownloadTask
import com.jodon.core.common.MediaKind
import com.jodon.core.common.SegmentState
import com.jodon.core.common.humanBytes
import com.jodon.core.storage.DownloadsFileStore
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.file.StandardOpenOption
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.ceil
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

data class SegmentPlan(val index: Int, val start: Long, val endExclusive: Long) {
    val length: Long get() = endExclusive - start
    fun remaining(written: Long): Long = (length - written).coerceAtLeast(0L)
}

object SegmentPlanner {
    const val MIN_CONNECTIONS = 8
    const val MAX_CONNECTIONS = 32

    fun normalizeConnections(requested: Int, supportsRanges: Boolean): Int =
        if (!supportsRanges) 1 else requested.coerceIn(MIN_CONNECTIONS, MAX_CONNECTIONS)

    fun plan(totalBytes: Long, requestedConnections: Int, supportsRanges: Boolean): List<SegmentPlan> {
        if (totalBytes <= 0L) return listOf(SegmentPlan(0, 0L, 0L))
        val count = normalizeConnections(requestedConnections, supportsRanges)
        if (count == 1) return listOf(SegmentPlan(0, 0L, totalBytes))
        val size = ceil(totalBytes.toDouble() / count).toLong().coerceAtLeast(1L)
        return (0 until count).mapNotNull { i ->
            val start = i * size
            if (start >= totalBytes) null else SegmentPlan(i, start, minOf(start + size, totalBytes))
        }
    }

    fun steal(active: Map<Int, Pair<SegmentPlan, Long>>, nextIndex: Int): Pair<SegmentPlan, SegmentPlan>? {
        val slowest = active.values
            .filter { (plan, written) -> plan.remaining(written) > 512 * 1024L }
            .maxByOrNull { (plan, written) -> plan.remaining(written) }
            ?: return null
        val (plan, written) = slowest
        val resumeAt = plan.start + written
        val mid = resumeAt + (plan.endExclusive - resumeAt) / 2
        if (mid <= resumeAt || mid >= plan.endExclusive) return null
        return plan.copy(endExclusive = mid) to SegmentPlan(nextIndex, mid, plan.endExclusive)
    }
}

class SpeedLimiter(private val bytesPerSecond: Long) {
    private var lastNs = System.nanoTime()
    private var tokens = bytesPerSecond.toDouble()

    suspend fun acquire(bytes: Int) {
        if (bytesPerSecond <= 0L) return
        while (true) {
            synchronized(this) {
                val now = System.nanoTime()
                val elapsed = (now - lastNs) / 1_000_000_000.0
                lastNs = now
                tokens = min(bytesPerSecond.toDouble(), tokens + elapsed * bytesPerSecond)
                if (tokens >= bytes) {
                    tokens -= bytes
                    return
                }
            }
            delay(8)
        }
    }
}

sealed interface DownloadOutcome {
    data class Completed(val file: File) : DownloadOutcome
    data object Paused : DownloadOutcome
    data class Failed(val reason: String) : DownloadOutcome
}

data class DownloadProgress(
    val loadedBytes: Long,
    val totalBytes: Long,
    val speedBps: Long,
    val etaSeconds: Long?,
    val activeConnections: Int
)

@Singleton
class SegmentedDownloader @Inject constructor(
    private val client: OkHttpClient,
    private val store: DownloadsFileStore
) {
    private val paused = Collections.synchronizedSet(mutableSetOf<String>())
    private val cancelled = Collections.synchronizedSet(mutableSetOf<String>())

    fun pause(id: String) { paused.add(id) }
    fun resume(id: String) { paused.remove(id) }
    fun cancel(id: String) { cancelled.add(id) }

    suspend fun probeServer(task: DownloadTask): Pair<Long, Boolean> = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(task.url).get().header("Range", "bytes=0-0").apply {
            task.headers.forEach { (k, v) -> header(k, v) }
        }.build()
        runCatching {
            client.newCall(req).execute().use { res ->
                val rangeTotal = res.header("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
                val len = rangeTotal ?: res.header("Content-Length")?.toLongOrNull() ?: task.totalBytes
                val supports = res.code == 206 || res.header("Accept-Ranges")?.contains("bytes", true) == true
                len to supports
            }
        }.getOrDefault(task.totalBytes to false)
    }

    suspend fun download(
        task: DownloadTask,
        target: File,
        speedLimitKbps: Int = 0,
        onProgress: suspend (DownloadProgress) -> Unit
    ): DownloadOutcome = withContext(Dispatchers.IO) {
        val (probedTotal, supportsRanges) = probeServer(task)
        val total = if (probedTotal > 0L) probedTotal else task.totalBytes
        target.parentFile?.mkdirs()

        // Fallback single-stream download when total content length is unknown
        if (total <= 0L || !supportsRanges) {
            return@withContext singleStreamDownload(task, target, total, speedLimitKbps, onProgress)
        }

        RandomAccessFile(target, "rwd").use { it.setLength(total) }
        val persisted = store.loadSegments(task.id)
        val plans = if (persisted.isNotEmpty()) {
            persisted.map { SegmentPlan(it.index, it.start + it.written, it.end) }.filter { it.length > 0L }
        } else {
            SegmentPlanner.plan(total, task.connections, true)
        }
        if (plans.isEmpty()) return@withContext DownloadOutcome.Completed(target)

        val bounds = ConcurrentHashMap<Int, Long>().apply { plans.forEach { put(it.index, it.endExclusive) } }
        val active = Collections.synchronizedMap(mutableMapOf<Int, Pair<SegmentPlan, Long>>())
        val baseLoaded = persisted.sumOf { it.written }
        val loaded = AtomicLong(baseLoaded)
        val limiter = SpeedLimiter(speedLimitKbps * 1024L)
        val startedMs = System.currentTimeMillis()
        val channel = Channel<SegmentPlan>(Channel.UNLIMITED)
        plans.forEach(channel::trySend)
        val nextIndex = AtomicInteger((plans.maxOfOrNull { it.index } ?: -1) + 1)
        val workersCount = SegmentPlanner.normalizeConnections(task.connections, true)

        val runRes = runCatching {
            coroutineScope {
                val workers = (0 until workersCount).map {
                    launch(Dispatchers.IO) {
                        for (work in channel) {
                            if (!isActive || cancelled.contains(task.id)) break
                            while (paused.contains(task.id) && isActive) delay(120)
                            active[work.index] = work to 0L
                            val written = executeRange(task, target, work, limiter, { bounds[work.index] ?: work.endExclusive }) { delta ->
                                val cur = (active[work.index]?.second ?: 0L) + delta
                                active[work.index] = work to cur
                                val totalNow = loaded.addAndGet(delta.toLong())
                                val elapsedSec = ((System.currentTimeMillis() - startedMs) / 1000.0).coerceAtLeast(0.2)
                                val speed = ((totalNow - baseLoaded) / elapsedSec).toLong().coerceAtLeast(0L)
                                val eta = if (speed > 0L) (total - totalNow) / speed else null
                                onProgress(DownloadProgress(totalNow, total, speed, eta, active.size))
                            }
                            active.remove(work.index)
                            store.saveSegment(SegmentState(task.id, work.index, work.start, bounds[work.index] ?: work.endExclusive, written, task.etag, task.lastModified))
                            val snapshot = synchronized(active) { active.toMap() }
                            SegmentPlanner.steal(snapshot, nextIndex.get())?.let { (bounded, stolen) ->
                                nextIndex.incrementAndGet()
                                bounds[bounded.index] = bounded.endExclusive
                                bounds[stolen.index] = stolen.endExclusive
                                channel.trySend(stolen)
                            }
                        }
                    }
                }
                launch {
                    while (isActive) {
                        delay(180)
                        if (loaded.get() >= total || paused.contains(task.id) || cancelled.contains(task.id) || (active.isEmpty() && channel.isEmpty)) {
                            channel.close()
                            break
                        }
                    }
                }
                workers.forEach { it.join() }
            }
        }
        if (cancelled.remove(task.id)) return@withContext DownloadOutcome.Failed("Cancelled")
        if (paused.contains(task.id)) return@withContext DownloadOutcome.Paused
        if (runRes.isFailure) return@withContext DownloadOutcome.Failed(runRes.exceptionOrNull()?.message ?: "Network error")
        if (loaded.get() < total) return@withContext DownloadOutcome.Paused
        store.clearSegments(task.id)
        DownloadOutcome.Completed(target)
    }

    private suspend fun singleStreamDownload(
        task: DownloadTask,
        target: File,
        total: Long,
        speedLimitKbps: Int,
        onProgress: suspend (DownloadProgress) -> Unit
    ): DownloadOutcome = withContext(Dispatchers.IO) {
        val limiter = SpeedLimiter(speedLimitKbps * 1024L)
        val req = Request.Builder().url(task.url).get().apply {
            task.headers.forEach { (k, v) -> header(k, v) }
        }.build()
        val res = runCatching { client.newCall(req).execute() }.getOrNull()
            ?: return@withContext DownloadOutcome.Failed("Connection failed")
        res.use { response ->
            if (!response.isSuccessful) return@withContext DownloadOutcome.Failed("HTTP ${response.code}")
            val body = response.body ?: return@withContext DownloadOutcome.Failed("Empty response body")
            val started = System.currentTimeMillis()
            var written = 0L
            val buf = ByteArray(256 * 1024)
            target.outputStream().use { out ->
                body.byteStream().use { input ->
                    while (true) {
                        if (cancelled.remove(task.id)) return@withContext DownloadOutcome.Failed("Cancelled")
                        if (paused.contains(task.id)) return@withContext DownloadOutcome.Paused
                        val read = input.read(buf)
                        if (read < 0) break
                        limiter.acquire(read)
                        out.write(buf, 0, read)
                        written += read
                        val sec = ((System.currentTimeMillis() - started) / 1000.0).coerceAtLeast(0.2)
                        val spd = (written / sec).toLong()
                        onProgress(DownloadProgress(written, if (total > 0) total else written, spd, null, 1))
                    }
                }
            }
        }
        DownloadOutcome.Completed(target)
    }

    private suspend fun executeRange(
        task: DownloadTask,
        target: File,
        plan: SegmentPlan,
        limiter: SpeedLimiter,
        endBound: () -> Long,
        onBytes: suspend (Int) -> Unit
    ): Long = withContext(Dispatchers.IO) {
        var written = 0L
        repeat(4) { attempt ->
            val startAt = plan.start + written
            val limit = endBound()
            if (startAt >= limit) return@withContext written
            val req = Request.Builder()
                .url(task.url)
                .get()
                .header("Range", "bytes=$startAt-${limit - 1}")
                .apply {
                    task.headers.forEach { (k, v) -> header(k, v) }
                    (task.etag ?: task.lastModified)?.let { header("If-Range", it) }
                }
                .build()
            val res = runCatching { client.newCall(req).execute() }.getOrNull()
            if (res == null) {
                delay(250L * 2.0.pow(attempt).toLong() + Random.nextLong(50, 200))
                return@repeat
            }
            res.use { response ->
                if (!response.isSuccessful) {
                    delay(250L * 2.0.pow(attempt).toLong())
                    return@repeat
                }
                val stream = response.body?.byteStream() ?: return@repeat
                val buf = ByteArray(512 * 1024)
                FileChannel.open(target.toPath(), StandardOpenOption.WRITE).use { fc ->
                    while (true) {
                        if (cancelled.contains(task.id) || paused.contains(task.id)) return@withContext written
                        val dynamicLimit = endBound()
                        val maxRead = (dynamicLimit - (plan.start + written)).coerceAtMost(buf.size.toLong()).toInt()
                        if (maxRead <= 0) break
                        val read = stream.read(buf, 0, maxRead)
                        if (read < 0) break
                        limiter.acquire(read)
                        val bb = ByteBuffer.wrap(buf, 0, read)
                        var pos = plan.start + written
                        while (bb.hasRemaining()) pos += fc.write(bb, pos)
                        written += read
                        onBytes(read)
                    }
                }
                return@withContext written
            }
        }
        written
    }
}

@Singleton
class DownloadQueue @Inject constructor(
    @ApplicationContext private val context: Context,
    private val store: DownloadsFileStore,
    private val downloader: SegmentedDownloader
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _tasks = MutableStateFlow(store.loadTasksBlocking())
    val tasks: StateFlow<List<DownloadTask>> = _tasks.asStateFlow()
    private val jobs = ConcurrentHashMap<String, Job>()
    private val semaphore = Semaphore(4)
    val outputDir: File = File(context.getExternalFilesDir(null) ?: context.filesDir, "JoDon").apply { mkdirs() }

    private fun persist() {
        val snapshot = _tasks.value
        scope.launch { store.saveTasks(snapshot) }
    }

    fun enqueue(task: DownloadTask) {
        val targetFile = File(outputDir, task.fileName)
        val enriched = task.copy(targetPath = targetFile.absolutePath)
        _tasks.value = listOf(enriched) + _tasks.value.filterNot { it.id == task.id }
        persist()
        DownloadService.start(context)
        start(enriched.id)
    }

    fun start(taskId: String) {
        if (jobs[taskId]?.isActive == true) return
        val task = _tasks.value.firstOrNull { it.id == taskId } ?: return
        downloader.resume(taskId)
        jobs[taskId] = scope.launch {
            semaphore.withPermit {
                val target = if (task.targetPath.isNotBlank()) File(task.targetPath) else File(outputDir, task.fileName)
                val outcome = downloader.download(task, target) { prog ->
                    _tasks.value = _tasks.value.map { item ->
                        if (item.id != taskId) item else item.copy(
                            loadedBytes = prog.loadedBytes,
                            totalBytes = if (prog.totalBytes > 0) prog.totalBytes else item.totalBytes,
                            speedBps = prog.speedBps,
                            etaSeconds = prog.etaSeconds,
                            connections = prog.activeConnections,
                            speedHistory = (item.speedHistory + prog.speedBps).takeLast(28),
                            status = DownloadStatus.ACTIVE
                        )
                    }
                }
                when (outcome) {
                    is DownloadOutcome.Completed -> {
                        exportToPublicMediaStore(outcome.file, task.kind)
                        updateStatus(taskId, DownloadStatus.COMPLETED, loadedOverride = outcome.file.length())
                    }
                    is DownloadOutcome.Paused -> updateStatus(taskId, DownloadStatus.PAUSED)
                    is DownloadOutcome.Failed -> updateStatus(taskId, DownloadStatus.FAILED, outcome.reason)
                }
            }
        }
    }

    private fun exportToPublicMediaStore(file: File, kind: MediaKind) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || !file.exists()) return
        runCatching {
            val resolver = context.contentResolver
            val (collection, relPath, mime) = when (kind) {
                MediaKind.VIDEO -> Triple(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "${Environment.DIRECTORY_MOVIES}/JoDon", "video/mp4")
                MediaKind.AUDIO -> Triple(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "${Environment.DIRECTORY_MUSIC}/JoDon", "audio/mpeg")
                MediaKind.IMAGE -> Triple(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "${Environment.DIRECTORY_PICTURES}/JoDon", "image/jpeg")
                else -> Triple(MediaStore.Downloads.EXTERNAL_CONTENT_URI, "${Environment.DIRECTORY_DOWNLOADS}/JoDon", "application/octet-stream")
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
            }
            val uri = resolver.insert(collection, values) ?: return
            resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out, 512 * 1024) } }
        }
    }

    fun pause(id: String) { downloader.pause(id); updateStatus(id, DownloadStatus.PAUSED) }
    fun resume(id: String) { downloader.resume(id); start(id) }
    fun cancel(id: String) { downloader.cancel(id); jobs.remove(id)?.cancel(); updateStatus(id, DownloadStatus.CANCELLED) }
    fun retry(id: String) { downloader.resume(id); updateStatus(id, DownloadStatus.QUEUED); start(id) }
    fun delete(id: String) {
        cancel(id)
        _tasks.value.firstOrNull { it.id == id }?.targetPath?.takeIf { it.isNotBlank() }?.let { File(it).delete() }
        _tasks.value = _tasks.value.filterNot { it.id == id }
        persist()
    }

    fun reorder(from: Int, to: Int) {
        val list = _tasks.value.toMutableList()
        if (from !in list.indices || to !in list.indices) return
        val moved = list.removeAt(from)
        list.add(to, moved)
        _tasks.value = list.mapIndexed { idx, t -> t.copy(priority = list.size - idx) }
        persist()
    }

    fun restorePending() {
        _tasks.value.filter { it.status == DownloadStatus.ACTIVE || it.status == DownloadStatus.QUEUED }.forEach { start(it.id) }
    }

    private fun updateStatus(id: String, status: DownloadStatus, err: String? = null, loadedOverride: Long? = null) {
        _tasks.value = _tasks.value.map {
            if (it.id != id) it else it.copy(
                status = status,
                error = err,
                loadedBytes = loadedOverride ?: it.loadedBytes,
                speedBps = if (status == DownloadStatus.ACTIVE) it.speedBps else 0L
            )
        }
        persist()
    }
}

@AndroidEntryPoint
class DownloadService : Service() {
    @Inject lateinit var queue: DownloadQueue
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    companion object {
        const val CHANNEL_ID = "jodon_downloads"
        const val ACTION_PAUSE = "com.jodon.PAUSE"
        const val ACTION_RESUME = "com.jodon.RESUME"
        const val ACTION_CANCEL = "com.jodon.CANCEL"
        const val EXTRA_ID = "task_id"

        fun start(context: Context) {
            val intent = Intent(context, DownloadService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        ServiceCompat.startForeground(
            this,
            1001,
            buildNotification(null),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        )
        scope.launch {
            queue.tasks.collectLatest { list ->
                val active = list.firstOrNull { it.status == DownloadStatus.ACTIVE }
                getSystemService(NotificationManager::class.java).notify(1001, buildNotification(active))
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra(EXTRA_ID)
        when (intent?.action) {
            ACTION_PAUSE -> id?.let(queue::pause)
            ACTION_RESUME -> id?.let(queue::resume)
            ACTION_CANCEL -> id?.let(queue::cancel)
            else -> queue.restorePending()
        }
        return START_STICKY
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "𝒥𝒪 DON Downloads", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(task: DownloadTask?): Notification {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(task?.fileName ?: "𝒥𝒪 DON")
            .setContentText(
                if (task != null) "${humanBytes(task.loadedBytes)} / ${task.displaySize()} · ${humanBytes(task.speedBps)}/s"
                else "Download Engine Ready"
            )
            .setOnlyAlertOnce(true)
            .setOngoing(task != null)
        if (task != null) {
            builder.setProgress(100, (task.progress * 100).toInt(), task.totalBytes <= 0L)
            val pausePi = PendingIntent.getService(
                this, 1,
                Intent(this, DownloadService::class.java).setAction(ACTION_PAUSE).putExtra(EXTRA_ID, task.id),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val cancelPi = PendingIntent.getService(
                this, 2,
                Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL).putExtra(EXTRA_ID, task.id),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_media_pause, "Pause", pausePi)
            builder.addAction(android.R.drawable.ic_delete, "Cancel", cancelPi)
        }
        return builder.build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
