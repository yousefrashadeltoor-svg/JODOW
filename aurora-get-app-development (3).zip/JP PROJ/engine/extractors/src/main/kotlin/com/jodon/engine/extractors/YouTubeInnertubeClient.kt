package com.jodon.engine.extractors

import com.jodon.core.common.YouTubeVideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

data class YouTubePage(
    val items: List<YouTubeVideoItem>,
    val continuation: String? = null
)

/**
 * Native YouTube client powered directly by public YouTube Innertube JSON endpoints
 * and Google's YouTube Autocomplete endpoint — NOT a WebView, NO official account required.
 */
@Singleton
class YouTubeInnertubeClient @Inject constructor(
    private val client: OkHttpClient,
    private val json: Json
) {
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    /** Real live search suggestions as the user types. */
    suspend fun suggest(query: String, hl: String = "ar"): List<String> = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isBlank()) return@withContext emptyList()
        val encoded = URLEncoder.encode(q, "UTF-8")
        val url = "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&hl=$hl&q=$encoded"
        runCatching {
            client.newCall(Request.Builder().url(url).get().build()).execute().use { res ->
                if (!res.isSuccessful) return@use emptyList()
                val arr = json.parseToJsonElement(res.body?.string().orEmpty()).jsonArray
                arr.getOrNull(1)?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull }.orEmpty()
            }
        }.getOrDefault(emptyList())
    }

    /** Real YouTube search with continuation token support for infinite scrolling. */
    suspend fun search(
        query: String,
        continuation: String? = null,
        shortsOnly: Boolean = false,
        hl: String = "ar"
    ): YouTubePage = withContext(Dispatchers.IO) {
        val payload = buildJsonObject {
            putJsonObject("context") {
                putJsonObject("client") {
                    put("clientName", "WEB")
                    put("clientVersion", "2.20250115.01.00")
                    put("hl", hl)
                    put("gl", "US")
                }
            }
            if (continuation != null) {
                put("continuation", continuation)
            } else {
                put("query", if (shortsOnly && !query.contains("#shorts", true)) "$query #shorts" else query)
            }
        }
        val req = Request.Builder()
            .url("https://www.youtube.com/youtubei/v1/search?prettyPrint=false")
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/131.0.0.0 Mobile Safari/537.36")
            .post(payload.toString().toRequestBody(jsonMedia))
            .build()
        runCatching {
            client.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return@use YouTubePage(emptyList(), null)
                val root = json.parseToJsonElement(res.body?.string().orEmpty()).jsonObject
                val videos = mutableListOf<YouTubeVideoItem>()
                var nextToken: String? = null
                collectVideoRenderers(root, videos) { token -> if (nextToken == null) nextToken = token }
                val filtered = if (shortsOnly) videos.filter { it.isShort || it.durationSeconds in 1..75 } else videos
                YouTubePage(filtered.distinctBy { it.videoId }, nextToken)
            }
        }.getOrDefault(YouTubePage(emptyList(), null))
    }

    /** Fetches uploads from a locally followed channel via Innertube browseId. */
    suspend fun fetchChannelVideos(channelId: String, hl: String = "ar"): List<YouTubeVideoItem> = withContext(Dispatchers.IO) {
        if (!channelId.startsWith("UC")) return@withContext search(channelId, hl = hl).items
        val payload = buildJsonObject {
            putJsonObject("context") {
                putJsonObject("client") {
                    put("clientName", "WEB")
                    put("clientVersion", "2.20250115.01.00")
                    put("hl", hl)
                }
            }
            put("browseId", channelId)
        }
        val req = Request.Builder()
            .url("https://www.youtube.com/youtubei/v1/browse?prettyPrint=false")
            .post(payload.toString().toRequestBody(jsonMedia))
            .build()
        runCatching {
            client.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return@use emptyList()
                val root = json.parseToJsonElement(res.body?.string().orEmpty()).jsonObject
                val videos = mutableListOf<YouTubeVideoItem>()
                collectVideoRenderers(root, videos) {}
                videos.distinctBy { it.videoId }
            }
        }.getOrDefault(emptyList())
    }

    private fun collectVideoRenderers(
        element: JsonElement,
        sink: MutableList<YouTubeVideoItem>,
        onContinuation: (String) -> Unit
    ) {
        when (element) {
            is JsonObject -> {
                element["videoRenderer"]?.jsonObject?.let { vr ->
                    parseVideoRenderer(vr)?.let(sink::add)
                }
                element["reelItemRenderer"]?.jsonObject?.let { rr ->
                    parseReelRenderer(rr)?.let(sink::add)
                }
                element["shortsLockupViewModel"]?.jsonObject?.let { sl ->
                    parseShortsLockup(sl)?.let(sink::add)
                }
                element["continuationCommand"]?.jsonObject?.get("token")?.jsonPrimitive?.contentOrNull?.let(onContinuation)
                element.values.forEach { collectVideoRenderers(it, sink, onContinuation) }
            }
            is JsonArray -> element.forEach { collectVideoRenderers(it, sink, onContinuation) }
            else -> Unit
        }
    }

    private fun parseVideoRenderer(vr: JsonObject): YouTubeVideoItem? {
        val id = vr["videoId"]?.jsonPrimitive?.contentOrNull ?: return null
        val title = textOf(vr["title"]).ifBlank { return null }
        val channelName = textOf(vr["ownerText"]).ifBlank { textOf(vr["longBylineText"]) }
        val channelId = vr["ownerText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()
            ?.jsonObject?.get("navigationEndpoint")?.jsonObject?.get("browseEndpoint")
            ?.jsonObject?.get("browseId")?.jsonPrimitive?.contentOrNull.orEmpty()
        val channelAvatar = vr["channelThumbnailSupportedRenderers"]?.jsonObject
            ?.get("channelThumbnailWithLinkRenderer")?.jsonObject
            ?.get("thumbnail")?.jsonObject?.get("thumbnails")?.jsonArray?.lastOrNull()
            ?.jsonObject?.get("url")?.jsonPrimitive?.contentOrNull.orEmpty()
        val thumb = vr["thumbnail"]?.jsonObject?.get("thumbnails")?.jsonArray?.lastOrNull()
            ?.jsonObject?.get("url")?.jsonPrimitive?.contentOrNull
            ?: "https://i.ytimg.com/vi/$id/hqdefault.jpg"
        val lengthStr = textOf(vr["lengthText"])
        val durSec = parseDurationText(lengthStr)
        val views = textOf(vr["shortViewCountText"]).ifBlank { textOf(vr["viewCountText"]) }
        val published = textOf(vr["publishedTimeText"])
        val isShort = durSec in 1..60 && vr.toString().contains("/shorts/")
        return YouTubeVideoItem(
            videoId = id,
            title = title,
            channelId = channelId.ifBlank { channelName },
            channelName = channelName,
            channelAvatar = channelAvatar,
            thumbnailUrl = thumb,
            durationSeconds = durSec,
            viewCountText = views,
            publishedText = published,
            isShort = isShort
        )
    }

    private fun parseReelRenderer(rr: JsonObject): YouTubeVideoItem? {
        val id = rr["videoId"]?.jsonPrimitive?.contentOrNull ?: return null
        val title = textOf(rr["headline"]).ifBlank { "Shorts" }
        val views = textOf(rr["viewCountText"])
        val thumb = rr["thumbnail"]?.jsonObject?.get("thumbnails")?.jsonArray?.lastOrNull()
            ?.jsonObject?.get("url")?.jsonPrimitive?.contentOrNull
            ?: "https://i.ytimg.com/vi/$id/oar2.jpg"
        return YouTubeVideoItem(
            videoId = id, title = title, channelId = "shorts", channelName = "YouTube Shorts",
            thumbnailUrl = thumb, durationSeconds = 45L, viewCountText = views, isShort = true
        )
    }

    private fun parseShortsLockup(sl: JsonObject): YouTubeVideoItem? {
        val endpointStr = sl["onTap"]?.toString().orEmpty()
        val id = Regex("\"videoId\"\\s*:\\s*\"([a-zA-Z0-9_-]{11})\"").find(endpointStr)?.groupValues?.get(1) ?: return null
        val title = sl["overlayMetadata"]?.jsonObject?.get("primaryText")?.jsonObject?.get("content")?.jsonPrimitive?.contentOrNull ?: "Shorts"
        val views = sl["overlayMetadata"]?.jsonObject?.get("secondaryText")?.jsonObject?.get("content")?.jsonPrimitive?.contentOrNull.orEmpty()
        return YouTubeVideoItem(
            videoId = id, title = title, channelId = "shorts", channelName = "Shorts",
            thumbnailUrl = "https://i.ytimg.com/vi/$id/hqdefault.jpg",
            durationSeconds = 45L, viewCountText = views, isShort = true
        )
    }

    private fun textOf(el: JsonElement?): String {
        val obj = el as? JsonObject ?: return ""
        obj["simpleText"]?.jsonPrimitive?.contentOrNull?.let { return it }
        val runs = obj["runs"] as? JsonArray ?: return ""
        return runs.joinToString("") { (it as? JsonObject)?.get("text")?.jsonPrimitive?.contentOrNull.orEmpty() }
    }

    private fun parseDurationText(raw: String): Long {
        if (raw.isBlank()) return 0L
        val parts = raw.trim().split(":").mapNotNull { it.toLongOrNull() }
        return when (parts.size) {
            3 -> parts[0] * 3600 + parts[1] * 60 + parts[2]
            2 -> parts[0] * 60 + parts[1]
            1 -> parts[0]
            else -> 0L
        }
    }
}
