package com.jodon.engine.extractors

import android.content.Context
import com.jodon.core.common.AnalysisResult
import com.jodon.core.common.MediaFormat
import com.jodon.core.common.MediaKind
import com.jodon.core.common.SizeInfo
import com.jodon.core.common.SizeSource
import com.jodon.core.common.UrlNormalizer
import com.jodon.core.network.SizeResolver
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class YtDlpExtractor @Inject constructor(
    @ApplicationContext private val context: Context,
    private val json: Json
) {
    @Volatile private var initialized = false

    suspend fun ensureInitialized(autoUpdate: Boolean): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            if (!initialized) {
                YoutubeDL.getInstance().init(context)
                FFmpeg.getInstance().init(context)
                Aria2c.getInstance().init(context)
                initialized = true
            }
            if (autoUpdate) {
                runCatching { YoutubeDL.getInstance().updateYoutubeDL(context, YoutubeDL.UpdateChannel.STABLE) }
            }
            true
        }.getOrDefault(false)
    }

    suspend fun extract(url: String): AnalysisResult? = withContext(Dispatchers.IO) {
        ensureInitialized(false)
        val response = runCatching {
            val req = YoutubeDLRequest(url).apply {
                addOption("--dump-single-json")
                addOption("--no-warnings")
                addOption("--no-playlist")
                addOption("--skip-download")
            }
            YoutubeDL.getInstance().execute(req)
        }.getOrNull() ?: return@withContext null
        if (response.exitCode != 0 || response.out.isBlank()) return@withContext null
        val root = runCatching { json.parseToJsonElement(response.out).jsonObject }.getOrNull() ?: return@withContext null
        parseYtDlpJson(url, root)
    }

    suspend fun resolvePlayableStream(videoUrl: String, audioOnly: Boolean = false): Pair<String, Map<String, String>>? =
        withContext(Dispatchers.IO) {
            ensureInitialized(false)
            runCatching {
                val req = YoutubeDLRequest(videoUrl).apply {
                    addOption("-f", if (audioOnly) "bestaudio[ext=m4a]/bestaudio/best" else "best[ext=mp4]/best")
                    addOption("--no-playlist")
                }
                val info = YoutubeDL.getInstance().getInfo(req)
                val direct = info.url ?: return@runCatching null
                direct to emptyMap<String, String>()
            }.getOrNull()
        }

    private fun parseYtDlpJson(url: String, root: JsonObject): AnalysisResult {
        val formatsArr = root["formats"]?.jsonArray ?: JsonArray(emptyList())
        val rawFormats = formatsArr.mapNotNull { el ->
            val obj = el as? JsonObject ?: return@mapNotNull null
            val directUrl = obj.str("url") ?: return@mapNotNull null
            val vcodec = obj.str("vcodec").orEmpty()
            val acodec = obj.str("acodec").orEmpty()
            val hasVideo = vcodec.isNotBlank() && vcodec != "none"
            val hasAudio = acodec.isNotBlank() && acodec != "none"
            val exactBytes = obj["filesize"]?.jsonPrimitive?.longOrNull
            val approxBytes = obj["filesize_approx"]?.jsonPrimitive?.longOrNull
                ?: obj["filesize_approx"]?.jsonPrimitive?.doubleOrNull?.toLong()
            val bytes = exactBytes ?: approxBytes ?: 0L
            val kind = when {
                hasVideo -> MediaKind.VIDEO
                hasAudio -> MediaKind.AUDIO
                else -> MediaKind.OTHER
            }
            val reqHeaders = (obj["http_headers"] as? JsonObject)?.entries?.associate {
                it.key to (it.value.jsonPrimitive.contentOrNull.orEmpty())
            }.orEmpty()
            MediaFormat(
                id = obj.str("format_id") ?: directUrl.hashCode().toString(),
                url = directUrl,
                kind = kind,
                label = obj.str("format_note") ?: obj.str("ext").orEmpty(),
                quality = obj["height"]?.jsonPrimitive?.longOrNull?.let { "${it}p" } ?: obj.str("format_note").orEmpty(),
                container = obj.str("ext").orEmpty().uppercase(),
                codec = listOf(vcodec, acodec).filter { it.isNotBlank() && it != "none" }.joinToString(" / "),
                fps = obj["fps"]?.jsonPrimitive?.doubleOrNull?.toInt(),
                bitrateKbps = obj["tbr"]?.jsonPrimitive?.doubleOrNull?.toInt(),
                size = SizeInfo(
                    bytes = bytes,
                    exact = exactBytes != null && exactBytes > 0L,
                    source = if (exactBytes != null) SizeSource.YTDLP_FILESIZE else SizeSource.YTDLP_FILESIZE_APPROX
                ),
                headers = reqHeaders,
                needsMerge = hasVideo && !hasAudio
            )
        }
        val bestAudio = rawFormats.filter { it.kind == MediaKind.AUDIO }.maxByOrNull { it.size.bytes }
        val mergedFormats = rawFormats.map { f ->
            if (f.needsMerge && bestAudio != null) f.copy(bestAudio = bestAudio) else f
        }
        val thumbs = (root["thumbnails"] as? JsonArray)?.mapNotNull { (it as? JsonObject)?.str("url") }.orEmpty()
        val imageFormats = thumbs.takeLast(4).mapIndexed { idx, tUrl ->
            MediaFormat(
                id = "thumb-$idx", url = tUrl, kind = MediaKind.IMAGE,
                label = "Cover #${idx + 1}", quality = "HD", container = "JPG", codec = "JPEG",
                size = SizeInfo(0L, false, SizeSource.YTDLP_FILESIZE_APPROX)
            )
        }
        val subs = mutableListOf<MediaFormat>()
        (root["subtitles"] as? JsonObject)?.forEach { (lang, arr) ->
            val first = (arr as? JsonArray)?.firstOrNull() as? JsonObject ?: return@forEach
            val subUrl = first.str("url") ?: return@forEach
            val ext = first.str("ext")?.uppercase() ?: "VTT"
            subs += MediaFormat(
                id = "sub-$lang", url = subUrl, kind = MediaKind.SUBTITLE,
                label = "Subtitles ($lang)", quality = ext, container = ext, codec = "UTF-8",
                size = SizeInfo(0L, false, SizeSource.YTDLP_FILESIZE_APPROX)
            )
        }
        return AnalysisResult(
            url = url,
            domain = UrlNormalizer.domain(url),
            siteName = root.str("extractor_key") ?: UrlNormalizer.siteName(url),
            title = root.str("title").orEmpty(),
            fileName = UrlNormalizer.sanitizeFileName(root.str("title") ?: UrlNormalizer.fileName(url)),
            thumbnailUrl = root.str("thumbnail") ?: thumbs.lastOrNull().orEmpty(),
            durationSeconds = root["duration"]?.jsonPrimitive?.doubleOrNull?.toLong(),
            uploader = root.str("uploader") ?: root.str("channel").orEmpty(),
            publishDate = root.str("upload_date").orEmpty(),
            formats = mergedFormats + imageFormats + subs,
            subtitles = subs,
            completedStages = setOf(0, 1, 2, 3)
        )
    }

    private fun JsonObject.str(key: String): String? = this[key]?.jsonPrimitive?.contentOrNull
}

@Singleton
class NativeExtractors @Inject constructor(
    private val client: OkHttpClient,
    private val sizeResolver: SizeResolver
) {
    private val directMediaRegex = Regex(
        "https?://[^\\s\"'<>]+?\\.(?:mp4|webm|mkv|mov|m3u8|mpd|mp3|m4a|aac|opus|ogg|flac|wav|jpg|jpeg|png|webp|avif|zip|pdf|apk|srt|vtt)(\\?[^\\s\"'<>]*)?",
        RegexOption.IGNORE_CASE
    )

    suspend fun extract(url: String, headers: Map<String, String> = emptyMap()): AnalysisResult = withContext(Dispatchers.IO) {
        val domain = UrlNormalizer.domain(url)
        val ext = UrlNormalizer.extension(url)
        if (directMediaRegex.containsMatchIn(url) || ext in setOf("mp4", "mkv", "mp3", "m4a", "zip", "apk", "pdf", "png", "jpg", "webp")) {
            val resolved = sizeResolver.resolve(url, headers) ?: SizeInfo(0L, false, SizeSource.YTDLP_FILESIZE_APPROX)
            val format = MediaFormat(
                id = "direct-0",
                url = url,
                kind = UrlNormalizer.kindOf(null, url),
                label = ext.uppercase().ifBlank { "Direct" },
                quality = ext.uppercase().ifBlank { "FILE" },
                container = ext.uppercase().ifBlank { "BIN" },
                codec = "Direct Stream",
                size = resolved,
                headers = headers
            )
            return@withContext AnalysisResult(
                url = url,
                domain = domain,
                siteName = UrlNormalizer.siteName(url),
                title = UrlNormalizer.fileName(url),
                fileName = UrlNormalizer.sanitizeFileName(UrlNormalizer.fileName(url)),
                formats = listOf(format),
                completedStages = setOf(0, 1)
            )
        }
        val html = runCatching {
            val req = Request.Builder().url(url).get().apply { headers.forEach { (k, v) -> header(k, v) } }.build()
            client.newCall(req).execute().use { if (it.isSuccessful) it.body?.string().orEmpty() else "" }
        }.getOrDefault("")
        val doc = Jsoup.parse(html, url)
        val ogTitle = doc.selectFirst("meta[property=og:title]")?.attr("content").orEmpty()
        val ogImage = doc.selectFirst("meta[property=og:image]")?.attr("content").orEmpty()
        val ogVideo = doc.selectFirst("meta[property=og:video]")?.attr("content").orEmpty()
        val favicon = doc.selectFirst("link[rel~=apple-touch-icon], link[rel~=icon]")?.absUrl("href").orEmpty()
        val discovered = buildSet {
            if (ogVideo.isNotBlank()) add(ogVideo)
            addAll(directMediaRegex.findAll(html).map { it.value })
            doc.select("video[src], video source[src], audio[src], audio source[src]").forEach { add(it.absUrl("src")) }
        }.filter { it.startsWith("http", true) }
        val formats = discovered.mapIndexed { i, mediaUrl ->
            val mExt = UrlNormalizer.extension(mediaUrl).uppercase().ifBlank { "MEDIA" }
            MediaFormat(
                id = "page-$i", url = mediaUrl, kind = UrlNormalizer.kindOf(null, mediaUrl),
                label = mExt, quality = mExt, container = mExt, codec = "Web Media",
                size = SizeInfo(0L, false, SizeSource.YTDLP_FILESIZE_APPROX), headers = headers
            )
        }
        AnalysisResult(
            url = url,
            domain = domain,
            siteName = UrlNormalizer.siteName(url),
            faviconUrl = favicon,
            title = ogTitle.ifBlank { doc.title() },
            fileName = UrlNormalizer.sanitizeFileName(ogTitle.ifBlank { doc.title() }.ifBlank { UrlNormalizer.fileName(url) }),
            thumbnailUrl = ogImage,
            formats = formats,
            completedStages = setOf(0, 1, 2),
            directPage = formats.isEmpty()
        )
    }
}
