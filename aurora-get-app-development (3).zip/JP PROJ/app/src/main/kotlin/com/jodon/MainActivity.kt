package com.jodon

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import com.jodon.core.designsystem.DockDestination
import com.jodon.core.designsystem.FloatingDock
import com.jodon.core.designsystem.IconBtn
import com.jodon.core.designsystem.JoDonDesign
import com.jodon.core.designsystem.JoDonGlyph
import com.jodon.core.designsystem.JoDonTheme
import com.jodon.core.designsystem.PillChip
import com.jodon.core.storage.SettingsStore
import com.jodon.feature.browser.SnifferBrowserScreen
import com.jodon.feature.compressor.CompressorScreen
import com.jodon.feature.converter.ConverterScreen
import com.jodon.feature.downloads.DownloadsScreen
import com.jodon.feature.files.MusicAndFilesScreen
import com.jodon.feature.home.HomeScreen
import com.jodon.feature.player.LuxuryPlayerScreen
import com.jodon.feature.player.LuxuryPlayerViewModel
import com.jodon.feature.settings.SettingsScreen
import com.jodon.feature.youtube.YouTubePlatformScreen
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : FragmentActivity() {
    @Inject lateinit var settingsStore: SettingsStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sharedUrl = parseIncomingUrl(intent)
        val initialRoute = intent?.getStringExtra("jodon_route") ?: "home"
        setContent {
            val settings by settingsStore.settings.collectAsState()
            JoDonTheme(
                themeId = settings.themeId,
                light = settings.lightTheme,
                fontScale = settings.fontScale,
                animationScale = settings.animationScale
            ) {
                JoDonRootShell(
                    isArabic = settings.languageTag == "ar",
                    initialRoute = initialRoute,
                    sharedUrl = sharedUrl,
                    onToggleLang = {
                        settingsStore.updateAsync {
                            it.copy(languageTag = if (it.languageTag == "ar") "en" else "ar")
                        }
                    }
                )
            }
        }
    }

    private fun parseIncomingUrl(intent: Intent?): String? = when (intent?.action) {
        Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
        Intent.ACTION_VIEW -> intent.dataString
        else -> null
    }
}

@Composable
private fun JoDonRootShell(
    isArabic: Boolean,
    initialRoute: String,
    sharedUrl: String?,
    onToggleLang: () -> Unit,
    playerVm: LuxuryPlayerViewModel = hiltViewModel()
) {
    val L: (String, String) -> String = { ar, en -> if (isArabic) ar else en }
    var route by remember(initialRoute) { mutableStateOf(initialRoute) }
    var toolsSubTab by remember { mutableStateOf("converter") }
    val transitionMs = JoDonDesign.theme.motion.transitionDurationMs

    val dockItems = listOf(
        DockDestination("home", L("الرئيسية", "Home"), JoDonGlyph.HOME),
        DockDestination("youtube", L("يوتيوب", "YouTube"), JoDonGlyph.YOUTUBE),
        DockDestination("player", L("المشغل", "Player"), JoDonGlyph.PLAYER),
        DockDestination("music", L("الموسيقى", "Music"), JoDonGlyph.MUSIC),
        DockDestination("downloads", L("التحميلات", "Downloads"), JoDonGlyph.DOWNLOAD),
        DockDestination("settings", L("الثيمات", "Themes"), JoDonGlyph.SETTINGS)
    )

    BackHandler(route != "home") { route = "home" }

    CompositionLocalProvider(LocalLayoutDirection provides if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                // Sleek Top Utility Strip
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PillChip("𝒥𝒪 DON", active = true, onClick = { route = "home" })
                        Spacer(Modifier.width(6.dp))
                        PillChip(L("الأدوات", "Tools"), route == "tools", { route = "tools" })
                        Spacer(Modifier.width(6.dp))
                        PillChip(L("المتصفح", "Sniffer"), route == "browser", { route = "browser" })
                    }
                    IconBtn(JoDonGlyph.BROWSER, "Language", onToggleLang)
                }

                Box(Modifier.weight(1f).fillMaxWidth()) {
                    AnimatedContent(
                        targetState = route,
                        transitionSpec = {
                            (fadeIn(tween(transitionMs)) + scaleIn(tween(transitionMs), 0.97f)) togetherWith
                                (fadeOut(tween(transitionMs / 2)) + scaleOut(tween(transitionMs / 2), 0.97f))
                        },
                        label = "routeAnim"
                    ) { currentRoute ->
                        when (currentRoute) {
                            "home" -> HomeScreen(
                                isArabic = isArabic,
                                initialSharedUrl = sharedUrl,
                                onOpenYouTube = { route = "youtube" },
                                onOpenBrowser = { route = "browser" },
                                onOpenDownloads = { route = "downloads" }
                            )
                            "youtube" -> YouTubePlatformScreen(isArabic = isArabic)
                            "player" -> LuxuryPlayerScreen(
                                isArabic = isArabic,
                                vm = playerVm,
                                onPickFilesRequest = { route = "music" }
                            )
                            "music" -> MusicAndFilesScreen(
                                isArabic = isArabic,
                                onPlayQueue = { items, index, asSong ->
                                    playerVm.loadQueue(items, index, asSong)
                                    route = "player"
                                }
                            )
                            "downloads" -> DownloadsScreen(isArabic = isArabic)
                            "browser" -> SnifferBrowserScreen(isArabic = isArabic)
                            "tools" -> Column(Modifier.fillMaxSize()) {
                                Row(
                                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    PillChip(L("محوّل الصيغ", "Converter"), toolsSubTab == "converter", { toolsSubTab = "converter" }, Modifier.weight(1f))
                                    PillChip(L("تصغير الحجم", "Compressor"), toolsSubTab == "compressor", { toolsSubTab = "compressor" }, Modifier.weight(1f))
                                }
                                if (toolsSubTab == "converter") ConverterScreen(isArabic) else CompressorScreen(isArabic)
                            }
                            else -> SettingsScreen(isArabic = isArabic)
                        }
                    }
                }
            }

            FloatingDock(
                items = dockItems,
                selectedId = route,
                onSelect = { route = it },
                modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 12.dp, vertical = 12.dp)
            )
        }
    }
}
