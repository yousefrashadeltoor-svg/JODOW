package com.jodon

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.jodon.engine.downloader.DownloadService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            DownloadService.start(context)
        }
    }
}
