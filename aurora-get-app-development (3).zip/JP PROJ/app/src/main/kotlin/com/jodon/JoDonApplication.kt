package com.jodon

import android.app.Application
import com.jodon.core.storage.SettingsStore
import com.jodon.engine.extractors.YtDlpExtractor
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.HiltAndroidApp
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideJson(): Json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        encodeDefaults = true
        coerceInputValues = true
    }
}

@HiltAndroidApp
class JoDonApplication : Application() {
    @Inject lateinit var ytdlp: YtDlpExtractor
    @Inject lateinit var settingsStore: SettingsStore
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) Timber.plant(Timber.DebugTree())
        appScope.launch {
            ytdlp.ensureInitialized(settingsStore.settings.value.ytdlpAutoUpdate)
        }
    }
}
