package com.jodon.tile

import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import com.jodon.MainActivity
import com.jodon.core.common.DownloadStatus
import com.jodon.engine.downloader.DownloadQueue
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@RequiresApi(Build.VERSION_CODES.N)
@AndroidEntryPoint
class JoDonTileService : TileService() {
    @Inject lateinit var queue: DownloadQueue

    override fun onStartListening() {
        super.onStartListening()
        val activeCount = queue.tasks.value.count { it.status == DownloadStatus.ACTIVE }
        qsTile?.apply {
            state = Tile.STATE_ACTIVE
            subtitle = "$activeCount active"
            updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("jodon_route", "home")
        startActivityAndCollapse(intent)
    }
}
