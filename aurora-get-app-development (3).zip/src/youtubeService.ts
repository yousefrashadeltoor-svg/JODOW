import type { ExtractedFormat, YouTubeVideo } from "./types";

const PIPED_INSTANCES = [
  "https://pipedapi.kavin.rocks",
  "https://pipedapi.adminforge.de",
  "https://pipedapi.smnz.de",
  "https://api.piped.private.coffee",
];

const INVIDIOUS_INSTANCES = [
  "https://inv.nadeko.net",
  "https://invidious.nerdvpn.de",
  "https://yewtu.be",
];

async function fetchJsonWithTimeout<T>(url: string, ms = 6500): Promise<T> {
  const ctrl = new AbortController();
  const id = window.setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return (await res.json()) as T;
  } finally {
    window.clearTimeout(id);
  }
}

/** Real YouTube search autocomplete via JSONP to suggestqueries.google.com + Piped fallback. */
export async function fetchYouTubeSuggestions(query: string, lang = "ar"): Promise<string[]> {
  const q = query.trim();
  if (!q) return [];
  // Try Piped suggestions first (fast CORS JSON)
  for (const base of PIPED_INSTANCES.slice(0, 2)) {
    try {
      const list = await fetchJsonWithTimeout<string[]>(
        `${base}/suggestions?query=${encodeURIComponent(q)}`,
        3200
      );
      if (Array.isArray(list) && list.length > 0) return list.slice(0, 8);
    } catch {
      // continue to next endpoint
    }
  }
  // Fallback to Google YouTube JSONP suggest endpoint
  return new Promise((resolve) => {
    const cbName = `__jodon_yt_sug_${Date.now()}_${Math.floor(Math.random() * 9999)}`;
    const script = document.createElement("script");
    const timer = window.setTimeout(() => {
      cleanup();
      resolve([]);
    }, 3000);
    function cleanup() {
      window.clearTimeout(timer);
      delete (window as unknown as Record<string, unknown>)[cbName];
      script.remove();
    }
    (window as unknown as Record<string, unknown>)[cbName] = (data: unknown) => {
      cleanup();
      if (Array.isArray(data) && Array.isArray(data[1])) {
        const parsed = (data[1] as unknown[])
          .map((entry) => (Array.isArray(entry) ? String(entry[0]) : String(entry)))
          .filter(Boolean);
        resolve(parsed.slice(0, 8));
      } else {
        resolve([]);
      }
    };
    script.onerror = () => {
      cleanup();
      resolve([]);
    };
    script.src = `https://suggestqueries.google.com/complete/search?client=youtube&ds=yt&hl=${lang}&q=${encodeURIComponent(q)}&callback=${cbName}`;
    document.head.appendChild(script);
  });
}

function formatCompactViews(v?: number): string {
  if (!v || v <= 0) return "";
  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M views`;
  if (v >= 1_000) return `${(v / 1_000).toFixed(1)}K views`;
  return `${v} views`;
}

export async function searchYouTubeNative(
  query: string,
  shortsOnly = false
): Promise<YouTubeVideo[]> {
  const effectiveQuery = shortsOnly && !query.toLowerCase().includes("shorts") ? `${query} #shorts` : query;

  // 1. Try Piped instances
  for (const base of PIPED_INSTANCES) {
    try {
      const data = await fetchJsonWithTimeout<{ items?: Record<string, unknown>[] }>(
        `${base}/search?q=${encodeURIComponent(effectiveQuery)}&filter=videos`,
        5500
      );
      if (Array.isArray(data.items) && data.items.length > 0) {
        const mapped: YouTubeVideo[] = data.items
          .map((item) => {
            const rawUrl = String(item.url || "");
            const idMatch = rawUrl.match(/(?:v=|\/shorts\/)([a-zA-Z0-9_-]{11})/);
            const videoId = idMatch ? idMatch[1] : "";
            const dur = Number(item.duration || 0);
            const isShort = Boolean(item.isShort) || (dur > 0 && dur <= 65 && rawUrl.includes("shorts"));
            return {
              videoId,
              title: String(item.title || ""),
              channelId: String(item.uploaderUrl || item.uploaderName || "").replace("/channel/", ""),
              channelName: String(item.uploaderName || "YouTube Creator"),
              channelAvatar: String(item.uploaderAvatar || ""),
              thumbnail: String(item.thumbnail || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`),
              durationSec: dur > 0 ? dur : 0,
              viewsText: formatCompactViews(Number(item.views || 0)),
              uploadedText: String(item.uploadedDate || ""),
              isShort,
            };
          })
          .filter((v) => v.videoId && v.title);
        const filtered = shortsOnly ? mapped.filter((v) => v.isShort || (v.durationSec > 0 && v.durationSec <= 75)) : mapped;
        if (filtered.length > 0) return filtered;
      }
    } catch {
      // try next instance
    }
  }

  // 2. Fallback to Invidious instances
  for (const base of INVIDIOUS_INSTANCES) {
    try {
      const items = await fetchJsonWithTimeout<Record<string, unknown>[]>(
        `${base}/api/v1/search?q=${encodeURIComponent(effectiveQuery)}&type=video`,
        5500
      );
      if (Array.isArray(items) && items.length > 0) {
        const mapped: YouTubeVideo[] = items
          .map((it) => {
            const videoId = String(it.videoId || "");
            const dur = Number(it.lengthSeconds || 0);
            return {
              videoId,
              title: String(it.title || ""),
              channelId: String(it.authorId || it.author || ""),
              channelName: String(it.author || "YouTube"),
              channelAvatar: "",
              thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
              durationSec: dur,
              viewsText: formatCompactViews(Number(it.viewCount || 0)),
              uploadedText: String(it.publishedText || ""),
              isShort: dur > 0 && dur <= 65,
            };
          })
          .filter((v) => v.videoId && v.title);
        const filtered = shortsOnly ? mapped.filter((v) => v.isShort) : mapped;
        if (filtered.length > 0) return filtered;
      }
    } catch {
      // try next
    }
  }
  return [];
}

export async function extractYouTubeStreams(videoId: string): Promise<{
  title: string;
  uploader: string;
  thumbnail: string;
  durationSec: number;
  hlsUrl?: string;
  formats: ExtractedFormat[];
} | null> {
  // Try Piped /streams/:videoId for real direct adaptive & muxed formats
  for (const base of PIPED_INSTANCES) {
    try {
      const data = await fetchJsonWithTimeout<Record<string, unknown>>(
        `${base}/streams/${encodeURIComponent(videoId)}`,
        6000
      );
      const formats: ExtractedFormat[] = [];
      const videoStreams = (data.videoStreams as Record<string, unknown>[]) || [];
      const audioStreams = (data.audioStreams as Record<string, unknown>[]) || [];

      videoStreams.forEach((vs, idx) => {
        const url = String(vs.url || "");
        if (!url) return;
        const bitrate = Number(vs.bitrate || 0);
        const dur = Number(data.duration || 0);
        const estBytes = Number(vs.contentLength || 0) || (bitrate > 0 && dur > 0 ? Math.round((bitrate / 8) * dur) : 0);
        formats.push({
          id: `v-${idx}-${vs.quality || ""}`,
          url,
          kind: "video",
          quality: String(vs.quality || "HD"),
          container: String(vs.format || "MP4").toUpperCase(),
          codec: String(vs.codec || "AVC1"),
          bitrateText: bitrate ? `${Math.round(bitrate / 1000)} kbps` : `${vs.fps || 30}fps`,
          bytes: estBytes,
          exact: Boolean(vs.contentLength && Number(vs.contentLength) > 0),
        });
      });

      audioStreams.forEach((as, idx) => {
        const url = String(as.url || "");
        if (!url) return;
        const bitrate = Number(as.bitrate || 0);
        const dur = Number(data.duration || 0);
        const estBytes = Number(as.contentLength || 0) || (bitrate > 0 && dur > 0 ? Math.round((bitrate / 8) * dur) : 0);
        formats.push({
          id: `a-${idx}-${as.quality || ""}`,
          url,
          kind: "audio",
          quality: String(as.quality || `${Math.round(bitrate / 1000)} kbps`),
          container: String(as.format || "M4A").toUpperCase(),
          codec: String(as.codec || "AAC / Opus"),
          bitrateText: bitrate ? `${Math.round(bitrate / 1000)} kbps` : "Audio",
          bytes: estBytes,
          exact: Boolean(as.contentLength && Number(as.contentLength) > 0),
        });
      });

      const thumb = String(data.thumbnailUrl || `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`);
      formats.push({
        id: "img-maxres",
        url: `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`,
        kind: "images",
        quality: "1280×720",
        container: "JPG",
        codec: "JPEG",
        bitrateText: "Cover Art",
        bytes: 0,
        exact: false,
      });

      const subs = (data.subtitles as Record<string, unknown>[]) || [];
      subs.slice(0, 6).forEach((sub, idx) => {
        const sUrl = String(sub.url || "");
        if (!sUrl) return;
        formats.push({
          id: `sub-${idx}`,
          url: sUrl,
          kind: "files",
          quality: String(sub.name || sub.code || "Subtitles"),
          container: String(sub.mimeType || "VTT").includes("ttml") ? "TTML" : "VTT",
          codec: "UTF-8",
          bitrateText: Boolean(sub.autoGenerated) ? "Auto" : "Captions",
          bytes: 0,
          exact: false,
        });
      });

      return {
        title: String(data.title || "YouTube Video"),
        uploader: String(data.uploader || "YouTube"),
        thumbnail: thumb,
        durationSec: Number(data.duration || 0),
        hlsUrl: data.hls ? String(data.hls) : undefined,
        formats,
      };
    } catch {
      // try next
    }
  }

  // Fallback to YouTube official public CORS oEmbed for metadata + thumbnail formats
  try {
    const watchUrl = `https://www.youtube.com/watch?v=${videoId}`;
    const oembed = await fetchJsonWithTimeout<Record<string, unknown>>(
      `https://www.youtube.com/oembed?url=${encodeURIComponent(watchUrl)}&format=json`,
      4500
    );
    return {
      title: String(oembed.title || `YouTube (${videoId})`),
      uploader: String(oembed.author_name || "YouTube"),
      thumbnail: String(oembed.thumbnail_url || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`),
      durationSec: 0,
      formats: [
        {
          id: "thumb-hq",
          url: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
          kind: "images",
          quality: "HQ Cover",
          container: "JPG",
          codec: "JPEG",
          bitrateText: "Official Thumbnail",
          bytes: 0,
          exact: false,
        },
      ],
    };
  } catch {
    return null;
  }
}

export function extractYouTubeId(rawUrl: string): string | null {
  const m = rawUrl.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|shorts\/|embed\/))([a-zA-Z0-9_-]{11})/);
  return m ? m[1] : null;
}

/** Real URL Analyzer for direct files & YouTube links (Zero Fake Data). */
export async function analyzeAnyUrlReal(rawInput: string): Promise<{
  normalizedUrl: string;
  domain: string;
  title: string;
  uploader: string;
  thumbnail: string;
  durationSec: number;
  formats: ExtractedFormat[];
} | null> {
  const cleaned = rawInput.trim();
  if (!cleaned) return null;
  const normalizedUrl = /^https?:\/\//i.test(cleaned) ? cleaned : `https://${cleaned}`;
  let domain = "";
  try {
    domain = new URL(normalizedUrl).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }

  const ytId = extractYouTubeId(normalizedUrl);
  if (ytId) {
    const yt = await extractYouTubeStreams(ytId);
    if (yt) {
      return {
        normalizedUrl,
        domain,
        title: yt.title,
        uploader: yt.uploader,
        thumbnail: yt.thumbnail,
        durationSec: yt.durationSec,
        formats: yt.formats,
      };
    }
  }

  // Probe real direct URL via HEAD / Range: bytes=0-0
  const pathName = decodeURIComponent(new URL(normalizedUrl).pathname.split("/").pop() || "download");
  const ext = (pathName.split(".").pop() || "").toLowerCase();
  let bytes = 0;
  let exact = false;
  let contentType = "";

  try {
    const headRes = await fetch(normalizedUrl, { method: "HEAD" });
    contentType = headRes.headers.get("content-type") || "";
    const cl = Number(headRes.headers.get("content-length") || 0);
    if (cl > 0) {
      bytes = cl;
      exact = true;
    }
  } catch {
    // HEAD blocked by CORS or server; try Range bytes=0-0
    try {
      const rangeRes = await fetch(normalizedUrl, { headers: { Range: "bytes=0-0" } });
      contentType = rangeRes.headers.get("content-type") || "";
      const cr = rangeRes.headers.get("content-range") || "";
      const total = Number(cr.split("/").pop() || 0);
      if (total > 0) {
        bytes = total;
        exact = true;
      }
    } catch {
      // Cross-origin opaque link: still allow direct download without faking size
    }
  }

  const kind: ExtractedFormat["kind"] =
    contentType.startsWith("video/") || ["mp4", "mkv", "webm", "mov", "m3u8"].includes(ext)
      ? "video"
      : contentType.startsWith("audio/") || ["mp3", "m4a", "opus", "ogg", "flac", "wav"].includes(ext)
      ? "audio"
      : contentType.startsWith("image/") || ["jpg", "jpeg", "png", "webp", "avif", "gif"].includes(ext)
      ? "images"
      : "files";

  return {
    normalizedUrl,
    domain,
    title: pathName || domain,
    uploader: domain,
    thumbnail: kind === "images" ? normalizedUrl : "",
    durationSec: 0,
    formats: [
      {
        id: "direct-stream",
        url: normalizedUrl,
        kind,
        quality: ext ? ext.toUpperCase() : "DIRECT",
        container: ext ? ext.toUpperCase() : "BIN",
        codec: contentType ? contentType.split(";")[0] : "HTTP Direct",
        bitrateText: exact ? "Verified Content-Length" : "Direct Link",
        bytes,
        exact,
      },
    ],
  };
}
