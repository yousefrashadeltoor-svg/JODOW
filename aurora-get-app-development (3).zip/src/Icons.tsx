import type { ReactNode } from "react";

export type IconId =
  | "youtube" | "shorts" | "home" | "player" | "music" | "download" | "settings"
  | "search" | "user" | "heart" | "copy" | "share" | "play" | "pause" | "next"
  | "prev" | "scissors" | "bell" | "timer" | "repeat" | "sliders" | "folder"
  | "plus" | "close" | "check" | "sparkles" | "link" | "clipboard" | "video"
  | "image" | "file" | "globe" | "sun" | "moon" | "trash" | "pip" | "waveform"
  | "upload" | "refresh" | "lock";

const PATHS: Record<IconId, ReactNode> = {
  youtube: (
    <>
      <rect x="2" y="5" width="20" height="14" rx="4.5" fill="#FF0033" stroke="none" />
      <polygon points="10,8.6 16.2,12 10,15.4" fill="#FFFFFF" stroke="none" />
    </>
  ),
  shorts: (
    <>
      <rect x="5.5" y="2.8" width="13" height="18.4" rx="4" />
      <polygon points="10,8.8 15.5,12 10,15.2" fill="currentColor" stroke="none" />
    </>
  ),
  home: <><path d="m3.5 10.5 8.5-7 8.5 7" /><path d="M6 9.8V19.5a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V9.8" /></>,
  player: <polygon points="7.5,5 19.5,12 7.5,19" fill="currentColor" stroke="none" />,
  play: <polygon points="7.5,5 19.5,12 7.5,19" fill="currentColor" stroke="none" />,
  pause: <><rect x="6.5" y="5" width="3.8" height="14" rx="1.4" fill="currentColor" stroke="none" /><rect x="13.7" y="5" width="3.8" height="14" rx="1.4" fill="currentColor" stroke="none" /></>,
  next: <><polygon points="5.5,6 15,12 5.5,18" fill="currentColor" stroke="none" /><path d="M18 6v12" /></>,
  prev: <><polygon points="18.5,6 9,12 18.5,18" fill="currentColor" stroke="none" /><path d="M6 6v12" /></>,
  music: <><path d="M9 18V6.2l10-1.8V16" /><circle cx="6.2" cy="18" r="2.6" /><circle cx="16.2" cy="16" r="2.6" /></>,
  download: <><path d="M12 3.5v11.5" /><path d="m7.5 10.5 4.5 4.5 4.5-4.5" /><path d="M4.5 19.5h15" /></>,
  settings: <><circle cx="12" cy="12" r="3.2" /><circle cx="12" cy="12" r="8.4" strokeDasharray="3 2.2" /></>,
  search: <><circle cx="10.6" cy="10.6" r="6.2" /><path d="m15.2 15.2 4.5 4.5" /></>,
  user: <><circle cx="12" cy="8" r="3.8" /><path d="M5 20a7 7 0 0 1 14 0" /></>,
  heart: <path d="M12 20s-7.5-4.5-7.5-9.4A4.2 4.2 0 0 1 12 8a4.2 4.2 0 0 1 7.5 2.6C19.5 15.5 12 20 12 20Z" />,
  copy: <><rect x="8.2" y="8.2" width="11.5" height="11.5" rx="2.6" /><path d="M15.8 8.2V6.4A2.2 2.2 0 0 0 13.6 4.2H6.4A2.2 2.2 0 0 0 4.2 6.4v7.2a2.2 2.2 0 0 0 2.2 2.2h1.8" /></>,
  share: <><circle cx="18" cy="5.5" r="2.3" /><circle cx="6" cy="12" r="2.3" /><circle cx="18" cy="18.5" r="2.3" /><path d="m8.2 10.9 7.6-4.3M8.2 13.1l7.6 4.3" /></>,
  scissors: <><circle cx="6.5" cy="7.5" r="2.6" /><circle cx="6.5" cy="16.5" r="2.6" /><path d="M8.8 9 19.5 18M8.8 15 19.5 6" /></>,
  bell: <><path d="M6 9.5a6 6 0 0 1 12 0c0 4 1.6 5.5 1.6 5.5H4.4S6 13.5 6 9.5Z" /><path d="M10 18.5a2.2 2.2 0 0 0 4 0" /></>,
  timer: <><circle cx="12" cy="12.5" r="8" /><path d="M12 8v4.5l3.2 2M9.5 2.5h5" /></>,
  repeat: <><path d="M17 4l3 3-3 3" /><path d="M4 11V9a2 2 0 0 1 2-2h14" /><path d="M7 20l-3-3 3-3" /><path d="M20 13v2a2 2 0 0 1-2 2H4" /></>,
  sliders: <><path d="M4 7h9M17 7h3M4 17h3M11 17h9" /><circle cx="15" cy="7" r="2" /><circle cx="9" cy="17" r="2" /></>,
  folder: <path d="M3.5 7.5A2 2 0 0 1 5.5 5.5h3.8l2 2.2h7.2a2 2 0 0 1 2 2v8.2a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2V7.5Z" />,
  plus: <path d="M12 5v14M5 12h14" />,
  close: <path d="M6 6 18 18M18 6 6 18" />,
  check: <path d="m5 12.5 4.4 4.4L19 7.5" />,
  sparkles: <path d="M12 3.2 13.9 8.4l5.2 1.9-5.2 1.9L12 17.4l-1.9-5.2-5.2-1.9 5.2-1.9L12 3.2Z" />,
  link: <><path d="M9.5 14.5 14.5 9.5" /><path d="M7.4 11.1 5.9 12.6a3.7 3.7 0 0 0 5.2 5.2l1.5-1.5" /><path d="m16.6 12.9 1.5-1.5a3.7 3.7 0 0 0-5.2-5.2l-1.5 1.5" /></>,
  clipboard: <><rect x="6" y="4.8" width="12" height="15.8" rx="2.8" /><path d="M9.5 10.5h5M9.5 14.5h3.5" /></>,
  video: <><rect x="3" y="5.5" width="13" height="13" rx="3" /><path d="m16 10.5 5-3v9l-5-3" /></>,
  image: <><rect x="3.5" y="4.5" width="17" height="15" rx="3" /><circle cx="8.6" cy="9.6" r="1.5" /><path d="m4.5 17 5-4.5 3.5 3 2.5-2.2 4 3.7" /></>,
  file: <><rect x="5.5" y="3.5" width="13" height="17" rx="2.5" /><path d="M8.5 11h7M8.5 15h5" /></>,
  globe: <><circle cx="12" cy="12" r="8.5" /><path d="M3.5 12h17M12 3.5c2.2 2.4 3.2 5.3 3.2 8.5s-1 6.1-3.2 8.5c-2.2-2.4-3.2-5.3-3.2-8.5s1-6.1 3.2-8.5Z" /></>,
  sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2" /></>,
  moon: <path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z" />,
  trash: <><path d="M4.5 7h15M9 7V4.8h6V7M6.8 7l.8 12.2a1.5 1.5 0 0 0 1.5 1.3h5.8a1.5 1.5 0 0 0 1.5-1.3L17.2 7" /></>,
  pip: <><rect x="3" y="5" width="18" height="14" rx="3" /><rect x="12" y="12" width="7" height="5" rx="1.4" /></>,
  waveform: <path d="M4 12v0M8 7v10M12 4v16M16 8v8M20 10v4" />,
  upload: <><path d="M12 16V4.5" /><path d="m7.5 9 4.5-4.5L16.5 9" /><path d="M4.5 19.5h15" /></>,
  refresh: <><path d="M20 10a8 8 0 1 0 .2 4" /><path d="M20 4v6h-6" /></>,
  lock: <><rect x="5" y="10.5" width="14" height="9.5" rx="3" /><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" /></>,
};

export function Icon({ id, size = 18, className = "" }: { id: IconId; size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={`shrink-0 ${className}`}
      aria-hidden="true"
    >
      {PATHS[id]}
    </svg>
  );
}
