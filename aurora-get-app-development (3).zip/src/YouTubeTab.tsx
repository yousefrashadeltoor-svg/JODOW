import { useEffect, useRef, useState } from "react";
import { Icon } from "./Icons";
import type {
  ExtractedFormat,
  FollowedChannel,
  Lang,
  LocalYouTubeProfile,
  YouTubeVideo,
} from "./types";
import { formatBytes, formatClock } from "./types";
import {
  extractYouTubeStreams,
  fetchYouTubeSuggestions,
  searchYouTubeNative,
} from "./youtubeService";

interface Props {
  lang: Lang;
  profile: LocalYouTubeProfile;
  setProfile: (updater: (prev: LocalYouTubeProfile) => LocalYouTubeProfile) => void;
  onStartDownload: (title: string, fmt: ExtractedFormat) => void;
  onToast: (msg: string) => void;
}

type YtView = "home" | "shorts" | "subs" | "account";

export function YouTubeTab({
  lang,
  profile,
  setProfile,
  onStartDownload,
  onToast,
}: Props) {
  const t = (ar: string, en: string) => (lang === "ar" ? ar : en);

  const [view, setView] = useState<YtView>("home");
  const [topic, setTopic] = useState("for_you");
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [homeVideos, setHomeVideos] = useState<YouTubeVideo[]>([]);
  const [shortsVideos, setShortsVideos] = useState<YouTubeVideo[]>([]);
  const [subsVideos, setSubsVideos] = useState<YouTubeVideo[]>([]);
  const [searchResults, setSearchResults] = useState<YouTubeVideo[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [onlineError, setOnlineError] = useState(false);

  const [activeWatch, setActiveWatch] = useState<YouTubeVideo | null>(null);
  const [watchAsSong, setWatchAsSong] = useState(false);
  const [watchDirectStream, setWatchDirectStream] = useState<string | null>(null);

  const [dlModalVideo, setDlModalVideo] = useState<YouTubeVideo | null>(null);
  const [dlFormats, setDlFormats] = useState<ExtractedFormat[]>([]);
  const [dlLoading, setDlLoading] = useState(false);
  const [playlistModalVideo, setPlaylistModalVideo] = useState<YouTubeVideo | null>(null);
  const [newPlaylistName, setNewPlaylistName] = useState("");
  const [shortIdx, setShortIdx] = useState(0);

  const [editName, setEditName] = useState(profile.displayName);
  const [editHandle, setEditHandle] = useState(profile.handle);
  const [editBio, setEditBio] = useState(profile.bio);

  const seedCursor = useRef(0);
  const sentinelRef = useRef<HTMLDivElement | null>(null);
  const importInputRef = useRef<HTMLInputElement | null>(null);

  const getPersonalizedSeeds = (): string[] => {
    const chs = profile.followedChannels.map((c) => c.name);
    const weightedTopics = Object.entries(profile.topicWeights)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([k]) => k);
    const weightedChs = Object.entries(profile.channelWeights)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([k]) => k);
    const merged = Array.from(new Set([...chs, ...weightedChs, ...weightedTopics])).filter(Boolean);
    return merged.length > 0
      ? merged
      : ["4K nature documentary", "arabic acoustic music", "science technology", "cinematic soundtrack"];
  };

  const loadMoreHome = async (reset = false, overrideTopic?: string) => {
    if (loading) return;
    setLoading(true);
    setOnlineError(false);
    const activeT = overrideTopic ?? topic;
    const seeds = getPersonalizedSeeds();
    const seedQuery =
      activeT !== "for_you"
        ? activeT
        : seeds[seedCursor.current++ % seeds.length];

    const batch = await searchYouTubeNative(seedQuery, false);
    if (batch.length === 0 && (reset || homeVideos.length === 0)) {
      setOnlineError(true);
    }
    setHomeVideos((prev) => {
      const base = reset ? [] : prev;
      const seen = new Set(base.map((v) => v.videoId));
      return [...base, ...batch.filter((v) => !seen.has(v.videoId))];
    });
    setLoading(false);
  };

  const loadShorts = async () => {
    setLoading(true);
    const seeds = getPersonalizedSeeds();
    const items = await searchYouTubeNative(seeds[0] || "shorts", true);
    setShortsVideos((prev) => {
      const seen = new Set(prev.map((v) => v.videoId));
      return [...prev, ...items.filter((v) => !seen.has(v.videoId))];
    });
    setLoading(false);
  };

  const loadSubscriptions = async () => {
    if (profile.followedChannels.length === 0) {
      setSubsVideos([]);
      return;
    }
    setLoading(true);
    const all: YouTubeVideo[] = [];
    for (const ch of profile.followedChannels.slice(0, 6)) {
      const res = await searchYouTubeNative(ch.name, false);
      all.push(...res.slice(0, 6));
    }
    const seen = new Set<string>();
    setSubsVideos(
      all.filter((v) => {
        if (seen.has(v.videoId)) return false;
        seen.add(v.videoId);
        return true;
      })
    );
    setLoading(false);
  };

  useEffect(() => {
    void loadMoreHome(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (view === "shorts" && shortsVideos.length === 0) void loadShorts();
    if (view === "subs") void loadSubscriptions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view, profile.followedChannels.length]);

  // Infinite scroll observer on Home feed
  useEffect(() => {
    if (view !== "home" || searchResults !== null) return;
    const node = sentinelRef.current;
    if (!node) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting && !loading && homeVideos.length > 0) {
          void loadMoreHome(false);
        }
      },
      { rootMargin: "220px" }
    );
    obs.observe(node);
    return () => obs.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view, searchResults, loading, homeVideos.length, topic]);

  // Debounced live autocomplete suggestions
  useEffect(() => {
    const q = query.trim();
    if (!q) {
      setSuggestions([]);
      return;
    }
    const timer = window.setTimeout(async () => {
      const list = await fetchYouTubeSuggestions(q, lang);
      setSuggestions(list);
    }, 180);
    return () => window.clearTimeout(timer);
  }, [query, lang]);

  const runSearch = async (q: string) => {
    const clean = q.trim();
    if (!clean) return;
    setQuery(clean);
    setSuggestions([]);
    setLoading(true);
    setProfile((prev) => ({
      ...prev,
      searchHistory: [clean, ...prev.searchHistory.filter((x) => x.toLowerCase() !== clean.toLowerCase())].slice(0, 30),
      topicWeights: {
        ...prev.topicWeights,
        [clean.toLowerCase()]: (prev.topicWeights[clean.toLowerCase()] || 0) + 2,
      },
    }));
    const res = await searchYouTubeNative(clean, false);
    setSearchResults(res);
    setLoading(false);
  };

  const recordWatchSignal = (video: YouTubeVideo) => {
    if (profile.historyPaused) return;
    const tokens = video.title
      .split(/[^\p{L}\p{N}]+/u)
      .map((w) => w.toLowerCase())
      .filter((w) => w.length >= 4)
      .slice(0, 5);
    setProfile((prev) => {
      const nextTopics = { ...prev.topicWeights };
      tokens.forEach((tk) => {
        nextTopics[tk] = (nextTopics[tk] || 0) + 1.5;
      });
      const nextCh = { ...prev.channelWeights };
      if (video.channelName) {
        nextCh[video.channelName] = (nextCh[video.channelName] || 0) + 2.5;
      }
      return {
        ...prev,
        watchHistory: [video, ...prev.watchHistory.filter((v) => v.videoId !== video.videoId)].slice(0, 200),
        topicWeights: nextTopics,
        channelWeights: nextCh,
      };
    });
  };

  const openWatch = async (video: YouTubeVideo, asSong: boolean) => {
    recordWatchSignal(video);
    setActiveWatch(video);
    setWatchAsSong(asSong);
    setWatchDirectStream(null);
    const streams = await extractYouTubeStreams(video.videoId);
    if (streams) {
      const chosen = asSong
        ? streams.formats.find((f) => f.kind === "audio")
        : streams.formats.find((f) => f.kind === "video");
      if (chosen) setWatchDirectStream(chosen.url);
    }
  };

  const openDownloadPicker = async (video: YouTubeVideo) => {
    setDlModalVideo(video);
    setDlFormats([]);
    setDlLoading(true);
    const extracted = await extractYouTubeStreams(video.videoId);
    setDlLoading(false);
    if (extracted && extracted.formats.length > 0) {
      setDlFormats(extracted.formats);
    }
  };

  const toggleFollow = (ch: FollowedChannel) => {
    setProfile((prev) => {
      const exists = prev.followedChannels.some((c) => c.channelId === ch.channelId);
      onToast(
        exists
          ? t(`تم إلغاء متابعة ${ch.name}`, `Unfollowed ${ch.name}`)
          : t(`تمت متابعة ${ch.name} محلياً`, `Followed ${ch.name} locally`)
      );
      return {
        ...prev,
        followedChannels: exists
          ? prev.followedChannels.filter((c) => c.channelId !== ch.channelId)
          : [ch, ...prev.followedChannels],
      };
    });
  };

  const toggleLike = (video: YouTubeVideo) => {
    setProfile((prev) => {
      const liked = prev.likedVideos.some((v) => v.videoId === video.videoId);
      return {
        ...prev,
        likedVideos: liked
          ? prev.likedVideos.filter((v) => v.videoId !== video.videoId)
          : [video, ...prev.likedVideos],
      };
    });
  };

  const copyVideoLink = (video: YouTubeVideo) => {
    const link = video.isShort
      ? `https://www.youtube.com/shorts/${video.videoId}`
      : `https://www.youtube.com/watch?v=${video.videoId}`;
    void navigator.clipboard?.writeText(link);
    onToast(t("تم نسخ رابط الفيديو إلى الحافظة", "Video URL copied to clipboard"));
  };

  const exportProfileJson = () => {
    const blob = new Blob([JSON.stringify(profile, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `jodon_youtube_profile_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    onToast(t("تم تصدير ملفك الشخصي المحلي (JSON)", "Local YouTube profile exported"));
  };

  const importProfileJson = async (file: File | undefined) => {
    if (!file) return;
    try {
      const raw = await file.text();
      const parsed = JSON.parse(raw) as Partial<LocalYouTubeProfile>;
      if (!parsed || typeof parsed !== "object") throw new Error("Invalid");
      setProfile((prev) => ({
        ...prev,
        ...parsed,
        followedChannels: Array.isArray(parsed.followedChannels) ? parsed.followedChannels : prev.followedChannels,
        watchHistory: Array.isArray(parsed.watchHistory) ? parsed.watchHistory : prev.watchHistory,
        likedVideos: Array.isArray(parsed.likedVideos) ? parsed.likedVideos : prev.likedVideos,
        playlists: Array.isArray(parsed.playlists) ? parsed.playlists : prev.playlists,
      }));
      onToast(t("تم استيراد الحساب المحلي والاشتراكات والسجل بنجاح!", "Profile, subscriptions & history imported!"));
    } catch {
      onToast(t("ملف JSON غير صالح", "Invalid JSON backup file"));
    }
  };

  const dynamicTopics: [string, string][] = [
    ["for_you", t("مقترح لك", "For You")],
    ["music", t("موسيقى", "Music")],
    ["technology", t("تقنية", "Tech")],
    ["documentary", t("وثائقيات", "Docs")],
    ["gaming", t("ألعاب", "Gaming")],
    ...Object.keys(profile.topicWeights)
      .slice(0, 4)
      .map((k): [string, string] => [k, `#${k}`]),
  ];

  const renderVideoCard = (v: YouTubeVideo) => {
    const isFollowing = profile.followedChannels.some((c) => c.channelId === v.channelId);
    const isLiked = profile.likedVideos.some((x) => x.videoId === v.videoId);
    return (
      <div key={v.videoId} className="glass-panel p-3 spring-enter">
        <div
          onClick={() => void openWatch(v, false)}
          className="relative w-full h-[186px] rounded-[18px] overflow-hidden cursor-pointer bg-black/40"
        >
          <img
            src={v.thumbnail}
            alt={v.title}
            loading="lazy"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
          <span className="absolute top-2.5 inset-inline-start-2.5 px-2 py-0.5 rounded-full text-[9.5px] font-bold bg-black/65 text-white flex items-center gap-1">
            <Icon id="youtube" size={13} /> YouTube
          </span>
          {v.durationSec > 0 && (
            <span className="absolute bottom-2 inset-inline-end-2.5 px-2 py-0.5 rounded-md text-[10px] font-bold bg-black/80 text-white mono">
              {formatClock(v.durationSec)}
            </span>
          )}
        </div>

        <h3
          onClick={() => void openWatch(v, false)}
          className="m-0 mt-2.5 text-[13px] font-bold leading-snug cursor-pointer"
        >
          {v.title}
        </h3>

        <div className="flex items-center justify-between gap-2 mt-2">
          <div className="flex items-center gap-2 min-w-0">
            {v.channelAvatar ? (
              <img src={v.channelAvatar} alt="" className="w-7 h-7 rounded-full object-cover shrink-0" />
            ) : (
              <span className="w-7 h-7 rounded-full grid place-items-center text-[11px] font-bold bg-[var(--glass-hi)] shrink-0">
                {v.channelName.slice(0, 1).toUpperCase()}
              </span>
            )}
            <div className="min-w-0">
              <div className="text-[11px] font-bold truncate text-[var(--a1)]">{v.channelName}</div>
              <div className="text-[9.5px] text-[var(--muted)] truncate">
                {[v.viewsText, v.uploadedText].filter(Boolean).join(" · ")}
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={() =>
              toggleFollow({
                channelId: v.channelId || v.channelName,
                name: v.channelName,
                avatar: v.channelAvatar,
                followedAt: Date.now(),
              })
            }
            className={`pill pressable ${isFollowing ? "active" : ""}`}
          >
            {isFollowing ? t("متابَع ✓", "Following ✓") : t("+ متابعة", "+ Follow")}
          </button>
        </div>

        {/* Dedicated Actions Underneath Every Video: Download, Copy Link, Play as Song, Like, Playlist */}
        <div className="flex items-center gap-1.5 mt-3 flex-wrap">
          <button
            type="button"
            onClick={() => void openDownloadPicker(v)}
            className="btn-aurora pressable flex-1 !py-2 !px-3 !text-[11px]"
          >
            <Icon id="download" size={14} /> {t("تحميل", "Download")}
          </button>
          <button
            type="button"
            onClick={() => copyVideoLink(v)}
            className="btn-glass pressable !py-2 !px-2.5"
            title={t("نسخ رابط الفيديو", "Copy Video Link")}
          >
            <Icon id="copy" size={13} /> {t("نسخ الرابط", "Copy Link")}
          </button>
          <button
            type="button"
            onClick={() => void openWatch(v, true)}
            className="btn-glass pressable !py-2 !px-2.5"
            title={t("تشغيل كأغنية", "Play as Song")}
          >
            <Icon id="music" size={13} /> {t("كأغنية", "Song")}
          </button>
          <button
            type="button"
            onClick={() => toggleLike(v)}
            className={`btn-glass pressable !py-2 !px-2.5 ${isLiked ? "!text-rose-400" : ""}`}
            title="Like"
          >
            <Icon id="heart" size={13} />
          </button>
          <button
            type="button"
            onClick={() => setPlaylistModalVideo(v)}
            className="btn-glass pressable !py-2 !px-2.5"
            title="Add to Playlist"
          >
            <Icon id="plus" size={13} />
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-3">
      {/* Platform Header: Official YouTube Logo + Shorts Button + My Local Account Button */}
      <div className="flex items-center justify-between gap-2 pt-1">
        <div
          onClick={() => {
            setSearchResults(null);
            setView("home");
          }}
          className="flex items-center gap-2 cursor-pointer"
        >
          <Icon id="youtube" size={28} />
          <div>
            <div className="text-[16px] font-extrabold leading-none tracking-tight">YouTube</div>
            <div className="text-[9px] text-[var(--muted)] mt-0.5">
              {t("تطبيق مستقل مدمج · حساب محلي حر", "Native Hub · Local Account")}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => {
              setSearchResults(null);
              setView("shorts");
            }}
            className={`pill pressable ${view === "shorts" && !searchResults ? "active" : ""}`}
          >
            <Icon id="shorts" size={13} /> {t("شورتس", "Shorts")}
          </button>
          <button
            type="button"
            onClick={() => {
              setSearchResults(null);
              setView("account");
            }}
            className={`pill pressable ${view === "account" && !searchResults ? "active" : ""}`}
          >
            <Icon id="user" size={13} /> {t("حسابي", "My Account")}
          </button>
        </div>
      </div>

      {/* Search Bar with Live Autocomplete Suggestions */}
      <div className="relative">
        <div className="glass-subtle flex items-center gap-2 px-3 py-2 !rounded-full">
          <Icon id="search" size={15} className="text-[var(--muted)]" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && void runSearch(query)}
            placeholder={t("ابحث في يوتيوب بدقة...", "Search YouTube...")}
            className="flex-1 min-w-0 text-[12px]"
          />
          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery("");
                setSuggestions([]);
                setSearchResults(null);
              }}
              className="text-[var(--muted)] pressable"
            >
              <Icon id="close" size={14} />
            </button>
          )}
          <button
            type="button"
            onClick={() => void runSearch(query)}
            className="pill active pressable !py-1 !px-2.5"
          >
            {t("بحث", "Search")}
          </button>
        </div>

        {suggestions.length > 0 && (
          <div className="glass-panel p-2 mt-1.5 space-y-1 z-30 relative">
            {suggestions.map((sug) => (
              <button
                key={sug}
                type="button"
                onClick={() => void runSearch(sug)}
                className="w-full text-start px-2.5 py-1.5 rounded-xl hover:bg-[var(--glass-hi)] flex items-center gap-2 text-[11.5px]"
              >
                <Icon id="search" size={13} className="text-[var(--a1)]" />
                <span className="truncate">{sug}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Sub-navigation Strip */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
        <button
          type="button"
          onClick={() => {
            setSearchResults(null);
            setView("home");
          }}
          className={`pill pressable ${view === "home" && !searchResults ? "active" : ""}`}
        >
          <Icon id="home" size={12} /> {t("الرئيسية", "Home")}
        </button>
        <button
          type="button"
          onClick={() => {
            setSearchResults(null);
            setView("shorts");
          }}
          className={`pill pressable ${view === "shorts" && !searchResults ? "active" : ""}`}
        >
          <Icon id="shorts" size={12} /> {t("شورتس", "Shorts")}
        </button>
        <button
          type="button"
          onClick={() => {
            setSearchResults(null);
            setView("subs");
          }}
          className={`pill pressable ${view === "subs" && !searchResults ? "active" : ""}`}
        >
          {t("الاشتراكات", "Subscriptions")} ({profile.followedChannels.length})
        </button>
        <button
          type="button"
          onClick={() => {
            setSearchResults(null);
            setView("account");
          }}
          className={`pill pressable ${view === "account" && !searchResults ? "active" : ""}`}
        >
          <Icon id="user" size={12} /> {t("حسابي المحلي", "Local Profile")}
        </button>
      </div>

      {/* Inline Native Watch / Song Player */}
      {activeWatch && (
        <div className="glass-panel p-3 space-y-2.5 spring-enter">
          <div className="flex items-center justify-between gap-2">
            <span className="pill active">
              <Icon id={watchAsSong ? "music" : "play"} size={11} />
              {watchAsSong ? t("وضع الأغنية الصوتية", "Audio Song Mode") : t("المشغل المدمج", "Now Playing")}
            </span>
            <button type="button" onClick={() => setActiveWatch(null)} className="btn-glass !p-1.5">
              <Icon id="close" size={14} />
            </button>
          </div>

          {watchAsSong ? (
            <div className="flex items-center gap-3 p-2 rounded-2xl bg-black/30">
              <img src={activeWatch.thumbnail} alt="" className="w-16 h-16 rounded-2xl object-cover" />
              <div className="flex-1 min-w-0">
                <div className="text-[12px] font-bold truncate">{activeWatch.title}</div>
                <div className="text-[10px] text-[var(--muted)]">{activeWatch.channelName}</div>
                {watchDirectStream ? (
                  <audio src={watchDirectStream} controls autoPlay className="w-full h-8 mt-1.5" />
                ) : (
                  <div className="text-[10px] text-[var(--a1)] mt-1">
                    {t("جارٍ استخراج المسار الصوتي المباشر...", "Resolving direct audio stream...")}
                  </div>
                )}
              </div>
            </div>
          ) : watchDirectStream ? (
            <video
              src={watchDirectStream}
              controls
              autoPlay
              playsInline
              poster={activeWatch.thumbnail}
              className="w-full rounded-2xl max-h-[220px] bg-black"
            />
          ) : (
            <iframe
              title={activeWatch.title}
              src={`https://www.youtube-nocookie.com/embed/${activeWatch.videoId}?autoplay=1&rel=0`}
              allow="autoplay; encrypted-media; picture-in-picture"
              allowFullScreen
              className="w-full h-[210px] rounded-2xl border-0 bg-black"
            />
          )}

          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              onClick={() => void openWatch(activeWatch, !watchAsSong)}
              className="btn-glass pressable !py-1.5 !px-2.5"
            >
              <Icon id={watchAsSong ? "video" : "music"} size={13} />
              {watchAsSong ? t("عرض الفيديو", "Show Video") : t("تشغيل كأغنية", "Play as Song")}
            </button>
            <button
              type="button"
              onClick={() => void openDownloadPicker(activeWatch)}
              className="btn-aurora pressable !py-1.5 !px-3"
            >
              <Icon id="download" size={13} /> {t("تحميل", "Download")}
            </button>
            <button
              type="button"
              onClick={() => copyVideoLink(activeWatch)}
              className="btn-glass pressable !py-1.5 !px-2.5"
            >
              <Icon id="copy" size={13} /> {t("نسخ الرابط", "Copy Link")}
            </button>
          </div>
        </div>
      )}

      {/* Search Results View */}
      {searchResults !== null ? (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[12px] font-bold">
              {t("نتائج البحث الدقيقة", "Search Results")} ({searchResults.length})
            </span>
            <button type="button" onClick={() => setSearchResults(null)} className="text-[11px] text-[var(--a1)]">
              {t("عودة للرئيسية", "Back to Feed")}
            </button>
          </div>
          {searchResults.map(renderVideoCard)}
        </div>
      ) : view === "home" ? (
        <div className="space-y-3">
          {/* Personalized Topic Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
            {dynamicTopics.map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => {
                  setTopic(key);
                  void loadMoreHome(true, key);
                }}
                className={`pill pressable ${topic === key ? "active" : ""}`}
              >
                {label}
              </button>
            ))}
          </div>

          {onlineError && homeVideos.length === 0 && (
            <div className="glass-panel p-4 text-center space-y-2">
              <div className="text-[13px] font-bold">
                {t("أنت غير متصل بالإنترنت أو تعذر الوصول لخوادم البحث", "Offline — Live YouTube feed requires internet")}
              </div>
              <p className="text-[11px] text-[var(--muted)] m-0">
                {t("تبقى جميع ميزات حسابك المحلي، سجل المشاهدة، القنوات المتابعة، والمشغل الفاخر عاملة 100% بدون إنترنت.", "Your local profile, subscriptions, watch history, and local media player remain 100% available offline.")}
              </p>
              <button type="button" onClick={() => void loadMoreHome(true)} className="btn-aurora pressable">
                <Icon id="refresh" size={14} /> {t("إعادة المحاولة", "Retry")}
              </button>
            </div>
          )}

          {homeVideos.map(renderVideoCard)}
          <div ref={sentinelRef} className="py-3 text-center">
            {loading ? (
              <span className="pill">{t("جارٍ جلب اقتراحات مخصصة جديدة...", "Loading personalized recommendations...")}</span>
            ) : homeVideos.length > 0 ? (
              <button type="button" onClick={() => void loadMoreHome(false)} className="btn-glass pressable">
                {t("تحميل المزيد من الاقتراحات", "Load More Recommendations")}
              </button>
            ) : null}
          </div>
        </div>
      ) : view === "shorts" ? (
        <div className="space-y-3">
          {shortsVideos.length === 0 ? (
            <div className="glass-panel p-6 text-center space-y-3">
              <Icon id="shorts" size={36} className="mx-auto text-[var(--a1)]" />
              <div className="text-[13px] font-bold">{t("مشغل شورتس العمودي", "Vertical Shorts Feed")}</div>
              <button type="button" onClick={() => void loadShorts()} className="btn-aurora pressable">
                {loading ? t("جارٍ التحميل...", "Loading...") : t("استعراض مقاطع شورتس", "Load Shorts")}
              </button>
            </div>
          ) : (
            (() => {
              const cur = shortsVideos[shortIdx % shortsVideos.length];
              const isFol = profile.followedChannels.some((c) => c.channelId === cur.channelId);
              return (
                <div className="relative rounded-[28px] overflow-hidden h-[490px] border border-[var(--border)] bg-black">
                  <img src={cur.thumbnail} alt={cur.title} className="w-full h-full object-cover opacity-90" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/15 to-black/40" />

                  <div className="absolute top-3 inset-inline-3 flex items-center justify-between">
                    <span className="pill active">
                      <Icon id="shorts" size={12} /> Shorts · {shortIdx + 1}/{shortsVideos.length}
                    </span>
                    <button
                      type="button"
                      onClick={() => void openWatch(cur, false)}
                      className="btn-aurora pressable !py-1.5 !px-3"
                    >
                      <Icon id="play" size={12} /> {t("تشغيل", "Play")}
                    </button>
                  </div>

                  <div className="absolute bottom-4 inset-inline-start-4 end-16 space-y-2 text-white">
                    <div className="flex items-center gap-2">
                      <span className="text-[12px] font-bold">{cur.channelName}</span>
                      <button
                        type="button"
                        onClick={() =>
                          toggleFollow({
                            channelId: cur.channelId || cur.channelName,
                            name: cur.channelName,
                            avatar: cur.channelAvatar,
                            followedAt: Date.now(),
                          })
                        }
                        className={`pill pressable ${isFol ? "active" : ""}`}
                      >
                        {isFol ? t("متابَع", "Following") : t("متابعة", "Follow")}
                      </button>
                    </div>
                    <div className="text-[12.5px] font-semibold leading-snug">{cur.title}</div>
                  </div>

                  <div className="absolute bottom-4 inset-inline-end-3 flex flex-col gap-2.5">
                    <button
                      type="button"
                      onClick={() => setShortIdx((i) => (i > 0 ? i - 1 : shortsVideos.length - 1))}
                      className="btn-glass !p-2.5 !rounded-full text-white"
                      title="Previous Short"
                    >
                      ▲
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (shortIdx + 2 >= shortsVideos.length) void loadShorts();
                        setShortIdx((i) => i + 1);
                      }}
                      className="btn-glass !p-2.5 !rounded-full text-white"
                      title="Next Short"
                    >
                      ▼
                    </button>
                    <button
                      type="button"
                      onClick={() => toggleLike(cur)}
                      className="btn-glass !p-2.5 !rounded-full text-white"
                      title="Like"
                    >
                      <Icon id="heart" size={16} />
                    </button>
                    <button
                      type="button"
                      onClick={() => void openDownloadPicker(cur)}
                      className="btn-aurora !p-2.5 !rounded-full"
                      title="Download Short"
                    >
                      <Icon id="download" size={16} />
                    </button>
                    <button
                      type="button"
                      onClick={() => copyVideoLink(cur)}
                      className="btn-glass !p-2.5 !rounded-full text-white"
                      title="Copy Link"
                    >
                      <Icon id="copy" size={16} />
                    </button>
                  </div>
                </div>
              );
            })()
          )}
        </div>
      ) : view === "subs" ? (
        <div className="space-y-3">
          {profile.followedChannels.length === 0 ? (
            <div className="glass-panel p-5 text-center space-y-2">
              <div className="text-[13px] font-bold">
                {t("لا توجد قنوات متابَعة محلياً بعد", "No Locally Followed Channels Yet")}
              </div>
              <p className="text-[11px] text-[var(--muted)] m-0">
                {t("اضغط زر «+ متابعة» تحت أي فيديو لمتابعة صانع المحتوى محلياً بدون أي حساب رسمي!", "Tap '+ Follow' on any video card to subscribe locally without any Google account!")}
              </p>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
                {profile.followedChannels.map((ch) => (
                  <button
                    key={ch.channelId}
                    type="button"
                    onClick={() => toggleFollow(ch)}
                    className="pill active pressable"
                    title={t("اضغط لإلغاء المتابعة", "Tap to unfollow")}
                  >
                    {ch.name} ✕
                  </button>
                ))}
              </div>
              {subsVideos.map(renderVideoCard)}
            </>
          )}
        </div>
      ) : (
        /* My Standalone Local Profile View (Export/Import JSON, History, Playlists, Likes) */
        <div className="space-y-3">
          <div className="glass-panel p-4 space-y-3">
            <div className="flex items-center gap-3">
              <span className="w-12 h-12 rounded-2xl grid place-items-center text-white font-extrabold text-[18px]" style={{ background: "linear-gradient(135deg, var(--a1), var(--a2))" }}>
                {profile.displayName.slice(0, 1).toUpperCase()}
              </span>
              <div className="flex-1 min-w-0">
                <div className="text-[14px] font-extrabold">{profile.displayName}</div>
                <div className="text-[11px] text-[var(--a1)] mono ltr">{profile.handle}</div>
                <div className="text-[10px] text-[var(--muted)]">
                  {t("ملف شخصي محلي بالكامل · بدون حساب جوجل", "100% Local Profile · No Google Login")}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="glass-subtle p-2">
                <div className="text-[14px] font-extrabold grad-text">{profile.followedChannels.length}</div>
                <div className="text-[9.5px] text-[var(--muted)]">{t("متابَعون", "Following")}</div>
              </div>
              <div className="glass-subtle p-2">
                <div className="text-[14px] font-extrabold grad-text">{profile.likedVideos.length}</div>
                <div className="text-[9.5px] text-[var(--muted)]">{t("إعجابات", "Liked")}</div>
              </div>
              <div className="glass-subtle p-2">
                <div className="text-[14px] font-extrabold grad-text">{profile.watchHistory.length}</div>
                <div className="text-[9.5px] text-[var(--muted)]">{t("السجل", "Watched")}</div>
              </div>
            </div>

            <div className="space-y-2">
              <input
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder={t("الاسم المعروض", "Display Name")}
                className="w-full glass-subtle px-3 py-2 text-[12px]"
              />
              <input
                value={editHandle}
                onChange={(e) => setEditHandle(e.target.value)}
                placeholder="@handle"
                className="w-full glass-subtle px-3 py-2 text-[12px] mono ltr"
              />
              <input
                value={editBio}
                onChange={(e) => setEditBio(e.target.value)}
                placeholder={t("نبذة شخصية محلية...", "Local bio...")}
                className="w-full glass-subtle px-3 py-2 text-[12px]"
              />
              <button
                type="button"
                onClick={() => {
                  setProfile((p) => ({
                    ...p,
                    displayName: editName.trim() || "JoDon Member",
                    handle: editHandle.startsWith("@") ? editHandle.trim() : `@${editHandle.trim()}`,
                    bio: editBio.trim(),
                  }));
                  onToast(t("تم حفظ ملفك الشخصي محلياً", "Local profile saved"));
                }}
                className="btn-aurora pressable w-full"
              >
                <Icon id="check" size={14} /> {t("حفظ بيانات الحساب المحلي", "Save Local Profile")}
              </button>
            </div>

            <div className="flex gap-2">
              <button type="button" onClick={exportProfileJson} className="btn-glass pressable flex-1">
                <Icon id="share" size={14} /> {t("تصدير الحساب (JSON)", "Export JSON")}
              </button>
              <button
                type="button"
                onClick={() => importInputRef.current?.click()}
                className="btn-glass pressable flex-1"
              >
                <Icon id="upload" size={14} /> {t("استيراد حساب (JSON)", "Import JSON")}
              </button>
              <input
                ref={importInputRef}
                type="file"
                accept="application/json,.json"
                className="hidden"
                onChange={(e) => void importProfileJson(e.target.files?.[0])}
              />
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setProfile((p) => ({ ...p, historyPaused: !p.historyPaused }))}
                className="btn-glass pressable flex-1"
              >
                {profile.historyPaused ? t("استئناف سجل المشاهدة", "Resume History") : t("إيقاف السجل مؤقتاً", "Pause History")}
              </button>
              <button
                type="button"
                onClick={() => setProfile((p) => ({ ...p, watchHistory: [], searchHistory: [] }))}
                className="btn-glass pressable flex-1"
              >
                <Icon id="trash" size={13} /> {t("مسح السجل", "Clear History")}
              </button>
            </div>
          </div>

          {profile.playlists.length > 0 && (
            <div className="space-y-2">
              <div className="text-[12.5px] font-bold">{t("قوائم التشغيل المحلية", "Local Playlists")}</div>
              {profile.playlists.map((pl) => (
                <div key={pl.id} className="glass-panel p-3">
                  <div className="text-[12px] font-bold">{pl.name} ({pl.videos.length})</div>
                </div>
              ))}
            </div>
          )}

          {profile.watchHistory.length > 0 && (
            <div className="space-y-2">
              <div className="text-[12.5px] font-bold">{t("سجل المشاهدة المحلي", "Local Watch History")}</div>
              {profile.watchHistory.slice(0, 10).map(renderVideoCard)}
            </div>
          )}
        </div>
      )}

      {/* Download Format Sheet for Any YouTube Video */}
      {dlModalVideo && (
        <>
          <div className="sheet-overlay" onClick={() => setDlModalVideo(null)} />
          <div className="bottom-sheet">
            <div className="w-11 h-1 rounded-full bg-[var(--border-lit)] mx-auto mb-3" />
            <div className="flex items-center justify-between mb-2">
              <div className="text-[13.5px] font-bold truncate pe-2">{dlModalVideo.title}</div>
              <button type="button" onClick={() => setDlModalVideo(null)} className="btn-glass !p-1.5">
                <Icon id="close" size={14} />
              </button>
            </div>
            <div className="overflow-y-auto no-scrollbar space-y-2">
              {dlLoading ? (
                <div className="py-6 text-center text-[12px] text-[var(--muted)]">
                  {t("جارٍ استخراج جميع الصيغ والجودات الحقيقية...", "Extracting real video & audio formats...")}
                </div>
              ) : dlFormats.length === 0 ? (
                <div className="py-4 text-center text-[11.5px] text-[var(--muted)]">
                  {t("تعذر جلب الروابط المباشرة من الخادم الوسيط حالياً؛ يمكنك نسخ الرابط لتحميله عبر محرك APK.", "Direct stream CORS blocked right now; copy the link or use APK yt-dlp engine.")}
                </div>
              ) : (
                dlFormats.map((fmt) => (
                  <div key={fmt.id} className="glass-subtle p-2.5 flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="text-[11.5px] font-bold">
                        {fmt.quality} · {fmt.container} · {fmt.codec}
                      </div>
                      <div className="text-[10px] text-[var(--muted)] mono">
                        {fmt.bitrateText}
                        {fmt.bytes > 0 ? ` · ${fmt.exact ? "" : "≈ "}${formatBytes(fmt.bytes)}` : ""}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        onStartDownload(`${dlModalVideo.title}.${fmt.container.toLowerCase()}`, fmt);
                        setDlModalVideo(null);
                      }}
                      className="btn-aurora pressable !py-1.5 !px-3"
                    >
                      <Icon id="download" size={13} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </>
      )}

      {/* Add to Local YouTube Playlist Sheet */}
      {playlistModalVideo && (
        <>
          <div className="sheet-overlay" onClick={() => setPlaylistModalVideo(null)} />
          <div className="bottom-sheet space-y-2.5">
            <div className="text-[13.5px] font-bold">{t("حفظ في قائمة تشغيل محلية", "Save to Local Playlist")}</div>
            <div className="flex gap-2">
              <input
                value={newPlaylistName}
                onChange={(e) => setNewPlaylistName(e.target.value)}
                placeholder={t("اسم قائمة جديدة...", "New playlist name...")}
                className="flex-1 glass-subtle px-3 py-2 text-[12px]"
              />
              <button
                type="button"
                onClick={() => {
                  const name = newPlaylistName.trim();
                  if (!name) return;
                  setProfile((p) => ({
                    ...p,
                    playlists: [
                      { id: `pl-${Date.now()}`, name, videos: [playlistModalVideo], createdAt: Date.now() },
                      ...p.playlists,
                    ],
                  }));
                  setNewPlaylistName("");
                  setPlaylistModalVideo(null);
                  onToast(t("تم الإنشاء والإضافة", "Created & added"));
                }}
                className="btn-aurora pressable"
              >
                {t("إنشاء", "Create")}
              </button>
            </div>
            {profile.playlists.map((pl) => (
              <button
                key={pl.id}
                type="button"
                onClick={() => {
                  setProfile((p) => ({
                    ...p,
                    playlists: p.playlists.map((x) =>
                      x.id !== pl.id
                        ? x
                        : {
                            ...x,
                            videos: [
                              playlistModalVideo,
                              ...x.videos.filter((v) => v.videoId !== playlistModalVideo.videoId),
                            ],
                          }
                    ),
                  }));
                  setPlaylistModalVideo(null);
                  onToast(t(`أُضيف إلى ${pl.name}`, `Added to ${pl.name}`));
                }}
                className="w-full glass-subtle p-2.5 text-start text-[12px] font-bold"
              >
                {pl.name} ({pl.videos.length})
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
