/**
 * Real Web Audio API Studio Engine:
 * - Decodes real audio waveforms from uploaded video/audio files for the Visual Manual Trimmer
 * - Captures real video frame filmstrip thumbnails onto Canvas
 * - Encodes sample-accurate trimmed audio slices into downloadable .wav / .m4r Ringtone files
 * - Connects HTMLMediaElement to 5-band BiquadFilter Equalizer + Bass Boost + 60fps FFT Analyser
 */

const EQ_FREQS = [60, 230, 910, 3600, 14000];

export interface WebAudioRig {
  ctx: AudioContext;
  analyser: AnalyserNode;
  filters: BiquadFilterNode[];
  bassFilter: BiquadFilterNode;
  masterGain: GainNode;
}

const connectedElements = new WeakMap<HTMLMediaElement, WebAudioRig>();

export function attachMediaAudioRig(mediaEl: HTMLMediaElement): WebAudioRig | null {
  const existing = connectedElements.get(mediaEl);
  if (existing) return existing;
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AudioCtx();
    const source = ctx.createMediaElementSource(mediaEl);

    const bassFilter = ctx.createBiquadFilter();
    bassFilter.type = "lowshelf";
    bassFilter.frequency.value = 110;
    bassFilter.gain.value = 0;

    const filters = EQ_FREQS.map((freq) => {
      const f = ctx.createBiquadFilter();
      f.type = "peaking";
      f.frequency.value = freq;
      f.Q.value = 1.1;
      f.gain.value = 0;
      return f;
    });

    const masterGain = ctx.createGain();
    masterGain.gain.value = 1;

    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;
    analyser.smoothingTimeConstant = 0.78;

    let head: AudioNode = source;
    head.connect(bassFilter);
    head = bassFilter;
    for (const f of filters) {
      head.connect(f);
      head = f;
    }
    head.connect(masterGain);
    masterGain.connect(analyser);
    analyser.connect(ctx.destination);

    const rig: WebAudioRig = { ctx, analyser, filters, bassFilter, masterGain };
    connectedElements.set(mediaEl, rig);
    return rig;
  } catch {
    return null;
  }
}

export async function decodeRealWaveform(
  file: File | undefined,
  buckets = 84
): Promise<{ peaks: number[]; audioBuffer: AudioBuffer | null }> {
  if (!file) return { peaks: [], audioBuffer: null };
  try {
    const arrayBuffer = await file.arrayBuffer();
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const offlineCtx = new AudioCtx();
    const decoded = await offlineCtx.decodeAudioData(arrayBuffer.slice(0));
    const channelData = decoded.getChannelData(0);
    const blockSize = Math.max(1, Math.floor(channelData.length / buckets));
    const peaks: number[] = [];
    let maxVal = 0.01;
    for (let i = 0; i < buckets; i++) {
      const start = i * blockSize;
      let sum = 0;
      const count = Math.min(blockSize, 1200);
      const stride = Math.max(1, Math.floor(blockSize / count));
      let samples = 0;
      for (let j = 0; j < blockSize && start + j < channelData.length; j += stride) {
        sum += Math.abs(channelData[start + j]);
        samples++;
      }
      const avg = samples > 0 ? sum / samples : 0.05;
      if (avg > maxVal) maxVal = avg;
      peaks.push(avg);
    }
    void offlineCtx.close();
    return {
      peaks: peaks.map((p) => Math.max(0.08, Math.min(1, p / maxVal))),
      audioBuffer: decoded,
    };
  } catch {
    return { peaks: [], audioBuffer: null };
  }
}

export async function extractVideoFilmstrip(videoUrl: string, count = 7): Promise<string[]> {
  return new Promise((resolve) => {
    const vid = document.createElement("video");
    vid.src = videoUrl;
    vid.muted = true;
    vid.playsInline = true;
    vid.preload = "metadata";
    const frames: string[] = [];
    const canvas = document.createElement("canvas");
    canvas.width = 120;
    canvas.height = 68;
    const ctx = canvas.getContext("2d");

    const timeout = window.setTimeout(() => resolve(frames), 4500);

    vid.onloadedmetadata = async () => {
      const dur = vid.duration;
      if (!Number.isFinite(dur) || dur <= 0 || !ctx) {
        window.clearTimeout(timeout);
        resolve([]);
        return;
      }
      for (let i = 0; i < count; i++) {
        const targetTime = ((i + 0.5) / count) * dur;
        await new Promise<void>((r) => {
          const onSeek = () => {
            vid.removeEventListener("seeked", onSeek);
            ctx.drawImage(vid, 0, 0, canvas.width, canvas.height);
            frames.push(canvas.toDataURL("image/jpeg", 0.65));
            r();
          };
          vid.addEventListener("seeked", onSeek);
          vid.currentTime = targetTime;
        });
      }
      window.clearTimeout(timeout);
      vid.src = "";
      resolve(frames);
    };
    vid.onerror = () => {
      window.clearTimeout(timeout);
      resolve([]);
    };
  });
}

/** Encodes a trimmed [startSec..endSec] slice of an AudioBuffer into a real 16-bit PCM WAV Blob. */
export function encodeTrimmedWavBlob(
  buffer: AudioBuffer,
  startSec: number,
  endSec: number
): Blob {
  const sampleRate = buffer.sampleRate;
  const numChannels = Math.min(2, buffer.numberOfChannels);
  const startSample = Math.max(0, Math.floor(startSec * sampleRate));
  const endSample = Math.min(buffer.length, Math.ceil(endSec * sampleRate));
  const frameCount = Math.max(1, endSample - startSample);
  const bytesPerSample = 2;
  const blockAlign = numChannels * bytesPerSample;
  const dataByteLength = frameCount * blockAlign;
  const out = new ArrayBuffer(44 + dataByteLength);
  const view = new DataView(out);

  const writeStr = (offset: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(offset + i, s.charCodeAt(i));
  };

  writeStr(0, "RIFF");
  view.setUint32(4, 36 + dataByteLength, true);
  writeStr(8, "WAVE");
  writeStr(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true);
  writeStr(36, "data");
  view.setUint32(40, dataByteLength, true);

  const channels: Float32Array[] = [];
  for (let c = 0; c < numChannels; c++) {
    channels.push(buffer.getChannelData(c));
  }

  let offset = 44;
  for (let i = 0; i < frameCount; i++) {
    const idx = startSample + i;
    for (let c = 0; c < numChannels; c++) {
      const sample = Math.max(-1, Math.min(1, channels[c][idx] || 0));
      view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
      offset += 2;
    }
  }
  return new Blob([out], { type: "audio/wav" });
}
