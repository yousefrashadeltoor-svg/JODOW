import { useEffect, useRef, useState } from "react";
import {
  attachMediaAudioRig,
  decodeRealWaveform,
  encodeTrimmedWavBlob,
  extractVideoFilmstrip,
} from "./audioEngine";
import type { WebAudioRig } from "./audioEngine";
import { Icon } from "./Icons";
import type {
  Lang,
  LocalMusicPlaylist,
  LocalTrack,
  RepeatKind,
  VisualizerStyle,
} from "./types";
import { formatBytes, formatClock } from "./types";

interface PlayerProps {
  lang: Lang;
  tracks: LocalTrack[];
  currentIndex: number;
  setCurrentIndex: (idx: number) => void;
  songMode: boolean;
  setSongMode: (v: boolean) => void;
  visualizerStyle: VisualizerStyle;
  setVisualizerStyle: (s: VisualizerStyle) => void;
  onImportFiles: (files: FileList | null) => void;
  onAddGeneratedTrack: (track: LocalTrack) => void;
  onToast: (msg: string) => void;
}

export function LuxuryPlayerView({
  lang,
  tracks,
  currentIndex,
  setCurrentIndex,
  songMode,
  setSongMode,
  visualizerStyle,
  setVisualizerStyle,
  onImportFiles,
  onAddGeneratedTrack,
  onToast,
}: PlayerProps) {
  const t = (ar: string, en: string) => (lang === "ar" ? ar : en);
  const current = tracks[currentIndex] || null;

  const mediaRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const trimBoxRef = useRef<HTMLDivElement | null>(null);
  const filePickerRef = useRef<HTMLInputElement | null>(null);
  const rigRef = useRef<WebAudioRig | null>(null);

  const [playing, setPlaying] = useState(false);
  const [curTime, setCurTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [repeat, setRepeat] = useState<RepeatKind>("off");
  const [shuffle, setShuffle] = useState(false);
  const [loopA, setLoopA] = useState<number | null>(null);
  const [loopB, setLoopB] = useState<number | null>(null);
  const [speed, setSpeed] = useState(1);
  const [preservePitch, setPreservePitch] = useState(true);
  const [locked, setLocked] = useState(false);
  const [fitCover, setFitCover] = useState(false);

  const [sleepSec, setSleepSec] = useState<number | null>(null);
  const [sleepEndOfTrack, setSleepEndOfTrack] = useState(false);

  const [eqGains, setEqGains] = useState<number[]>([0, 0, 0, 0, 0]);
  const [bassGain, setBassGain] = useState(0);

  const [activeSheet, setActiveSheet] = useState<null | "trim" | "sleep" | "eq">(null);
  const [peaks, setPeaks] = useState<number[]>([]);
  const [filmstrip, setFilmstrip] = useState<string[]>([]);
  const [decodedBuffer, setDecodedBuffer] = useState<AudioBuffer | null>(null);
  const [trimStart, setTrimStart] = useState(0.08);
  const [trimEnd, setTrimEnd] = useState(0.88);
  const [draggingHandle, setDraggingHandle] = useState<null | "start" | "end" | "scrub">(null);

  // Decode real waveform & video filmstrip whenever current local track changes
  useEffect(() => {
    let cancelled = false;
    setPeaks([]);
    setFilmstrip([]);
    setDecodedBuffer(null);
    setLoopA(null);
    setLoopB(null);
    setTrimStart(0.08);
    setTrimEnd(0.9);
    if (!current) return;

    void decodeRealWaveform(current.file, 80).then((res) => {
      if (cancelled) return;
      setPeaks(res.peaks);
      setDecodedBuffer(res.audioBuffer);
    });

    if (current.isVideo) {
      void extractVideoFilmstrip(current.url, 6).then((frames) => {
        if (!cancelled) setFilmstrip(frames);
      });
    }
    return () => {
      cancelled = true;
    };
  }, [current]);

  // Apply playback rate & pitch preservation
  useEffect(() => {
    const el = mediaRef.current;
    if (!el) return;
    el.playbackRate = speed;
    (el as HTMLVideoElement & { preservesPitch?: boolean }).preservesPitch = preservePitch;
  }, [speed, preservePitch, current]);

  // Apply 5-band Equalizer & Bass Boost gains
  useEffect(() => {
    const rig = rigRef.current;
    if (!rig) return;
    rig.bassFilter.gain.value = bassGain;
    eqGains.forEach((g, idx) => {
      if (rig.filters[idx]) rig.filters[idx].gain.value = g;
    });
  }, [eqGains, bassGain]);

  // Sleep Timer Countdown + Smooth 10s Gain Fade-out
  useEffect(() => {
    if (sleepSec === null) {
      if (rigRef.current) rigRef.current.masterGain.gain.value = 1;
      return;
    }
    const id = window.setInterval(() => {
      setSleepSec((prev) => {
        if (prev === null) return null;
        if (prev <= 1) {
          mediaRef.current?.pause();
          if (rigRef.current) rigRef.current.masterGain.gain.value = 1;
          onToast(t("مؤقت النوم أوقف التشغيل تلقائياً", "Sleep timer paused playback"));
          return null;
        }
        if (prev <= 10 && rigRef.current) {
          rigRef.current.masterGain.gain.value = Math.max(0.05, (prev - 1) / 10);
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sleepSec]);

  // Real-time 60fps Canvas Audio Visualizer
  useEffect(() => {
    if (!current || (!songMode && current.isVideo)) return;
    let raf = 0;
    const freqData = new Uint8Array(128);
    const waveData = new Uint8Array(128);

    const render = () => {
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          const w = canvas.width;
          const h = canvas.height;
          ctx.clearRect(0, 0, w, h);

          const analyser = rigRef.current?.analyser;
          if (analyser && playing) {
            analyser.getByteFrequencyData(freqData);
            analyser.getByteTimeDomainData(waveData);
          } else {
            freqData.fill(16);
            waveData.fill(128);
          }

          const styles = getComputedStyle(canvas);
          const c1 = styles.getPropertyValue("--a1").trim() || "#4285f4";
          const c2 = styles.getPropertyValue("--a2").trim() || "#9b72cb";
          const c3 = styles.getPropertyValue("--a3").trim() || "#d96570";

          if (visualizerStyle === "bars") {
            const bars = 44;
            const step = w / bars;
            const grad = ctx.createLinearGradient(0, h, 0, 0);
            grad.addColorStop(0, c1);
            grad.addColorStop(0.55, c2);
            grad.addColorStop(1, c3);
            ctx.fillStyle = grad;
            for (let i = 0; i < bars; i++) {
              const v = (freqData[i * 2] || 14) / 255;
              const bh = Math.max(6, v * h * 0.82);
              const bw = Math.max(3, step * 0.62);
              ctx.beginPath();
              ctx.roundRect(i * step + (step - bw) / 2, h - bh - 10, bw, bh, 4);
              ctx.fill();
            }
          } else if (visualizerStyle === "wave") {
            const grad = ctx.createLinearGradient(0, 0, w, 0);
            grad.addColorStop(0, c1);
            grad.addColorStop(0.5, c2);
            grad.addColorStop(1, c3);
            ctx.strokeStyle = grad;
            ctx.lineWidth = 3.5;
            ctx.beginPath();
            for (let i = 0; i < waveData.length; i++) {
              const x = (i / (waveData.length - 1)) * w;
              const v = (waveData[i] - 128) / 128;
              const y = h / 2 + v * h * 0.38;
              if (i === 0) ctx.moveTo(x, y);
              else ctx.lineTo(x, y);
            }
            ctx.stroke();
          } else if (visualizerStyle === "orbit") {
            const cx = w / 2;
            const cy = h / 2;
            const baseR = Math.min(w, h) * 0.24;
            let avg = 0;
            for (let i = 0; i < 32; i++) avg += freqData[i];
            avg = avg / 32 / 255;
            ctx.strokeStyle = c2;
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.arc(cx, cy, baseR * (1 + avg * 0.55), 0, Math.PI * 2);
            ctx.stroke();
            const spokes = 48;
            ctx.strokeStyle = c1;
            for (let i = 0; i < spokes; i++) {
              const ang = (i / spokes) * Math.PI * 2;
              const amp = (freqData[i] || 12) / 255;
              const r2 = baseR + amp * baseR * 0.85;
              ctx.beginPath();
              ctx.moveTo(cx + Math.cos(ang) * baseR, cy + Math.sin(ang) * baseR);
              ctx.lineTo(cx + Math.cos(ang) * r2, cy + Math.sin(ang) * r2);
              ctx.stroke();
            }
          } else {
            ctx.fillStyle = c1;
            for (let i = 0; i < 40; i++) {
              const amp = (freqData[i * 2] || 18) / 255;
              const x = ((i * 67) % 100) * 0.01 * w;
              const y = h - amp * (h - 24) - 12;
              ctx.beginPath();
              ctx.arc(x, y, 2.5 + amp * 7, 0, Math.PI * 2);
              ctx.fill();
            }
          }
        }
      }
      raf = window.requestAnimationFrame(render);
    };
    raf = window.requestAnimationFrame(render);
    return () => window.cancelAnimationFrame(raf);
  }, [current, songMode, visualizerStyle, playing]);

  const ensureAudioRig = () => {
    const el = mediaRef.current;
    if (!el) return;
    if (!rigRef.current) {
      rigRef.current = attachMediaAudioRig(el);
    }
    if (rigRef.current?.ctx.state === "suspended") {
      void rigRef.current.ctx.resume();
    }
  };

  const togglePlay = () => {
    const el = mediaRef.current;
    if (!el) return;
    ensureAudioRig();
    if (el.paused) void el.play();
    else el.pause();
  };

  const goNext = () => {
    if (tracks.length === 0) return;
    const next = shuffle ? Math.floor(Math.random() * tracks.length) : (currentIndex + 1) % tracks.length;
    setCurrentIndex(next);
  };

  const goPrev = () => {
    if (tracks.length === 0) return;
    setCurrentIndex((currentIndex - 1 + tracks.length) % tracks.length);
  };

  const cycleRepeat = () => {
    const order: RepeatKind[] = ["off", "all", "one", "ab"];
    const next = order[(order.indexOf(repeat) + 1) % order.length];
    setRepeat(next);
  };

  const markAbLoop = () => {
    if (loopA === null || loopB !== null) {
      setLoopA(curTime);
      setLoopB(null);
      setRepeat("ab");
      onToast(t(`تم تحديد النقطة A عند ${formatClock(curTime)}`, `Point A set at ${formatClock(curTime)}`));
    } else if (curTime > loopA) {
      setLoopB(curTime);
      setRepeat("ab");
      onToast(t(`تكرار المقطع A–B مفعّل`, `A–B Loop active`));
    }
  };

  // Interactive Pointer Dragging on the Visual Waveform + Filmstrip Timeline
  const handleTrimPointer = (clientX: number, mode: "start" | "end" | "scrub") => {
    const box = trimBoxRef.current;
    if (!box) return;
    const rect = box.getBoundingClientRect();
    // Respect RTL visual direction or keep timeline strictly LTR for intuitive left=start, right=end
    const frac = Math.max(0, Math.min(1, (clientX - rect.left) / Math.max(1, rect.width)));
    if (mode === "start") {
      const clamped = Math.min(frac, trimEnd - 0.03);
      setTrimStart(clamped);
      if (mediaRef.current && duration > 0) mediaRef.current.currentTime = clamped * duration;
    } else if (mode === "end") {
      const clamped = Math.max(frac, trimStart + 0.03);
      setTrimEnd(clamped);
    } else {
      const clamped = Math.max(trimStart, Math.min(trimEnd, frac));
      if (mediaRef.current && duration > 0) mediaRef.current.currentTime = clamped * duration;
    }
  };

  const exportTrimmedAudioOrRingtone = (asRingtone: boolean) => {
    if (!current || !decodedBuffer || duration <= 0) {
      onToast(t("يرجى الانتظار ريثما يكتمل فك الموجة الصوتية للملف", "Decoding audio buffer, please wait a moment"));
      return;
    }
    const sSec = trimStart * duration;
    const eSec = trimEnd * duration;
    const wavBlob = encodeTrimmedWavBlob(decodedBuffer, sSec, eSec);
    const baseName = current.name.replace(/\.[^.]+$/, "");
    const ext = asRingtone ? "m4r.wav" : "wav";
    const fileName = `${baseName}_${asRingtone ? "ringtone" : "trimmed"}.${ext}`;
    const blobUrl = URL.createObjectURL(wavBlob);

    const a = document.createElement("a");
    a.href = blobUrl;
    a.download = fileName;
    a.click();

    onAddGeneratedTrack({
      id: `cut-${Date.now()}`,
      name: fileName,
      artist: asRingtone ? "JoDon Ringtone Studio" : current.artist,
      album: asRingtone ? "Ringtones" : "Trimmed Clips",
      folder: "Studio Cuts",
      url: blobUrl,
      file: new File([wavBlob], fileName, { type: "audio/wav" }),
      sizeBytes: wavBlob.size,
      durationSec: Math.max(1, eSec - sSec),
      isVideo: false,
      addedAt: Date.now(),
    });

    onToast(
      asRingtone
        ? t("تم قص النغمة وحفظها لتعيينها كنغمة رنين! (في نسخة APK تُعيَّن تلقائياً للنظام)", "Ringtone cut exported & added to library!")
        : t("تم حفظ المقطع المقصوص وإضافته لمكتبتك الصوتية", "Trimmed audio saved & added to your library")
    );
    setActiveSheet(null);
  };

  if (!current) {
    return (
      <div className="glass-panel p-6 text-center space-y-4 mt-2 spring-enter">
        <div
          className="w-20 h-20 rounded-[28px] mx-auto grid place-items-center text-white"
          style={{ background: "linear-gradient(135deg, var(--a1), var(--a2), var(--a3))" }}
        >
          <Icon id="player" size={34} />
        </div>
        <h2 className="m-0 text-[18px] font-extrabold">
          {t("المشغل المحلي الفاخر للفيديو والموسيقى", "Luxury Local Video & Music Player")}
        </h2>
        <p className="m-0 text-[11.5px] leading-relaxed text-[var(--muted)]">
          {t(
            "اختر أي ملفات فيديو أو أغاني من جهازك لتشغيلها بسلاسة بدون إنترنت، تحويل أي فيديو لأغنية، القص المرئي اليدوي بالسحب فوق الموجة الصوتية، صناعة نغمات الرنين، مؤقت النوم، ومعادل الصوت الحقيقي.",
            "Import any local video or audio files from your device for smooth offline playback, Play-as-Song mode, tactile visual waveform trimming, ringtone creation, sleep timer, and 5-band EQ."
          )}
        </p>
        <button
          type="button"
          onClick={() => filePickerRef.current?.click()}
          className="btn-aurora pressable w-full"
        >
          <Icon id="folder" size={16} /> {t("استيراد فيديوهات أو أغاني من جهازي", "Open Local Videos & Songs")}
        </button>
        <input
          ref={filePickerRef}
          type="file"
          multiple
          accept="video/*,audio/*"
          className="hidden"
          onChange={(e) => onImportFiles(e.target.files)}
        />
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Top Status & Mode Strip */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setSongMode(!songMode)}
            className="pill active pressable"
          >
            <Icon id={songMode || !current.isVideo ? "music" : "video"} size={12} />
            {songMode || !current.isVideo ? t("وضع الأغنية", "Song Mode") : t("وضع الفيديو", "Video Mode")}
          </button>
          {sleepSec !== null && (
            <button type="button" onClick={() => setActiveSheet("sleep")} className="pill pressable">
              <Icon id="timer" size={11} /> {formatClock(sleepSec)}
            </button>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setLocked((v) => !v)}
            className={`btn-glass !p-2 ${locked ? "!border-[var(--a1)] !text-[var(--a1)]" : ""}`}
            title={t("قفل اللمس", "Lock Controls")}
          >
            <Icon id="lock" size={14} />
          </button>
          {current.isVideo && !songMode && (
            <button
              type="button"
              onClick={() => {
                if (mediaRef.current && document.pictureInPictureEnabled) {
                  void mediaRef.current.requestPictureInPicture();
                }
              }}
              className="btn-glass !p-2"
              title="Picture in Picture"
            >
              <Icon id="pip" size={14} />
            </button>
          )}
          <button
            type="button"
            onClick={() => filePickerRef.current?.click()}
            className="btn-glass !p-2"
            title={t("إضافة ملفات", "Add Files")}
          >
            <Icon id="plus" size={14} />
          </button>
          <input
            ref={filePickerRef}
            type="file"
            multiple
            accept="video/*,audio/*"
            className="hidden"
            onChange={(e) => onImportFiles(e.target.files)}
          />
        </div>
      </div>

      {/* Main Media Stage: Smooth Video OR Real-Time Audio Visualizer */}
      <div
        onDoubleClick={(e) => {
          if (locked || !mediaRef.current) return;
          const rect = e.currentTarget.getBoundingClientRect();
          const delta = e.clientX - rect.left < rect.width / 2 ? -10 : 10;
          mediaRef.current.currentTime = Math.max(0, Math.min(duration, mediaRef.current.currentTime + delta));
        }}
        className="relative w-full h-[242px] rounded-[26px] overflow-hidden border border-[var(--border)] bg-black/80"
      >
        <video
          ref={mediaRef}
          src={current.url}
          playsInline
          onPlay={() => {
            ensureAudioRig();
            setPlaying(true);
          }}
          onPause={() => setPlaying(false)}
          onLoadedMetadata={(e) => setDuration(e.currentTarget.duration || 0)}
          onTimeUpdate={(e) => {
            const tNow = e.currentTarget.currentTime;
            setCurTime(tNow);
            if (repeat === "ab" && loopA !== null && loopB !== null && tNow >= loopB) {
              e.currentTarget.currentTime = loopA;
            }
            if (activeSheet === "trim" && duration > 0 && tNow > trimEnd * duration) {
              e.currentTarget.currentTime = trimStart * duration;
            }
          }}
          onEnded={() => {
            if (sleepEndOfTrack) {
              setSleepEndOfTrack(false);
              setPlaying(false);
              onToast(t("توقف المشغل بعد انتهاء المقطع", "Stopped at end of track"));
              return;
            }
            if (repeat === "one" && mediaRef.current) {
              mediaRef.current.currentTime = 0;
              void mediaRef.current.play();
            } else if (repeat === "all" || currentIndex < tracks.length - 1) {
              goNext();
            }
          }}
          className={`w-full h-full ${fitCover ? "object-cover" : "object-contain"} ${
            songMode || !current.isVideo ? "opacity-0 pointer-events-none absolute" : ""
          }`}
        />

        {(songMode || !current.isVideo) && (
          <div className="absolute inset-0 flex flex-col items-center justify-between p-4">
            <div className="w-full flex items-center justify-between">
              <span className="pill">
                <Icon id="waveform" size={12} /> {visualizerStyle.toUpperCase()}
              </span>
              <button
                type="button"
                onClick={() => {
                  const list: VisualizerStyle[] = ["bars", "wave", "orbit", "particles"];
                  setVisualizerStyle(list[(list.indexOf(visualizerStyle) + 1) % list.length]);
                }}
                className="btn-glass pressable !py-1 !px-2.5 !text-[10px]"
              >
                {t("تغيير التأثير البصري", "Switch Visualizer")}
              </button>
            </div>
            <canvas ref={canvasRef} width={380} height={160} className="w-full h-[155px]" />
          </div>
        )}
      </div>

      {/* Track Title, Timeline & Transport Controls */}
      <div className="glass-panel p-3.5 space-y-2.5">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="text-[14px] font-extrabold truncate">{current.name}</div>
            <div className="text-[10.5px] text-[var(--muted)]">
              {current.artist} · {formatBytes(current.sizeBytes)}
            </div>
          </div>
          {current.isVideo && (
            <button
              type="button"
              onClick={() => setSongMode(!songMode)}
              className="btn-glass pressable !py-1.5 !px-2.5 shrink-0"
            >
              <Icon id="music" size={13} />
              {songMode ? t("إظهار الفيديو", "Show Video") : t("تشغيل كأغنية", "Play as Song")}
            </button>
          )}
        </div>

        <input
          type="range"
          min={0}
          max={Math.max(1, duration)}
          step={0.1}
          value={curTime}
          disabled={locked}
          onChange={(e) => {
            const val = Number(e.target.value);
            setCurTime(val);
            if (mediaRef.current) mediaRef.current.currentTime = val;
          }}
          className="w-full jodon-range ltr"
        />

        <div className="flex items-center justify-between text-[10.5px] text-[var(--muted)] mono">
          <span>{formatClock(curTime)}</span>
          {loopA !== null && (
            <span className="text-[var(--a1)] font-bold">
              A {formatClock(loopA)} → B {loopB !== null ? formatClock(loopB) : "..."}
            </span>
          )}
          <span>{formatClock(duration)}</span>
        </div>

        {!locked && (
          <div className="flex items-center justify-between gap-1.5 pt-1">
            <button
              type="button"
              onClick={cycleRepeat}
              className={`pill pressable ${repeat !== "off" ? "active" : ""}`}
            >
              <Icon id="repeat" size={12} />
              {repeat === "off"
                ? t("بدون تكرار", "Off")
                : repeat === "all"
                ? t("الكل", "All")
                : repeat === "one"
                ? "1×"
                : "A–B"}
            </button>

            <div className="flex items-center gap-2">
              <button type="button" onClick={goPrev} className="btn-glass pressable !p-2.5">
                <Icon id="prev" size={15} />
              </button>
              <button type="button" onClick={togglePlay} className="btn-aurora pressable !px-5 !py-2.5">
                <Icon id={playing ? "pause" : "play"} size={17} />
              </button>
              <button type="button" onClick={goNext} className="btn-glass pressable !p-2.5">
                <Icon id="next" size={15} />
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShuffle((s) => !s)}
              className={`pill pressable ${shuffle ? "active" : ""}`}
            >
              {t("خلط", "Shuffle")}
            </button>
          </div>
        )}
      </div>

      {/* Studio Pro Action Grid: Visual Trimmer, Ringtone, A-B Loop, Sleep Timer, EQ */}
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => setActiveSheet("trim")}
          className="glass-panel p-3 flex items-center gap-2.5 pressable text-start col-span-2"
        >
          <span className="w-9 h-9 rounded-2xl grid place-items-center text-white shrink-0" style={{ background: "linear-gradient(135deg, var(--a1), var(--a2))" }}>
            <Icon id="scissors" size={17} />
          </span>
          <div className="min-w-0 flex-1">
            <div className="text-[12px] font-bold">
              {t("القص المرئي اليدوي + جعل كنغمة رنين", "Visual Manual Trimmer & Ringtone Studio")}
            </div>
            <div className="text-[10px] text-[var(--muted)]">
              {t("اسحب المقابض يدوياً فوق الموجة وشريط اللقطات بدون كتابة أرقام", "Drag handles over real waveform & filmstrip frames")}
            </div>
          </div>
        </button>

        <button type="button" onClick={markAbLoop} className="btn-glass pressable">
          <Icon id="repeat" size={14} /> {t("تحديد تكرار A–B", "Mark A–B Loop")}
        </button>
        <button type="button" onClick={() => setActiveSheet("sleep")} className="btn-glass pressable">
          <Icon id="timer" size={14} /> {t("مؤقت النوم", "Sleep Timer")}
        </button>
        <button type="button" onClick={() => setActiveSheet("eq")} className="btn-glass pressable">
          <Icon id="sliders" size={14} /> {t("معادل الصوت والسرعة", "5-Band EQ & Speed")}
        </button>
        {current.isVideo && !songMode ? (
          <button type="button" onClick={() => setFitCover((v) => !v)} className="btn-glass pressable">
            <Icon id="video" size={14} /> {fitCover ? t("احتواء (Fit)", "Fit") : t("ملء (Fill)", "Fill")}
          </button>
        ) : (
          <button
            type="button"
            onClick={() => {
              const list: VisualizerStyle[] = ["bars", "wave", "orbit", "particles"];
              setVisualizerStyle(list[(list.indexOf(visualizerStyle) + 1) % list.length]);
            }}
            className="btn-glass pressable"
          >
            <Icon id="sparkles" size={14} /> {t("تأثير بصري", "Visualizer")}
          </button>
        )}
      </div>

      {/* Visual Manual Trimmer & Ringtone Sheet */}
      {activeSheet === "trim" && (
        <>
          <div className="sheet-overlay" onClick={() => setActiveSheet(null)} />
          <div className="bottom-sheet space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-[13.5px] font-extrabold">
                {t("القص المرئي اليدوي وصانع النغمات", "Visual Manual Trimmer & Ringtone Maker")}
              </div>
              <button type="button" onClick={() => setActiveSheet(null)} className="btn-glass !p-1.5">
                <Icon id="close" size={14} />
              </button>
            </div>
            <p className="m-0 text-[10.5px] text-[var(--muted)]">
              {t(
                "اسحب المقبض الأيسر (البداية) والمقبض الأيمن (النهاية) مباشرة بإصبعك أو المؤشر فوق الموجة الصوتية الحقيقية:",
                "Drag the left (Start) and right (End) handles directly across the real decoded waveform & filmstrip:"
              )}
            </p>

            {/* Tactile Visual Timeline (LTR coordinate space for left=start, right=end) */}
            <div
              ref={trimBoxRef}
              onPointerMove={(e) => {
                if (draggingHandle) handleTrimPointer(e.clientX, draggingHandle);
              }}
              onPointerUp={() => setDraggingHandle(null)}
              onPointerLeave={() => setDraggingHandle(null)}
              className="ltr relative w-full h-[108px] rounded-2xl overflow-hidden border border-[var(--border-lit)] bg-black/70 select-none touch-none"
            >
              {/* Optional Video Filmstrip Backdrop */}
              {filmstrip.length > 0 && (
                <div className="absolute inset-0 flex opacity-40">
                  {filmstrip.map((src, idx) => (
                    <img key={idx} src={src} alt="" className="flex-1 h-full object-cover" />
                  ))}
                </div>
              )}

              {/* Dimmed Unselected Regions */}
              <div
                className="absolute inset-y-0 left-0 bg-black/70 z-10"
                style={{ width: `${trimStart * 100}%` }}
              />
              <div
                className="absolute inset-y-0 right-0 bg-black/70 z-10"
                style={{ width: `${(1 - trimEnd) * 100}%` }}
              />

              {/* Highlighted Selected Window */}
              <div
                onPointerDown={(e) => {
                  setDraggingHandle("scrub");
                  handleTrimPointer(e.clientX, "scrub");
                }}
                className="absolute inset-y-0 border-y-2 border-[var(--a1)] bg-[var(--a1)]/15 z-10 cursor-ew-resize"
                style={{
                  left: `${trimStart * 100}%`,
                  width: `${(trimEnd - trimStart) * 100}%`,
                }}
              />

              {/* Real Decoded Audio Waveform Bars */}
              <div className="absolute inset-0 flex items-center justify-between px-1 gap-[2px] pointer-events-none z-10">
                {(peaks.length > 0 ? peaks : Array.from({ length: 64 }, (_, i) => 0.25 + 0.45 * Math.abs(Math.sin(i * 0.3)))).map(
                  (amp, i, arr) => {
                    const pos = i / arr.length;
                    const active = pos >= trimStart && pos <= trimEnd;
                    return (
                      <span
                        key={i}
                        className="flex-1 rounded-full transition-colors"
                        style={{
                          height: `${Math.max(10, amp * 82)}%`,
                          background: active ? "var(--a1)" : "rgba(255,255,255,0.22)",
                        }}
                      />
                    );
                  }
                )}
              </div>

              {/* Live Playhead */}
              {duration > 0 && (
                <div
                  className="absolute inset-y-0 w-[2px] bg-white shadow-[0_0_8px_#fff] z-20 pointer-events-none"
                  style={{ left: `${Math.min(100, (curTime / duration) * 100)}%` }}
                />
              )}

              {/* Left Draggable Tactile Start Handle */}
              <div
                onPointerDown={(e) => {
                  e.stopPropagation();
                  e.currentTarget.setPointerCapture(e.pointerId);
                  setDraggingHandle("start");
                }}
                className="absolute inset-y-0 w-4 -ml-2 bg-[var(--a1)] rounded-md z-30 cursor-ew-resize grid place-items-center shadow-lg"
                style={{ left: `${trimStart * 100}%` }}
              >
                <span className="w-1 h-7 rounded-full bg-white" />
              </div>

              {/* Right Draggable Tactile End Handle */}
              <div
                onPointerDown={(e) => {
                  e.stopPropagation();
                  e.currentTarget.setPointerCapture(e.pointerId);
                  setDraggingHandle("end");
                }}
                className="absolute inset-y-0 w-4 -ml-2 bg-[var(--a3)] rounded-md z-30 cursor-ew-resize grid place-items-center shadow-lg"
                style={{ left: `${trimEnd * 100}%` }}
              >
                <span className="w-1 h-7 rounded-full bg-white" />
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] mono">
              <span className="pill active">{formatClock(trimStart * duration)}</span>
              <span className="text-[var(--muted)]">
                {t("مدة المقطع", "Cut Length")}: {formatClock(Math.max(0, (trimEnd - trimStart) * duration))}
              </span>
              <span className="pill active">{formatClock(trimEnd * duration)}</span>
            </div>

            <button
              type="button"
              onClick={() => {
                if (mediaRef.current && duration > 0) {
                  mediaRef.current.currentTime = trimStart * duration;
                  void mediaRef.current.play();
                }
              }}
              className="btn-glass pressable w-full"
            >
              <Icon id="play" size={14} /> {t("معاينة المقطع المحدد الآن", "Loop-Preview Selected Cut")}
            </button>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => exportTrimmedAudioOrRingtone(false)}
                className="btn-aurora pressable flex-1"
              >
                <Icon id="scissors" size={14} /> {t("قص وحفظ المقطع", "Save Trimmed Clip")}
              </button>
              <button
                type="button"
                onClick={() => exportTrimmedAudioOrRingtone(true)}
                className="btn-aurora pressable flex-1"
              >
                <Icon id="bell" size={14} /> {t("جعل كنغمة رنين", "Make Ringtone")}
              </button>
            </div>
          </div>
        </>
      )}

      {/* Sleep Timer Sheet */}
      {activeSheet === "sleep" && (
        <>
          <div className="sheet-overlay" onClick={() => setActiveSheet(null)} />
          <div className="bottom-sheet space-y-3">
            <div className="text-[13.5px] font-extrabold">
              {t("مؤقت النوم الذكي (خفوت صوت تدريجي)", "Smart Sleep Timer (Smooth Audio Fade)")}
            </div>
            <div className="grid grid-cols-5 gap-1.5">
              {[5, 15, 30, 45, 60].map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => {
                    setSleepSec(m * 60);
                    setSleepEndOfTrack(false);
                    setActiveSheet(null);
                    onToast(t(`تم ضبط مؤقت النوم على ${m} دقيقة`, `Sleep timer set for ${m} min`));
                  }}
                  className="btn-glass pressable !py-2"
                >
                  {m}m
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => {
                setSleepEndOfTrack(true);
                setSleepSec(null);
                setActiveSheet(null);
                onToast(t("سيتوقف التشغيل عند نهاية هذا المقطع", "Will pause at end of current track"));
              }}
              className="btn-aurora pressable w-full"
            >
              <Icon id="timer" size={14} /> {t("إيقاف عند نهاية المقطع الحالي", "Stop at End of Current Track")}
            </button>
            <button
              type="button"
              onClick={() => {
                setSleepSec(null);
                setSleepEndOfTrack(false);
                setActiveSheet(null);
              }}
              className="btn-glass pressable w-full"
            >
              {t("إلغاء المؤقت", "Cancel Sleep Timer")}
            </button>
          </div>
        </>
      )}

      {/* 5-Band Equalizer + Bass Boost + Speed / Nightcore / Slowed Sheet */}
      {activeSheet === "eq" && (
        <>
          <div className="sheet-overlay" onClick={() => setActiveSheet(null)} />
          <div className="bottom-sheet space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-[13.5px] font-extrabold">
                {t("معادل الصوت (5 نطاقات) والسرعة", "5-Band Web Audio Equalizer & Speed")}
              </div>
              <button
                type="button"
                onClick={() => {
                  setEqGains([0, 0, 0, 0, 0]);
                  setBassGain(0);
                  setSpeed(1);
                  setPreservePitch(true);
                }}
                className="text-[11px] text-[var(--a1)]"
              >
                {t("إعادة ضبط", "Reset")}
              </button>
            </div>
            {["60Hz", "230Hz", "910Hz", "3.6kHz", "14kHz"].map((freq, idx) => (
              <div key={freq} className="flex items-center gap-3">
                <span className="w-12 text-[10.5px] mono text-[var(--muted)]">{freq}</span>
                <input
                  type="range"
                  min={-12}
                  max={12}
                  step={0.5}
                  value={eqGains[idx]}
                  onChange={(e) => {
                    ensureAudioRig();
                    const next = [...eqGains];
                    next[idx] = Number(e.target.value);
                    setEqGains(next);
                  }}
                  className="flex-1 jodon-range ltr"
                />
                <span className="w-10 text-end text-[10px] mono">{eqGains[idx]}dB</span>
              </div>
            ))}
            <div className="flex items-center gap-3">
              <span className="w-12 text-[10.5px] font-bold">Bass</span>
              <input
                type="range"
                min={0}
                max={15}
                step={0.5}
                value={bassGain}
                onChange={(e) => {
                  ensureAudioRig();
                  setBassGain(Number(e.target.value));
                }}
                className="flex-1 jodon-range ltr"
              />
              <span className="w-10 text-end text-[10px] mono">+{bassGain}dB</span>
            </div>
            <div className="flex items-center gap-1.5 flex-wrap pt-1">
              <button
                type="button"
                onClick={() => {
                  setSpeed(1);
                  setPreservePitch(true);
                }}
                className={`pill pressable ${speed === 1 ? "active" : ""}`}
              >
                1.0× Normal
              </button>
              <button
                type="button"
                onClick={() => {
                  setSpeed(1.25);
                  setPreservePitch(false);
                }}
                className={`pill pressable ${speed === 1.25 && !preservePitch ? "active" : ""}`}
              >
                1.25× Nightcore
              </button>
              <button
                type="button"
                onClick={() => {
                  setSpeed(0.85);
                  setPreservePitch(false);
                }}
                className={`pill pressable ${speed === 0.85 && !preservePitch ? "active" : ""}`}
              >
                0.85× Slowed
              </button>
              <button
                type="button"
                onClick={() => {
                  setSpeed(1.5);
                  setPreservePitch(true);
                }}
                className={`pill pressable ${speed === 1.5 ? "active" : ""}`}
              >
                1.5× Fast
              </button>
              <button
                type="button"
                onClick={() => {
                  setSpeed(2);
                  setPreservePitch(true);
                }}
                className={`pill pressable ${speed === 2 ? "active" : ""}`}
              >
                2.0×
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

/* Dedicated Music & Local Media Library Pages */
interface MusicLibraryProps {
  lang: Lang;
  tracks: LocalTrack[];
  favorites: string[];
  toggleFavorite: (id: string) => void;
  playlists: LocalMusicPlaylist[];
  createPlaylist: (name: string) => void;
  addTrackToPlaylist: (plId: string, trackId: string) => void;
  onImportFiles: (files: FileList | null) => void;
  onPlayTrack: (index: number, asSong: boolean) => void;
}

export function MusicPagesView({
  lang,
  tracks,
  favorites,
  toggleFavorite,
  playlists,
  createPlaylist,
  addTrackToPlaylist,
  onImportFiles,
  onPlayTrack,
}: MusicLibraryProps) {
  const t = (ar: string, en: string) => (lang === "ar" ? ar : en);
  const pickerRef = useRef<HTMLInputElement | null>(null);
  const [page, setPage] = useState<"songs" | "videos" | "albums" | "artists" | "playlists">("songs");
  const [filter, setFilter] = useState("");
  const [newPl, setNewPl] = useState("");

  const songs = tracks.filter((x) => !x.isVideo);
  const videos = tracks.filter((x) => x.isVideo);
  const totalBytes = tracks.reduce((acc, x) => acc + x.sizeBytes, 0);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="m-0 text-[18px] font-extrabold grad-text">
            {t("صفحات الموسيقى والملفات المحلية", "Music Pages & Local Library")}
          </h2>
          <div className="text-[10.5px] text-[var(--muted)]">
            {songs.length} {t("أغنية", "Songs")} · {videos.length} {t("فيديو", "Videos")} · {formatBytes(totalBytes)}
          </div>
        </div>
        <button
          type="button"
          onClick={() => pickerRef.current?.click()}
          className="btn-aurora pressable !py-2 !px-3"
        >
          <Icon id="plus" size={14} /> {t("إضافة ملفات", "Add Media")}
        </button>
        <input
          ref={pickerRef}
          type="file"
          multiple
          accept="video/*,audio/*"
          className="hidden"
          onChange={(e) => onImportFiles(e.target.files)}
        />
      </div>

      {/* Music Pages Sub-Navigation */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
        {(
          [
            ["songs", t("الأغاني", "Songs")],
            ["videos", t("الفيديوهات", "Videos")],
            ["albums", t("الألبومات", "Albums")],
            ["artists", t("الفنانون", "Artists")],
            ["playlists", t("قوائم التشغيل والمفضلة", "Playlists & Favorites")],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setPage(id)}
            className={`pill pressable ${page === id ? "active" : ""}`}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="glass-subtle flex items-center gap-2 px-3 py-2 !rounded-full">
        <Icon id="search" size={14} className="text-[var(--muted)]" />
        <input
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder={t("ابحث في مكتبتك المحلية...", "Search your local library...")}
          className="flex-1 text-[12px]"
        />
      </div>

      {tracks.length === 0 ? (
        <div
          onClick={() => pickerRef.current?.click()}
          className="glass-panel p-6 text-center space-y-2.5 cursor-pointer pressable"
        >
          <Icon id="music" size={34} className="mx-auto text-[var(--a1)]" />
          <div className="text-[13px] font-bold">
            {t("مكتبتك المحلية جاهزة — اختر أو اسحب ملفاتك هنا", "Your Local Library is Ready — Pick or Drop Media Files")}
          </div>
          <p className="m-0 text-[11px] text-[var(--muted)]">
            {t("لا توجد أي أمثلة وهمية؛ أضف ملفات MP3, M4A, FLAC, WAV, MP4, MKV, WebM من جهازك لتشغيلها وقصها.", "Zero fake mock files. Pick real audio or video files from your device to play, organize, or cut ringtones.")}
          </p>
        </div>
      ) : page === "songs" || page === "videos" ? (
        <div className="space-y-2">
          {tracks
            .map((tr, globalIdx) => ({ tr, globalIdx }))
            .filter(({ tr }) => (page === "videos" ? tr.isVideo : true))
            .filter(({ tr }) => !filter || tr.name.toLowerCase().includes(filter.toLowerCase()))
            .map(({ tr, globalIdx }) => {
              const fav = favorites.includes(tr.id);
              return (
                <div key={tr.id} className="glass-panel p-3 flex items-center gap-2.5 spring-enter">
                  <button
                    type="button"
                    onClick={() => onPlayTrack(globalIdx, page === "songs")}
                    className="w-10 h-10 rounded-2xl grid place-items-center text-white shrink-0 pressable"
                    style={{ background: "linear-gradient(135deg, var(--a1), var(--a2))" }}
                  >
                    <Icon id={tr.isVideo && page === "videos" ? "video" : "music"} size={17} />
                  </button>
                  <div
                    onClick={() => onPlayTrack(globalIdx, page === "songs")}
                    className="flex-1 min-w-0 cursor-pointer"
                  >
                    <div className="text-[12px] font-bold truncate">{tr.name}</div>
                    <div className="text-[10px] text-[var(--muted)]">
                      {tr.artist} · {formatBytes(tr.sizeBytes)}
                    </div>
                  </div>
                  {tr.isVideo && (
                    <button
                      type="button"
                      onClick={() => onPlayTrack(globalIdx, true)}
                      className="pill pressable"
                      title={t("تشغيل كأغنية", "Play as Song")}
                    >
                      <Icon id="music" size={11} /> {t("كأغنية", "Song")}
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => toggleFavorite(tr.id)}
                    className={`btn-glass !p-2 ${fav ? "!text-rose-400" : ""}`}
                  >
                    <Icon id="heart" size={14} />
                  </button>
                  {playlists[0] && (
                    <button
                      type="button"
                      onClick={() => addTrackToPlaylist(playlists[0].id, tr.id)}
                      className="btn-glass !p-2"
                      title={`Add to ${playlists[0].name}`}
                    >
                      <Icon id="plus" size={14} />
                    </button>
                  )}
                </div>
              );
            })}
        </div>
      ) : page === "albums" ? (
        <div className="grid grid-cols-2 gap-2.5">
          {Object.entries(
            tracks.reduce<Record<string, LocalTrack[]>>((acc, tr) => {
              const k = tr.album || "Local Album";
              (acc[k] = acc[k] || []).push(tr);
              return acc;
            }, {})
          ).map(([album, list]) => (
            <div
              key={album}
              onClick={() => {
                const idx = tracks.findIndex((x) => x.id === list[0].id);
                if (idx >= 0) onPlayTrack(idx, true);
              }}
              className="glass-panel p-3.5 cursor-pointer pressable space-y-1.5"
            >
              <Icon id="music" size={22} className="text-[var(--a1)]" />
              <div className="text-[12px] font-bold truncate">{album}</div>
              <div className="text-[10px] text-[var(--muted)]">
                {list.length} {t("مقاطع", "tracks")}
              </div>
            </div>
          ))}
        </div>
      ) : page === "artists" ? (
        <div className="space-y-2">
          {Object.entries(
            tracks.reduce<Record<string, LocalTrack[]>>((acc, tr) => {
              const k = tr.artist || "Local Artist";
              (acc[k] = acc[k] || []).push(tr);
              return acc;
            }, {})
          ).map(([artist, list]) => (
            <div
              key={artist}
              onClick={() => {
                const idx = tracks.findIndex((x) => x.id === list[0].id);
                if (idx >= 0) onPlayTrack(idx, true);
              }}
              className="glass-panel p-3 flex items-center justify-between cursor-pointer pressable"
            >
              <div>
                <div className="text-[12.5px] font-bold">{artist}</div>
                <div className="text-[10px] text-[var(--muted)]">{list.length} {t("أعمال", "items")}</div>
              </div>
              <Icon id="play" size={15} className="text-[var(--a1)]" />
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex gap-2">
            <input
              value={newPl}
              onChange={(e) => setNewPl(e.target.value)}
              placeholder={t("اسم قائمة تشغيل موسيقية جديدة...", "New music playlist name...")}
              className="flex-1 glass-subtle px-3 py-2 text-[12px]"
            />
            <button
              type="button"
              onClick={() => {
                if (!newPl.trim()) return;
                createPlaylist(newPl.trim());
                setNewPl("");
              }}
              className="btn-aurora pressable"
            >
              {t("إنشاء", "Create")}
            </button>
          </div>
          <div className="glass-panel p-3.5">
            <div className="text-[12.5px] font-bold">
              ♥ {t("المفضلة", "Favorites")} ({favorites.length})
            </div>
          </div>
          {playlists.map((pl) => (
            <div key={pl.id} className="glass-panel p-3.5">
              <div className="text-[12.5px] font-bold">
                {pl.name} ({pl.trackIds.length})
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
