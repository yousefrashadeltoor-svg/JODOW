export type Lang = "ar" | "en";
export type VisualizerStyle = "bars" | "wave" | "orbit" | "particles";
export type RepeatKind = "off" | "all" | "one" | "ab";

export interface ThemeSpec {
  id: string;
  nameAr: string;
  nameEn: string;
  descAr: string;
  descEn: string;
  photo: string;
  swatches: [string, string, string];
  defaultVisualizer: VisualizerStyle;
  motionTagAr: string;
  motionTagEn: string;
}

export const THEMES_CATALOG: ThemeSpec[] = [
  {
    id: "aurora",
    nameAr: "أورورا القطب",
    nameEn: "Arctic Aurora",
    descAr: "شفق قطبي متموج بفيزياء ناعمة وتوهج زجاجي عميق",
    descEn: "Polar aurora ribbons with silky spring physics & deep glass",
    photo: "themes/theme_aurora.jpg",
    swatches: ["#4285F4", "#9B72CB", "#D96570"],
    defaultVisualizer: "wave",
    motionTagAr: "فيزياء حريرية · 28px",
    motionTagEn: "Silky Spring · 28px",
  },
  {
    id: "sahara",
    nameAr: "غسق الصحراء الذهبي",
    nameEn: "Sahara Golden Dusk",
    descAr: "كثبان العنبر والذهب مع زجاج دافئ وحركة انسيابية هادئة",
    descEn: "Warm amber dunes, gilded borders & calm desert motion",
    photo: "themes/theme_sahara.jpg",
    swatches: ["#F59E0B", "#EC4899", "#FBBF24"],
    defaultVisualizer: "bars",
    motionTagAr: "انسياب دافئ · 26px",
    motionTagEn: "Warm Glide · 26px",
  },
  {
    id: "ocean",
    nameAr: "أعماق المحيط المضيئة",
    nameEn: "Bioluminescent Ocean",
    descAr: "أمواج السيان الكهربائي والياقوت الأزرق بحواف بلورية",
    descEn: "Electric cyan waves & sapphire crystal glass reflections",
    photo: "themes/theme_ocean.jpg",
    swatches: ["#06B6D4", "#3B82F6", "#2DD4BF"],
    defaultVisualizer: "wave",
    motionTagAr: "موج بلوري · 30px",
    motionTagEn: "Fluid Wave · 30px",
  },
  {
    id: "sakura",
    nameAr: "ليالي الساكورا القرمزية",
    nameEn: "Crimson Sakura Nocturne",
    descAr: "أزهار الكرز الليلية تحت المطر مع استجابة نابضة فورية",
    descEn: "Rain-kissed Kyoto blossoms with snappy tactile bounce",
    photo: "themes/theme_sakura.jpg",
    swatches: ["#F43F5E", "#D946EF", "#FB7185"],
    defaultVisualizer: "orbit",
    motionTagAr: "ارتداد حيوي · 32px",
    motionTagEn: "Snappy Bounce · 32px",
  },
  {
    id: "emerald",
    nameAr: "ضباب الغابة الزمردية",
    nameEn: "Emerald Mist Canopy",
    descAr: "أشعة الصباح عبر الضباب الزمردي بتوازن بصري مريح للعين",
    descEn: "Morning sunbeams over jade mist with organic motion",
    photo: "themes/theme_emerald.jpg",
    swatches: ["#10B981", "#14B8A6", "#84CC16"],
    defaultVisualizer: "particles",
    motionTagAr: "عضوي هادئ · 24px",
    motionTagEn: "Calm Organic · 24px",
  },
  {
    id: "obsidian",
    nameAr: "تيتانيوم أوبسيديان AMOLED",
    nameEn: "Obsidian Titanium AMOLED",
    descAr: "سواد مطلق #000000 لتوفير الطاقة مع معدن التيتانيوم المصقول",
    descEn: "True #000000 pitch-black AMOLED with crisp titanium precision",
    photo: "themes/theme_obsidian.jpg",
    swatches: ["#E2E8F0", "#94A3B8", "#38BDF8"],
    defaultVisualizer: "bars",
    motionTagAr: "استجابة خاطفة · 20px",
    motionTagEn: "Ultra Crisp · 20px",
  },
];

export interface YouTubeVideo {
  videoId: string;
  title: string;
  channelId: string;
  channelName: string;
  channelAvatar: string;
  thumbnail: string;
  durationSec: number;
  viewsText: string;
  uploadedText: string;
  isShort: boolean;
}

export interface FollowedChannel {
  channelId: string;
  name: string;
  avatar: string;
  followedAt: number;
}

export interface LocalYtPlaylist {
  id: string;
  name: string;
  videos: YouTubeVideo[];
  createdAt: number;
}

export interface LocalYouTubeProfile {
  displayName: string;
  handle: string;
  bio: string;
  historyPaused: boolean;
  followedChannels: FollowedChannel[];
  watchHistory: YouTubeVideo[];
  likedVideos: YouTubeVideo[];
  watchLater: YouTubeVideo[];
  playlists: LocalYtPlaylist[];
  searchHistory: string[];
  topicWeights: Record<string, number>;
  channelWeights: Record<string, number>;
}

export const DEFAULT_YT_PROFILE: LocalYouTubeProfile = {
  displayName: "JoDon Member",
  handle: "@jodon_local",
  bio: "",
  historyPaused: false,
  followedChannels: [],
  watchHistory: [],
  likedVideos: [],
  watchLater: [],
  playlists: [],
  searchHistory: [],
  topicWeights: {},
  channelWeights: {},
};

export interface LocalTrack {
  id: string;
  name: string;
  artist: string;
  album: string;
  folder: string;
  url: string;
  file?: File;
  sizeBytes: number;
  durationSec: number;
  isVideo: boolean;
  addedAt: number;
}

export interface LocalMusicPlaylist {
  id: string;
  name: string;
  trackIds: string[];
}

export interface ExtractedFormat {
  id: string;
  url: string;
  kind: "video" | "audio" | "images" | "files";
  quality: string;
  container: string;
  codec: string;
  bitrateText: string;
  bytes: number;
  exact: boolean;
}

export interface RealDownloadTask {
  id: string;
  title: string;
  url: string;
  kind: "video" | "audio" | "images" | "files";
  status: "active" | "paused" | "done" | "failed";
  loadedBytes: number;
  totalBytes: number;
  exact: boolean;
  speedBps: number;
  blobUrl?: string;
  error?: string;
  spark: number[];
}

export function formatBytes(bytes: number): string {
  if (!bytes || bytes <= 0) return "0 B";
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KiB", "MiB", "GiB", "TiB"];
  let val = bytes / 1024;
  let i = 0;
  while (val >= 1024 && i < units.length - 1) {
    val /= 1024;
    i++;
  }
  return `${val >= 100 ? val.toFixed(1) : val.toFixed(2)} ${units[i]}`;
}

export function formatClock(sec: number): string {
  if (!Number.isFinite(sec) || sec <= 0) return "0:00";
  const total = Math.floor(sec);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function loadLocal<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return { ...fallback, ...JSON.parse(raw) };
  } catch {
    return fallback;
  }
}

export function saveLocal<T>(key: string, value: T): void {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Ignore storage quota errors
  }
}
