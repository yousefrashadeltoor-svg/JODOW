import { useEffect, useRef, useState } from "react";
import { decodeRealWaveform, encodeTrimmedWavBlob } from "./audioEngine";
import { Icon } from "./Icons";
import type { IconId } from "./Icons";
import { LuxuryPlayerView, MusicPagesView } from "./LuxuryPlayerAndMusic";
import {
  DEFAULT_YT_PROFILE,
  THEMES_CATALOG,
  formatBytes,
  formatClock,
  loadLocal,
  saveLocal,
} from "./types";
import type {
  ExtractedFormat,
  Lang,
  LocalMusicPlaylist,
  LocalTrack,
  LocalYouTubeProfile,
  RealDownloadTask,
  VisualizerStyle,
} from "./types";
import { analyzeAnyUrlReal } from "./youtubeService";
import { YouTubeTab } from "./YouTubeTab";

type MainRoute = "home" | "youtube" | "player" | "music" | "downloads" | "tools" | "themes";

const DOCK_ITEMS: { id: MainRoute; ar: string; en: string; icon: IconId }[] = [
  { id: "home", ar: "الرئيسية", en: "Home", icon: "home" },
  { id: "youtube", ar: "يوتيوب", en: "YouTube", icon: "youtube" },
  { id: "player", ar: "المشغل", en: "Player", icon: "player" },
  { id: "music", ar: "الموسيقى", en: "Music", icon: "music" },
  { id: "downloads", ar: "التحميلات", en: "Downloads", icon: "download" },
  { id: "themes", ar: "الثيمات", en: "Themes", icon: "settings" },
];

export default function App() {
  const [prefs, setPrefs] = useState(() =>
    loadLocal("jodon_prefs_v2", {
      lang: "ar" as Lang,
      themeId: "aurora",
      light: false,
      animSpeed: 1,
      visualizer: "bars" as VisualizerStyle,
    })
  );

  const [ytProfile, setYtProfileState] = useState<LocalYouTubeProfile>(() =>
    loadLocal("jodon_yt_profile_v2", DEFAULT_YT_PROFILE)
  );
  const [musicFavs, setMusicFavs] = useState<string[]>(() =>
    loadLocal("jodon_music_favs_v2", { list: [] as string[] }).list
  );
  const [musicPlaylists, setMusicPlaylists] = useState<LocalMusicPlaylist[]>(() =>
    loadLocal("jodon_music_pls_v2", { list: [] as LocalMusicPlaylist[] }).list
  );

  const [route, setRoute] = useState<MainRoute>("home");
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<number | null>(null);

  // Home Real Link Analyzer State (Zero Fake Items)
  const [urlInput, setUrlInput] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<Awaited<ReturnType<typeof analyzeAnyUrlReal>>>(null);
  const [customTitle, setCustomTitle] = useState("");
  const [openFormatKind, setOpenFormatKind] = useState<ExtractedFormat["kind"] | null>(null);

  // Real Downloads State
  const [downloads, setDownloads] = useState<RealDownloadTask[]>([]);

  // Real Local Media Tracks State
  const [localTracks, setLocalTracks] = useState<LocalTrack[]>([]);
  const [currentTrackIdx, setCurrentTrackIdx] = useState(0);
  const [playAsSong, setPlayAsSong] = useState(false);

  // Real Browser Tools (Compressor & Audio Extractor) State
  const [toolFile, setToolFile] = useState<File | null>(null);
  const [toolPreviewOrig, setToolPreviewOrig] = useState<string | null>(null);
  const [toolPreviewAfter, setToolPreviewAfter] = useState<string | null>(null);
  const [toolLossless, setToolLossless] = useState(false);
  const [toolResult, setToolResult] = useState<{
    before: number;
    after: number;
    blobUrl: string | null;
    outName: string;
    msg: string;
  } | null>(null);
  const [comparePos, setComparePos] = useState(50);

  const lang = prefs.lang;
  const t = (ar: string, en: string) => (lang === "ar" ? ar : en);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    saveLocal("jodon_prefs_v2", prefs);
  }, [lang, prefs]);

  useEffect(() => {
    saveLocal("jodon_yt_profile_v2", ytProfile);
  }, [ytProfile]);

  useEffect(() => {
    saveLocal("jodon_music_favs_v2", { list: musicFavs });
  }, [musicFavs]);

  useEffect(() => {
    saveLocal("jodon_music_pls_v2", { list: musicPlaylists });
  }, [musicPlaylists]);

  const showToast = (msg: string) => {
    setToast(msg);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 3200);
  };

  const setYtProfile = (updater: (prev: LocalYouTubeProfile) => LocalYouTubeProfile) => {
    setYtProfileState((prev) => updater(prev));
  };

  const importLocalMediaFiles = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const added: LocalTrack[] = [];
    Array.from(files).forEach((f) => {
      const isVid = f.type.startsWith("video/") || /\.(mp4|mkv|webm|mov|avi)$/i.test(f.name);
      const url = URL.createObjectURL(f);
      added.push({
        id: `local-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        name: f.name,
        artist: isVid ? t("فيديو محلي", "Local Video") : t("مقطع محلي", "Local Audio"),
        album: isVid ? "Videos" : "Local Music",
        folder: "Device",
        url,
        file: f,
        sizeBytes: f.size,
        durationSec: 0,
        isVideo: isVid,
        addedAt: Date.now(),
      });
    });
    setLocalTracks((prev) => [...added, ...prev]);
    setCurrentTrackIdx(0);
    showToast(t(`تم استيراد ${added.length} ملف محلي بنجاح`, `Imported ${added.length} local file(s)`));
  };

  const runRealUrlAnalysis = async (targetUrl?: string) => {
    const raw = (targetUrl ?? urlInput).trim();
    if (!raw) return;
    setAnalyzing(true);
    setAnalysis(null);
    const res = await analyzeAnyUrlReal(raw);
    setAnalyzing(false);
    if (!res) {
      showToast(t("تعذر تحليل هذا الرابط، تأكد من صحته أو اتصالك", "Could not parse URL"));
      return;
    }
    setAnalysis(res);
    setCustomTitle(res.title);
  };

  /** Executes a genuine HTTP stream download (or direct anchor fallback when cross-origin blocks fetch). */
  const startRealDownload = async (fileName: string, fmt: ExtractedFormat) => {
    const taskId = `dl-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const cleanName = fileName.replace(/[\\/:*?"<>|]/g, "_").slice(0, 140) || "jodon_download";
    const initial: RealDownloadTask = {
      id: taskId,
      title: cleanName,
      url: fmt.url,
      kind: fmt.kind,
      status: "active",
      loadedBytes: 0,
      totalBytes: fmt.bytes,
      exact: fmt.exact,
      speedBps: 0,
      spark: [10],
    };
    setDownloads((prev) => [initial, ...prev]);
    showToast(t("بدأ التحميل الفعلي في مدير التحميلات", "Real download started in Manager"));

    try {
      const response = await fetch(fmt.url);
      if (!response.ok || !response.body) throw new Error(`HTTP ${response.status}`);
      const cl = Number(response.headers.get("content-length") || 0);
      const total = cl > 0 ? cl : fmt.bytes;
      const reader = response.body.getReader();
      const chunks: Uint8Array[] = [];
      let loaded = 0;
      const started = performance.now();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value) {
          chunks.push(value);
          loaded += value.byteLength;
          const elapsedSec = Math.max(0.2, (performance.now() - started) / 1000);
          const speed = Math.round(loaded / elapsedSec);
          setDownloads((prev) =>
            prev.map((d) =>
              d.id !== taskId
                ? d
                : {
                    ...d,
                    loadedBytes: loaded,
                    totalBytes: total || loaded,
                    exact: cl > 0 || d.exact,
                    speedBps: speed,
                    spark: [...d.spark.slice(-18), Math.min(100, Math.max(8, Math.round(speed / 25000)))],
                  }
            )
          );
        }
      }

      const blob = new Blob(chunks as BlobPart[]);
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = blobUrl;
      a.download = cleanName;
      a.click();

      setDownloads((prev) =>
        prev.map((d) =>
          d.id !== taskId
            ? d
            : {
                ...d,
                status: "done",
                loadedBytes: blob.size,
                totalBytes: blob.size,
                exact: true,
                speedBps: 0,
                blobUrl,
              }
        )
      );

      // Automatically register downloaded audio/video into Local Player library!
      if (fmt.kind === "video" || fmt.kind === "audio") {
        const fileObj = new File([blob], cleanName, {
          type: fmt.kind === "video" ? "video/mp4" : "audio/mp4",
        });
        setLocalTracks((prev) => [
          {
            id: `dl-track-${Date.now()}`,
            name: cleanName,
            artist: "𝒥𝒪 DON Downloads",
            album: "Downloaded",
            folder: "JoDon",
            url: blobUrl,
            file: fileObj,
            sizeBytes: blob.size,
            durationSec: 0,
            isVideo: fmt.kind === "video",
            addedAt: Date.now(),
          },
          ...prev,
        ]);
      }
    } catch {
      // Cross-origin server restricts fetch ReadableStream: trigger real browser download anchor cleanly
      const a = document.createElement("a");
      a.href = fmt.url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.download = cleanName;
      a.click();
      setDownloads((prev) =>
        prev.map((d) =>
          d.id !== taskId
            ? d
            : {
                ...d,
                status: "done",
                error: t("تم فتح التحميل المباشر عبر المتصفح (قيود CORS من المصدر)", "Direct browser stream opened (CORS origin policy)"),
              }
        )
      );
    }
  };

  /** Real Studio Tool: Compress Image to WebP OR Extract WAV Audio from Video. */
  const runRealStudioTool = async (file: File, lossless: boolean) => {
    setToolFile(file);
    setToolResult(null);
    if (file.type.startsWith("image/")) {
      const origUrl = URL.createObjectURL(file);
      setToolPreviewOrig(origUrl);
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        ctx.drawImage(img, 0, 0);
        canvas.toBlob(
          (blob) => {
            if (!blob) return;
            if (blob.size >= file.size) {
              setToolPreviewAfter(origUrl);
              setToolResult({
                before: file.size,
                after: file.size,
                blobUrl: null,
                outName: file.name,
                msg: t(
                  "الملف مضغوط بأقصى درجة مسبقاً — لم يصغُر الحجم ولن نعرض ملفاً أكبر بصدق تام.",
                  "File is already maximally compressed — honest check kept original."
                ),
              });
            } else {
              const afterUrl = URL.createObjectURL(blob);
              setToolPreviewAfter(afterUrl);
              const pct = (((file.size - blob.size) / file.size) * 100).toFixed(1);
              const outName = `${file.name.replace(/\.[^.]+$/, "")}_compressed.webp`;
              setToolResult({
                before: file.size,
                after: blob.size,
                blobUrl: afterUrl,
                outName,
                msg: t(`تم توفير ${pct}% فعلياً بنسخة جديدة دون مساس بالأصل!`, `Saved ${pct}% genuinely into a new file!`),
              });
            }
          },
          "image/webp",
          lossless ? 1.0 : 0.84
        );
      };
      img.src = origUrl;
    } else if (file.type.startsWith("video/") || file.type.startsWith("audio/")) {
      setToolPreviewOrig(null);
      setToolPreviewAfter(null);
      const { audioBuffer } = await decodeRealWaveform(file, 32);
      if (!audioBuffer) {
        setToolResult({
          before: file.size,
          after: file.size,
          blobUrl: null,
          outName: "",
          msg: t("تعذر استخراج المسار الصوتي من هذا الملف", "Could not decode audio stream"),
        });
        return;
      }
      const wav = encodeTrimmedWavBlob(audioBuffer, 0, audioBuffer.duration);
      const url = URL.createObjectURL(wav);
      const outName = `${file.name.replace(/\.[^.]+$/, "")}_extracted.wav`;
      setToolResult({
        before: file.size,
        after: wav.size,
        blobUrl: url,
        outName,
        msg: t("تم استخراج المسار الصوتي الكامل بجودة PCM WAV جاهزة للحفظ!", "Extracted full lossless PCM WAV audio track!"),
      });
    }
  };

  const activeTheme = THEMES_CATALOG.find((x) => x.id === prefs.themeId) || THEMES_CATALOG[0];

  return (
    <div
      className={`jodon-app ${prefs.light ? "light" : ""}`}
      data-theme={prefs.themeId}
      style={{
        ["--anim-dur" as string]: `${Math.round(440 / prefs.animSpeed)}ms`,
        ["--glow-dur" as string]: `${(5.2 / prefs.animSpeed).toFixed(1)}s`,
      }}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        if (e.dataTransfer.files?.length) {
          importLocalMediaFiles(e.dataTransfer.files);
          setRoute("player");
        }
      }}
    >
      <div className="stage-shell">
        <i className="ambient-blob ambient-1" />
        <i className="ambient-blob ambient-2" />
        <i className="ambient-blob ambient-3" />

        {/* Desktop Companion Showcase Sidebar */}
        <aside className="desktop-sidebar">
          <div className="flex items-center gap-3">
            <span
              className="w-12 h-12 rounded-[18px] grid place-items-center text-white shadow-lg"
              style={{ background: "linear-gradient(135deg, var(--a1), var(--a2), var(--a3))" }}
            >
              <Icon id="sparkles" size={24} />
            </span>
            <div>
              <div className="text-[22px] font-extrabold grad-text leading-none">𝒥𝒪 DON</div>
              <div className="text-[11px] text-[var(--muted)] mt-1">
                {t("تطبيق متكامل بدون محاكاة أو سحابة أو قاعدة بيانات", "Zero-Mock · Zero-Backend · Zero-Database")}
              </div>
            </div>
          </div>

          <p className="m-0 text-[13px] leading-relaxed text-[var(--muted)]">
            {t(
              "يعمل التطبيق بكامل قوته أوفلاين (عدا تصفح يوتيوب والتحميل): منصة يوتيوب مدمجة بشورتس وحساب محلي قابل للتصدير والاستيراد، مشغل فيديو وموسيقى فاخر مع قص مرئي يدوي بالموجة الصوتية ونغمات رنين، و6 ثيمات حية بصور واقعية. مشروع الـ APK الكامل جاهز للبناء في مجلد JP PROJ.",
              "100% real functionality offline-first: standalone native YouTube hub with Shorts & exportable local profile, luxury local video/music player with tactile waveform trimming & ringtone maker, and 6 photo-backed live themes. Full Android APK source is in JP PROJ."
            )}
          </p>

          <div className="grid grid-cols-2 gap-2">
            {DOCK_ITEMS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setRoute(item.id)}
                className={`glass-subtle p-2.5 flex items-center gap-2 pressable text-[12px] font-bold ${
                  route === item.id ? "!border-[var(--a1)]" : ""
                }`}
              >
                <Icon id={item.icon} size={16} />
                <span>{t(item.ar, item.en)}</span>
              </button>
            ))}
          </div>

          <div className="space-y-2">
            <div className="text-[11px] font-bold text-[var(--muted)]">
              {t("تبديل الثيم الفوري (يتحكم بكل شيء):", "Instant Master Theme Switcher:")}
            </div>
            <div className="grid grid-cols-3 gap-2">
              {THEMES_CATALOG.map((th) => (
                <button
                  key={th.id}
                  type="button"
                  onClick={() =>
                    setPrefs((p) => ({
                      ...p,
                      themeId: th.id,
                      visualizer: th.defaultVisualizer,
                    }))
                  }
                  className={`relative h-14 rounded-2xl overflow-hidden border-2 pressable ${
                    prefs.themeId === th.id ? "border-white scale-[1.03]" : "border-transparent opacity-80"
                  }`}
                >
                  <img src={th.photo} alt={th.nameEn} className="w-full h-full object-cover" />
                  <span className="absolute inset-0 bg-black/35 grid place-items-center text-[10px] font-extrabold text-white px-1 text-center">
                    {t(th.nameAr, th.nameEn)}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* Main Mobile Device Frame */}
        <div className="phone-chassis">
          <div className="phone-viewport">
            {/* Top App Bar */}
            <header className="relative z-10 flex items-center justify-between px-4 pt-3 pb-2 border-b border-[var(--border)]">
              <div
                onClick={() => setRoute("home")}
                className="flex items-center gap-2 cursor-pointer"
              >
                <span
                  className="w-8 h-8 rounded-[12px] grid place-items-center text-white"
                  style={{ background: "linear-gradient(135deg, var(--a1), var(--a2), var(--a3))" }}
                >
                  <Icon id="sparkles" size={16} />
                </span>
                <div>
                  <div className="text-[14px] font-extrabold leading-none grad-text">𝒥𝒪 DON</div>
                  <div className="text-[9px] text-[var(--muted)] mt-0.5">
                    {t(activeTheme.nameAr, activeTheme.nameEn)}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setRoute("tools")}
                  className={`pill pressable ${route === "tools" ? "active" : ""}`}
                >
                  <Icon id="sliders" size={12} /> {t("الأدوات", "Studio")}
                </button>
                <button
                  type="button"
                  onClick={() => setPrefs((p) => ({ ...p, light: !p.light }))}
                  className="btn-glass !p-2"
                  title="Light / Dark"
                >
                  <Icon id={prefs.light ? "sun" : "moon"} size={14} />
                </button>
                <button
                  type="button"
                  onClick={() => setPrefs((p) => ({ ...p, lang: p.lang === "ar" ? "en" : "ar" }))}
                  className="btn-glass !px-2.5 !py-1.5 !text-[10.5px]"
                >
                  {lang === "ar" ? "EN" : "عربي"}
                </button>
              </div>
            </header>

            {/* Active Screen Content */}
            <main className="scroll-pane" key={`${route}-${lang}`}>
              {route === "home" && (
                <div className="space-y-3.5 spring-enter">
                  <div className="pt-1">
                    <h1 className="m-0 text-[22px] font-extrabold leading-tight">
                      {t("حمّل، شاهد، واستمع", "Download, Watch & Listen")}{" "}
                      <span className="grad-text">{t("بفخامة مطلقة.", "Without Limits.")}</span>
                    </h1>
                    <p className="m-0 mt-1 text-[11px] text-[var(--muted)]">
                      {t(
                        "أوفلاين بالكامل في واجهته · بدون باكيند أو داتابيز · خصوصية محلية تامة",
                        "100% Offline-Ready UI · Zero Backend · Zero Database"
                      )}
                    </p>
                  </div>

                  {/* Glowing Real URL Input Card */}
                  <div className={`glow-ring ${analyzing ? "" : "idle"}`}>
                    <div className="glass-panel p-3.5 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold flex items-center gap-1.5">
                          <Icon id="link" size={14} className="text-[var(--a1)]" />
                          {t("ألصق رابط فيديو أو صوت أو صورة أو ملف", "Paste Video, Audio, Image or File URL")}
                        </span>
                        {urlInput && (
                          <button
                            type="button"
                            onClick={() => {
                              setUrlInput("");
                              setAnalysis(null);
                            }}
                            className="text-[var(--muted)]"
                          >
                            <Icon id="close" size={14} />
                          </button>
                        )}
                      </div>

                      <textarea
                        rows={2}
                        value={urlInput}
                        onChange={(e) => setUrlInput(e.target.value)}
                        placeholder={t(
                          "https://... الصق أي رابط حقيقي هنا للتحليل والتحميل الفعلي",
                          "https://... paste any real URL here to analyze & download"
                        )}
                        className="w-full glass-subtle p-2.5 text-[11.5px] mono ltr resize-none"
                      />

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              const clip = await navigator.clipboard.readText();
                              if (clip) {
                                setUrlInput(clip);
                                void runRealUrlAnalysis(clip);
                              }
                            } catch {
                              showToast(t("الصق الرابط في الحقل مباشرة", "Paste directly into the field"));
                            }
                          }}
                          className="btn-glass pressable"
                        >
                          <Icon id="clipboard" size={14} /> {t("لصق", "Paste")}
                        </button>
                        <button
                          type="button"
                          onClick={() => void runRealUrlAnalysis()}
                          className="btn-aurora pressable flex-1"
                        >
                          <Icon id="sparkles" size={15} />
                          {analyzing ? t("جارٍ التحليل الفعلي...", "Analyzing...") : t("تحليل الرابط", "Analyze Link")}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Real Analysis Result + Smart 4 Buttons */}
                  {analysis && (
                    <div className="glass-panel p-3.5 space-y-3 spring-enter">
                      <div className="flex items-center justify-between gap-2">
                        <span className="pill active">{analysis.domain}</span>
                        <button
                          type="button"
                          onClick={() => {
                            void navigator.clipboard?.writeText(analysis.normalizedUrl);
                            showToast(t("تم نسخ الرابط", "URL copied"));
                          }}
                          className="btn-glass pressable !py-1 !px-2.5"
                        >
                          <Icon id="copy" size={12} /> {t("نسخ الرابط", "Copy URL")}
                        </button>
                      </div>

                      {analysis.thumbnail && (
                        <img
                          src={analysis.thumbnail}
                          alt={analysis.title}
                          className="w-full h-[156px] rounded-2xl object-cover"
                        />
                      )}

                      <div>
                        <div className="text-[13px] font-bold">{analysis.title}</div>
                        <div className="text-[10.5px] text-[var(--muted)] mt-0.5">
                          {analysis.uploader}
                          {analysis.durationSec > 0 ? ` · ${formatClock(analysis.durationSec)}` : ""}
                        </div>
                      </div>

                      <input
                        value={customTitle}
                        onChange={(e) => setCustomTitle(e.target.value)}
                        className="w-full glass-subtle px-3 py-2 text-[11.5px] mono ltr"
                        aria-label="Filename"
                      />

                      {/* Smart 4 Buttons — Only rendered for categories that genuinely exist! */}
                      <div className="grid grid-cols-4 gap-2">
                        {(
                          [
                            ["video", t("فيديو", "Video"), "video"],
                            ["audio", t("صوت", "Audio"), "music"],
                            ["images", t("صور", "Images"), "image"],
                            ["files", t("ملفات", "Files"), "file"],
                          ] as const
                        )
                          .filter(([k]) => analysis.formats.some((f) => f.kind === k))
                          .map(([k, label, icon]) => {
                            const count = analysis.formats.filter((f) => f.kind === k).length;
                            return (
                              <button
                                key={k}
                                type="button"
                                onClick={() => setOpenFormatKind(k)}
                                className="glass-subtle p-2.5 text-center pressable relative"
                              >
                                <span className="absolute top-1.5 inset-inline-end-1.5 px-1.5 rounded-full text-[9px] font-bold bg-[var(--a2)] text-white">
                                  {count}
                                </span>
                                <Icon id={icon} size={19} className="mx-auto text-[var(--a1)]" />
                                <div className="text-[10.5px] font-bold mt-1">{label}</div>
                              </button>
                            );
                          })}
                      </div>
                    </div>
                  )}

                  {/* Quick Feature Launchers */}
                  <div className="grid grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={() => setRoute("youtube")}
                      className="glass-panel p-3.5 text-start pressable space-y-2"
                    >
                      <Icon id="youtube" size={28} />
                      <div className="text-[13px] font-extrabold">
                        {t("منصة يوتيوب المدمجة", "Built-in YouTube Hub")}
                      </div>
                      <div className="text-[10px] text-[var(--muted)] leading-relaxed">
                        {t("شورتس + اقتراحات ذكية + حساب محلي قابل للتصدير + تحميل تحت كل فيديو", "Shorts, infinite personalized feed, local profile & 1-tap download")}
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRoute("player")}
                      className="glass-panel p-3.5 text-start pressable space-y-2"
                    >
                      <span
                        className="w-7 h-7 rounded-xl grid place-items-center text-white"
                        style={{ background: "linear-gradient(135deg, var(--a1), var(--a2))" }}
                      >
                        <Icon id="player" size={15} />
                      </span>
                      <div className="text-[13px] font-extrabold">
                        {t("المشغل المحلي والقص اليدوي", "Luxury Player & Trimmer")}
                      </div>
                      <div className="text-[10px] text-[var(--muted)] leading-relaxed">
                        {t("تشغيل كأغنية، قص مرئي بالموجة الصوتية، نغمات رنين، ومؤقت نوم", "Play as song, tactile waveform trimmer, ringtone maker & sleep timer")}
                      </div>
                    </button>
                  </div>

                  <p className="m-0 text-[9.5px] text-center text-[var(--muted)] pt-2">
                    {t(
                      "المسؤولية على المستخدم في احترام حقوق النشر · لا تجاوز DRM ولا Paywalls",
                      "Users are responsible for respecting copyright · No DRM or paywall circumvention"
                    )}
                  </p>
                </div>
              )}

              {route === "youtube" && (
                <YouTubeTab
                  lang={lang}
                  profile={ytProfile}
                  setProfile={setYtProfile}
                  onStartDownload={(title, fmt) => void startRealDownload(title, fmt)}
                  onToast={showToast}
                />
              )}

              {route === "player" && (
                <LuxuryPlayerView
                  lang={lang}
                  tracks={localTracks}
                  currentIndex={currentTrackIdx}
                  setCurrentIndex={setCurrentTrackIdx}
                  songMode={playAsSong}
                  setSongMode={setPlayAsSong}
                  visualizerStyle={prefs.visualizer}
                  setVisualizerStyle={(s) => setPrefs((p) => ({ ...p, visualizer: s }))}
                  onImportFiles={importLocalMediaFiles}
                  onAddGeneratedTrack={(tr) => setLocalTracks((prev) => [tr, ...prev])}
                  onToast={showToast}
                />
              )}

              {route === "music" && (
                <MusicPagesView
                  lang={lang}
                  tracks={localTracks}
                  favorites={musicFavs}
                  toggleFavorite={(id) =>
                    setMusicFavs((prev) =>
                      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
                    )
                  }
                  playlists={musicPlaylists}
                  createPlaylist={(name) =>
                    setMusicPlaylists((prev) => [
                      { id: `mpl-${Date.now()}`, name, trackIds: [] },
                      ...prev,
                    ])
                  }
                  addTrackToPlaylist={(plId, trackId) => {
                    setMusicPlaylists((prev) =>
                      prev.map((pl) =>
                        pl.id !== plId || pl.trackIds.includes(trackId)
                          ? pl
                          : { ...pl, trackIds: [...pl.trackIds, trackId] }
                      )
                    );
                    showToast(t("تمت الإضافة لقائمة التشغيل", "Added to playlist"));
                  }}
                  onImportFiles={importLocalMediaFiles}
                  onPlayTrack={(idx, asSong) => {
                    setCurrentTrackIdx(idx);
                    setPlayAsSong(asSong);
                    setRoute("player");
                  }}
                />
              )}

              {route === "downloads" && (
                <div className="space-y-3 spring-enter">
                  <div className="flex items-center justify-between">
                    <h2 className="m-0 text-[18px] font-extrabold grad-text">
                      {t("مدير التحميلات الفعلي", "Real Download Manager")}
                    </h2>
                    <span className="pill active">{downloads.length}</span>
                  </div>

                  {downloads.length === 0 ? (
                    <div className="glass-panel p-6 text-center space-y-2.5">
                      <Icon id="download" size={32} className="mx-auto text-[var(--a1)]" />
                      <div className="text-[13px] font-bold">
                        {t("لا توجد تحميلات وهمية — المدير جاهز لتحميلاتك الحقيقية", "Zero Fake Downloads — Ready for Real Transfers")}
                      </div>
                      <p className="m-0 text-[11px] text-[var(--muted)]">
                        {t("ابدأ أي تحميل من تبويب «يوتيوب» أو من محلل الروابط في «الرئيسية».", "Start any download from the YouTube tab or the Home URL analyzer.")}
                      </p>
                    </div>
                  ) : (
                    downloads.map((d) => {
                      const pct =
                        d.totalBytes > 0
                          ? Math.min(100, Math.round((d.loadedBytes / d.totalBytes) * 100))
                          : d.status === "done"
                          ? 100
                          : 15;
                      return (
                        <div key={d.id} className="glass-panel p-3.5 space-y-2">
                          <div className="flex items-center justify-between gap-2">
                            <div className="text-[12px] font-bold truncate">{d.title}</div>
                            <span className="pill">{d.status.toUpperCase()}</span>
                          </div>
                          <div className="h-2 rounded-full bg-[var(--track)] overflow-hidden">
                            <div
                              className="h-full rounded-full transition-all"
                              style={{
                                width: `${pct}%`,
                                background: "linear-gradient(90deg, var(--a1), var(--a2), var(--a3))",
                              }}
                            />
                          </div>
                          <div className="flex items-center justify-between text-[10px] text-[var(--muted)] mono">
                            <span>
                              {formatBytes(d.loadedBytes)}
                              {d.totalBytes > 0 ? ` / ${d.exact ? "" : "≈ "}${formatBytes(d.totalBytes)}` : ""}
                            </span>
                            <span>{d.speedBps > 0 ? `${formatBytes(d.speedBps)}/s` : ""}</span>
                          </div>
                          {d.error && <div className="text-[10px] text-[var(--a1)]">{d.error}</div>}
                          <div className="flex items-center gap-1.5">
                            {d.blobUrl && (
                              <a
                                href={d.blobUrl}
                                download={d.title}
                                className="btn-aurora pressable !py-1.5 !px-3 no-underline"
                              >
                                <Icon id="download" size={13} /> {t("حفظ نسخة", "Save File")}
                              </a>
                            )}
                            <button
                              type="button"
                              onClick={() => {
                                void navigator.clipboard?.writeText(d.url);
                                showToast(t("تم نسخ الرابط المباشر", "Direct URL copied"));
                              }}
                              className="btn-glass pressable !py-1.5 !px-2.5"
                            >
                              <Icon id="copy" size={13} /> {t("نسخ الرابط", "Copy Link")}
                            </button>
                            <button
                              type="button"
                              onClick={() => setDownloads((prev) => prev.filter((x) => x.id !== d.id))}
                              className="btn-glass pressable !p-1.5 ms-auto"
                            >
                              <Icon id="trash" size={14} />
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              )}

              {route === "tools" && (
                <div className="space-y-3 spring-enter">
                  <h2 className="m-0 text-[18px] font-extrabold grad-text">
                    {t("استوديو التحويل والتصغير الذكي الفعلي", "Real Converter & Smart Compressor")}
                  </h2>
                  <p className="m-0 text-[11px] text-[var(--muted)]">
                    {t(
                      "اختر صورة لضغطها فعلياً إلى WebP مع مقارنة حية قبل/بعد، أو اختر ملف فيديو لاستخراج مساره الصوتي الكامل كملف WAV بدون فقد:",
                      "Pick an image for real WebP compression with live Before/After slider, or pick a video to extract its full lossless WAV audio:"
                    )}
                  </p>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setToolLossless(true)}
                      className={`pill pressable flex-1 justify-center ${toolLossless ? "active" : ""}`}
                    >
                      🟢 {t("أعلى جودة (Lossless/Max)", "Max Quality")}
                    </button>
                    <button
                      type="button"
                      onClick={() => setToolLossless(false)}
                      className={`pill pressable flex-1 justify-center ${!toolLossless ? "active" : ""}`}
                    >
                      🟡 {t("شفاف بصرياً (Transparent)", "Visually Transparent")}
                    </button>
                  </div>

                  <label className="glass-panel p-5 flex flex-col items-center justify-center gap-2 cursor-pointer pressable text-center">
                    <Icon id="upload" size={26} className="text-[var(--a1)]" />
                    <span className="text-[12.5px] font-bold">
                      {toolFile ? toolFile.name : t("اضغط لاختيار صورة أو فيديو من جهازك", "Choose Image or Video File")}
                    </span>
                    <input
                      type="file"
                      accept="image/*,video/*,audio/*"
                      className="hidden"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) void runRealStudioTool(f, toolLossless);
                      }}
                    />
                  </label>

                  {toolPreviewOrig && toolPreviewAfter && (
                    <div className="glass-panel p-2 space-y-2">
                      <div className="relative h-[186px] rounded-2xl overflow-hidden ltr">
                        <img src={toolPreviewOrig} alt="Before" className="absolute inset-0 w-full h-full object-cover" />
                        <img
                          src={toolPreviewAfter}
                          alt="After"
                          className="absolute inset-0 w-full h-full object-cover"
                          style={{ clipPath: `inset(0 0 0 ${comparePos}%)` }}
                        />
                        <div
                          className="absolute inset-y-0 w-[2px] bg-white shadow-lg pointer-events-none"
                          style={{ left: `${comparePos}%` }}
                        />
                        <input
                          type="range"
                          min={0}
                          max={100}
                          value={comparePos}
                          onChange={(e) => setComparePos(Number(e.target.value))}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize"
                        />
                        <span className="absolute bottom-2 left-2 pill !bg-black/70 !text-white">BEFORE</span>
                        <span className="absolute bottom-2 right-2 pill !bg-black/70 !text-white">AFTER</span>
                      </div>
                    </div>
                  )}

                  {toolResult && (
                    <div className="glass-panel p-3.5 space-y-2">
                      <div className="flex items-center justify-between text-[11.5px] mono">
                        <span>{t("قبل", "Before")}: {formatBytes(toolResult.before)}</span>
                        <span className="text-[var(--a4)] font-bold">
                          {t("بعد", "After")}: {formatBytes(toolResult.after)}
                        </span>
                      </div>
                      <div className="text-[11.5px] font-semibold">{toolResult.msg}</div>
                      {toolResult.blobUrl && (
                        <a
                          href={toolResult.blobUrl}
                          download={toolResult.outName}
                          className="btn-aurora pressable w-full no-underline"
                        >
                          <Icon id="download" size={14} /> {t("حفظ النسخة الجديدة", "Download Output")} ({toolResult.outName})
                        </a>
                      )}
                    </div>
                  )}
                </div>
              )}

              {route === "themes" && (
                <div className="space-y-3 spring-enter">
                  <div>
                    <h2 className="m-0 text-[18px] font-extrabold grad-text">
                      {t("استوديو الثيمات الحية الشاملة", "Master Theme Studio")}
                    </h2>
                    <p className="m-0 mt-1 text-[11px] text-[var(--muted)]">
                      {t(
                        "كل ثيم مصحوب بصورته الفوتوغرافية الواقعية ويتحكم في الألوان، انكسار الزجاج، استدارة الحواف، المؤثر البصري، وسرعة وفيزياء الأنيميشن في كامل التطبيق:",
                        "Every theme features realistic photography and transforms colors, glass blur, corner geometry, visualizer style, and spring animation physics across all screens:"
                      )}
                    </p>
                  </div>

                  {/* Realistic Photo Theme Gallery Cards */}
                  <div className="space-y-2.5">
                    {THEMES_CATALOG.map((th) => {
                      const selected = prefs.themeId === th.id;
                      return (
                        <button
                          key={th.id}
                          type="button"
                          onClick={() => {
                            setPrefs((p) => ({
                              ...p,
                              themeId: th.id,
                              visualizer: th.defaultVisualizer,
                            }));
                            showToast(t(`تم تفعيل ثيم ${th.nameAr}`, `Activated ${th.nameEn}`));
                          }}
                          className={`relative w-full h-[116px] rounded-[24px] overflow-hidden text-start pressable block border-2 transition-all ${
                            selected ? "border-white shadow-xl" : "border-[var(--border)]"
                          }`}
                        >
                          <img src={th.photo} alt={th.nameEn} className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent" />
                          <div className="absolute top-2.5 inset-inline-end-2.5 flex items-center gap-1">
                            {th.swatches.map((hex) => (
                              <span
                                key={hex}
                                className="w-3.5 h-3.5 rounded-full border border-white/60"
                                style={{ background: hex }}
                              />
                            ))}
                          </div>
                          <div className="absolute bottom-2.5 inset-inline-3 text-white">
                            <div className="flex items-center gap-2">
                              <span className="text-[14px] font-extrabold">{t(th.nameAr, th.nameEn)}</span>
                              <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-white/20 backdrop-blur-md">
                                {t(th.motionTagAr, th.motionTagEn)}
                              </span>
                              {selected && (
                                <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-[var(--a1)]">
                                  ✓ {t("نشط", "Active")}
                                </span>
                              )}
                            </div>
                            <div className="text-[10.5px] text-white/85 mt-0.5 truncate">
                              {t(th.descAr, th.descEn)}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {/* Motion Speed & Global Controls */}
                  <div className="glass-panel p-3.5 space-y-3">
                    <div className="flex items-center justify-between text-[12px] font-bold">
                      <span>{t("سرعة واستجابة الأنيميشن", "Global Animation Physics Speed")}</span>
                      <span className="mono text-[var(--a1)]">{prefs.animSpeed.toFixed(1)}×</span>
                    </div>
                    <input
                      type="range"
                      min={0.6}
                      max={1.8}
                      step={0.1}
                      value={prefs.animSpeed}
                      onChange={(e) => setPrefs((p) => ({ ...p, animSpeed: Number(e.target.value) }))}
                      className="w-full jodon-range ltr"
                    />
                    <div className="flex items-center justify-between pt-1">
                      <span className="text-[12px] font-bold">
                        {t("الوضع النهاري المضيء", "Daylight Frosted Glass")}
                      </span>
                      <button
                        type="button"
                        onClick={() => setPrefs((p) => ({ ...p, light: !p.light }))}
                        className={`pill pressable ${prefs.light ? "active" : ""}`}
                      >
                        {prefs.light ? t("مفعّل", "On") : t("داكن AMOLED", "Dark")}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </main>

            {/* Floating Glass Dock */}
            <nav className="floating-dock" aria-label="Main navigation">
              {DOCK_ITEMS.map((item) => {
                const active = route === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setRoute(item.id)}
                    className={`flex-1 h-full rounded-[20px] flex flex-col items-center justify-center gap-0.5 pressable transition-colors ${
                      active ? "bg-[var(--glass-hi)] text-[var(--text)]" : "text-[var(--muted)]"
                    }`}
                  >
                    <Icon id={item.icon} size={19} />
                    <span className="text-[9px] font-bold">{t(item.ar, item.en)}</span>
                  </button>
                );
              })}
            </nav>

            {/* Toast Notification */}
            {toast && (
              <div className="absolute z-40 bottom-22 inset-inline-6 glass-panel px-4 py-2.5 text-center text-[11.5px] font-bold shadow-2xl spring-enter">
                {toast}
              </div>
            )}

            {/* Home Smart Category Format Bottom Sheet */}
            {openFormatKind && analysis && (
              <>
                <div className="sheet-overlay" onClick={() => setOpenFormatKind(null)} />
                <div className="bottom-sheet space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="text-[13.5px] font-extrabold">
                      {t("اختر الجودة والصيغة للتحميل", "Select Quality & Format")}
                    </div>
                    <button type="button" onClick={() => setOpenFormatKind(null)} className="btn-glass !p-1.5">
                      <Icon id="close" size={14} />
                    </button>
                  </div>
                  <div className="overflow-y-auto no-scrollbar space-y-2">
                    {analysis.formats
                      .filter((f) => f.kind === openFormatKind)
                      .map((fmt) => (
                        <div
                          key={fmt.id}
                          className="glass-subtle p-2.5 flex items-center justify-between gap-2"
                        >
                          <div className="min-w-0">
                            <div className="text-[11.5px] font-bold">
                              {fmt.quality} · {fmt.container} · {fmt.codec}
                            </div>
                            <div className="text-[10px] text-[var(--muted)] mono">
                              {fmt.bitrateText}
                              {fmt.bytes > 0
                                ? ` · ${fmt.exact ? "" : "≈ "}${formatBytes(fmt.bytes)}`
                                : ""}
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              const ext = fmt.container.toLowerCase();
                              const base = customTitle.trim() || analysis.title;
                              const fname = base.endsWith(`.${ext}`) ? base : `${base}.${ext}`;
                              void startRealDownload(fname, fmt);
                              setOpenFormatKind(null);
                            }}
                            className="btn-aurora pressable !py-1.5 !px-3"
                          >
                            <Icon id="download" size={14} />
                          </button>
                        </div>
                      ))}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
