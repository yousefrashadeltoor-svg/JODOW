import { chromium } from 'playwright';
const browser = await chromium.launch({args:['--no-sandbox']});
const page = await browser.newPage({viewport:{width:1440,height:1050}});
await page.goto('http://127.0.0.1:4173', {waitUntil:'networkidle'});
await page.waitForTimeout(1200);
await page.getByRole('button',{name:/شاشة الترحيب/}).first().click();
await page.waitForTimeout(700);
const boxes = await page.evaluate(() => {
  const pick = (sel) => { const el = document.querySelector(sel); if(!el) return null; const r = el.getBoundingClientRect(); const cs = getComputedStyle(el); return {x:r.x,y:r.y,w:r.width,h:r.height, pos:cs.position, left:cs.left, right:cs.right, transform:cs.transform, dir:cs.direction}; };
  const host = document.querySelector('#phone-overlay')?.firstElementChild;
  const hr = host?.getBoundingClientRect();
  return {
    app: pick('.app-surface'),
    host: pick('#phone-overlay'),
    onboarding: hr ? {x:hr.x,y:hr.y,w:hr.width,h:hr.height} : null,
    scroll: {sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, sx: window.scrollX},
    inner: (()=>{const el=document.querySelector('#phone-overlay')?.firstElementChild?.firstElementChild; if(!el) return null; const r=el.getBoundingClientRect(); return {x:r.x,y:r.y,w:r.width,h:r.height};})()
  };
});
console.log(JSON.stringify(boxes,null,2));
await browser.close();
