export type MediaKind = "video" | "audio" | "image" | "file";
export type Screen = "home" | "downloads" | "browser" | "files" | "tools" | "settings";
export type Lang = "ar" | "en";
export type ThemeId = "aurora" | "ocean" | "sunset" | "emerald" | "mono" | "neon";

export interface FormatOption {
  id: string;
  quality: string;
  format: string;
  codec: string;
  detail: string;
  size: string;
  approx?: boolean;
  kind: MediaKind;
  recommended?: boolean;
  tokens?: string;
}

export interface SiteAnalysis {
  source: string;
  domain: string;
  title: string;
  filename: string;
  channel: string;
  verified: boolean;
  duration: string;
  published: string;
  views: string;
  thumbnail: string;
  logoBg: string;
  logoText: string;
  accent: string;
  formats: Record<MediaKind, FormatOption[]>;
}

export type DownloadStatus = "downloading" | "queued" | "paused" | "completed" | "failed";

export interface DownloadItem {
  id: string;
  title: string;
  kind: MediaKind;
  format: string;
  quality: string;
  sizeBytes: number;
  downloadedBytes: number;
  speed: number;
  connections: number;
  status: DownloadStatus;
  thumbnail: string;
  sparkline: number[];
  source: string;
  approx?: boolean;
  eta?: string;
}

export const IMAGES = {
  aurora:
    "https://images.pexels.com/photos/37538265/pexels-photo-37538265.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  aurora2:
    "https://images.pexels.com/photos/36193665/pexels-photo-36193665.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  aurora3:
    "https://images.pexels.com/photos/38394972/pexels-photo-38394972.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  night:
    "https://images.pexels.com/photos/16325032/pexels-photo-16325032.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  lake:
    "https://images.pexels.com/photos/38167361/pexels-photo-38167361.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  camp:
    "https://images.pexels.com/photos/19039999/pexels-photo-19039999.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
};

export const THEMES: { id: ThemeId; ar: string; en: string; colors: string[] }[] = [
  { id: "aurora", ar: "أورورا", en: "Aurora", colors: ["#4285F4", "#9B72CB", "#D96570"] },
  { id: "ocean", ar: "محيط", en: "Ocean", colors: ["#22d3ee", "#3b82f6", "#818cf8"] },
  { id: "sunset", ar: "غروب", en: "Sunset", colors: ["#fb923c", "#f43f5e", "#e879f9"] },
  { id: "emerald", ar: "زمرد", en: "Emerald", colors: ["#34d399", "#06b6d4", "#a3e635"] },
  { id: "mono", ar: "أحادي", en: "Mono", colors: ["#e7e9f0", "#a8adbd", "#7d8497"] },
  { id: "neon", ar: "نيون", en: "Neon", colors: ["#d946ef", "#8b5cf6", "#22d3ee"] },
];

const youtubeFormats: Record<MediaKind, FormatOption[]> = {
  video: [
    { id: "v1", quality: "8K", format: "MP4", codec: "AV1", detail: "60fps · HDR · 68 Mbps", size: "3.42 GB", kind: "video", tokens: "v-av1-8k" },
    { id: "v2", quality: "4K", format: "MP4", codec: "VP9", detail: "60fps · HDR · 24 Mbps", size: "1.18 GB", kind: "video", tokens: "v-vp9-4k" },
    { id: "v3", quality: "1440p", format: "WEBM", codec: "VP9", detail: "60fps · 12 Mbps", size: "614 MB", kind: "video" },
    { id: "v4", quality: "1080p", format: "MP4", codec: "AVC", detail: "60fps · 6.2 Mbps", size: "318 MB", kind: "video", recommended: true },
    { id: "v5", quality: "720p", format: "MP4", codec: "AVC", detail: "30fps · 3.1 Mbps", size: "158 MB", kind: "video" },
    { id: "v6", quality: "480p", format: "MP4", codec: "AVC", detail: "30fps · 1.4 Mbps", size: "72.4 MB", kind: "video" },
    { id: "v7", quality: "144p", format: "MP4", codec: "AVC", detail: "15fps · 310 Kbps", size: "16.1 MB", kind: "video" },
  ],
  audio: [
    { id: "a1", quality: "Master", format: "FLAC", codec: "FLAC", detail: "48 kHz · 24-bit · 1,536 Kbps", size: "128 MB", kind: "audio", recommended: true },
    { id: "a2", quality: "High", format: "M4A", codec: "AAC", detail: "44.1 kHz · 256 Kbps", size: "21.4 MB", kind: "audio" },
    { id: "a3", quality: "High", format: "WEBM", codec: "Opus", detail: "48 kHz · 160 Kbps", size: "13.8 MB", kind: "audio" },
    { id: "a4", quality: "Medium", format: "MP3", codec: "LAME", detail: "44.1 kHz · 192 Kbps", size: "16.2 MB", kind: "audio" },
    { id: "a5", quality: "Wave", format: "WAV", codec: "PCM", detail: "48 kHz · 24-bit · 2,304 Kbps", size: "192 MB", kind: "audio" },
  ],
  image: [
    { id: "i1", quality: "Max", format: "JPG", codec: "sRGB", detail: "3840 × 2160 · 4K", size: "8.2 MB", kind: "image", recommended: true },
    { id: "i2", quality: "HD", format: "WEBP", codec: "VP8L", detail: "1920 × 1080 · Lossless", size: "2.8 MB", kind: "image" },
    { id: "i3", quality: "Medium", format: "JPG", codec: "sRGB", detail: "1280 × 720", size: "764 KB", kind: "image" },
    { id: "i4", quality: "Cover", format: "AVIF", codec: "AV1", detail: "1080 × 1080 · Near-lossless", size: "504 KB", kind: "image" },
  ],
  file: [
    { id: "f1", quality: "Arabic", format: "SRT", codec: "UTF-8", detail: "الترجمة العربية · 612 سطر", size: "38.4 KB", kind: "file" },
    { id: "f2", quality: "English", format: "VTT", codec: "UTF-8", detail: "English captions · 608 lines", size: "36.1 KB", kind: "file" },
    { id: "f3", quality: "Metadata", format: "JSON", codec: "UTF-8", detail: "البيانات الوصفية الكاملة", size: "12.6 KB", kind: "file", approx: true },
    { id: "f4", quality: "Translated", format: "ASS", codec: "UTF-8", detail: "Arabic styled subtitles", size: "44.9 KB", kind: "file" },
  ],
};

const tiktokFormats: Record<MediaKind, FormatOption[]> = {
  video: [
    { id: "t1", quality: "1080p", format: "MP4", codec: "H.264", detail: "60fps · 5.8 Mbps · No Watermark", size: "48.3 MB", kind: "video", recommended: true },
    { id: "t2", quality: "1080p", format: "MP4", codec: "H.264", detail: "60fps · With Watermark", size: "49.1 MB", kind: "video" },
    { id: "t3", quality: "720p", format: "MP4", codec: "H.264", detail: "30fps · 2.9 Mbps", size: "22.2 MB", kind: "video" },
  ],
  audio: [
    { id: "ta1", quality: "Original", format: "M4A", codec: "AAC", detail: "44.1 kHz · 128 Kbps", size: "1.9 MB", kind: "audio", recommended: true },
    { id: "ta2", quality: "Original", format: "MP3", codec: "LAME", detail: "44.1 kHz · 192 Kbps", size: "2.7 MB", kind: "audio" },
  ],
  image: [
    { id: "ti1", quality: "Cover", format: "JPG", codec: "sRGB", detail: "1080 × 1920", size: "1.1 MB", kind: "image", recommended: true },
    { id: "ti2", quality: "Slide 01", format: "JPG", codec: "sRGB", detail: "1080 × 1920 · Photo Mode", size: "928 KB", kind: "image" },
    { id: "ti3", quality: "Slide 02", format: "JPG", codec: "sRGB", detail: "1080 × 1920 · Photo Mode", size: "894 KB", kind: "image" },
  ],
  file: [],
};

export const ANALYSES: Record<"youtube" | "tiktok", SiteAnalysis> = {
  youtube: {
    source: "YouTube",
    domain: "youtube.com",
    title: "حين يلتقي الضوء بالسماء — رحلة إلى الشفق القطبي",
    filename: "aurora-night-sky-8k.mp4",
    channel: "Aurora Studio",
    verified: true,
    duration: "18:42",
    published: "قبل 3 أيام",
    views: "1.8M مشاهدة",
    thumbnail: IMAGES.night,
    logoBg: "#ff0033",
    logoText: "▶",
    accent: "#9B72CB",
    formats: youtubeFormats,
  },
  tiktok: {
    source: "TikTok",
    domain: "tiktok.com",
    title: "لحظات لا تُنسى تحت سماء الشفق ✨",
    filename: "aurora-moments-no-watermark.mp4",
    channel: "@aurora.tales",
    verified: true,
    duration: "00:58",
    published: "قبل 5 ساعات",
    views: "4.2M مشاهدة",
    thumbnail: IMAGES.aurora,
    logoBg: "#25F4EE",
    logoText: "♪",
    accent: "#25F4EE",
    formats: tiktokFormats,
  },
};

export const INITIAL_DOWNLOADS: DownloadItem[] = [
  {
    id: "d1",
    title: "Aurora — Cinematic Night Collection",
    kind: "video",
    format: "MP4 · HEVC",
    quality: "4K · HDR",
    sizeBytes: 1_186_247_680,
    downloadedBytes: 736_915_456,
    speed: 8.4,
    connections: 16,
    status: "downloading",
    thumbnail: IMAGES.night,
    sparkline: [22, 38, 31, 55, 48, 74, 66, 88, 72, 94, 82, 97],
    source: "YouTube",
  },
  {
    id: "d2",
    title: "Midnight Echoes — Original Soundtrack",
    kind: "audio",
    format: "FLAC · 24-bit",
    quality: "Lossless",
    sizeBytes: 128_974_848,
    downloadedBytes: 57_671_680,
    speed: 3.1,
    connections: 8,
    status: "downloading",
    thumbnail: IMAGES.aurora2,
    sparkline: [30, 24, 44, 36, 58, 49, 42, 63, 51, 72, 61, 69],
    source: "SoundCloud",
  },
  {
    id: "d3",
    title: "Star Trails — Wallpaper Pack (12 photos)",
    kind: "image",
    format: "ZIP · WebP",
    quality: "Original",
    sizeBytes: 84_115_456,
    downloadedBytes: 8_409_088,
    speed: 0,
    connections: 0,
    status: "paused",
    thumbnail: IMAGES.lake,
    sparkline: [12, 18, 15, 24, 20, 27, 0, 0, 0, 0, 0, 0],
    source: "Pinterest",
  },
  {
    id: "d4",
    title: "Aurora Design System — Documentation",
    kind: "file",
    format: "PDF",
    quality: "Document",
    sizeBytes: 24_117_248,
    downloadedBytes: 24_117_248,
    speed: 0,
    connections: 0,
    status: "completed",
    thumbnail: IMAGES.aurora3,
    sparkline: [18, 32, 46, 60, 71, 82, 91, 100, 100, 100, 100, 100],
    source: "Direct link",
  },
  {
    id: "d5",
    title: "Clouds Above the Valley — 8K Timelapse",
    kind: "video",
    format: "WEBM · AV1",
    quality: "8K",
    sizeBytes: 3_421_798_400,
    downloadedBytes: 1_247_000_000,
    speed: 0,
    connections: 0,
    status: "queued",
    thumbnail: IMAGES.camp,
    sparkline: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    source: "Vimeo",
  },
];

export const SPEEDS = [8.4, 7.9, 9.1, 8.8, 10.2, 9.6, 8.9, 10.8];

export const FILES: {
  id: string;
  title: string;
  kind: MediaKind;
  meta: string;
  image: string;
  date: string;
}[] = [
  { id: "lf1", title: "Aurora Night Sky", kind: "video", meta: "4K HDR · 1.18 GB", image: IMAGES.night, date: "اليوم" },
  { id: "lf2", title: "Midnight Echoes", kind: "audio", meta: "FLAC · 128 MB", image: IMAGES.aurora2, date: "اليوم" },
  { id: "lf3", title: "Star Trails Pack", kind: "image", meta: "12 صور · 84 MB", image: IMAGES.lake, date: "أمس" },
  { id: "lf4", title: "Aurora Design System", kind: "file", meta: "PDF · 24 MB", image: IMAGES.aurora3, date: "أمس" },
  { id: "lf5", title: "Clouds Timelapse", kind: "video", meta: "8K · 3.42 GB", image: IMAGES.camp, date: "12 يونيو" },
  { id: "lf6", title: "Iridescent Waves", kind: "image", meta: "Heic · 8.2 MB", image: IMAGES.aurora, date: "10 يونيو" },
];

export const TOOLS = {
  converterFormats: ["MP4", "MKV", "WEBM", "MOV", "MP3", "FLAC", "WAV", "GIF"],
  imageFormats: ["JPG", "PNG", "WEBP", "AVIF"],
};

export const T = {
  ar: {
    home: "الرئيسية",
    downloads: "التحميلات",
    browser: "المتصفح",
    files: "المكتبة",
    tools: "الأدوات",
    settings: "الإعدادات",
    greeting: "مساء الخير، أحمد",
    hero1: "ماذا تريد أن",
    hero2: "تحمّل اليوم؟",
    heroSub: "الصق أي رابط. سنكتشف أفضل الجودات، ونحمّلها بأقصى سرعة.",
    placeholder: "الصق رابط فيديو، صوت، صورة أو ملف…",
    analyze: "تحليل",
    paste: "لصق",
    detect: "رابط مكتشف في الحافظة",
    recent: "آخر التحميلات",
    viewAll: "عرض الكل",
    video: "فيديو",
    audio: "صوت",
    image: "صور",
    file: "ملفات",
    smartChoices: "اختر ما تريد تحميله",
    fileName: "اسم الملف",
    duration: "المدة",
    publisher: "الناشر",
    published: "تاريخ النشر",
    size: "الحجم",
    exactSize: "الحجم الحقيقي",
    approx: "تقريبي",
    merge: "دمج تلقائي مع أفضل صوت",
    download: "تحميل",
    sheetHint: "كل الجودات مستخرجة من المصدر مباشرة",
    newDownload: "بدأ التحميل في الخلفية",
    all: "الكل",
    active: "جارٍ",
    queued: "في الانتظار",
    completed: "مكتمل",
    failed: "فاشل",
    currentSpeed: "السرعة الحالية",
    activeDownloads: "تحميلات نشطة",
    connections: "اتصال",
    pause: "إيقاف مؤقت",
    resume: "استكمال",
    cancel: "إلغاء",
    queue: "الطابور",
    analyzing: "جارٍ التحليل على مراحل…",
    stage0: "تطبيع الرابط",
    stage1: "قراءة ترويسات الملف",
    stage2: "المستخرج السريع",
    stage3: "كل الجودات والترجمات",
    detected: "اكتُشف",
    adblock: "مانع الإعلانات",
    blocked: "عنصر محجوب",
    sniffer: "الملفات المكتشفة",
    openIn: "فتح في المتصفح الداخلي",
    noResults: "لا توجد نتائج",
    lossless: "بدون فقد",
    transparent: "فقد غير ملحوظ",
    compress: "تصغير",
    convert: "تحويل",
    before: "قبل",
    after: "بعد",
    savings: "وفّرت",
    storage: "مساحة التخزين",
    vault: "القبو الخاص",
    vaultHint: "محمي بالبصمة وتشفير AES-256",
    theme: "المظهر",
    language: "اللغة",
    network: "الشبكة",
    privacy: "الخصوصية",
    adblockList: "قوائم الحجب والمتصفح",
    autoUpdate: "تحديث yt-dlp تلقائيًا",
    wifiOnly: "التحميل عبر Wi-Fi فقط",
    batteryOnly: "الشحن فقط",
    clipboard: "مراقبة الحافظة",
    doh: "DNS مشفّر (DoH)",
    connectionsMax: "أقصى عدد اتصالات",
    about: "حول التطبيق",
    copyright: "المسؤولية على المستخدم في احترام حقوق النشر.",
    uiPreview: "نموذج تفاعلي",
    play: "تشغيل",
    now: "يعمل الآن",
  },
  en: {
    home: "Home",
    downloads: "Downloads",
    browser: "Browser",
    files: "Library",
    tools: "Tools",
    settings: "Settings",
    greeting: "Good evening, Ahmed",
    hero1: "What would you like",
    hero2: "to download?",
    heroSub: "Paste any link. We discover the best qualities and download at full speed.",
    placeholder: "Paste a video, audio, image or file link…",
    analyze: "Analyze",
    paste: "Paste",
    detect: "Link detected in clipboard",
    recent: "Recent downloads",
    viewAll: "View all",
    video: "Video",
    audio: "Audio",
    image: "Images",
    file: "Files",
    smartChoices: "Choose what to download",
    fileName: "File name",
    duration: "Duration",
    publisher: "Publisher",
    published: "Published",
    size: "Size",
    exactSize: "Exact size",
    approx: "approx.",
    merge: "Auto-merge with best audio",
    download: "Download",
    sheetHint: "All qualities extracted directly from the source",
    newDownload: "Download started in background",
    all: "All",
    active: "Active",
    queued: "Queued",
    completed: "Completed",
    failed: "Failed",
    currentSpeed: "Current speed",
    activeDownloads: "active downloads",
    connections: "connections",
    pause: "Pause",
    resume: "Resume",
    cancel: "Cancel",
    queue: "Queued",
    analyzing: "Analyzing in parallel stages…",
    stage0: "Normalizing link",
    stage1: "Reading file headers",
    stage2: "Fast native extractor",
    stage3: "All qualities & subtitles",
    detected: "detected",
    adblock: "AdBlock",
    blocked: "items blocked",
    sniffer: "Discovered media",
    openIn: "Open in in-app browser",
    noResults: "No results",
    lossless: "Lossless",
    transparent: "Visually transparent",
    compress: "Compress",
    convert: "Convert",
    before: "Before",
    after: "After",
    savings: "Saved",
    storage: "Storage",
    vault: "Private vault",
    vaultHint: "Protected by biometrics + AES-256",
    theme: "Appearance",
    language: "Language",
    network: "Network",
    privacy: "Privacy",
    adblockList: "AdBlock & browser",
    autoUpdate: "Auto-update yt-dlp",
    wifiOnly: "Wi-Fi only downloads",
    batteryOnly: "Charging only",
    clipboard: "Clipboard monitor",
    doh: "Encrypted DNS (DoH)",
    connectionsMax: "Max connections",
    about: "About app",
    copyright: "Users are responsible for respecting copyright.",
    uiPreview: "Interactive preview",
    play: "Play",
    now: "Now playing",
  },
} as const;

export type TranslationKey = keyof typeof T.ar;

export function formatBytes(bytes: number, lang: Lang = "ar") {
  if (bytes >= 1_000_000_000) return `${(bytes / 1_000_000_000).toFixed(2)} GB`;
  if (bytes >= 1_000_000) return `${(bytes / 1_000_000).toFixed(1)} MB`;
  return `${Math.round(bytes / 1000)} KB · ${lang === "ar" ? "بايت" : "bytes"}`;
}

export function formatExact(bytes: number) {
  return `${bytes.toLocaleString("en-US")} bytes`;
}
