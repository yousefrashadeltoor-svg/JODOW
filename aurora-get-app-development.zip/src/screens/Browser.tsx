import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowDownToLine,
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronDown,
  Download,
  Globe2,
  Home,
  Lock,
  Menu,
  Play,
  Plus,
  RefreshCw,
  Shield,
  ShieldCheck,
  Sparkles,
  Video,
  Zap,
} from "lucide-react";
import { useApp } from "../state";
import { IMAGES } from "../data";
import { Badge, IconButton, Sheet, TypeIcon } from "../components/ui";

interface SniffedItem {
  id: string;
  name: string;
  kind: "video" | "audio" | "image" | "file";
  format: string;
  quality: string;
  size: number;
  sizeLabel: string;
  stream?: boolean;
  headers: boolean;
}

const DISCOVERED: SniffedItem[] = [
  { id: "s1", name: "aurora_master", kind: "video", format: "HLS · m3u8", quality: "1080p · 6.8 Mbps", size: 318_000_000, sizeLabel: "318 MB", stream: true, headers: true },
  { id: "s2", name: "aurora_2160p", kind: "video", format: "MP4 · H.265", quality: "4K HDR · 24 Mbps", size: 1_182_000_000, sizeLabel: "1.18 GB", headers: true },
  { id: "s3", name: "aurora_theme", kind: "audio", format: "M4A · AAC", quality: "256 Kbps · 48 kHz", size: 21_400_000, sizeLabel: "21.4 MB", headers: true },
  { id: "s4", name: "aurora_cover", kind: "image", format: "JPG", quality: "3840 × 2160", size: 8_240_000, sizeLabel: "8.2 MB", headers: true },
  { id: "s5", name: "aurora_ar", kind: "file", format: "SRT · UTF-8", quality: "Arabic subtitles", size: 38_240, sizeLabel: "38.2 KB", headers: false },
  { id: "s6", name: "aurora_dash", kind: "video", format: "DASH · mpd", quality: "Adaptive · 144p–4K", size: 2_840_000_000, sizeLabel: "≈ 2.84 GB", stream: true, headers: true },
  { id: "s7", name: "meta_aurora", kind: "file", format: "JSON", quality: "Full metadata", size: 12_620, sizeLabel: "12.6 KB", headers: false },
];

export function BrowserScreen() {
  const { t, lang, notify, startDownload, setScreen } = useApp();
  const [shieldOpen, setShieldOpen] = useState(false);
  const [snifferOpen, setSnifferOpen] = useState(false);
  const [added, setAdded] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [shieldOn, setShieldOn] = useState(true);
  const filtered = DISCOVERED.filter((item) => !added.includes(item.id));

  const reload = () => {
    setLoading(true);
    window.setTimeout(() => setLoading(false), 900);
  };

  const addItem = (item: SniffedItem) => {
    startDownload({
      title: item.name.includes("aurora") ? `Aurora — ${item.name}` : item.name,
      kind: item.kind,
      format: item.format.split(" · ")[0],
      quality: item.quality.split(" · ")[0],
      sizeBytes: item.size,
      thumbnail: IMAGES.night,
      source: "Browser sniff",
      approx: item.sizeLabel.startsWith("≈"),
    });
    setAdded((prev) => [...prev, item.id]);
  };

  const addAll = () => {
    filtered.forEach(addItem);
    setAdded(DISCOVERED.map((item) => item.id));
    notify(lang === "ar" ? "أُضيفت كل الملفات المكتشفة إلى الطابور" : "All discovered files added to queue");
    window.setTimeout(() => setSnifferOpen(false), 400);
  };

  return (
    <div className="relative flex min-h-[690px] flex-col">
      {/* browser chrome */}
      <div className="px-3 pt-1">
        <div className="flex items-center gap-1.5">
          <IconButton label="رجوع" size="sm">
            <ArrowRight size={13} />
          </IconButton>
          <IconButton label="تقدم" size="sm">
            <ArrowLeft size={13} />
          </IconButton>
          <div className="specular relative flex h-[34px] min-w-0 flex-1 items-center gap-1.5 rounded-[12px] border border-white/[.09] bg-white/[.05] px-2 backdrop-blur-xl">
            <Lock size={9} className="shrink-0 text-[#67e8c7]" />
            <div className="min-w-0 flex-1">
              <span dir="ltr" className="block truncate text-left font-display text-[8.5px] text-white/62">aurora-studio.com/night-sky</span>
            </div>
            <button aria-label="إعادة تحميل" onClick={reload} className="press text-white/35 hover:text-white/70">
              <RefreshCw size={10} className={loading ? "animate-spin" : ""} />
            </button>
            <button
              aria-label="حجب الإعلانات"
              onClick={() => setShieldOpen(!shieldOpen)}
              className={`press flex items-center gap-0.5 rounded-full px-1 py-0.5 text-[7.5px] font-semibold ${
                shieldOn ? "bg-[#67e8c7]/15 text-[#67e8c7]" : "bg-white/[.06] text-white/40"
              }`}
            >
              <Shield size={8} /> 24
            </button>
          </div>
          <IconButton label="تبويبات" size="sm">
            <div className="relative">
              <div className="grid h-3.5 w-3.5 place-items-center rounded-[3px] border border-white/40 text-[7px] font-bold text-white/70">2</div>
            </div>
          </IconButton>
        </div>
        <div className="mt-1.5 flex items-center gap-1.5 rounded-t-[12px] border border-b-0 border-white/[.07] bg-white/[.025] px-2 py-1">
          <span className="grid h-4 w-4 place-items-center rounded-full bg-[#ff0033] text-[7px] text-white">▶</span>
          <span className="flex-1 truncate text-[7.5px] text-white/55">Aurora Studio — Night Sky</span>
          <span className="h-1 w-1 rounded-full bg-[#67e8c7]" />
          <Plus size={9} className="text-white/35" />
          <ChevronDown size={9} className="text-white/25" />
        </div>
      </div>

      {/* webpage */}
      <div className="relative mx-3 mt-0 overflow-hidden rounded-b-[16px] border border-white/[.075] bg-[#0b0d14]">
        <div className="relative h-[176px] overflow-hidden">
          <img src={IMAGES.night} alt="Aurora Studio website preview" className="h-full w-full object-cover opacity-90" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0b0d14] via-[#0b0d14]/20 to-[#0b0d14]/65" />
          <div className="absolute inset-x-0 top-0 flex items-center justify-between px-3 py-2">
            <div className="flex items-center gap-1.5 rounded-full border border-white/15 bg-black/30 px-2 py-1 backdrop-blur-md">
              <span className="grid h-4 w-4 place-items-center rounded-full bg-white/90 font-display text-[8px] font-black text-black">A</span>
              <span className="font-display text-[8px] font-semibold tracking-wide text-white/85">AURORA STUDIO</span>
            </div>
            <div className="flex items-center gap-2 text-white/55">
              <Menu size={11} />
            </div>
          </div>
          <div className="absolute inset-x-0 bottom-3 px-3">
            <span className="rounded-full border border-white/15 bg-white/[.08] px-1.5 py-0.5 text-[6.5px] font-medium text-white/70 backdrop-blur-md">FIELD NOTES · 04</span>
            <h2 className="mt-1.5 font-display text-[17px] font-semibold leading-[1.25] tracking-tight text-white">
              Chasing the <span className="aurora-text">aurora</span><br />above the silence.
            </h2>
          </div>
        </div>

        <div className="px-3 pb-20 pt-2">
          <div className="flex items-center gap-2 border-b border-white/[.06] pb-1.5">
            {["Film", "Gallery", "Journal", "About"].map((tab, i) => (
              <span key={tab} className={`text-[7.5px] ${i === 0 ? "text-white/80" : "text-white/30"}`}>{tab}</span>
            ))}
            <span className="mr-auto rounded-[5px] bg-white/[.08] px-1.5 py-0.5 text-[6.5px] text-white/52">Subscribe</span>
          </div>
          <p className="mt-2 text-[7.5px] leading-[1.9] text-white/35">
            {lang === "ar"
              ? "في ليلة باردة فوق الجبال، يتحوّل السماء إلى لوحة من الضوء. نشاهد هنا تسجيلًا سينمائيًا بدقة 8K مع صوت محيطي وترجمة عربية."
              : "On a cold night above the mountains, the sky turns into a canvas of light. A cinematic 8K recording with spatial audio and Arabic subtitles."}
          </p>

          <div className="relative mt-2.5 overflow-hidden rounded-[13px] border border-white/[.1]">
            <img src={IMAGES.aurora} alt="" className="h-[102px] w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/5" />
            <button
              aria-label="تشغيل"
              onClick={() => notify(lang === "ar" ? "المعاينة داخل التطبيق عبر Media3 · ExoPlayer" : "In-app Media3 · ExoPlayer preview")}
              className="press absolute inset-0 grid place-items-center"
            >
              <span className="grid h-9 w-9 place-items-center rounded-full border border-white/25 bg-black/35 backdrop-blur-md">
                <Play size={13} className="fill-white text-white" />
              </span>
            </button>
            <div className="absolute bottom-1.5 right-2 left-2 flex items-center justify-between">
              <span className="font-display text-[7.5px] text-white/70">Northern Lights — 4K HDR</span>
              <span className="flex items-center gap-1 rounded bg-black/50 px-1 py-0.5 font-display text-[6.5px] text-white/70"><Video size={7} /> 18:42</span>
            </div>
          </div>

          <div className="mt-2.5 flex items-center gap-2 rounded-[9px] border border-[#67e8c7]/15 bg-[#67e8c7]/[.04] px-2 py-1.5">
            <ShieldCheck size={11} className="shrink-0 text-[#67e8c7]" />
            <div className="min-w-0 flex-1">
              <p className="text-[7px] font-medium text-white/62">{lang === "ar" ? "تم اجتياز تحدي Cloudflare بنجاح" : "Cloudflare challenge cleared"}</p>
              <p className="text-[6.5px] text-white/27">{lang === "ar" ? "cf_clearance + Cookies + UA نُقلت إلى CookieJar" : "cf_clearance + Cookies + UA synced to CookieJar"}</p>
            </div>
            <Badge className="border-[#67e8c7]/20 bg-[#67e8c7]/10 px-1.5 text-[6.5px] text-[#67e8c7]">SECURE</Badge>
          </div>
        </div>

        {/* adblock overlay */}
        <AnimatePresence>
          {shieldOpen && (
            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -6, scale: 0.97 }}
              transition={{ type: "spring", stiffness: 360, damping: 28 }}
              className="glass-deep absolute left-2 right-2 top-[43px] z-20 rounded-[17px] p-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`grid h-8 w-8 place-items-center rounded-[10px] ${shieldOn ? "bg-[#67e8c7]/15 text-[#67e8c7]" : "bg-white/[.06] text-white/40"}`}>
                    <Shield size={15} />
                  </span>
                  <div>
                    <p className="text-[10px] font-semibold text-white/85">{t("adblock")}</p>
                    <p className="text-[7px] text-white/35">EasyList · EasyPrivacy · uBlock</p>
                  </div>
                </div>
                <button
                  onClick={() => setShieldOn(!shieldOn)}
                  className={`press relative h-5 w-9 rounded-full border transition-colors ${shieldOn ? "border-transparent bg-[#67e8c7]/80" : "border-white/10 bg-white/10"}`}
                  aria-label={t("adblock")}
                >
                  <span className={`absolute top-[2px] h-3.5 w-3.5 rounded-full bg-white transition-all ${shieldOn ? "right-[2px]" : "right-[20px]"}`} />
                </button>
              </div>
              <div className="mt-2 grid grid-cols-3 gap-1.5">
                {[
                  { value: "24", label: lang === "ar" ? "عنصر محجوب" : "Blocked" },
                  { value: "9", label: lang === "ar" ? "متتبع" : "Trackers" },
                  { value: "3", label: lang === "ar" ? "نوافذ منبثقة" : "Popups" },
                ].map((stat) => (
                  <div key={stat.label} className="rounded-[9px] border border-white/[.055] bg-white/[.025] px-1.5 py-1 text-center">
                    <p className="font-display text-[13px] font-semibold text-white/80">{stat.value}</p>
                    <p className="text-[6.5px] text-white/30">{stat.label}</p>
                  </div>
                ))}
              </div>
              <div className="mt-2 flex items-center justify-between">
                <span className="text-[7px] text-white/28">{lang === "ar" ? "Cosmetic filtering مفعل · استثناءات الموقع" : "Cosmetic filtering on · Site exceptions"}</span>
                <button onClick={() => setShieldOpen(false)} className="press text-[7px] text-[var(--a2)]">{lang === "ar" ? "تم" : "Done"}</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* sniffer fab */}
        <button
          onClick={() => setSnifferOpen(true)}
          className="press absolute bottom-3 left-3 z-20 flex items-center gap-1.5 rounded-[15px] border border-white/[.16] bg-[linear-gradient(135deg,rgba(31,34,50,.92),rgba(13,15,24,.92))] px-2.5 py-2 shadow-[0_14px_35px_-10px_rgba(0,0,0,.85)] backdrop-blur-2xl"
        >
          <span className="relative grid h-7 w-7 place-items-center rounded-[9px] app-btn-primary">
            <ArrowDownToLine size={13} className="text-white" />
            <motion.span
              key={added.length}
              initial={{ scale: 0.4 }}
              animate={{ scale: 1 }}
              className="absolute -right-1.5 -top-1.5 grid h-[16px] min-w-[16px] place-items-center rounded-full border-2 border-[#0e1018] bg-[#67e8c7] px-[2px] text-[7px] font-bold text-[#041512]"
            >
              {filtered.length}
            </motion.span>
          </span>
          <span className="text-right">
            <span className="block text-[8px] font-medium leading-tight text-white/85">{t("sniffer")}</span>
            <span className="block text-[6.5px] leading-tight text-white/32">{lang === "ar" ? "التُقطت من الشبكة" : "Captured from network"}</span>
          </span>
          <Zap size={10} className="text-[#f5ce8a]" />
        </button>
      </div>

      {/* toolbar */}
      <div className="mt-auto px-3 pb-14 pt-2">
        <div className="flex items-center justify-around rounded-[15px] border border-white/[.07] bg-white/[.03] px-2 py-1.5 backdrop-blur-xl">
          <button onClick={() => notify(lang === "ar" ? "الرجوع للخلف" : "Going back")} className="press text-white/38 hover:text-white/75"><ArrowRight size={14} /></button>
          <button onClick={() => notify(lang === "ar" ? "الرجوع للأمام" : "Going forward")} className="press text-white/22"><ArrowLeft size={14} /></button>
          <button onClick={() => setScreen("home")} className="press text-white/38 hover:text-white/75"><Home size={13} /></button>
          <button onClick={() => notify(lang === "ar" ? "3 تبويبات مفتوحة" : "3 open tabs")} className="press relative text-white/38 hover:text-white/75">
            <div className="grid h-4 w-4 place-items-center rounded-[3px] border-[1.5px] border-current text-[6px] font-bold">3</div>
          </button>
          <button onClick={() => notify(lang === "ar" ? "الوضع المكتبي مفعّل" : "Desktop site enabled")} className="press text-white/38 hover:text-white/75"><Globe2 size={13} /></button>
          <button onClick={() => notify(lang === "ar" ? "وضع التصفح الخاص" : "Private browsing")} className="press text-white/38 hover:text-white/75"><Menu size={14} /></button>
        </div>
      </div>

      <Sheet
        open={snifferOpen}
        onClose={() => setSnifferOpen(false)}
        title={t("sniffer")}
        subtitle={lang === "ar" ? "ملفات ملتقطة من طلبات الشبكة · مع Cookies و Headers الكاملة" : "Captured network requests with full cookies & headers"}
        maxHeight="80%"
      >
        <div className="mb-2 flex items-center justify-between rounded-[11px] border border-white/[.06] bg-white/[.03] px-2.5 py-1.5">
          <div className="flex items-center gap-1.5 text-[8px] text-white/40">
            <Sparkles size={10} className="text-[var(--a2)]" />
            {filtered.length} {lang === "ar" ? "ملف جديد" : "new files"} · {added.length} {lang === "ar" ? "مضاف" : "added"}
          </div>
          <button onClick={addAll} className="press rounded-[7px] bg-[rgba(var(--a-glow),.15)] px-2 py-1 text-[7.5px] text-[var(--a1)]">
            {lang === "ar" ? "إضافة الكل" : "Add all"}
          </button>
        </div>
        <div className="space-y-1.5">
          {DISCOVERED.map((item, index) => {
            const isAdded = added.includes(item.id);
            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.04 }}
                className="flex items-center gap-2 rounded-[13px] border border-white/[.06] bg-white/[.025] p-2"
              >
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-[10px] border border-white/[.07] bg-black/20">
                  <TypeIcon kind={item.kind} size={14} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1">
                    <p className="truncate font-display text-[9px] font-medium text-white/75">{item.name}</p>
                    {item.stream && <span className="rounded-[3px] bg-[var(--a3)]/15 px-1 text-[6px] text-[var(--a3)]">STREAM</span>}
                  </div>
                  <p className="truncate text-[7px] text-white/32">{item.format} · {item.quality}</p>
                  <div className="mt-0.5 flex items-center gap-1.5 text-[6px] text-white/24">
                    <span className="font-display">{item.sizeLabel}</span>
                    {item.headers && <span className="flex items-center gap-0.5 text-[#67e8c7]/65"><Lock size={6} /> Headers</span>}
                    {item.stream && <span className="flex items-center gap-0.5"><ArrowDownToLine size={6} /> 32 segments</span>}
                  </div>
                </div>
                <button
                  onClick={() => addItem(item)}
                  className={`press flex h-6 w-[52px] shrink-0 items-center justify-center gap-1 rounded-[7px] text-[7.5px] font-medium ${
                    isAdded ? "border border-[#67e8c7]/25 bg-[#67e8c7]/10 text-[#67e8c7]" : "app-btn-primary text-white"
                  }`}
                >
                  {isAdded ? <><Check size={9} /> {lang === "ar" ? "أضيف" : "Added"}</> : <><Download size={9} /> {t("download")}</>}
                </button>
              </motion.div>
            );
          })}
        </div>
        <p className="mt-2 text-center text-[7px] text-white/20">{lang === "ar" ? "يُنقل كل تحميل مع Cookies + UA + Referer + Origin إلى محرك التطبيق" : "Every download carries Cookies + UA + Referer + Origin to the app engine"}</p>
      </Sheet>
    </div>
  );
}
