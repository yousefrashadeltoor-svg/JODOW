import { useState } from "react";
import { motion } from "framer-motion";
import {
  Activity,
  BadgeCheck,
  BatteryCharging,
  Check,
  ChevronLeft,
  Clock3,
  CloudDownload,
  Database,
  Fingerprint,
  Gauge,
  Globe2,
  Languages,
  Lock,
  Moon,
  ClipboardPaste,
  RefreshCw,
  RotateCcw,
  Shield,
  ShieldCheck,
  Sparkles,
  Trash2,
  UserRound,
  Wifi,
  Zap,
} from "lucide-react";
import { useApp } from "../state";
import { THEMES, formatBytes } from "../data";
import { AppHeader, Badge, GlassCard, IconButton, Toggle } from "../components/ui";

function SettingsSection({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <section className="mt-3">
      <div className="mb-1.5 flex items-center justify-between px-0.5">
        <h2 className="text-[9px] font-semibold tracking-wide text-white/55">{title}</h2>
        {subtitle && <span className="text-[6.5px] text-white/22">{subtitle}</span>}
      </div>
      <GlassCard className="overflow-hidden">
        <div className="divide-y divide-white/[.045]">{children}</div>
      </GlassCard>
    </section>
  );
}

function SettingRow({
  icon: Icon,
  title,
  subtitle,
  value,
  onClick,
  color = "var(--a1)",
}: {
  icon: React.ElementType;
  title: string;
  subtitle?: string;
  value?: React.ReactNode;
  onClick?: () => void;
  color?: string;
  last?: boolean;
}) {
  return (
    <div className="flex items-center gap-2.5 px-3 py-2.5">
      <span className="grid h-7 w-7 shrink-0 place-items-center rounded-[9px] border border-white/[.07] bg-white/[.035]" style={{ color }}>
        <Icon size={12} strokeWidth={1.9} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-[9px] font-medium text-white/72">{title}</p>
        {subtitle && <p className="mt-0.5 text-[7px] leading-4 text-white/28">{subtitle}</p>}
      </div>
      <div className="flex shrink-0 items-center gap-1.5">{value}</div>
      {onClick && <button aria-label={title} onClick={onClick} className="press text-white/20"><ChevronLeft size={12} /></button>}
    </div>
  );
}

export function SettingsScreen() {
  const { t, lang, setLang, theme, setTheme, notify } = useApp();
  const [wifiOnly, setWifiOnly] = useState(true);
  const [chargingOnly, setChargingOnly] = useState(false);
  const [clipboard, setClipboard] = useState(true);
  const [adblock, setAdblock] = useState(true);
  const [doh, setDoh] = useState(true);
  const [batterySaver, setBatterySaver] = useState(false);
  const [connections, setConnections] = useState(32);
  const [testing, setTesting] = useState(false);
  const [testSpeed, setTestSpeed] = useState<number | null>(null);
  const [updated, setUpdated] = useState(false);

  const speedTest = () => {
    if (testing) return;
    setTesting(true);
    setTestSpeed(0);
    let speed = 0;
    const timer = window.setInterval(() => {
      speed += Math.random() * 24 + 8;
      if (speed >= 96) {
        window.clearInterval(timer);
        setTestSpeed(96.4);
        setTesting(false);
        setConnections(32);
        notify(lang === "ar" ? "اقتراح: 32 اتصالًا للوصول لأقصى سرعة" : "Suggested: 32 connections for peak speed");
      } else {
        setTestSpeed(speed);
      }
    }, 260);
  };

  return (
    <div className="relative">
      <AppHeader
        title={t("settings")}
        subtitle={lang === "ar" ? "تحكّم كامل، خصوصية كاملة" : "Full control, privacy by design"}
        right={
          <>
            <IconButton label="تصفير" size="sm" onClick={() => notify(lang === "ar" ? "أُعيدت الإعدادات الافتراضية" : "Defaults restored")}>
              <RotateCcw size={12} />
            </IconButton>
            <Badge className="border-[#67e8c7]/20 bg-[#67e8c7]/[.07] px-1.5 text-[6.5px] text-[#67e8c7]">
              <ShieldCheck size={7} /> OFFLINE
            </Badge>
          </>
        }
      />
      <div className="thin-scroll max-h-[612px] overflow-y-auto px-4 pb-24">
        {/* profile */}
        <GlassCard glow className="p-3">
          <div className="absolute -left-8 -top-10 h-28 w-28 rounded-full bg-[rgba(var(--a-glow-2),.22)] blur-2xl" />
          <div className="relative flex items-center gap-2.5">
            <div className="relative">
              <div className="grid h-11 w-11 place-items-center rounded-[15px] border border-white/20 bg-[linear-gradient(145deg,rgba(155,114,203,.5),rgba(66,133,244,.32),rgba(217,101,112,.3))] font-display text-[16px] font-semibold text-white">
                A
              </div>
              <span className="absolute -bottom-0.5 -left-0.5 grid h-4 w-4 place-items-center rounded-full border-2 border-[#0d0f18] bg-[#67e8c7] text-[#06110e]"><Check size={8} strokeWidth={3} /></span>
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1">
                <h2 className="text-[12px] font-semibold text-white/90">{lang === "ar" ? "أحمد العتيبي" : "Ahmed Alotaibi"}</h2>
                <BadgeCheck size={10} className="text-[var(--a1)]" />
              </div>
              <p className="mt-0.5 text-[7.5px] text-white/30">{lang === "ar" ? "مساحة محلية · بدون حساب سحابي" : "Local profile · no cloud account"}</p>
              <div className="mt-1 flex gap-1">
                <Badge className="px-1.5 py-[1px] text-[6.5px] text-white/45"><Zap size={6} className="text-[#f5ce8a]" /> Pro local</Badge>
                <Badge className="px-1.5 py-[1px] text-[6.5px] text-white/45">{lang === "ar" ? "بدون تتبّع" : "No tracking"}</Badge>
              </div>
            </div>
            <button onClick={() => notify(lang === "ar" ? "الملف الشخصي محلي ولا يحتوي بيانات" : "Local profile holds no personal data")} className="press grid h-7 w-7 place-items-center rounded-full border border-white/[.09] bg-white/[.04] text-white/35">
              <UserRound size={12} />
            </button>
          </div>
          <div className="relative mt-2.5 grid grid-cols-3 gap-1">
            {[
              { label: lang === "ar" ? "إجمالي المُحمّل" : "Downloaded", value: "148 GB" },
              { label: lang === "ar" ? "وفّرت بالضغط" : "Saved", value: "12.6 GB" },
              { label: lang === "ar" ? "أكثر موقع" : "Top site", value: "YouTube" },
            ].map((stat) => (
              <div key={stat.label} className="rounded-[9px] border border-white/[.05] bg-black/20 px-1.5 py-1.5 text-center">
                <p className="font-display text-[11px] font-semibold text-white/80">{stat.value}</p>
                <p className="mt-0.5 text-[6px] text-white/28">{stat.label}</p>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* appearance */}
        <SettingsSection title={t("theme")} subtitle={`${THEMES.length} themes · Dark-first`}>
          <div className="p-2.5">
            <div className="grid grid-cols-3 gap-1.5">
              {THEMES.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setTheme(item.id)}
                  className={`press relative overflow-hidden rounded-[11px] border p-1.5 text-right ${
                    theme === item.id ? "border-white/25 bg-white/[.07]" : "border-white/[.055] bg-white/[.02]"
                  }`}
                >
                  <span className="flex h-3 w-full overflow-hidden rounded-full">
                    {item.colors.map((color) => <span key={color} className="h-full flex-1" style={{ background: color }} />)}
                  </span>
                  <span className="mt-1 flex items-center justify-between">
                    <span className="text-[7px] text-white/55">{lang === "ar" ? item.ar : item.en}</span>
                    {theme === item.id && <Check size={8} className="text-white/80" />}
                  </span>
                  {theme === item.id && <span className="absolute inset-0 rounded-[11px] ring-1 ring-inset ring-white/20" />}
                </button>
              ))}
            </div>
            <div className="mt-2 flex items-center justify-between rounded-[9px] bg-white/[.025] px-2 py-1.5">
              <span className="flex items-center gap-1.5 text-[7.5px] text-white/40"><Moon size={9} /> AMOLED dark · Light theme available</span>
              <Badge className="px-1 py-0 text-[6px] text-white/30">Aurora Glass</Badge>
            </div>
          </div>
        </SettingsSection>

        {/* language */}
        <SettingsSection title={t("language")} subtitle="RTL + LTR">
          <div className="flex items-center gap-2.5 px-3 py-2.5">
            <span className="grid h-7 w-7 shrink-0 place-items-center rounded-[9px] border border-white/[.07] bg-white/[.035] text-[var(--a2)]"><Languages size={12} /></span>
            <div className="flex-1">
              <p className="text-[9px] font-medium text-white/72">{lang === "ar" ? "العربية (افتراضي)" : "English"}</p>
              <p className="mt-0.5 text-[7px] text-white/28">{lang === "ar" ? "واجهة RTL كاملة · localisation عالية الجودة" : "Full RTL support · high-quality localization"}</p>
            </div>
            <div className="flex rounded-[8px] border border-white/[.08] bg-black/20 p-0.5">
              {(["ar", "en"] as const).map((code) => (
                <button
                  key={code}
                  onClick={() => setLang(code)}
                  className={`press rounded-[6px] px-2 py-1 text-[7px] font-medium ${lang === code ? "bg-white/[.12] text-white" : "text-white/30"}`}
                >
                  {code === "ar" ? "عربي" : "EN"}
                </button>
              ))}
            </div>
          </div>
        </SettingsSection>

        {/* speed test */}
        <GlassCard className="mt-3 p-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="grid h-7 w-7 place-items-center rounded-[9px] border border-white/[.08] bg-white/[.035] text-[#67e8c7]"><Gauge size={12} /></span>
              <div>
                <p className="text-[9px] font-medium text-white/72">{lang === "ar" ? "فحص السرعة والاتصالات" : "Speed & connections test"}</p>
                <p className="text-[6.5px] text-white/28">{lang === "ar" ? "اقتراح عدد الأجزاء الأمثل" : "Optimal segments suggestion"}</p>
              </div>
            </div>
            <button onClick={speedTest} className="press flex items-center gap-1 rounded-[8px] border border-white/[.09] bg-white/[.05] px-2 py-1.5 text-[7.5px] text-white/60">
              {testing ? <RefreshCw size={9} className="animate-spin" /> : <Zap size={9} />}
              {testing ? `${Math.round(testSpeed ?? 0)}` : (lang === "ar" ? "ابدأ" : "Start")}
            </button>
          </div>
          <div className="mt-2 flex items-center gap-2 rounded-[9px] bg-black/20 px-2 py-1.5">
            <Activity size={10} className="text-[#67e8c7]" />
            <div className="h-5 flex-1 flex items-end gap-[2px] overflow-hidden">
              {Array.from({ length: 24 }).map((_, index) => (
                <motion.span
                  key={index}
                  className="w-[3px] shrink-0 rounded-full bg-[linear-gradient(to_top,var(--a1),var(--a3))]"
                  animate={{ height: testing ? [4, 6 + Math.random() * 16, 4] : testSpeed ? 8 + Math.random() * 14 : 5 + (index % 5) * 2 }}
                  transition={{ duration: 0.7, repeat: testing ? Infinity : 0, delay: index * 0.025 }}
                />
              ))}
            </div>
            <span className="font-display text-[10px] font-semibold tabular-nums text-white/75">{testSpeed !== null ? testSpeed.toFixed(1) : "—"} <span className="text-[6px] font-normal text-white/30">MB/s</span></span>
          </div>
          {testSpeed !== null && testSpeed > 90 && (
            <p className="mt-1 flex items-center gap-1 text-[6.5px] text-[#67e8c7]/70"><Check size={8} /> {lang === "ar" ? "محسّن: 32 اتصالًا متوازيًا" : "Optimized: 32 parallel segments"}</p>
          )}
        </GlassCard>

        {/* network */}
        <SettingsSection title={t("network")}>
          <SettingRow
            icon={Wifi}
            title={t("wifiOnly")}
            subtitle={lang === "ar" ? "إيقاف البداية التلقائية على بيانات الجوال" : "Pause automatic starts on mobile data"}
            value={<Toggle on={wifiOnly} onChange={setWifiOnly} label={t("wifiOnly")} />}
            color="#67e8c7"
          />
          <SettingRow
            icon={BatteryCharging}
            title={t("batteryOnly")}
            subtitle={lang === "ar" ? "تحميل غير محدود عند توصيل الشاحن" : "Unrestricted downloads when charging"}
            value={<Toggle on={chargingOnly} onChange={setChargingOnly} label={t("batteryOnly")} />}
            color="#f5ce8a"
          />
          <SettingRow
            icon={Gauge}
            title={t("connectionsMax")}
            subtitle={lang === "ar" ? "تجزئة ذكية تتكيف تلقائيًا مع الشبكة" : "Adaptive segmentation up to 32"}
            value={
              <div className="flex items-center gap-1.5">
                <button onClick={() => setConnections(Math.max(8, connections - 4))} className="press grid h-5 w-5 place-items-center rounded-full border border-white/[.08] bg-white/[.04] text-[10px] text-white/50">−</button>
                <span className="w-5 text-center font-display text-[10px] font-semibold tabular-nums text-white/80">{connections}</span>
                <button onClick={() => setConnections(Math.min(32, connections + 4))} className="press grid h-5 w-5 place-items-center rounded-full border border-white/[.08] bg-white/[.04] text-[10px] text-white/50">+</button>
              </div>
            }
            color="var(--a1)"
          />
          <SettingRow
            icon={Globe2}
            title={t("doh")}
            subtitle={lang === "ar" ? "DoH مُشفّر + DNS Cache + Preconnect" : "Encrypted DoH + DNS cache + preconnect"}
            value={<Toggle on={doh} onChange={setDoh} label={t("doh")} />}
            color="var(--a2)"
            last
          />
        </SettingsSection>

        {/* downloads */}
        <SettingsSection title={t("downloads")}>
          <SettingRow
            icon={Clock3}
            title={lang === "ar" ? "جدولة التحميل والطابور" : "Schedule & smart queue"}
            subtitle={lang === "ar" ? "أولوية، سحب وإفلات، وإيقاف تلقائي" : "Priority, drag & drop, auto-pause"}
            onClick={() => notify(lang === "ar" ? "الجدولة: 02:00 — 06:00" : "Schedule: 02:00 — 06:00")}
            value={<Badge className="px-1.5 py-[1px] text-[6.5px] text-white/40">02:00 → 06:00</Badge>}
            color="var(--a3)"
          />
          <SettingRow
            icon={ClipboardPaste}
            title={t("clipboard")}
            subtitle={lang === "ar" ? "شريحة هادئة عند اكتشاف رابط" : "A quiet chip when a link is found"}
            value={<Toggle on={clipboard} onChange={setClipboard} label={t("clipboard")} />}
            color="var(--a1)"
          />
          <SettingRow
            icon={Database}
            title={lang === "ar" ? "فحص السلامة والـ Hash" : "Integrity & Hash checks"}
            subtitle={lang === "ar" ? "MD5 · SHA-1 · SHA-256 ومنع التكرار" : "MD5 · SHA-1 · SHA-256 & duplicate detection"}
            onClick={() => notify(lang === "ar" ? "منع التكرار مفعّل" : "Duplicate detection enabled")}
            value={<Badge className="border-[#67e8c7]/20 bg-[#67e8c7]/[.07] px-1.5 py-[1px] text-[6.5px] text-[#67e8c7]">ON</Badge>}
            color="#67e8c7"
            last
          />
        </SettingsSection>

        {/* privacy */}
        <SettingsSection title={t("privacy")}>
          <SettingRow
            icon={Shield}
            title={t("adblock")}
            subtitle={lang === "ar" ? "24 عنصرًا محجوبًا في الجلسة الحالية" : "24 items blocked this session"}
            value={<Toggle on={adblock} onChange={setAdblock} label={t("adblock")} />}
            color="#67e8c7"
          />
          <SettingRow
            icon={Fingerprint}
            title={t("vault")}
            subtitle={t("vaultHint")}
            onClick={() => notify(lang === "ar" ? "القبو متاح من المكتبة" : "Vault available in Library")}
            value={<Badge className="px-1.5 py-[1px] text-[6px] text-white/35">AES-256</Badge>}
            color="var(--a2)"
          />
          <SettingRow
            icon={BatteryCharging}
            title={lang === "ar" ? "وضع توفير البيانات والبطارية" : "Data & battery saver"}
            subtitle={lang === "ar" ? "تقليل الاتصالات والتحميل المسبق" : "Fewer connections, limited prefetch"}
            value={<Toggle on={batterySaver} onChange={setBatterySaver} label="battery saver" />}
            color="#f5ce8a"
          />
          <SettingRow
            icon={Lock}
            title={lang === "ar" ? "لا Firebase · لا تتبّع" : "No Firebase · No tracking"}
            subtitle={lang === "ar" ? "كل البيانات محلية ومشفّرة" : "All data stays local and encrypted"}
            value={<ShieldCheck size={13} className="text-[#67e8c7]" />}
            color="#67e8c7"
            last
          />
        </SettingsSection>

        {/* updates */}
        <SettingsSection title={lang === "ar" ? "التحديثات والنسخ" : "Updates & backup"}>
          <SettingRow
            icon={CloudDownload}
            title={lang === "ar" ? "تحديث محرك الاستخراج" : "Extractor engine update"}
            subtitle={updated ? (lang === "ar" ? "yt-dlp 2026.02.18 · محدث الآن" : "yt-dlp 2026.02.18 · updated") : (lang === "ar" ? "yt-dlp 2026.01.29 · تحديث متاح" : "yt-dlp 2026.01.29 · update available")}
            value={
              <button
                onClick={() => {
                  setUpdated(true);
                  notify(lang === "ar" ? "تم تحديث yt-dlp إلى 2026.02.18" : "yt-dlp updated to 2026.02.18");
                }}
                className="press rounded-[7px] bg-[rgba(var(--a-glow),.14)] px-2 py-1 text-[7px] text-[var(--a1)]"
              >
                {updated ? <Check size={8} /> : (lang === "ar" ? "تحديث" : "Update")}
              </button>
            }
            color="var(--a1)"
          />
          <SettingRow
            icon={Database}
            title={lang === "ar" ? "نسخ احتياطي واستعادة" : "Backup & restore"}
            subtitle={lang === "ar" ? "السجل والإعدادات بصيغة JSON" : "History & settings as JSON"}
            onClick={() => notify(lang === "ar" ? "تم تصدير نسخة احتياطية مشفرة" : "Encrypted backup exported")}
            value={<Badge className="px-1.5 py-[1px] text-[6px] text-white/35">JSON</Badge>}
            color="var(--a2)"
          />
          <SettingRow
            icon={Trash2}
            title={lang === "ar" ? "مسح ذاكرة التحليل المؤقتة" : "Clear analyzer cache"}
            subtitle={lang === "ar" ? "34.8 MB · TTL ذكي" : "34.8 MB · smart TTL"}
            onClick={() => notify(lang === "ar" ? "تم مسح الذاكرة المؤقتة" : "Cache cleared")}
            value={<span className="font-display text-[8px] text-white/30">{formatBytes(34_800_000)}</span>}
            color="var(--a3)"
            last
          />
        </SettingsSection>

        {/* about */}
        <div className="mt-3 rounded-[16px] border border-white/[.055] bg-white/[.018] p-3 text-center">
          <div className="mx-auto mb-2 grid h-9 w-9 place-items-center rounded-[12px] bg-[linear-gradient(140deg,var(--a1),var(--a2),var(--a3))]">
            <Sparkles size={16} className="text-white" />
          </div>
          <p className="font-display text-[10px] font-semibold text-white/70">Aurora Get <span className="text-[7px] font-normal text-white/30">v1.0.0 · Aurora Glass</span></p>
          <p className="mx-auto mt-1 max-w-[235px] text-[6.5px] leading-4 text-white/24">{t("copyright")}</p>
          <div className="mt-1.5 flex items-center justify-center gap-2 text-[6px] text-white/20">
            <span className="flex items-center gap-0.5"><BadgeCheck size={7} /> minSdk 24</span>
            <span>·</span>
            <span className="flex items-center gap-0.5"><Globe2 size={7} /> targetSdk 35</span>
            <span>·</span>
            <span className="flex items-center gap-0.5"><ShieldCheck size={7} /> No Material</span>
          </div>
        </div>
      </div>
    </div>
  );
}
