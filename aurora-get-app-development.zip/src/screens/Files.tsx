import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Fingerprint,
  Grid2X2,
  HardDrive,
  LayoutList,
  Lock,
  MoreVertical,
  Play,
  Search,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { useApp } from "../state";
import { FILES, type MediaKind } from "../data";
import { AppHeader, Badge, FilterPill, GlassCard, IconButton, TypeIcon } from "../components/ui";

type FileKind = "all" | MediaKind;

export function FilesScreen() {
  const { t, lang, setNowPlaying, notify, setScreen } = useApp();
  const [filter, setFilter] = useState<FileKind>("all");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [vaultOpen, setVaultOpen] = useState(false);
  const [vaultUnlocked, setVaultUnlocked] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [host, setHost] = useState<HTMLElement | null>(null);
  useEffect(() => {
    setHost(document.getElementById("phone-overlay"));
  }, []);

  const files = useMemo(() => FILES.filter((file) => filter === "all" || file.kind === filter), [filter]);

  const openFile = (file: (typeof FILES)[number]) => {
    if (file.kind === "video" || file.kind === "audio" || file.kind === "image") {
      setNowPlaying({ title: file.title, subtitle: `${file.meta} · ${file.date}`, image: file.image });
    } else {
      notify(lang === "ar" ? "جارٍ فتح المستند في العارض المدمج…" : "Opening document in the built-in viewer…");
    }
  };

  return (
    <div className="relative">
      <AppHeader
        title={t("files")}
        subtitle={lang === "ar" ? "كل ما حمّلته، مرتّبًا وخاصًا" : "Everything you downloaded, organized & private"}
        right={
          <>
            <IconButton label="بحث" size="sm" active={searchOpen} onClick={() => setSearchOpen(!searchOpen)}>
              <Search size={13} />
            </IconButton>
            <IconButton label="عرض" size="sm" onClick={() => setView(view === "grid" ? "list" : "grid")}>
              {view === "grid" ? <LayoutList size={13} /> : <Grid2X2 size={13} />}
            </IconButton>
          </>
        }
      />
      <div className="px-4">
        <AnimatePresence>
          {searchOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0, marginBottom: 0 }}
              animate={{ opacity: 1, height: 36, marginBottom: 10 }}
              exit={{ opacity: 0, height: 0, marginBottom: 0 }}
              className="overflow-hidden"
            >
              <div className="flex h-9 items-center gap-2 rounded-[12px] border border-white/[.08] bg-white/[.04] px-2.5">
                <Search size={11} className="text-white/30" />
                <input autoFocus placeholder={lang === "ar" ? "ابحث في ملفاتك…" : "Search your files…"} className="flex-1 bg-transparent text-[9px] text-white/70 outline-none placeholder:text-white/25" />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* storage overview */}
        <GlassCard glow className="p-3">
          <div className="absolute -right-8 -top-10 h-28 w-28 rounded-full bg-[rgba(var(--a-glow),.18)] blur-2xl" />
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-[10px] border border-white/10 bg-white/[.045]">
                <HardDrive size={14} className="text-[var(--a1)]" />
              </span>
              <div>
                <p className="text-[9.5px] font-medium text-white/72">{t("storage")}</p>
                <p className="mt-0.5 font-display text-[8px] text-white/32" dir="ltr">12.4 GB / 128 GB</p>
              </div>
            </div>
            <div className="text-left">
              <span className="font-display text-[14px] font-semibold text-white">9.7%</span>
              <p className="text-[6.5px] text-white/28">{lang === "ar" ? "مستخدم" : "used"}</p>
            </div>
          </div>
          <div className="mt-2.5 flex h-[6px] gap-[2px] overflow-hidden rounded-full">
            <div className="h-full rounded-full bg-[var(--a1)]" style={{ width: "39%" }} />
            <div className="h-full rounded-full bg-[var(--a2)]" style={{ width: "28%" }} />
            <div className="h-full rounded-full bg-[var(--a3)]" style={{ width: "21%" }} />
            <div className="h-full rounded-full bg-[#67e8c7]" style={{ width: "12%" }} />
            <div className="h-full flex-1 rounded-full bg-white/[.05]" />
          </div>
          <div className="mt-2 flex items-center gap-3">
            {[
              { color: "var(--a1)", label: t("video"), value: "4.8 GB" },
              { color: "var(--a2)", label: t("audio"), value: "3.4 GB" },
              { color: "var(--a3)", label: t("image"), value: "2.6 GB" },
              { color: "#67e8c7", label: t("file"), value: "1.6 GB" },
            ].map((item) => (
              <span key={item.label} className="flex items-center gap-1 text-[7px] text-white/32">
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: item.color }} />
                {item.label} <span className="font-display text-white/48">{item.value}</span>
              </span>
            ))}
          </div>
        </GlassCard>

        {/* vault */}
        <motion.button
          whileTap={{ scale: 0.985 }}
          onClick={() => {
            if (!vaultUnlocked) {
              setVaultOpen(true);
            } else {
              notify(lang === "ar" ? "القبو مفتوح في وضع المعاينة" : "Vault opened in preview");
            }
          }}
          className="press relative mt-2 flex w-full items-center gap-2.5 overflow-hidden rounded-[18px] border border-white/[.09] bg-[linear-gradient(120deg,rgba(155,114,203,.17),rgba(66,133,244,.08),rgba(217,101,112,.08))] p-2.5 text-right backdrop-blur-xl"
        >
          <span className="absolute -left-3 -top-5 h-16 w-16 rounded-full bg-[rgba(var(--a-glow-2),.2)] blur-2xl" />
          <span className="relative grid h-9 w-9 shrink-0 place-items-center rounded-[12px] border border-white/15 bg-white/[.08]">
            {vaultUnlocked ? <ShieldCheck size={16} className="text-[#67e8c7]" /> : <Fingerprint size={16} className="text-white/85" />}
          </span>
          <div className="relative min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <p className="text-[10px] font-medium text-white/88">{t("vault")}</p>
              <Badge className="border-[var(--a3)]/25 bg-[var(--a3)]/10 px-1 py-0 text-[6px] text-[var(--a3)]">AES-256</Badge>
            </div>
            <p className="mt-0.5 text-[7px] text-white/35">{vaultUnlocked ? (lang === "ar" ? "3 ملفات محمية · مفتوح مؤقتًا" : "3 protected items · temporarily unlocked") : t("vaultHint")}</p>
          </div>
          <span className="relative rounded-full border border-white/[.09] bg-black/20 px-2 py-1 text-[7px] text-white/52">
            {vaultUnlocked ? (lang === "ar" ? "عرض" : "Open") : (lang === "ar" ? "فتح" : "Unlock")}
          </span>
        </motion.button>

        {/* suggestions */}
        <div className="mt-2 flex items-center gap-2 rounded-[13px] border border-white/[.055] bg-white/[.025] px-2.5 py-1.5">
          <Sparkles size={11} className="shrink-0 text-[#f5ce8a]" />
          <p className="flex-1 text-[7.5px] leading-4 text-white/38">
            {lang === "ar" ? "يمكنك توفير 2.6 GB بضغط 4 ملفات فيديو بدون تغيير الجودة المرئية." : "Save 2.6 GB by compressing 4 videos with visually transparent quality."}
          </p>
          <button onClick={() => setScreen("tools")} className="press shrink-0 rounded-[7px] bg-[rgba(var(--a-glow),.14)] px-1.5 py-1 text-[7px] text-[var(--a1)]">{t("compress")}</button>
        </div>

        {/* filters */}
        <div className="thin-scroll mt-2.5 flex items-center gap-1.5 overflow-x-auto pb-1">
          {(["all", "video", "audio", "image", "file"] as FileKind[]).map((kind) => (
            <FilterPill key={kind} active={filter === kind} onClick={() => setFilter(kind)} count={kind === "all" ? FILES.length : FILES.filter((file) => file.kind === kind).length}>
              {kind !== "all" && <TypeIcon kind={kind} size={10} />}
              {kind === "all" ? t("all") : t(kind)}
            </FilterPill>
          ))}
        </div>

        {/* files */}
        <div className={view === "grid" ? "mt-1 grid grid-cols-2 gap-2 pb-5" : "mt-1 space-y-1.5 pb-5"}>
          <AnimatePresence mode="popLayout">
            {files.map((file, index) =>
              view === "grid" ? (
                <motion.button
                  layout
                  key={file.id}
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.96 }}
                  transition={{ delay: index * 0.045, type: "spring", stiffness: 300, damping: 26 }}
                  onClick={() => openFile(file)}
                  className="press group relative overflow-hidden rounded-[16px] border border-white/[.075] bg-white/[.025] text-right"
                >
                  <div className="relative h-[94px] overflow-hidden">
                    <img src={file.image} alt="" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                    <span className="absolute inset-0 bg-gradient-to-t from-[#0a0b12] via-transparent to-black/20" />
                    <span className="absolute left-1.5 top-1.5 rounded-[6px] border border-white/12 bg-black/35 p-1 backdrop-blur-md">
                      <TypeIcon kind={file.kind} size={10} />
                    </span>
                    {file.kind !== "file" && (
                      <span className="absolute bottom-1.5 left-1.5 grid h-6 w-6 place-items-center rounded-full border border-white/20 bg-black/40 backdrop-blur-md">
                        <Play size={9} className="ml-0.5 fill-white text-white" />
                      </span>
                    )}
                  </div>
                  <div className="p-2">
                    <p className="truncate text-[9px] font-medium text-white/82">{file.title}</p>
                    <div className="mt-0.5 flex items-center justify-between">
                      <span className="font-display text-[6.8px] text-white/32" dir="ltr">{file.meta}</span>
                      <span className="text-[6px] text-white/22">{file.date}</span>
                    </div>
                  </div>
                </motion.button>
              ) : (
                <motion.button
                  layout
                  key={file.id}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  transition={{ delay: index * 0.035 }}
                  onClick={() => openFile(file)}
                  className="press flex w-full items-center gap-2.5 rounded-[13px] border border-white/[.06] bg-white/[.025] p-2 text-right"
                >
                  <div className="relative h-9 w-11 shrink-0 overflow-hidden rounded-[8px]">
                    <img src={file.image} alt="" className="h-full w-full object-cover" />
                    <span className="absolute inset-0 bg-black/25" />
                    <span className="absolute inset-0 grid place-items-center"><TypeIcon kind={file.kind} size={11} /></span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[9px] font-medium text-white/78">{file.title}</p>
                    <p className="font-display text-[7px] text-white/30" dir="ltr">{file.meta}</p>
                  </div>
                  <span className="text-[7px] text-white/25">{file.date}</span>
                  <MoreVertical size={11} className="text-white/25" />
                </motion.button>
              ),
            )}
          </AnimatePresence>
        </div>
      </div>

      {(host ? createPortal(<AnimatePresence>
        {vaultOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-[70] grid place-items-center bg-[#04050a]/80 px-6 backdrop-blur-xl"
          >
            <motion.div
              initial={{ scale: 0.92, y: 14 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.92, y: 14 }}
              transition={{ type: "spring", stiffness: 320, damping: 26 }}
              className="glass-deep relative w-full overflow-hidden rounded-[26px] p-5 text-center"
            >
              <div className="absolute inset-x-0 top-0 h-24 bg-[radial-gradient(circle_at_50%_0%,rgba(var(--a-glow),.28),transparent_70%)]" />
              <div className="relative mx-auto grid h-16 w-16 place-items-center rounded-[22px] border border-white/[.12] bg-white/[.055]">
                <motion.span
                  animate={{ scale: [1, 1.08, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="absolute inset-2 rounded-[17px] border border-[var(--a1)]/20"
                />
                <Fingerprint size={30} className="text-[var(--a1)]" strokeWidth={1.4} />
              </div>
              <h3 className="mt-3 text-[14px] font-semibold text-white">{t("vault")}</h3>
              <p className="mx-auto mt-1 max-w-[210px] text-[8.5px] leading-4 text-white/35">{lang === "ar" ? "المس ببصمتك لفتح الملفات المشفرة محليًا. لا تغادر البيانات جهازك أبدًا." : "Touch the sensor to unlock locally encrypted files. Data never leaves your device."}</p>
              <button
                onClick={() => {
                  setVaultUnlocked(true);
                  setVaultOpen(false);
                  notify(lang === "ar" ? "تم التحقق · القبو مفتوح مؤقتًا" : "Verified · vault temporarily unlocked");
                }}
                className="press app-btn-primary mt-4 flex w-full items-center justify-center gap-1.5 rounded-[12px] py-2.5 text-[10px] font-medium text-white"
              >
                <Lock size={12} /> {lang === "ar" ? "فتح بالبصمة" : "Unlock with biometrics"}
              </button>
              <button onClick={() => setVaultOpen(false)} className="press mt-2 w-full py-1 text-[8px] text-white/30">{t("cancel")}</button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>, host) : null)}
    </div>
  );
}
