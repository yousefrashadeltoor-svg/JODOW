import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowUpLeft,
  BadgeCheck,
  Bell,
  Box,
  CalendarDays,
  Check,
  ChevronLeft,
  ClipboardPaste,
  Clock3,
  Download,
  ExternalLink,
  FileJson2,
  Folder,
  Globe2,
  Link2,
  Loader2,
  Merge,
  Pencil,
  Play,
  ScanLine,
  ShieldCheck,
  Sparkles,
  UserRound,
  Wand2,
  X,
  Zap,
} from "lucide-react";
import { useApp } from "../state";
import {
  formatBytes,
  formatExact,
  type FormatOption,
  type MediaKind,
  type SiteAnalysis,
} from "../data";
import {
  Badge,
  GlassCard,
  IconButton,
  ProgressBar,
  Sheet,
  SmartKindButton,
  TypeIcon,
} from "../components/ui";

const SAMPLE_YOUTUBE = "https://youtube.com/watch?v=aurora4k";
const SAMPLE_TIKTOK = "https://tiktok.com/@aurora.tales/video/7412";

function parseSize(value: string): number {
  const match = value.replace(/,/g, "").match(/([\d.]+)\s*(GB|MB|KB)/i);
  if (!match) return 48_000_000;
  const amount = Number(match[1]);
  const unit = match[2].toUpperCase();
  if (unit === "GB") return amount * 1_000_000_000;
  if (unit === "MB") return amount * 1_000_000;
  return amount * 1_000;
}

const KIND_ORDER: MediaKind[] = ["audio", "image", "video", "file"];

export function HomeScreen() {
  const {
    t,
    lang,
    url,
    setUrl,
    analyze,
    analyzing,
    analysis,
    startDownload,
    setScreen,
    downloads,
    notify,
    setNowPlaying,
  } = useApp();
  const [sheetKind, setSheetKind] = useState<MediaKind | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [filename, setFilename] = useState<string | null>(null);
  const [showClipboard, setShowClipboard] = useState(true);
  const [editingName, setEditingName] = useState(false);

  const counts = useMemo(() => {
    const result: Record<MediaKind, number> = { video: 0, audio: 0, image: 0, file: 0 };
    if (!analysis) return result;
    KIND_ORDER.forEach((kind) => {
      result[kind] = analysis.formats[kind].length;
    });
    return result;
  }, [analysis]);

  const activeDownloads = downloads.filter((item) => item.status !== "completed").slice(0, 2);
  const sheetFormats = sheetKind && analysis ? analysis.formats[sheetKind] : [];
  const sheetLabel = sheetKind ? t(sheetKind) : "";

  const pickSample = (value: string) => {
    setUrl(value);
    setShowClipboard(false);
    analyze(value);
  };

  const handleDownload = (format: FormatOption) => {
    if (!analysis) return;
    setSelected(format.id);
    const needsMerge = format.kind === "video" && /AV1|VP9/.test(format.codec);
    window.setTimeout(() => {
      startDownload({
        title: (filename ?? analysis.title).replace(/\s+/g, "-").slice(0, 40),
        kind: format.kind,
        format: format.format,
        quality: format.quality,
        sizeBytes: parseSize(format.size) * (needsMerge ? 1.08 : 1),
        thumbnail: analysis.thumbnail,
        source: analysis.source,
        approx: format.approx,
      });
      setSelected(null);
      setSheetKind(null);
      setScreen("downloads");
    }, 380);
  };

  return (
    <div className="relative flex flex-col">
      {/* brand header */}
      <header className="flex items-center justify-between px-4 pb-1 pt-0.5">
        <div className="flex items-center gap-2">
          <div className="relative">
            <div
              className="grid h-9 w-9 place-items-center rounded-[13px]"
              style={{ background: "linear-gradient(140deg, var(--a1), var(--a2) 58%, var(--a3))" }}
            >
              <svg width="21" height="21" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M12 3.4c.6 4.5 3.3 7.2 7.8 7.8-4.5.6-7.2 3.3-7.8 7.8-.6-4.5-3.3-7.2-7.8-7.8 4.5-.6 7.2-3.3 7.8-7.8Z" fill="white" fillOpacity=".97" />
              </svg>
            </div>
            <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full border border-[#0b0d14] bg-[#67e8c7]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-display text-[14px] font-semibold tracking-[-0.01em] text-white">Aurora Get</span>
              <Badge className="border-white/[.1] bg-white/[.055] px-1.5 py-[2px] text-[7.5px] text-white/55">BETA</Badge>
            </div>
            <p className="text-[8px] tracking-[0.06em] text-white/30">{lang === "ar" ? "مدير التحميل الذكي" : "SMART DOWNLOADER"}</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <IconButton label="مسح QR" size="sm">
            <ScanLine size={14} />
          </IconButton>
          <IconButton label="الإشعارات" size="sm" className="relative">
            <Bell size={14} />
            <span className="absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-[var(--a3)] shadow-[0_0_8px_var(--a3)]" />
          </IconButton>
          <button
            onClick={() => setScreen("settings")}
            aria-label="الملف الشخصي"
            className="press grid h-8 w-8 place-items-center rounded-full border border-white/15 bg-[linear-gradient(145deg,rgba(155,114,203,.42),rgba(66,133,244,.32))]"
          >
            <UserRound size={14} className="text-white/90" />
          </button>
        </div>
      </header>

      <div className="px-4 pt-4">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ type: "spring", stiffness: 220, damping: 24 }}
        >
          <div className="mb-1.5 flex items-center gap-1.5 text-[9px] text-white/40">
            <Sparkles size={10} className="text-[var(--a2)]" />
            {t("greeting")}
          </div>
          <h1 className="text-[25px] font-semibold leading-[1.38] tracking-[-0.025em] text-white">
            {t("hero1")} <br />
            <span className="aurora-text">{t("hero2")}</span>
          </h1>
          <p className="mt-1.5 max-w-[280px] text-[10px] leading-[1.9] text-white/38">{t("heroSub")}</p>
        </motion.div>

        {/* Glowing URL field */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.08, type: "spring", stiffness: 220, damping: 25 }}
          className="relative mt-4"
        >
          <span className="absolute -inset-2 -z-10 rounded-[30px] bg-[radial-gradient(ellipse_at_50%_100%,rgba(var(--a-glow),.22),transparent_65%)] blur-md" />
          <div
            className={`specular noise relative overflow-hidden rounded-[24px] border bg-[linear-gradient(150deg,rgba(255,255,255,.09),rgba(255,255,255,.028))] p-2.5 backdrop-blur-2xl ${
              analyzing ? "glow-ring border-transparent" : "border-white/[.11]"
            }`}
          >
            <div className="flex items-center gap-2 rounded-[16px] border border-white/[.06] bg-black/25 px-2.5 py-2">
              <Link2 size={14} className="shrink-0 text-white/30" />
              <input
                dir="ltr"
                value={url}
                onChange={(event) => setUrl(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") analyze();
                }}
                placeholder={t("placeholder")}
                className="min-w-0 flex-1 bg-transparent text-left font-display text-[10px] font-light tracking-wide text-white/85 outline-none placeholder:text-right placeholder:font-sans placeholder:text-white/22"
              />
              {url ? (
                <button aria-label="مسح" onClick={() => setUrl("")} className="text-white/35 hover:text-white/70">
                  <X size={13} />
                </button>
              ) : (
                <button
                  onClick={() => pickSample(SAMPLE_YOUTUBE)}
                  aria-label={t("paste")}
                  className="press flex items-center gap-1 rounded-full border border-white/[.08] bg-white/[.055] px-2 py-[3px] text-[8px] text-white/60"
                >
                  <ClipboardPaste size={10} />
                  {t("paste")}
                </button>
              )}
            </div>
            <div className="mt-2 flex items-center gap-2">
              <div className="flex min-w-0 flex-1 items-center gap-1 px-1">
                <span className="h-1 w-1 shrink-0 rounded-full bg-[#67e8c7]" />
                <span className="truncate text-[8px] text-white/32">
                  {lang === "ar" ? "يدعم +1800 موقع · HLS · DASH · مباشر" : "1,800+ sites · HLS · DASH · Direct"}
                </span>
              </div>
              <button
                onClick={() => analyze()}
                disabled={analyzing}
                className="press app-btn-primary relative flex h-[32px] min-w-[94px] items-center justify-center gap-1.5 rounded-[12px] px-3 text-[10px] font-semibold text-white disabled:opacity-90"
              >
                {analyzing ? (
                  <>
                    <Loader2 size={12} className="animate-spin" />
                    {t("analyze")}…
                  </>
                ) : (
                  <>
                    <Zap size={12} className="fill-white/90" />
                    {t("analyze")}
                  </>
                )}
              </button>
            </div>
          </div>
        </motion.div>

        {/* Clipboard chip */}
        <AnimatePresence>
          {showClipboard && !analyzing && (
            <motion.button
              initial={{ opacity: 0, y: -5, height: 0 }}
              animate={{ opacity: 1, y: 0, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              onClick={() => pickSample(SAMPLE_TIKTOK)}
              className="press mt-2 flex w-full items-center gap-2 rounded-[13px] border border-white/[.065] bg-white/[.032] px-2.5 py-1.5 text-right backdrop-blur-lg"
            >
              <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-[rgba(var(--a-glow),.14)] text-[var(--a1)]">
                <ClipboardPaste size={11} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[8.5px] font-medium text-white/70">{t("detect")}</span>
                <span className="block truncate font-display text-[7.5px] text-white/28" dir="ltr">tiktok.com/@aurora.tales/video/7412</span>
              </span>
              <span className="rounded-full border border-white/10 px-2 py-0.5 text-[8px] text-white/55">{t("paste")}</span>
            </motion.button>
          )}
        </AnimatePresence>

        <div className="mt-2 flex items-center gap-1.5">
          <span className="text-[8px] text-white/25">{lang === "ar" ? "جرّب:" : "Try:"}</span>
          {[
            { label: "YouTube", value: SAMPLE_YOUTUBE, color: "#ff4e5b", icon: "▶" },
            { label: "TikTok", value: SAMPLE_TIKTOK, color: "#43e6e0", icon: "♪" },
            { label: "Vimeo", value: "https://vimeo.com/aurora-night", color: "#7dd3fc", icon: "V" },
          ].map((site) => (
            <button
              key={site.label}
              onClick={() => pickSample(site.value)}
              className="press flex items-center gap-1 rounded-full border border-white/[.06] bg-white/[.028] px-2 py-[3px] text-[8px] text-white/42 hover:text-white/70"
            >
              <span style={{ color: site.color }} className="font-display text-[9px] font-bold">{site.icon}</span>
              {site.label}
            </button>
          ))}
          <button
            onClick={() => setScreen("browser")}
            className="press mr-auto flex items-center gap-1 text-[8px] text-[var(--a2)]"
          >
            {t("openIn")}
            <ExternalLink size={8} />
          </button>
        </div>

        {/* Analyzer area */}
        <div className="relative mt-4">
          <AnimatePresence mode="wait">
            {analyzing ? (
              <AnalyzingCard key="loading" />
            ) : analysis ? (
              <motion.div
                key={analysis.domain}
                initial={{ opacity: 0, y: 16, scale: 0.985, filter: "blur(8px)" }}
                animate={{ opacity: 1, y: 0, scale: 1, filter: "blur(0px)" }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ type: "spring", stiffness: 240, damping: 27 }}
              >
                <InfoCard
                  analysis={analysis}
                  filename={filename ?? analysis.filename}
                  editing={editingName}
                  setEditing={setEditingName}
                  setFilename={setFilename}
                  onPlay={() =>
                    setNowPlaying({
                      title: analysis.title,
                      subtitle: `${analysis.channel} · ${analysis.duration}`,
                      image: analysis.thumbnail,
                    })
                  }
                  counts={counts}
                  onOpenKind={(kind) => setSheetKind(kind)}
                />
              </motion.div>
            ) : null}
          </AnimatePresence>
        </div>

        {/* Recent downloads */}
        <div className="mt-4 flex items-center justify-between px-0.5">
          <div className="flex items-center gap-1.5">
            <h2 className="text-[12px] font-semibold text-white/90">{t("recent")}</h2>
            <Badge className="px-1.5 py-[1px] text-[7.5px] text-white/45">{activeDownloads.length}</Badge>
          </div>
          <button onClick={() => setScreen("downloads")} className="press flex items-center gap-1 text-[9px] text-white/38">
            {t("viewAll")}
            <ChevronLeft size={11} />
          </button>
        </div>

        <div className="mt-2 space-y-2 pb-2">
          {activeDownloads.map((item) => {
            const percent = (item.downloadedBytes / item.sizeBytes) * 100;
            return (
              <GlassCard key={item.id} className="p-2.5">
                <div className="flex items-center gap-2.5">
                  <div className="relative h-10 w-12 shrink-0 overflow-hidden rounded-[10px]">
                    <img src={item.thumbnail} alt="" className="h-full w-full object-cover" />
                    <span className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <span className="absolute bottom-0.5 right-0.5"><TypeIcon kind={item.kind} size={10} /></span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-[10px] font-medium text-white/85">{item.title}</p>
                      <span className="shrink-0 font-display text-[9px] font-medium tabular-nums text-white/55">
                        {Math.round(percent)}%
                      </span>
                    </div>
                    <div className="mt-1.5">
                      <ProgressBar value={percent} />
                    </div>
                    <div className="mt-1 flex items-center justify-between text-[7.5px] text-white/32">
                      <span className="flex items-center gap-1">
                        <Download size={8} /> {formatBytes(item.downloadedBytes, lang)} / {formatBytes(item.sizeBytes, lang)}
                      </span>
                      <span className="flex items-center gap-1.5">
                        {item.status === "downloading" ? (
                          <>
                            <span className="font-display tabular-nums text-white/60">{item.speed.toFixed(1)} MB/s</span>
                            <span className="h-1 w-1 rounded-full bg-[#67e8c7]" />
                            <span>{item.connections} {t("connections")}</span>
                          </>
                        ) : (
                          <span className="text-[#f4c98a]">{t("queue")}</span>
                        )}
                      </span>
                    </div>
                  </div>
                </div>
              </GlassCard>
            );
          })}
          <div className="flex items-center justify-center gap-1.5 pt-0.5 text-[7.5px] text-white/22">
            <ShieldCheck size={9} />
            {lang === "ar" ? "خصوصية كاملة · بدون تتبّع · يعمل دون اتصال" : "Private by design · No tracking · Offline-first"}
          </div>
        </div>
      </div>

      <Sheet
        open={sheetKind !== null}
        onClose={() => setSheetKind(null)}
        title={`${sheetLabel} · ${sheetFormats.length} ${lang === "ar" ? "خيارات" : "options"}`}
        subtitle={t("sheetHint")}
      >
        {sheetFormats.length > 0 ? (
          <div className="space-y-2">
            {sheetKind === "video" && (
              <div className="flex items-center gap-2 rounded-[14px] border border-[rgba(var(--a-glow),.18)] bg-[rgba(var(--a-glow),.08)] px-3 py-2">
                <Merge size={13} className="text-[var(--a1)]" />
                <p className="flex-1 text-[9px] leading-4 text-white/55">{t("merge")}</p>
                <Badge className="border-white/10 text-[7.5px] text-white/50">FFmpeg</Badge>
              </div>
            )}
            {sheetFormats.map((format, index) => (
              <motion.div
                key={format.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.045, type: "spring", stiffness: 280, damping: 26 }}
                className={`relative overflow-hidden rounded-[17px] border p-2.5 ${
                  format.recommended
                    ? "border-[rgba(var(--a-glow),.24)] bg-[linear-gradient(120deg,rgba(var(--a-glow),.10),rgba(var(--a-glow-2),.06))]"
                    : "border-white/[.07] bg-white/[.028]"
                }`}
              >
                {format.recommended && (
                  <span className="absolute left-0 top-0 rounded-br-[10px] bg-[rgba(var(--a-glow),.28)] px-2 py-0.5 text-[7px] font-medium text-white/80">
                    {lang === "ar" ? "مقترح" : "Best"}
                  </span>
                )}
                <div className="flex items-center gap-2.5">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-[12px] border border-white/[.09] bg-black/25">
                    <TypeIcon kind={format.kind} size={16} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="font-display text-[12px] font-semibold text-white">{format.quality}</span>
                      <span className="rounded-[4px] bg-white/[.08] px-1 py-[1px] font-display text-[7.5px] font-medium text-white/55">{format.format}</span>
                      <span className="rounded-[4px] border border-white/[.07] px-1 py-[1px] font-display text-[7px] text-white/38">{format.codec}</span>
                    </div>
                    <p className="mt-0.5 truncate text-[8px] text-white/35">{format.detail}</p>
                  </div>
                  <div className="shrink-0 text-left">
                    <div dir="ltr" className="flex items-center justify-end gap-1 whitespace-nowrap font-display text-[9.5px] font-medium tabular-nums text-white/75">
                      {format.approx && <span className="text-[var(--a3)]">≈</span>}
                      {format.size}
                    </div>
                    <button
                      onClick={() => handleDownload(format)}
                      className="press app-btn-primary mt-1.5 flex h-[26px] w-[64px] items-center justify-center gap-1 rounded-[8px] text-[8.5px] font-medium text-white"
                    >
                      {selected === format.id ? <Loader2 size={10} className="animate-spin" /> : <Download size={10} />}
                      {t("download")}
                    </button>
                  </div>
                </div>
                <div className="mt-2 flex items-center justify-between border-t border-white/[.055] pt-1.5">
                  <button
                    onClick={() => notify(`${format.format} → ${lang === "ar" ? "أضيف إلى طابور التحويل" : "Added to conversion queue"}`)}
                    className="press flex items-center gap-1 text-[8px] text-white/35 hover:text-white/65"
                  >
                    <Wand2 size={9} /> {lang === "ar" ? "تحويل إلى…" : "Convert to…"}
                  </button>
                  <span className="flex items-center gap-1 font-display text-[7px] text-white/25">
                    <Check size={8} /> {lang === "ar" ? "حجم مؤكد" : "Verified size"}
                  </span>
                </div>
              </motion.div>
            ))}
            <p className="pt-1 text-center text-[7.5px] leading-4 text-white/22">{t("copyright")}</p>
          </div>
        ) : (
          <p className="py-8 text-center text-[11px] text-white/35">{t("noResults")}</p>
        )}
      </Sheet>
    </div>
  );
}

function AnalyzingCard() {
  const { t, lang } = useApp();
  const stages = [
    { label: t("stage0"), ms: "42ms", done: true },
    { label: t("stage1"), ms: "238ms", done: true },
    { label: t("stage2"), ms: "0.9s", done: false },
    { label: t("stage3"), ms: "…", done: false },
  ];
  return (
    <GlassCard className="p-4" glow>
      <div className="mb-3 flex items-center gap-2.5">
        <span className="relative grid h-10 w-10 place-items-center rounded-[14px] border border-white/10 bg-white/[.04]">
          <span className="absolute inset-0 animate-ping rounded-[14px] bg-[rgba(var(--a-glow),.15)]" />
          <Loader2 size={17} className="relative animate-spin text-[var(--a1)]" />
        </span>
        <div>
          <p className="text-[11px] font-medium text-white/85">{t("analyzing")}</p>
          <p className="mt-0.5 font-display text-[8px] text-white/30" dir="ltr">Parallel pipeline · IO dispatcher</p>
        </div>
        <Badge className="ml-auto border-[rgba(var(--a-glow),.2)] bg-[rgba(var(--a-glow),.1)] text-[7.5px] text-white/60">
          <span className="h-1 w-1 animate-pulse rounded-full bg-[var(--a1)]" /> LIVE
        </Badge>
      </div>
      <div className="space-y-1.5">
        {stages.map((stage, index) => (
          <div key={stage.label} className="flex items-center gap-2">
            <span
              className={`grid h-4 w-4 place-items-center rounded-full border ${
                stage.done ? "border-[#67e8c7]/30 bg-[#67e8c7]/10 text-[#67e8c7]" : "border-white/10 text-white/25"
              }`}
            >
              {stage.done ? <Check size={9} /> : <Loader2 size={8} className={index === 2 ? "animate-spin" : ""} />}
            </span>
            <span className={`flex-1 text-[8.5px] ${stage.done ? "text-white/50" : "text-white/30"}`}>{stage.label}</span>
            <span className="font-display text-[7.5px] tabular-nums text-white/25">{stage.ms}</span>
          </div>
        ))}
      </div>
      <div className="mt-3 h-1 overflow-hidden rounded-full bg-white/[.06]">
        <motion.div
          className="h-full rounded-full progress-fill"
          initial={{ width: "12%" }}
          animate={{ width: "78%" }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
        />
      </div>
      <div className="mt-2.5 rounded-[10px] bg-white/[.03] px-2.5 py-1.5">
        <span className="shimmer block h-2 w-3/4 rounded bg-white/[.06]" />
      </div>
      <p className="mt-2 text-center text-[7px] text-white/20">{lang === "ar" ? "لا نُجمّد الواجهة — كل شيء في الخلفية" : "Non-blocking · everything runs in background"}</p>
    </GlassCard>
  );
}

function InfoCard({
  analysis,
  filename,
  editing,
  setEditing,
  setFilename,
  onPlay,
  counts,
  onOpenKind,
}: {
  analysis: SiteAnalysis;
  filename: string;
  editing: boolean;
  setEditing: (value: boolean) => void;
  setFilename: (value: string) => void;
  onPlay: () => void;
  counts: Record<MediaKind, number>;
  onOpenKind: (kind: MediaKind) => void;
}) {
  const { t, lang } = useApp();
  const totalExact = useMemo(
    () =>
      analysis.formats.video.reduce((sum, item) => sum + parseSize(item.size), 0) +
      analysis.formats.audio.reduce((sum, item) => sum + parseSize(item.size), 0),
    [analysis],
  );

  return (
    <GlassCard glow className="p-2.5">
      {/* cover */}
      <div className="relative overflow-hidden rounded-[17px]">
        <button onClick={onPlay} className="group block w-full" aria-label={t("play")}>
          <img src={analysis.thumbnail} alt={analysis.title} className="h-[145px] w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]" />
          <span className="absolute inset-0 bg-gradient-to-t from-[#0a0b12]/90 via-[#0a0b12]/10 to-[#0a0b12]/25" />
          <span className="absolute inset-0 grid place-items-center">
            <span className="press grid h-11 w-11 place-items-center rounded-full border border-white/25 bg-black/30 text-white shadow-[0_8px_28px_rgba(0,0,0,.4)] backdrop-blur-xl transition-transform group-hover:scale-105">
              <Play size={16} className="ml-0.5 fill-white" />
            </span>
          </span>
          <span className="absolute left-2 top-2 flex items-center gap-1.5 rounded-full border border-white/15 bg-black/35 py-1 pl-1 pr-2 backdrop-blur-xl">
            <span
              className="grid h-4 w-4 place-items-center rounded-full text-[8px] font-bold text-black"
              style={{ background: analysis.logoBg }}
            >
              {analysis.logoText}
            </span>
            <span className="font-display text-[8px] font-medium text-white/90">{analysis.source}</span>
            {analysis.verified && <BadgeCheck size={9} className="text-white/60" />}
          </span>
          <span className="absolute right-2 top-2 flex items-center gap-1 rounded-full border border-white/15 bg-black/40 px-1.5 py-1 backdrop-blur-xl">
            <BadgeCheck size={8} className="text-[#67e8c7]" />
            <span className="font-display text-[7.5px] text-white/70">{analysis.domain}</span>
          </span>
          <span className="absolute bottom-2 right-2 flex items-center gap-1 rounded-md bg-black/65 px-1.5 py-0.5 font-display text-[8px] font-medium tabular-nums text-white/90 backdrop-blur-sm">
            <Clock3 size={8} /> {analysis.duration}
          </span>
          <span className="absolute bottom-2 left-2 rounded-md border border-white/10 bg-black/35 px-1.5 py-0.5 text-[7.5px] text-white/60 backdrop-blur-sm">
            {lang === "ar" ? "معاينة Media3" : "Media3 preview"}
          </span>
        </button>
      </div>

      <div className="px-1 pt-2.5">
        <div className="flex items-start gap-2">
          <span
            className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-[9px] font-display text-[12px] font-bold text-black"
            style={{ background: analysis.logoBg }}
          >
            {analysis.logoText}
          </span>
          <div className="min-w-0 flex-1">
            <h3 className="text-[11.5px] font-semibold leading-[1.75] text-white/92">{analysis.title}</h3>
            <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[8px] text-white/35">
              <span className="flex items-center gap-0.5 text-white/55">
                {analysis.channel} <BadgeCheck size={8} className="text-[var(--a1)]" />
              </span>
              <span>·</span>
              <span>{analysis.views}</span>
              <span>·</span>
              <span>{analysis.published}</span>
            </div>
          </div>
        </div>

        {/* file name editable */}
        <div className="mt-2 flex items-center gap-2 rounded-[10px] border border-white/[.055] bg-black/20 px-2 py-1.5">
          <Folder size={10} className="shrink-0 text-white/30" />
          {editing ? (
            <input
              autoFocus
              value={filename}
              onChange={(event) => setFilename(event.target.value)}
              onBlur={() => setEditing(false)}
              onKeyDown={(event) => event.key === "Enter" && setEditing(false)}
              dir="ltr"
              className="min-w-0 flex-1 bg-transparent text-left font-display text-[8px] text-white/75 outline-none"
            />
          ) : (
            <span dir="ltr" className="min-w-0 flex-1 truncate text-left font-display text-[8px] text-white/45">{filename}</span>
          )}
          <button onClick={() => setEditing(!editing)} aria-label="تعديل اسم الملف" className="press text-white/30 hover:text-white/60">
            <Pencil size={9} />
          </button>
        </div>

        {/* exact size + merge */}
        <div className="mt-2 flex items-center gap-1.5">
          <div className="flex flex-1 items-center gap-1.5 rounded-[9px] border border-white/[.055] bg-white/[.025] px-2 py-1.5">
            <Box size={10} className="shrink-0 text-[#67e8c7]" />
            <div className="min-w-0">
              <p className="text-[7px] text-white/30">{t("exactSize")}</p>
              <p dir="ltr" className="truncate text-left font-display text-[7.5px] tabular-nums text-white/65">{formatExact(Math.round(totalExact))}</p>
            </div>
            <span className="mr-auto rounded-[4px] bg-[#67e8c7]/10 px-1 py-[1px] text-[6.5px] text-[#67e8c7]">✓ {lang === "ar" ? "مؤكد" : "Exact"}</span>
          </div>
          <div className="flex items-center gap-1 text-[6.5px] text-white/28">
            <span className="text-[9px] text-[var(--a3)]">≈</span>
            {lang === "ar" ? "التقريبي بعلامة" : "approx marked"}
          </div>
        </div>

        {/* four smart buttons */}
        <div className="mb-1 mt-3 flex items-center justify-between">
          <p className="flex items-center gap-1 text-[9px] font-medium text-white/60">
            <Sparkles size={9} className="text-[var(--a2)]" />
            {t("smartChoices")}
          </p>
          <span className="flex items-center gap-1 text-[6.5px] text-white/25">
            <Merge size={7} /> Auto-merge
          </span>
        </div>
        <div className="grid grid-cols-4 gap-1.5">
          {KIND_ORDER.map((kind) =>
            counts[kind] > 0 ? (
              <SmartKindButton key={kind} kind={kind} count={counts[kind]} compact onClick={() => onOpenKind(kind)} />
            ) : null,
          )}
        </div>

        <div className="mt-2 flex items-center gap-1.5 text-[6.5px] text-white/22">
          <ShieldCheck size={8} />
          {lang === "ar" ? "بدون DRM · بدون تجاوز Paywall · احترم حقوق النشر" : "No DRM bypass · No paywall bypass · Respect copyright"}
        </div>
      </div>
    </GlassCard>
  );
}

export function HomeFooterHint() {
  return (
    <div className="flex items-center justify-between rounded-[14px] border border-white/[.06] bg-white/[.025] px-2.5 py-2">
      <div className="flex items-center gap-1.5 text-[8px] text-white/40">
        <Globe2 size={10} />
        Internal browser sniffer
      </div>
      <div className="flex items-center gap-1.5 text-[8px] text-white/40">
        <CalendarDays size={10} />
        Queue schedule
      </div>
      <div className="flex items-center gap-1.5 text-[8px] text-white/40">
        <ArrowUpLeft size={10} />
        Share target
      </div>
    </div>
  );
}

export function JsonBadge() {
  return (
    <span className="inline-flex items-center gap-1 text-[8px] text-white/35">
      <FileJson2 size={9} /> JSON
    </span>
  );
}

export function Separator() {
  return <span className="text-white/15">·</span>;
}
