import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowDownToLine,
  BatteryCharging,
  Check,
  ChevronDown,
  Clock3,
  Copy,
  FolderOpen,
  Gauge,
  HardDrive,
  ListFilter,
  MoreHorizontal,
  Pause,
  Play,
  Plus,
  RefreshCw,
  Share2,
  Sparkles,
  Trash2,
  TrendingUp,
  Wand2,
  Wifi,
  X,
  Zap,
} from "lucide-react";
import { useApp } from "../state";
import { formatBytes, formatExact, type DownloadItem, type DownloadStatus } from "../data";
import {
  AppHeader,
  Badge,
  EmptyState,
  FilterPill,
  GlassCard,
  IconButton,
  ProgressBar,
  Sparkline,
  TypeIcon,
} from "../components/ui";

type FilterId = "all" | "downloading" | "queued" | "completed" | "failed";

function statusLabel(status: DownloadStatus, lang: "ar" | "en") {
  const map = {
    downloading: lang === "ar" ? "جارٍ التحميل" : "Downloading",
    queued: lang === "ar" ? "في الانتظار" : "Queued",
    paused: lang === "ar" ? "موقوف" : "Paused",
    completed: lang === "ar" ? "مكتمل" : "Completed",
    failed: lang === "ar" ? "فاشل" : "Failed",
  };
  return map[status];
}

export function DownloadsScreen() {
  const { t, lang, downloads, togglePause, retryDownload, removeDownload, totalSpeed, activeCount, notify, setScreen } = useApp();
  const [filter, setFilter] = useState<FilterId>("all");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);

  const counts = useMemo(
    () => ({
      all: downloads.length,
      downloading: downloads.filter((item) => item.status === "downloading").length,
      queued: downloads.filter((item) => item.status === "queued").length,
      completed: downloads.filter((item) => item.status === "completed").length,
      failed: downloads.filter((item) => item.status === "failed").length,
    }),
    [downloads],
  );

  const filtered = downloads.filter((item) => {
    if (filter === "all") return true;
    if (filter === "downloading") return item.status === "downloading" || item.status === "paused";
    return item.status === filter;
  });

  const totalDownloaded = downloads.reduce((sum, item) => sum + item.downloadedBytes, 0);
  const totalBytes = downloads.reduce((sum, item) => sum + item.sizeBytes, 0);
  const globalProgress = totalBytes ? (totalDownloaded / totalBytes) * 100 : 0;
  const ringCircumference = 2 * Math.PI * 25;

  const filters: { id: FilterId; label: string; count: number }[] = [
    { id: "all", label: t("all"), count: counts.all },
    { id: "downloading", label: t("active"), count: counts.downloading },
    { id: "queued", label: t("queued"), count: counts.queued },
    { id: "completed", label: t("completed"), count: counts.completed },
    { id: "failed", label: t("failed"), count: counts.failed },
  ];

  return (
    <div className="relative">
      <AppHeader
        title={t("downloads")}
        subtitle={lang === "ar" ? "طابور ذكي · 32 اتصالًا متوازيًا" : "Smart queue · up to 32 parallel segments"}
        right={
          <>
            <IconButton label="إضافة رابط" size="sm" onClick={() => setScreen("home")}>
              <Plus size={14} />
            </IconButton>
            <div className="relative">
              <IconButton label="خيارات" size="sm" active={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
                <MoreHorizontal size={14} />
              </IconButton>
              <AnimatePresence>
                {menuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -6, scale: 0.96 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -4, scale: 0.96 }}
                    transition={{ type: "spring", stiffness: 380, damping: 28 }}
                    className="glass-deep absolute left-0 top-10 z-50 w-[150px] overflow-hidden rounded-[16px] p-1"
                  >
                    {[
                      { icon: ListFilter, label: lang === "ar" ? "ترتيب حسب الأولوية" : "Sort by priority" },
                      { icon: Wifi, label: lang === "ar" ? "Wi-Fi فقط" : "Wi-Fi only" },
                      { icon: BatteryCharging, label: lang === "ar" ? "الشحن فقط" : "Charging only" },
                      { icon: Clock3, label: lang === "ar" ? "جدولة التحميل" : "Schedule queue" },
                    ].map((item) => (
                      <button
                        key={item.label}
                        onClick={() => {
                          notify(item.label);
                          setMenuOpen(false);
                        }}
                        className="press flex w-full items-center gap-2 rounded-[10px] px-2.5 py-2 text-right text-[9px] text-white/55 hover:bg-white/[.06] hover:text-white/85"
                      >
                        <item.icon size={11} /> {item.label}
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </>
        }
      />

      <div className="px-4">
        {/* overview */}
        <GlassCard glow className="p-3">
          <div className="absolute -left-10 -top-12 h-32 w-32 rounded-full bg-[rgba(var(--a-glow-2),.22)] blur-2xl" />
          <div className="relative flex items-center gap-3">
            <div className="relative h-[66px] w-[66px] shrink-0">
              <svg viewBox="0 0 60 60" className="h-full w-full -rotate-90">
                <defs>
                  <linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop stopColor="var(--a1)" />
                    <stop offset=".5" stopColor="var(--a2)" />
                    <stop offset="1" stopColor="var(--a3)" />
                  </linearGradient>
                </defs>
                <circle cx="30" cy="30" r="25" fill="none" stroke="rgba(255,255,255,.07)" strokeWidth="4" />
                <motion.circle
                  cx="30"
                  cy="30"
                  r="25"
                  fill="none"
                  stroke="url(#ringGrad)"
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeDasharray={ringCircumference}
                  animate={{ strokeDashoffset: ringCircumference - (ringCircumference * globalProgress) / 100 }}
                  transition={{ type: "spring", stiffness: 80, damping: 20 }}
                />
              </svg>
              <div className="absolute inset-0 grid place-items-center text-center">
                <div>
                  <p className="font-display text-[15px] font-semibold leading-none text-white">{Math.round(globalProgress)}%</p>
                  <p className="mt-1 text-[6.5px] text-white/30">{lang === "ar" ? "الإجمالي" : "TOTAL"}</p>
                </div>
              </div>
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#67e8c7] opacity-75" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-[#67e8c7]" />
                </span>
                <p className="text-[9px] text-white/45">{t("currentSpeed")}</p>
              </div>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="aurora-text font-display text-[27px] font-semibold leading-none tabular-nums">{totalSpeed.toFixed(1)}</span>
                <span className="font-display text-[10px] text-white/40">MB/s</span>
                <TrendingUp size={11} className="mb-1 mr-1 text-[#67e8c7]" />
              </div>
              <div className="mt-2 flex flex-wrap items-center gap-1">
                <Badge className="bg-white/[.05] px-1.5 text-[7px] text-white/50">
                  <Zap size={7} className="text-[var(--a1)]" /> {activeCount} {t("activeDownloads")}
                </Badge>
                <Badge className="bg-white/[.05] px-1.5 text-[7px] text-white/50">
                  <Gauge size={7} /> 32 {t("connections")}
                </Badge>
                <Badge className="bg-white/[.05] px-1.5 text-[7px] text-white/50">
                  <HardDrive size={7} /> {formatBytes(totalDownloaded, lang)}
                </Badge>
              </div>
            </div>
          </div>
          <div className="relative mt-2.5 flex items-center justify-between rounded-[10px] border border-white/[.055] bg-black/20 px-2.5 py-1.5">
            <div className="flex items-center gap-1.5 text-[7.5px] text-white/40">
              <Wifi size={9} className="text-[#67e8c7]" /> Wi-Fi · 5 GHz
            </div>
            <div className="flex items-center gap-1 font-display text-[7.5px] tabular-nums text-white/35">
              <TrendingUp size={8} /> 94% <span className="text-white/20">{lang === "ar" ? "من عرض النطاق" : "bandwidth"}</span>
            </div>
          </div>
        </GlassCard>

        {/* filters */}
        <div className="thin-scroll -mx-1 mt-3 flex items-center gap-1.5 overflow-x-auto px-1 pb-1">
          {filters.map((item) => (
            <FilterPill key={item.id} active={filter === item.id} onClick={() => setFilter(item.id)} count={item.count}>
              {item.id === "downloading" && <span className="h-1.5 w-1.5 rounded-full bg-[#67e8c7]" />}
              {item.id === "completed" && <Check size={9} />}
              {item.id === "queued" && <Clock3 size={9} />}
              {item.label}
            </FilterPill>
          ))}
        </div>

        {/* download list */}
        <div className="mt-1 space-y-2 pb-5">
          <AnimatePresence initial={false}>
            {filtered.map((item, index) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.97 }}
                transition={{ delay: Math.min(index * 0.05, 0.2), type: "spring", stiffness: 280, damping: 28 }}
              >
                <DownloadCard
                  item={item}
                  expanded={expanded === item.id}
                  onExpand={() => setExpanded(expanded === item.id ? null : item.id)}
                  onPause={() => togglePause(item.id)}
                  onRetry={() => retryDownload(item.id)}
                  onRemove={() => removeDownload(item.id)}
                  onNotify={notify}
                  onTools={() => setScreen("tools")}
                />
              </motion.div>
            ))}
          </AnimatePresence>
          {filtered.length === 0 && (
            <GlassCard className="mt-3">
              <EmptyState title={t("noResults")} subtitle={lang === "ar" ? "أضف رابطًا جديدًا لتبدأ التحميل" : "Add a new link to start downloading"} />
            </GlassCard>
          )}
          <button
            onClick={() => setScreen("home")}
            className="press mt-1 flex w-full items-center justify-center gap-1.5 rounded-[14px] border border-dashed border-white/[.09] py-2.5 text-[9px] text-white/35 hover:border-white/20 hover:text-white/65"
          >
            <Plus size={11} /> {lang === "ar" ? "إضافة تحميل جديد" : "Add new download"}
          </button>
        </div>
      </div>
    </div>
  );
}

function DownloadCard({
  item,
  expanded,
  onExpand,
  onPause,
  onRetry,
  onRemove,
  onNotify,
  onTools,
}: {
  item: DownloadItem;
  expanded: boolean;
  onExpand: () => void;
  onPause: () => void;
  onRetry: () => void;
  onRemove: () => void;
  onNotify: (message: string) => void;
  onTools: () => void;
}) {
  const { t, lang } = useApp();
  const percent = Math.min(100, (item.downloadedBytes / item.sizeBytes) * 100);
  const remaining: Record<DownloadStatus, string> = {
    downloading: item.eta ?? "02:14",
    queued: "—",
    paused: lang === "ar" ? "متوقف" : "Paused",
    completed: lang === "ar" ? "اكتمل" : "Done",
    failed: lang === "ar" ? "فشل" : "Failed",
  };

  return (
    <GlassCard className="p-2.5">
      <div className="flex items-start gap-2.5">
        <div className="relative h-[52px] w-[52px] shrink-0 overflow-hidden rounded-[13px]">
          <img src={item.thumbnail} alt="" className="h-full w-full object-cover" />
          <span className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/20" />
          <span className="absolute left-1 top-1 grid h-5 w-5 place-items-center rounded-[7px] border border-white/15 bg-black/35 backdrop-blur-md">
            <TypeIcon kind={item.kind} size={11} />
          </span>
          {item.status === "completed" && (
            <span className="absolute bottom-1 right-1 grid h-4 w-4 place-items-center rounded-full bg-[#67e8c7] text-[#07110f]">
              <Check size={10} strokeWidth={3} />
            </span>
          )}
          {item.status === "paused" && (
            <span className="absolute bottom-1 right-1 grid h-4 w-4 place-items-center rounded-full bg-black/60 text-white/70">
              <Pause size={8} fill="currentColor" />
            </span>
          )}
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-1.5">
            <div className="min-w-0">
              <h3 className="truncate text-[10.5px] font-medium leading-5 text-white/88">{item.title}</h3>
              <div className="mt-0.5 flex items-center gap-1.5 text-[7.5px] text-white/32">
                <span className="font-display font-medium text-white/50">{item.quality}</span>
                <span>·</span>
                <span className="font-display">{item.format}</span>
                <span>·</span>
                <span>{item.source}</span>
              </div>
            </div>
            <div className="flex shrink-0 items-center gap-1">
              <button
                onClick={item.status === "completed" || item.status === "failed" ? onRetry : onPause}
                aria-label={item.status === "downloading" ? t("pause") : t("resume")}
                className="press grid h-6 w-6 place-items-center rounded-full border border-white/[.09] bg-white/[.055] text-white/65 hover:bg-white/[.1]"
              >
                {item.status === "downloading" ? <Pause size={10} fill="currentColor" /> : item.status === "completed" ? <FolderOpen size={11} /> : <Play size={10} fill="currentColor" className="ml-0.5" />}
              </button>
              <button onClick={onExpand} aria-label="المزيد" className="press grid h-6 w-6 place-items-center rounded-full text-white/30 hover:bg-white/[.06] hover:text-white/70">
                <ChevronDown size={12} className={`transition-transform ${expanded ? "rotate-180" : ""}`} />
              </button>
            </div>
          </div>

          <div className="mt-2 flex items-center gap-2">
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between text-[7px]">
                <span dir="ltr" className="whitespace-nowrap font-display tabular-nums text-white/42">
                  {formatBytes(item.downloadedBytes, lang)} <span className="text-white/20">/ {formatBytes(item.sizeBytes, lang)}</span>
                  {item.approx && <span className="ml-1 text-[var(--a3)]">≈</span>}
                </span>
                <span className={`font-display tabular-nums ${item.status === "completed" ? "text-[#67e8c7]" : "text-white/50"}`}>
                  {item.status === "completed" ? (lang === "ar" ? "مكتمل" : "Complete") : item.status === "queued" ? statusLabel(item.status, lang) : `${Math.round(percent)}%`}
                </span>
              </div>
              <div className="mt-1.5">
                <ProgressBar value={percent} animated={item.status === "downloading"} />
              </div>
              <div className="mt-1.5 flex items-center justify-between">
                <div className="flex items-center gap-2 text-[7px] text-white/30">
                  {item.status === "downloading" ? (
                    <>
                      <span className="flex items-center gap-0.5 font-display font-medium tabular-nums text-[var(--a2)]">
                        <ArrowDownToLine size={8} /> {item.speed.toFixed(1)} MB/s
                      </span>
                      <span className="flex items-center gap-0.5">
                        <Clock3 size={8} /> {remaining[item.status]}
                      </span>
                      <span className="flex items-center gap-0.5">
                        <Gauge size={8} /> {item.connections}
                      </span>
                    </>
                  ) : (
                    <span className="flex items-center gap-0.5">
                      {item.status === "completed" ? <Check size={8} className="text-[#67e8c7]" /> : <Clock3 size={8} />}
                      {statusLabel(item.status, lang)}
                    </span>
                  )}
                </div>
                <Sparkline data={item.sparkline} width={48} height={16} />
              </div>
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence initial={false}>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="mt-2.5 border-t border-white/[.06] pt-2">
              <div className="mb-2 flex items-center justify-between rounded-[8px] bg-black/20 px-2 py-1">
                <span className="text-[7px] text-white/30">{t("exactSize")}</span>
                <span dir="ltr" className="font-display text-[7.5px] tabular-nums text-white/55">{formatExact(item.sizeBytes)}</span>
              </div>
              <div className="grid grid-cols-5 gap-1">
                {[
                  { icon: Play, label: lang === "ar" ? "فتح" : "Open", action: () => onNotify(lang === "ar" ? "جارٍ فتح الملف…" : "Opening file…") },
                  { icon: Share2, label: lang === "ar" ? "مشاركة" : "Share", action: () => onNotify(lang === "ar" ? "تمت مشاركة الرابط" : "Link shared") },
                  { icon: Copy, label: lang === "ar" ? "نسخ الرابط" : "Copy", action: () => onNotify(lang === "ar" ? "تم نسخ الرابط المباشر" : "Direct link copied") },
                  { icon: Wand2, label: lang === "ar" ? "تحويل" : "Convert", action: onTools },
                  { icon: item.status === "completed" ? Trash2 : X, label: item.status === "completed" ? (lang === "ar" ? "حذف" : "Delete") : (lang === "ar" ? "إلغاء" : "Cancel"), action: onRemove, danger: true },
                ].map((action) => (
                  <button
                    key={action.label}
                    onClick={action.action}
                    className={`press flex flex-col items-center gap-1 rounded-[9px] border border-white/[.055] bg-white/[.025] py-1.5 text-[6.5px] ${
                      action.danger ? "text-[#ff9daa]/65" : "text-white/42"
                    } hover:bg-white/[.06]`}
                  >
                    <action.icon size={11} />
                    {action.label}
                  </button>
                ))}
              </div>
              <div className="mt-1.5 flex items-center gap-1.5">
                <button
                  onClick={onRetry}
                  className="press flex flex-1 items-center justify-center gap-1 rounded-[8px] border border-white/[.06] bg-white/[.025] py-1 text-[7.5px] text-white/38"
                >
                  <RefreshCw size={9} /> {item.status === "completed" ? (lang === "ar" ? "إعادة التحميل" : "Re-download") : t("resume")}
                </button>
                <button
                  onClick={() => {
                    onNotify(`${lang === "ar" ? "اقتراح تصغير" : "Compression suggestion"}: −38% · ${formatBytes(item.sizeBytes * 0.38, lang)}`);
                    onTools();
                  }}
                  className="press flex flex-1 items-center justify-center gap-1 rounded-[8px] border border-[rgba(var(--a-glow),.16)] bg-[rgba(var(--a-glow),.07)] py-1 text-[7.5px] text-[var(--a1)]"
                >
                  <Sparkles size={9} /> {lang === "ar" ? "وفّر مساحة" : "Save space"}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </GlassCard>
  );
}
