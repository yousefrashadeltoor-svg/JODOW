import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowDown,
  ArrowRight,
  AudioLines,
  Check,
  ChevronDown,
  Clock3,
  Code2,
  FileArchive,
  FileImage,
  Film,
  Gauge,
  Image as ImageIcon,
  Layers,
  Music2,
  RotateCcw,
  Scissors,
  Settings2,
  ShieldCheck,
  Sparkles,
  TrendingDown,
  Wand2,
  X,
  Zap,
} from "lucide-react";
import { useApp } from "../state";
import { FILES, IMAGES, TOOLS } from "../data";
import { AppHeader, Badge, GlassCard, IconButton, ProgressBar, TypeIcon } from "../components/ui";

type ToolMode = "converter" | "compressor";

const conversionGroups = [
  { label: "فيديو", icon: Film, formats: ["MP4", "MKV", "WEBM", "MOV", "AVI", "GIF"], color: "var(--a1)" },
  { label: "صوت", icon: Music2, formats: ["MP3", "M4A", "OPUS", "OGG", "FLAC", "WAV"], color: "var(--a2)" },
  { label: "صور", icon: ImageIcon, formats: ["JPG", "PNG", "WEBP", "AVIF"], color: "var(--a3)" },
];

export function ToolsScreen() {
  const { lang, notify, setScreen } = useApp();
  const [mode, setMode] = useState<ToolMode>("converter");
  const [selectedFormat, setSelectedFormat] = useState("MP4");
  const [fileIndex, setFileIndex] = useState(0);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [trim, setTrim] = useState(24);
  const [lossless, setLossless] = useState(true);
  const [compare, setCompare] = useState(48);
  const [quality, setQuality] = useState("High");
  const [batchOpen, setBatchOpen] = useState(false);

  const file = FILES[fileIndex % FILES.length];

  const savings = useMemo(() => {
    if (lossless) return { before: 8.2, after: 5.6, percent: 32 };
    return { before: 8.2, after: 3.1, percent: 62 };
  }, [lossless]);

  const run = () => {
    if (running) return;
    setRunning(true);
    setProgress(8);
    const timer = window.setInterval(() => {
      setProgress((prev) => {
        const next = prev + Math.random() * 17;
        if (next >= 100) {
          window.clearInterval(timer);
          setRunning(false);
          notify(
            mode === "converter"
              ? lang === "ar"
                ? `اكتمل التحويل إلى ${selectedFormat} · ${file.title}`
                : `Converted to ${selectedFormat} · ${file.title}`
              : lang === "ar"
                ? `تم التصغير بنجاح · وفّرت ${savings.percent}% دون استبدال الأصل`
                : `Compressed successfully · ${savings.percent}% saved, original untouched`,
          );
          return 100;
        }
        return next;
      });
    }, 420);
  };

  return (
    <div className="relative">
      <AppHeader
        title={lang === "ar" ? "استوديو المعالجة" : "Processing Studio"}
        subtitle={lang === "ar" ? "FFmpeg · MediaCodec · معالجة محلية 100%" : "FFmpeg · MediaCodec · 100% on-device"}
        right={
          <>
            <IconButton label="الطابور" size="sm" active={batchOpen} onClick={() => setBatchOpen(!batchOpen)}>
              <Layers size={13} />
            </IconButton>
            <IconButton label="الإعدادات" size="sm" onClick={() => setScreen("settings")}>
              <Settings2 size={13} />
            </IconButton>
          </>
        }
      />
      <div className="px-4">
        {/* mode segment */}
        <div className="relative grid grid-cols-2 gap-1 rounded-[16px] border border-white/[.075] bg-black/25 p-1">
          {[
            { id: "converter" as const, label: lang === "ar" ? "تحويل الصيغ" : "Converter", icon: Wand2 },
            { id: "compressor" as const, label: lang === "ar" ? "تصغير الحجم" : "Compressor", icon: TrendingDown },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setMode(item.id)}
              className={`press relative flex items-center justify-center gap-1.5 rounded-[12px] py-2 text-[9px] font-medium ${
                mode === item.id ? "text-white" : "text-white/38"
              }`}
            >
              {mode === item.id && (
                <motion.span
                  layoutId="tool-mode"
                  transition={{ type: "spring", stiffness: 420, damping: 32 }}
                  className="absolute inset-0 rounded-[12px] border border-white/[.11] bg-[linear-gradient(120deg,rgba(var(--a-glow),.22),rgba(var(--a-glow-2),.17))]"
                />
              )}
              <item.icon size={11} className="relative" />
              <span className="relative">{item.label}</span>
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={mode}
            initial={{ opacity: 0, y: 10, filter: "blur(4px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ type: "spring", stiffness: 260, damping: 26 }}
          >
            {/* selected source */}
            <GlassCard glow className="mt-2.5 p-2.5">
              <div className="flex items-center gap-2.5">
                <div className="relative h-[52px] w-[52px] shrink-0 overflow-hidden rounded-[13px]">
                  <img src={file.image} alt="" className="h-full w-full object-cover" />
                  <span className="absolute inset-0 bg-black/25" />
                  <span className="absolute bottom-1 right-1 rounded-[4px] border border-white/15 bg-black/45 px-1 py-[1px] font-display text-[6px] text-white/70">
                    {mode === "converter" ? "MP4" : "JPG"}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1">
                    <TypeIcon kind={file.kind} size={9} />
                    <span className="text-[7px] text-white/30">{mode === "converter" ? "المصدر" : "الملف الأصلي"}</span>
                    <Badge className="px-1 py-0 text-[6px] text-[#67e8c7]">
                      <Check size={6} /> {lang === "ar" ? "مؤكد" : "Exact"}
                    </Badge>
                  </div>
                  <p className="mt-0.5 truncate text-[10px] font-medium text-white/82">{file.title}</p>
                  <p className="mt-0.5 font-display text-[7.5px] text-white/32" dir="ltr">
                    {file.meta} · {mode === "converter" ? "1920×1080 · 60fps · H.264" : "8.2 MB"}
                  </p>
                </div>
                <button
                  onClick={() => {
                    setFileIndex((prev) => prev + 1);
                    notify(lang === "ar" ? "تم اختيار ملف آخر من المكتبة" : "Selected another file from library");
                  }}
                  className="press shrink-0 rounded-[8px] border border-white/[.08] bg-white/[.04] px-2 py-1.5 text-[7px] text-white/45"
                >
                  {lang === "ar" ? "تغيير" : "Change"}
                </button>
              </div>
              <div className="mt-2 flex items-center gap-1.5 rounded-[9px] bg-black/20 px-2 py-1.5">
                <ShieldCheck size={10} className="shrink-0 text-[#67e8c7]" />
                <p className="text-[7px] leading-4 text-white/32">
                  {lang === "ar" ? "الناتج ملف جديد — لن يُستبدل الأصل دون تأكيدك." : "Output is a new file — the original is never replaced without confirmation."}
                </p>
              </div>
            </GlassCard>

            {mode === "converter" ? (
              <ConverterBody
                selectedFormat={selectedFormat}
                setSelectedFormat={setSelectedFormat}
                quality={quality}
                setQuality={setQuality}
                trim={trim}
                setTrim={setTrim}
              />
            ) : (
              <CompressorBody
                lossless={lossless}
                setLossless={setLossless}
                compare={compare}
                setCompare={setCompare}
                savings={savings}
              />
            )}

            {/* run card */}
            <GlassCard className="mt-2 p-2.5" glow={running}>
              <AnimatePresence mode="wait">
                {running ? (
                  <motion.div key="running" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    <div className="flex items-center gap-2">
                      <span className="relative grid h-8 w-8 place-items-center rounded-[10px] border border-white/[.1] bg-white/[.045]">
                        <span className="absolute inset-0 animate-ping rounded-[10px] bg-[rgba(var(--a-glow),.14)]" />
                        <Gauge size={14} className="relative text-[var(--a1)]" />
                      </span>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <p className="text-[9px] font-medium text-white/72">{mode === "converter" ? "جارٍ التحويل محليًا…" : "جارٍ التصغير والتحقق…"}</p>
                          <span className="font-display text-[11px] font-semibold tabular-nums text-white/80">{Math.round(progress)}%</span>
                        </div>
                        <div className="mt-1.5"><ProgressBar value={progress} /></div>
                        <div className="mt-1 flex items-center justify-between text-[7px] text-white/30">
                          <span className="flex items-center gap-1"><Zap size={7} /> MediaCodec Hardware</span>
                          <span className="font-display">{mode === "converter" ? `→ ${selectedFormat}` : "SSIM 97.4%"}</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    <div className="mb-2 flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-[7.5px] text-white/35">
                        <Clock3 size={9} />
                        {lang === "ar" ? "متوقع:" : "Estimated:"} {mode === "converter" ? "~ 42 ثانية" : "~ 1.8 دقيقة"}
                      </div>
                      <div className="flex items-center gap-1 text-[7px] text-[#67e8c7]/70">
                        <ShieldCheck size={8} /> {lang === "ar" ? "يعمل في الخلفية" : "Background"}
                      </div>
                    </div>
                    <button onClick={run} className="press app-btn-primary flex w-full items-center justify-center gap-1.5 rounded-[12px] py-2.5 text-[10px] font-medium text-white">
                      {mode === "converter" ? <><Wand2 size={12} /> {lang === "ar" ? `تحويل إلى ${selectedFormat}` : `Convert to ${selectedFormat}`}</> : <><TrendingDown size={12} /> {lang === "ar" ? "تصغير الآن" : "Compress now"}</>}
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </GlassCard>

            {/* batch queue */}
            <div className="mt-2 pb-5">
              <button onClick={() => setBatchOpen(!batchOpen)} className="flex w-full items-center justify-between px-0.5 py-1">
                <span className="flex items-center gap-1.5 text-[9px] font-medium text-white/55">
                  <Layers size={10} /> {lang === "ar" ? "طابور المعالجة" : "Processing queue"}
                  <Badge className="px-1 py-0 text-[6.5px] text-white/40">3</Badge>
                </span>
                <ChevronDown size={11} className={`text-white/30 transition-transform ${batchOpen ? "rotate-180" : ""}`} />
              </button>
              <AnimatePresence>
                {batchOpen && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                    <div className="space-y-1.5 pt-1">
                      {[
                        { title: "Aurora Night Sky", task: "MP4 HEVC · 4K", progress: 100, image: IMAGES.night },
                        { title: "Midnight Echoes", task: "FLAC → OPUS", progress: 68, image: IMAGES.aurora2 },
                        { title: "Star Trails Pack", task: "PNG → WEBP · Lossless", progress: 22, image: IMAGES.lake },
                      ].map((item) => (
                        <div key={item.title} className="flex items-center gap-2 rounded-[11px] border border-white/[.055] bg-white/[.025] p-1.5">
                          <img src={item.image} alt="" className="h-7 w-9 rounded-[6px] object-cover" />
                          <div className="min-w-0 flex-1">
                            <div className="flex justify-between text-[7.5px]"><span className="truncate text-white/60">{item.title}</span><span className="font-display text-white/35">{item.progress}%</span></div>
                            <div className="mt-1"><ProgressBar value={item.progress} /></div>
                          </div>
                          <button onClick={() => notify(lang === "ar" ? "أُلغي من الطابور" : "Removed from queue")} className="press text-white/25 hover:text-white/60"><X size={10} /></button>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

function ConverterBody({
  selectedFormat,
  setSelectedFormat,
  quality,
  setQuality,
  trim,
  setTrim,
}: {
  selectedFormat: string;
  setSelectedFormat: (value: string) => void;
  quality: string;
  setQuality: (value: string) => void;
  trim: number;
  setTrim: (value: number) => void;
}) {
  const { lang } = useApp();
  return (
    <>
      <div className="mt-2.5 flex items-center justify-between px-0.5">
        <p className="text-[9px] font-medium text-white/55">{lang === "ar" ? "الصيغة الناتجة" : "Output format"}</p>
        <span className="flex items-center gap-1 text-[6.5px] text-white/25"><Code2 size={8} /> Stream copy when possible</span>
      </div>
      <div className="mt-1.5 space-y-2">
        {conversionGroups.map((group) => (
          <div key={group.label}>
            <div className="mb-1 flex items-center gap-1.5">
              <group.icon size={9} style={{ color: group.color }} />
              <span className="text-[7.5px] text-white/35">{lang === "ar" ? group.label : group.label === "فيديو" ? "Video" : group.label === "صوت" ? "Audio" : "Images"}</span>
            </div>
            <div className="flex flex-wrap gap-1">
              {group.formats.map((format) => (
                <button
                  key={format}
                  onClick={() => setSelectedFormat(format)}
                  className={`press rounded-[8px] border px-2 py-1 font-display text-[8px] transition-colors ${
                    selectedFormat === format
                      ? "border-[rgba(var(--a-glow),.4)] bg-[rgba(var(--a-glow),.18)] text-white"
                      : "border-white/[.06] bg-white/[.025] text-white/35"
                  }`}
                >
                  {format}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-2.5 grid grid-cols-2 gap-1.5">
        <div className="rounded-[12px] border border-white/[.06] bg-white/[.025] p-2">
          <p className="text-[7px] text-white/30">{lang === "ar" ? "الجودة" : "Quality"}</p>
          <div className="mt-1 flex gap-1">
            {["High", "Balanced", "Small"].map((item) => (
              <button
                key={item}
                onClick={() => setQuality(item)}
                className={`press flex-1 rounded-[6px] py-1 text-[6.5px] ${quality === item ? "bg-[rgba(var(--a-glow),.2)] text-white/85" : "bg-white/[.03] text-white/30"}`}
              >
                {item}
              </button>
            ))}
          </div>
        </div>
        <div className="rounded-[12px] border border-white/[.06] bg-white/[.025] p-2">
          <p className="text-[7px] text-white/30">{lang === "ar" ? "الترميز" : "Encoding"}</p>
          <div className="mt-1 flex items-center justify-between">
            <span className="font-display text-[9px] font-medium text-white/65">H.265 · HW</span>
            <Badge className="px-1 py-0 text-[6px] text-[#67e8c7]"><Zap size={6} /> 4.2×</Badge>
          </div>
          <p className="mt-0.5 text-[6px] text-white/22">{lang === "ar" ? "تسريع MediaCodec" : "MediaCodec acceleration"}</p>
        </div>
      </div>

      <div className="mt-2 rounded-[13px] border border-white/[.06] bg-white/[.025] p-2.5">
        <div className="flex items-center justify-between">
          <p className="flex items-center gap-1 text-[8px] font-medium text-white/55"><Scissors size={9} /> {lang === "ar" ? "قص المقطع" : "Trim clip"}</p>
          <span className="font-display text-[7.5px] tabular-nums text-white/40">00:{trim.toString().padStart(2, "0")} → 18:42</span>
        </div>
        <input
          type="range"
          min={0}
          max={100}
          value={trim}
          onChange={(event) => setTrim(Number(event.target.value))}
          aria-label="trim start"
          className="mt-2 h-1 w-full cursor-pointer appearance-none rounded-full accent-[var(--a1)]"
          style={{ background: `linear-gradient(to left, rgba(var(--a-glow),.55) ${trim}%, rgba(255,255,255,.08) ${trim}%)` }}
        />
        <div className="mt-1 flex justify-between font-display text-[6px] text-white/22"><span dir="ltr">00:00</span><span dir="ltr">18:42</span></div>
      </div>
    </>
  );
}

function CompressorBody({
  lossless,
  setLossless,
  compare,
  setCompare,
  savings,
}: {
  lossless: boolean;
  setLossless: (value: boolean) => void;
  compare: number;
  setCompare: (value: number) => void;
  savings: { before: number; after: number; percent: number };
}) {
  const { lang, notify } = useApp();
  return (
    <>
      <div className="mt-2.5 grid grid-cols-2 gap-1.5">
        {[
          { value: true, title: "Lossless", subtitle: lang === "ar" ? "بدون فقد أي بكسل" : "Zero pixel loss", icon: ShieldCheck, color: "#67e8c7" },
          { value: false, title: "Transparent", subtitle: lang === "ar" ? "فقد غير ملحوظ" : "Visually invisible", icon: Sparkles, color: "#f5ce8a" },
        ].map((item) => (
          <button
            key={String(item.value)}
            onClick={() => setLossless(item.value)}
            className={`press relative overflow-hidden rounded-[13px] border p-2 text-right ${
              lossless === item.value ? "border-white/[.16] bg-white/[.07]" : "border-white/[.06] bg-white/[.022]"
            }`}
          >
            {lossless === item.value && <span className="absolute inset-0 bg-[radial-gradient(circle_at_100%_0%,rgba(var(--a-glow),.16),transparent_65%)]" />}
            <div className="relative flex items-center gap-1.5">
              <item.icon size={11} style={{ color: item.color }} />
              <p className="text-[8.5px] font-medium text-white/75">{item.title}</p>
              {lossless === item.value && <Check size={8} className="mr-auto text-white/55" />}
            </div>
            <p className="relative mt-1 text-[6.5px] text-white/30">{item.subtitle}</p>
          </button>
        ))}
      </div>

      {/* before / after compare */}
      <div className="mt-2.5">
        <div className="mb-1.5 flex items-center justify-between px-0.5">
          <p className="flex items-center gap-1 text-[9px] font-medium text-white/55"><ImageIcon size={9} /> {lang === "ar" ? "مقارنة قبل / بعد" : "Before / After"}</p>
          <span className="rounded-full bg-[#67e8c7]/10 px-1.5 py-0.5 text-[6.5px] text-[#67e8c7]">SSIM 97.4%</span>
        </div>
        <div className="relative h-[138px] overflow-hidden rounded-[14px] border border-white/[.08]">
          <img src={IMAGES.aurora2} alt="after compression" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0" style={{ clipPath: `inset(0 ${100 - compare}% 0 0)` }}>
            <img src={IMAGES.aurora2} alt="before compression" className="h-full w-full object-cover" style={{ filter: "saturate(.82) brightness(.86)" }} />
            <span className="absolute inset-0 bg-black/15" />
            <span className="absolute left-1.5 top-1.5 rounded-[5px] border border-white/15 bg-black/45 px-1.5 py-0.5 text-[6.5px] text-white/65 backdrop-blur-md">{lang === "ar" ? "قبل" : "Before"} · 8.2 MB</span>
          </div>
          <span className="absolute right-1.5 top-1.5 rounded-[5px] border border-white/15 bg-black/45 px-1.5 py-0.5 text-[6.5px] text-white/70 backdrop-blur-md">{lang === "ar" ? "بعد" : "After"} · {savings.after} MB</span>
          <div className="pointer-events-none absolute inset-y-0" style={{ left: `${compare}%` }}>
            <span className="absolute inset-y-0 left-0 w-[1.5px] bg-white/80 shadow-[0_0_10px_rgba(255,255,255,.5)]" />
            <span className="absolute left-1/2 top-1/2 grid h-6 w-6 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border border-white/60 bg-white/25 backdrop-blur-md">
              <ArrowRight size={9} className="text-white" />
            </span>
          </div>
          <input
            type="range"
            min={5}
            max={95}
            value={compare}
            onChange={(event) => setCompare(Number(event.target.value))}
            aria-label="compare before after"
            className="absolute inset-0 h-full w-full cursor-ew-resize opacity-0"
          />
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent px-2 pb-1.5 pt-4">
            <div className="flex items-center justify-between text-[7px]">
              <span className="flex items-center gap-1 font-display text-white/60"><ArrowDown size={8} /> {lang === "ar" ? "وفّرت" : "Saved"} <span className="font-semibold text-[#67e8c7]">{savings.percent}%</span></span>
              <span className="font-display text-white/40">{savings.before} → {savings.after} MB</span>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-2 grid grid-cols-3 gap-1.5">
        {[
          { icon: FileImage, label: "JPEG", detail: "mozjpeg", color: "#ffadbd" },
          { icon: FileArchive, label: "ZIP/APK", detail: "Zopfli", color: "#f5ce8a" },
          { icon: Film, label: "HEVC / AV1", detail: "VMAF ≥ 95", color: "#8db8ff" },
        ].map((tool) => (
          <button key={tool.label} onClick={() => notify(`${tool.label} · ${tool.detail} — ${lang === "ar" ? "الاستراتيجية جاهزة" : "strategy ready"}`)} className="press rounded-[10px] border border-white/[.06] bg-white/[.025] p-1.5 text-right">
            <tool.icon size={10} style={{ color: tool.color }} />
            <p className="mt-1 font-display text-[7px] font-medium text-white/52">{tool.label}</p>
            <p className="font-display text-[6px] text-white/25">{tool.detail}</p>
          </button>
        ))}
      </div>

      <div className="mt-2 flex items-center gap-1.5 rounded-[10px] border border-white/[.06] bg-black/20 px-2 py-1.5">
        <RotateCcw size={9} className="shrink-0 text-white/30" />
        <p className="flex-1 text-[6.8px] leading-4 text-white/28">{lang === "ar" ? "إن لم يصغر الملف فعليًا فلن يُعرض ناتج أكبر — نعرض الحقيقة دائمًا." : "If the file doesn't actually shrink, no larger output is delivered — always truthful."}</p>
        <Badge className="shrink-0 px-1 py-0 text-[6px] text-white/35">{lossless ? "PNG / OXIPNG" : "NEAR-LOSSLESS"}</Badge>
      </div>
    </>
  );
}

export function AudioPreviewStrip() {
  return (
    <div className="flex items-end gap-[2px]">
      {[30, 55, 35, 80, 48, 65, 90, 42, 70, 32, 62].map((h, index) => (
        <span key={index} className="w-[2px] rounded-full bg-[var(--a2)]" style={{ height: `${Math.max(4, h / 5)}px`, opacity: 0.3 + h / 130 }} />
      ))}
    </div>
  );
}

export function ConversionBadge() {
  return (
    <span className="flex items-center gap-1 text-[7px] text-white/30">
      <AudioLines size={8} /> {TOOLS.converterFormats.length} formats
    </span>
  );
}
