import { motion } from "framer-motion";
import {
  ArrowUpLeft,
  Check,
  Download,
  FolderDown,
  Globe2,
  Home,
  Layers,
  Lock,
  Palette,
  Settings,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Wand2,
  Zap,
} from "lucide-react";
import { AppProvider, useApp } from "./state";
import { Phone } from "./components/Phone";
import { BrandMark } from "./components/ui";
import { THEMES, type Screen } from "./data";

const screenItems: { id: Screen; icon: typeof Home; ar: string; en: string; hint: string }[] = [
  { id: "home", icon: Home, ar: "الرئيسية", en: "Home", hint: "لصق · تحليل" },
  { id: "downloads", icon: Download, ar: "التحميلات", en: "Downloads", hint: "طابور حي" },
  { id: "browser", icon: Globe2, ar: "المتصفح", en: "Browser", hint: "Sniffer" },
  { id: "files", icon: FolderDown, ar: "المكتبة", en: "Library", hint: "قبو مشفّر" },
  { id: "tools", icon: Wand2, ar: "الأدوات", en: "Tools", hint: "تحويل · ضغط" },
  { id: "settings", icon: Settings, ar: "الإعدادات", en: "Settings", hint: "ثيمات · شبكة" },
];

const features = [
  { icon: Layers, title: "محرك تحميل مجزأ", en: "Segmented engine", body: "8–32 اتصالًا متوازيًا مع Work-Stealing واستكمال آمن بعد إغلاق التطبيق." },
  { icon: Sparkles, title: "تحليل متعدد المراحل", en: "Parallel analyzer", body: "أول معلومة في أقل من 300ms، كل الجودات والترجمات والحجم الحقيقي." },
  { icon: ShieldCheck, title: "خصوصية بلا تنازل", en: "Private by default", body: "بدون Firebase أو تتبّع. حجب إعلانات، DNS مشفّر، وقبو بالبصمة." },
  { icon: Palette, title: "Aurora Glass", en: "Custom design system", body: "زجاج حقيقي وتوهج Gemini وأنيميشن Spring — صفر Material في الكود." },
];

function Showcase() {
  const { lang, setLang, theme, setTheme, screen, setScreen, setUrl, analyze, notify, setOnboarding } = useApp();
  const isAr = lang === "ar";

  const tryDemo = () => {
    setScreen("home");
    setUrl("https://youtube.com/watch?v=aurora4k");
    analyze("https://youtube.com/watch?v=aurora4k");
    notify(isAr ? "حلّلنا رابط YouTube تجريبيًا — جرّب الأزرار الأربعة" : "Sample YouTube link analyzed — try the four smart buttons");
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#06070b] text-white" dir="rtl">
      {/* ambient background */}
      <div className="pointer-events-none fixed inset-0 -z-0">
        <div className="absolute left-[8%] top-[-12%] h-[420px] w-[420px] rounded-full bg-[#4285F4]/[.18] blur-[110px]" />
        <div className="absolute right-[16%] top-[6%] h-[380px] w-[380px] rounded-full bg-[#9B72CB]/[.16] blur-[120px]" />
        <div className="absolute bottom-[-12%] left-[40%] h-[430px] w-[430px] rounded-full bg-[#D96570]/[.10] blur-[130px]" />
        <div className="absolute inset-0 opacity-[.035]" style={{ backgroundImage: "radial-gradient(circle, rgba(255,255,255,.55) 1px, transparent 1px)", backgroundSize: "34px 34px" }} />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_0%,transparent_20%,#06070b_78%)]" />
      </div>

      <div className="relative mx-auto max-w-[1460px] px-4 pb-16 pt-5 sm:px-7">
        {/* nav */}
        <header className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <BrandMark size={35} standalone />
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-display text-[16px] font-semibold tracking-[-0.02em] text-white">Aurora Get</span>
                <span className="rounded-full border border-white/10 bg-white/[.04] px-1.5 py-[2px] font-display text-[6.5px] tracking-[0.14em] text-white/40">V1.0</span>
              </div>
              <span className="text-[7.5px] tracking-[0.08em] text-white/25">AURORA GLASS · ANDROID</span>
            </div>
          </div>
          <nav className="hidden items-center gap-1 rounded-full border border-white/[.06] bg-white/[.025] p-1 backdrop-blur-xl lg:flex">
            {[
              { label: isAr ? "المعاينة" : "Preview", target: "preview" },
              { label: isAr ? "المزايا" : "Features", target: "features" },
              { label: isAr ? "نظام التصميم" : "Design system", target: "design" },
            ].map((item, index) => (
              <button
                key={item.target}
                onClick={() => document.getElementById(item.target)?.scrollIntoView({ behavior: "smooth", block: index === 0 ? "start" : "center" })}
                className={`press rounded-full px-3 py-1.5 text-[9px] transition-colors ${index === 0 ? "bg-white/[.09] text-white/80" : "text-white/35 hover:text-white/70"}`}
              >
                {item.label}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <div className="hidden items-center gap-1.5 rounded-full border border-[#67e8c7]/15 bg-[#67e8c7]/[.05] px-2 py-1 md:flex">
              <span className="relative flex h-1.5 w-1.5"><span className="absolute h-full w-full animate-ping rounded-full bg-[#67e8c7]/70" /><span className="relative h-1.5 w-1.5 rounded-full bg-[#67e8c7]" /></span>
              <span className="text-[7.5px] text-[#67e8c7]/70">{isAr ? "نموذج تفاعلي مباشر" : "Live interactive preview"}</span>
            </div>
            <button onClick={() => setOnboarding(true)} className="press flex items-center gap-1.5 rounded-full border border-white/[.1] bg-white/[.045] px-3 py-2 text-[8.5px] text-white/65 backdrop-blur-xl hover:bg-white/[.08] hover:text-white">
              <Sparkles size={11} /> <span className="hidden sm:inline">{isAr ? "شاشة الترحيب" : "Onboarding"}</span>
              <ArrowUpLeft size={10} className="text-white/35" />
            </button>
          </div>
        </header>

        {/* main stage */}
        <main id="preview" className="mt-8 grid grid-cols-1 items-start gap-8 lg:mt-10 lg:grid-cols-[1fr_auto_310px] xl:gap-12">
          {/* left narrative */}
          <div className="order-2 hidden pt-10 lg:order-1 lg:block">
            <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ type: "spring", stiffness: 180, damping: 24 }}>
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/[.08] bg-white/[.03] px-2.5 py-1 text-[8px] text-white/40 backdrop-blur-xl">
                <span className="h-1.5 w-1.5 rounded-full app-btn-primary" />
                {isAr ? "تطبيق Android كامل · Kotlin + Compose" : "Native Android · Kotlin + Compose"}
              </div>
              <h1 className="max-w-[420px] text-[42px] font-semibold leading-[1.32] tracking-[-0.035em] xl:text-[48px]">
                حمّل ما تحب.
                <br />
                <span className="aurora-text">{isAr ? "بتصميم يشبه السحر." : "In glass, at lightning speed."}</span>
              </h1>
              <p className="mt-4 max-w-[360px] text-[11px] leading-[2.1] text-white/36">
                {isAr
                  ? "Aurora Get يجمع تحليل الروابط الذكي، محرك تحميل مجزأ فائق السرعة، ومعاينة كل وسائطك — في واجهة زجاجية عربية بالكامل مستوحاة من مساعد Gemini."
                  : "Aurora Get unifies smart link analysis, a segmented lightning-fast engine, and previews of all your media — inside a fully Arabic, Gemini-inspired glass interface."}
              </p>

              <div className="mt-5 flex flex-wrap gap-2">
                <button onClick={tryDemo} className="press app-btn-primary flex items-center gap-1.5 rounded-[12px] px-4 py-2.5 text-[9.5px] font-semibold text-white">
                  <Zap size={12} /> {isAr ? "جرّب التحليل الآن" : "Try the analyzer"}
                </button>
                <button onClick={() => setScreen("browser")} className="press flex items-center gap-1.5 rounded-[12px] border border-white/[.1] bg-white/[.03] px-3.5 py-2.5 text-[9px] text-white/55 hover:bg-white/[.06]">
                  <Globe2 size={12} /> {isAr ? "المتصفح الداخلي" : "In-app browser"}
                </button>
              </div>

              <div className="mt-7 grid max-w-[380px] grid-cols-3 gap-2">
                {[
                  { value: "1,800+", label: isAr ? "موقع مدعوم" : "supported sites" },
                  { value: "32", label: isAr ? "اتصال متوازٍ" : "parallel segments" },
                  { value: "< 300ms", label: isAr ? "أول معلومة" : "first insight" },
                ].map((stat) => (
                  <div key={stat.label} className="rounded-[13px] border border-white/[.06] bg-white/[.025] px-2 py-2.5 text-center backdrop-blur-xl">
                    <p className="font-display text-[13px] font-semibold text-white/85">{stat.value}</p>
                    <p className="mt-0.5 text-[6.5px] text-white/27">{stat.label}</p>
                  </div>
                ))}
              </div>

              <div className="mt-5 flex flex-wrap gap-1.5">
                {[
                  { icon: ShieldCheck, label: isAr ? "صفر تتبّع" : "Zero tracking" },
                  { icon: Lock, label: isAr ? "قبو بالبصمة" : "Biometric vault" },
                  { icon: Layers, label: isAr ? "بدون Material" : "No Material" },
                  { icon: Smartphone, label: "RTL كامل" },
                ].map((chip) => (
                  <span key={chip.label} className="flex items-center gap-1.5 rounded-full border border-white/[.065] bg-white/[.025] px-2 py-1 text-[7.5px] text-white/35">
                    <chip.icon size={9} className="text-white/45" /> {chip.label}
                  </span>
                ))}
              </div>

              <div className="mt-8 flex items-center gap-2 rounded-[14px] border border-white/[.055] bg-white/[.02] p-2.5">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-[9px] bg-[linear-gradient(140deg,rgba(66,133,244,.22),rgba(155,114,203,.22))]">
                  <Download size={12} className="text-[#8db8ff]" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-[8px] font-medium text-white/55">{isAr ? "حزمة Android جاهزة في المشروع" : "Android package inside the project"}</p>
                  <p className="font-display text-[6.5px] text-white/25" dir="ltr">JP PROJ/ · Kotlin 2.x · minSdk 24 · targetSdk 35</p>
                </div>
                <Check size={12} className="shrink-0 text-[#67e8c7]/70" />
              </div>
            </motion.div>
          </div>

          {/* phone */}
          <div className="order-1 flex justify-center lg:order-2">
            <motion.div initial={{ opacity: 0, y: 26, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ type: "spring", stiffness: 160, damping: 22, delay: 0.06 }} className="w-full max-w-[394px]">
              <Phone onOpenOnboarding={() => setOnboarding(true)} />
            </motion.div>
          </div>

          {/* right controls */}
          <aside className="order-3 hidden space-y-2.5 pt-2 lg:block">
            <div className="glass rounded-[20px] p-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-semibold text-white/75">{isAr ? "شاشات التطبيق" : "App screens"}</p>
                  <p className="mt-0.5 text-[7px] text-white/27">{isAr ? "بدّل مباشرة داخل الهاتف" : "Switch directly inside the device"}</p>
                </div>
                <span className="rounded-full border border-white/[.08] bg-white/[.04] px-1.5 py-0.5 font-display text-[6.5px] text-white/35">07</span>
              </div>
              <div className="mt-2.5 grid grid-cols-2 gap-1.5">
                {screenItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setScreen(item.id)}
                    className={`press relative overflow-hidden rounded-[12px] border px-2 py-2 text-right transition-colors ${
                      screen === item.id
                        ? "border-[rgba(var(--a-glow),.32)] bg-[rgba(var(--a-glow),.13)]"
                        : "border-white/[.06] bg-white/[.022] hover:bg-white/[.045]"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`grid h-6 w-6 place-items-center rounded-[8px] ${screen === item.id ? "bg-white/[.12] text-white" : "bg-white/[.035] text-white/40"}`}>
                        <item.icon size={11} />
                      </span>
                      {screen === item.id && <span className="h-1 w-1 rounded-full bg-[#67e8c7]" />}
                    </div>
                    <p className={`mt-1.5 text-[8px] font-medium ${screen === item.id ? "text-white/85" : "text-white/50"}`}>{isAr ? item.ar : item.en}</p>
                    <p className="mt-0.5 text-[6px] text-white/22">{item.hint}</p>
                  </button>
                ))}
                <button onClick={() => setOnboarding(true)} className="press relative overflow-hidden rounded-[12px] border border-white/[.06] bg-[linear-gradient(140deg,rgba(155,114,203,.13),rgba(66,133,244,.06))] px-2 py-2 text-right">
                  <div className="flex items-center justify-between">
                    <span className="grid h-6 w-6 place-items-center rounded-[8px] bg-white/[.08] text-white/65"><Sparkles size={11} /></span>
                    <ArrowUpLeft size={9} className="text-white/25" />
                  </div>
                  <p className="mt-1.5 text-[8px] font-medium text-white/60">{isAr ? "الترحيب" : "Onboarding"}</p>
                  <p className="mt-0.5 text-[6px] text-white/22">01 · intro</p>
                </button>
              </div>
            </div>

            <div id="design" className="glass rounded-[20px] p-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-semibold text-white/75">{isAr ? "المظهر والهوية" : "Appearance"}</p>
                  <p className="mt-0.5 text-[7px] text-white/27">{isAr ? "يتغير داخل الهاتف فورًا" : "Live inside the device"}</p>
                </div>
                <Palette size={12} className="text-white/30" />
              </div>
              <div className="mt-2.5 grid grid-cols-3 gap-1.5">
                {THEMES.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setTheme(item.id)}
                    className={`press rounded-[9px] border p-1 text-right ${theme === item.id ? "border-white/25 bg-white/[.07]" : "border-white/[.05] bg-white/[.02]"}`}
                  >
                    <span className="flex h-2.5 overflow-hidden rounded-full">
                      {item.colors.map((color) => <span key={color} className="flex-1" style={{ background: color }} />)}
                    </span>
                    <span className="mt-1 flex items-center justify-between">
                      <span className="text-[6.5px] text-white/40">{isAr ? item.ar : item.en}</span>
                      {theme === item.id && <Check size={6.5} className="text-white/70" />}
                    </span>
                  </button>
                ))}
              </div>
              <div className="mt-2 flex items-center justify-between rounded-[9px] bg-white/[.025] px-2 py-1.5">
                <span className="text-[7px] text-white/32">{isAr ? "لغة الواجهة" : "Interface language"}</span>
                <div className="flex rounded-[6px] border border-white/[.07] bg-black/25 p-[1px]">
                  {(["ar", "en"] as const).map((code) => (
                    <button key={code} onClick={() => setLang(code)} className={`press rounded-[5px] px-2 py-[3px] text-[6.5px] ${lang === code ? "bg-white/[.12] text-white/85" : "text-white/30"}`}>
                      {code === "ar" ? "عربي" : "EN"}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-[20px] border border-white/[.08] bg-[linear-gradient(150deg,rgba(155,114,203,.14),rgba(66,133,244,.07),rgba(217,101,112,.08))] p-3 backdrop-blur-xl">
              <div className="absolute -left-3 -top-6 h-16 w-16 rounded-full bg-[rgba(var(--a-glow-2),.3)] blur-2xl" />
              <div className="relative flex items-start gap-2">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-[9px] border border-white/10 bg-white/[.07]"><Layers size={12} className="text-white/75" /></span>
                <div>
                  <p className="text-[9px] font-medium text-white/72">30+ modules · Clean MVI</p>
                  <p className="mt-0.5 text-[6.5px] leading-4 text-white/28">app · core · feature · engine — كل شاشة معروضة هنا لها مسار Android حقيقي.</p>
                </div>
              </div>
              <div className="relative mt-2 flex items-center gap-1.5">
                <span className="rounded border border-white/[.08] bg-black/20 px-1.5 py-0.5 font-display text-[6px] text-white/35">compose.foundation</span>
                <span className="rounded border border-[#67e8c7]/20 bg-[#67e8c7]/[.06] px-1.5 py-0.5 font-display text-[6px] text-[#67e8c7]/65">No Material</span>
              </div>
            </div>
          </aside>
        </main>

        {/* mobile demo trigger */}
        <div className="mt-5 flex justify-center gap-2 lg:hidden">
          <button onClick={tryDemo} className="press app-btn-primary flex items-center gap-1.5 rounded-[11px] px-3 py-2 text-[9px] font-medium text-white"><Zap size={11} /> {isAr ? "جرّب التحليل" : "Try analyzer"}</button>
          <button onClick={() => setOnboarding(true)} className="press flex items-center gap-1.5 rounded-[11px] border border-white/[.1] bg-white/[.03] px-3 py-2 text-[9px] text-white/55"><Sparkles size={11} /> {isAr ? "الترحيب" : "Onboarding"}</button>
        </div>

        {/* features */}
        <section id="features" className="relative mt-20 scroll-mt-6">
          <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
            <div>
              <span className="text-[7.5px] tracking-[0.18em] text-[#8db8ff]/60">BUILT DIFFERENT</span>
              <h2 className="mt-2 text-[24px] font-semibold tracking-[-0.02em] text-white/90 sm:text-[30px]">{isAr ? "قوة محرك، هدوء تصميم." : "Engineered power. Serene design."}</h2>
            </div>
            <p className="max-w-[350px] text-[9px] leading-5 text-white/30">{isAr ? "كل تفاصيل Aurora Get مبنية لتكون سريعة وواضحة — من التجزئة المتوازية إلى أنعم زاوية في الواجهة." : "Every detail in Aurora Get is built to be fast and clear — from parallel segmentation to the softest corner."}</p>
          </div>
          <div className="mt-5 grid gap-2.5 sm:grid-cols-2 xl:grid-cols-4">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ delay: index * 0.06, type: "spring", stiffness: 200, damping: 24 }}
                className="specular group relative overflow-hidden rounded-[20px] border border-white/[.07] bg-white/[.026] p-3.5 backdrop-blur-xl transition-colors hover:bg-white/[.05]"
              >
                <div className="absolute -left-5 -top-6 h-16 w-16 rounded-full bg-[rgba(var(--a-glow-2),.16)] blur-2xl transition-opacity group-hover:opacity-100" />
                <span className="relative grid h-9 w-9 place-items-center rounded-[12px] border border-white/[.09] bg-white/[.045] text-white/65">
                  <feature.icon size={16} strokeWidth={1.7} />
                </span>
                <p className="relative mt-3 text-[11px] font-semibold text-white/80">{feature.title}</p>
                <p className="relative mt-0.5 font-display text-[7px] tracking-[0.08em] text-white/22">{feature.en}</p>
                <p className="relative mt-2 text-[8.5px] leading-[1.95] text-white/32">{feature.body}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* design strip */}
        <section className="relative mt-10 overflow-hidden rounded-[26px] border border-white/[.08] bg-[linear-gradient(130deg,rgba(155,114,203,.12),rgba(10,12,20,.55)_45%,rgba(66,133,244,.09))] p-5 backdrop-blur-xl sm:p-7">
          <div className="absolute -left-10 -top-16 h-56 w-56 rounded-full bg-[#9B72CB]/20 blur-[70px]" />
          <div className="absolute -bottom-20 right-10 h-56 w-56 rounded-full bg-[#4285F4]/15 blur-[70px]" />
          <div className="relative flex flex-col justify-between gap-6 md:flex-row md:items-center">
            <div className="max-w-[440px]">
              <div className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full app-btn-primary" />
                <span className="font-display text-[7px] tracking-[0.18em] text-white/35">AURORA GLASS · DESIGN SYSTEM</span>
              </div>
              <h2 className="mt-2 text-[20px] font-semibold leading-[1.55] text-white/88">{isAr ? "زجاج حقيقي، توهج نابض، وحركة كالفيزياء." : "Real glass, glowing gradients, physics-based motion."}</h2>
              <p className="mt-1.5 text-[9px] leading-5 text-white/30">{isAr ? "Haze blur، حدود Specular، ضجيج خفيف، Mesh Gradient متحرك، وSpring في كل لمسة — بدون أي مكوّن Material." : "Haze blur, specular edges, subtle grain, animated mesh gradients and springs on every touch — with zero Material components."}</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {[
                { label: "Haze blur", value: "real" },
                { label: "Spring", value: "native" },
                { label: "RTL", value: "full" },
                { label: "Material", value: "none" },
              ].map((item) => (
                <div key={item.label} className="rounded-[12px] border border-white/[.08] bg-black/20 px-2.5 py-2 backdrop-blur-xl">
                  <p className="font-display text-[11px] font-semibold text-white/75">{item.value}</p>
                  <p className="mt-0.5 text-[6.5px] text-white/28">{item.label}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="relative mt-5 flex flex-wrap items-center gap-2 border-t border-white/[.06] pt-4">
            <span className="text-[7px] text-white/25">{isAr ? "الكود الأصلي:" : "Native code:"}</span>
            {["Kotlin 2.x", "Compose Foundation", "Room", "WorkManager", "yt-dlp", "FFmpeg", "OkHttp · Cronet", "Coil 3", "Media3"].map((tag) => (
              <span key={tag} className="rounded-full border border-white/[.06] bg-white/[.025] px-2 py-1 font-display text-[6.5px] text-white/32">{tag}</span>
            ))}
            <span className="mr-auto flex items-center gap-1 text-[7px] text-white/25"><ShieldCheck size={8} /> {isAr ? "بدون Firebase · بدون تحليلات" : "No Firebase · No analytics"}</span>
          </div>
        </section>

        <footer className="mt-9 flex flex-col items-center justify-between gap-3 border-t border-white/[.055] pt-5 sm:flex-row">
          <div className="flex items-center gap-2">
            <BrandMark size={20} />
            <span className="text-[8px] text-white/30">Aurora Get · {isAr ? "نموذج واجهة تفاعلي لتطبيق Android" : "Interactive UI preview of a native Android app"}</span>
          </div>
          <div className="flex items-center gap-3 text-[7px] text-white/22">
            <span>{isAr ? "المسؤولية على المستخدم في احترام حقوق النشر." : "Users are responsible for respecting copyright."}</span>
            <span>·</span>
            <span className="font-display">JP PROJ</span>
            <span>·</span>
            <span>v1.0.0</span>
          </div>
        </footer>
      </div>

    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Showcase />
    </AppProvider>
  );
}
