import { motion, AnimatePresence } from "framer-motion";
import {
  AudioLines,
  Check,
  ChevronLeft,
  ChevronRight,
  Container,
  Download,
  FileArchive,
  FileText,
  FolderDown,
  Globe2,
  Home,
  Image as ImageIcon,
  Music2,
  Pause,
  Play,
  Settings,
  Sparkles,
  Video,
  Wrench,
  X,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { cn } from "../utils/cn";
import { useApp } from "../state";
import type { MediaKind, Screen } from "../data";

export function BrandMark({ size = 34, standalone = false }: { size?: number; standalone?: boolean }) {
  return (
    <div
      className={cn(
        "relative grid shrink-0 place-items-center overflow-hidden rounded-[30%]",
        standalone && "shadow-[0_12px_40px_-10px_rgba(155,114,203,.65)]",
      )}
      style={{
        width: size,
        height: size,
        background: "linear-gradient(140deg, var(--a1) 0%, var(--a2) 54%, var(--a3) 100%)",
        boxShadow: "inset 0 1px 1px rgba(255,255,255,.45), inset 0 -8px 18px rgba(0,0,0,.18)",
      }}
    >
      <span className="absolute inset-0 rounded-[30%] bg-[radial-gradient(circle_at_28%_18%,rgba(255,255,255,.48),transparent_42%)]" />
      <svg width={size * 0.62} height={size * 0.62} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path
          d="M12 3.2c.6 4.6 3.4 7.4 8.1 8.1-4.7.7-7.5 3.5-8.1 8.1-.6-4.6-3.4-7.4-8.1-8.1 4.7-.7 7.5-3.5 8.1-8.1Z"
          fill="white"
          fillOpacity=".96"
        />
        <path d="M5.3 16.8c.3 2 1.5 3.2 3.5 3.5-2 .3-3.2 1.5-3.5 3.5-.3-2-1.5-3.2-3.5-3.5 2-.3 3.2-1.5 3.5-3.5Z" fill="white" fillOpacity=".65" transform="translate(2 -2) scale(.72)" />
      </svg>
    </div>
  );
}

export function AppStatusBar() {
  const { lang } = useApp();
  const now = new Date();
  const time = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`;
  return (
    <div className="relative z-30 flex h-[38px] items-center justify-between px-6 pt-1 text-[11px] font-semibold text-white/90">
      <span className="font-display tabular-nums tracking-wide">{time}</span>
      <div className="flex items-center gap-1.5">
        <span className="text-[9px] font-medium tracking-wide text-white/60">{lang === "ar" ? "٥G" : "5G"}</span>
        <svg width="15" height="10" viewBox="0 0 16 11" fill="none" aria-hidden="true">
          {[3, 5, 7, 9].map((h, i) => (
            <rect key={h} x={i * 4} y={10 - h} width="2.4" height={h} rx=".8" fill="white" opacity={i === 3 ? 1 : 0.82} />
          ))}
        </svg>
        <div className="ml-0.5 flex h-[10px] w-[20px] items-center rounded-[3px] border border-white/70 p-[1.5px]">
          <div className="h-full w-[72%] rounded-[1.5px] bg-white" />
        </div>
      </div>
    </div>
  );
}

export function GlassCard({
  children,
  className,
  glow = false,
  onClick,
  as = "div",
}: {
  children: ReactNode;
  className?: string;
  glow?: boolean;
  onClick?: () => void;
  as?: "div" | "button";
}) {
  const Tag = as;
  return (
    <Tag
      onClick={onClick}
      className={cn(
        "specular relative overflow-hidden rounded-[24px] glass",
        glow && "shadow-[0_22px_60px_-32px_rgba(var(--a-glow-2),.65)]",
        as === "button" && "press text-right",
        className,
      )}
    >
      {children}
    </Tag>
  );
}

export function IconButton({
  children,
  onClick,
  label,
  className,
  active,
  size = "md",
}: {
  children: ReactNode;
  onClick?: () => void;
  label: string;
  className?: string;
  active?: boolean;
  size?: "sm" | "md";
}) {
  return (
    <button
      aria-label={label}
      title={label}
      onClick={onClick}
      className={cn(
        "press relative grid place-items-center rounded-full border border-white/[.08] bg-white/[.045] text-white/70 backdrop-blur-xl hover:bg-white/[.09] hover:text-white",
        size === "md" ? "h-10 w-10" : "h-8 w-8",
        active && "border-white/20 bg-white/[.12] text-white",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Badge({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/[.07] px-2 py-[3px] text-[9px] font-medium leading-none text-white/70",
        className,
      )}
    >
      {children}
    </span>
  );
}

export function TypeIcon({ kind, size = 16 }: { kind: MediaKind; size?: number }) {
  const map: Record<MediaKind, { icon: LucideIcon; color: string }> = {
    video: { icon: Video, color: "#8fb6ff" },
    audio: { icon: Music2, color: "#c6a7ff" },
    image: { icon: ImageIcon, color: "#ffb2c1" },
    file: { icon: FileText, color: "#8de8d5" },
  };
  const { icon: Icon, color } = map[kind];
  return <Icon size={size} style={{ color }} strokeWidth={1.9} />;
}

export function SmartKindButton({
  kind,
  count,
  onClick,
  compact = false,
}: {
  kind: MediaKind;
  count: number;
  onClick: () => void;
  compact?: boolean;
}) {
  const { t } = useApp();
  const kinds: Record<MediaKind, { label: MediaKind; icon: LucideIcon; tone: string; ring: string }> = {
    audio: { label: "audio", icon: Music2, tone: "#c4a5ff", ring: "rgba(155,114,203,.55)" },
    image: { label: "image", icon: ImageIcon, tone: "#ffadbd", ring: "rgba(217,101,112,.5)" },
    video: { label: "video", icon: Video, tone: "#8db8ff", ring: "rgba(66,133,244,.55)" },
    file: { label: "file", icon: FileText, tone: "#8ae2d0", ring: "rgba(45,212,191,.45)" },
  };
  const item = kinds[kind];
  const Icon = item.icon;
  if (!count) return null;
  return (
    <motion.button
      layout
      initial={{ opacity: 0, scale: 0.75, filter: "blur(6px)" }}
      animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
      exit={{ opacity: 0, scale: 0.8 }}
      transition={{ type: "spring", stiffness: 380, damping: 24 }}
      whileTap={{ scale: 0.94 }}
      onClick={onClick}
      className={cn(
        "group relative flex flex-1 flex-col items-start justify-between overflow-hidden rounded-[19px] border border-white/[.09] bg-white/[.045] text-right backdrop-blur-xl",
        compact ? "h-[62px] p-2.5" : "h-[72px] p-3",
      )}
      style={{ boxShadow: `inset 0 1px 0 rgba(255,255,255,.09), 0 10px 30px -20px ${item.ring}` }}
    >
      <span
        className="pointer-events-none absolute -left-3 -top-3 h-12 w-12 rounded-full opacity-70 blur-xl transition-opacity group-hover:opacity-100"
        style={{ background: item.ring }}
      />
      <div className="flex w-full items-start justify-between">
        <span
          className="grid h-7 w-7 place-items-center rounded-[10px] border border-white/10"
          style={{ background: `${item.ring.replace(/[\d.]+\)$/, "0.18)")}` }}
        >
          <Icon size={14} style={{ color: item.tone }} strokeWidth={2} />
        </span>
        <span className="rounded-full border border-white/10 bg-black/25 px-1.5 py-0.5 text-[9px] font-semibold tabular-nums text-white/70">
          {count}
        </span>
      </div>
      <span className="text-[11px] font-semibold leading-none text-white/85">{t(item.label)}</span>
    </motion.button>
  );
}

export function Sparkline({
  data,
  width = 56,
  height = 20,
}: {
  data: number[];
  width?: number;
  height?: number;
}) {
  const max = Math.max(...data, 1);
  const points = data
    .map((value, i) => {
      const x = (i / (data.length - 1)) * width;
      const y = height - (value / max) * (height - 3) - 1;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
  const id = `spark-${data.join("-").slice(0, 18)}`;
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} fill="none" aria-hidden="true">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="0">
          <stop stopColor="var(--a1)" />
          <stop offset=".55" stopColor="var(--a2)" />
          <stop offset="1" stopColor="var(--a3)" />
        </linearGradient>
      </defs>
      <polyline points={points} stroke={`url(#${id})`} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function ProgressBar({ value, animated = true }: { value: number; animated?: boolean }) {
  return (
    <div className="h-[4px] w-full overflow-hidden rounded-full bg-white/[.07]">
      <div
        className={cn("h-full rounded-full progress-fill transition-[width] duration-700", !animated && "animation-none")}
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (value: boolean) => void; label: string }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={() => onChange(!on)}
      className={cn(
        "relative h-[24px] w-[42px] shrink-0 rounded-full border transition-colors duration-300",
        on ? "border-transparent" : "border-white/10 bg-white/[.07]",
      )}
      style={on ? { background: "linear-gradient(110deg, var(--a1), var(--a2))" } : undefined}
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 500, damping: 32 }}
        className={cn(
          "absolute top-[2px] h-[18px] w-[18px] rounded-full bg-white shadow-sm",
          on ? "right-[2px]" : "right-[20px]",
        )}
      />
    </button>
  );
}

const DOCK: { id: Screen; icon: LucideIcon; label: "home" | "downloads" | "browser" | "files" | "tools" | "settings" }[] = [
  { id: "home", icon: Home, label: "home" },
  { id: "downloads", icon: Download, label: "downloads" },
  { id: "browser", icon: Globe2, label: "browser" },
  { id: "files", icon: FolderDown, label: "files" },
  { id: "tools", icon: Wrench, label: "tools" },
  { id: "settings", icon: Settings, label: "settings" },
];

export function GlassDock() {
  const { screen, setScreen, t, activeCount } = useApp();
  return (
    <nav className="pointer-events-auto absolute inset-x-3 bottom-3 z-40">
      <div className="specular relative flex items-center justify-between rounded-[26px] border border-white/[.11] bg-[rgba(17,19,30,.82)] px-1.5 py-1.5 shadow-[0_22px_50px_-16px_rgba(0,0,0,.9)] backdrop-blur-[28px]">
        {DOCK.map((item) => {
          const active = screen === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setScreen(item.id)}
              aria-label={t(item.label)}
              className={cn(
                "press relative flex flex-1 flex-col items-center justify-center gap-[3px] rounded-[19px] py-[7px] text-[8px] font-medium transition-colors",
                active ? "text-white" : "text-white/42 hover:text-white/75",
              )}
            >
              {active && (
                <motion.span
                  layoutId="dock-pill"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  className="absolute inset-0 rounded-[19px] border border-white/[.13] bg-white/[.095] shadow-[inset_0_1px_0_rgba(255,255,255,.12)]"
                />
              )}
              <span className="relative">
                <Icon size={17} strokeWidth={active ? 2.2 : 1.8} />
                {item.id === "downloads" && activeCount > 0 && (
                  <span className="absolute -right-2 -top-1.5 grid h-[13px] min-w-[13px] place-items-center rounded-full px-[3px] text-[7px] font-bold text-white shadow-sm app-btn-primary">
                    {activeCount}
                  </span>
                )}
              </span>
              <span className="relative leading-none">{t(item.label)}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

export function Sheet({
  open,
  onClose,
  children,
  title,
  subtitle,
  maxHeight = "78%",
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  title?: string;
  subtitle?: string;
  maxHeight?: string;
}) {
  const [host, setHost] = useState<HTMLElement | null>(null);
  useEffect(() => {
    setHost(document.getElementById("phone-overlay"));
  }, []);
  const content = (
    <AnimatePresence>
      {open && (
        <motion.div
          className="absolute inset-0 z-[60] flex items-end"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.button
            aria-label="إغلاق"
            className="absolute inset-0 bg-[#030408]/60 backdrop-blur-[7px]"
            onClick={onClose}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 320, damping: 34 }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.4 }}
            onDragEnd={(_, info) => {
              if (info.offset.y > 110) onClose();
            }}
            style={{ maxHeight }}
            className="relative z-10 flex w-full flex-col overflow-hidden rounded-t-[30px] border-x border-t border-white/[.13] bg-[linear-gradient(170deg,rgba(26,29,43,.97),rgba(10,12,20,.99))] shadow-[0_-30px_80px_rgba(0,0,0,.65)] backdrop-blur-3xl"
          >
            <div className="mx-auto mt-2.5 h-[4px] w-9 rounded-full bg-white/20" />
            {title && (
              <div className="flex items-start justify-between gap-3 px-5 pb-2 pt-3">
                <div>
                  <h3 className="flex items-center gap-2 text-[16px] font-semibold text-white">
                    {title}
                    <Sparkles size={13} className="text-white/40" />
                  </h3>
                  {subtitle && <p className="mt-1 text-[10px] leading-5 text-white/40">{subtitle}</p>}
                </div>
                <IconButton label="إغلاق" onClick={onClose} size="sm">
                  <X size={14} />
                </IconButton>
              </div>
            )}
            <div className="thin-scroll flex-1 overflow-y-auto overflow-x-hidden px-4 pb-5">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
  return host ? createPortal(content, host) : null;
}

export function AppHeader({
  title,
  subtitle,
  right,
  back,
}: {
  title: string;
  subtitle?: string;
  right?: ReactNode;
  back?: () => void;
}) {
  return (
    <header className="flex items-center justify-between gap-2 px-4 pb-3 pt-1">
      <div className="flex min-w-0 items-center gap-2.5">
        {back ? (
          <IconButton label="رجوع" onClick={back} size="sm">
            <ChevronRight size={15} />
          </IconButton>
        ) : (
          <BrandMark size={32} />
        )}
        <div className="min-w-0">
          <h1 className="truncate text-[17px] font-semibold leading-tight text-white">{title}</h1>
          {subtitle && <p className="mt-0.5 truncate text-[9.5px] text-white/38">{subtitle}</p>}
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-1.5">{right}</div>
    </header>
  );
}

export function EmptyState({
  icon: Icon = Container,
  title,
  subtitle,
}: {
  icon?: LucideIcon;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 px-6 py-10 text-center">
      <div className="relative mb-1 grid h-16 w-16 place-items-center rounded-[24px] border border-white/10 bg-white/[.035]">
        <div className="absolute inset-0 rounded-[24px] bg-[radial-gradient(circle_at_50%_20%,rgba(var(--a-glow),.22),transparent_70%)]" />
        <Icon size={25} className="relative text-white/55" strokeWidth={1.5} />
      </div>
      <p className="text-[13px] font-medium text-white/80">{title}</p>
      {subtitle && <p className="max-w-[220px] text-[10px] leading-5 text-white/35">{subtitle}</p>}
    </div>
  );
}

export function FilterPill({
  active,
  onClick,
  children,
  count,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  count?: number;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "press flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-[7px] text-[10px] font-medium transition-colors",
        active ? "chip-active" : "border-white/[.075] bg-white/[.025] text-white/45",
      )}
    >
      {children}
      {typeof count === "number" && (
        <span className={cn("text-[9px] tabular-nums", active ? "text-white/70" : "text-white/30")}>{count}</span>
      )}
    </button>
  );
}

export function InfoRow({ icon: Icon, label, value }: { icon: LucideIcon; label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-[7px]">
      <span className="flex items-center gap-1.5 text-[9.5px] text-white/38">
        <Icon size={11} strokeWidth={1.8} /> {label}
      </span>
      <span className="text-[9.5px] font-medium text-white/70">{value}</span>
    </div>
  );
}

export const icons = {
  audioLines: AudioLines,
  archive: FileArchive,
  check: Check,
  chevronLeft: ChevronLeft,
  chevronRight: ChevronRight,
  globe: Globe2,
  pause: Pause,
  play: Play,
  sparkles: Sparkles,
  video: Video,
  zap: Zap,
};
