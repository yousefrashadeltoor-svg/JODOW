import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  AudioLines,
  Check,
  Download,
  ChevronDown,
  ListMusic,
  Heart,
  Maximize2,
  MoreVertical,
  Pause,
  Play,
  Share2,
  Shuffle,
  SkipBack,
  SkipForward,
  Sparkles,
  Subtitles,
  Volume2,
  X,
  Zap,
} from "lucide-react";
import { useApp } from "../state";
import { HomeScreen } from "../screens/Home";
import { DownloadsScreen } from "../screens/Downloads";
import { BrowserScreen } from "../screens/Browser";
import { FilesScreen } from "../screens/Files";
import { ToolsScreen } from "../screens/Tools";
import { SettingsScreen } from "../screens/Settings";
import { AppStatusBar, GlassDock, IconButton, ProgressBar } from "./ui";
import { OnboardingOverlay } from "./Onboarding";

const SCREENS = {
  home: HomeScreen,
  downloads: DownloadsScreen,
  browser: BrowserScreen,
  files: FilesScreen,
  tools: ToolsScreen,
  settings: SettingsScreen,
} as const;

export function Phone({ onOpenOnboarding }: { onOpenOnboarding: () => void }) {
  const { screen, dir, toast, nowPlaying, setNowPlaying, lang, onboarding, setOnboarding } = useApp();
  const ActiveScreen = SCREENS[screen];

  return (
    <div className="relative w-full max-w-[394px] select-none">
      <div className="pointer-events-none absolute -inset-12 -z-10 rounded-full bg-[rgba(var(--a-glow-2),.16)] blur-[60px]" />
      {/* device frame */}
      <div className="relative rounded-[48px] border border-white/[.14] bg-[linear-gradient(150deg,#3c4050_0%,#14161e_14%,#08090e_52%,#1e212c_88%,#454a59_100%)] p-[3px] shadow-[0_50px_110px_-30px_rgba(0,0,0,.95),0_0_0_1px_rgba(255,255,255,.05),inset_0_1px_0_rgba(255,255,255,.15)]">
        <div className="relative overflow-hidden rounded-[46px] border border-black/80 bg-[#080910]">
          {/* side buttons */}
          <span className="absolute -left-[5px] top-[130px] h-10 w-[3px] rounded-l bg-[#2c303d]" />
          <span className="absolute -left-[5px] top-[180px] h-14 w-[3px] rounded-l bg-[#2c303d]" />
          <span className="absolute -right-[5px] top-[160px] h-16 w-[3px] rounded-r bg-[#2c303d]" />
          {/* dynamic island */}
          <div className="absolute left-1/2 top-[7px] z-50 flex h-[22px] w-[92px] -translate-x-1/2 items-center justify-end rounded-full bg-black px-2.5">
            <span className="h-1.5 w-1.5 rounded-full bg-[#0c1b22] ring-1 ring-[#173040]" />
          </div>

          <AppStatusBar />
          <div dir={dir} className="relative">
            <div className="app-surface relative h-[724px] overflow-hidden">
              <div className="pointer-events-none absolute -left-20 top-10 h-48 w-48 rounded-full bg-[rgba(var(--a-glow-2),.14)] blur-[55px]" />
              <div className="pointer-events-none absolute -right-24 top-[330px] h-52 w-52 rounded-full bg-[rgba(var(--a-glow),.1)] blur-[60px]" />
              <div
                key={screen}
                className="phone-scroll relative h-full overflow-y-auto pb-[76px]"
                style={{ scrollBehavior: "smooth" }}
              >
                <AnimatePresence mode="wait">
                  <motion.div
                    key={screen}
                    initial={{ opacity: 0, scale: 0.985, filter: "blur(5px)" }}
                    animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                    exit={{ opacity: 0, scale: 1.008, filter: "blur(4px)" }}
                    transition={{ duration: 0.26, ease: [0.22, 0.8, 0.25, 1] }}
                  >
                    <ActiveScreen />
                  </motion.div>
                </AnimatePresence>
              </div>

              <div id="phone-overlay" className="pointer-events-none absolute inset-0 z-[60] [&>*]:pointer-events-auto" />

              <GlassDock />
              <OnboardingOverlay open={onboarding} onClose={() => setOnboarding(false)} />

              {/* toast */}
              <AnimatePresence>
                {toast && (
                  <motion.div
                    initial={{ opacity: 0, y: 14, scale: 0.96 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.96 }}
                    transition={{ type: "spring", stiffness: 380, damping: 28 }}
                    className="pointer-events-none absolute inset-x-3 bottom-[74px] z-50"
                  >
                    <div className="glass-deep flex items-center gap-2 rounded-[14px] px-2.5 py-2">
                      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#67e8c7]/15 text-[#67e8c7]"><Check size={12} strokeWidth={2.5} /></span>
                      <p className="flex-1 text-[8.5px] leading-4 text-white/75">{toast}</p>
                      <Sparkles size={10} className="text-white/25" />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <AnimatePresence>
                {nowPlaying && <PlayerOverlay onClose={() => setNowPlaying(null)} lang={lang} />}
              </AnimatePresence>
            </div>
          </div>
          {/* home indicator */}
          <div className="absolute bottom-[5px] left-1/2 z-40 h-[4px] w-[105px] -translate-x-1/2 rounded-full bg-white/60" />
        </div>
      </div>
      <div className="mt-4 flex items-center justify-center gap-2 desktop-only">
        <span className="text-[9px] text-white/25">{lang === "ar" ? "نموذج تفاعلي · استخدمه كما في الجهاز" : "Interactive preview · use it like the real device"}</span>
        <button onClick={onOpenOnboarding} className="press flex items-center gap-1 rounded-full border border-white/[.09] bg-white/[.04] px-2 py-1 text-[8px] text-white/40 hover:text-white/70">
          <Sparkles size={8} /> {lang === "ar" ? "شاشة الترحيب" : "Onboarding"}
        </button>
      </div>
    </div>
  );
}

function PlayerOverlay({ onClose, lang }: { onClose: () => void; lang: "ar" | "en" }) {
  const { nowPlaying, notify } = useApp();
  const [playing, setPlaying] = useState(true);
  const [progress, setProgress] = useState(36);
  const [liked, setLiked] = useState(false);
  const [speed, setSpeed] = useState("1×");
  const [isAudio, setIsAudio] = useState(false);
  if (!nowPlaying) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 20, scale: 0.98 }}
      transition={{ type: "spring", stiffness: 280, damping: 30 }}
      className="absolute inset-0 z-[80] flex flex-col overflow-hidden bg-[#06070b]"
    >
      <div className="absolute inset-0">
        <img src={nowPlaying.image} alt="" className="h-full w-full scale-110 object-cover opacity-25 blur-2xl" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#06070b]/30 via-[#06070b]/75 to-[#06070b]" />
      </div>
      <div className="relative flex items-center justify-between px-4 pt-3">
        <IconButton label="إغلاق" onClick={onClose} size="sm"><X size={14} /></IconButton>
        <div className="text-center">
          <p className="text-[7px] tracking-[0.16em] text-white/30">{lang === "ar" ? "تشغيل الآن" : "NOW PLAYING"}</p>
          <p className="mt-0.5 text-[8.5px] text-white/55">Aurora Media3 · ExoPlayer</p>
        </div>
        <IconButton label="المزيد" size="sm"><MoreVertical size={14} /></IconButton>
      </div>

      <div className="relative flex flex-1 flex-col px-5 pt-4">
        <div className={`relative mx-auto w-full overflow-hidden border border-white/[.12] shadow-[0_30px_70px_-20px_rgba(var(--a-glow-2),.45)] ${isAudio ? "aspect-square rounded-[26px]" : "aspect-video rounded-[22px]"}`}>
          <img src={nowPlaying.image} alt={nowPlaying.title} className="h-full w-full object-cover" />
          <span className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-black/10" />
          <button onClick={() => setPlaying(!playing)} className="absolute inset-0 grid place-items-center">
            {!playing && (
              <span className="grid h-14 w-14 place-items-center rounded-full border border-white/20 bg-black/30 text-white backdrop-blur-xl">
                <Play size={20} className="ml-0.5 fill-white" />
              </span>
            )}
          </button>
          <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
            <span className="rounded-md bg-black/45 px-1.5 py-0.5 font-display text-[7px] text-white/65 backdrop-blur-md">4K · HDR</span>
            <button onClick={() => notify(lang === "ar" ? "وضع PiP مفعّل — تشغيل في نافذة عائمة" : "PiP enabled — floating playback")} className="rounded-md bg-black/45 p-1 text-white/65 backdrop-blur-md"><Maximize2 size={10} /></button>
          </div>
        </div>

        <div className="mt-4">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0 flex-1">
              <h2 className="truncate text-[14px] font-semibold text-white/92">{nowPlaying.title}</h2>
              <p className="mt-1 truncate text-[8.5px] text-white/35">{nowPlaying.subtitle}</p>
            </div>
            <button onClick={() => setLiked(!liked)} className={`press grid h-8 w-8 shrink-0 place-items-center rounded-full border ${liked ? "border-[var(--a3)]/30 bg-[var(--a3)]/15 text-[var(--a3)]" : "border-white/10 bg-white/[.04] text-white/35"}`}>
              <Heart size={13} fill={liked ? "currentColor" : "none"} />
            </button>
          </div>

          <div className="mt-4">
            <div className="mb-1.5 flex items-center justify-between font-display text-[7.5px] tabular-nums text-white/35">
              <span dir="ltr">06:42</span>
              <span dir="ltr">18:42</span>
            </div>
            <div className="relative">
              <ProgressBar value={progress} />
              <input
                type="range"
                min={0}
                max={100}
                value={progress}
                onChange={(event) => setProgress(Number(event.target.value))}
                aria-label="seek"
                className="absolute inset-x-0 -top-2 h-4 w-full cursor-pointer opacity-0"
              />
              <span className="pointer-events-none absolute top-0 h-1 w-1 -translate-y-[2px] rounded-full bg-white shadow-[0_0_8px_white]" style={{ right: `${progress}%` }} />
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between px-2">
            <button onClick={() => setIsAudio(!isAudio)} className="press text-white/35"><Shuffle size={15} /></button>
            <button className="press text-white/65"><SkipBack size={19} fill="currentColor" /></button>
            <button onClick={() => setPlaying(!playing)} className="press app-btn-primary grid h-12 w-12 place-items-center rounded-full text-white">
              {playing ? <Pause size={19} fill="currentColor" /> : <Play size={19} fill="currentColor" className="ml-0.5" />}
            </button>
            <button className="press text-white/65"><SkipForward size={19} fill="currentColor" /></button>
            <button onClick={() => setSpeed(speed === "1×" ? "1.5×" : speed === "1.5×" ? "2×" : "1×")} className="press rounded-md border border-white/10 px-1.5 py-0.5 font-display text-[8px] text-white/45">{speed}</button>
          </div>

          <div className="mt-4 flex items-center gap-1.5">
            {[
              { icon: Subtitles, label: lang === "ar" ? "ترجمة عربية" : "Arabic CC" },
              { icon: OfflineIcon, label: "Offline" },
              { icon: Share2, label: lang === "ar" ? "مشاركة" : "Share" },
              { icon: Volume2, label: "Audio" },
            ].map((item) => (
              <button key={item.label} className="press flex flex-1 items-center justify-center gap-1 rounded-[9px] border border-white/[.07] bg-white/[.035] py-1.5 text-[7px] text-white/38">
                <item.icon size={9} /> {item.label}
              </button>
            ))}
          </div>

          <div className="mt-3 rounded-[14px] border border-white/[.07] bg-white/[.03] p-2.5">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1 text-[8px] text-white/45"><AudioLines size={10} /> {lang === "ar" ? "المسار الصوتي" : "Audio track"} · AAC 256</span>
              <ChevronDown size={10} className="text-white/25" />
            </div>
            <div className="mt-2 flex h-6 items-end gap-[2px]">
              {Array.from({ length: 52 }).map((_, index) => (
                <motion.span
                  key={index}
                  className="flex-1 rounded-full bg-[linear-gradient(to_top,var(--a1),var(--a2),var(--a3))]"
                  style={{ opacity: 0.3 + (index % 7) / 12 }}
                  animate={{ height: playing ? [`${15 + ((index * 13) % 60)}%`, `${25 + ((index * 23) % 70)}%`, `${15 + ((index * 17) % 55)}%`] : "18%" }}
                  transition={{ duration: 0.9 + (index % 5) * 0.12, repeat: playing ? Infinity : 0, repeatType: "mirror", delay: index * 0.015 }}
                />
              ))}
            </div>
          </div>

          <div className="mt-2.5 flex items-center justify-between pb-5">
            <div className="flex items-center gap-1 text-[7px] text-white/22"><Zap size={8} /> PiP · Background playback · Gestures</div>
            <div className="flex items-center gap-1 text-[7px] text-white/22"><ListMusic size={8} /> 24 {lang === "ar" ? "عنصرًا" : "items"}</div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function OfflineIcon({ size = 12 }: { size?: number }) {
  return <Download size={size} />;
}
