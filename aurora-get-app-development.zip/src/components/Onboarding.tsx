import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowUpFromLine,
  AudioLines,
  Check,
  Download,
  Fingerprint,
  ShieldCheck,
  Sparkles,
  Zap,
} from "lucide-react";
import { useApp } from "../state";
import { BrandMark } from "./ui";

export function OnboardingOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [slide, setSlide] = useState(0);
  const { lang } = useApp();
  const isAr = lang === "ar";

  const slides = [
    {
      badge: "AURORA GLASS",
      title: isAr ? "كل وسائطك،\nفي مكان واحد." : "All your media,\nin one place.",
      subtitle: isAr
        ? "فيديو، صوت، صور وملفات من أكثر من 1800 موقع — بسرعة البرق وتصميم يشبه السحر."
        : "Video, audio, images and files from 1,800+ sites — lightning fast and beautifully glassy.",
      accent: "linear-gradient(135deg,#4285F4,#9B72CB,#D96570)",
      icon: Download,
      chipIcon: AudioLines,
      chipColor: "#c6a7ff",
    },
    {
      badge: "SMART ANALYZER",
      title: isAr ? "الصق. اكتشف.\nحمّل." : "Paste. Discover.\nDownload.",
      subtitle: isAr
        ? "نحلل الرابط على مراحل متوازية، نستخرج كل الجودات والحجم الحقيقي، ثم تختار أنت."
        : "We analyze in parallel stages, extract every quality and the exact size — then you choose.",
      accent: "linear-gradient(135deg,#22d3ee,#4285F4,#9B72CB)",
      icon: Sparkles,
      chipIcon: Zap,
      chipColor: "#f5ce8a",
    },
    {
      badge: "PRIVATE BY DEFAULT",
      title: isAr ? "بياناتك\nتبقى لك." : "Your data\nstays yours.",
      subtitle: isAr
        ? "بدون Firebase، بدون تتبّع. محرك مجزأ، قبو بالبصمة، وحجب إعلانات مدمج."
        : "No Firebase, no tracking. Segmented engine, biometric vault and built-in AdBlock.",
      accent: "linear-gradient(135deg,#34d399,#22d3ee,#9B72CB)",
      icon: ShieldCheck,
      chipIcon: Fingerprint,
      chipColor: "#8db8ff",
    },
  ];

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          className="absolute inset-0 z-[90] overflow-hidden bg-[#06070c]"
        >
          <div className="pointer-events-none absolute inset-0">
            <motion.div
              key={slide}
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.42 }}
              className="absolute left-1/2 top-[-10%] h-[330px] w-[330px] -translate-x-1/2 rounded-full blur-[85px]"
              style={{ background: slides[slide].accent }}
            />
            <div className="absolute -bottom-24 -left-20 h-[250px] w-[250px] rounded-full bg-[rgba(var(--a-glow),.2)] blur-[80px]" />
            <div className="absolute inset-0 opacity-[.04]" style={{ backgroundImage: "radial-gradient(circle, white 1px, transparent 1px)", backgroundSize: "20px 20px" }} />
          </div>

          <div className="relative flex h-full flex-col px-5 pb-5 pt-7">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BrandMark size={30} standalone />
                <div>
                  <p className="text-[12px] font-semibold text-white">Aurora Get</p>
                  <p className="text-[7px] tracking-[0.1em] text-white/28">AURORA GLASS · ANDROID</p>
                </div>
              </div>
              <button onClick={onClose} className="press rounded-full border border-white/10 bg-white/[.045] px-2.5 py-1 text-[8px] text-white/40">
                {isAr ? "تخطي" : "Skip"}
              </button>
            </div>

            <div className="flex flex-1 flex-col justify-center">
              <motion.div
                key={slide}
                initial={{ opacity: 0, y: 18, filter: "blur(7px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                transition={{ type: "spring", stiffness: 220, damping: 26 }}
              >
                <div className="relative mx-auto mb-6 grid h-[142px] w-[142px] place-items-center">
                  <span className="absolute inset-0 rotate-6 rounded-[42px] border border-white/10 bg-white/[.025] backdrop-blur-xl" />
                  <span className="absolute inset-2 -rotate-6 rounded-[36px] border border-white/10 bg-white/[.03] backdrop-blur-xl" />
                  <span className="absolute inset-7 rounded-full opacity-60 blur-2xl" style={{ background: slides[slide].accent }} />
                  <div className="relative grid h-[88px] w-[88px] place-items-center rounded-[28px] border border-white/15 shadow-2xl" style={{ background: slides[slide].accent }}>
                    {(() => {
                      const Icon = slides[slide].icon;
                      return <Icon size={32} className="text-white" strokeWidth={1.8} />;
                    })()}
                  </div>
                  <motion.span animate={{ y: [0, -8, 0] }} transition={{ duration: 4, repeat: Infinity }} className="absolute right-0 top-4 rounded-[10px] border border-white/15 bg-black/40 p-2 backdrop-blur-xl">
                    {(() => {
                      const Icon = slides[slide].chipIcon;
                      return <Icon size={12} style={{ color: slides[slide].chipColor }} />;
                    })()}
                  </motion.span>
                  <motion.span animate={{ y: [0, 7, 0] }} transition={{ duration: 3.4, repeat: Infinity, delay: 0.4 }} className="absolute bottom-2 left-0 rounded-[10px] border border-white/15 bg-black/40 p-2 backdrop-blur-xl">
                    <Check size={12} className="text-[#67e8c7]" />
                  </motion.span>
                </div>
                <span className="rounded-full border border-white/12 bg-white/[.05] px-2 py-1 font-display text-[6.5px] tracking-[0.18em] text-white/45">{slides[slide].badge}</span>
                <h1 className="mt-2.5 whitespace-pre-line text-[25px] font-semibold leading-[1.42] tracking-[-0.02em] text-white">{slides[slide].title}</h1>
                <p className="mt-2 max-w-[300px] text-[9.5px] leading-[2.05] text-white/38">{slides[slide].subtitle}</p>
              </motion.div>

              <div className="mt-6 flex items-center gap-1.5">
                {slides.map((_, index) => (
                  <button key={index} onClick={() => setSlide(index)} className={`h-1 rounded-full transition-all ${slide === index ? "w-7 bg-white" : "w-2 bg-white/20"}`} aria-label={`slide ${index + 1}`} />
                ))}
                <span className="mr-auto flex items-center gap-1 text-[6.5px] text-white/25"><ShieldCheck size={8} /> {isAr ? "بدون تتبّع" : "No tracking"}</span>
              </div>

              <div className="mt-4 flex gap-2">
                {slide > 0 && (
                  <button onClick={() => setSlide(slide - 1)} aria-label="السابق" className="press grid h-10 w-10 shrink-0 place-items-center rounded-[12px] border border-white/10 bg-white/[.04] text-white/50">
                    <ArrowUpFromLine size={15} className="-rotate-90" />
                  </button>
                )}
                <button
                  onClick={() => (slide < slides.length - 1 ? setSlide(slide + 1) : onClose())}
                  className="press app-btn-primary flex h-10 flex-1 items-center justify-center gap-1.5 rounded-[12px] text-[10px] font-semibold text-white"
                >
                  {slide < slides.length - 1 ? (isAr ? "التالي" : "Continue") : (isAr ? "ابدأ الاستخدام" : "Get started")}
                  <ArrowUpFromLine size={13} className="rotate-90" />
                </button>
              </div>
              <p className="mt-2.5 text-center text-[6px] text-white/18">{isAr ? "المسؤولية على المستخدم في احترام حقوق النشر." : "Users are responsible for respecting copyright."}</p>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
