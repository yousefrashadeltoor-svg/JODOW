import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  ANALYSES,
  INITIAL_DOWNLOADS,
  T,
  formatBytes,
  type DownloadItem,
  type Lang,
  type MediaKind,
  type Screen,
  type SiteAnalysis,
  type ThemeId,
  type TranslationKey,
} from "./data";

interface StartDownloadPayload {
  title: string;
  kind: MediaKind;
  format: string;
  quality: string;
  sizeBytes: number;
  thumbnail: string;
  source: string;
  approx?: boolean;
}

interface AppContextValue {
  lang: Lang;
  setLang: (lang: Lang) => void;
  t: (key: TranslationKey) => string;
  dir: "rtl" | "ltr";
  theme: ThemeId;
  setTheme: (theme: ThemeId) => void;
  screen: Screen;
  setScreen: (screen: Screen) => void;
  url: string;
  setUrl: (url: string) => void;
  analyzing: boolean;
  analysis: SiteAnalysis | null;
  analyze: (input?: string) => void;
  clearAnalysis: () => void;
  downloads: DownloadItem[];
  activeCount: number;
  totalSpeed: number;
  startDownload: (payload: StartDownloadPayload) => void;
  togglePause: (id: string) => void;
  retryDownload: (id: string) => void;
  removeDownload: (id: string) => void;
  toast: string | null;
  notify: (message: string) => void;
  onboarding: boolean;
  setOnboarding: (value: boolean) => void;
  nowPlaying: { title: string; subtitle: string; image: string } | null;
  setNowPlaying: (value: { title: string; subtitle: string; image: string } | null) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

function createDownload(item: DownloadItem): DownloadItem {
  return item;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>("ar");
  const [theme, setTheme] = useState<ThemeId>("aurora");
  const [screen, setScreen] = useState<Screen>("home");
  const [url, setUrl] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<SiteAnalysis | null>(ANALYSES.youtube);
  const [downloads, setDownloads] = useState<DownloadItem[]>(INITIAL_DOWNLOADS);
  const [toast, setToast] = useState<string | null>(null);
  const [nowPlaying, setNowPlaying] = useState<AppContextValue["nowPlaying"]>(null);
  const [onboarding, setOnboarding] = useState(false);
  const analyzeTimer = useRef<number | null>(null);
  const toastTimer = useRef<number | null>(null);

  const dir = lang === "ar" ? "rtl" : "ltr";
  const t = useCallback((key: TranslationKey) => T[lang][key], [lang]);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  const notify = useCallback((message: string) => {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    setToast(message);
    toastTimer.current = window.setTimeout(() => setToast(null), 3400);
  }, []);

  const analyze = useCallback(
    (input?: string) => {
      const candidate = (input ?? url).trim();
      if (!candidate) {
        notify("الصق رابطًا صالحًا للبدء · Paste a valid link");
        return;
      }
      if (analyzeTimer.current) window.clearTimeout(analyzeTimer.current);
      setAnalyzing(true);
      setAnalysis(null);
      analyzeTimer.current = window.setTimeout(() => {
        const next = /tiktok/i.test(candidate) ? ANALYSES.tiktok : ANALYSES.youtube;
        setAnalysis(next);
        setAnalyzing(false);
      }, 1450);
    },
    [url, notify],
  );

  const clearAnalysis = useCallback(() => {
    setAnalysis(null);
    setUrl("");
  }, []);

  const startDownload = useCallback(
    (payload: StartDownloadPayload) => {
      const item: DownloadItem = createDownload({
        id: `dl-${Date.now()}`,
        title: payload.title,
        kind: payload.kind,
        format: payload.format,
        quality: payload.quality,
        sizeBytes: payload.sizeBytes,
        downloadedBytes: 0,
        speed: 7.6,
        connections: 16,
        status: "downloading",
        thumbnail: payload.thumbnail,
        sparkline: [12, 20, 34, 29, 45, 54, 48, 66, 59, 71, 64, 78],
        source: payload.source,
        approx: payload.approx,
      });
      setDownloads((prev) => [item, ...prev]);
      notify(`${payload.title} — ${T[lang].newDownload}`);
    },
    [lang, notify],
  );

  const togglePause = useCallback((id: string) => {
    setDownloads((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        if (item.status === "completed" || item.status === "failed") return item;
        if (item.status === "downloading") {
          return { ...item, status: "paused", speed: 0, connections: 0 };
        }
        return { ...item, status: "downloading", speed: 6.9, connections: 16 };
      }),
    );
  }, []);

  const retryDownload = useCallback((id: string) => {
    setDownloads((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              status: "downloading",
              speed: 6.4,
              connections: 16,
              downloadedBytes: Math.min(item.downloadedBytes, item.sizeBytes - 1),
            }
          : item,
      ),
    );
  }, []);

  const removeDownload = useCallback((id: string) => {
    setDownloads((prev) => prev.filter((item) => item.id !== id));
  }, []);

  useEffect(() => {
    const interval = window.setInterval(() => {
      setDownloads((prev) => {
        const active = prev.filter((item) => item.status === "downloading").length;
        let slots = Math.max(0, 2 - active);
        return prev.map((item) => {
          if (item.status === "queued" && slots > 0) {
            slots -= 1;
            return {
              ...item,
              status: "downloading",
              speed: 5.8,
              connections: 12,
            };
          }
          if (item.status !== "downloading") return item;
          const speed = Math.min(14.8, Math.max(1.4, item.speed + (Math.random() - 0.48) * 1.9));
          const downloaded = Math.min(
            item.sizeBytes,
            item.downloadedBytes + speed * 1_000_000,
          );
          const done = downloaded >= item.sizeBytes;
          const remaining = (item.sizeBytes - downloaded) / 1_000_000 / speed;
          return {
            ...item,
            downloadedBytes: downloaded,
            speed: done ? 0 : speed,
            connections: done ? 0 : item.connections,
            status: done ? "completed" : "downloading",
            eta: done
              ? undefined
              : `${Math.floor(remaining / 60)
                  .toString()
                  .padStart(2, "0")}:${Math.floor(remaining % 60)
                  .toString()
                  .padStart(2, "0")}`,
            sparkline: [...item.sparkline.slice(1), Math.round((speed / 15) * 100)],
          };
        });
      });
    }, 1200);
    return () => window.clearInterval(interval);
  }, []);

  useEffect(
    () => () => {
      if (analyzeTimer.current) window.clearTimeout(analyzeTimer.current);
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
    },
    [],
  );

  const activeCount = downloads.filter(
    (item) => item.status === "downloading" || item.status === "queued",
  ).length;
  const totalSpeed = downloads
    .filter((item) => item.status === "downloading")
    .reduce((sum, item) => sum + item.speed, 0);

  const value = useMemo<AppContextValue>(
    () => ({
      lang,
      setLang,
      t,
      dir,
      theme,
      setTheme,
      screen,
      setScreen,
      url,
      setUrl,
      analyzing,
      analysis,
      analyze,
      clearAnalysis,
      downloads,
      activeCount,
      totalSpeed,
      startDownload,
      togglePause,
      retryDownload,
      removeDownload,
      toast,
      notify,
      nowPlaying,
      setNowPlaying,
      onboarding,
      setOnboarding,
    }),
    [
      lang,
      t,
      dir,
      theme,
      screen,
      url,
      analyzing,
      analysis,
      analyze,
      clearAnalysis,
      downloads,
      activeCount,
      totalSpeed,
      startDownload,
      togglePause,
      retryDownload,
      removeDownload,
      toast,
      notify,
      nowPlaying,
      onboarding,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

export function humanSize(bytes: number, lang: Lang) {
  return formatBytes(bytes, lang);
}
