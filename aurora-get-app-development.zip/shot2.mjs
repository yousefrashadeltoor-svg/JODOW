import { chromium } from 'playwright';
const browser = await chromium.launch({args:['--no-sandbox']});
const page = await browser.newPage({viewport:{width:1440,height:1100}, deviceScaleFactor:1});
await page.goto('http://localhost:4173', {waitUntil:'networkidle'});
await page.waitForTimeout(1800);
const phone = page.locator('.app-surface');
const shots = [
  ['التحميلات','downloads'],['المتصفح','browser'],['المكتبة','files'],['الأدوات','tools'],['الإعدادات','settings'],['الرئيسية','home']
];
for (const [label,name] of shots) {
  await page.getByRole('button',{name:label, exact:true}).last().click();
  await page.waitForTimeout(900);
  await page.screenshot({path:`/tmp/s-${name}.png`, clip: await phone.boundingBox()});
}
// open video sheet
await page.getByRole('button',{name:'فيديو', exact:true}).first().click();
await page.waitForTimeout(800);
await page.screenshot({path:'/tmp/s-sheet.png', clip: await phone.boundingBox()});
await page.getByRole('button',{name:'إغلاق'}).first().click();
// onboarding
await page.getByRole('button',{name:/شاشة الترحيب/}).first().click();
await page.waitForTimeout(800);
await page.screenshot({path:'/tmp/s-onboarding.png', clip: await phone.boundingBox()});
await browser.close();
