import { chromium } from 'playwright';
const browser = await chromium.launch({args:['--no-sandbox']});
const page = await browser.newPage({viewport:{width:1440,height:1050}});
await page.goto('http://127.0.0.1:4173', {waitUntil:'networkidle'});
await page.waitForTimeout(1200);
await page.locator('.app-surface button').filter({hasText:'فيديو'}).first().click();
await page.waitForTimeout(1200);
await page.evaluate(() => {
  const panel = document.querySelector('#phone-overlay')?.firstElementChild?.lastElementChild;
  if (panel) { panel.style.outline = '2px solid lime'; }
});
await page.waitForTimeout(200);
const box = await page.locator('.app-surface').boundingBox();
await page.screenshot({path:'/tmp/z-sheet.png', clip: box});
await browser.close();
