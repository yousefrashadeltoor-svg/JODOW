import { chromium } from 'playwright';
const browser = await chromium.launch({args:['--no-sandbox']});
const page = await browser.newPage({viewport:{width:1440,height:1050}});
await page.goto('http://127.0.0.1:4173', {waitUntil:'networkidle'});
await page.waitForTimeout(1200);
await page.locator('.app-surface button').filter({hasText:'فيديو'}).first().click();
await page.waitForTimeout(900);
const info = await page.evaluate(() => {
  const host = document.querySelector('#phone-overlay');
  const wrap = host?.firstElementChild;
  const panel = wrap?.lastElementChild;
  const rect = (el) => { if(!el) return null; const r = el.getBoundingClientRect(); const cs = getComputedStyle(el); return {x:Math.round(r.x), y:Math.round(r.y), w:Math.round(r.width), h:Math.round(r.height), pos:cs.position, transform:cs.transform, overflowX:cs.overflowX, dir:cs.direction}; };
  return {
    hostCount: document.querySelectorAll('#phone-overlay').length,
    host: rect(host), wrap: rect(wrap), panel: rect(panel),
    hostScrollW: host?.scrollWidth, wrapScrollW: wrap?.scrollWidth, wrapClientW: wrap?.clientWidth,
    panelStyle: panel ? { padding: getComputedStyle(panel).padding, maxHeight: getComputedStyle(panel).maxHeight } : null,
    scrollable: panel ? {sw:panel.scrollWidth, cw:panel.clientWidth} : null,
  };
});
console.log(JSON.stringify(info,null,2));
await browser.close();
