import { useEffect, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { useDon } from "../don/store";
import { cn } from "../utils/cn";

export function spring(scale = 1) {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  return { type: "spring" as const, stiffness: 320 * scale, damping: 28 };
}

export function useSpring() {
  const { theme } = useDon();
  return { type: "spring" as const, stiffness: theme.stiffness, damping: theme.damping };
}

export function Card({
  children,
  className,
  onClick,
  glow = false,
  deep = false,
  style,
}: {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  glow?: boolean;
  deep?: boolean;
  style?: React.CSSProperties;
}) {
  const Tag = onClick ? motion.button : motion.div;
  return (
    <Tag
      onClick={onClick}
      style={style}
      whileTap={onClick ? { scale: 0.985 } : undefined}
      className={cn(
        "specular relative overflow-hidden rounded-[var(--radius)] text-right",
        deep ? "glass-deep" : "glass",
        glow && "shadow-[0_24px_60px_-34px_rgba(var(--glow2),0.75)]",
        className,
      )}
    >
      {children}
    </Tag>
  );
}

export function IconButton({
  children,
  label,
  onClick,
  active,
  size = "md",
  className,
  tone,
}: {
  children: ReactNode;
  label: string;
  onClick?: () => void;
  active?: boolean;
  size?: "sm" | "md" | "lg";
  className?: string;
  tone?: string;
}) {
  const dims = size === "sm" ? "h-8 w-8" : size === "lg" ? "h-12 w-12" : "h-10 w-10";
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      style={tone ? { color: tone } : undefined}
      className={cn(
        "press relative grid shrink-0 place-items-center rounded-full border backdrop-blur-xl",
        dims,
        active ? "border-white/25 bg-white/15 text-[var(--tx)]" : "border-[var(--line)] bg-[var(--surface-alt)] text-[var(--tx-dim)] hover:text-[var(--tx)]",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Pill({
  children,
  active,
  onClick,
  className,
  count,
}: {
  children: ReactNode;
  active?: boolean;
  onClick?: () => void;
  className?: string;
  count?: number;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "press flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-[7px] text-[10px] font-medium whitespace-nowrap",
        active ? "border-transparent text-white" : "border-[var(--line)] bg-[var(--surface-alt)] text-[var(--tx-mute)]",
        className,
      )}
      style={active ? { background: "linear-gradient(115deg, var(--c1), var(--c2))", boxShadow: "0 8px 22px -12px rgba(var(--glow),0.9)" } : undefined}
    >
      {children}
      {typeof count === "number" && <span className={cn("text-[9px] tabular-nums", active ? "text-white/75" : "text-[var(--tx-mute)]")}>{count}</span>}
    </button>
  );
}

export function Badge({ children, className, tone }: { children: ReactNode; className?: string; tone?: string }) {
  return (
    <span
      style={tone ? { color: tone, borderColor: `${tone}44`, background: `${tone}14` } : undefined}
      className={cn(
        "inline-flex items-center gap-1 rounded-full border border-[var(--line)] bg-[var(--surface-alt)] px-2 py-[3px] text-[9px] leading-none text-[var(--tx-dim)]",
        className,
      )}
    >
      {children}
    </span>
  );
}

export function Bar({ value, className, height = 4 }: { value: number; className?: string; height?: number }) {
  return (
    <div className={cn("w-full overflow-hidden rounded-full bg-white/10", className)} style={{ height }}>
      <div className="h-full rounded-full bar-fill transition-[width] duration-500" style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  );
}

export function Ring({ value, size = 62, stroke = 5, children }: { value: number; size?: number; stroke?: number; children?: ReactNode }) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  return (
    <div className="relative grid shrink-0 place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id="don-ring" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="var(--c1)" />
            <stop offset="55%" stopColor="var(--c2)" />
            <stop offset="100%" stopColor="var(--c3)" />
          </linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="rgba(255,255,255,0.09)" strokeWidth={stroke} />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="url(#don-ring)"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          animate={{ strokeDashoffset: circumference - (circumference * Math.max(0, Math.min(100, value))) / 100 }}
          transition={{ type: "spring", stiffness: 90, damping: 22 }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">{children}</div>
    </div>
  );
}

export function Sparkline({ data, width = 62, height = 20 }: { data: number[]; width?: number; height?: number }) {
  const points = data.length ? data : [0, 0];
  const max = Math.max(...points, 1);
  const path = points
    .map((value, index) => {
      const x = (index / Math.max(1, points.length - 1)) * width;
      const y = height - (value / max) * (height - 2) - 1;
      return `${index === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} fill="none" aria-hidden="true">
      <path d={path} stroke="var(--c2)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" opacity="0.9" />
    </svg>
  );
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (value: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={() => onChange(!on)}
      className={cn("relative h-[24px] w-[44px] shrink-0 rounded-full border transition-colors", on ? "border-transparent" : "border-[var(--line)] bg-white/10")}
      style={on ? { background: "linear-gradient(110deg, var(--c1), var(--c2))" } : undefined}
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 520, damping: 34 }}
        className={cn("absolute top-[2px] h-[18px] w-[18px] rounded-full bg-white shadow", on ? "right-[2px]" : "right-[22px]")}
      />
    </button>
  );
}

export function Row({
  icon,
  title,
  hint,
  right,
  onClick,
  chevron,
}: {
  icon?: ReactNode;
  title: string;
  hint?: string;
  right?: ReactNode;
  onClick?: () => void;
  chevron?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!onClick}
      className={cn("flex w-full items-center gap-2.5 px-3 py-2.5 text-right", onClick && "press hover:bg-white/5")}
    >
      {icon && <span className="grid h-8 w-8 shrink-0 place-items-center rounded-[11px] border border-[var(--line)] bg-[var(--surface-alt)] text-[var(--tx-dim)]">{icon}</span>}
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[10.5px] font-medium text-[var(--tx)]">{title}</span>
        {hint && <span className="mt-0.5 block text-[8.5px] leading-4 text-[var(--tx-mute)]">{hint}</span>}
      </span>
      {right}
      {chevron && <span className="text-[var(--tx-mute)]">›</span>}
    </button>
  );
}

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-2 mt-4 flex items-center justify-between gap-2 px-0.5">
      <h2 className="text-[12px] font-semibold tracking-tight text-[var(--tx)]">{children}</h2>
      {action}
    </div>
  );
}

export function Empty({ title, hint, icon }: { title: string; hint?: string; icon?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 px-6 py-12 text-center">
      <div className="relative grid h-16 w-16 place-items-center rounded-[22px] border border-[var(--line)] bg-[var(--surface-alt)]">
        <div className="absolute inset-0 rounded-[22px] bg-[radial-gradient(circle_at_50%_15%,rgba(var(--glow),0.25),transparent_70%)]" />
        <span className="relative text-[var(--tx-dim)]">{icon ?? "◎"}</span>
      </div>
      <p className="text-[12px] font-medium text-[var(--tx)]">{title}</p>
      {hint && <p className="max-w-[240px] text-[9.5px] leading-5 text-[var(--tx-mute)]">{hint}</p>}
    </div>
  );
}

export function Sheet({
  open,
  onClose,
  title,
  subtitle,
  children,
  maxHeight = "82%",
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children: ReactNode;
  maxHeight?: string;
}) {
  const [host, setHost] = useState<HTMLElement | null>(null);
  const { theme } = useDon();
  useEffect(() => {
    setHost(document.getElementById("don-overlay"));
  }, []);

  const content = (
    <AnimatePresence>
      {open && (
        <motion.div className="absolute inset-0 z-[70] flex items-end" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <button type="button" aria-label="close" onClick={onClose} className="absolute inset-0 bg-black/65 backdrop-blur-[6px]" />
          <motion.div
            initial={{ y: "102%" }}
            animate={{ y: 0 }}
            exit={{ y: "102%" }}
            transition={{ type: "spring", stiffness: theme.stiffness, damping: theme.damping + 4 }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.45 }}
            onDragEnd={(_, info) => {
              if (info.offset.y > 100) onClose();
            }}
            style={{ maxHeight }}
            className="relative z-10 flex w-full flex-col overflow-hidden rounded-t-[30px] border-x border-t border-[var(--line)] bg-[linear-gradient(175deg,color-mix(in_srgb,var(--bg-soft)_92%,transparent),color-mix(in_srgb,var(--bg)_97%,transparent))] shadow-[0_-30px_80px_rgba(0,0,0,0.6)] backdrop-blur-3xl"
          >
            <div className="mx-auto mt-2.5 h-[4px] w-9 shrink-0 rounded-full bg-white/25" />
            {(title || subtitle) && (
              <div className="flex items-start justify-between gap-3 px-4 pb-2 pt-3">
                <div className="min-w-0">
                  {title && <h3 className="truncate text-[15px] font-semibold text-[var(--tx)]">{title}</h3>}
                  {subtitle && <p className="mt-1 text-[9.5px] leading-4 text-[var(--tx-mute)]">{subtitle}</p>}
                </div>
                <IconButton label="close" size="sm" onClick={onClose}>
                  <X size={14} />
                </IconButton>
              </div>
            )}
            <div className="thin-bar flex-1 overflow-y-auto overflow-x-hidden px-3 pb-5">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
  return host ? createPortal(content, host) : null;
}

export function Header({ title, subtitle, right, back }: { title: string; subtitle?: string; right?: ReactNode; back?: () => void }) {
  return (
    <header className="flex items-center justify-between gap-2 px-4 pb-2 pt-1">
      <div className="flex min-w-0 items-center gap-2">
        {back && (
          <IconButton label="back" size="sm" onClick={back}>
            <span className="text-[13px]">›</span>
          </IconButton>
        )}
        <div className="min-w-0">
          <h1 className="truncate text-[17px] font-semibold tracking-tight text-[var(--tx)]">{title}</h1>
          {subtitle && <p className="mt-0.5 truncate text-[9px] text-[var(--tx-mute)]">{subtitle}</p>}
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-1.5">{right}</div>
    </header>
  );
}

export function Avatar({ name, color, size = 34, image }: { name: string; color: string; size?: number; image?: string }) {
  return (
    <span
      className="relative grid shrink-0 place-items-center overflow-hidden rounded-full font-display font-semibold text-white"
      style={{
        width: size,
        height: size,
        fontSize: size * 0.4,
        background: image ? undefined : `linear-gradient(140deg, ${color}, color-mix(in srgb, ${color} 45%, #000))`,
        boxShadow: `inset 0 1px 0 rgba(255,255,255,.35), 0 6px 18px -8px ${color}`,
      }}
    >
      {image && <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover" />}
      <span className="relative">{name.trim().charAt(0).toUpperCase() || "D"}</span>
    </span>
  );
}

export function BrandMark({ size = 34 }: { size?: number }) {
  return (
    <span
      className="relative grid shrink-0 place-items-center overflow-hidden rounded-[30%]"
      style={{ width: size, height: size, background: "linear-gradient(140deg, var(--c1), var(--c2) 55%, var(--c3))", boxShadow: "inset 0 1px 1px rgba(255,255,255,.4)" }}
    >
      <svg width={size * 0.6} height={size * 0.6} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M7 4h6.2c3.4 0 5.8 2.3 5.8 5.7v4.6c0 3.4-2.4 5.7-5.8 5.7H7V4Zm3 2.6v8.8h3c1.8 0 3-1.2 3-3V9.6c0-1.8-1.2-3-3-3h-3Z" fill="white" fillOpacity="0.96" />
      </svg>
    </span>
  );
}
