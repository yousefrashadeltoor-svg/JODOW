import { useEffect, useState, type CSSProperties } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Check,
  Download,
  FolderDown,
  Globe2,
  Home,
  Play,
  Settings,
  TriangleAlert,
  Wrench,
} from "lucide-react";
import { useDon, type Screen } from "../don/store";
import { themeCssVars } from "../don/core";
import { HomeScreen } from "../screens/Home";
import { TubeScreen } from "../screens/Tube";
import { DownloadsScreen } from "../screens/Downloads";
import { BrowserScreen } from "../screens/Browser";
import { FilesScreen } from "../screens/Files";
import { ToolsScreen } from "../screens/Tools";
import { SettingsScreen } from "../screens/Settings";
import { PlayerLayer } from "./Player";
import { cn } from "../utils/cn";

const SCREENS: Record<Screen, () => React.ReactElement> = {
  home: HomeScreen,
  tube: TubeScreen,
  downloads: DownloadsScreen,
  browser: BrowserScreen,
  files: FilesScreen,
  tools: ToolsScreen,
  settings: SettingsScreen,
};

const DOCK: { id: Screen; icon: typeof Home; ar: string; en: string }[] = [
  { id: "home", icon: Home, ar: "الرئيسية", en: "Home" },
  { id: "tube", icon: Play, ar: "Tube", en: "Tube" },
  { id: "downloads", icon: Download, ar: "التحميلات", en: "Downloads" },
  { id: "browser", icon: Globe2, ar: "المتصفح", en: "Browser" },
  { id: "files", icon: FolderDown, ar: "المكتبة", en: "Library" },
  { id: "tools", icon: Wrench, ar: "الأدوات", en: "Tools" },
  { id: "settings", icon: Settings, ar: "الإعدادات", en: "Settings" },
];

export function StatusBar() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 15_000);
    return () => window.clearInterval(id);
  }, []);
  const time = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`;
  return (
    <div className="relative z-40 flex h-[34px] items-center justify-between px-6 text-[11px] font-semibold text-[var(--tx)]">
      <span className="font-display tabular-nums tracking-wide">{time}</span>
      <span className="absolute left-1/2 top-[6px] h-[22px] w-[92px] -translate-x-1/2 rounded-full bg-black" />
      <span className="flex items-center gap-1.5">
        <svg width="15" height="10" viewBox="0 0 16 11" fill="none" aria-hidden="true">
          {[3, 5, 7, 9].map((height, index) => (
            <rect key={height} x={index * 4} y={10 - height} width="2.4" height={height} rx="0.8" fill="currentColor" opacity={index === 3 ? 1 : 0.8} />
          ))}
        </svg>
        <span className="flex h-[10px] w-[20px] items-center rounded-[3px] border border-current p-[1.5px] opacity-85">
          <span className="h-full w-[74%] rounded-[1.5px] bg-current" />
        </span>
      </span>
    </div>
  );
}

export function Dock() {
  const { screen, setScreen, lang, tasks } = useDon();
  const active = tasks.filter((task) => task.status === "active" || task.status === "queued").length;
  return (
    <nav className="pointer-events-auto absolute inset-x-2.5 bottom-2.5 z-40">
      <div className="specular flex items-center justify-between rounded-[22px] border border-[var(--line)] bg-[var(--surface)] px-1 py-1 shadow-[0_20px_45px_-18px_rgba(0,0,0,0.9)] backdrop-blur-2xl">
        {DOCK.map((item) => {
          const isActive = screen === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setScreen(item.id)}
              aria-label={lang === "ar" ? item.ar : item.en}
              className={cn("press relative flex flex-1 flex-col items-center gap-[2px] rounded-[16px] py-[6px] text-[7px]", isActive ? "text-[var(--tx)]" : "text-[var(--tx-mute)]")}
            >
              {isActive && <motion.span layoutId="don-dock" transition={{ type: "spring", stiffness: 420, damping: 32 }} className="absolute inset-0 rounded-[16px] border border-[var(--line)] bg-white/10" />}
              <span className="relative">
                <item.icon size={15} strokeWidth={isActive ? 2.3 : 1.8} />
                {item.id === "downloads" && active > 0 && (
                  <span className="absolute -right-2 -top-1.5 grid h-[13px] min-w-[13px] place-items-center rounded-full px-[3px] text-[7px] font-bold text-white btn-primary">{active}</span>
                )}
              </span>
              <span className="relative leading-none">{lang === "ar" ? item.ar : item.en}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

export function Toast() {
  const { toast } = useDon();
  return (
    <AnimatePresence>
      {toast && (
        <motion.div
          key={toast.id}
          initial={{ opacity: 0, y: 16, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 10, scale: 0.97 }}
          transition={{ type: "spring", stiffness: 400, damping: 30 }}
          className="pointer-events-none absolute inset-x-3 bottom-[68px] z-[65]"
        >
          <div className="glass-deep flex items-center gap-2 rounded-[14px] px-2.5 py-2">
            <span
              className="grid h-6 w-6 shrink-0 place-items-center rounded-full"
              style={{
                background: toast.tone === "error" ? "rgba(255,157,157,0.16)" : toast.tone === "warn" ? "rgba(245,206,138,0.16)" : "rgba(103,232,199,0.16)",
                color: toast.tone === "error" ? "#ff9d9d" : toast.tone === "warn" ? "#f5ce8a" : "#67e8c7",
              }}
            >
              {toast.tone === "ok" ? <Check size={12} strokeWidth={2.6} /> : <TriangleAlert size={12} />}
            </span>
            <p className="flex-1 text-[8.5px] leading-4 text-[var(--tx)]">{toast.text}</p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function Phone() {
  const { screen, dir, theme, settings, player } = useDon();
  const Active = SCREENS[screen];
  const vars = themeCssVars(theme) as CSSProperties;

  return (
    <div className="relative w-full max-w-[392px] select-none">
      <div className="pointer-events-none absolute -inset-14 -z-10 rounded-full blur-[70px]" style={{ background: `radial-gradient(circle at 50% 30%, rgba(var(--glow2),0.22), transparent 70%)` }} />
      <div className="relative rounded-[46px] border border-white/12 bg-[linear-gradient(150deg,#414655_0%,#15171f_16%,#08090e_52%,#1d2029_86%,#4a4f5e_100%)] p-[3px] shadow-[0_50px_120px_-30px_rgba(0,0,0,0.95),inset_0_1px_0_rgba(255,255,255,0.18)]">
        <span className="absolute -left-[5px] top-[128px] h-10 w-[3px] rounded-l bg-[#2c303d]" />
        <span className="absolute -left-[5px] top-[176px] h-14 w-[3px] rounded-l bg-[#2c303d]" />
        <span className="absolute -right-[5px] top-[158px] h-16 w-[3px] rounded-r bg-[#2c303d]" />
        <div className="relative overflow-hidden rounded-[44px] border border-black/80" style={{ ...vars, background: "var(--bg)" }} data-motion={settings.reduceMotion ? "reduced" : "full"}>
          <StatusBar />
          <div dir={dir} className="relative">
            <div className="relative h-[720px] overflow-hidden">
              {settings.wallpaper && (
                <div className="pointer-events-none absolute inset-0 opacity-[0.16]">
                  <img src={theme.image} alt="" className="h-full w-full object-cover" />
                  <div className="absolute inset-0" style={{ background: `linear-gradient(180deg, color-mix(in srgb, var(--bg) 55%, transparent), var(--bg))` }} />
                </div>
              )}
              <div className="pointer-events-none absolute -left-16 top-24 h-44 w-44 rounded-full blur-[60px]" style={{ background: `rgba(var(--glow2),0.16)` }} />
              <div className="pointer-events-none absolute -right-20 top-[420px] h-48 w-48 rounded-full blur-[65px]" style={{ background: `rgba(var(--glow),0.13)` }} />

              <div className="no-bar relative h-full overflow-y-auto pb-[70px]">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={screen}
                    initial={{ opacity: 0, scale: 0.988, filter: "blur(5px)" }}
                    animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                    exit={{ opacity: 0, scale: 1.006, filter: "blur(4px)" }}
                    transition={{ duration: settings.reduceMotion ? 0.08 : 0.26, ease: [0.22, 0.8, 0.25, 1] }}
                  >
                    <Active />
                  </motion.div>
                </AnimatePresence>
              </div>

              <div id="don-overlay" className="pointer-events-none absolute inset-0 z-[60] [&>*]:pointer-events-auto" />
              <Dock />
              <Toast />
              <AnimatePresence>{player && <PlayerLayer />}</AnimatePresence>
            </div>
          </div>
          <span className="absolute bottom-[5px] left-1/2 z-[80] h-[4px] w-[104px] -translate-x-1/2 rounded-full bg-white/55" />
        </div>
      </div>
    </div>
  );
}
