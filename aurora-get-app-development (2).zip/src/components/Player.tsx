import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  AudioLines,
  BellRing,
  Check,
  Copy,
  Download,
  Film,
  Gauge,
  Loader2,
  Maximize,
  Music2,
  Pause,
  PictureInPicture2,
  Play,
  Repeat,
  Repeat1,
  Scissors,
  Share2,
  SkipForward,
  Sparkles,
  Timer,
  Trash2,
  Volume2,
  VolumeX,
  Wand2,
  X,
} from "lucide-react";
import { useDon, type RepeatMode } from "../don/store";
import { formatBytes, formatClock, formatDuration } from "../don/core";
import { captureFilmstrip, recordSegment, saveBlob } from "../don/media";
import { Badge, Bar, IconButton, Sheet } from "./ui";
import { cn } from "../utils/cn";

type Panel = null | "speed" | "effects" | "trim" | "sleep" | "tools";

const SPEEDS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3];

const EFFECTS: { id: string; ar: string; en: string; css: string; transform?: string }[] = [
  { id: "off", ar: "بدون", en: "Off", css: "none" },
  { id: "cinema", ar: "سينمائي", en: "Cinema", css: "contrast(1.12) saturate(1.08) brightness(0.94)" },
  { id: "vivid", ar: "حيوي", en: "Vivid", css: "saturate(1.55) contrast(1.08)" },
  { id: "night", ar: "ليلي", en: "Night", css: "brightness(1.22) contrast(0.92) saturate(0.8)" },
  { id: "cool", ar: "بارد", en: "Cool", css: "hue-rotate(-12deg) saturate(1.1) brightness(1.03)" },
  { id: "warm", ar: "دافئ", en: "Warm", css: "sepia(0.22) saturate(1.25) brightness(1.04)" },
  { id: "mono", ar: "أحادي", en: "Mono", css: "grayscale(1) contrast(1.1)" },
  { id: "zoom", ar: "تقريب", en: "Zoom", css: "saturate(1.05)", transform: "scale(1.35)" },
];

export function PlayerLayer() {
  const {
    player,
    stopPlayer,
    t,
    lang,
    settings,
    updateSettings,
    recordWatch,
    enqueue,
    notify,
    copy,
    addLocalFiles,
    library,
    play,
    libraryUrls,
    theme,
  } = useDon();

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const audioGraph = useRef<{ ctx: AudioContext; analyser: AnalyserNode } | null>(null);
  const rafRef = useRef<number | null>(null);
  const stopAtRef = useRef<number | null>(null);

  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [speed, setSpeed] = useState(settings.defaultSpeed);
  const [repeat, setRepeat] = useState<RepeatMode>(settings.repeatMode);
  const [sleepLeft, setSleepLeft] = useState<number | null>(null);
  const [effect, setEffect] = useState("off");
  const [audioMode, setAudioMode] = useState(false);
  const [panel, setPanel] = useState<Panel>(null);
  const [levels, setLevels] = useState<number[]>(() => Array.from({ length: 30 }, () => 0));
  const [frames, setFrames] = useState<string[]>([]);
  const [framesTainted, setFramesTainted] = useState(false);
  const [range, setRange] = useState({ from: 0, to: 0 });
  const [busy, setBusy] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<{ label: string; size: number } | null>(null);
  const [analyserState, setAnalyserState] = useState<"off" | "live" | "blocked">("off");

  const isLocal = !!player && (player.src.startsWith("blob:") || player.src.startsWith("data:"));
  const activeEffect = EFFECTS.find((item) => item.id === effect) ?? EFFECTS[0];

  /* ------- element wiring ------- */
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !player) return;
    setTime(0);
    setDuration(0);
    setFrames([]);
    setFramesTainted(false);
    setResult(null);
    setRange({ from: 0, to: 0 });
    setAudioMode(player.kind === "audio");
    setSpeed(settings.defaultSpeed);
    video.playbackRate = settings.defaultSpeed;
    video.volume = volume;
    video.muted = muted;
    stopAtRef.current = null;
    if (settings.autoplay) {
      video.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [player?.src]);

  useEffect(() => {
    if (!player) return;
    if ("mediaSession" in navigator) {
      try {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: player.title,
          artist: "DON",
          album: player.kind === "audio" ? "Local audio" : "Local video",
          artwork: player.poster ? [{ src: player.poster, sizes: "480x360", type: "image/jpeg" }] : [],
        });
      } catch {
        /* metadata unsupported */
      }
    }
  }, [player]);

  useEffect(() => {
    if (!("mediaSession" in navigator)) return;
    const handlers: [MediaSessionAction, () => void][] = [
      ["play", () => void videoRef.current?.play()],
      ["pause", () => videoRef.current?.pause()],
      ["seekbackward", () => seekBy(-10)],
      ["seekforward", () => void seekBy(10)],
    ];
    handlers.forEach(([action, handler]) => {
      try {
        navigator.mediaSession.setActionHandler(action, handler);
      } catch {
        /* action unsupported */
      }
    });
    return () => {
      handlers.forEach(([action]) => {
        try {
          navigator.mediaSession.setActionHandler(action, null);
        } catch {
          /* ignore */
        }
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [duration]);

  const seekBy = useCallback((delta: number) => {
    const video = videoRef.current;
    if (!video) return;
    video.currentTime = Math.max(0, Math.min(video.duration || 0, video.currentTime + delta));
  }, []);

  /* ------- sleep timer (real countdown) ------- */
  useEffect(() => {
    if (sleepLeft === null) return;
    if (sleepLeft <= 0) {
      videoRef.current?.pause();
      setPlaying(false);
      setSleepLeft(null);
      notify(lang === "ar" ? "انتهى مؤقّت النوم — تم الإيقاف" : "Sleep timer finished — playback paused", "ok");
      return;
    }
    const id = window.setTimeout(() => setSleepLeft((value) => (value === null ? null : value - 1)), 1000);
    return () => window.clearTimeout(id);
  }, [sleepLeft, notify, lang]);

  /* ------- selection preview enforcement ------- */
  const onTimeUpdate = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    setTime(video.currentTime);
    setDuration(Number.isFinite(video.duration) ? video.duration : 0);
    if (video.buffered.length) setBuffered(video.buffered.end(video.buffered.length - 1));
    if (stopAtRef.current !== null && video.currentTime >= stopAtRef.current) {
      video.pause();
      setPlaying(false);
      stopAtRef.current = null;
    }
    if (player?.videoId && duration > 0) {
      recordWatch(player.videoId, video.currentTime / duration);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [duration, player?.videoId]);

  /* ------- repeat modes ------- */
  const onEnded = useCallback(() => {
    setPlaying(false);
    const video = videoRef.current;
    if (repeat === "one" && video) {
      video.currentTime = 0;
      void video.play();
      setPlaying(true);
      return;
    }
    if (repeat === "all") {
      const sameKind = library.filter((item) => item.kind === player?.kind);
      const index = sameKind.findIndex((item) => item.id === player?.libraryId);
      const next = sameKind[(index + 1) % Math.max(1, sameKind.length)];
      const nextUrl = next ? libraryUrls[next.id] : undefined;
      if (next && nextUrl) {
        play({ src: nextUrl, title: next.title, poster: next.poster, kind: next.kind, libraryId: next.id });
      } else if (video) {
        video.currentTime = 0;
        void video.play();
        setPlaying(true);
      }
    }
  }, [repeat, library, libraryUrls, play, player?.kind, player?.libraryId]);

  /* ------- real analyser for local sources ------- */
  const enableAnalyser = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    if (!isLocal) {
      setAnalyserState("blocked");
      notify(lang === "ar" ? "محلّل الصوت يعمل على الملفات المحلية فقط" : "Audio analyser works on local files only", "warn");
      return;
    }
    try {
      if (!audioGraph.current) {
        const ctx = new AudioContext();
        const source = ctx.createMediaElementSource(video);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 128;
        source.connect(analyser);
        analyser.connect(ctx.destination);
        audioGraph.current = { ctx, analyser };
      }
      void audioGraph.current.ctx.resume();
      setAnalyserState("live");
      const loop = () => {
        const analyser = audioGraph.current?.analyser;
        if (!analyser) return;
        const data = new Uint8Array(analyser.frequencyBinCount);
        analyser.getByteFrequencyData(data);
        setLevels(Array.from({ length: 30 }, (_, index) => data[Math.floor((index / 30) * data.length)] / 255));
        rafRef.current = requestAnimationFrame(loop);
      };
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      loop();
    } catch {
      setAnalyserState("blocked");
    }
  }, [isLocal, lang, notify]);

  useEffect(
    () => () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      audioGraph.current?.ctx.close().catch(() => undefined);
    },
    [],
  );

  /* ------- real processing actions ------- */
  const ensureRange = useCallback(() => {
    if (range.to <= range.from) return { from: 0, to: duration || 0 };
    return range;
  }, [range, duration]);

  const captureStrip = useCallback(async () => {
    const video = videoRef.current;
    if (!video || !duration) return;
    setBusy("frames");
    const { frames: captured, tainted } = await captureFilmstrip(video, 0, duration, 10);
    setFrames(captured);
    setFramesTainted(tainted);
    setBusy(null);
    if (tainted) notify(lang === "ar" ? "تعذّر التقاط الإطارات (قيود CORS) — المعاينة بالبحث الحقيقي تعمل" : "Frame capture blocked by CORS — real seek preview still works", "warn");
  }, [duration, lang, notify]);

  const runExport = useCallback(
    async (mode: "trim" | "ringtone" | "audio" | "compress") => {
      const video = videoRef.current;
      if (!video) return;
      if (!isLocal) {
        notify(lang === "ar" ? "التصدير الفعلي يعمل على الملفات المحلية أو بعد التحميل" : "Real export works on local or downloaded files", "warn");
        return;
      }
      const selection = mode === "trim" || mode === "ringtone" ? ensureRange() : { from: 0, to: duration };
      if (selection.to - selection.from < 0.3) {
        notify(lang === "ar" ? "اختر مقطعًا أطول" : "Select a longer segment", "warn");
        return;
      }
      setBusy(mode);
      setProgress(0);
      setResult(null);
      try {
        const blob = await recordSegment(video, {
          from: selection.from,
          to: selection.to,
          audioOnly: mode === "ringtone" || mode === "audio",
          videoBitsPerSecond: mode === "compress" ? 500_000 : undefined,
          onProgress: (ratio) => setProgress(ratio),
        });
        const base = player?.title.replace(/\.[a-z0-9]+$/i, "") || "don";
        const ext = blob.type.includes("mp4") ? "mp4" : "webm";
        const suffix = mode === "ringtone" ? "ringtone" : mode === "audio" ? "audio" : mode === "compress" ? "small" : "cut";
        const filename = `${base}-${suffix}.${mode === "ringtone" || mode === "audio" ? (blob.type.includes("mp4") ? "m4a" : "weba") : ext}`;
        await addLocalFiles([new File([blob], filename, { type: blob.type })]);
        setResult({ label: filename, size: blob.size });
        setPanel(null);
        notify(`${filename} · ${formatBytes(blob.size)}`, "ok");
      } catch (error) {
        notify(
          error instanceof Error && error.message === "capture-stream-unsupported"
            ? lang === "ar"
              ? "المتصفح لا يدعم captureStream"
              : "captureStream unsupported here"
            : lang === "ar"
              ? "تعذّر التصدير من هذا المصدر"
              : "Export failed for this source",
          "error",
        );
      } finally {
        setBusy(null);
        setProgress(0);
      }
    },
    [addLocalFiles, duration, ensureRange, isLocal, lang, notify, player?.title],
  );

  const toggleFullscreen = useCallback(async () => {
    const container = videoRef.current?.parentElement?.parentElement;
    if (!container) return;
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await container.requestFullscreen();
    } catch {
      notify(lang === "ar" ? "ملء الشاشة غير متاح هنا" : "Fullscreen unavailable here", "warn");
    }
  }, [lang, notify]);

  const togglePip = useCallback(async () => {
    const video = videoRef.current;
    if (!video) return;
    try {
      if (document.pictureInPictureElement) await document.exitPictureInPicture();
      else await video.requestPictureInPicture();
    } catch {
      notify(lang === "ar" ? "النافذة العائمة غير مدعومة لهذا المصدر" : "PiP not supported for this source", "warn");
    }
  }, [lang, notify]);

  const percent = duration > 0 ? (time / duration) * 100 : 0;
  const bufferedPercent = duration > 0 ? (buffered / duration) * 100 : 0;
  const subtitle = useMemo(() => {
    if (!player) return "";
    return `${formatDuration(duration)} · ${player.kind === "audio" ? t("audio") : t("video")}${isLocal ? ` · ${lang === "ar" ? "محلي" : "local"}` : ""}`;
  }, [player, duration, isLocal, lang, t]);

  if (!player) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 26 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      transition={{ type: "spring", stiffness: theme.stiffness, damping: theme.damping }}
      className="absolute inset-0 z-[80] flex flex-col overflow-hidden"
      style={{ background: `linear-gradient(180deg, color-mix(in srgb, var(--bg) 88%, transparent), var(--bg))` }}
    >
      {player.poster && !audioMode && (
        <img src={player.poster} alt="" className="pointer-events-none absolute inset-0 h-full w-full scale-125 object-cover opacity-20 blur-3xl" />
      )}

      {/* top bar */}
      <div className="relative flex items-center gap-2 px-3 pt-2">
        <IconButton label="close" size="sm" onClick={stopPlayer}>
          <X size={14} />
        </IconButton>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[11px] font-semibold text-[var(--tx)]">{player.title}</p>
          <p className="truncate text-[8px] text-[var(--tx-mute)]">{subtitle}</p>
        </div>
        {sleepLeft !== null && (
          <Badge tone="#f5ce8a">
            <Timer size={9} /> {formatClock(sleepLeft)}
          </Badge>
        )}
        <IconButton label={t("pip")} size="sm" onClick={togglePip}>
          <PictureInPicture2 size={13} />
        </IconButton>
        <IconButton label={t("fullscreen")} size="sm" onClick={toggleFullscreen}>
          <Maximize size={13} />
        </IconButton>
      </div>

      {/* stage */}
      <div className="relative flex flex-1 items-center justify-center px-3 py-2">
        <div className={cn("relative w-full overflow-hidden rounded-[20px] border border-[var(--line)] bg-black", player.vertical ? "max-h-[430px]" : "aspect-video")}>
          <video
            ref={videoRef}
            src={player.src}
            poster={player.poster}
            playsInline
            preload="metadata"
            onClick={() => {
              const video = videoRef.current;
              if (!video) return;
              if (video.paused) {
                void video.play();
                setPlaying(true);
              } else {
                video.pause();
                setPlaying(false);
              }
            }}
            onPlay={() => setPlaying(true)}
            onPause={() => setPlaying(false)}
            onTimeUpdate={onTimeUpdate}
            onEnded={onEnded}
            onLoadedMetadata={(event) => {
              const video = event.currentTarget;
              setDuration(Number.isFinite(video.duration) ? video.duration : 0);
              setRange({ from: 0, to: Number.isFinite(video.duration) ? video.duration : 0 });
            }}
            className={cn("h-full w-full bg-black object-contain", audioMode && "opacity-0")}
            style={{ filter: activeEffect.css, transform: activeEffect.transform }}
          />
          {audioMode && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-5">
              {player.poster ? (
                <img src={player.poster} alt="" className="h-32 w-32 rounded-[22px] border border-[var(--line)] object-cover shadow-[0_20px_50px_-20px_rgba(var(--glow),0.7)]" />
              ) : (
                <span className="grid h-32 w-32 place-items-center rounded-[22px] border border-[var(--line)] bg-[var(--surface-alt)]">
                  <Music2 size={38} className="text-[var(--tx-dim)]" />
                </span>
              )}
              <div className="flex h-16 w-full items-end justify-center gap-[3px]">
                {levels.map((level, index) => (
                  <span
                    key={index}
                    className="w-[4px] rounded-full"
                    style={{
                      height: `${Math.max(6, level * 100)}%`,
                      background: "linear-gradient(to top, var(--c1), var(--c2), var(--c3))",
                      opacity: analyserState === "live" ? 0.35 + level * 0.65 : 0.22,
                      transition: "height 90ms linear",
                    }}
                  />
                ))}
              </div>
              <button
                type="button"
                onClick={() => (analyserState === "live" ? setAnalyserState("off") : enableAnalyser())}
                className="press flex items-center gap-1 rounded-full border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-1 text-[8px] text-[var(--tx-dim)]"
              >
                <AudioLines size={10} />
                {analyserState === "live" ? (lang === "ar" ? "المحلّل يعمل" : "Analyser live") : lang === "ar" ? "تشغيل محلّل الصوت" : "Enable audio analyser"}
              </button>
            </div>
          )}
          {!playing && !audioMode && (
            <button type="button" aria-label="play" onClick={() => void videoRef.current?.play()} className="absolute inset-0 grid place-items-center bg-black/25">
              <span className="grid h-14 w-14 place-items-center rounded-full border border-white/25 bg-black/45 backdrop-blur-xl">
                <Play size={20} className="ml-0.5 fill-white text-white" />
              </span>
            </button>
          )}
        </div>
      </div>

      {/* transport */}
      <div className="relative px-3">
        <div className="mb-1 flex items-center justify-between font-display text-[8px] tabular-nums text-[var(--tx-mute)]">
          <span dir="ltr">{formatClock(time)}</span>
          <span className="flex items-center gap-2">
            {bufferedPercent > 0 && <span dir="ltr" className="text-[var(--tx-mute)]">buffered {Math.round(bufferedPercent)}%</span>}
            <span dir="ltr">{formatClock(duration)}</span>
          </span>
        </div>
        <div className="relative">
          <div className="absolute inset-x-0 top-[7px] h-[4px] overflow-hidden rounded-full bg-white/10">
            <div className="h-full rounded-full bg-white/20" style={{ width: `${bufferedPercent}%` }} />
          </div>
          <Bar value={percent} className="absolute inset-x-0 top-[7px]" />
          <input
            type="range"
            className="don-range relative w-full"
            min={0}
            max={Math.max(0.1, duration)}
            step={0.05}
            value={time}
            aria-label="seek"
            onChange={(event) => {
              const video = videoRef.current;
              if (!video) return;
              video.currentTime = Number(event.target.value);
              setTime(video.currentTime);
            }}
          />
        </div>

        <div className="mt-1 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <IconButton label={playing ? t("pause") : "play"} onClick={() => (playing ? videoRef.current?.pause() : void videoRef.current?.play())}>
              {playing ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" className="ml-0.5" />}
            </IconButton>
            <IconButton label="-10s" size="sm" onClick={() => seekBy(-10)}>
              <span className="text-[8px]">10-</span>
            </IconButton>
            <IconButton label="+10s" size="sm" onClick={() => seekBy(10)}>
              <span className="text-[8px]">+10</span>
            </IconButton>
            <IconButton label={muted ? "unmute" : "mute"} size="sm" onClick={() => { const video = videoRef.current; if (!video) return; video.muted = !muted; setMuted(!muted); }}>
              {muted ? <VolumeX size={13} /> : <Volume2 size={13} />}
            </IconButton>
            <input
              type="range"
              className="don-range w-14"
              min={0}
              max={1}
              step={0.02}
              value={muted ? 0 : volume}
              aria-label="volume"
              onChange={(event) => {
                const next = Number(event.target.value);
                setVolume(next);
                setMuted(next === 0);
                const video = videoRef.current;
                if (video) {
                  video.volume = next;
                  video.muted = next === 0;
                }
              }}
            />
          </div>
          <div className="flex items-center gap-1.5">
            <IconButton
              label={t("repeat")}
              size="sm"
              active={repeat !== "off"}
              onClick={() => {
                const next: RepeatMode = repeat === "off" ? "all" : repeat === "all" ? "one" : "off";
                setRepeat(next);
                updateSettings({ repeatMode: next });
              }}
            >
              {repeat === "one" ? <Repeat1 size={13} /> : <Repeat size={13} />}
            </IconButton>
            <IconButton label={t("audioMode")} size="sm" active={audioMode} onClick={() => { setAudioMode(!audioMode); if (!audioMode && analyserState === "off") enableAnalyser(); }}>
              <Music2 size={13} />
            </IconButton>
            <IconButton label={t("effects")} size="sm" active={panel === "effects"} onClick={() => setPanel(panel === "effects" ? null : "effects")}>
              <Sparkles size={13} />
            </IconButton>
            <IconButton label={t("trim")} size="sm" active={panel === "trim"} onClick={() => { setPanel(panel === "trim" ? null : "trim"); if (!frames.length) void captureStrip(); }}>
              <Scissors size={13} />
            </IconButton>
          </div>
        </div>

        {/* quick tools */}
        <div className="mt-2 grid grid-cols-4 gap-1.5 pb-3">
          {[
            { icon: Download, label: t("download"), onClick: () => void enqueue(player.src, { title: player.title, poster: player.poster, kind: player.kind }), disabled: isLocal },
            { icon: Copy, label: t("copyLink"), onClick: () => void copy(player.src, player.title) },
            { icon: Gauge, label: `${speed}×`, onClick: () => setPanel(panel === "speed" ? null : "speed") },
            { icon: Timer, label: t("sleepTimer"), onClick: () => setPanel(panel === "sleep" ? null : "sleep") },
          ].map((tool) => (
            <button
              key={tool.label}
              type="button"
              disabled={tool.disabled}
              onClick={tool.onClick}
              className="press flex flex-col items-center gap-1 rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] py-2 text-[8px] text-[var(--tx-dim)] disabled:opacity-40"
            >
              <tool.icon size={13} />
              {tool.label}
            </button>
          ))}
        </div>

        {result && (
          <div className="mb-3 flex items-center gap-2 rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-2">
            <Check size={12} className="text-[#67e8c7]" />
            <span className="min-w-0 flex-1 truncate text-[8.5px] text-[var(--tx-dim)]">{result.label} · {formatBytes(result.size)}</span>
            <button type="button" onClick={() => setPanel("tools")} className="press text-[8px] text-[var(--c1)]">{t("tools")}</button>
          </div>
        )}
      </div>

      {/* panels */}
      <Sheet open={panel === "speed"} onClose={() => setPanel(null)} title={lang === "ar" ? "سرعة التشغيل" : "Playback speed"}>
        <div className="grid grid-cols-4 gap-1.5 pb-2">
          {SPEEDS.map((value) => (
            <button
              key={value}
              type="button"
              onClick={() => {
                setSpeed(value);
                updateSettings({ defaultSpeed: value });
                const video = videoRef.current;
                if (video) video.playbackRate = value;
                setPanel(null);
              }}
              className={cn("press rounded-[11px] border py-2 font-display text-[10px]", speed === value ? "border-transparent text-white" : "border-[var(--line)] bg-[var(--surface-alt)] text-[var(--tx-dim)]")}
              style={speed === value ? { background: "linear-gradient(115deg, var(--c1), var(--c2))" } : undefined}
            >
              {value}×
            </button>
          ))}
        </div>
      </Sheet>

      <Sheet open={panel === "effects"} onClose={() => setPanel(null)} title={t("effects")} subtitle={lang === "ar" ? "تُطبَّق مباشرة على طبقة العرض" : "Applied live on the render layer"}>
        <div className="grid grid-cols-2 gap-1.5 pb-2">
          {EFFECTS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setEffect(item.id)}
              className={cn("press flex items-center gap-2 rounded-[12px] border p-2 text-right", effect === item.id ? "border-[rgba(var(--glow),0.5)] bg-[rgba(var(--glow),0.12)]" : "border-[var(--line)] bg-[var(--surface-alt)]")}
            >
              <span className="h-8 w-12 shrink-0 overflow-hidden rounded-[7px] border border-[var(--line)] bg-black">
                {player.poster && <img src={player.poster} alt="" className="h-full w-full object-cover" style={{ filter: item.css, transform: item.transform }} />}
              </span>
              <span className="min-w-0">
                <span className="block truncate text-[9px] text-[var(--tx)]">{lang === "ar" ? item.ar : item.en}</span>
                <span className="block truncate font-display text-[6.5px] text-[var(--tx-mute)]">{item.css.slice(0, 26)}</span>
              </span>
            </button>
          ))}
        </div>
      </Sheet>

      <Sheet open={panel === "sleep"} onClose={() => setPanel(null)} title={t("sleepTimer")} subtitle={lang === "ar" ? "يوقف التشغيل فعليًا عند انتهاء الوقت" : "Really pauses playback when time is up"}>
        <div className="grid grid-cols-4 gap-1.5 pb-2">
          {[5, 10, 15, 30, 45, 60, 90].map((minutes) => (
            <button
              key={minutes}
              type="button"
              onClick={() => {
                setSleepLeft(minutes * 60);
                updateSettings({ sleepMinutes: minutes });
                setPanel(null);
                notify(`${minutes} ${lang === "ar" ? "دقيقة" : "min"}`, "ok");
              }}
              className="press rounded-[11px] border border-[var(--line)] bg-[var(--surface-alt)] py-2 font-display text-[10px] text-[var(--tx-dim)]"
            >
              {minutes}
            </button>
          ))}
          <button type="button" onClick={() => { setSleepLeft(null); setPanel(null); }} className="press rounded-[11px] border border-[var(--line)] bg-[var(--surface-alt)] py-2 text-[9px] text-[var(--tx-mute)]">
            <X size={12} className="mx-auto" />
          </button>
        </div>
      </Sheet>

      <Sheet open={panel === "trim"} onClose={() => setPanel(null)} title={t("trim")} subtitle={lang === "ar" ? "اسحب المقابض على الإطارات الحقيقية" : "Drag the handles over real frames"} maxHeight="86%">
        <div className="pb-2">
          <div className="relative mb-2 h-[64px] overflow-hidden rounded-[12px] border border-[var(--line)] bg-black/40">
            {frames.length ? (
              <div className="flex h-full w-full">
                {frames.map((frame) => (
                  <img key={frame} src={frame} alt="" className="h-full flex-1 object-cover opacity-80" />
                ))}
              </div>
            ) : (
              <div className="flex h-full items-center justify-center gap-2 text-[8.5px] text-[var(--tx-mute)]">
                {busy === "frames" ? <Loader2 size={12} className="animate-spin" /> : <Film size={12} />}
                {busy === "frames" ? (lang === "ar" ? "جارٍ التقاط الإطارات…" : "Capturing frames…") : framesTainted ? (lang === "ar" ? "الإطارات محجوبة (CORS) — استخدم المعاينة" : "Frames blocked (CORS) — use preview") : lang === "ar" ? "اضغط لالتقاط الإطارات" : "Tap to capture frames"}
              </div>
            )}
            {/* selection */}
            <div
              className="absolute inset-y-0 border-x-2 border-[var(--c1)] bg-[rgba(var(--glow),0.18)]"
              style={{
                right: duration ? `${(range.from / duration) * 100}%` : 0,
                width: duration ? `${Math.max(2, ((range.to - range.from) / duration) * 100)}%` : "100%",
              }}
            />
            <div
              className="absolute bottom-0 top-0 h-full w-[3px] bg-white/70"
              style={{ right: duration ? `calc(${(range.from / duration) * 100}% - 1px)` : 0 }}
            />
            <div className="absolute bottom-0 top-0 h-full w-[3px] bg-white/70" style={{ right: duration ? `calc(${(range.to / duration) * 100}% - 1px)` : 0 }} />
            <span className="absolute bottom-1 right-2 rounded bg-black/60 px-1 py-0.5 font-display text-[7px] text-white/80" dir="ltr">
              {formatClock(range.from)} → {formatClock(range.to)}
            </span>
          </div>

          <div className="space-y-2">
            <div>
              <div className="mb-1 flex justify-between text-[8px] text-[var(--tx-mute)]">
                <span>{lang === "ar" ? "البداية" : "Start"} <span dir="ltr">{formatClock(range.from)}</span></span>
              </div>
              <input
                type="range"
                className="don-range w-full"
                min={0}
                max={Math.max(0.1, duration)}
                step={0.05}
                value={range.from}
                aria-label="trim start"
                onChange={(event) => {
                  const value = Math.min(Number(event.target.value), range.to - 0.2);
                  setRange((prev) => ({ ...prev, from: Math.max(0, value) }));
                }}
              />
            </div>
            <div>
              <div className="mb-1 flex justify-between text-[8px] text-[var(--tx-mute)]">
                <span>{lang === "ar" ? "النهاية" : "End"} <span dir="ltr">{formatClock(range.to)}</span></span>
              </div>
              <input
                type="range"
                className="don-range w-full"
                min={0}
                max={Math.max(0.1, duration)}
                step={0.05}
                value={range.to}
                aria-label="trim end"
                onChange={(event) => {
                  const value = Math.max(Number(event.target.value), range.from + 0.2);
                  setRange((prev) => ({ ...prev, to: value }));
                }}
              />
            </div>
          </div>

          <div className="mt-2 grid grid-cols-3 gap-1.5">
            <button type="button" onClick={captureStrip} className="press flex items-center justify-center gap-1 rounded-[10px] border border-[var(--line)] bg-[var(--surface-alt)] py-2 text-[8px] text-[var(--tx-dim)]">
              <Film size={11} /> {lang === "ar" ? "التقاط الإطارات" : "Capture"}
            </button>
            <button
              type="button"
              onClick={() => {
                const video = videoRef.current;
                if (!video) return;
                video.currentTime = range.from;
                stopAtRef.current = range.to;
                void video.play();
                setPlaying(true);
              }}
              className="press flex items-center justify-center gap-1 rounded-[10px] border border-[var(--line)] bg-[var(--surface-alt)] py-2 text-[8px] text-[var(--tx-dim)]"
            >
              <Play size={11} /> {lang === "ar" ? "معاينة" : "Preview"}
            </button>
            <button
              type="button"
              onClick={() => setRange({ from: 0, to: duration })}
              className="press flex items-center justify-center gap-1 rounded-[10px] border border-[var(--line)] bg-[var(--surface-alt)] py-2 text-[8px] text-[var(--tx-dim)]"
            >
              <Trash2 size={11} /> {lang === "ar" ? "تصفير" : "Reset"}
            </button>
          </div>

          {busy && (
            <div className="mt-2">
              <div className="mb-1 flex items-center justify-between text-[8px] text-[var(--tx-dim)]">
                <span className="flex items-center gap-1"><Loader2 size={10} className="animate-spin" /> {busy}</span>
                <span className="font-display tabular-nums">{Math.round(progress * 100)}%</span>
              </div>
              <Bar value={progress * 100} />
            </div>
          )}

          <div className="mt-2 grid grid-cols-2 gap-1.5">
            <button type="button" disabled={!!busy} onClick={() => void runExport("trim")} className="press btn-primary flex items-center justify-center gap-1 rounded-[11px] py-2.5 text-[9px] font-medium disabled:opacity-50">
              <Scissors size={12} /> {lang === "ar" ? "تصدير المقطع" : "Export clip"}
            </button>
            <button type="button" disabled={!!busy} onClick={() => void runExport("compress")} className="press flex items-center justify-center gap-1 rounded-[11px] border border-[var(--line)] bg-[var(--surface-alt)] py-2.5 text-[9px] text-[var(--tx-dim)] disabled:opacity-50">
              <Wand2 size={12} /> {t("compress")} 500kbps
            </button>
          </div>
        </div>
      </Sheet>

      <Sheet open={panel === "tools"} onClose={() => setPanel(null)} title={lang === "ar" ? "أدوات الوسائط" : "Media tools"} subtitle={lang === "ar" ? "كل إجراء يُنتج ملفًا حقيقيًا على جهازك" : "Every action produces a real file on your device"}>
        <div className="space-y-1.5 pb-2">
          {[
            { icon: BellRing, label: t("ringtone"), hint: lang === "ar" ? "تصدير صوتي للمقطع المحدد" : "Audio-only export of selection", action: () => void runExport("ringtone") },
            { icon: Music2, label: t("extractAudio"), hint: lang === "ar" ? "استخراج المسار الصوتي كاملًا" : "Extract the full audio track", action: () => void runExport("audio") },
            { icon: Film, label: t("compress"), hint: lang === "ar" ? "إعادة ترميز بمعدل 500kbps" : "Re-encode at 500 kbps", action: () => void runExport("compress") },
            { icon: Scissors, label: t("trim"), hint: lang === "ar" ? "قص مرئي بمقابض على الإطارات" : "Visual trim with frame handles", action: () => { setPanel("trim"); void captureStrip(); } },
            {
              icon: Download,
              label: lang === "ar" ? "حفظ إلى الجهاز" : "Save to device",
              hint: isLocal ? (lang === "ar" ? "كتابة الملف فعليًا في التنزيلات" : "Writes the real file to downloads") : lang === "ar" ? "يتطلب ملفًا محليًا" : "Requires a local file",
              action: async () => {
                try {
                  const blob = await (await fetch(player.src)).blob();
                  saveBlob(blob, `${player.title}.media`);
                  notify(t("savedOk"), "ok");
                } catch {
                  notify(lang === "ar" ? "تعذّرت الكتابة" : "Write failed", "error");
                }
              },
            },
            { icon: Share2, label: t("share"), hint: lang === "ar" ? "مشاركة النظام إن توفرت" : "Native share when available", action: async () => {
              const shared = await navigator.share?.({ title: player.title, url: player.src }).then(() => true).catch(() => false);
              if (!shared) void copy(player.src, player.title);
            } },
            { icon: SkipForward, label: lang === "ar" ? "التالي في المكتبة" : "Next in library", hint: lang === "ar" ? "تشغيل العنصر التالي من نفس النوع" : "Play next item of same kind", action: () => {
              const sameKind = library.filter((item) => item.kind === player.kind);
              const index = sameKind.findIndex((item) => item.id === player.libraryId);
              const next = sameKind[(index + 1) % Math.max(1, sameKind.length)];
              const url = next ? libraryUrls[next.id] : undefined;
              if (next && url) play({ src: url, title: next.title, poster: next.poster, kind: next.kind, libraryId: next.id });
            } },
          ].map((tool) => (
            <button key={tool.label} type="button" onClick={tool.action} className="press flex w-full items-center gap-2.5 rounded-[13px] border border-[var(--line)] bg-[var(--surface-alt)] p-2.5 text-right">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-[10px] border border-[var(--line)] bg-black/20 text-[var(--c2)]">
                <tool.icon size={14} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[10px] font-medium text-[var(--tx)]">{tool.label}</span>
                <span className="block truncate text-[8px] text-[var(--tx-mute)]">{tool.hint}</span>
              </span>
              {busy && <Loader2 size={12} className="animate-spin text-[var(--tx-mute)]" />}
            </button>
          ))}
        </div>
      </Sheet>

      <button
        type="button"
        onClick={() => setPanel("tools")}
        className="press absolute bottom-3 left-3 z-10 flex items-center gap-1.5 rounded-full border border-[var(--line)] bg-[var(--surface)] px-3 py-2 text-[9px] text-[var(--tx-dim)] backdrop-blur-xl"
      >
        <Wand2 size={12} /> {lang === "ar" ? "أدوات" : "Tools"}
      </button>
      <AnimatePresence>
        {busy && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pointer-events-none absolute inset-x-0 top-14 z-20 flex justify-center">
            <span className="flex items-center gap-1.5 rounded-full border border-[var(--line)] bg-black/70 px-3 py-1.5 text-[8.5px] text-white/80 backdrop-blur-xl">
              <Loader2 size={11} className="animate-spin" /> {busy} · {Math.round(progress * 100)}%
            </span>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
