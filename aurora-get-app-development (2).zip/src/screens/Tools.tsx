import { useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowRight,
  AudioLines,
  Check,
  Film,
  FolderUp,
  Gauge,
  Image as ImageIcon,
  Loader2,
  Music2,
  Scissors,
  Sparkles,
  TriangleAlert,
  Wand2,
} from "lucide-react";
import { useDon } from "../don/store";
import { formatBytes } from "../don/core";
import { processImage, recordSegment, saveBlob } from "../don/media";
import { Badge, Bar, Card, Empty, Header, Pill, useSpring } from "../components/ui";
import { cn } from "../utils/cn";

type Mode = "image" | "video";
type ImageType = "image/jpeg" | "image/png" | "image/webp";

interface ImageResult {
  blob: Blob;
  width: number;
  height: number;
  url: string;
  type: ImageType;
  quality: number;
}

export function ToolsScreen() {
  const { t, lang, library, libraryUrls, addLocalFiles, notify, play } = useDon();
  const [mode, setMode] = useState<Mode>("image");
  const [sourceId, setSourceId] = useState<string | null>(null);
  const [type, setType] = useState<ImageType>("image/webp");
  const [quality, setQuality] = useState(0.82);
  const [maxEdge, setMaxEdge] = useState(0);
  const [result, setResult] = useState<ImageResult | null>(null);
  const [compare, setCompare] = useState(50);
  const [working, setWorking] = useState<string | null>(null);
  const [videoProgress, setVideoProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const spring = useSpring();

  const images = useMemo(() => library.filter((item) => item.kind === "image"), [library]);
  const videos = useMemo(() => library.filter((item) => item.kind === "video"), [library]);
  const pool = mode === "image" ? images : videos;
  const source = pool.find((item) => item.id === sourceId) || null;
  const sourceUrl = source ? libraryUrls[source.id] : undefined;

  const runImage = async () => {
    if (!source || !sourceUrl) return;
    setWorking("image");
    setResult(null);
    try {
      const original = await (await fetch(sourceUrl)).blob();
      const output = await processImage(original, type, quality, maxEdge || undefined);
      const url = URL.createObjectURL(output.blob);
      setResult({ ...output, url, type, quality });
      const saving = original.size > 0 ? Math.round((1 - output.blob.size / original.size) * 100) : 0;
      notify(
        saving > 0
          ? `${formatBytes(original.size)} → ${formatBytes(output.blob.size)} · ${t("saved")} ${saving}%`
          : lang === "ar"
            ? `الناتج أكبر من الأصل (${formatBytes(output.blob.size)}) — لن نستبدل ملفك`
            : `Output is larger (${formatBytes(output.blob.size)}) — your file stays untouched`,
        saving > 0 ? "ok" : "warn",
      );
    } catch {
      notify(lang === "ar" ? "تعذّرت معالجة الصورة" : "Image processing failed", "error");
    } finally {
      setWorking(null);
    }
  };

  const runVideo = async (action: "trim" | "compress" | "audio") => {
    const video = videoRef.current;
    if (!video || !source) return;
    if (!sourceUrl?.startsWith("blob:")) {
      notify(lang === "ar" ? "اختر ملفًا محليًا من مكتبتك" : "Pick a local file from your library", "warn");
      return;
    }
    setWorking(action);
    setVideoProgress(0);
    try {
      const duration = Number.isFinite(video.duration) ? video.duration : 0;
      const blob = await recordSegment(video, {
        from: 0,
        to: Math.min(duration, action === "trim" ? Math.min(10, duration) : duration),
        audioOnly: action === "audio",
        videoBitsPerSecond: action === "compress" ? 500_000 : undefined,
        onProgress: setVideoProgress,
      });
      const base = source.title.replace(/\.[a-z0-9]+$/i, "");
      const isAudio = action === "audio";
      const filename = `${base}-${action}.${isAudio ? "weba" : "webm"}`;
      await addLocalFiles([new File([blob], filename, { type: blob.type })]);
      saveBlob(blob, filename);
      notify(`${filename} · ${formatBytes(blob.size)}`, "ok");
    } catch (error) {
      notify(
        error instanceof Error && error.message === "capture-stream-unsupported"
          ? lang === "ar" ? "المتصفح لا يدعم captureStream" : "captureStream unsupported"
          : lang === "ar" ? "تعذّرت المعالجة" : "Processing failed",
        "error",
      );
    } finally {
      setWorking(null);
      setVideoProgress(0);
    }
  };

  return (
    <div className="pb-4">
      <Header
        title={t("tools")}
        subtitle={lang === "ar" ? "معالجة حقيقية على جهازك — بلا خادم" : "Real on-device processing — no server"}
        right={
          <input
            ref={fileRef}
            type="file"
            accept={mode === "image" ? "image/*" : "video/*,audio/*"}
            className="hidden"
            onChange={async (event) => {
              const files = event.target.files;
              if (files?.length) {
                await addLocalFiles(files);
                notify(lang === "ar" ? "أُضيف للمكتبة — اختره الآن" : "Added to library — select it now", "ok");
              }
              event.target.value = "";
            }}
          />
        }
      />

      <div className="px-4">
        <div className="relative grid grid-cols-2 gap-1 rounded-[16px] border border-[var(--line)] bg-black/25 p-1">
          {([
            { id: "image" as Mode, label: lang === "ar" ? "الصور" : "Images", icon: ImageIcon },
            { id: "video" as Mode, label: lang === "ar" ? "فيديو وصوت" : "Video & audio", icon: Film },
          ]).map((item) => (
            <button key={item.id} type="button" onClick={() => { setMode(item.id); setSourceId(null); setResult(null); }} className={cn("press relative flex items-center justify-center gap-1.5 rounded-[12px] py-2 text-[9.5px] font-medium", mode === item.id ? "text-[var(--tx)]" : "text-[var(--tx-mute)]")}>
              {mode === item.id && <motion.span layoutId="tools-mode" transition={spring} className="absolute inset-0 rounded-[12px] border border-[var(--line)]" style={{ background: "linear-gradient(115deg, rgba(var(--glow),0.22), rgba(var(--glow2),0.16))" }} />}
              <item.icon size={12} className="relative" />
              <span className="relative">{item.label}</span>
            </button>
          ))}
        </div>

        {/* source picker */}
        <div className="mt-2.5">
          <div className="mb-1.5 flex items-center justify-between">
            <p className="text-[9.5px] font-semibold text-[var(--tx)]">{lang === "ar" ? "الملف المصدر" : "Source file"}</p>
            <button type="button" onClick={() => fileRef.current?.click()} className="press flex items-center gap-1 rounded-full border border-[var(--line)] bg-[var(--surface-alt)] px-2 py-1 text-[7.5px] text-[var(--tx-dim)]">
              <FolderUp size={9} /> {t("pickFile")}
            </button>
          </div>
          {pool.length ? (
            <div className="no-bar flex gap-1.5 overflow-x-auto pb-1">
              {pool.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => { setSourceId(item.id); setResult(null); }}
                  className={cn("press relative h-[54px] w-[86px] shrink-0 overflow-hidden rounded-[12px] border", sourceId === item.id ? "border-[var(--c1)]" : "border-[var(--line)]")}
                >
                  {item.kind === "image" && libraryUrls[item.id] ? (
                    <img src={libraryUrls[item.id]} alt="" className="h-full w-full object-cover" />
                  ) : item.poster ? (
                    <img src={item.poster} alt="" className="h-full w-full object-cover opacity-80" />
                  ) : (
                    <span className="grid h-full w-full place-items-center bg-black/40 text-[var(--tx-mute)]"><Film size={16} /></span>
                  )}
                  <span className="absolute inset-x-0 bottom-0 truncate bg-black/70 px-1 py-[2px] text-left font-display text-[6.5px] text-white/80" dir="ltr">
                    {formatBytes(item.size)}
                  </span>
                  {sourceId === item.id && <span className="absolute right-1 top-1 grid h-4 w-4 place-items-center rounded-full bg-[var(--c1)] text-white"><Check size={9} /></span>}
                </button>
              ))}
            </div>
          ) : (
            <Card>
              <Empty title={lang === "ar" ? "لا ملفات من هذا النوع" : "No files of this type"} hint={lang === "ar" ? "أضف ملفًا من جهازك أو حمّله من DON Tube" : "Add a file from your device or download one from DON Tube"} icon={<FolderUp size={22} />} />
            </Card>
          )}
        </div>

        <AnimatePresence mode="wait">
          {mode === "image" ? (
            <motion.div key="image" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={spring} className="mt-3">
              <Card className="p-3">
                <p className="text-[9.5px] font-semibold text-[var(--tx)]">{t("convert")}</p>
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {([
                    { id: "image/webp" as ImageType, label: "WebP" },
                    { id: "image/jpeg" as ImageType, label: "JPG" },
                    { id: "image/png" as ImageType, label: "PNG" },
                  ]).map((item) => (
                    <Pill key={item.id} active={type === item.id} onClick={() => setType(item.id)}>{item.label}</Pill>
                  ))}
                </div>
                <div className="mt-2.5">
                  <div className="mb-1 flex justify-between text-[8px] text-[var(--tx-mute)]">
                    <span>{lang === "ar" ? "الجودة" : "Quality"}</span>
                    <span className="font-display tabular-nums" dir="ltr">{Math.round(quality * 100)}%</span>
                  </div>
                  <input type="range" className="don-range w-full" min={0.2} max={1} step={0.01} value={quality} onChange={(event) => setQuality(Number(event.target.value))} aria-label="quality" />
                </div>
                <div className="mt-1.5">
                  <div className="mb-1 flex justify-between text-[8px] text-[var(--tx-mute)]">
                    <span>{lang === "ar" ? "أقصى ضلع (0 = الأصل)" : "Max edge (0 = original)"}</span>
                    <span className="font-display tabular-nums" dir="ltr">{maxEdge || "—"}</span>
                  </div>
                  <input type="range" className="don-range w-full" min={0} max={2400} step={100} value={maxEdge} onChange={(event) => setMaxEdge(Number(event.target.value))} aria-label="max edge" />
                </div>
                <button type="button" disabled={!source || !!working} onClick={() => void runImage()} className="press btn-primary mt-2.5 flex w-full items-center justify-center gap-1.5 rounded-[12px] py-2.5 text-[10px] font-semibold disabled:opacity-40">
                  {working === "image" ? <Loader2 size={12} className="animate-spin" /> : <Wand2 size={12} />}
                  {working === "image" ? (lang === "ar" ? "جارٍ الترميز…" : "Encoding…") : `${t("convert")} → ${type.split("/")[1].toUpperCase()}`}
                </button>
              </Card>

              {result && source && (
                <Card glow className="mt-2 p-3">
                  <div className="flex items-center justify-between">
                    <p className="flex items-center gap-1.5 text-[9.5px] font-semibold text-[var(--tx)]"><Sparkles size={11} className="text-[var(--c2)]" /> {t("before")} / {t("after")}</p>
                    <Badge tone={result.blob.size < source.size ? "#67e8c7" : "#ff9d9d"}>
                      {result.blob.size < source.size ? `${t("saved")} ${Math.round((1 - result.blob.size / source.size) * 100)}%` : lang === "ar" ? "أكبر من الأصل" : "larger"}
                    </Badge>
                  </div>
                  <div className="relative mt-2 h-[150px] overflow-hidden rounded-[13px] border border-[var(--line)] bg-black/40">
                    <img src={result.url} alt="after" className="absolute inset-0 h-full w-full object-contain" />
                    <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - compare}% 0 0)` }}>
                      <img src={libraryUrls[source.id]} alt="before" className="h-full w-full object-contain" />
                    </div>
                    <div className="pointer-events-none absolute inset-y-0" style={{ left: `${compare}%` }}>
                      <span className="absolute inset-y-0 left-0 w-[1.5px] bg-white/85" />
                      <span className="absolute left-1/2 top-1/2 grid h-6 w-6 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border border-white/70 bg-white/25 backdrop-blur-md">
                        <ArrowRight size={9} className="text-white" />
                      </span>
                    </div>
                    <input type="range" min={2} max={98} value={compare} onChange={(event) => setCompare(Number(event.target.value))} aria-label="compare" className="don-range absolute inset-0 h-full w-full cursor-ew-resize opacity-0" />
                    <span className="absolute left-1.5 top-1.5 rounded-[5px] bg-black/60 px-1.5 py-[2px] font-display text-[6.5px] text-white/80">{t("before")} · {formatBytes(source.size)}</span>
                    <span className="absolute right-1.5 top-1.5 rounded-[5px] bg-black/60 px-1.5 py-[2px] font-display text-[6.5px] text-white/80">{t("after")} · {formatBytes(result.blob.size)}</span>
                  </div>
                  <div className="mt-2 grid grid-cols-3 gap-1.5">
                    <button type="button" onClick={() => saveBlob(result.blob, `${source.title.split(".")[0]}-${result.type.split("/")[1]}`)} className="press btn-primary flex items-center justify-center gap-1 rounded-[10px] py-2 text-[8.5px] font-medium">
                      <Check size={10} /> {t("exportFile")}
                    </button>
                    <button type="button" onClick={async () => { await addLocalFiles([new File([result.blob], `${source.title.split(".")[0]}-${result.type.split("/")[1]}`, { type: result.blob.type })]); }} className="press flex items-center justify-center gap-1 rounded-[10px] border border-[var(--line)] bg-[var(--surface-alt)] py-2 text-[8.5px] text-[var(--tx-dim)]">
                      <FolderUp size={10} /> {lang === "ar" ? "للمكتبة" : "To library"}
                    </button>
                    <button type="button" onClick={() => play({ src: result.url, title: result.type, kind: "image" })} className="press flex items-center justify-center gap-1 rounded-[10px] border border-[var(--line)] bg-[var(--surface-alt)] py-2 text-[8.5px] text-[var(--tx-dim)]">
                      <ImageIcon size={10} /> {t("open")}
                    </button>
                  </div>
                  <p className="mt-1.5 text-[7px] text-[var(--tx-mute)]">
                    {result.width}×{result.height} · {result.type} · q={result.quality} · {lang === "ar" ? "الأصل لم يُستبدل" : "original untouched"}
                  </p>
                </Card>
              )}
            </motion.div>
          ) : (
            <motion.div key="video" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={spring} className="mt-3">
              {source && sourceUrl ? (
                <Card className="p-3">
                  <video ref={videoRef} src={sourceUrl} poster={source.poster} controls playsInline className="aspect-video w-full rounded-[12px] border border-[var(--line)] bg-black object-contain" />
                  <p className="mt-2 truncate text-[9.5px] text-[var(--tx)]">{source.title}</p>
                  <p className="font-display text-[7.5px] text-[var(--tx-mute)]" dir="ltr">{formatBytes(source.size)} · {source.kind}</p>

                  <div className="mt-2 grid grid-cols-3 gap-1.5">
                    {[
                      { id: "trim" as const, icon: Scissors, label: lang === "ar" ? "قص 10 ثوانٍ" : "Trim 10s" },
                      { id: "compress" as const, icon: Gauge, label: lang === "ar" ? "ضغط 500k" : "Compress 500k" },
                      { id: "audio" as const, icon: Music2, label: t("extractAudio") },
                    ].map((action) => (
                      <button key={action.id} type="button" disabled={!!working} onClick={() => void runVideo(action.id)} className="press flex flex-col items-center gap-1 rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] py-2.5 text-[8px] text-[var(--tx-dim)] disabled:opacity-50">
                        {working === action.id ? <Loader2 size={13} className="animate-spin" /> : <action.icon size={13} />}
                        {action.label}
                      </button>
                    ))}
                  </div>

                  {working && (
                    <div className="mt-2">
                      <div className="mb-1 flex justify-between text-[8px] text-[var(--tx-dim)]">
                        <span className="flex items-center gap-1"><AudioLines size={9} /> {lang === "ar" ? "تسجيل فعلي بالوقت الحقيقي" : "Recording in real time"}</span>
                        <span className="font-display tabular-nums">{Math.round(videoProgress * 100)}%</span>
                      </div>
                      <Bar value={videoProgress * 100} />
                    </div>
                  )}

                  <div className="mt-2 flex items-start gap-2 rounded-[11px] border border-[var(--line)] bg-black/20 p-2">
                    <TriangleAlert size={11} className="mt-0.5 shrink-0 text-[#f5ce8a]" />
                    <p className="text-[7px] leading-4 text-[var(--tx-mute)]">
                      {lang === "ar"
                        ? "المعالجة تتم فعليًا عبر MediaRecorder + Canvas على جهازك. الملفات البعيدة تحتاج تحميلها أولًا لأن المتصفح يمنع التسجيل عبر النطاقات."
                        : "Processing really runs through MediaRecorder + Canvas on your device. Remote files must be downloaded first because browsers block cross-origin recording."}
                    </p>
                  </div>
                </Card>
              ) : (
                <Card>
                  <Empty title={lang === "ar" ? "اختر ملف فيديو أو صوت" : "Pick a video or audio file"} hint={lang === "ar" ? "من المكتبة أو من جهازك مباشرة" : "From your library or your device"} icon={<Film size={22} />} />
                </Card>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
