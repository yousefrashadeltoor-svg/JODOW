import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowDownToLine,
  Bell,
  Check,
  ChevronLeft,
  Copy,
  Download,
  Heart,
  History,
  Home,
  Image as ImageIcon,
  Link2,
  ListVideo,
  Music2,
  Pause,
  Play,
  Plus,
  Save,
  Search,
  Settings2,
  Share2,
  ThumbsDown,
  ThumbsUp,
  Trash2,
  Tv,
  UserRound,
  Video,
  X,
} from "lucide-react";
import { useDon } from "../don/store";
import { CATALOG, CHANNELS, channelById, compactNumber, formatBytes, formatDuration, relativeDays, type TubeVideo } from "../don/core";
import { Avatar, Badge, Bar, Card, Empty, IconButton, Pill, Sheet, useSpring } from "../components/ui";
import { cn } from "../utils/cn";

type TubeTab = "home" | "shorts" | "subs" | "me";
type TubeView = { kind: "tab" } | { kind: "watch"; videoId: string } | { kind: "search"; query: string } | { kind: "channel"; channelId: string };

const PAGE = 4;

export function TubeScreen() {
  const {
    t,
    lang,
    play,
    enqueue,
    copy,
    following,
    toggleFollow,
    likes,
    toggleLike,
    saved,
    toggleSaved,
    history,
    hideVideo,
    recommendations,
    library,
    notify,
    setScreen,
  } = useDon();

  const [tab, setTab] = useState<TubeTab>("home");
  const [view, setView] = useState<TubeView>({ kind: "tab" });
  const [query, setQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [page, setPage] = useState(1);
  const [tag, setTag] = useState<string | null>(null);
  const [menuFor, setMenuFor] = useState<string | null>(null);
  const [sheetVideo, setSheetVideo] = useState<TubeVideo | null>(null);
  const sentinel = useRef<HTMLDivElement | null>(null);
  const spring = useSpring();

  const ranked = useMemo(() => recommendations(), [recommendations]);
  const feed = useMemo(() => {
    const filtered = tag ? ranked.filter((video) => video.tags.includes(tag)) : ranked;
    return filtered.slice(0, page * PAGE);
  }, [ranked, page, tag]);
  const exhausted = feed.length >= (tag ? ranked.filter((video) => video.tags.includes(tag)).length : ranked.length);

  const shorts = useMemo(() => CATALOG.filter((video) => video.kind === "short" || video.kind === "music"), []);
  const tags = useMemo(() => [...new Set(CATALOG.flatMap((video) => video.tags))].slice(0, 14), []);

  /* real infinite feed */
  useEffect(() => {
    const node = sentinel.current;
    if (!node || view.kind !== "tab" || tab !== "home") return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting && !exhausted) setPage((value) => value + 1);
      },
      { rootMargin: "120px" },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [exhausted, tab, view.kind]);

  const searchIndex = useMemo(() => {
    const libraryTitles = library.map((item) => ({ title: item.title, kind: "library" as const, id: item.id }));
    return { libraryTitles };
  }, [library]);

  const suggestions = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [] as string[];
    const fromCatalog = CATALOG.filter((video) => video.title.toLowerCase().includes(q)).map((video) => video.title);
    const fromTags = tags.filter((item) => item.includes(q));
    const fromChannels = CHANNELS.filter((channel) => channel.name.toLowerCase().includes(q)).map((channel) => channel.name);
    const fromLibrary = searchIndex.libraryTitles.filter((item) => item.title.toLowerCase().includes(q)).map((item) => item.title);
    return [...new Set([...fromCatalog, ...fromChannels, ...fromTags, ...fromLibrary])].slice(0, 6);
  }, [query, tags, searchIndex]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [] as TubeVideo[];
    return CATALOG.filter(
      (video) =>
        video.title.toLowerCase().includes(q) ||
        video.tags.some((item) => item.includes(q)) ||
        channelById(video.channelId).name.toLowerCase().includes(q),
    );
  }, [query]);

  const openWatch = (videoId: string) => {
    setView({ kind: "watch", videoId });
    setMenuFor(null);
  };

  const goTab = (next: TubeTab) => {
    setTab(next);
    setView({ kind: "tab" });
    setPage(1);
    setSearchOpen(false);
  };

  const watchedProgress = (videoId: string) => history.find((entry) => entry.videoId === videoId)?.progress || 0;

  return (
    <div className="relative flex min-h-[640px] flex-col pb-[76px]">
      {/* top bar */}
      <div className="sticky top-0 z-30 px-3 pb-2 pt-1 backdrop-blur-xl" style={{ background: `color-mix(in srgb, var(--bg) 82%, transparent)` }}>
        <div className="flex items-center gap-2">
          {view.kind !== "tab" ? (
            <IconButton label={t("back")} size="sm" onClick={() => setView({ kind: "tab" })}>
              <ChevronLeft size={14} className={lang === "ar" ? "rotate-180" : ""} />
            </IconButton>
          ) : (
            <span className="flex items-center gap-1.5">
              <span className="grid h-7 w-7 place-items-center rounded-[9px]" style={{ background: "linear-gradient(140deg, var(--c1), var(--c2) 55%, var(--c3))" }}>
                <Play size={12} className="fill-white text-white" />
              </span>
              <span className="font-display text-[13px] font-semibold tracking-tight text-[var(--tx)]">DON <span className="grad-text">Tube</span></span>
            </span>
          )}

          <div className="flex min-w-0 flex-1 items-center gap-1.5 rounded-full border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-[7px]">
            <Search size={11} className="shrink-0 text-[var(--tx-mute)]" />
            <input
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                setSearchOpen(true);
                if (event.target.value.trim()) setView({ kind: "search", query: event.target.value });
                else setView({ kind: "tab" });
              }}
              onFocus={() => setSearchOpen(true)}
              placeholder={t("search")}
              className="min-w-0 flex-1 bg-transparent text-[9.5px] text-[var(--tx)] outline-none placeholder:text-[var(--tx-mute)]"
            />
            {query && (
              <button type="button" aria-label="clear" onClick={() => { setQuery(""); setView({ kind: "tab" }); }}>
                <X size={11} className="text-[var(--tx-mute)]" />
              </button>
            )}
          </div>
          <IconButton label={t("settings")} size="sm" onClick={() => setScreen("settings")}>
            <Settings2 size={13} />
          </IconButton>
        </div>

        {/* suggestions */}
        <AnimatePresence>
          {searchOpen && query.trim() && suggestions.length > 0 && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
              <div className="mt-1.5 space-y-0.5 rounded-[14px] border border-[var(--line)] bg-[var(--surface)] p-1 backdrop-blur-xl">
                {suggestions.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => { setQuery(item); setSearchOpen(false); setView({ kind: "search", query: item }); }}
                    className="press flex w-full items-center gap-2 rounded-[9px] px-2 py-1.5 text-right hover:bg-white/5"
                  >
                    <Search size={10} className="text-[var(--tx-mute)]" />
                    <span className="min-w-0 flex-1 truncate text-[9px] text-[var(--tx-dim)]">{item}</span>
                    <ChevronLeft size={10} className="text-[var(--tx-mute)]" />
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* content */}
      <div className="flex-1 px-3">
        <AnimatePresence mode="wait">
          {view.kind === "watch" ? (
            <motion.div key={`watch-${view.videoId}`} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} transition={spring}>
              <WatchView
                videoId={view.videoId}
                onOpenPlayer={(video) => play({ src: video.src, title: video.title, poster: video.poster, kind: video.kind === "music" ? "audio" : "video", videoId: video.id, channelId: video.channelId, vertical: video.kind !== "video", remote: true })}
                onDownload={(video) => void enqueue(video.src, { title: video.title, kind: video.kind === "music" ? "audio" : "video", poster: video.poster })}
                onCopy={(video) => void copy(video.src, video.title)}
              />
            </motion.div>
          ) : view.kind === "channel" ? (
            <motion.div key={`channel-${view.channelId}`} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={spring}>
              <ChannelView channelId={view.channelId} onOpen={openWatch} />
            </motion.div>
          ) : view.kind === "search" ? (
            <motion.div key="search" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <p className="mb-2 text-[9px] text-[var(--tx-mute)]">
                {results.length} {lang === "ar" ? "نتيجة في الفهرس المحلي" : "results in the local index"}
              </p>
              {results.length ? (
                <div className="space-y-2">
                  {results.map((video) => (
                    <VideoRow key={video.id} video={video} onOpen={openWatch} onMenu={() => setSheetVideo(video)} progress={watchedProgress(video.id)} />
                  ))}
                </div>
              ) : (
                <Card><Empty title={t("noItems")} hint={lang === "ar" ? "جرّب كلمة أخرى أو تصفّح التغذية" : "Try another word or browse the feed"} icon={<Search size={22} />} /></Card>
              )}
            </motion.div>
          ) : tab === "home" ? (
            <motion.div key="home" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="no-bar -mx-1 mb-2 flex gap-1.5 overflow-x-auto px-1">
                <Pill active={!tag} onClick={() => { setTag(null); setPage(1); }}>{lang === "ar" ? "لك" : "For you"}</Pill>
                {tags.map((item) => (
                  <Pill key={item} active={tag === item} onClick={() => { setTag(tag === item ? null : item); setPage(1); }}>
                    {item}
                  </Pill>
                ))}
              </div>
              <div className="mb-2 flex items-center gap-1.5 text-[8px] text-[var(--tx-mute)]">
                <SparklineIcon /> {t("infinite")} · {history.length} {lang === "ar" ? "إشارة مشاهدة" : "watch signals"}
              </div>
              <div className="space-y-3">
                {feed.map((video) => (
                  <VideoCard key={`${video.id}-${feed.indexOf(video)}`} video={video} onOpen={openWatch} onMenu={() => setSheetVideo(video)} progress={watchedProgress(video.id)} onChannel={() => setView({ kind: "channel", channelId: video.channelId })} />
                ))}
              </div>
              <div ref={sentinel} className="h-8" />
              {exhausted && (
                <p className="py-3 text-center text-[8px] text-[var(--tx-mute)]">
                  {lang === "ar" ? "انتهى الفهرس المحلي — حمّل روابط أو أضف ملفات لتوسيع التوصيات" : "Local index exhausted — download links or add files to widen recommendations"}
                </p>
              )}
            </motion.div>
          ) : tab === "shorts" ? (
            <motion.div key="shorts" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <ShortsRail videos={shorts} />
            </motion.div>
          ) : tab === "subs" ? (
            <motion.div key="subs" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              {following.length ? (
                <div className="space-y-2">
                  {following.map((channelId) => {
                    const channel = channelById(channelId);
                    const videos = CATALOG.filter((video) => video.channelId === channelId);
                    return (
                      <Card key={channelId} className="p-2.5">
                        <div className="flex items-center gap-2">
                          <Avatar name={channel.initial} color={channel.color} size={32} />
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-[10.5px] font-medium text-[var(--tx)]">{channel.name}</p>
                            <p className="font-display text-[7.5px] text-[var(--tx-mute)]">{compactNumber(channel.followers, lang)} {t("followers")} · {videos.length} {t("videosCount")}</p>
                          </div>
                          <button type="button" onClick={() => toggleFollow(channelId)} className="press rounded-full border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-1 text-[8px] text-[var(--tx-dim)]">
                            {t("unfollow")}
                          </button>
                        </div>
                        {videos[0] && (
                          <button type="button" onClick={() => openWatch(videos[0].id)} className="press mt-2 flex w-full items-center gap-2 rounded-[12px] border border-[var(--line)] bg-black/20 p-1.5 text-right">
                            <img src={videos[0].poster} alt="" className="h-10 w-16 shrink-0 rounded-[8px] object-cover" />
                            <span className="min-w-0 flex-1">
                              <span className="block truncate text-[9px] text-[var(--tx)]">{videos[0].title}</span>
                              <span className="block font-display text-[7px] text-[var(--tx-mute)]">{relativeDays(videos[0].publishedDaysAgo, lang)}</span>
                            </span>
                            <Play size={12} className="shrink-0 text-[var(--tx-dim)]" />
                          </button>
                        )}
                      </Card>
                    );
                  })}
                </div>
              ) : (
                <Card><Empty title={lang === "ar" ? "لا متابعة بعد" : "No follows yet"} hint={lang === "ar" ? "تابع القنوات المحلية من صفحة أي فيديو" : "Follow local channels from any video page"} icon={<Bell size={22} />} /></Card>
              )}
            </motion.div>
          ) : (
            <motion.div key="me" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <ProfileView />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* tab bar */}
      <nav className="sticky bottom-[76px] z-30 mt-3 px-3">
        <div className="specular flex items-center justify-between rounded-[20px] border border-[var(--line)] bg-[var(--surface)] px-1.5 py-1.5 backdrop-blur-2xl">
          {([
            { id: "home" as TubeTab, icon: Home, label: t("home") },
            { id: "shorts" as TubeTab, icon: Tv, label: t("shorts") },
            { id: "subs" as TubeTab, icon: ListVideo, label: t("subscriptions") },
            { id: "me" as TubeTab, icon: UserRound, label: t("profile") },
          ]).map((item) => (
            <button key={item.id} type="button" onClick={() => goTab(item.id)} className={cn("press relative flex flex-1 flex-col items-center gap-[3px] rounded-[15px] py-[6px] text-[8px]", tab === item.id && view.kind === "tab" ? "text-[var(--tx)]" : "text-[var(--tx-mute)]")}>
              {tab === item.id && view.kind === "tab" && (
                <motion.span layoutId="tube-pill" transition={spring} className="absolute inset-0 rounded-[15px] border border-[var(--line)] bg-white/10" />
              )}
              <item.icon size={15} className="relative" />
              <span className="relative">{item.label}</span>
              {item.id === "subs" && following.length > 0 && <span className="absolute right-3 top-1 h-1.5 w-1.5 rounded-full" style={{ background: "var(--c3)" }} />}
            </button>
          ))}
        </div>
      </nav>

      {/* video action sheet */}
      <Sheet open={!!sheetVideo || !!menuFor} onClose={() => { setSheetVideo(null); setMenuFor(null); }} title={sheetVideo?.title} subtitle={sheetVideo ? `${channelById(sheetVideo.channelId).name} · ${compactNumber(sheetVideo.views, lang)} ${t("views")}` : undefined}>
        {sheetVideo && (
          <div className="space-y-1.5 pb-2">
            {[
              { icon: Play, label: lang === "ar" ? "تشغيل في المشغّل الكامل" : "Play in full player", action: () => { play({ src: sheetVideo.src, title: sheetVideo.title, poster: sheetVideo.poster, kind: sheetVideo.kind === "music" ? "audio" : "video", videoId: sheetVideo.id, channelId: sheetVideo.channelId, vertical: sheetVideo.kind !== "video", remote: true }); setSheetVideo(null); } },
              { icon: Download, label: `${t("download")} · ${sheetVideo.quality}`, action: () => { void enqueue(sheetVideo.src, { title: sheetVideo.title, kind: sheetVideo.kind === "music" ? "audio" : "video", poster: sheetVideo.poster }); setSheetVideo(null); setScreen("downloads"); } },
              { icon: Copy, label: t("copyLink"), action: () => { void copy(sheetVideo.src, sheetVideo.title); setSheetVideo(null); } },
              { icon: Save, label: saved.includes(sheetVideo.id) ? lang === "ar" ? "إزالة من لاحقًا" : "Remove from later" : t("watchLater"), action: () => { toggleSaved(sheetVideo.id); setSheetVideo(null); } },
              { icon: Heart, label: likes.includes(sheetVideo.id) ? lang === "ar" ? "إلغاء الإعجاب" : "Unlike" : lang === "ar" ? "إعجاب" : "Like", action: () => { toggleLike(sheetVideo.id); setSheetVideo(null); } },
              { icon: Bell, label: following.includes(sheetVideo.channelId) ? t("unfollow") : `${t("follow")} ${channelById(sheetVideo.channelId).name}`, action: () => { toggleFollow(sheetVideo.channelId); setSheetVideo(null); } },
              { icon: X, label: t("notInterested"), action: () => { hideVideo(sheetVideo.id); notify(lang === "ar" ? "لن يظهر هذا العنصر مجددًا" : "This item will not appear again", "ok"); setSheetVideo(null); } },
            ].map((action) => (
              <button key={action.label} type="button" onClick={action.action} className="press flex w-full items-center gap-2.5 rounded-[13px] border border-[var(--line)] bg-[var(--surface-alt)] p-2.5 text-right">
                <span className="grid h-8 w-8 place-items-center rounded-[10px] border border-[var(--line)] bg-black/20 text-[var(--c2)]"><action.icon size={14} /></span>
                <span className="min-w-0 flex-1 truncate text-[10px] text-[var(--tx)]">{action.label}</span>
              </button>
            ))}
            <p className="pt-1 text-center text-[7.5px] text-[var(--tx-mute)]">{t("copyright")}</p>
          </div>
        )}
      </Sheet>
    </div>
  );
}

function SparklineIcon() {
  return (
    <span className="flex h-3 items-end gap-[1.5px]">
      {[40, 70, 55, 90, 65].map((height) => (
        <span key={height} className="w-[2px] rounded-full eq-bar" style={{ height: `${height}%`, background: "var(--c2)" }} />
      ))}
    </span>
  );
}

function VideoCard({ video, onOpen, onMenu, progress, onChannel }: { video: TubeVideo; onOpen: (id: string) => void; onMenu: () => void; progress: number; onChannel: () => void }) {
  const { lang, t, enqueue, likes, toggleLike, following, toggleFollow } = useDon();
  const channel = channelById(video.channelId);
  const [preview, setPreview] = useState(false);
  const previewRef = useRef<HTMLVideoElement | null>(null);

  return (
    <Card className="overflow-hidden">
      <button type="button" onClick={() => onOpen(video.id)} className="press relative block w-full">
        <div className="relative aspect-video w-full overflow-hidden bg-black">
          {preview ? (
            <video ref={previewRef} src={video.src} poster={video.poster} autoPlay muted loop playsInline className="h-full w-full object-cover" />
          ) : (
            <img src={video.poster} alt={video.title} loading="lazy" className="h-full w-full object-cover" />
          )}
          <span className="absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-black/80 to-transparent" />
          <span className="absolute bottom-1.5 right-2 rounded-[5px] bg-black/75 px-1.5 py-[2px] font-display text-[8px] font-medium text-white/90" dir="ltr">
            {formatDuration(video.duration)}
          </span>
          <span className="absolute bottom-1.5 left-2 rounded-[5px] border border-white/15 bg-black/50 px-1.5 py-[2px] font-display text-[7px] text-white/70" dir="ltr">
            {video.quality}
          </span>
          {progress > 0.02 && (
            <span className="absolute inset-x-0 bottom-0 h-[2px] bg-white/20">
              <span className="block h-full" style={{ width: `${Math.min(100, progress * 100)}%`, background: "var(--c3)" }} />
            </span>
          )}
        </div>
      </button>
      <div className="flex items-start gap-2 p-2.5">
        <button type="button" onClick={onChannel} className="press">
          <Avatar name={channel.initial} color={channel.color} size={30} />
        </button>
        <div className="min-w-0 flex-1">
          <button type="button" onClick={() => onOpen(video.id)} className="press block w-full text-right">
            <p className="line-clamp-2 text-[10.5px] font-medium leading-[1.6] text-[var(--tx)]">{video.title}</p>
          </button>
          <p className="mt-0.5 truncate text-[8px] text-[var(--tx-mute)]">
            {channel.name} {channel.verified && <Check size={7} className="inline text-[var(--c1)]" />} · {compactNumber(video.views, lang)} {t("views")} · {relativeDays(video.publishedDaysAgo, lang)}
          </p>
          <div className="mt-1.5 flex flex-wrap items-center gap-1">
            <button type="button" onClick={() => void enqueue(video.src, { title: video.title, kind: video.kind === "music" ? "audio" : "video", poster: video.poster })} className="press btn-primary flex items-center gap-1 rounded-full px-2.5 py-1 text-[8px] font-medium">
              <ArrowDownToLine size={9} /> {t("download")}
            </button>
            <button type="button" onClick={() => { setPreview(!preview); }} className="press flex items-center gap-1 rounded-full border border-[var(--line)] bg-[var(--surface-alt)] px-2 py-1 text-[8px] text-[var(--tx-dim)]">
              {preview ? <Pause size={9} /> : <Play size={9} />} {preview ? (lang === "ar" ? "إيقاف المعاينة" : "Stop preview") : lang === "ar" ? "معاينة صامتة" : "Mute preview"}
            </button>
            <button type="button" onClick={() => toggleLike(video.id)} className={cn("press flex items-center gap-1 rounded-full border px-2 py-1 text-[8px]", likes.includes(video.id) ? "border-transparent text-white" : "border-[var(--line)] bg-[var(--surface-alt)] text-[var(--tx-dim)]")} style={likes.includes(video.id) ? { background: "linear-gradient(115deg, var(--c1), var(--c2))" } : undefined}>
              <ThumbsUp size={9} />
            </button>
            <button type="button" onClick={() => toggleFollow(channel.id)} className="press flex items-center gap-1 rounded-full border border-[var(--line)] bg-[var(--surface-alt)] px-2 py-1 text-[8px] text-[var(--tx-dim)]">
              {following.includes(channel.id) ? <Check size={9} /> : <Plus size={9} />} {following.includes(channel.id) ? lang === "ar" ? "متابَع" : "Following" : t("follow")}
            </button>
            <button type="button" onClick={onMenu} aria-label="more" className="press ml-auto grid h-6 w-6 place-items-center rounded-full text-[var(--tx-mute)]">
              <ListVideo size={12} />
            </button>
          </div>
        </div>
      </div>
    </Card>
  );
}

function VideoRow({ video, onOpen, onMenu, progress }: { video: TubeVideo; onOpen: (id: string) => void; onMenu: () => void; progress: number }) {
  const { lang, t } = useDon();
  const channel = channelById(video.channelId);
  return (
    <Card className="flex items-center gap-2.5 p-2">
      <button type="button" onClick={() => onOpen(video.id)} className="press relative h-14 w-24 shrink-0 overflow-hidden rounded-[10px] bg-black">
        <img src={video.poster} alt="" loading="lazy" className="h-full w-full object-cover" />
        <span className="absolute bottom-1 right-1 rounded bg-black/75 px-1 font-display text-[7px] text-white/85" dir="ltr">{formatDuration(video.duration)}</span>
        {progress > 0.02 && <span className="absolute inset-x-0 bottom-0 h-[2px]" style={{ background: `linear-gradient(to left, var(--c3) ${Math.min(100, progress * 100)}%, rgba(255,255,255,.2) 0)` }} />}
      </button>
      <button type="button" onClick={() => onOpen(video.id)} className="press min-w-0 flex-1 text-right">
        <p className="line-clamp-2 text-[9.5px] font-medium leading-[1.55] text-[var(--tx)]">{video.title}</p>
        <p className="mt-0.5 truncate text-[7.5px] text-[var(--tx-mute)]">{channel.name} · {compactNumber(video.views, lang)} {t("views")}</p>
      </button>
      <IconButton label="more" size="sm" onClick={onMenu}>
        <ListVideo size={12} />
      </IconButton>
    </Card>
  );
}

function WatchView({
  videoId,
  onOpenPlayer,
  onDownload,
  onCopy,
}: {
  videoId: string;
  onOpenPlayer: (video: TubeVideo) => void;
  onDownload: (video: TubeVideo) => void;
  onCopy: (video: TubeVideo) => void;
}) {
  const {
    lang,
    t,
    likes,
    dislikes,
    toggleLike,
    toggleDislike,
    saved,
    toggleSaved,
    following,
    toggleFollow,
    notes,
    addNote,
    removeNote,
    recommendations,
    history,
    notify,
  } = useDon();
  const video = CATALOG.find((item) => item.id === videoId);
  const inlineRef = useRef<HTMLVideoElement | null>(null);
  const [playing, setPlaying] = useState(true);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [noteText, setNoteText] = useState("");
  const [showNotes, setShowNotes] = useState(false);

  const related = useMemo(() => recommendations(videoId).filter((item) => item.id !== videoId).slice(0, 6), [recommendations, videoId]);
  if (!video) return null;
  const channel = channelById(video.channelId);
  const videoNotes = notes[video.id] || [];
  const progress = history.find((entry) => entry.videoId === video.id)?.progress || 0;

  return (
    <div className="pb-3">
      <div className="relative aspect-video w-full overflow-hidden rounded-[18px] border border-[var(--line)] bg-black">
        <video
          ref={inlineRef}
          src={video.src}
          poster={video.poster}
          autoPlay
          playsInline
          onTimeUpdate={(event) => setTime(event.currentTarget.currentTime)}
          onLoadedMetadata={(event) => setDuration(event.currentTarget.duration || 0)}
          onPlay={() => setPlaying(true)}
          onPause={() => setPlaying(false)}
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent px-2 pb-2 pt-6">
          <div className="mb-1.5"><Bar value={duration ? (time / duration) * 100 : 0} height={3} /></div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              aria-label={playing ? t("pause") : "play"}
              onClick={() => {
                const element = inlineRef.current;
                if (!element) return;
                if (element.paused) void element.play();
                else element.pause();
              }}
              className="press grid h-8 w-8 place-items-center rounded-full border border-white/20 bg-black/45 text-white backdrop-blur-md"
            >
              {playing ? <Pause size={13} fill="currentColor" /> : <Play size={13} fill="currentColor" className="ml-0.5" />}
            </button>
            <span className="font-display text-[8px] tabular-nums text-white/75" dir="ltr">{formatClock(time)} / {formatClock(duration)}</span>
            <button type="button" onClick={() => onOpenPlayer(video)} className="press ml-auto flex items-center gap-1 rounded-full border border-white/20 bg-black/45 px-2.5 py-1.5 text-[8px] text-white/85 backdrop-blur-md">
              <Tv size={10} /> {lang === "ar" ? "المشغّل الكامل" : "Full player"}
            </button>
          </div>
        </div>
      </div>

      <h1 className="mt-2.5 text-[13px] font-semibold leading-[1.6] text-[var(--tx)]">{video.title}</h1>
      <p className="mt-1 text-[8.5px] text-[var(--tx-mute)]">
        {compactNumber(video.views, lang)} {t("views")} · {relativeDays(video.publishedDaysAgo, lang)} · <span dir="ltr">{video.quality}</span>
      </p>
      {progress > 0.02 && (
        <p className="mt-1 flex items-center gap-1 text-[7.5px] text-[var(--c1)]">
          <History size={9} /> {lang === "ar" ? "شوهد" : "watched"} {Math.round(progress * 100)}%
        </p>
      )}

      <div className="mt-2 flex items-center gap-2 rounded-[16px] border border-[var(--line)] bg-[var(--surface-alt)] p-2">
        <Avatar name={channel.initial} color={channel.color} size={34} />
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-1 truncate text-[10.5px] font-medium text-[var(--tx)]">
            {channel.name} {channel.verified && <Check size={9} className="text-[var(--c1)]" />}
          </p>
          <p className="font-display text-[7.5px] text-[var(--tx-mute)]">{compactNumber(channel.followers + (following.includes(channel.id) ? 1 : 0), lang)} {t("followers")}</p>
        </div>
        <button
          type="button"
          onClick={() => toggleFollow(channel.id)}
          className={cn("press rounded-full px-3 py-1.5 text-[8.5px] font-medium", following.includes(channel.id) ? "border border-[var(--line)] bg-[var(--surface)] text-[var(--tx-dim)]" : "btn-primary")}
        >
          {following.includes(channel.id) ? t("unfollow") : t("follow")}
        </button>
      </div>

      <div className="mt-2 grid grid-cols-5 gap-1.5">
        {[
          { icon: ThumbsUp, active: likes.includes(video.id), label: lang === "ar" ? "إعجاب" : "Like", action: () => toggleLike(video.id) },
          { icon: ThumbsDown, active: dislikes.includes(video.id), label: lang === "ar" ? "لا يعجبني" : "Dislike", action: () => toggleDislike(video.id) },
          { icon: Save, active: saved.includes(video.id), label: t("watchLater"), action: () => toggleSaved(video.id) },
          { icon: Copy, active: false, label: t("copyLink"), action: () => onCopy(video) },
          { icon: Share2, active: false, label: t("share"), action: async () => { const ok = await navigator.share?.({ title: video.title, url: video.src }).then(() => true).catch(() => false); if (!ok) onCopy(video); } },
        ].map((action) => (
          <button key={action.label} type="button" onClick={action.action} className={cn("press flex flex-col items-center gap-1 rounded-[12px] border py-2 text-[7.5px]", action.active ? "border-transparent text-white" : "border-[var(--line)] bg-[var(--surface-alt)] text-[var(--tx-dim)]")} style={action.active ? { background: "linear-gradient(115deg, var(--c1), var(--c2))" } : undefined}>
            <action.icon size={13} />
            {action.label}
          </button>
        ))}
      </div>

      <button type="button" onClick={() => onDownload(video)} className="press btn-primary mt-2 flex w-full items-center justify-center gap-1.5 rounded-[13px] py-2.5 text-[10px] font-semibold">
        <Download size={13} /> {t("download")} · {video.quality}
      </button>

      <Card className="mt-2 p-2.5">
        <div className="flex items-start gap-2">
          <Link2 size={12} className="mt-0.5 shrink-0 text-[var(--c2)]" />
          <div className="min-w-0 flex-1">
            <p className="text-[9px] leading-5 text-[var(--tx-dim)]">{video.description}</p>
            <p className="mt-1 truncate font-display text-[7.5px] text-[var(--tx-mute)]" dir="ltr">{video.src}</p>
            <div className="mt-1.5 flex flex-wrap gap-1">
              {video.tags.map((item) => (
                <Badge key={item}>#{item}</Badge>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {/* local notes */}
      <div className="mt-2">
        <button type="button" onClick={() => setShowNotes(!showNotes)} className="flex w-full items-center justify-between rounded-[13px] border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-2">
          <span className="flex items-center gap-1.5 text-[9px] text-[var(--tx-dim)]">
            <Music2 size={11} className="text-[var(--c2)]" /> {t("notes")} · {videoNotes.length}
          </span>
          <span className="text-[var(--tx-mute)]">{showNotes ? "−" : "+"}</span>
        </button>
        <AnimatePresence>
          {showNotes && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="mt-1.5 flex gap-1.5">
                <input
                  value={noteText}
                  onChange={(event) => setNoteText(event.target.value)}
                  placeholder={t("addNote")}
                  className="min-w-0 flex-1 rounded-[11px] border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-2 text-[9px] text-[var(--tx)] outline-none placeholder:text-[var(--tx-mute)]"
                />
                <button
                  type="button"
                  onClick={() => { if (!noteText.trim()) return; addNote(video.id, noteText, time); setNoteText(""); notify(t("savedOk"), "ok"); }}
                  className="press btn-primary rounded-[11px] px-3 text-[9px] font-medium"
                >
                  {t("save")}
                </button>
              </div>
              <div className="mt-1.5 space-y-1">
                {videoNotes.map((note) => (
                  <div key={note.id} className="flex items-center gap-2 rounded-[11px] border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-1.5">
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[9px] text-[var(--tx-dim)]">{note.text}</span>
                      <span className="block font-display text-[7px] text-[var(--tx-mute)]" dir="ltr">{typeof note.time === "number" ? formatClock(note.time) : ""} · {new Date(note.at).toLocaleTimeString()}</span>
                    </span>
                    {typeof note.time === "number" && (
                      <button type="button" onClick={() => { const element = inlineRef.current; const at = note.time as number; if (element) { element.currentTime = at; void element.play(); } }} className="press text-[7.5px] text-[var(--c1)]">
                        <Play size={10} />
                      </button>
                    )}
                    <button type="button" onClick={() => removeNote(video.id, note.id)} aria-label="delete note" className="press text-[var(--tx-mute)]">
                      <Trash2 size={11} />
                    </button>
                  </div>
                ))}
                {!videoNotes.length && <p className="py-2 text-center text-[8px] text-[var(--tx-mute)]">{lang === "ar" ? "لا ملاحظات — تُحفظ محليًا مع الفيديو" : "No notes — stored locally with the video"}</p>}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <p className="mb-2 mt-3 text-[10px] font-semibold text-[var(--tx)]">{lang === "ar" ? "التالي حسب تصفّحك" : "Next based on your browsing"}</p>
      <div className="space-y-2">
        {related.map((item) => (
          <VideoRow key={item.id} video={item} onOpen={(id) => onOpenPlayer(CATALOG.find((video2) => video2.id === id) as TubeVideo)} onMenu={() => onCopy(item)} progress={history.find((entry) => entry.videoId === item.id)?.progress || 0} />
        ))}
      </div>
    </div>
  );
}

function ChannelView({ channelId, onOpen }: { channelId: string; onOpen: (id: string) => void }) {
  const { lang, t, following, toggleFollow } = useDon();
  const channel = channelById(channelId);
  const videos = CATALOG.filter((video) => video.channelId === channelId);
  return (
    <div className="pb-3">
      <div className="relative h-24 overflow-hidden rounded-[18px] border border-[var(--line)]">
        <img src={videos[0]?.poster} alt="" className="h-full w-full object-cover opacity-70" />
        <span className="absolute inset-0" style={{ background: `linear-gradient(120deg, ${channel.color}55, transparent)` }} />
      </div>
      <div className="mt-2 flex items-center gap-2.5">
        <Avatar name={channel.initial} color={channel.color} size={44} />
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-1 text-[13px] font-semibold text-[var(--tx)]">{channel.name} {channel.verified && <Check size={10} className="text-[var(--c1)]" />}</p>
          <p className="font-display text-[8px] text-[var(--tx-mute)]">{channel.handle} · {compactNumber(channel.followers, lang)} {t("followers")} · {videos.length} {t("videosCount")}</p>
        </div>
        <button type="button" onClick={() => toggleFollow(channel.id)} className={cn("press rounded-full px-3 py-1.5 text-[8.5px] font-medium", following.includes(channel.id) ? "border border-[var(--line)] bg-[var(--surface-alt)] text-[var(--tx-dim)]" : "btn-primary")}>
          {following.includes(channel.id) ? t("unfollow") : t("follow")}
        </button>
      </div>
      <p className="mt-2 text-[9px] text-[var(--tx-mute)]">{channel.about}</p>
      <div className="mt-3 space-y-2">
        {videos.map((video) => (
          <VideoRow key={video.id} video={video} onOpen={onOpen} onMenu={() => onOpen(video.id)} progress={0} />
        ))}
      </div>
    </div>
  );
}

function ShortsRail({ videos }: { videos: TubeVideo[] }) {
  const { lang, t, likes, toggleLike, following, toggleFollow, enqueue, copy, play } = useDon();
  const [index, setIndex] = useState(0);
  const railRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const node = railRef.current;
    if (!node) return;
    const onScroll = () => {
      const next = Math.round(node.scrollTop / Math.max(1, node.clientHeight));
      setIndex(Math.max(0, Math.min(videos.length - 1, next)));
    };
    node.addEventListener("scroll", onScroll, { passive: true });
    return () => node.removeEventListener("scroll", onScroll);
  }, [videos.length]);

  const video = videos[index];
  if (!video) return null;
  const channel = channelById(video.channelId);

  return (
    <div className="pb-2">
      <div ref={railRef} className="snap-y-mandatory no-bar h-[470px] overflow-y-auto rounded-[20px] border border-[var(--line)] bg-black">
        {videos.map((item) => (
          <div key={item.id} className="snap-start-item relative h-[470px] w-full">
            <video src={item.src} poster={item.poster} autoPlay muted loop playsInline className="h-full w-full object-cover" />
            <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/35" />
            <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-2 p-3">
              <div className="min-w-0 flex-1">
                <p className="line-clamp-2 text-[11px] font-medium text-white">{item.title}</p>
                <p className="mt-1 flex items-center gap-1 text-[8px] text-white/70">
                  <Avatar name={channel.initial} color={channel.color} size={16} /> {channel.handle} · {compactNumber(item.views, lang)} {t("views")}
                </p>
                <p className="mt-1 font-display text-[7px] text-white/50" dir="ltr">{item.quality}</p>
              </div>
              <div className="flex shrink-0 flex-col gap-1.5">
                {[
                  { icon: Heart, active: likes.includes(item.id), action: () => toggleLike(item.id), label: "like" },
                  { icon: Bell, active: following.includes(item.channelId), action: () => toggleFollow(item.channelId), label: "follow" },
                  { icon: Download, active: false, action: () => void enqueue(item.src, { title: item.title, kind: "video", poster: item.poster }), label: "download" },
                  { icon: Copy, active: false, action: () => void copy(item.src, item.title), label: "copy" },
                  { icon: Tv, active: false, action: () => play({ src: item.src, title: item.title, poster: item.poster, kind: item.kind === "music" ? "audio" : "video", videoId: item.id, vertical: true, remote: true }), label: "player" },
                ].map((action) => (
                  <button key={action.label} type="button" aria-label={action.label} onClick={action.action} className={cn("press grid h-9 w-9 place-items-center rounded-full border backdrop-blur-md", action.active ? "border-white/40 bg-white/25 text-white" : "border-white/20 bg-black/40 text-white/85")}>
                    <action.icon size={15} fill={action.active ? "currentColor" : "none"} />
                  </button>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-2 flex items-center justify-center gap-1">
        {videos.map((item, itemIndex) => (
          <span key={item.id} className={cn("h-1 rounded-full transition-all", itemIndex === index ? "w-5 bg-[var(--c2)]" : "w-1.5 bg-white/20")} />
        ))}
      </div>
    </div>
  );
}

function ProfileView() {
  const { lang, t, profile, updateProfile, exportProfile, importProfile, following, toggleFollow, history, clearHistory, likes, saved, library, tasks, storage, notify, theme } = useDon();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(profile);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const downloadedBytes = tasks.filter((task) => task.status === "done").reduce((sum, task) => sum + (task.total || task.received), 0);
  const localBytes = library.reduce((sum, item) => sum + item.size, 0);

  return (
    <div className="pb-3">
      <Card glow className="p-3">
        <div className="absolute -left-10 -top-12 h-32 w-32 rounded-full blur-3xl" style={{ background: `rgba(var(--glow2),0.25)` }} />
        <div className="relative flex items-center gap-3">
          <Avatar name={profile.name} color={profile.color} size={52} />
          <div className="min-w-0 flex-1">
            <p className="truncate text-[14px] font-semibold text-[var(--tx)]">{profile.name}</p>
            <p className="font-display text-[8.5px] text-[var(--tx-mute)]" dir="ltr">{profile.handle}</p>
            <p className="mt-1 line-clamp-2 text-[8.5px] leading-4 text-[var(--tx-dim)]">{profile.bio}</p>
          </div>
          <button type="button" onClick={() => { setDraft(profile); setEditing(true); }} className="press grid h-8 w-8 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-alt)] text-[var(--tx-dim)]">
            <Settings2 size={13} />
          </button>
        </div>
        <div className="relative mt-2.5 grid grid-cols-4 gap-1.5">
          {[
            { value: history.length, label: lang === "ar" ? "شوهد" : "watched" },
            { value: likes.length, label: lang === "ar" ? "إعجاب" : "likes" },
            { value: saved.length, label: lang === "ar" ? "لاحقًا" : "later" },
            { value: following.length, label: lang === "ar" ? "متابعة" : "follows" },
          ].map((stat) => (
            <div key={stat.label} className="rounded-[11px] border border-[var(--line)] bg-black/20 py-1.5 text-center">
              <p className="font-display text-[13px] font-semibold text-[var(--tx)]">{stat.value}</p>
              <p className="text-[6.5px] text-[var(--tx-mute)]">{stat.label}</p>
            </div>
          ))}
        </div>
        <div className="relative mt-2 rounded-[11px] border border-[var(--line)] bg-black/20 p-2">
          <div className="flex items-center justify-between text-[8px] text-[var(--tx-dim)]">
            <span>{t("storage")}</span>
            <span className="font-display tabular-nums" dir="ltr">{formatBytes(storage.usage)} / {storage.quota ? formatBytes(storage.quota) : "—"}</span>
          </div>
          <div className="mt-1.5"><Bar value={storage.quota ? (storage.usage / storage.quota) * 100 : 0} height={3} /></div>
          <div className="mt-1.5 flex items-center justify-between text-[7px] text-[var(--tx-mute)]">
            <span>{lang === "ar" ? "ملفات محلية" : "local files"}: {library.length} · {formatBytes(localBytes)}</span>
            <span>{lang === "ar" ? "مُحمّل" : "downloaded"}: {formatBytes(downloadedBytes)}</span>
          </div>
        </div>
      </Card>

      <div className="mt-2 grid grid-cols-2 gap-1.5">
        <button type="button" onClick={exportProfile} className="press flex items-center justify-center gap-1.5 rounded-[13px] border border-[var(--line)] bg-[var(--surface-alt)] py-2.5 text-[9px] text-[var(--tx-dim)]">
          <Download size={12} /> {t("exportProfile")}
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="application/json,.json"
          className="hidden"
          onChange={async (event) => {
            const file = event.target.files?.[0];
            if (file) await importProfile(file);
            event.target.value = "";
          }}
        />
        <button type="button" onClick={() => fileRef.current?.click()} className="press flex items-center justify-center gap-1.5 rounded-[13px] border border-[var(--line)] bg-[var(--surface-alt)] py-2.5 text-[9px] text-[var(--tx-dim)]">
          <Plus size={12} /> {t("importProfile")}
        </button>
      </div>

      <p className="mb-1.5 mt-3 text-[10px] font-semibold text-[var(--tx)]">{lang === "ar" ? "قنواتك المحلية" : "Your local channels"}</p>
      <div className="space-y-1.5">
        {CHANNELS.map((channel) => {
          const isFollowing = following.includes(channel.id);
          return (
            <div key={channel.id} className="flex items-center gap-2 rounded-[13px] border border-[var(--line)] bg-[var(--surface-alt)] p-2">
              <Avatar name={channel.initial} color={channel.color} size={28} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[9.5px] text-[var(--tx)]">{channel.name}</p>
                <p className="font-display text-[7px] text-[var(--tx-mute)]">{compactNumber(channel.followers, lang)} {t("followers")}</p>
              </div>
              <button type="button" onClick={() => toggleFollow(channel.id)} className={cn("press rounded-full px-2.5 py-1 text-[8px]", isFollowing ? "border border-[var(--line)] bg-[var(--surface)] text-[var(--tx-dim)]" : "btn-primary")}>
                {isFollowing ? t("unfollow") : t("follow")}
              </button>
            </div>
          );
        })}
      </div>

      <p className="mb-1.5 mt-3 flex items-center justify-between text-[10px] font-semibold text-[var(--tx)]">
        <span className="flex items-center gap-1.5"><History size={11} /> {t("history")}</span>
        {history.length > 0 && (
          <button type="button" onClick={() => { clearHistory(); notify(lang === "ar" ? "مُسح السجل المحلي" : "Local history cleared", "ok"); }} className="press flex items-center gap-1 text-[8px] font-normal text-[var(--tx-mute)]">
            <Trash2 size={10} /> {t("clearHistory")}
          </button>
        )}
      </p>
      {history.length ? (
        <div className="space-y-1.5">
          {history.slice(0, 8).map((entry) => {
            const video = CATALOG.find((item) => item.id === entry.videoId);
            if (!video) return null;
            return (
              <div key={`${entry.videoId}-${entry.at}`} className="flex items-center gap-2 rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] p-1.5">
                <img src={video.poster} alt="" className="h-9 w-14 shrink-0 rounded-[7px] object-cover" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[9px] text-[var(--tx)]">{video.title}</p>
                  <p className="font-display text-[7px] text-[var(--tx-mute)]" dir="ltr">{Math.round(entry.progress * 100)}% · {new Date(entry.at).toLocaleTimeString()}</p>
                </div>
                <Badge tone="#8db8ff"><ImageIcon size={8} /> {video.kind}</Badge>
              </div>
            );
          })}
        </div>
      ) : (
        <Card><Empty title={lang === "ar" ? "السجل فارغ" : "History is empty"} hint={lang === "ar" ? "شغّل أي فيديو ليُسجَّل محليًا" : "Play any video to record it locally"} icon={<Video size={22} />} /></Card>
      )}

      <p className="mt-3 text-center text-[7px] text-[var(--tx-mute)]">
        {t("localOnly")} · theme {theme.id} · {springLabel(theme.stiffness, theme.damping)}
      </p>

      <Sheet open={editing} onClose={() => setEditing(false)} title={t("profile")} subtitle={lang === "ar" ? "محلي تمامًا — لا حساب ولا خادم" : "Fully local — no account, no server"}>
        <div className="space-y-2 pb-2">
          {([
            { key: "name" as const, label: t("name") },
            { key: "handle" as const, label: t("handle") },
            { key: "bio" as const, label: t("bio") },
          ]).map((field) => (
            <label key={field.key} className="block">
              <span className="mb-1 block text-[8px] text-[var(--tx-mute)]">{field.label}</span>
              <input
                value={draft[field.key]}
                onChange={(event) => setDraft({ ...draft, [field.key]: event.target.value })}
                dir={field.key === "handle" ? "ltr" : undefined}
                className="w-full rounded-[11px] border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-2 text-[10px] text-[var(--tx)] outline-none"
              />
            </label>
          ))}
          <div>
            <span className="mb-1 block text-[8px] text-[var(--tx-mute)]">{lang === "ar" ? "لون الهوية" : "Identity color"}</span>
            <div className="flex gap-1.5">
              {["#9B72CB", "#4285F4", "#34d399", "#f472b6", "#fb923c", "#22d3ee", "#a855f7", "#f43f5e"].map((color) => (
                <button key={color} type="button" onClick={() => setDraft({ ...draft, color })} className={cn("press h-7 w-7 rounded-full border-2", draft.color === color ? "border-white" : "border-transparent")} style={{ background: color }} aria-label={color} />
              ))}
            </div>
          </div>
          <button type="button" onClick={() => { updateProfile(draft); setEditing(false); notify(t("savedOk"), "ok"); }} className="press btn-primary w-full rounded-[12px] py-2.5 text-[10px] font-semibold">
            {t("save")}
          </button>
        </div>
      </Sheet>
    </div>
  );
}

function springLabel(stiffness: number, damping: number) {
  return `spring ${stiffness}/${damping}`;
}

function formatClock(seconds: number) {
  if (!Number.isFinite(seconds)) return "0:00";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}
