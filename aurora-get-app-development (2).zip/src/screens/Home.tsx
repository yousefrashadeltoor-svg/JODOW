import { useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowDownToLine,
  Check,
  ClipboardPaste,
  FileUp,
  FolderOpen,
  Globe2,
  Info,
  Link2,
  Loader2,
  Music2,
  Play,
  ScanLine,
  Search,
  ShieldCheck,
  Sparkles,
  Video,
  X,
  Zap,
} from "lucide-react";
import { useDon } from "../don/store";
import { formatBytes, formatDuration, formatSpeed, youtubeThumb } from "../don/core";
import { readClipboard } from "../don/media";
import { Badge, Bar, Card, Empty, IconButton, SectionTitle, useSpring } from "../components/ui";
import { cn } from "../utils/cn";

const KIND_ICON = { video: Video, audio: Music2, image: FolderOpen, file: FileUp };

export function HomeScreen() {
  const { t, lang, analysis, analyzing, analyze, enqueue, copy, play, tasks, library, libraryUrls, notify, setScreen, theme, addLocalFiles } = useDon();
  const [url, setUrl] = useState("");
  const [picked, setPicked] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const spring = useSpring();

  const stageTone = (status: string) =>
    status === "done" ? "#67e8c7" : status === "running" ? "var(--c1)" : status === "error" ? "#ff9d9d" : "var(--tx-mute)";

  const groups = (analysis?.candidates || []).reduce<Record<string, number>>((acc, item) => {
    acc[item.kind] = (acc[item.kind] || 0) + 1;
    return acc;
  }, {});

  const active = tasks.filter((task) => task.status === "active" || task.status === "queued");

  return (
    <div className="pb-4">
      <header className="flex items-center justify-between px-4 pb-1 pt-1">
        <div className="flex items-center gap-2">
          <span className="relative grid h-9 w-9 place-items-center rounded-[13px]" style={{ background: "linear-gradient(140deg, var(--c1), var(--c2) 55%, var(--c3))" }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M7 4h6.2c3.4 0 5.8 2.3 5.8 5.7v4.6c0 3.4-2.4 5.7-5.8 5.7H7V4Zm3 2.6v8.8h3c1.8 0 3-1.2 3-3V9.6c0-1.8-1.2-3-3-3h-3Z" fill="white" fillOpacity=".96" />
            </svg>
            <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full border-2 border-[var(--bg)] bg-[#67e8c7]" />
          </span>
          <div>
            <p className="text-[15px] font-semibold leading-tight tracking-tight text-[var(--tx)]">DON</p>
            <p className="text-[7.5px] tracking-[0.1em] text-[var(--tx-mute)]">{t("localOnly")}</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <IconButton label={t("tube")} size="sm" onClick={() => setScreen("tube")}>
            <Play size={13} />
          </IconButton>
          <IconButton label={t("browser")} size="sm" onClick={() => setScreen("browser")}>
            <Globe2 size={13} />
          </IconButton>
          <IconButton label={lang === "ar" ? "مسح QR" : "Scan QR"} size="sm" onClick={() => notify(lang === "ar" ? "الماسح يعمل في بناء Android (ML Kit)" : "Scanner runs in the Android build (ML Kit)", "warn")}>
            <ScanLine size={13} />
          </IconButton>
        </div>
      </header>

      <div className="px-4">
        {/* link field */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={spring} className={cn("relative mt-2 overflow-hidden rounded-[22px] p-2.5", analyzing ? "ring-live" : "")}>
          <div className="noise specular absolute inset-0 rounded-[22px] glass" />
          <div className="relative flex items-center gap-2 rounded-[15px] border border-[var(--line)] bg-black/25 px-2.5 py-2">
            <Link2 size={14} className="shrink-0 text-[var(--tx-mute)]" />
            <input
              dir="ltr"
              value={url}
              onChange={(event) => setUrl(event.target.value)}
              onKeyDown={(event) => { if (event.key === "Enter") void analyze(url); }}
              placeholder={t("pasteLink")}
              className="min-w-0 flex-1 bg-transparent text-left text-[10px] text-[var(--tx)] outline-none placeholder:text-right placeholder:text-[var(--tx-mute)]"
            />
            {url ? (
              <button type="button" aria-label="clear" onClick={() => setUrl("")} className="text-[var(--tx-mute)]">
                <X size={13} />
              </button>
            ) : (
              <button
                type="button"
                onClick={async () => {
                  const text = await readClipboard();
                  if (text) {
                    setUrl(text);
                    void analyze(text);
                  } else {
                    notify(lang === "ar" ? "الحافظة فارغة أو الإذن مرفوض" : "Clipboard empty or permission denied", "warn");
                  }
                }}
                className="press flex items-center gap-1 rounded-full border border-[var(--line)] bg-[var(--surface-alt)] px-2 py-[3px] text-[8px] text-[var(--tx-dim)]"
              >
                <ClipboardPaste size={10} /> {t("paste")}
              </button>
            )}
          </div>
          <div className="relative mt-2 flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => void analyze(url)}
              disabled={analyzing || !url.trim()}
              className="press btn-primary flex h-[34px] flex-1 items-center justify-center gap-1.5 rounded-[12px] text-[10px] font-semibold"
            >
              {analyzing ? <Loader2 size={13} className="animate-spin" /> : <Zap size={13} />}
              {analyzing ? t("analyze") : t("analyze")}
            </button>
            <input
              ref={fileRef}
              type="file"
              multiple
              accept="video/*,audio/*,image/*,.pdf,.zip,.json,.srt"
              className="hidden"
              onChange={async (event) => {
                const files = event.target.files;
                if (!files?.length) return;
                setPicked(true);
                await addLocalFiles(files);
                event.target.value = "";
              }}
            />
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="press flex h-[34px] items-center gap-1.5 rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] px-3 text-[9px] text-[var(--tx-dim)]"
            >
              <FileUp size={12} /> {t("pickFile")}
            </button>
          </div>
          {picked && (
            <p className="relative mt-1.5 flex items-center gap-1 text-[7.5px] text-[#67e8c7]">
              <Check size={9} /> {lang === "ar" ? "الملفات محفوظة محليًا وتعمل دون اتصال" : "Files stored locally and work offline"}
            </p>
          )}
        </motion.div>

        {/* active tasks */}
        {active.length > 0 && (
          <div className="mt-2 space-y-1.5">
            {active.slice(0, 2).map((task) => {
              const percent = task.total ? (task.received / task.total) * 100 : 0;
              return (
                <Card key={task.id} className="p-2.5">
                  <div className="flex items-center gap-2">
                    <span className="grid h-8 w-8 place-items-center rounded-[10px] border border-[var(--line)] bg-black/25 text-[var(--c1)]">
                      {task.status === "active" ? <ArrowDownToLine size={14} /> : <Loader2 size={14} className="animate-spin" />}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[9.5px] text-[var(--tx)]">{task.title}</p>
                      <div className="mt-1"><Bar value={percent} height={3} /></div>
                      <div className="mt-1 flex items-center justify-between font-display text-[7.5px] tabular-nums text-[var(--tx-mute)]">
                        <span dir="ltr">{formatBytes(task.received)} / {task.total ? formatBytes(task.total) : "?"}</span>
                        <span dir="ltr">{formatSpeed(task.speed)}</span>
                      </div>
                    </div>
                    <button type="button" onClick={() => setScreen("downloads")} className="press text-[8px] text-[var(--c2)]">{t("queue")}</button>
                  </div>
                </Card>
              );
            })}
          </div>
        )}

        {/* stages */}
        <AnimatePresence>
          {(analyzing || analysis) && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
              <SectionTitle action={<Badge>{t("realEngine")}</Badge>}>{t("stages")}</SectionTitle>
              <Card className="p-2.5">
                <div className="space-y-1.5">
                  {(analysis?.stages || []).map((stage) => (
                    <div key={stage.key} className="flex items-center gap-2">
                      <span className="grid h-4 w-4 place-items-center rounded-full border" style={{ borderColor: `${stageTone(stage.status)}55`, color: stageTone(stage.status) }}>
                        {stage.status === "done" ? <Check size={9} /> : stage.status === "running" ? <Loader2 size={8} className="animate-spin" /> : stage.status === "error" ? <X size={8} /> : <span className="h-1 w-1 rounded-full bg-current" />}
                      </span>
                      <span className="flex-1 text-[9px] text-[var(--tx-dim)]">{t(stage.key)}</span>
                      {stage.detail && <span className="max-w-[130px] truncate font-display text-[7px] text-[var(--tx-mute)]" dir="ltr">{stage.detail}</span>}
                      {typeof stage.ms === "number" && <span className="font-display text-[7px] tabular-nums text-[var(--tx-mute)]">{stage.ms}ms</span>}
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* result */}
        <AnimatePresence mode="wait">
          {analysis && !analyzing && (
            <motion.div key={analysis.url} initial={{ opacity: 0, y: 14, filter: "blur(6px)" }} animate={{ opacity: 1, y: 0, filter: "blur(0px)" }} exit={{ opacity: 0 }} transition={spring}>
              <SectionTitle
                action={
                  <div className="flex gap-1">
                    {Object.entries(groups).map(([kind, count]) => {
                      const Icon = KIND_ICON[kind as keyof typeof KIND_ICON];
                      return (
                        <Badge key={kind}>
                          <Icon size={9} /> {count}
                        </Badge>
                      );
                    })}
                  </div>
                }
              >
                {analysis.host}
              </SectionTitle>

              <Card glow className="p-3">
                <div className="flex items-start gap-2.5">
                  {analysis.poster ? (
                    <img src={analysis.poster} alt="" className="h-16 w-24 shrink-0 rounded-[12px] border border-[var(--line)] object-cover" onError={(event) => { (event.currentTarget as HTMLImageElement).style.display = "none"; }} />
                  ) : (
                    <span className="grid h-16 w-24 shrink-0 place-items-center rounded-[12px] border border-[var(--line)] bg-black/25 text-[var(--tx-mute)]">
                      <Globe2 size={18} />
                    </span>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="line-clamp-2 text-[11px] font-medium leading-5 text-[var(--tx)]">{analysis.title || analysis.url}</p>
                    <p className="mt-1 truncate font-display text-[8px] text-[var(--tx-mute)]" dir="ltr">{analysis.url}</p>
                    <div className="mt-1.5 flex flex-wrap gap-1">
                      <Badge tone="#8db8ff">{analysis.provider}</Badge>
                      {analysis.contentType && <Badge>{analysis.contentType.split(";")[0]}</Badge>}
                      {analysis.size ? <Badge tone="#67e8c7"><Check size={8} /> {formatBytes(analysis.size)}</Badge> : <Badge tone="#f5ce8a">{lang === "ar" ? "الحجم غير مُعلن" : "size not advertised"}</Badge>}
                      <Badge tone={analysis.rangeSupported ? "#67e8c7" : "#ff9d9d"}>{analysis.rangeSupported ? t("resumeSupport") : t("noResume")}</Badge>
                    </div>
                  </div>
                </div>

                {analysis.description && <p className="mt-2 line-clamp-2 text-[8.5px] leading-4 text-[var(--tx-mute)]">{analysis.description}</p>}

                {analysis.youtubeId && (
                  <div className="mt-2 flex items-start gap-2 rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] p-2">
                    <Info size={12} className="mt-0.5 shrink-0 text-[var(--c1)]" />
                    <div className="min-w-0 flex-1">
                      <p className="text-[8.5px] leading-4 text-[var(--tx-dim)]">
                        {lang === "ar"
                          ? "استخراج مسارات يوتيوب يتم عبر محرك yt-dlp الأصلي داخل بناء Android (مجلد JP PROJ). هنا يعمل التحليل الحقيقي للترويسات والمستند."
                          : "YouTube stream extraction runs through the native yt-dlp engine in the Android build (JP PROJ). Header and document analysis here are real."}
                      </p>
                      <div className="mt-1.5 flex flex-wrap gap-1">
                        <button type="button" onClick={() => void copy(`https://youtu.be/${analysis.youtubeId}`, "YouTube")} className="press rounded-[7px] border border-[var(--line)] bg-black/20 px-2 py-1 text-[7.5px] text-[var(--tx-dim)]">
                          {t("copyLink")}
                        </button>
                        <button type="button" onClick={() => play({ src: youtubeThumb(analysis.youtubeId as string), title: analysis.youtubeId as string, kind: "image", remote: true })} className="press flex items-center gap-1 rounded-[7px] border border-[var(--line)] bg-black/20 px-2 py-1 text-[7.5px] text-[var(--tx-dim)]">
                          <Play size={8} /> {lang === "ar" ? "عرض الغلاف" : "View thumbnail"}
                        </button>
                        <button type="button" onClick={() => setScreen("tube")} className="press flex items-center gap-1 rounded-[7px] border border-[rgba(var(--glow),0.4)] bg-[rgba(var(--glow),0.12)] px-2 py-1 text-[7.5px] text-[var(--c1)]">
                          <Sparkles size={8} /> DON Tube
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* candidates */}
                <div className="mt-2.5 space-y-1.5">
                  {analysis.candidates.length ? (
                    analysis.candidates.map((candidate) => {
                      const Icon = KIND_ICON[candidate.kind];
                      return (
                        <div key={candidate.url} className="flex items-center gap-2 rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] p-2">
                          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-[10px] border border-[var(--line)] bg-black/25 text-[var(--c2)]">
                            <Icon size={13} />
                          </span>
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-[9px] text-[var(--tx)]">{candidate.label}</p>
                            <p className="font-display text-[7.5px] text-[var(--tx-mute)]" dir="ltr">
                              {candidate.kind} · {candidate.size ? formatBytes(candidate.size) : "HEAD required"}
                            </p>
                          </div>
                          <button type="button" onClick={() => play({ src: candidate.url, title: candidate.label, kind: candidate.kind, remote: true })} className="press grid h-7 w-7 place-items-center rounded-full border border-[var(--line)] bg-black/25 text-[var(--tx-dim)]">
                            <Play size={11} />
                          </button>
                          <button type="button" onClick={() => void enqueue(candidate.url, { title: candidate.label, kind: candidate.kind, poster: analysis.poster })} className="press btn-primary flex h-7 items-center gap-1 rounded-full px-2.5 text-[8px] font-medium">
                            <ArrowDownToLine size={10} /> {t("download")}
                          </button>
                        </div>
                      );
                    })
                  ) : (
                    <div className="flex items-start gap-2 rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] p-2.5">
                      <ShieldCheck size={12} className="mt-0.5 shrink-0 text-[#f5ce8a]" />
                      <p className="text-[8.5px] leading-4 text-[var(--tx-dim)]">
                        {lang === "ar"
                          ? "لم يُعثر على وسائط مباشرة داخل المستند (قد يكون محميًا بـ CORS أو يتطلب محرك الاستخراج الأصلي). جرّب المتصفح الداخلي لاصطياد الطلبات."
                          : "No direct media found in the document (it may be CORS-protected or need the native extractor). Try the in-app browser sniffer."}
                      </p>
                      <button type="button" onClick={() => setScreen("browser")} className="press shrink-0 rounded-[7px] border border-[var(--line)] px-2 py-1 text-[7.5px] text-[var(--tx-dim)]">
                        {t("browser")}
                      </button>
                    </div>
                  )}
                </div>

                {analysis.error && <p className="mt-2 text-[8px] text-[#ff9d9d]">{analysis.error}</p>}
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* library + tasks preview */}
        <SectionTitle action={<button type="button" onClick={() => setScreen("files")} className="press text-[9px] text-[var(--c2)]">{t("files")}</button>}>
          {lang === "ar" ? "أحدث ما في مكتبتك" : "Latest in your library"}
        </SectionTitle>
        {library.length ? (
          <div className="space-y-1.5">
            {library.slice(0, 3).map((item) => {
              const Icon = KIND_ICON[item.kind];
              const src = libraryUrls[item.id];
              return (
                <Card key={item.id} className="flex items-center gap-2.5 p-2.5">
                  <span className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-[12px] border border-[var(--line)] bg-black/25">
                    {item.kind === "image" && src ? <img src={src} alt="" className="h-full w-full object-cover" /> : <Icon size={15} className="text-[var(--c2)]" />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[10px] text-[var(--tx)]">{item.title}</p>
                    <p className="font-display text-[7.5px] text-[var(--tx-mute)]" dir="ltr">
                      {formatBytes(item.size)} · {item.origin}
                      {item.duration ? ` · ${formatDuration(item.duration)}` : ""}
                    </p>
                  </div>
                  {src && (item.kind === "video" || item.kind === "audio") && (
                    <button type="button" onClick={() => play({ src, title: item.title, kind: item.kind, libraryId: item.id, poster: item.poster })} className="press grid h-8 w-8 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-alt)] text-[var(--tx)]">
                      <Play size={12} fill="currentColor" />
                    </button>
                  )}
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <Empty title={t("noItems")} hint={t("noItemsHint")} icon={<Search size={22} />} />
          </Card>
        )}

        <p className="mt-3 flex items-center justify-center gap-1.5 text-[7.5px] text-[var(--tx-mute)]">
          <ShieldCheck size={9} /> {t("copyright")}
        </p>
        <p className="mt-1 text-center font-display text-[7px] text-[var(--tx-mute)]" style={{ color: `color-mix(in srgb, var(--tx-mute) 70%, transparent)` }}>
          theme: {theme.id} · {theme.mode} · radius {theme.radius} · blur {theme.blur}
        </p>
      </div>

    </div>
  );

}
