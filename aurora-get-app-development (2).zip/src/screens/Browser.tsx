import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowDownToLine,
  Check,
  ExternalLink,
  Globe2,
  Loader2,
  Lock,
  Music2,
  Play,
  Radar,
  RefreshCw,
  ShieldCheck,
  TriangleAlert,
  Video,
  X,
} from "lucide-react";
import { useDon } from "../don/store";
import { formatBytes, parseLink } from "../don/core";
import { probeRemote, readPageMeta, type PageMeta, type ProbeResult } from "../don/media";
import { Badge, Bar, Card, Empty, Header, IconButton } from "../components/ui";

const HISTORY_KEY = "don.browser.history";

interface Found {
  url: string;
  kind: "video" | "audio";
  probe?: ProbeResult;
}

function loadHistory(): string[] {
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]") as string[];
  } catch {
    return [];
  }
}

export function BrowserScreen() {
  const { t, lang, enqueue, play, notify, copy } = useDon();
  const [url, setUrl] = useState("https://videos.pexels.com/video-files/39924448/17034603_3840_2160_30fps.mp4");
  const [committed, setCommitted] = useState(url);
  const [status, setStatus] = useState<"idle" | "loading" | "loaded" | "blocked">("loading");
  const [history, setHistory] = useState<string[]>(() => loadHistory());
  const [sniffing, setSniffing] = useState(false);
  const [found, setFound] = useState<Found[]>([]);
  const [meta, setMeta] = useState<PageMeta | null>(null);
  const [sniffError, setSniffError] = useState<string | null>(null);
  const frameRef = useRef<HTMLIFrameElement | null>(null);
  const timeoutRef = useRef<number | null>(null);

  const parsed = parseLink(committed);
  const isDirectMedia = !!parsed?.isMedia;

  const pushHistory = (value: string) => {
    setHistory((prev) => {
      const next = [value, ...prev.filter((item) => item !== value)].slice(0, 12);
      try {
        localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
      } catch {
        /* storage full */
      }
      return next;
    });
  };

  const navigate = (value: string) => {
    const target = value.trim();
    if (!target) return;
    const normalized = parseLink(target);
    if (!normalized) {
      notify(lang === "ar" ? "رابط غير صالح" : "Invalid URL", "error");
      return;
    }
    setUrl(normalized.raw);
    setCommitted(normalized.raw);
    setStatus("loading");
    setFound([]);
    setMeta(null);
    setSniffError(null);
    pushHistory(normalized.raw);
    if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
    timeoutRef.current = window.setTimeout(() => {
      setStatus((current) => (current === "loading" ? "blocked" : current));
    }, 7000);
  };

  useEffect(() => () => { if (timeoutRef.current) window.clearTimeout(timeoutRef.current); }, []);

  const sniff = async () => {
    if (!parsed) return;
    setSniffing(true);
    setSniffError(null);
    const results: Found[] = [];
    if (parsed.isMedia && (parsed.mediaType === "video" || parsed.mediaType === "audio")) {
      results.push({ url: parsed.raw, kind: parsed.mediaType });
    }
    const page = await readPageMeta(parsed.raw);
    setMeta(page);
    page.videos.forEach((src) => results.push({ url: src, kind: "video" }));
    page.audios.forEach((src) => results.push({ url: src, kind: "audio" }));
    const unique = results.filter((item, index, list) => list.findIndex((other) => other.url === item.url) === index);
    const probed = await Promise.all(
      unique.slice(0, 8).map(async (item) => ({ ...item, probe: await probeRemote(item.url) })),
    );
    setFound(probed);
    setSniffing(false);
    if (!probed.length) setSniffError(page.error || (lang === "ar" ? "لم يُعثر على وسائط" : "No media found"));
  };

  return (
    <div className="flex min-h-[640px] flex-col pb-[76px]">
      <Header
        title={t("browser")}
        subtitle={lang === "ar" ? "تنقّل حقيقي + اصطياد وسائط من الشبكة" : "Real navigation + network media sniffer"}
        right={
          <>
            <IconButton label={t("reload")} size="sm" onClick={() => navigate(committed)}>
              <RefreshCw size={13} className={status === "loading" ? "animate-spin" : ""} />
            </IconButton>
            <IconButton label={t("sniffer")} size="sm" active={sniffing} onClick={() => void sniff()}>
              <Radar size={13} />
            </IconButton>
          </>
        }
      />

      <div className="px-4">
        <div className="flex items-center gap-1.5 rounded-[14px] border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-1.5">
          {status === "loaded" || isDirectMedia ? <Lock size={11} className="shrink-0 text-[#67e8c7]" /> : <Globe2 size={11} className="shrink-0 text-[var(--tx-mute)]" />}
          <input
            dir="ltr"
            value={url}
            onChange={(event) => setUrl(event.target.value)}
            onKeyDown={(event) => { if (event.key === "Enter") navigate(url); }}
            placeholder="https://"
            className="min-w-0 flex-1 bg-transparent text-left font-display text-[9px] text-[var(--tx)] outline-none placeholder:text-[var(--tx-mute)]"
          />
          {status === "loading" && <Loader2 size={11} className="animate-spin text-[var(--c1)]" />}
          <button type="button" onClick={() => navigate(url)} className="press btn-primary rounded-[9px] px-2.5 py-1 text-[8.5px] font-medium">
            {lang === "ar" ? "انتقال" : "Go"}
          </button>
        </div>

        {status === "loading" && <div className="mt-1"><Bar value={70} height={2} /></div>}

        {/* history */}
        {history.length > 0 && (
          <div className="no-bar mt-2 flex gap-1.5 overflow-x-auto pb-1">
            {history.slice(0, 6).map((item) => (
              <button key={item} type="button" onClick={() => navigate(item)} className="press flex shrink-0 items-center gap-1 rounded-full border border-[var(--line)] bg-[var(--surface-alt)] px-2 py-1 text-[7.5px] text-[var(--tx-mute)]">
                <Globe2 size={8} />
                <span className="max-w-[110px] truncate font-display" dir="ltr">{item.replace(/^https?:\/\//, "")}</span>
              </button>
            ))}
            <button type="button" onClick={() => { setHistory([]); localStorage.removeItem(HISTORY_KEY); }} className="press shrink-0 rounded-full border border-[var(--line)] px-2 py-1 text-[7.5px] text-[var(--tx-mute)]">
              <X size={8} />
            </button>
          </div>
        )}

        {/* viewport */}
        <div className="relative mt-2 overflow-hidden rounded-[18px] border border-[var(--line)] bg-black/60">
          {isDirectMedia && parsed?.mediaType === "video" ? (
            <video src={committed} controls playsInline className="h-[230px] w-full bg-black object-contain" onLoadedData={() => setStatus("loaded")} />
          ) : isDirectMedia && parsed?.mediaType === "audio" ? (
            <div className="flex h-[230px] flex-col items-center justify-center gap-3 px-6">
              <span className="grid h-16 w-16 place-items-center rounded-[20px] border border-[var(--line)] bg-[var(--surface-alt)] text-[var(--c2)]"><Music2 size={26} /></span>
              <audio src={committed} controls className="w-full" onLoadedData={() => setStatus("loaded")} />
            </div>
          ) : isDirectMedia && parsed?.mediaType === "image" ? (
            <img src={committed} alt="" className="h-[230px] w-full object-contain" onLoad={() => setStatus("loaded")} onError={() => setStatus("blocked")} />
          ) : (
            <iframe
              key={committed}
              ref={frameRef}
              src={committed}
              title="DON browser"
              onLoad={() => setStatus("loaded")}
              onError={() => setStatus("blocked")}
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
              className="h-[230px] w-full border-0 bg-white"
            />
          )}

          <AnimatePresence>
            {status === "blocked" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 grid place-items-center bg-black/80 p-4 backdrop-blur-md">
                <div className="w-full rounded-[16px] border border-[var(--line)] bg-[var(--surface)] p-3 text-center">
                  <TriangleAlert size={20} className="mx-auto text-[#f5ce8a]" />
                  <p className="mt-2 text-[10px] font-medium text-[var(--tx)]">{t("blockedFrame")}</p>
                  <p className="mt-1 text-[8px] leading-4 text-[var(--tx-mute)]">
                    {lang === "ar"
                      ? "الموقع يرسل X-Frame-Options أو رفض الطلب. يمكنك اصطياد الوسائط أو فتحه خارجيًا."
                      : "The site sends X-Frame-Options or refused the request. Sniff its media or open it externally."}
                  </p>
                  <div className="mt-2 flex gap-1.5">
                    <button type="button" onClick={() => void sniff()} className="press btn-primary flex flex-1 items-center justify-center gap-1 rounded-[10px] py-2 text-[8.5px] font-medium">
                      <Radar size={11} /> {t("sniffer")}
                    </button>
                    <button type="button" onClick={() => window.open(committed, "_blank", "noopener")} className="press flex flex-1 items-center justify-center gap-1 rounded-[10px] border border-[var(--line)] bg-[var(--surface-alt)] py-2 text-[8.5px] text-[var(--tx-dim)]">
                      <ExternalLink size={11} /> {lang === "ar" ? "فتح خارجي" : "Open"}
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* actions */}
        <div className="mt-2 grid grid-cols-4 gap-1.5">
          {[
            { icon: Radar, label: t("sniffer"), action: () => void sniff(), busy: sniffing },
            { icon: ArrowDownToLine, label: t("download"), action: () => void enqueue(committed, { title: parsed?.host || "file" }) },
            { icon: Play, label: lang === "ar" ? "تشغيل" : "Play", action: () => play({ src: committed, title: parsed?.host || committed, kind: parsed?.mediaType || "video", remote: true }) },
            { icon: ExternalLink, label: lang === "ar" ? "نسخ" : "Copy", action: () => void copy(committed) },
          ].map((action) => (
            <button key={action.label} type="button" onClick={action.action} className="press flex flex-col items-center gap-1 rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] py-2 text-[7.5px] text-[var(--tx-dim)]">
              {action.busy ? <Loader2 size={12} className="animate-spin" /> : <action.icon size={12} />}
              {action.label}
            </button>
          ))}
        </div>

        {/* sniff results */}
        <div className="mt-3">
          <div className="mb-1.5 flex items-center justify-between">
            <p className="flex items-center gap-1.5 text-[10px] font-semibold text-[var(--tx)]">
              <Radar size={11} className="text-[var(--c2)]" /> {t("sniffer")}
            </p>
            {meta?.ok && <Badge tone="#67e8c7"><Check size={8} /> {meta.status}</Badge>}
          </div>

          {found.length ? (
            <div className="space-y-1.5">
              {found.map((item) => (
                <Card key={item.url} className="flex items-center gap-2 p-2">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-[10px] border border-[var(--line)] bg-black/25 text-[var(--c2)]">
                    {item.kind === "video" ? <Video size={14} /> : <Music2 size={14} />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-display text-[8.5px] text-[var(--tx)]" dir="ltr">{item.url.split("/").pop()?.slice(0, 42) || item.url}</p>
                    <p className="mt-0.5 flex flex-wrap items-center gap-1 text-[7px] text-[var(--tx-mute)]">
                      <span>{item.kind}</span>
                      {item.probe?.size ? <span dir="ltr">· {formatBytes(item.probe.size)}</span> : <span>· {lang === "ar" ? "الحجم غير مُعلن" : "size hidden"}</span>}
                      {item.probe?.contentType && <span dir="ltr">· {item.probe.contentType.split(";")[0]}</span>}
                      {item.probe?.rangeSupported && <Badge tone="#67e8c7">{t("resumeSupport")}</Badge>}
                      {item.probe && !item.probe.ok && <Badge tone="#ff9d9d">{item.probe.error?.slice(0, 24)}</Badge>}
                    </p>
                  </div>
                  <IconButton label="play" size="sm" onClick={() => play({ src: item.url, title: item.url, kind: item.kind, remote: true })}>
                    <Play size={11} />
                  </IconButton>
                  <button type="button" onClick={() => void enqueue(item.url, { title: item.url.split("/").pop() || "media", kind: item.kind })} className="press btn-primary flex h-7 items-center gap-1 rounded-full px-2.5 text-[8px] font-medium">
                    <ArrowDownToLine size={9} /> {t("download")}
                  </button>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <Empty
                title={sniffError ? (lang === "ar" ? "تعذّر الاصطياد" : "Sniffing blocked") : lang === "ar" ? "لا وسائط مكتشفة بعد" : "No media discovered yet"}
                hint={
                  sniffError
                    ? `${sniffError.slice(0, 90)} — ${lang === "ar" ? "المتصفح يمنع القراءة عبر النطاقات" : "the browser blocks cross-origin reads"}`
                    : lang === "ar"
                      ? "اضغط اصطياد لقراءة المستند واستخراج الوسائط الحقيقية"
                      : "Tap sniffer to read the document and extract real media"
                }
                icon={<Radar size={22} />}
              />
            </Card>
          )}
        </div>

        <div className="mt-3 flex items-start gap-2 rounded-[13px] border border-[var(--line)] bg-[var(--surface-alt)] p-2.5">
          <ShieldCheck size={12} className="mt-0.5 shrink-0 text-[#67e8c7]" />
          <p className="text-[7.5px] leading-4 text-[var(--tx-mute)]">
            {lang === "ar"
              ? "الاصطياد هنا حقيقي: جلب المستند، تحليل DOM، ثم قياس الحجم الفعلي لكل مصدر بطلبات HEAD/Range متوازية. لا تجاوز لـ DRM أو Paywall."
              : "Sniffing here is real: fetch the document, parse the DOM, then measure each source with parallel HEAD/Range requests. No DRM or paywall bypass."}
          </p>
        </div>
      </div>
    </div>
  );
}
