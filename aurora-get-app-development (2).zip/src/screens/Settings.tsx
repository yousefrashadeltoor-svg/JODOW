import { useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  BatteryCharging,
  Bell,
  Check,
  Database,
  Download,
  Eye,
  Gauge,
  Globe2,
  HardDrive,
  Image as ImageIcon,
  Languages,
  Moon,
  Play,
  Repeat,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Timer,
  Trash2,
  Upload,
  UserRound,
  Wifi,
  Zap,
} from "lucide-react";
import { useDon, type RepeatMode } from "../don/store";
import { THEMES, formatBytes } from "../don/core";
import { Avatar, Badge, Bar, Card, Header, Row, SectionTitle, Toggle } from "../components/ui";
import { cn } from "../utils/cn";

export function SettingsScreen() {
  const {
    t,
    lang,
    setLang,
    themeId,
    setThemeId,
    theme,
    settings,
    updateSettings,
    profile,
    exportProfile,
    importProfile,
    storage,
    refreshStorage,
    library,
    removeLibraryItem,
    history,
    clearHistory,
    tasks,
    notify,
  } = useDon();
  const [confirmClear, setConfirmClear] = useState(false);
  const importRef = useRef<HTMLInputElement | null>(null);

  const downloadedCount = tasks.filter((task) => task.status === "done").length;

  return (
    <div className="pb-6">
      <Header
        title={t("settings")}
        subtitle={lang === "ar" ? "كل إعداد يُطبَّق فورًا على التطبيق كله" : "Every setting applies instantly across the app"}
        right={
          <Badge tone="#67e8c7">
            <ShieldCheck size={8} /> {lang === "ar" ? "محلي" : "LOCAL"}
          </Badge>
        }
      />

      <div className="thin-bar max-h-[560px] space-y-1 overflow-y-auto px-4 pb-24">
        {/* themes */}
        <SectionTitle action={<Badge>{theme.mode === "dark" ? t("dark") : t("light")}</Badge>}>{t("theme")}</SectionTitle>
        <Card glow className="p-2.5">
          <p className="mb-2 text-[8.5px] leading-4 text-[var(--tx-mute)]">{t("themeHint")}</p>
          <div className="grid grid-cols-2 gap-2">
            {THEMES.map((item) => {
              const active = themeId === item.id;
              return (
                <motion.button
                  key={item.id}
                  type="button"
                  layout
                  onClick={() => {
                    setThemeId(item.id);
                    notify(`${lang === "ar" ? item.name.ar : item.name.en} · ${t("applyToAll")}`, "ok");
                  }}
                  whileTap={{ scale: 0.97 }}
                  className={cn("press relative overflow-hidden rounded-[15px] border text-right", active ? "border-white/40" : "border-[var(--line)]")}
                  style={active ? { boxShadow: `0 12px 34px -18px ${item.c2}` } : undefined}
                >
                  <span className="relative block h-[58px] w-full overflow-hidden">
                    <img src={item.thumb} alt={lang === "ar" ? item.name.ar : item.name.en} loading="lazy" className={cn("h-full w-full object-cover transition-transform duration-500", active ? "scale-105" : "scale-100 opacity-80")} />
                    <span className="absolute inset-0" style={{ background: `linear-gradient(140deg, ${item.c1}55, ${item.c2}33 55%, ${item.c3}44)` }} />
                    <span className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                    {active && (
                      <span className="absolute right-1.5 top-1.5 grid h-5 w-5 place-items-center rounded-full border border-white/40 bg-black/45 backdrop-blur-md">
                        <Check size={11} className="text-white" />
                      </span>
                    )}
                    <span className="absolute bottom-1.5 right-2 flex items-center gap-1">
                      {[item.c1, item.c2, item.c3].map((color) => (
                        <span key={color} className="h-2.5 w-2.5 rounded-full border border-white/25" style={{ background: color }} />
                      ))}
                    </span>
                  </span>
                  <span className="flex items-center justify-between px-2 py-1.5" style={{ background: item.bg }}>
                    <span className="text-[9px] font-medium" style={{ color: item.text }}>{lang === "ar" ? item.name.ar : item.name.en}</span>
                    <span className="font-display text-[6.5px]" style={{ color: item.textMute }}>
                      r{item.radius} · b{item.blur} · {item.mode}
                    </span>
                  </span>
                </motion.button>
              );
            })}
          </div>

          <div className="mt-2.5 rounded-[13px] border border-[var(--line)] bg-black/20 p-2.5">
            <div className="flex items-center justify-between">
              <p className="flex items-center gap-1.5 text-[9px] font-medium text-[var(--tx)]"><SlidersHorizontal size={11} className="text-[var(--c2)]" /> {lang === "ar" ? "قيم الثيم الحالية" : "Active theme values"}</p>
              <Badge tone={theme.mode === "dark" ? "#8db8ff" : "#f5ce8a"}>{theme.mode}</Badge>
            </div>
            <div className="mt-2 space-y-1.5">
              {[
                { label: t("radiusLabel"), value: theme.radius, max: 32, unit: "px" },
                { label: t("blurLabel"), value: theme.blur, max: 32, unit: "px" },
                { label: t("grainLabel"), value: Math.round(theme.grain * 100), max: 100, unit: "%" },
                { label: t("motion"), value: theme.stiffness, max: 460, unit: `/${theme.damping}` },
              ].map((row) => (
                <div key={row.label}>
                  <div className="flex justify-between text-[7.5px] text-[var(--tx-mute)]">
                    <span>{row.label}</span>
                    <span className="font-display tabular-nums" dir="ltr">{row.value}{row.unit}</span>
                  </div>
                  <div className="mt-1"><Bar value={(row.value / row.max) * 100} height={3} /></div>
                </div>
              ))}
            </div>
            <div className="mt-2 flex items-center justify-between">
              <span className="text-[7.5px] text-[var(--tx-mute)]">{t("wallpaper")}</span>
              <Toggle on={settings.wallpaper} onChange={(value) => updateSettings({ wallpaper: value })} label={t("wallpaper")} />
            </div>
            {settings.wallpaper && (
              <div className="mt-1.5 h-14 overflow-hidden rounded-[10px] border border-[var(--line)]">
                <img src={theme.image} alt={lang === "ar" ? theme.name.ar : theme.name.en} className="h-full w-full object-cover opacity-80" />
              </div>
            )}
          </div>
        </Card>

        {/* language */}
        <SectionTitle>{t("language")}</SectionTitle>
        <Card>
          <Row
            icon={<Languages size={14} />}
            title={lang === "ar" ? "العربية — RTL" : "English — LTR"}
            hint={lang === "ar" ? "تبديل فوري لاتجاه الواجهة بالكامل" : "Instantly flips the whole interface direction"}
            right={
              <span className="flex rounded-[9px] border border-[var(--line)] bg-black/25 p-[2px]">
                {(["ar", "en"] as const).map((code) => (
                  <button key={code} type="button" onClick={() => setLang(code)} className={cn("press rounded-[7px] px-2 py-1 text-[8px] font-medium", lang === code ? "text-[var(--tx)]" : "text-[var(--tx-mute)]")} style={lang === code ? { background: "linear-gradient(115deg, var(--c1), var(--c2))" } : undefined}>
                    {code === "ar" ? "عربي" : "EN"}
                  </button>
                ))}
              </span>
            }
          />
        </Card>

        {/* network */}
        <SectionTitle>{t("network")}</SectionTitle>
        <Card>
          <Row
            icon={<Gauge size={14} />}
            title={t("concurrent")}
            hint={`${settings.maxConcurrent} · ${lang === "ar" ? "طابور فعلي بمحرك التدفق" : "real queue on the stream engine"}`}
            right={
              <span className="flex items-center gap-1.5">
                <button type="button" onClick={() => updateSettings({ maxConcurrent: Math.max(1, settings.maxConcurrent - 1) })} className="press grid h-6 w-6 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-alt)] text-[11px] text-[var(--tx-dim)]">−</button>
                <span className="w-4 text-center font-display text-[11px] font-semibold text-[var(--tx)]">{settings.maxConcurrent}</span>
                <button type="button" onClick={() => updateSettings({ maxConcurrent: Math.min(6, settings.maxConcurrent + 1) })} className="press grid h-6 w-6 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-alt)] text-[11px] text-[var(--tx-dim)]">+</button>
              </span>
            }
          />
          <Row icon={<Zap size={14} />} title={lang === "ar" ? "بدء التحميل تلقائيًا" : "Start downloads automatically"} hint={lang === "ar" ? "يدخل الطابور ويعمل فورًا" : "Enters the queue and runs immediately"} right={<Toggle on={settings.autoStart} onChange={(value) => updateSettings({ autoStart: value })} label="auto start" />} />
          <Row icon={<Wifi size={14} />} title={lang === "ar" ? "توفير البيانات" : "Data saver"} hint={lang === "ar" ? "يخفض جودة المعاينة داخل المشغّل" : "Lowers preview quality inside the player"} right={<Toggle on={settings.dataSaver} onChange={(value) => updateSettings({ dataSaver: value })} label="data saver" />} />
          <Row icon={<Bell size={14} />} title={lang === "ar" ? "إشعارات النظام" : "System notifications"} hint={lang === "ar" ? "يطلب الإذن الحقيقي من المتصفح" : "Requests the real browser permission"} right={<Toggle on={settings.notifications} onChange={(value) => updateSettings({ notifications: value })} label="notifications" />} />
          <Row icon={<BatteryCharging size={14} />} title={lang === "ar" ? "إيقاف عند انخفاض البطارية" : "Pause on low battery"} hint={lang === "ar" ? "يُنفَّذ في بناء Android عبر WorkManager" : "Enforced in the Android build via WorkManager"} right={<Badge>{lang === "ar" ? "أصلي" : "native"}</Badge>} />
        </Card>

        {/* player */}
        <SectionTitle>{t("player")}</SectionTitle>
        <Card>
          <Row icon={<Play size={14} />} title={lang === "ar" ? "تشغيل تلقائي" : "Autoplay"} hint={lang === "ar" ? "يبدأ العرض فور فتح المشغّل" : "Starts playback as soon as the player opens"} right={<Toggle on={settings.autoplay} onChange={(value) => updateSettings({ autoplay: value })} label="autoplay" />} />
          <Row
            icon={<Gauge size={14} />}
            title={lang === "ar" ? "السرعة الافتراضية" : "Default speed"}
            hint={`${settings.defaultSpeed}× playbackRate`}
            right={
              <span className="flex gap-1">
                {[0.75, 1, 1.5, 2].map((value) => (
                  <button key={value} type="button" onClick={() => updateSettings({ defaultSpeed: value })} className={cn("press rounded-[7px] border px-1.5 py-1 font-display text-[7.5px]", settings.defaultSpeed === value ? "border-transparent text-white" : "border-[var(--line)] bg-[var(--surface-alt)] text-[var(--tx-mute)]")} style={settings.defaultSpeed === value ? { background: "linear-gradient(115deg, var(--c1), var(--c2))" } : undefined}>
                    {value}×
                  </button>
                ))}
              </span>
            }
          />
          <Row
            icon={<Repeat size={14} />}
            title={t("repeat")}
            hint={lang === "ar" ? "يُطبَّق فعليًا عند انتهاء التشغيل" : "Applied for real when playback ends"}
            right={
              <span className="flex gap-1">
                {(["off", "one", "all"] as RepeatMode[]).map((value) => (
                  <button key={value} type="button" onClick={() => updateSettings({ repeatMode: value })} className={cn("press rounded-[7px] border px-2 py-1 text-[7.5px]", settings.repeatMode === value ? "border-transparent text-white" : "border-[var(--line)] bg-[var(--surface-alt)] text-[var(--tx-mute)]")} style={settings.repeatMode === value ? { background: "linear-gradient(115deg, var(--c1), var(--c2))" } : undefined}>
                    {value === "off" ? t("repeatOff") : value === "one" ? t("repeatOne") : t("repeatAll")}
                  </button>
                ))}
              </span>
            }
          />
          <Row
            icon={<Timer size={14} />}
            title={t("sleepTimer")}
            hint={`${settings.sleepMinutes} ${lang === "ar" ? "دقيقة — يوقف التشغيل فعليًا" : "minutes — really pauses playback"}`}
            right={
              <span className="flex gap-1">
                {[5, 15, 30, 60].map((value) => (
                  <button key={value} type="button" onClick={() => updateSettings({ sleepMinutes: value })} className={cn("press rounded-[7px] border px-1.5 py-1 font-display text-[7.5px]", settings.sleepMinutes === value ? "border-transparent text-white" : "border-[var(--line)] bg-[var(--surface-alt)] text-[var(--tx-mute)]")} style={settings.sleepMinutes === value ? { background: "linear-gradient(115deg, var(--c1), var(--c2))" } : undefined}>
                    {value}
                  </button>
                ))}
              </span>
            }
          />
          <Row icon={<Eye size={14} />} title={lang === "ar" ? "تقليل الحركة" : "Reduce motion"} hint={lang === "ar" ? "يوقف النبض والتوهج المتحرك" : "Stops pulses and animated glow"} right={<Toggle on={settings.reduceMotion} onChange={(value) => updateSettings({ reduceMotion: value })} label="reduce motion" />} />
        </Card>

        {/* privacy */}
        <SectionTitle>{t("privacy")}</SectionTitle>
        <Card>
          <Row icon={<ShieldCheck size={14} />} title={lang === "ar" ? "بلا خادم · بلا تحليلات" : "No server · No analytics"} hint={lang === "ar" ? "كل شيء في IndexedDB و localStorage على جهازك" : "Everything lives in IndexedDB and localStorage"} right={<Check size={14} className="text-[#67e8c7]" />} />
          <Row icon={<Database size={14} />} title={lang === "ar" ? "الإبقاء على الأصل بعد المعالجة" : "Keep original after processing"} hint={lang === "ar" ? "لا يُستبدل ملفك أبدًا" : "Your file is never replaced"} right={<Toggle on={settings.keepOriginal} onChange={(value) => updateSettings({ keepOriginal: value })} label="keep original" />} />
          <Row icon={<Moon size={14} />} title={lang === "ar" ? "الوضع الداكن أولًا" : "Dark-first design"} hint={`${THEMES.filter((item) => item.mode === "dark").length} ${lang === "ar" ? "ثيمات داكنة" : "dark themes"} · ${THEMES.filter((item) => item.mode === "light").length} ${lang === "ar" ? "فاتح" : "light"}`} right={<Badge>{theme.mode}</Badge>} />
        </Card>

        {/* profile */}
        <SectionTitle>{t("profile")}</SectionTitle>
        <Card className="p-2.5">
          <div className="flex items-center gap-2.5">
            <Avatar name={profile.name} color={profile.color} size={42} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[11px] font-semibold text-[var(--tx)]">{profile.name}</p>
              <p className="font-display text-[7.5px] text-[var(--tx-mute)]" dir="ltr">{profile.handle}</p>
            </div>
            <Badge tone="#8db8ff"><UserRound size={8} /> {lang === "ar" ? "محلي" : "local"}</Badge>
          </div>
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            <button type="button" onClick={exportProfile} className="press flex items-center justify-center gap-1.5 rounded-[11px] border border-[var(--line)] bg-[var(--surface-alt)] py-2 text-[8.5px] text-[var(--tx-dim)]">
              <Download size={11} /> {t("exportProfile")}
            </button>
            <input ref={importRef} type="file" accept="application/json,.json" className="hidden" onChange={async (event) => { const file = event.target.files?.[0]; if (file) await importProfile(file); event.target.value = ""; }} />
            <button type="button" onClick={() => importRef.current?.click()} className="press flex items-center justify-center gap-1.5 rounded-[11px] border border-[var(--line)] bg-[var(--surface-alt)] py-2 text-[8.5px] text-[var(--tx-dim)]">
              <Upload size={11} /> {t("importProfile")}
            </button>
          </div>
        </Card>

        {/* storage */}
        <SectionTitle action={<button type="button" onClick={() => void refreshStorage()} className="press text-[8.5px] text-[var(--c2)]">{lang === "ar" ? "قياس" : "Measure"}</button>}>{t("storage")}</SectionTitle>
        <Card className="p-2.5">
          <div className="flex items-center justify-between text-[8.5px] text-[var(--tx-dim)]">
            <span className="flex items-center gap-1.5"><HardDrive size={11} className="text-[var(--c1)]" /> IndexedDB</span>
            <span className="font-display tabular-nums" dir="ltr">{formatBytes(storage.usage)} / {storage.quota ? formatBytes(storage.quota) : "—"}</span>
          </div>
          <div className="mt-1.5"><Bar value={storage.quota ? (storage.usage / storage.quota) * 100 : 0} /></div>
          <div className="mt-2 grid grid-cols-3 gap-1.5">
            {[
              { value: library.length, label: lang === "ar" ? "ملف" : "files" },
              { value: downloadedCount, label: lang === "ar" ? "تحميل مكتمل" : "completed" },
              { value: history.length, label: lang === "ar" ? "مشاهدة" : "watches" },
            ].map((stat) => (
              <div key={stat.label} className="rounded-[10px] border border-[var(--line)] bg-black/20 py-1.5 text-center">
                <p className="font-display text-[12px] font-semibold text-[var(--tx)]">{stat.value}</p>
                <p className="text-[6.5px] text-[var(--tx-mute)]">{stat.label}</p>
              </div>
            ))}
          </div>
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            <button type="button" onClick={() => { clearHistory(); notify(lang === "ar" ? "مُسح السجل" : "History cleared", "ok"); }} className="press flex items-center justify-center gap-1.5 rounded-[11px] border border-[var(--line)] bg-[var(--surface-alt)] py-2 text-[8.5px] text-[var(--tx-dim)]">
              <Trash2 size={11} /> {t("clearHistory")}
            </button>
            <button type="button" onClick={() => setConfirmClear(true)} className="press flex items-center justify-center gap-1.5 rounded-[11px] border border-[#ff9d9d]/25 bg-[#ff9d9d]/10 py-2 text-[8.5px] text-[#ffb3b3]">
              <Database size={11} /> {lang === "ar" ? "تفريغ المكتبة" : "Empty library"}
            </button>
          </div>
          {confirmClear && (
            <div className="mt-2 rounded-[11px] border border-[#ff9d9d]/25 bg-[#ff9d9d]/[.07] p-2">
              <p className="text-[8px] leading-4 text-[#ffc9c9]">{lang === "ar" ? `سيُحذف ${library.length} ملفًا من التخزين المحلي نهائيًا.` : `This permanently deletes ${library.length} files from local storage.`}</p>
              <div className="mt-1.5 flex gap-1.5">
                <button
                  type="button"
                  onClick={async () => {
                    for (const item of library) await removeLibraryItem(item.id);
                    setConfirmClear(false);
                    notify(lang === "ar" ? "أُفرغت المكتبة" : "Library emptied", "ok");
                  }}
                  className="press flex flex-1 items-center justify-center gap-1 rounded-[9px] bg-[#ff9d9d]/85 py-1.5 text-[8px] font-medium text-[#2a0b0b]"
                >
                  <Trash2 size={10} /> {lang === "ar" ? "حذف الكل" : "Delete all"}
                </button>
                <button type="button" onClick={() => setConfirmClear(false)} className="press rounded-[9px] border border-[var(--line)] px-2.5 py-1.5 text-[8px] text-[var(--tx-dim)]">{t("cancel")}</button>
              </div>
            </div>
          )}
        </Card>

        {/* about */}
        <div className="mt-3 rounded-[16px] border border-[var(--line)] bg-[var(--surface-alt)] p-3 text-center">
          <span className="mx-auto grid h-10 w-10 place-items-center rounded-[14px]" style={{ background: "linear-gradient(140deg, var(--c1), var(--c2) 55%, var(--c3))" }}>
            <Sparkles size={17} className="text-white" />
          </span>
          <p className="mt-2 font-display text-[12px] font-semibold text-[var(--tx)]">DON <span className="text-[8px] font-normal text-[var(--tx-mute)]">v3.0.0</span></p>
          <p className="mx-auto mt-1 max-w-[250px] text-[7.5px] leading-4 text-[var(--tx-mute)]">{t("copyright")}</p>
          <div className="mt-2 flex flex-wrap items-center justify-center gap-1">
            {["IndexedDB", "MediaRecorder", "Canvas", "Web Audio", "MediaSession", "PiP", "Clipboard"].map((tag) => (
              <span key={tag} className="rounded-full border border-[var(--line)] bg-black/20 px-1.5 py-[2px] font-display text-[6px] text-[var(--tx-mute)]">{tag}</span>
            ))}
          </div>
          <p className="mt-2 flex items-center justify-center gap-1 text-[6.5px] text-[var(--tx-mute)]">
            <ImageIcon size={8} /> {lang === "ar" ? "حزمة Android الأصلية في مجلد JP PROJ" : "Native Android package in the JP PROJ folder"}
          </p>
        </div>
      </div>
    </div>
  );
}

export function SettingsShortcuts() {
  return <Globe2 size={12} />;
}
