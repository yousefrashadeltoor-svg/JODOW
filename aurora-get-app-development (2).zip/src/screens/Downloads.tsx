import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowDownToLine,
  Bell,
  Check,
  Copy,
  FolderOpen,
  Gauge,
  HardDrive,
  Link2,
  Loader2,
  Pause,
  Play,
  Plus,
  RefreshCw,
  Share2,
  Trash2,
  TriangleAlert,
  X,
  Zap,
} from "lucide-react";
import { useDon, type TaskStatus } from "../don/store";
import { formatBytes, formatClock, formatSpeed } from "../don/core";
import { saveBlob } from "../don/media";
import { Badge, Bar, Card, Empty, Header, IconButton, Pill, Ring, Sparkline, useSpring } from "../components/ui";
import { cn } from "../utils/cn";

type Filter = "all" | "active" | "queued" | "done" | "error";

const STATUS_TONE: Record<TaskStatus, string> = {
  active: "#67e8c7",
  queued: "#f5ce8a",
  paused: "#f5ce8a",
  done: "#8db8ff",
  error: "#ff9d9d",
  blocked: "#ff9d9d",
};

export function DownloadsScreen() {
  const { t, lang, tasks, pauseTask, resumeTask, cancelTask, retryTask, removeTask, openTaskResult, enqueue, settings, updateSettings, notify, storage, refreshStorage, copy, play, libraryUrls } = useDon();
  const [filter, setFilter] = useState<Filter>("all");
  const [draft, setDraft] = useState("");
  const [adding, setAdding] = useState(false);
  const spring = useSpring();

  const counts = useMemo(
    () => ({
      all: tasks.length,
      active: tasks.filter((task) => task.status === "active").length,
      queued: tasks.filter((task) => task.status === "queued" || task.status === "paused").length,
      done: tasks.filter((task) => task.status === "done").length,
      error: tasks.filter((task) => task.status === "error" || task.status === "blocked").length,
    }),
    [tasks],
  );

  const visible = tasks.filter((task) => {
    if (filter === "all") return true;
    if (filter === "active") return task.status === "active";
    if (filter === "queued") return task.status === "queued" || task.status === "paused";
    if (filter === "done") return task.status === "done";
    return task.status === "error" || task.status === "blocked";
  });

  const totalSpeed = tasks.filter((task) => task.status === "active").reduce((sum, task) => sum + task.speed, 0);
  const totalReceived = tasks.reduce((sum, task) => sum + task.received, 0);
  const totalBytes = tasks.reduce((sum, task) => sum + Math.max(task.total, task.received), 0);
  const globalPercent = totalBytes ? (totalReceived / totalBytes) * 100 : 0;

  const statusLabel = (status: TaskStatus) =>
    ({
      active: lang === "ar" ? "نشط" : "Active",
      queued: t("queued"),
      paused: lang === "ar" ? "موقوف" : "Paused",
      done: t("done"),
      error: t("failed"),
      blocked: lang === "ar" ? "محجوب (CORS)" : "Blocked (CORS)",
    })[status];

  return (
    <div className="pb-4">
      <Header
        title={t("downloads")}
        subtitle={`${lang === "ar" ? "محرك فعلي بالتدفق والاستئناف" : "Real streaming engine with resume"} · ${settings.maxConcurrent} ${t("concurrent")}`}
        right={
          <>
            <IconButton label={lang === "ar" ? "إشعارات النظام" : "System notifications"} size="sm" active={settings.notifications} onClick={() => updateSettings({ notifications: !settings.notifications })}>
              <Bell size={13} />
            </IconButton>
            <IconButton label={t("addUrl")} size="sm" onClick={() => setAdding(!adding)}>
              <Plus size={14} />
            </IconButton>
          </>
        }
      />

      <div className="px-4">
        <AnimatePresence>
          {adding && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
              <div className="mb-2 flex items-center gap-1.5 rounded-[14px] border border-[var(--line)] bg-[var(--surface-alt)] p-1.5">
                <Link2 size={12} className="ml-1 shrink-0 text-[var(--tx-mute)]" />
                <input
                  dir="ltr"
                  value={draft}
                  onChange={(event) => setDraft(event.target.value)}
                  onKeyDown={async (event) => {
                    if (event.key === "Enter" && draft.trim()) {
                      await enqueue(draft.trim());
                      setDraft("");
                    }
                  }}
                  placeholder="https://…"
                  className="min-w-0 flex-1 bg-transparent text-left text-[9px] text-[var(--tx)] outline-none placeholder:text-[var(--tx-mute)]"
                />
                <button
                  type="button"
                  disabled={!draft.trim()}
                  onClick={async () => {
                    await enqueue(draft.trim());
                    setDraft("");
                  }}
                  className="press btn-primary rounded-[10px] px-2.5 py-1.5 text-[8.5px] font-medium disabled:opacity-40"
                >
                  {t("start")}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <Card glow className="p-3">
          <div className="absolute -left-10 -top-12 h-32 w-32 rounded-full blur-3xl" style={{ background: "rgba(var(--glow2),0.22)" }} />
          <div className="relative flex items-center gap-3">
            <Ring value={globalPercent} size={68}>
              <div>
                <p className="font-display text-[15px] font-semibold leading-none text-[var(--tx)]">{Math.round(globalPercent)}%</p>
                <p className="mt-0.5 text-[6.5px] text-[var(--tx-mute)]">{lang === "ar" ? "الإجمالي" : "TOTAL"}</p>
              </div>
            </Ring>
            <div className="min-w-0 flex-1">
              <p className="flex items-center gap-1.5 text-[9px] text-[var(--tx-dim)]">
                {counts.active > 0 ? <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#67e8c7]" /> : <Zap size={10} />}
                {t("speed")}
              </p>
              <p className="mt-0.5 font-display text-[24px] font-semibold leading-none tabular-nums grad-text">{totalSpeed > 0 ? formatSpeed(totalSpeed) : "—"}</p>
              <div className="mt-2 flex flex-wrap gap-1">
                <Badge tone="#8db8ff"><ArrowDownToLine size={8} /> {counts.active} {t("active")}</Badge>
                <Badge tone="#f5ce8a">{counts.queued} {t("queued")}</Badge>
                <Badge tone="#67e8c7"><HardDrive size={8} /> {formatBytes(storage.usage)}</Badge>
              </div>
            </div>
          </div>
          <div className="relative mt-2.5 grid grid-cols-3 gap-1.5">
            <div className="rounded-[11px] border border-[var(--line)] bg-black/20 p-1.5">
              <p className="text-[6.5px] text-[var(--tx-mute)]">{t("concurrent")}</p>
              <div className="mt-1 flex items-center gap-1">
                <button type="button" onClick={() => updateSettings({ maxConcurrent: Math.max(1, settings.maxConcurrent - 1) })} className="press grid h-5 w-5 place-items-center rounded-full border border-[var(--line)] text-[10px] text-[var(--tx-dim)]">−</button>
                <span className="flex-1 text-center font-display text-[11px] font-semibold text-[var(--tx)]">{settings.maxConcurrent}</span>
                <button type="button" onClick={() => updateSettings({ maxConcurrent: Math.min(6, settings.maxConcurrent + 1) })} className="press grid h-5 w-5 place-items-center rounded-full border border-[var(--line)] text-[10px] text-[var(--tx-dim)]">+</button>
              </div>
            </div>
            <button type="button" onClick={() => updateSettings({ autoStart: !settings.autoStart })} className="press rounded-[11px] border border-[var(--line)] bg-black/20 p-1.5 text-right">
              <p className="text-[6.5px] text-[var(--tx-mute)]">{lang === "ar" ? "بدء تلقائي" : "Auto start"}</p>
              <p className="mt-1 flex items-center gap-1 text-[9px] text-[var(--tx-dim)]">{settings.autoStart ? <Check size={10} className="text-[#67e8c7]" /> : <X size={10} />} {settings.autoStart ? (lang === "ar" ? "مفعّل" : "On") : lang === "ar" ? "متوقف" : "Off"}</p>
            </button>
            <div className="rounded-[11px] border border-[var(--line)] bg-black/20 p-1.5">
              <p className="text-[6.5px] text-[var(--tx-mute)]">{lang === "ar" ? "بيانات محفوظة" : "Stored"}</p>
              <p className="mt-1 font-display text-[9px] text-[var(--tx-dim)]" dir="ltr">{formatBytes(totalReceived)}</p>
            </div>
          </div>
        </Card>

        <div className="no-bar -mx-1 mt-2.5 flex gap-1.5 overflow-x-auto px-1 pb-1">
          {([
            { id: "all" as Filter, label: t("all"), count: counts.all },
            { id: "active" as Filter, label: t("active"), count: counts.active },
            { id: "queued" as Filter, label: t("queued"), count: counts.queued },
            { id: "done" as Filter, label: t("done"), count: counts.done },
            { id: "error" as Filter, label: t("failed"), count: counts.error },
          ]).map((item) => (
            <Pill key={item.id} active={filter === item.id} onClick={() => setFilter(item.id)} count={item.count}>
              {item.label}
            </Pill>
          ))}
        </div>

        <div className="mt-1.5 space-y-2">
          <AnimatePresence initial={false}>
            {visible.map((task) => {
              const percent = task.total ? Math.min(100, (task.received / task.total) * 100) : 0;
              const objectUrl = task.libraryId ? libraryUrls[task.libraryId] : undefined;
              return (
                <motion.div key={task.id} layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.97 }} transition={spring}>
                  <Card className="p-2.5">
                    <div className="flex items-start gap-2.5">
                      <span className="relative grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-[13px] border border-[var(--line)] bg-black/25">
                        {task.poster ? <img src={task.poster} alt="" className="h-full w-full object-cover" /> : <ArrowDownToLine size={16} className="text-[var(--c2)]" />}
                        <span className="absolute inset-x-0 bottom-0 h-[3px] bg-white/10">
                          <span className="block h-full bar-fill" style={{ width: `${percent}%` }} />
                        </span>
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[10px] font-medium text-[var(--tx)]">{task.title}</p>
                        <div className="mt-0.5 flex flex-wrap items-center gap-1">
                          <Badge tone={STATUS_TONE[task.status]}>
                            {task.status === "active" ? <Loader2 size={7} className="animate-spin" /> : task.status === "done" ? <Check size={7} /> : task.status === "error" || task.status === "blocked" ? <TriangleAlert size={7} /> : <Pause size={7} />}
                            {statusLabel(task.status)}
                          </Badge>
                          <Badge>{task.kind}</Badge>
                          {task.rangeSupported && <Badge tone="#67e8c7">{t("resumeSupport")}</Badge>}
                        </div>
                        <div className="mt-1.5"><Bar value={percent} /></div>
                        <div className="mt-1 flex items-center justify-between font-display text-[7.5px] tabular-nums text-[var(--tx-mute)]">
                          <span dir="ltr">{formatBytes(task.received)} / {task.total ? formatBytes(task.total) : "?"}</span>
                          <span className="flex items-center gap-2">
                            {task.status === "active" && <span dir="ltr" className="text-[var(--c1)]">{formatSpeed(task.speed)}</span>}
                            {task.status === "active" && task.eta > 0 && <span dir="ltr">{formatClock(task.eta)}</span>}
                            <Sparkline data={task.samples} width={44} height={14} />
                          </span>
                        </div>
                        {task.error && (
                          <p className="mt-1 flex items-start gap-1 text-[7.5px] leading-4 text-[#ff9d9d]">
                            <TriangleAlert size={9} className="mt-0.5 shrink-0" />
                            {task.error === "cors"
                              ? lang === "ar"
                                ? "الخادم منع القراءة المباشرة (CORS). افتح الملف للبث أو جرّب رابطًا مباشرًا."
                                : "Server blocked direct reads (CORS). Stream it or use a direct link."
                              : task.error}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="mt-2 flex items-center gap-1.5">
                      {task.status === "active" ? (
                        <button type="button" onClick={() => pauseTask(task.id)} className="press flex flex-1 items-center justify-center gap-1 rounded-[10px] border border-[var(--line)] bg-[var(--surface-alt)] py-1.5 text-[8.5px] text-[var(--tx-dim)]">
                          <Pause size={10} /> {t("pause")}
                        </button>
                      ) : task.status === "done" ? (
                        <button type="button" onClick={() => (objectUrl ? openTaskResult(task.id) : play({ src: task.url, title: task.title, kind: task.kind, remote: true }))} className="press btn-primary flex flex-1 items-center justify-center gap-1 rounded-[10px] py-1.5 text-[8.5px] font-medium">
                          {objectUrl ? <Play size={10} fill="currentColor" /> : <FolderOpen size={10} />} {t("open")}
                        </button>
                      ) : (
                        <button type="button" onClick={() => resumeTask(task.id)} className="press btn-primary flex flex-1 items-center justify-center gap-1 rounded-[10px] py-1.5 text-[8.5px] font-medium">
                          <Play size={10} fill="currentColor" /> {t("resume")}
                        </button>
                      )}
                      {(task.status === "error" || task.status === "blocked") && (
                        <button type="button" onClick={() => void retryTask(task.id)} className="press flex items-center justify-center gap-1 rounded-[10px] border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-1.5 text-[8.5px] text-[var(--tx-dim)]">
                          <RefreshCw size={10} /> {t("retry")}
                        </button>
                      )}
                      {task.status === "blocked" && (
                        <button type="button" onClick={() => play({ src: task.url, title: task.title, kind: task.kind, poster: task.poster, remote: true })} className="press flex items-center justify-center gap-1 rounded-[10px] border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-1.5 text-[8.5px] text-[var(--tx-dim)]">
                          <Play size={10} /> {lang === "ar" ? "بث" : "Stream"}
                        </button>
                      )}
                      {task.status === "done" && task.libraryId && (
                        <IconButton
                          label={t("exportFile")}
                          size="sm"
                          onClick={async () => {
                            try {
                              const url = libraryUrls[task.libraryId as string];
                              if (!url) throw new Error("missing");
                              const blob = await (await fetch(url)).blob();
                              saveBlob(blob, task.filename);
                              notify(t("savedOk"), "ok");
                            } catch {
                              notify(lang === "ar" ? "الملف غير متاح للتصدير" : "File unavailable for export", "error");
                            }
                          }}
                        >
                          <FolderOpen size={12} />
                        </IconButton>
                      )}
                      <IconButton label={t("copyLink")} size="sm" onClick={() => void copy(task.url, task.title)}>
                        <Copy size={12} />
                      </IconButton>
                      <IconButton label={t("share")} size="sm" onClick={async () => {
                        const ok = await navigator.share?.({ title: task.title, url: task.url }).then(() => true).catch(() => false);
                        if (!ok) void copy(task.url, task.title);
                      }}>
                        <Share2 size={12} />
                      </IconButton>
                      {task.status === "active" && (
                        <IconButton label={t("cancel")} size="sm" onClick={() => void cancelTask(task.id)}>
                          <X size={12} />
                        </IconButton>
                      )}
                      <IconButton label={t("remove")} size="sm" onClick={() => void removeTask(task.id)}>
                        <Trash2 size={12} />
                      </IconButton>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </AnimatePresence>

          {!visible.length && (
            <Card>
              <Empty
                title={t("noItems")}
                hint={lang === "ar" ? "أضف رابطًا مباشرًا أو حمّل من DON Tube" : "Add a direct link or download from DON Tube"}
                icon={<ArrowDownToLine size={22} />}
              />
            </Card>
          )}
        </div>

        <button type="button" onClick={() => void (async () => { await refreshStorage(); notify(`${formatBytes(storage.usage)} · IndexedDB`, "ok"); })()} className={cn("press mt-3 flex w-full items-center justify-center gap-1.5 rounded-[13px] border border-dashed border-[var(--line)] py-2.5 text-[8.5px] text-[var(--tx-mute)]")}>
          <Gauge size={11} /> {lang === "ar" ? "قياس التخزين المحلي الحقيقي" : "Measure real local storage"}
        </button>
        {tasks.some((task) => task.status === "paused") && (
          <p className="mt-2 flex items-center justify-center gap-1 text-[7.5px] text-[var(--tx-mute)]">
            <Check size={9} className="text-[#67e8c7]" /> {lang === "ar" ? "الاستئناف يعمل بعد إعادة فتح التطبيق (الجزء محفوظ محليًا)" : "Resume survives app restarts (partial data stored locally)"}
          </p>
        )}
        <p className="mt-2 text-center text-[7px] text-[var(--tx-mute)]">{t("copyright")}</p>
      </div>
    </div>
  );
}
