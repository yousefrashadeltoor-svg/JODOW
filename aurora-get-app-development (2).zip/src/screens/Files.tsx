import { useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  AudioLines,
  Check,
  Download,
  FileText,
  FolderOpen,
  FolderUp,
  Grid2x2,
  HardDrive,
  Image as ImageIcon,
  LayoutList,
  Music2,
  Pause,
  Play,
  Search,
  Trash2,
  Video,
  X,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { useDon } from "../don/store";
import { formatBytes } from "../don/core";
import { saveBlob } from "../don/media";
import { Badge, Bar, Card, Empty, Header, IconButton, Pill, useSpring } from "../components/ui";
import { cn } from "../utils/cn";

type KindFilter = "all" | "video" | "audio" | "image" | "file";

const KIND_ICON = { video: Video, audio: Music2, image: ImageIcon, file: FileText };

export function FilesScreen() {
  const { t, lang, library, libraryUrls, addLocalFiles, removeLibraryItem, play, notify, storage, refreshStorage, setScreen } = useDon();
  const [filter, setFilter] = useState<KindFilter>("all");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [query, setQuery] = useState("");
  const [viewer, setViewer] = useState<{ src: string; title: string } | null>(null);
  const [zoom, setZoom] = useState(1);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const spring = useSpring();

  const items = useMemo(
    () =>
      library.filter((item) => {
        const matchesKind = filter === "all" || item.kind === filter;
        const matchesQuery = !query.trim() || item.title.toLowerCase().includes(query.trim().toLowerCase());
        return matchesKind && matchesQuery;
      }),
    [library, filter, query],
  );

  const totalBytes = library.reduce((sum, item) => sum + item.size, 0);
  const byKind = (kind: KindFilter) => (kind === "all" ? library.length : library.filter((item) => item.kind === kind).length);
  const audioItems = library.filter((item) => item.kind === "audio");

  const openItem = (id: string) => {
    const item = library.find((entry) => entry.id === id);
    if (!item) return;
    const src = libraryUrls[id];
    if (!src) {
      notify(lang === "ar" ? "الملف غير مخزّن محليًا" : "File is not stored locally", "warn");
      return;
    }
    if (item.kind === "image") {
      setViewer({ src, title: item.title });
      setZoom(1);
      return;
    }
    play({ src, title: item.title, kind: item.kind, libraryId: item.id, poster: item.poster });
  };

  const exportItem = async (id: string) => {
    const item = library.find((entry) => entry.id === id);
    const src = libraryUrls[id];
    if (!item || !src) return;
    try {
      const blob = await (await fetch(src)).blob();
      saveBlob(blob, item.title);
      notify(t("savedOk"), "ok");
    } catch {
      notify(lang === "ar" ? "تعذّرت الكتابة على الجهاز" : "Could not write to the device", "error");
    }
  };

  return (
    <div className="pb-4">
      <Header
        title={t("files")}
        subtitle={`${library.length} ${lang === "ar" ? "عنصر" : "items"} · ${formatBytes(totalBytes)}`}
        right={
          <>
            <IconButton label={lang === "ar" ? "عرض" : "View"} size="sm" onClick={() => setView(view === "grid" ? "list" : "grid")}>
              {view === "grid" ? <LayoutList size={13} /> : <Grid2x2 size={13} />}
            </IconButton>
            <IconButton label={t("pickFile")} size="sm" onClick={() => fileRef.current?.click()}>
              <FolderUp size={13} />
            </IconButton>
          </>
        }
      />
      <input
        ref={fileRef}
        type="file"
        multiple
        accept="video/*,audio/*,image/*,.pdf,.zip,.json,.srt"
        className="hidden"
        onChange={async (event) => {
          const files = event.target.files;
          if (files?.length) await addLocalFiles(files);
          event.target.value = "";
        }}
      />

      <div className="px-4">
        <Card glow className="p-3">
          <div className="absolute -right-10 -top-12 h-32 w-32 rounded-full blur-3xl" style={{ background: "rgba(var(--glow),0.2)" }} />
          <div className="relative flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-[13px] border border-[var(--line)] bg-black/25 text-[var(--c1)]">
              <HardDrive size={17} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-[10.5px] font-medium text-[var(--tx)]">{t("storage")}</p>
              <p className="mt-0.5 font-display text-[8px] tabular-nums text-[var(--tx-mute)]" dir="ltr">
                {formatBytes(storage.usage)} {storage.quota ? `/ ${formatBytes(storage.quota)}` : ""} · IndexedDB
              </p>
            </div>
            <button type="button" onClick={() => void refreshStorage()} className="press rounded-full border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-1 text-[8px] text-[var(--tx-dim)]">
              {lang === "ar" ? "تحديث" : "Refresh"}
            </button>
          </div>
          <div className="relative mt-2"><Bar value={storage.quota ? (storage.usage / storage.quota) * 100 : 0} height={4} /></div>
          <div className="relative mt-2 grid grid-cols-4 gap-1.5">
            {(["video", "audio", "image", "file"] as const).map((kind) => {
              const Icon = KIND_ICON[kind];
              const bytes = library.filter((item) => item.kind === kind).reduce((sum, item) => sum + item.size, 0);
              return (
                <button key={kind} type="button" onClick={() => setFilter(kind)} className="press rounded-[11px] border border-[var(--line)] bg-black/20 p-1.5 text-right">
                  <Icon size={11} className="text-[var(--c2)]" />
                  <p className="mt-1 font-display text-[9px] text-[var(--tx)]">{byKind(kind)}</p>
                  <p className="font-display text-[6.5px] text-[var(--tx-mute)]" dir="ltr">{formatBytes(bytes)}</p>
                </button>
              );
            })}
          </div>
        </Card>

        {audioItems.length > 0 && (
          <Card className="mt-2 p-2.5">
            <div className="flex items-center gap-2">
              <span className="flex h-8 items-end gap-[2px] px-1 text-[var(--c2)]">
                {[35, 65, 45, 85, 55].map((height) => (
                  <span key={height} className="w-[2px] rounded-full eq-bar" style={{ height: `${height}%`, background: "currentColor" }} />
                ))}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-[10px] font-medium text-[var(--tx)]">{lang === "ar" ? "موسيقاي المحلية" : "My local music"}</p>
                <p className="font-display text-[7.5px] text-[var(--tx-mute)]">{audioItems.length} · {formatBytes(audioItems.reduce((sum, item) => sum + item.size, 0))}</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  const first = audioItems[0];
                  const src = libraryUrls[first.id];
                  if (src) play({ src, title: first.title, kind: "audio", libraryId: first.id });
                }}
                className="press btn-primary flex items-center gap-1 rounded-full px-2.5 py-1.5 text-[8.5px] font-medium"
              >
                <AudioLines size={11} /> {lang === "ar" ? "تشغيل الكل" : "Play all"}
              </button>
            </div>
          </Card>
        )}

        <div className="mt-2.5 flex items-center gap-1.5">
          <div className="flex min-w-0 flex-1 items-center gap-1.5 rounded-full border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-[7px]">
            <Search size={11} className="shrink-0 text-[var(--tx-mute)]" />
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={lang === "ar" ? "ابحث في مكتبتك" : "Search your library"} className="min-w-0 flex-1 bg-transparent text-[9px] text-[var(--tx)] outline-none placeholder:text-[var(--tx-mute)]" />
            {query && <button type="button" onClick={() => setQuery("")} aria-label="clear"><X size={11} className="text-[var(--tx-mute)]" /></button>}
          </div>
        </div>

        <div className="no-bar -mx-1 mt-2 flex gap-1.5 overflow-x-auto px-1 pb-1">
          {(["all", "video", "audio", "image", "file"] as KindFilter[]).map((kind) => (
            <Pill key={kind} active={filter === kind} onClick={() => setFilter(kind)} count={byKind(kind)}>
              {kind === "all" ? t("all") : t(kind)}
            </Pill>
          ))}
        </div>

        {items.length ? (
          <div className={cn("mt-1.5", view === "grid" ? "grid grid-cols-2 gap-2" : "space-y-1.5")}>
            <AnimatePresence mode="popLayout">
              {items.map((item) => {
                const Icon = KIND_ICON[item.kind];
                const src = libraryUrls[item.id];
                return view === "grid" ? (
                  <motion.div key={item.id} layout initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.96 }} transition={spring}>
                    <Card className="overflow-hidden">
                      <button type="button" onClick={() => openItem(item.id)} className="press relative block h-[86px] w-full bg-black/40">
                        {src && item.kind === "image" ? (
                          <img src={src} alt={item.title} className="h-full w-full object-cover" />
                        ) : item.poster ? (
                          <img src={item.poster} alt="" className="h-full w-full object-cover opacity-80" />
                        ) : (
                          <span className="grid h-full w-full place-items-center"><Icon size={22} className="text-[var(--tx-mute)]" /></span>
                        )}
                        <span className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                        <span className="absolute bottom-1.5 right-1.5 grid h-6 w-6 place-items-center rounded-full border border-white/25 bg-black/45 backdrop-blur-md">
                          {item.kind === "file" ? <FileText size={10} className="text-white/85" /> : <Play size={10} fill="white" className="ml-0.5 text-white" />}
                        </span>
                        <span className="absolute left-1.5 top-1.5"><Badge className="border-white/15 bg-black/45 text-white/80">{item.origin}</Badge></span>
                      </button>
                      <div className="p-2">
                        <p className="truncate text-[9px] font-medium text-[var(--tx)]">{item.title}</p>
                        <p className="mt-0.5 font-display text-[7px] text-[var(--tx-mute)]" dir="ltr">{formatBytes(item.size)} · {item.kind}</p>
                        <div className="mt-1.5 flex gap-1">
                          <button type="button" onClick={() => void exportItem(item.id)} className="press flex flex-1 items-center justify-center gap-1 rounded-[8px] border border-[var(--line)] bg-[var(--surface-alt)] py-1 text-[7px] text-[var(--tx-dim)]">
                            <Download size={9} /> {t("save")}
                          </button>
                          <button type="button" onClick={() => void removeLibraryItem(item.id)} aria-label={t("remove")} className="press grid h-[22px] w-[22px] place-items-center rounded-[8px] border border-[var(--line)] bg-[var(--surface-alt)] text-[var(--tx-mute)]">
                            <Trash2 size={9} />
                          </button>
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                ) : (
                  <motion.div key={item.id} layout initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} transition={spring}>
                    <Card className="flex items-center gap-2.5 p-2">
                      <button type="button" onClick={() => openItem(item.id)} className="press relative grid h-11 w-14 shrink-0 place-items-center overflow-hidden rounded-[10px] bg-black/35">
                        {src && item.kind === "image" ? <img src={src} alt="" className="h-full w-full object-cover" /> : <Icon size={15} className="text-[var(--c2)]" />}
                      </button>
                      <button type="button" onClick={() => openItem(item.id)} className="press min-w-0 flex-1 text-right">
                        <p className="truncate text-[9.5px] font-medium text-[var(--tx)]">{item.title}</p>
                        <p className="font-display text-[7px] text-[var(--tx-mute)]" dir="ltr">{formatBytes(item.size)} · {item.origin} · {new Date(item.addedAt).toLocaleDateString()}</p>
                      </button>
                      <IconButton label={t("save")} size="sm" onClick={() => void exportItem(item.id)}>
                        <Download size={12} />
                      </IconButton>
                      <IconButton label={t("remove")} size="sm" onClick={() => void removeLibraryItem(item.id)}>
                        <Trash2 size={12} />
                      </IconButton>
                    </Card>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        ) : (
          <Card className="mt-2">
            <Empty title={t("noItems")} hint={t("noItemsHint")} icon={<FolderOpen size={22} />} />
            <div className="flex gap-1.5 px-4 pb-4">
              <button type="button" onClick={() => fileRef.current?.click()} className="press btn-primary flex flex-1 items-center justify-center gap-1.5 rounded-[12px] py-2.5 text-[9.5px] font-medium">
                <FolderUp size={12} /> {t("pickFile")}
              </button>
              <button type="button" onClick={() => setScreen("tube")} className="press flex flex-1 items-center justify-center gap-1.5 rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] py-2.5 text-[9.5px] text-[var(--tx-dim)]">
                <Play size={12} /> DON Tube
              </button>
            </div>
          </Card>
        )}

        <p className="mt-3 flex items-center justify-center gap-1.5 text-[7.5px] text-[var(--tx-mute)]">
          <Check size={9} className="text-[#67e8c7]" /> {t("offlineReady")} · {t("localOnly")}
        </p>
      </div>

      {/* real image viewer with zoom */}
      <AnimatePresence>
        {viewer && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[75] flex flex-col bg-black/95 backdrop-blur-xl">
            <div className="flex items-center justify-between px-3 pt-2">
              <p className="min-w-0 flex-1 truncate text-[10px] text-white/80">{viewer.title}</p>
              <div className="flex items-center gap-1.5">
                <button type="button" onClick={() => setZoom((value) => Math.max(1, value - 0.35))} className="press grid h-8 w-8 place-items-center rounded-full border border-white/15 bg-white/10 text-white/80"><ZoomOut size={13} /></button>
                <span className="font-display text-[8px] text-white/60">{zoom.toFixed(2)}×</span>
                <button type="button" onClick={() => setZoom((value) => Math.min(4, value + 0.35))} className="press grid h-8 w-8 place-items-center rounded-full border border-white/15 bg-white/10 text-white/80"><ZoomIn size={13} /></button>
                <button type="button" onClick={() => setViewer(null)} aria-label="close" className="press grid h-8 w-8 place-items-center rounded-full border border-white/15 bg-white/10 text-white/80"><X size={13} /></button>
              </div>
            </div>
            <motion.div drag dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }} dragElastic={0.18} className="flex flex-1 items-center justify-center overflow-hidden p-4">
              <motion.img src={viewer.src} alt={viewer.title} animate={{ scale: zoom }} transition={spring} className="max-h-full max-w-full rounded-[14px] object-contain" />
            </motion.div>
            <div className="flex items-center justify-center gap-2 pb-4">
              <button
                type="button"
                onClick={async () => {
                  try {
                    const blob = await (await fetch(viewer.src)).blob();
                    saveBlob(blob, viewer.title);
                    notify(t("savedOk"), "ok");
                  } catch {
                    notify(lang === "ar" ? "تعذّر الحفظ" : "Save failed", "error");
                  }
                }}
                className="press btn-primary flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[9px] font-medium"
              >
                <Download size={11} /> {t("save")}
              </button>
              <button type="button" onClick={() => setZoom(1)} className="press flex items-center gap-1.5 rounded-full border border-white/15 bg-white/10 px-3.5 py-2 text-[9px] text-white/75">
                <Pause size={11} /> {lang === "ar" ? "إعادة الضبط" : "Reset zoom"}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
