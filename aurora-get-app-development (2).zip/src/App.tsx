import { useRef } from "react";
import { motion } from "framer-motion";
import {
  Activity,
  ArrowDownToLine,
  Cpu,
  Database,
  Download,
  FolderUp,
  Gauge,
  Globe2,
  HardDrive,
  Layers,
  Play,
  Radar,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Zap,
} from "lucide-react";
import { DonProvider, useDon, type Screen } from "./don/store";
import { THEMES, formatBytes, formatSpeed, themeCssVars } from "./don/core";
import { Phone } from "./components/Phone";
import { cn } from "./utils/cn";

const SAMPLE_MEDIA = "https://videos.pexels.com/video-files/39924448/17034603_3840_2160_30fps.mp4";

const NAV: { id: Screen; ar: string; en: string; hint: string; icon: typeof Play }[] = [
  { id: "home", icon: Zap, ar: "الرئيسية", en: "Home", hint: "تحليل روابط حقيقي · HEAD/Range · DOM" },
  { id: "tube", icon: Play, ar: "DON Tube", en: "DON Tube", hint: "تغذية · شورتس · اشتراكات · ملف محلي" },
  { id: "downloads", icon: Download, ar: "التحميلات", en: "Downloads", hint: "محرك تدفّق · إيقاف/استئناف · طابور" },
  { id: "browser", icon: Globe2, ar: "المتصفح", en: "Browser", hint: "تنقّل فعلي · اصطياد وسائط" },
  { id: "files", icon: FolderUp, ar: "المكتبة", en: "Library", hint: "IndexedDB · صور · موسيقى" },
  { id: "tools", icon: Layers, ar: "الأدوات", en: "Tools", hint: "تحويل · ضغط · قص · استخراج صوت" },
  { id: "settings", icon: ShieldCheck, ar: "الإعدادات", en: "Settings", hint: "8 ثيمات · لغة · خصوصية" },
];

const REAL_NOW = [
  { icon: Activity, ar: "محرك تحميل بالتدفق مع Range واستئناف حقيقي بعد الإغلاق", en: "Streaming download engine with real Range resume" },
  { icon: Database, ar: "تخزين IndexedDB دائم — بلا خادم وبلا قاعدة بيانات", en: "Persistent IndexedDB storage — no server, no DB" },
  { icon: Cpu, ar: "معالجة وسائط حقيقية: MediaRecorder + Canvas + Web Audio", en: "Real media processing: MediaRecorder + Canvas + Web Audio" },
  { icon: Radar, ar: "اصطياد وسائط فعلي: جلب المستند، تحليل DOM، قياس الأحجام", en: "Real media sniffing: fetch, DOM parse, size probing" },
  { icon: Smartphone, ar: "MediaSession · Picture-in-Picture · Fullscreen · Clipboard · Share", en: "MediaSession · PiP · Fullscreen · Clipboard · Share" },
];

const NATIVE_NEXT = [
  { label: "yt-dlp + aria2c", detail: "استخراج المسارات من 1800+ موقع (JP PROJ :engine:extractors)" },
  { label: "FFmpeg / MediaCodec", detail: "دمج DASH، تحويل HEVC/AV1، تضمين الترجمة والـ Metadata" },
  { label: "Room + WorkManager", detail: "طابور التحميل، الجدولة، وForeground Service dataSync" },
  { label: "OkHttp + Cronet", detail: "HTTP/2 و HTTP/3 (QUIC) مع DNS cache و CookieJar" },
  { label: "libadblock + WebView", detail: "حجب الإعلانات وحل تحديات Cloudflare شرعيًا" },
];

function Console() {
  const {
    lang,
    setLang,
    themeId,
    setThemeId,
    theme,
    screen,
    setScreen,
    tasks,
    library,
    storage,
    history,
    following,
    analyze,
    enqueue,
    addLocalFiles,
    notify,
    toast,
  } = useDon();
  const fileRef = useRef<HTMLInputElement | null>(null);
  const isAr = lang === "ar";
  const vars = themeCssVars(theme) as React.CSSProperties;

  const active = tasks.filter((task) => task.status === "active");
  const totalSpeed = active.reduce((sum, task) => sum + task.speed, 0);
  const doneCount = tasks.filter((task) => task.status === "done").length;

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden" style={{ ...vars, background: "var(--bg)", color: "var(--tx)" }} dir="rtl">
      {/* ambient */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="absolute inset-0 opacity-[0.22]" style={{ backgroundImage: `url(${theme.image})`, backgroundSize: "cover", backgroundPosition: "center", filter: "blur(28px) saturate(120%)" }} />
        <div className="absolute inset-0" style={{ background: `radial-gradient(120% 90% at 80% -10%, rgba(var(--glow),0.22), transparent 58%), radial-gradient(100% 80% at 5% 25%, rgba(var(--glow2),0.18), transparent 62%), linear-gradient(180deg, color-mix(in srgb, var(--bg) 72%, transparent), var(--bg))` }} />
        <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle, currentColor 1px, transparent 1px)", backgroundSize: "30px 30px" }} />
      </div>

      <div className="relative z-10 mx-auto max-w-[1500px] px-4 pb-14 pt-4 sm:px-6">
        {/* top bar */}
        <header className="flex flex-wrap items-center gap-3 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] px-3 py-2.5 backdrop-blur-2xl">
          <div className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-[14px]" style={{ background: "linear-gradient(140deg, var(--c1), var(--c2) 55%, var(--c3))", boxShadow: "inset 0 1px 1px rgba(255,255,255,.4)" }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M7 4h6.2c3.4 0 5.8 2.3 5.8 5.7v4.6c0 3.4-2.4 5.7-5.8 5.7H7V4Zm3 2.6v8.8h3c1.8 0 3-1.2 3-3V9.6c0-1.8-1.2-3-3-3h-3Z" fill="white" fillOpacity=".97" />
              </svg>
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display text-[19px] font-semibold tracking-[-0.02em]">DON</h1>
                <span className="rounded-full border border-[var(--line)] bg-[var(--surface-alt)] px-1.5 py-[2px] font-display text-[6.5px] tracking-[0.16em] text-[var(--tx-mute)]">V3 · LOCAL FIRST</span>
              </div>
              <p className="text-[8px] text-[var(--tx-mute)]">{isAr ? "مدير تحميل + مشغّل + منصة فيديو محلية — كلها تعمل فعليًا" : "Downloader + player + local video platform — all really working"}</p>
            </div>
          </div>

          <div className="mx-auto hidden items-center gap-2 lg:flex">
            {[
              { icon: Gauge, value: totalSpeed > 0 ? formatSpeed(totalSpeed) : "—", label: isAr ? "السرعة اللحظية" : "live speed" },
              { icon: HardDrive, value: formatBytes(storage.usage), label: isAr ? "التخزين المحلي" : "local storage" },
              { icon: Activity, value: `${active.length}/${tasks.length}`, label: isAr ? "نشط/الإجمالي" : "active/total" },
            ].map((chip) => (
              <div key={chip.label} className="flex items-center gap-2 rounded-[13px] border border-[var(--line)] bg-[var(--surface-alt)] px-2.5 py-1.5">
                <chip.icon size={12} className="text-[var(--c1)]" />
                <div>
                  <p className="font-display text-[10px] font-semibold tabular-nums leading-none" dir="ltr">{chip.value}</p>
                  <p className="mt-0.5 text-[6.5px] text-[var(--tx-mute)]">{chip.label}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-1.5">
            <div className="flex items-center gap-1 rounded-full border border-[var(--line)] bg-[var(--surface-alt)] p-1">
              {THEMES.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setThemeId(item.id)}
                  aria-label={isAr ? item.name.ar : item.name.en}
                  title={isAr ? item.name.ar : item.name.en}
                  className={cn("press h-5 w-5 rounded-full border transition-transform", themeId === item.id ? "scale-110 border-white/70" : "border-transparent opacity-75 hover:opacity-100")}
                  style={{ background: `linear-gradient(135deg, ${item.c1}, ${item.c2} 55%, ${item.c3})` }}
                />
              ))}
            </div>
            <div className="flex rounded-full border border-[var(--line)] bg-[var(--surface-alt)] p-[2px]">
              {(["ar", "en"] as const).map((code) => (
                <button key={code} type="button" onClick={() => setLang(code)} className={cn("press rounded-full px-2.5 py-1 text-[8px] font-medium", lang === code ? "text-white" : "text-[var(--tx-mute)]")} style={lang === code ? { background: "linear-gradient(115deg, var(--c1), var(--c2))" } : undefined}>
                  {code === "ar" ? "عربي" : "EN"}
                </button>
              ))}
            </div>
          </div>
        </header>

        {/* stage */}
        <main className="mt-4 grid grid-cols-1 items-start gap-4 lg:grid-cols-[290px_minmax(0,1fr)_320px]">
          {/* left rail */}
          <aside className="order-2 space-y-3 lg:order-1">
            <section className="rounded-[20px] border border-[var(--line)] bg-[var(--surface)] p-3 backdrop-blur-2xl">
              <p className="mb-2 text-[10px] font-semibold">{isAr ? "شاشات التطبيق" : "App screens"}</p>
              <div className="space-y-1">
                {NAV.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setScreen(item.id)}
                    className={cn("press relative flex w-full items-center gap-2.5 overflow-hidden rounded-[13px] border px-2.5 py-2 text-right", screen === item.id ? "border-[rgba(var(--glow),0.45)]" : "border-[var(--line)] bg-[var(--surface-alt)]")}
                    style={screen === item.id ? { background: `linear-gradient(115deg, rgba(var(--glow),0.18), rgba(var(--glow2),0.12))` } : undefined}
                  >
                    <span className={cn("grid h-7 w-7 shrink-0 place-items-center rounded-[9px] border border-[var(--line)]", screen === item.id ? "bg-white/10 text-[var(--tx)]" : "bg-black/20 text-[var(--tx-mute)]")}>
                      <item.icon size={12} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[9.5px] font-medium">{isAr ? item.ar : item.en}</span>
                      <span className="block truncate text-[7px] text-[var(--tx-mute)]">{item.hint}</span>
                    </span>
                    {screen === item.id && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-[#67e8c7]" />}
                  </button>
                ))}
              </div>
            </section>

            <section className="rounded-[20px] border border-[var(--line)] bg-[var(--surface)] p-3 backdrop-blur-2xl">
              <p className="mb-2 text-[10px] font-semibold">{isAr ? "إجراءات حقيقية" : "Real actions"}</p>
              <div className="space-y-1.5">
                <button type="button" onClick={async () => { setScreen("home"); await analyze(SAMPLE_MEDIA); }} className="press btn-primary flex w-full items-center justify-center gap-1.5 rounded-[12px] py-2.5 text-[9.5px] font-semibold">
                  <Radar size={12} /> {isAr ? "حلّل رابط وسائط حقيقي" : "Analyze a real media link"}
                </button>
                <button type="button" onClick={() => void enqueue(SAMPLE_MEDIA, { title: "Norway coastline — 4K", kind: "video" }).then(() => setScreen("downloads"))} className="press flex w-full items-center justify-center gap-1.5 rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] py-2.5 text-[9px] text-[var(--tx-dim)]">
                  <ArrowDownToLine size={12} /> {isAr ? "حمّل الملف فعليًا الآن" : "Really download it now"}
                </button>
                <input ref={fileRef} type="file" multiple className="hidden" onChange={async (event) => { const files = event.target.files; if (files?.length) { await addLocalFiles(files); setScreen("files"); } event.target.value = ""; }} />
                <button type="button" onClick={() => fileRef.current?.click()} className="press flex w-full items-center justify-center gap-1.5 rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] py-2.5 text-[9px] text-[var(--tx-dim)]">
                  <FolderUp size={12} /> {isAr ? "أضف ملفات من جهازك" : "Add files from your device"}
                </button>
                <button type="button" onClick={() => { setScreen("tube"); notify(isAr ? "DON Tube — فهرس محلي ومشغّل حقيقي" : "DON Tube — local index, real player", "ok"); }} className="press flex w-full items-center justify-center gap-1.5 rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] py-2.5 text-[9px] text-[var(--tx-dim)]">
                  <Play size={12} /> {isAr ? "افتح DON Tube" : "Open DON Tube"}
                </button>
              </div>
              <div className="mt-2 grid grid-cols-3 gap-1.5">
                {[
                  { value: library.length, label: isAr ? "ملف محلي" : "files" },
                  { value: doneCount, label: isAr ? "مكتمل" : "done" },
                  { value: history.length, label: isAr ? "مشاهدة" : "watches" },
                ].map((stat) => (
                  <div key={stat.label} className="rounded-[11px] border border-[var(--line)] bg-black/20 py-1.5 text-center">
                    <p className="font-display text-[13px] font-semibold">{stat.value}</p>
                    <p className="text-[6.5px] text-[var(--tx-mute)]">{stat.label}</p>
                  </div>
                ))}
              </div>
            </section>
          </aside>

          {/* phone */}
          <section className="order-1 flex justify-center lg:order-2">
            <motion.div initial={{ opacity: 0, y: 22, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ type: "spring", stiffness: 170, damping: 22 }}>
              <Phone />
            </motion.div>
          </section>

          {/* right telemetry */}
          <aside className="order-3 space-y-3">
            <section className="rounded-[20px] border border-[var(--line)] bg-[var(--surface)] p-3 backdrop-blur-2xl">
              <div className="flex items-center justify-between">
                <p className="text-[10px] font-semibold">{isAr ? "المحرك الحي" : "Live engine"}</p>
                <span className="flex items-center gap-1 font-display text-[9px] tabular-nums text-[var(--c1)]" dir="ltr">
                  {active.length > 0 && <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#67e8c7]" />}
                  {totalSpeed > 0 ? formatSpeed(totalSpeed) : "idle"}
                </span>
              </div>
              <div className="mt-2 space-y-1.5">
                {tasks.slice(0, 4).map((task) => {
                  const percent = task.total ? Math.min(100, (task.received / task.total) * 100) : 0;
                  return (
                    <div key={task.id} className="rounded-[12px] border border-[var(--line)] bg-[var(--surface-alt)] p-2">
                      <div className="flex items-center justify-between gap-2">
                        <p className="min-w-0 flex-1 truncate text-[8.5px]">{task.title}</p>
                        <span className="shrink-0 font-display text-[7.5px] tabular-nums text-[var(--tx-mute)]">{task.status}</span>
                      </div>
                      <div className="mt-1.5 h-[3px] w-full overflow-hidden rounded-full bg-white/10">
                        <div className="h-full rounded-full bar-fill" style={{ width: `${percent}%` }} />
                      </div>
                      <div className="mt-1 flex items-center justify-between font-display text-[7px] tabular-nums text-[var(--tx-mute)]" dir="ltr">
                        <span>{formatBytes(task.received)} / {task.total ? formatBytes(task.total) : "?"}</span>
                        <span>{task.speed > 0 ? formatSpeed(task.speed) : "—"}</span>
                      </div>
                    </div>
                  );
                })}
                {!tasks.length && <p className="rounded-[12px] border border-dashed border-[var(--line)] py-4 text-center text-[8px] text-[var(--tx-mute)]">{isAr ? "لا مهام بعد — اضغط «حمّل الملف فعليًا الآن»" : "No tasks yet — press “Really download it now”"}</p>}
              </div>
              {toast && <p className="mt-2 rounded-[10px] border border-[var(--line)] bg-black/25 px-2 py-1.5 text-[7.5px] text-[var(--tx-dim)]">{toast.text}</p>}
            </section>

            <section className="rounded-[20px] border border-[var(--line)] bg-[var(--surface)] p-3 backdrop-blur-2xl">
              <div className="flex items-center justify-between">
                <p className="text-[10px] font-semibold">{isAr ? "الثيم النشط" : "Active theme"}</p>
                <span className="rounded-full border border-[var(--line)] bg-black/20 px-1.5 py-[2px] font-display text-[6.5px] text-[var(--tx-mute)]">{theme.id}</span>
              </div>
              <div className="mt-2 overflow-hidden rounded-[12px] border border-[var(--line)]">
                <img src={theme.thumb} alt={isAr ? theme.name.ar : theme.name.en} className="h-20 w-full object-cover" />
              </div>
              <div className="mt-2 flex gap-1">
                {[theme.c1, theme.c2, theme.c3].map((color) => (
                  <span key={color} className="flex-1">
                    <span className="block h-6 rounded-[7px] border border-[var(--line)]" style={{ background: color }} />
                    <span className="mt-0.5 block text-center font-display text-[6px] text-[var(--tx-mute)]" dir="ltr">{color}</span>
                  </span>
                ))}
              </div>
              <div className="mt-2 space-y-1">
                {[
                  { k: isAr ? "الخلفية" : "bg", v: theme.bg },
                  { k: isAr ? "الحواف" : "radius", v: `${theme.radius}px` },
                  { k: isAr ? "التغبيش" : "blur", v: `${theme.blur}px` },
                  { k: isAr ? "الحركة" : "spring", v: `${theme.stiffness}/${theme.damping}` },
                  { k: isAr ? "الوضع" : "mode", v: theme.mode },
                ].map((row) => (
                  <div key={row.k} className="flex items-center justify-between rounded-[8px] bg-black/20 px-2 py-1">
                    <span className="text-[7.5px] text-[var(--tx-mute)]">{row.k}</span>
                    <span className="font-display text-[7.5px]" dir="ltr">{row.v}</span>
                  </div>
                ))}
              </div>
              <p className="mt-2 flex items-center gap-1 text-[7px] text-[var(--tx-mute)]">
                <Sparkles size={8} /> {isAr ? "يتحكم بكل الشاشات والمشغّل والقوائم" : "Controls every screen, player and sheet"}
              </p>
            </section>

            <section className="rounded-[20px] border border-[var(--line)] bg-[var(--surface)] p-3 backdrop-blur-2xl">
              <p className="mb-2 text-[10px] font-semibold">{isAr ? "حسابك المحلي" : "Local account"}</p>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { value: following.length, label: isAr ? "متابعة" : "follows" },
                  { value: library.filter((item) => item.kind === "audio").length, label: isAr ? "صوتيات" : "audio" },
                  { value: library.filter((item) => item.kind === "video").length, label: isAr ? "فيديو" : "video" },
                  { value: formatBytes(storage.quota), label: isAr ? "الحصة" : "quota" },
                ].map((stat) => (
                  <div key={stat.label} className="rounded-[11px] border border-[var(--line)] bg-black/20 py-1.5 text-center">
                    <p className="font-display text-[11px] font-semibold" dir="ltr">{stat.value}</p>
                    <p className="text-[6.5px] text-[var(--tx-mute)]">{stat.label}</p>
                  </div>
                ))}
              </div>
            </section>
          </aside>
        </main>

        {/* engineering ledger */}
        <section className="mt-5 grid gap-3 lg:grid-cols-[1.15fr_0.85fr]">
          <div className="rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4 backdrop-blur-2xl">
            <div className="flex items-center gap-2">
              <ShieldCheck size={14} className="text-[#67e8c7]" />
              <h2 className="text-[13px] font-semibold">{isAr ? "يعمل فعليًا هنا — بلا محاكاة" : "Really working here — no simulation"}</h2>
            </div>
            <div className="mt-3 space-y-1.5">
              {REAL_NOW.map((item) => (
                <div key={item.ar} className="flex items-start gap-2 rounded-[13px] border border-[var(--line)] bg-[var(--surface-alt)] p-2">
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-[9px] border border-[var(--line)] bg-black/20 text-[var(--c2)]"><item.icon size={12} /></span>
                  <p className="text-[8.5px] leading-5 text-[var(--tx-dim)]">{isAr ? item.ar : item.en}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4 backdrop-blur-2xl">
            <div className="flex items-center gap-2">
              <Smartphone size={14} className="text-[var(--c1)]" />
              <h2 className="text-[13px] font-semibold">{isAr ? "في بناء Android — مجلد JP PROJ" : "In the Android build — JP PROJ"}</h2>
            </div>
            <div className="mt-3 space-y-1.5">
              {NATIVE_NEXT.map((item) => (
                <div key={item.label} className="rounded-[13px] border border-[var(--line)] bg-[var(--surface-alt)] p-2">
                  <p className="font-display text-[9px] font-medium" dir="ltr">{item.label}</p>
                  <p className="mt-0.5 text-[7.5px] leading-4 text-[var(--tx-mute)]">{item.detail}</p>
                </div>
              ))}
            </div>
            <p className="mt-3 text-center text-[7px] text-[var(--tx-mute)]">{isAr ? "المسؤولية على المستخدم في احترام حقوق النشر." : "You are responsible for respecting copyright."}</p>
          </div>
        </section>

        <footer className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-[var(--line)] pt-3 text-[7.5px] text-[var(--tx-mute)]">
          <span>DON · {isAr ? "تطبيق محلي بالكامل" : "fully local app"} · IndexedDB + MediaRecorder + Canvas</span>
          <span className="font-display" dir="ltr">theme: {theme.id} · lang: {lang} · screens: {NAV.length}</span>
        </footer>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <DonProvider>
      <Console />
    </DonProvider>
  );
}
