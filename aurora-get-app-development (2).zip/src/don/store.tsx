import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  CATALOG,
  CHANNELS,
  THEMES,
  parseLink,
  themeById,
  translate,
  youtubeThumb,
  type Lang,
  type MediaKind,
  type ThemeId,
  type ThemeTokens,
  type TKey,
  type TubeVideo,
} from "./core";
import {
  copyText,
  guessKindFromMime,
  idbDelete,
  idbEstimate,
  idbGet,
  idbPut,
  probeRemote,
  readPageMeta,
  safeFilename,
  type PageMeta,
  type ProbeResult,
} from "./media";

export type Screen = "home" | "tube" | "downloads" | "browser" | "files" | "tools" | "settings";
export type RepeatMode = "off" | "one" | "all";

export interface LibraryItem {
  id: string;
  title: string;
  kind: MediaKind;
  size: number;
  origin: "download" | "local" | "edit" | "tube";
  addedAt: number;
  blobKey?: string;
  remoteUrl?: string;
  poster?: string;
  duration?: number;
  width?: number;
  height?: number;
  sourceUrl?: string;
  channelName?: string;
}

export type TaskStatus = "queued" | "active" | "paused" | "done" | "error" | "blocked";

export interface DownloadTask {
  id: string;
  url: string;
  filename: string;
  title: string;
  kind: MediaKind;
  poster?: string;
  total: number;
  received: number;
  speed: number;
  eta: number;
  status: TaskStatus;
  error?: string;
  rangeSupported: boolean;
  contentType?: string;
  samples: number[];
  startedAt: number;
  blobKey: string;
  libraryId?: string;
}

export interface Profile {
  name: string;
  handle: string;
  bio: string;
  color: string;
  createdAt: number;
}

export interface Settings {
  maxConcurrent: number;
  autoStart: boolean;
  notifications: boolean;
  wallpaper: boolean;
  reduceMotion: boolean;
  autoplay: boolean;
  sleepMinutes: number;
  defaultSpeed: number;
  repeatMode: RepeatMode;
  dataSaver: boolean;
  keepOriginal: boolean;
}

export interface HistoryEntry {
  videoId: string;
  at: number;
  progress: number;
}

export interface Note {
  id: string;
  text: string;
  at: number;
  time?: number;
}

export interface StageState {
  key: TKey;
  status: "idle" | "running" | "done" | "error";
  ms?: number;
  detail?: string;
}

export interface Analysis {
  input: string;
  url: string;
  host: string;
  provider: string;
  youtubeId: string | null;
  kind: MediaKind | null;
  title?: string;
  description?: string;
  poster?: string;
  size?: number;
  contentType?: string;
  rangeSupported: boolean;
  candidates: { url: string; kind: MediaKind; label: string; size?: number }[];
  stages: StageState[];
  error?: string;
  finishedAt: number;
}

export interface PlayerTarget {
  src: string;
  title: string;
  poster?: string;
  kind: MediaKind;
  libraryId?: string;
  videoId?: string;
  channelId?: string;
  vertical?: boolean;
  remote?: boolean;
}

interface Persisted {
  version: 3;
  lang: Lang;
  themeId: ThemeId;
  screen: Screen;
  settings: Settings;
  profile: Profile;
  following: string[];
  history: HistoryEntry[];
  likes: string[];
  dislikes: string[];
  saved: string[];
  notes: Record<string, Note[]>;
  hidden: string[];
  library: LibraryItem[];
  tasks: DownloadTask[];
}

const STORAGE_KEY = "don.state.v3";

const DEFAULT_SETTINGS: Settings = {
  maxConcurrent: 2,
  autoStart: true,
  notifications: false,
  wallpaper: true,
  reduceMotion: false,
  autoplay: true,
  sleepMinutes: 15,
  defaultSpeed: 1,
  repeatMode: "off",
  dataSaver: false,
  keepOriginal: true,
};

const DEFAULT_PROFILE: Profile = {
  name: "DON User",
  handle: "@don.local",
  bio: "Local profile — nothing leaves this device.",
  color: "#9B72CB",
  createdAt: Date.now(),
};

function defaultState(): Persisted {
  return {
    version: 3,
    lang: "ar",
    themeId: "aurora",
    screen: "home",
    settings: { ...DEFAULT_SETTINGS },
    profile: { ...DEFAULT_PROFILE },
    following: ["c3"],
    history: [],
    likes: [],
    dislikes: [],
    saved: [],
    notes: {},
    hidden: [],
    library: [],
    tasks: [],
  };
}

function loadState(): Persisted {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw) as Partial<Persisted>;
    const base = defaultState();
    return {
      ...base,
      ...parsed,
      settings: { ...base.settings, ...(parsed.settings || {}) },
      profile: { ...base.profile, ...(parsed.profile || {}) },
      notes: parsed.notes || {},
      library: parsed.library || [],
      tasks: (parsed.tasks || []).map((task) =>
        task.status === "active" || task.status === "queued" ? { ...task, status: "paused" as TaskStatus, speed: 0 } : task,
      ),
    };
  } catch {
    return defaultState();
  }
}

interface DonContextValue {
  lang: Lang;
  setLang: (lang: Lang) => void;
  t: (key: TKey) => string;
  dir: "rtl" | "ltr";
  themeId: ThemeId;
  theme: ThemeTokens;
  setThemeId: (id: ThemeId) => void;
  screen: Screen;
  setScreen: (screen: Screen) => void;
  settings: Settings;
  updateSettings: (patch: Partial<Settings>) => void;
  profile: Profile;
  updateProfile: (patch: Partial<Profile>) => void;
  exportProfile: () => void;
  importProfile: (file: File) => Promise<void>;
  following: string[];
  toggleFollow: (channelId: string) => void;
  history: HistoryEntry[];
  recordWatch: (videoId: string, progress: number) => void;
  clearHistory: () => void;
  likes: string[];
  dislikes: string[];
  toggleLike: (videoId: string) => void;
  toggleDislike: (videoId: string) => void;
  saved: string[];
  toggleSaved: (videoId: string) => void;
  notes: Record<string, Note[]>;
  addNote: (videoId: string, text: string, time?: number) => void;
  removeNote: (videoId: string, noteId: string) => void;
  hidden: string[];
  hideVideo: (videoId: string) => void;
  library: LibraryItem[];
  libraryUrls: Record<string, string>;
  addLocalFiles: (files: FileList | File[]) => Promise<number>;
  removeLibraryItem: (id: string) => Promise<void>;
  tasks: DownloadTask[];
  enqueue: (url: string, options?: { title?: string; kind?: MediaKind; poster?: string; filename?: string }) => Promise<void>;
  pauseTask: (id: string) => void;
  resumeTask: (id: string) => void;
  cancelTask: (id: string) => Promise<void>;
  retryTask: (id: string) => void;
  removeTask: (id: string) => Promise<void>;
  openTaskResult: (id: string) => void;
  analysis: Analysis | null;
  analyzing: boolean;
  analyze: (input: string) => Promise<void>;
  player: PlayerTarget | null;
  play: (target: PlayerTarget) => void;
  stopPlayer: () => void;
  toast: { id: number; text: string; tone: "ok" | "warn" | "error" } | null;
  notify: (text: string, tone?: "ok" | "warn" | "error") => void;
  storage: { usage: number; quota: number };
  refreshStorage: () => Promise<void>;
  copy: (text: string, label?: string) => Promise<void>;
  catalog: TubeVideo[];
  videoById: (id: string) => TubeVideo | undefined;
  recommendations: (seedVideoId?: string) => TubeVideo[];
}

const DonContext = createContext<DonContextValue | null>(null);

export function DonProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Persisted>(() => loadState());
  const [libraryUrls, setLibraryUrls] = useState<Record<string, string>>({});
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [player, setPlayer] = useState<PlayerTarget | null>(null);
  const [toast, setToast] = useState<DonContextValue["toast"]>(null);
  const [storage, setStorage] = useState({ usage: 0, quota: 0 });

  const controllers = useRef(new Map<string, AbortController>());
  const stateRef = useRef(state);
  const toastTimer = useRef<number | null>(null);
  stateRef.current = state;

  const theme = useMemo(() => themeById(state.themeId), [state.themeId]);
  const dir = state.lang === "ar" ? "rtl" : "ltr";
  const t = useCallback((key: TKey) => translate(state.lang, key), [state.lang]);

  /* ---------------- persistence ---------------- */
  useEffect(() => {
    const id = window.setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      } catch {
        /* quota exceeded — keep running in memory */
      }
    }, 220);
    return () => window.clearTimeout(id);
  }, [state]);

  const patch = useCallback((updater: (prev: Persisted) => Persisted) => {
    setState((prev) => updater(prev));
  }, []);

  const notify = useCallback((text: string, tone: "ok" | "warn" | "error" = "ok") => {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    setToast({ id: Date.now(), text, tone });
    toastTimer.current = window.setTimeout(() => setToast(null), 3600);
  }, []);

  const refreshStorage = useCallback(async () => {
    const estimate = await idbEstimate();
    setStorage(estimate);
  }, []);

  /* ---------------- restore local blobs on boot ---------------- */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const items = stateRef.current.library.filter((item) => item.blobKey);
      const entries: [string, string][] = [];
      for (const item of items) {
        try {
          const blob = await idbGet(item.blobKey as string);
          if (blob) entries.push([item.id, URL.createObjectURL(blob)]);
        } catch {
          /* missing blob — item stays listed with its remote url if any */
        }
      }
      if (!cancelled && entries.length) setLibraryUrls((prev) => ({ ...prev, ...Object.fromEntries(entries) }));
      await refreshStorage();
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------------- helpers ---------------- */
  const setTasks = useCallback((updater: (tasks: DownloadTask[]) => DownloadTask[]) => {
    patch((prev) => ({ ...prev, tasks: updater(prev.tasks) }));
  }, [patch]);

  const updateTask = useCallback((id: string, values: Partial<DownloadTask>) => {
    setTasks((tasks) => tasks.map((task) => (task.id === id ? { ...task, ...values } : task)));
  }, [setTasks]);

  const addLibraryItem = useCallback(
    (item: LibraryItem, url?: string) => {
      patch((prev) => ({ ...prev, library: [item, ...prev.library.filter((x) => x.id !== item.id)] }));
      if (url) setLibraryUrls((prev) => ({ ...prev, [item.id]: url }));
    },
    [patch],
  );

  /* ---------------- real download engine ---------------- */
  const persistPartial = useCallback(async (task: DownloadTask, chunks: BlobPart[]) => {
    if (!chunks.length) return;
    try {
      await idbPut(`${task.blobKey}.part`, new Blob(chunks));
    } catch {
      /* storage full — resume will restart */
    }
  }, []);

  const runTask = useCallback(
    async (id: string) => {
      const task = stateRef.current.tasks.find((item) => item.id === id);
      if (!task || controllers.current.has(id)) return;
      const controller = new AbortController();
      controllers.current.set(id, controller);

      let received = 0;
      const chunks: BlobPart[] = [];
      const startedAt = performance.now();
      let windowBytes = 0;
      let windowStart = performance.now();

      updateTask(id, { status: "active", error: undefined, speed: 0 });

      try {
        // Real resume: reuse the stored partial blob when the server supports ranges.
        const partial = await idbGet(`${task.blobKey}.part`);
        const headers: Record<string, string> = {};
        if (partial && partial.size > 0 && task.rangeSupported) {
          headers.Range = `bytes=${partial.size}-`;
          chunks.push(partial);
          received = partial.size;
        } else if (partial) {
          await idbDelete(`${task.blobKey}.part`);
        }

        let response: Response;
        try {
          response = await fetch(task.url, { headers, signal: controller.signal, cache: "no-store" });
        } catch (error) {
          if (controller.signal.aborted) throw new Error("__paused__");
          throw new Error("network-blocked");
        }

        if (!response.ok && response.status !== 206) {
          updateTask(id, { status: "error", error: `HTTP ${response.status}`, speed: 0 });
          controllers.current.delete(id);
          return;
        }

        const rangeSupported = response.status === 206 || (response.headers.get("Accept-Ranges") || "").includes("bytes");
        const contentType = response.headers.get("Content-Type") || task.contentType;
        const lengthHeader = Number(response.headers.get("Content-Length") || 0);
        const contentRange = response.headers.get("Content-Range") || "";
        const totalFromRange = Number((contentRange.match(/\/(\d+)$/) || [])[1] || 0);
        const total = totalFromRange || (response.status === 206 ? received + lengthHeader : lengthHeader) || task.total;

        updateTask(id, { rangeSupported, contentType, total: total || 0 });

        const pushSample = () => {
          const now = performance.now();
          const elapsed = (now - windowStart) / 1000;
          if (elapsed >= 0.4) {
            const speed = windowBytes / elapsed;
            windowBytes = 0;
            windowStart = now;
            const remaining = total > 0 ? Math.max(0, total - received) : 0;
            setTasks((tasks) =>
              tasks.map((item) =>
                item.id === id
                  ? {
                      ...item,
                      speed,
                      eta: speed > 0 ? remaining / speed : 0,
                      samples: [...item.samples.slice(-23), Math.min(100, Math.round((speed / 12_000_000) * 100))],
                    }
                  : item,
              ),
            );
          }
        };

        if (response.body) {
          const reader = response.body.getReader();
          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            if (value) {
              chunks.push(value);
              received += value.byteLength;
              windowBytes += value.byteLength;
              pushSample();
              const current = received;
              setTasks((tasks) => tasks.map((item) => (item.id === id ? { ...item, received: current } : item)));
            }
          }
        } else {
          const buffer = await response.arrayBuffer();
          chunks.push(buffer);
          received += buffer.byteLength;
        }

        const blob = new Blob(chunks, { type: contentType || "application/octet-stream" });
        await idbPut(task.blobKey, blob);
        await idbDelete(`${task.blobKey}.part`);
        const objectUrl = URL.createObjectURL(blob);
        const libraryId = `lib-${task.id}`;
        const kind = guessKindFromMime(contentType, task.filename);
        addLibraryItem(
          {
            id: libraryId,
            title: task.title,
            kind,
            size: blob.size,
            origin: "download",
            addedAt: Date.now(),
            blobKey: task.blobKey,
            poster: task.poster,
            sourceUrl: task.url,
          },
          objectUrl,
        );
        updateTask(id, {
          status: "done",
          received: blob.size,
          total: blob.size || total,
          speed: 0,
          eta: 0,
          libraryId,
          kind,
        });
        controllers.current.delete(id);
        await refreshStorage();
        notify(`${task.title} · ${translate(stateRef.current.lang, "done")}`, "ok");
        if (stateRef.current.settings.notifications && "Notification" in window && Notification.permission === "granted") {
          try {
            new Notification("DON", { body: `${task.title} — ${translate(stateRef.current.lang, "done")}` });
          } catch {
            /* notification blocked by the browser */
          }
        }
        void startedAt;
      } catch (error) {
        controllers.current.delete(id);
        const message = error instanceof Error ? error.message : String(error);
        if (message === "__paused__" || controller.signal.aborted) {
          await persistPartial(task, chunks);
          updateTask(id, { status: "paused", received, speed: 0 });
          return;
        }
        if (message === "network-blocked") {
          updateTask(id, {
            status: "blocked",
            speed: 0,
            error: "cors",
          });
          notify(translate(stateRef.current.lang, "blockedFrame"), "warn");
          return;
        }
        updateTask(id, { status: "error", error: message, speed: 0 });
      }
    },
    [addLibraryItem, notify, persistPartial, refreshStorage, setTasks, updateTask],
  );

  /* ---------------- queue scheduler ---------------- */
  useEffect(() => {
    const running = state.tasks.filter((task) => task.status === "active").length;
    let slots = Math.max(0, state.settings.maxConcurrent - running);
    if (slots <= 0) return;
    state.tasks
      .filter((task) => task.status === "queued")
      .sort((a, b) => a.startedAt - b.startedAt)
      .forEach((task) => {
        if (slots <= 0) return;
        slots -= 1;
        void runTask(task.id);
      });
  }, [state.tasks, state.settings.maxConcurrent, runTask]);

  const enqueue = useCallback<DonContextValue["enqueue"]>(
    async (url, options) => {
      const parsed = parseLink(url);
      if (!parsed) {
        notify(state.lang === "ar" ? "رابط غير صالح" : "Invalid link", "error");
        return;
      }
      const probe = await probeRemote(parsed.raw);
      const filename = options?.filename || safeFilename(parsed.raw);
      const kind = options?.kind || (probe.contentType ? guessKindFromMime(probe.contentType, filename) : parsed.mediaType) || "file";
      const task: DownloadTask = {
        id: `task-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        url: parsed.raw,
        filename,
        title: options?.title || filename,
        kind,
        poster: options?.poster,
        total: probe.size || 0,
        received: 0,
        speed: 0,
        eta: 0,
        status: state.settings.autoStart ? "queued" : "paused",
        rangeSupported: probe.rangeSupported,
        contentType: probe.contentType,
        samples: [],
        startedAt: Date.now(),
        blobKey: `blob-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      };
      setTasks((tasks) => [task, ...tasks]);
      notify(
        probe.ok
          ? `${task.title} · ${probe.rangeSupported ? translate(state.lang, "resumeSupport") : translate(state.lang, "noResume")}`
          : `${task.title} · ${probe.error || "HEAD blocked"}`,
        probe.ok ? "ok" : "warn",
      );
    },
    [notify, setTasks, state.lang, state.settings.autoStart],
  );

  const pauseTask = useCallback(
    (id: string) => {
      const controller = controllers.current.get(id);
      if (controller) {
        controller.abort();
        controllers.current.delete(id);
      } else {
        updateTask(id, { status: "paused", speed: 0 });
      }
    },
    [updateTask],
  );

  const resumeTask = useCallback(
    (id: string) => {
      updateTask(id, { status: "queued", speed: 0 });
    },
    [updateTask],
  );

  const retryTask = useCallback(
    async (id: string) => {
      const task = stateRef.current.tasks.find((item) => item.id === id);
      if (!task) return;
      const probe = await probeRemote(task.url);
      updateTask(id, {
        status: "queued",
        error: undefined,
        received: 0,
        speed: 0,
        total: probe.size || task.total,
        rangeSupported: probe.rangeSupported,
        samples: [],
      });
      try {
        await idbDelete(`${task.blobKey}.part`);
      } catch {
        /* nothing stored yet */
      }
    },
    [updateTask],
  );

  const cancelTask = useCallback(
    async (id: string) => {
      const task = stateRef.current.tasks.find((item) => item.id === id);
      controllers.current.get(id)?.abort();
      controllers.current.delete(id);
      if (task) {
        try {
          await idbDelete(`${task.blobKey}.part`);
        } catch {
          /* ignore */
        }
      }
      setTasks((tasks) => tasks.filter((item) => item.id !== id));
    },
    [setTasks],
  );

  const removeTask = useCallback(
    async (id: string) => {
      const task = stateRef.current.tasks.find((item) => item.id === id);
      controllers.current.get(id)?.abort();
      controllers.current.delete(id);
      if (task) {
        try {
          await idbDelete(`${task.blobKey}.part`);
          await idbDelete(task.blobKey);
        } catch {
          /* ignore */
        }
        if (task.libraryId) {
          const url = libraryUrls[task.libraryId];
          if (url) URL.revokeObjectURL(url);
          patch((prev) => ({ ...prev, library: prev.library.filter((item) => item.id !== task.libraryId) }));
          setLibraryUrls((prev) => {
            const next = { ...prev };
            delete next[task.libraryId as string];
            return next;
          });
        }
      }
      setTasks((tasks) => tasks.filter((item) => item.id !== id));
      await refreshStorage();
    },
    [libraryUrls, patch, refreshStorage, setTasks],
  );

  const openTaskResult = useCallback(
    (id: string) => {
      const task = stateRef.current.tasks.find((item) => item.id === id);
      if (!task?.libraryId) return;
      const item = stateRef.current.library.find((entry) => entry.id === task.libraryId);
      const src = libraryUrls[task.libraryId];
      if (!item || !src) return;
      setPlayer({ src, title: item.title, poster: item.poster, kind: item.kind, libraryId: item.id });
    },
    [libraryUrls],
  );

  /* ---------------- local files ---------------- */
  const addLocalFiles = useCallback<DonContextValue["addLocalFiles"]>(
    async (files) => {
      const list = Array.from(files);
      let added = 0;
      for (const file of list) {
        const id = `lib-local-${Date.now()}-${added}`;
        const blobKey = `local-${id}`;
        try {
          await idbPut(blobKey, file);
        } catch {
          notify(state.lang === "ar" ? "تعذّر حفظ الملف محليًا" : "Could not store the file locally", "error");
          continue;
        }
        const url = URL.createObjectURL(file);
        const kind = guessKindFromMime(file.type, file.name);
        addLibraryItem(
          {
            id,
            title: file.name,
            kind,
            size: file.size,
            origin: "local",
            addedAt: Date.now(),
            blobKey,
          },
          url,
        );
        added += 1;
      }
      await refreshStorage();
      if (added) notify(`${added} · ${translate(state.lang, "savedOk")}`, "ok");
      return added;
    },
    [addLibraryItem, notify, refreshStorage, state.lang],
  );

  const removeLibraryItem = useCallback<DonContextValue["removeLibraryItem"]>(
    async (id) => {
      const item = stateRef.current.library.find((entry) => entry.id === id);
      if (item?.blobKey) {
        try {
          await idbDelete(item.blobKey);
        } catch {
          /* ignore */
        }
      }
      const url = libraryUrls[id];
      if (url) URL.revokeObjectURL(url);
      setLibraryUrls((prev) => {
        const next = { ...prev };
        delete next[id];
        return next;
      });
      patch((prev) => ({ ...prev, library: prev.library.filter((entry) => entry.id !== id) }));
      await refreshStorage();
    },
    [libraryUrls, patch, refreshStorage],
  );

  /* ---------------- real link analysis ---------------- */
  const analyze = useCallback<DonContextValue["analyze"]>(
    async (input) => {
      const parsed = parseLink(input);
      if (!parsed) {
        notify(state.lang === "ar" ? "رابط غير صالح" : "Invalid link", "error");
        return;
      }
      setAnalyzing(true);
      const stages: StageState[] = [
        { key: "stage0", status: "running" },
        { key: "stage1", status: "idle" },
        { key: "stage2", status: "idle" },
        { key: "stage3", status: "idle" },
      ];
      const publish = (next: StageState[], partial: Partial<Analysis>) =>
        setAnalysis({
          input: parsed.raw,
          url: parsed.raw,
          host: parsed.host,
          provider: parsed.provider,
          youtubeId: parsed.youtubeId,
          kind: parsed.mediaType,
          candidates: [],
          rangeSupported: false,
          stages: next,
          finishedAt: Date.now(),
          ...partial,
        });
      publish(stages, {});

      // Stage 0 — normalization (local, instant).
      const t0 = performance.now();
      stages[0] = { ...stages[0], status: "done", ms: Math.max(1, performance.now() - t0), detail: parsed.host };
      publish(stages, {});

      // Stage 1 — real HEAD / ranged GET.
      stages[1] = { ...stages[1], status: "running" };
      publish(stages, {});
      const t1 = performance.now();
      const probe: ProbeResult = await probeRemote(parsed.raw);
      stages[1] = {
        ...stages[1],
        status: probe.ok ? "done" : "error",
        ms: Math.round(performance.now() - t1),
        detail: probe.ok ? `${probe.contentType || "unknown"} · ${probe.size ? `${probe.size} bytes` : "no length"}` : probe.error,
      };
      publish(stages, {
        size: probe.size,
        contentType: probe.contentType,
        rangeSupported: probe.rangeSupported,
      });

      // Stage 2 — real document parse for media candidates.
      stages[2] = { ...stages[2], status: "running" };
      publish(stages, {});
      const t2 = performance.now();
      let meta: PageMeta | null = null;
      if (!parsed.isMedia) {
        meta = await readPageMeta(parsed.raw);
      }
      const candidates: Analysis["candidates"] = [];
      if (parsed.isMedia) {
        candidates.push({
          url: parsed.raw,
          kind: parsed.mediaType || "file",
          label: safeFilename(parsed.raw),
          size: probe.size,
        });
      }
      if (meta?.ok) {
        meta.videos.forEach((src) => candidates.push({ url: src, kind: "video", label: safeFilename(src) }));
        meta.audios.forEach((src) => candidates.push({ url: src, kind: "audio", label: safeFilename(src) }));
      }
      stages[2] = {
        ...stages[2],
        status: parsed.isMedia ? "done" : meta?.ok ? "done" : "error",
        ms: Math.round(performance.now() - t2),
        detail: parsed.isMedia
          ? "direct media"
          : meta?.ok
            ? `${candidates.length} media urls`
            : meta?.error || "blocked",
      };
      publish(stages, {
        title: meta?.title,
        description: meta?.description,
        poster: meta?.image,
        candidates,
      });

      // Stage 3 — provider detection.
      const t3 = performance.now();
      stages[3] = {
        ...stages[3],
        status: "done",
        ms: Math.round(performance.now() - t3),
        detail: parsed.provider + (parsed.youtubeId ? ` · ${parsed.youtubeId}` : ""),
      };
      publish(stages, {
        poster: parsed.youtubeId ? youtubeThumb(parsed.youtubeId) : analysis?.poster || meta?.image,
        candidates: parsed.youtubeId && !candidates.length
          ? [{ url: parsed.raw, kind: "video", label: `youtube:${parsed.youtubeId}` }]
          : candidates,
      });
      setAnalyzing(false);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [notify, state.lang],
  );

  /* ---------------- tube state ---------------- */
  const toggleFollow = useCallback(
    (channelId: string) => {
      patch((prev) => ({
        ...prev,
        following: prev.following.includes(channelId)
          ? prev.following.filter((id) => id !== channelId)
          : [...prev.following, channelId],
      }));
    },
    [patch],
  );

  const recordWatch = useCallback(
    (videoId: string, progress: number) => {
      patch((prev) => {
        const rest = prev.history.filter((entry) => entry.videoId !== videoId);
        return { ...prev, history: [{ videoId, at: Date.now(), progress }, ...rest].slice(0, 120) };
      });
    },
    [patch],
  );

  const clearHistory = useCallback(() => patch((prev) => ({ ...prev, history: [] })), [patch]);

  const toggleLike = useCallback(
    (videoId: string) =>
      patch((prev) => ({
        ...prev,
        likes: prev.likes.includes(videoId) ? prev.likes.filter((id) => id !== videoId) : [...prev.likes, videoId],
        dislikes: prev.dislikes.filter((id) => id !== videoId),
      })),
    [patch],
  );

  const toggleDislike = useCallback(
    (videoId: string) =>
      patch((prev) => ({
        ...prev,
        dislikes: prev.dislikes.includes(videoId) ? prev.dislikes.filter((id) => id !== videoId) : [...prev.dislikes, videoId],
        likes: prev.likes.filter((id) => id !== videoId),
      })),
    [patch],
  );

  const toggleSaved = useCallback(
    (videoId: string) =>
      patch((prev) => ({
        ...prev,
        saved: prev.saved.includes(videoId) ? prev.saved.filter((id) => id !== videoId) : [...prev.saved, videoId],
      })),
    [patch],
  );

  const addNote = useCallback(
    (videoId: string, text: string, time?: number) => {
      const trimmed = text.trim();
      if (!trimmed) return;
      patch((prev) => ({
        ...prev,
        notes: {
          ...prev.notes,
          [videoId]: [{ id: `note-${Date.now()}`, text: trimmed, at: Date.now(), time }, ...(prev.notes[videoId] || [])],
        },
      }));
    },
    [patch],
  );

  const removeNote = useCallback(
    (videoId: string, noteId: string) =>
      patch((prev) => ({
        ...prev,
        notes: { ...prev.notes, [videoId]: (prev.notes[videoId] || []).filter((note) => note.id !== noteId) },
      })),
    [patch],
  );

  const hideVideo = useCallback(
    (videoId: string) => patch((prev) => ({ ...prev, hidden: [...new Set([...prev.hidden, videoId])] })),
    [patch],
  );

  const updateSettings = useCallback(
    (values: Partial<Settings>) => {
      patch((prev) => ({ ...prev, settings: { ...prev.settings, ...values } }));
      if (values.notifications && "Notification" in window && Notification.permission === "default") {
        void Notification.requestPermission();
      }
    },
    [patch],
  );

  const updateProfile = useCallback(
    (values: Partial<Profile>) => patch((prev) => ({ ...prev, profile: { ...prev.profile, ...values } })),
    [patch],
  );

  const exportProfile = useCallback(() => {
    const payload = {
      app: "DON",
      version: 3,
      exportedAt: new Date().toISOString(),
      profile: state.profile,
      following: state.following,
      likes: state.likes,
      saved: state.saved,
      notes: state.notes,
      history: state.history,
      settings: state.settings,
      themeId: state.themeId,
      lang: state.lang,
      libraryIndex: state.library.map((item) => ({
        title: item.title,
        kind: item.kind,
        size: item.size,
        origin: item.origin,
        sourceUrl: item.sourceUrl,
      })),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `don-profile-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 3000);
    notify(translate(state.lang, "exportProfile"), "ok");
  }, [notify, state]);

  const importProfile = useCallback<DonContextValue["importProfile"]>(
    async (file) => {
      try {
        const text = await file.text();
        const parsed = JSON.parse(text) as Partial<Persisted> & { app?: string };
        patch((prev) => ({
          ...prev,
          profile: { ...prev.profile, ...(parsed.profile || {}) },
          following: parsed.following || prev.following,
          likes: parsed.likes || prev.likes,
          saved: parsed.saved || prev.saved,
          notes: parsed.notes || prev.notes,
          history: parsed.history || prev.history,
          settings: { ...prev.settings, ...(parsed.settings || {}) },
          themeId: (parsed.themeId as ThemeId) || prev.themeId,
          lang: (parsed.lang as Lang) || prev.lang,
        }));
        notify(translate(state.lang, "importProfile"), "ok");
      } catch {
        notify(state.lang === "ar" ? "ملف غير صالح" : "Invalid file", "error");
      }
    },
    [notify, patch, state.lang],
  );

  const copy = useCallback(
    async (text: string, label?: string) => {
      const ok = await copyText(text);
      notify(ok ? `${label || translate(state.lang, "copyLink")} · ${translate(state.lang, "copied")}` : state.lang === "ar" ? "تعذّر النسخ" : "Copy failed", ok ? "ok" : "error");
    },
    [notify, state.lang],
  );

  const videoById = useCallback((id: string) => CATALOG.find((video) => video.id === id), []);

  /** Real recommendation scoring from watch history, likes and follows. */
  const recommendations = useCallback(
    (seedVideoId?: string) => {
      const seed = seedVideoId ? CATALOG.find((video) => video.id === seedVideoId) : undefined;
      const watchedTags = new Map<string, number>();
      state.history.slice(0, 40).forEach((entry, index) => {
        const video = CATALOG.find((item) => item.id === entry.videoId);
        if (!video) return;
        const weight = 1 / (1 + index * 0.15);
        video.tags.forEach((tag) => watchedTags.set(tag, (watchedTags.get(tag) || 0) + weight));
      });
      state.likes.forEach((id) => {
        const video = CATALOG.find((item) => item.id === id);
        video?.tags.forEach((tag) => watchedTags.set(tag, (watchedTags.get(tag) || 0) + 1.4));
      });
      if (seed) seed.tags.forEach((tag) => watchedTags.set(tag, (watchedTags.get(tag) || 0) + 2));

      const scored = CATALOG.filter((video) => !state.hidden.includes(video.id)).map((video) => {
        let score = video.tags.reduce((sum, tag) => sum + (watchedTags.get(tag) || 0), 0);
        if (state.following.includes(video.channelId)) score += 2.5;
        if (state.dislikes.includes(video.id)) score -= 4;
        score += Math.min(2, video.views / 3_000_000);
        score -= video.publishedDaysAgo / 120;
        if (seed && video.id === seed.id) score -= 10;
        return { video, score };
      });
      return scored.sort((a, b) => b.score - a.score).map((entry) => entry.video);
    },
    [state.following, state.hidden, state.history, state.likes, state.dislikes],
  );

  const value = useMemo<DonContextValue>(
    () => ({
      lang: state.lang,
      setLang: (lang) => patch((prev) => ({ ...prev, lang })),
      t,
      dir,
      themeId: state.themeId,
      theme,
      setThemeId: (themeId) => patch((prev) => ({ ...prev, themeId })),
      screen: state.screen,
      setScreen: (screen) => patch((prev) => ({ ...prev, screen })),
      settings: state.settings,
      updateSettings,
      profile: state.profile,
      updateProfile,
      exportProfile,
      importProfile,
      following: state.following,
      toggleFollow,
      history: state.history,
      recordWatch,
      clearHistory,
      likes: state.likes,
      dislikes: state.dislikes,
      toggleLike,
      toggleDislike,
      saved: state.saved,
      toggleSaved,
      notes: state.notes,
      addNote,
      removeNote,
      hidden: state.hidden,
      hideVideo,
      library: state.library,
      libraryUrls,
      addLocalFiles,
      removeLibraryItem,
      tasks: state.tasks,
      enqueue,
      pauseTask,
      resumeTask,
      cancelTask,
      retryTask,
      removeTask,
      openTaskResult,
      analysis,
      analyzing,
      analyze,
      player,
      play: (target) => setPlayer(target),
      stopPlayer: () => setPlayer(null),
      toast,
      notify,
      storage,
      refreshStorage,
      copy,
      catalog: CATALOG,
      videoById,
      recommendations,
    }),
    [
      state,
      t,
      dir,
      theme,
      patch,
      updateSettings,
      exportProfile,
      importProfile,
      toggleFollow,
      recordWatch,
      clearHistory,
      toggleLike,
      toggleDislike,
      toggleSaved,
      addNote,
      removeNote,
      hideVideo,
      libraryUrls,
      addLocalFiles,
      removeLibraryItem,
      enqueue,
      pauseTask,
      resumeTask,
      cancelTask,
      retryTask,
      removeTask,
      openTaskResult,
      analysis,
      analyzing,
      analyze,
      player,
      toast,
      notify,
      storage,
      refreshStorage,
      copy,
      videoById,
      recommendations,
    ],
  );

  return <DonContext.Provider value={value}>{children}</DonContext.Provider>;
}

export function useDon(): DonContextValue {
  const context = useContext(DonContext);
  if (!context) throw new Error("useDon must be used inside DonProvider");
  return context;
}

export { THEMES, CHANNELS, CATALOG };
