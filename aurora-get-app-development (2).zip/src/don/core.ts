/**
 * DON — core design tokens, localization and real media catalog.
 * Everything here is real data used by the running app (no mock screens).
 */

export type Lang = "ar" | "en";
export type ThemeId =
  | "aurora"
  | "ocean"
  | "sunset"
  | "emerald"
  | "mono"
  | "neon"
  | "royal"
  | "sakura";

export interface ThemeTokens {
  id: ThemeId;
  name: { ar: string; en: string };
  mode: "dark" | "light";
  /** accent gradient stops */
  c1: string;
  c2: string;
  c3: string;
  /** surfaces */
  bg: string;
  bgSoft: string;
  surface: string;
  surfaceAlt: string;
  border: string;
  text: string;
  textDim: string;
  textMute: string;
  /** glow rgb triplets */
  glow: string;
  glow2: string;
  /** shape + motion */
  radius: number;
  blur: number;
  stiffness: number;
  damping: number;
  grain: number;
  /** real wallpaper for the theme */
  image: string;
  thumb: string;
}

export const THEMES: ThemeTokens[] = [
  {
    id: "aurora",
    name: { ar: "أورورا", en: "Aurora" },
    mode: "dark",
    c1: "#4285F4",
    c2: "#9B72CB",
    c3: "#D96570",
    bg: "#07080d",
    bgSoft: "#0c0e16",
    surface: "rgba(255,255,255,0.055)",
    surfaceAlt: "rgba(255,255,255,0.028)",
    border: "rgba(255,255,255,0.09)",
    text: "#f4f6fb",
    textDim: "rgba(244,246,251,0.62)",
    textMute: "rgba(244,246,251,0.34)",
    glow: "66,133,244",
    glow2: "155,114,203",
    radius: 24,
    blur: 22,
    stiffness: 320,
    damping: 28,
    grain: 0.2,
    image:
      "https://images.pexels.com/photos/28357080/pexels-photo-28357080.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    thumb:
      "https://images.pexels.com/photos/28357080/pexels-photo-28357080.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=220&w=320",
  },
  {
    id: "ocean",
    name: { ar: "محيط", en: "Ocean" },
    mode: "dark",
    c1: "#22d3ee",
    c2: "#2563eb",
    c3: "#818cf8",
    bg: "#04121a",
    bgSoft: "#071c26",
    surface: "rgba(186,230,253,0.06)",
    surfaceAlt: "rgba(186,230,253,0.03)",
    border: "rgba(186,230,253,0.11)",
    text: "#eaf9ff",
    textDim: "rgba(234,249,255,0.62)",
    textMute: "rgba(234,249,255,0.33)",
    glow: "34,211,238",
    glow2: "37,99,235",
    radius: 26,
    blur: 26,
    stiffness: 280,
    damping: 30,
    grain: 0.16,
    image:
      "https://images.pexels.com/photos/28588323/pexels-photo-28588323.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    thumb:
      "https://images.pexels.com/photos/28588323/pexels-photo-28588323.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=220&w=320",
  },
  {
    id: "sunset",
    name: { ar: "غروب", en: "Sunset" },
    mode: "dark",
    c1: "#fb923c",
    c2: "#f43f5e",
    c3: "#e879f9",
    bg: "#150a0c",
    bgSoft: "#1e0f10",
    surface: "rgba(255,228,214,0.06)",
    surfaceAlt: "rgba(255,228,214,0.03)",
    border: "rgba(255,228,214,0.11)",
    text: "#fff4ee",
    textDim: "rgba(255,244,238,0.64)",
    textMute: "rgba(255,244,238,0.34)",
    glow: "251,146,60",
    glow2: "244,63,94",
    radius: 22,
    blur: 20,
    stiffness: 360,
    damping: 26,
    grain: 0.22,
    image:
      "https://images.pexels.com/photos/28396998/pexels-photo-28396998.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    thumb:
      "https://images.pexels.com/photos/28396998/pexels-photo-28396998.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=220&w=320",
  },
  {
    id: "emerald",
    name: { ar: "زمرّد", en: "Emerald" },
    mode: "dark",
    c1: "#34d399",
    c2: "#0d9488",
    c3: "#a3e635",
    bg: "#04120d",
    bgSoft: "#071a13",
    surface: "rgba(209,250,229,0.055)",
    surfaceAlt: "rgba(209,250,229,0.028)",
    border: "rgba(209,250,229,0.1)",
    text: "#ecfdf5",
    textDim: "rgba(236,253,245,0.62)",
    textMute: "rgba(236,253,245,0.32)",
    glow: "52,211,153",
    glow2: "13,148,136",
    radius: 28,
    blur: 24,
    stiffness: 300,
    damping: 32,
    grain: 0.18,
    image:
      "https://images.pexels.com/photos/38986817/pexels-photo-38986817.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    thumb:
      "https://images.pexels.com/photos/38986817/pexels-photo-38986817.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=220&w=320",
  },
  {
    id: "mono",
    name: { ar: "أحادي", en: "Mono" },
    mode: "dark",
    c1: "#f4f4f5",
    c2: "#a1a1aa",
    c3: "#71717a",
    bg: "#09090b",
    bgSoft: "#111114",
    surface: "rgba(255,255,255,0.05)",
    surfaceAlt: "rgba(255,255,255,0.025)",
    border: "rgba(255,255,255,0.1)",
    text: "#fafafa",
    textDim: "rgba(250,250,250,0.6)",
    textMute: "rgba(250,250,250,0.32)",
    glow: "212,212,216",
    glow2: "161,161,170",
    radius: 18,
    blur: 16,
    stiffness: 420,
    damping: 34,
    grain: 0.28,
    image:
      "https://images.pexels.com/photos/19669667/pexels-photo-19669667.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    thumb:
      "https://images.pexels.com/photos/19669667/pexels-photo-19669667.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=220&w=320",
  },
  {
    id: "neon",
    name: { ar: "نيون", en: "Neon" },
    mode: "dark",
    c1: "#d946ef",
    c2: "#8b5cf6",
    c3: "#22d3ee",
    bg: "#0a0512",
    bgSoft: "#120a1e",
    surface: "rgba(240,220,255,0.06)",
    surfaceAlt: "rgba(240,220,255,0.03)",
    border: "rgba(240,220,255,0.12)",
    text: "#fdf4ff",
    textDim: "rgba(253,244,255,0.66)",
    textMute: "rgba(253,244,255,0.36)",
    glow: "217,70,239",
    glow2: "34,211,238",
    radius: 20,
    blur: 28,
    stiffness: 400,
    damping: 22,
    grain: 0.24,
    image:
      "https://images.pexels.com/photos/14559060/pexels-photo-14559060.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    thumb:
      "https://images.pexels.com/photos/14559060/pexels-photo-14559060.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=220&w=320",
  },
  {
    id: "royal",
    name: { ar: "ملكي", en: "Royal" },
    mode: "dark",
    c1: "#818cf8",
    c2: "#6d28d9",
    c3: "#f5d78e",
    bg: "#080a1c",
    bgSoft: "#0e1130",
    surface: "rgba(224,231,255,0.06)",
    surfaceAlt: "rgba(224,231,255,0.03)",
    border: "rgba(224,231,255,0.12)",
    text: "#eef2ff",
    textDim: "rgba(238,242,255,0.64)",
    textMute: "rgba(238,242,255,0.34)",
    glow: "129,140,248",
    glow2: "245,215,142",
    radius: 30,
    blur: 30,
    stiffness: 260,
    damping: 26,
    grain: 0.14,
    image:
      "https://images.pexels.com/photos/8110132/pexels-photo-8110132.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    thumb:
      "https://images.pexels.com/photos/8110132/pexels-photo-8110132.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=220&w=320",
  },
  {
    id: "sakura",
    name: { ar: "ساكورا", en: "Sakura" },
    mode: "light",
    c1: "#f472b6",
    c2: "#a855f7",
    c3: "#38bdf8",
    bg: "#fbf7fa",
    bgSoft: "#f4edf3",
    surface: "rgba(255,255,255,0.72)",
    surfaceAlt: "rgba(255,255,255,0.5)",
    border: "rgba(80,40,70,0.12)",
    text: "#2a1b28",
    textDim: "rgba(42,27,40,0.66)",
    textMute: "rgba(42,27,40,0.42)",
    glow: "244,114,182",
    glow2: "168,85,247",
    radius: 26,
    blur: 24,
    stiffness: 320,
    damping: 28,
    grain: 0.1,
    image:
      "https://images.pexels.com/photos/33084529/pexels-photo-33084529.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    thumb:
      "https://images.pexels.com/photos/33084529/pexels-photo-33084529.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=220&w=320",
  },
];

export function themeById(id: ThemeId): ThemeTokens {
  return THEMES.find((t) => t.id === id) ?? THEMES[0];
}

export function themeCssVars(t: ThemeTokens): Record<string, string> {
  return {
    "--c1": t.c1,
    "--c2": t.c2,
    "--c3": t.c3,
    "--bg": t.bg,
    "--bg-soft": t.bgSoft,
    "--surface": t.surface,
    "--surface-alt": t.surfaceAlt,
    "--line": t.border,
    "--tx": t.text,
    "--tx-dim": t.textDim,
    "--tx-mute": t.textMute,
    "--glow": t.glow,
    "--glow2": t.glow2,
    "--radius": `${t.radius}px`,
    "--blur": `${t.blur}px`,
    "--grain": String(t.grain),
  };
}

/* ------------------------------------------------------------------ */
/* localization                                                        */
/* ------------------------------------------------------------------ */

const DICT = {
  appName: { ar: "DON", en: "DON" },
  home: { ar: "الرئيسية", en: "Home" },
  tube: { ar: "DON Tube", en: "DON Tube" },
  downloads: { ar: "التحميلات", en: "Downloads" },
  browser: { ar: "المتصفح", en: "Browser" },
  files: { ar: "المكتبة", en: "Library" },
  tools: { ar: "الأدوات", en: "Tools" },
  settings: { ar: "الإعدادات", en: "Settings" },
  pasteLink: { ar: "الصق رابطًا أو اختر ملفًا من جهازك", en: "Paste a link or pick a file from your device" },
  analyze: { ar: "تحليل", en: "Analyze" },
  paste: { ar: "لصق", en: "Paste" },
  pickFile: { ar: "اختيار ملف", en: "Pick file" },
  stages: { ar: "مراحل التحليل الفعلية", en: "Real analysis stages" },
  stage0: { ar: "تطبيع الرابط", en: "Normalize URL" },
  stage1: { ar: "قراءة الترويسات (HEAD)", en: "Read headers (HEAD)" },
  stage2: { ar: "جلب المستند واستخراج الوسائط", en: "Fetch document & extract media" },
  stage3: { ar: "التعرف على المزوّد", en: "Provider detection" },
  download: { ar: "تحميل", en: "Download" },
  pause: { ar: "إيقاف", en: "Pause" },
  resume: { ar: "استئناف", en: "Resume" },
  cancel: { ar: "إلغاء", en: "Cancel" },
  retry: { ar: "إعادة المحاولة", en: "Retry" },
  remove: { ar: "حذف", en: "Remove" },
  open: { ar: "فتح", en: "Open" },
  copyLink: { ar: "نسخ الرابط", en: "Copy link" },
  share: { ar: "مشاركة", en: "Share" },
  speed: { ar: "السرعة", en: "Speed" },
  remaining: { ar: "المتبقي", en: "Remaining" },
  size: { ar: "الحجم", en: "Size" },
  exactSize: { ar: "الحجم الحقيقي", en: "Real size" },
  all: { ar: "الكل", en: "All" },
  active: { ar: "نشط", en: "Active" },
  queued: { ar: "في الطابور", en: "Queued" },
  done: { ar: "مكتمل", en: "Done" },
  failed: { ar: "فاشل", en: "Failed" },
  addUrl: { ar: "إضافة رابط", en: "Add URL" },
  concurrent: { ar: "تحميلات متزامنة", en: "Concurrent downloads" },
  theme: { ar: "الثيمات", en: "Themes" },
  themeHint: { ar: "كل ثيم يتحكم بالألوان والحواف والتغبيش وفيزياء الحركة والخلفية", en: "Each theme controls colors, radius, blur, motion physics and wallpaper" },
  language: { ar: "اللغة", en: "Language" },
  appearance: { ar: "المظهر", en: "Appearance" },
  network: { ar: "الشبكة والتحميل", en: "Network & downloads" },
  privacy: { ar: "الخصوصية", en: "Privacy" },
  storage: { ar: "التخزين المحلي", en: "Local storage" },
  profile: { ar: "الملف الشخصي", en: "Profile" },
  exportProfile: { ar: "تصدير الملف", en: "Export profile" },
  importProfile: { ar: "استيراد ملف", en: "Import profile" },
  follow: { ar: "متابعة", en: "Follow" },
  unfollow: { ar: "إلغاء المتابعة", en: "Unfollow" },
  subscriptions: { ar: "الاشتراكات", en: "Subscriptions" },
  shorts: { ar: "شورتس", en: "Shorts" },
  search: { ar: "بحث", en: "Search" },
  searchHint: { ar: "ابحث في الفهرس المحلي ومكتبتك وسجلّك", en: "Search the local index, your library and history" },
  suggestions: { ar: "اقتراحات لك", en: "Suggested for you" },
  infinite: { ar: "تغذية لا متناهية حسب تصفّحك", en: "Infinite feed based on your browsing" },
  history: { ar: "السجل", en: "History" },
  clearHistory: { ar: "مسح السجل", en: "Clear history" },
  watchLater: { ar: "مشاهدة لاحقًا", en: "Watch later" },
  liked: { ar: "الإعجابات", en: "Liked" },
  notes: { ar: "ملاحظات محلية", en: "Local notes" },
  addNote: { ar: "أضف ملاحظة", en: "Add note" },
  player: { ar: "المشغّل", en: "Player" },
  audioMode: { ar: "تشغيل كأغنية", en: "Play as song" },
  sleepTimer: { ar: "مؤقّت النوم", en: "Sleep timer" },
  repeat: { ar: "تكرار", en: "Repeat" },
  repeatOff: { ar: "إيقاف", en: "Off" },
  repeatOne: { ar: "هذا فقط", en: "One" },
  repeatAll: { ar: "الكل", en: "All" },
  effects: { ar: "تأثيرات بصرية", en: "Visual effects" },
  trim: { ar: "قص مرئي", en: "Visual trim" },
  ringtone: { ar: "إنشاء نغمة", en: "Make ringtone" },
  extractAudio: { ar: "استخراج الصوت", en: "Extract audio" },
  compress: { ar: "ضغط", en: "Compress" },
  convert: { ar: "تحويل", en: "Convert" },
  before: { ar: "قبل", en: "Before" },
  after: { ar: "بعد", en: "After" },
  saved: { ar: "وفّرت", en: "Saved" },
  exportFile: { ar: "حفظ الملف", en: "Save file" },
  pip: { ar: "نافذة عائمة", en: "Picture in picture" },
  fullscreen: { ar: "ملء الشاشة", en: "Fullscreen" },
  video: { ar: "فيديو", en: "Video" },
  audio: { ar: "صوت", en: "Audio" },
  image: { ar: "صورة", en: "Image" },
  file: { ar: "ملف", en: "File" },
  noItems: { ar: "لا يوجد شيء هنا بعد", en: "Nothing here yet" },
  noItemsHint: { ar: "حمّل رابطًا أو أضف ملفًا من جهازك ليظهر هنا", en: "Download a link or add a local file to see it here" },
  offlineReady: { ar: "جاهز للعمل دون اتصال", en: "Works offline" },
  localOnly: { ar: "محلي بالكامل · بلا خادم · بلا قاعدة بيانات", en: "Fully local · no server · no database" },
  copyright: { ar: "المسؤولية على المستخدم في احترام حقوق النشر.", en: "You are responsible for respecting copyright." },
  sniffer: { ar: "اصطياد الوسائط", en: "Media sniffer" },
  blockedFrame: { ar: "الموقع يرفض العرض داخل التطبيق", en: "This site refuses to be embedded" },
  directMedia: { ar: "وسائط مباشرة", en: "Direct media" },
  queue: { ar: "الطابور", en: "Queue" },
  start: { ar: "بدء", en: "Start" },
  stop: { ar: "إيقاف", en: "Stop" },
  back: { ar: "رجوع", en: "Back" },
  forward: { ar: "تقدّم", en: "Forward" },
  reload: { ar: "إعادة تحميل", en: "Reload" },
  views: { ar: "مشاهدة", en: "views" },
  followers: { ar: "متابع", en: "followers" },
  videosCount: { ar: "فيديو", en: "videos" },
  save: { ar: "حفظ", en: "Save" },
  edit: { ar: "تعديل", en: "Edit" },
  name: { ar: "الاسم", en: "Name" },
  handle: { ar: "المعرّف", en: "Handle" },
  bio: { ar: "نبذة", en: "Bio" },
  notInterested: { ar: "لست مهتمًا", en: "Not interested" },
  addToQueue: { ar: "إضافة للطابور", en: "Add to queue" },
  savedOk: { ar: "تم الحفظ", en: "Saved" },
  copied: { ar: "تم النسخ", en: "Copied" },
  realEngine: { ar: "محرك فعلي", en: "Real engine" },
  segments: { ar: "اتصال متوازٍ", en: "parallel connections" },
  resumeSupport: { ar: "استئناف مدعوم", en: "Resume supported" },
  noResume: { ar: "الاستئناف غير مدعوم", en: "Resume not supported" },
  light: { ar: "فاتح", en: "Light" },
  dark: { ar: "داكن", en: "Dark" },
  wallpaper: { ar: "الخلفية", en: "Wallpaper" },
  motion: { ar: "الحركة", en: "Motion" },
  radiusLabel: { ar: "نعومة الحواف", en: "Corner softness" },
  blurLabel: { ar: "درجة التغبيش", en: "Blur level" },
  grainLabel: { ar: "حبيبات", en: "Grain" },
  applyToAll: { ar: "يُطبَّق على كل الشاشات", en: "Applies to every screen" },
} as const;

export type TKey = keyof typeof DICT;

export function translate(lang: Lang, key: TKey): string {
  return DICT[key][lang];
}

/* ------------------------------------------------------------------ */
/* real media catalog (playable files, real thumbnails)                */
/* ------------------------------------------------------------------ */

export type MediaKind = "video" | "audio" | "image" | "file";
export type TubeKind = "video" | "short" | "music";

export interface Channel {
  id: string;
  name: string;
  handle: string;
  followers: number;
  verified: boolean;
  color: string;
  initial: string;
  about: string;
}

export interface TubeVideo {
  id: string;
  title: string;
  channelId: string;
  src: string;
  poster: string;
  duration: number;
  views: number;
  publishedDaysAgo: number;
  kind: TubeKind;
  tags: string[];
  description: string;
  quality: string;
}

export const CHANNELS: Channel[] = [
  { id: "c1", name: "Aerial Earth", handle: "@aerialearth", followers: 2_480_000, verified: true, color: "#38bdf8", initial: "A", about: "cinematic drone films" },
  { id: "c2", name: "North Sea Docs", handle: "@northsea", followers: 612_000, verified: true, color: "#34d399", initial: "N", about: "coastal documentary" },
  { id: "c3", name: "Neon Sessions", handle: "@neonsessions", followers: 1_930_000, verified: true, color: "#d946ef", initial: "S", about: "live music & clubs" },
  { id: "c4", name: "City Nights", handle: "@citynights", followers: 448_000, verified: false, color: "#fb923c", initial: "C", about: "urban vertical stories" },
  { id: "c5", name: "Fjord Archive", handle: "@fjordarchive", followers: 128_000, verified: true, color: "#818cf8", initial: "F", about: "Norway landscape archive" },
  { id: "c6", name: "Studio Vocals", handle: "@studiovocals", followers: 3_120_000, verified: true, color: "#f472b6", initial: "V", about: "vocal performances" },
];

export const CATALOG: TubeVideo[] = [
  {
    id: "v1",
    title: "Serene aerial view over calm ocean waters — 4K",
    channelId: "c1",
    src: "https://videos.pexels.com/video-files/34547320/14638451_3840_2160_30fps.mp4",
    poster: "https://images.pexels.com/videos/34547320/cityscape-droneart-dronecapture-dronefootage-34547320.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    duration: 13,
    views: 1_842_000,
    publishedDaysAgo: 3,
    kind: "video",
    tags: ["aerial", "ocean", "4k", "drone", "calm"],
    description: "A slow drone pass above perfectly calm water, shot at 3840×2160.",
    quality: "3840×2160 · 30fps",
  },
  {
    id: "v2",
    title: "Dramatic drone view of northern sea cliffs",
    channelId: "c2",
    src: "https://videos.pexels.com/video-files/36505810/15479717_3840_2160_60fps.mp4",
    poster: "https://images.pexels.com/videos/36505810/4k-4k-drone-footage-asturias-cantabria-36505810.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    duration: 13,
    views: 964_000,
    publishedDaysAgo: 11,
    kind: "video",
    tags: ["cliffs", "drone", "60fps", "sea", "documentary"],
    description: "Asturias coastline at 60fps — real cliffs, real swell.",
    quality: "3840×2160 · 60fps",
  },
  {
    id: "v3",
    title: "Norway scenic coastline from above",
    channelId: "c5",
    src: "https://videos.pexels.com/video-files/39924448/17034603_3840_2160_30fps.mp4",
    poster: "https://images.pexels.com/videos/39924448/adventure-aerial-footage-aerial-view-beautiful-nature-39924448.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    duration: 10,
    views: 421_500,
    publishedDaysAgo: 1,
    kind: "video",
    tags: ["norway", "coast", "aerial", "nature"],
    description: "Ten seconds of Norwegian shoreline, no color grading tricks.",
    quality: "3840×2160 · 30fps",
  },
  {
    id: "v4",
    title: "Fjord landscape — drone archive 04",
    channelId: "c5",
    src: "https://videos.pexels.com/video-files/39928137/17036753_3840_2160_30fps.mp4",
    poster: "https://images.pexels.com/videos/39928137/adventure-aerial-view-arctic-landscape-beautiful-scenery-39928137.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    duration: 16,
    views: 288_900,
    publishedDaysAgo: 24,
    kind: "video",
    tags: ["fjord", "norway", "mountains", "landscape"],
    description: "Deep fjord valley with low cloud, archived in 4K.",
    quality: "3840×2160 · 30fps",
  },
  {
    id: "v5",
    title: "Coastal cliff and rough sea waves — long take",
    channelId: "c2",
    src: "https://videos.pexels.com/video-files/39232574/16694784_3840_2160_24fps.mp4",
    poster: "https://images.pexels.com/videos/39232574/pexels-photo-39232574.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    duration: 55,
    views: 1_120_000,
    publishedDaysAgo: 40,
    kind: "video",
    tags: ["waves", "cliff", "sea", "long take", "24fps"],
    description: "A 55-second unbroken take of heavy Atlantic swell.",
    quality: "3840×2160 · 24fps",
  },
  {
    id: "v6",
    title: "Rock formations and coastal cliffs",
    channelId: "c1",
    src: "https://videos.pexels.com/video-files/10234380/10234380-uhd_3840_2160_30fps.mp4",
    poster: "https://images.pexels.com/videos/10234380/beach-cliff-drone-ocean-10234380.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    duration: 40,
    views: 733_200,
    publishedDaysAgo: 60,
    kind: "video",
    tags: ["rocks", "beach", "cliff", "ocean"],
    description: "Geology in motion: sandstone stacks filmed at UHD.",
    quality: "3840×2160 · 30fps",
  },
  {
    id: "s1",
    title: "Neon room session — live guitar",
    channelId: "c3",
    src: "https://videos.pexels.com/video-files/34668819/14694799_1080_1920_30fps.mp4",
    poster: "https://images.pexels.com/videos/34668819/electric-guitar-34668819.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    duration: 16,
    views: 2_940_000,
    publishedDaysAgo: 2,
    kind: "short",
    tags: ["music", "neon", "guitar", "vertical"],
    description: "Vertical neon-lit guitar performance.",
    quality: "1080×1920 · 30fps",
  },
  {
    id: "s2",
    title: "Night street performance with skyline",
    channelId: "c4",
    src: "https://videos.pexels.com/video-files/32036075/13655513_1080_1920_30fps.mp4",
    poster: "https://images.pexels.com/videos/32036075/pexels-photo-32036075.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    duration: 18,
    views: 1_510_000,
    publishedDaysAgo: 6,
    kind: "short",
    tags: ["city", "night", "street", "vertical"],
    description: "Street musicians under a lit skyline.",
    quality: "1080×1920 · 30fps",
  },
  {
    id: "s3",
    title: "Club DJ set — vertical cut",
    channelId: "c3",
    src: "https://videos.pexels.com/video-files/7722357/7722357-uhd_2160_3840_25fps.mp4",
    poster: "https://images.pexels.com/videos/7722357/abstract-art-band-bass-7722357.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    duration: 7,
    views: 4_220_000,
    publishedDaysAgo: 9,
    kind: "short",
    tags: ["dj", "club", "bass", "vertical"],
    description: "Seven seconds of a packed club floor.",
    quality: "2160×3840 · 25fps",
  },
  {
    id: "m1",
    title: "Vocal take in winter coat — studio session",
    channelId: "c6",
    src: "https://videos.pexels.com/video-files/8042161/8042161-uhd_2160_4096_25fps.mp4",
    poster: "https://images.pexels.com/videos/8042161/adult-art-audience-audio-8042161.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    duration: 13,
    views: 5_870_000,
    publishedDaysAgo: 14,
    kind: "music",
    tags: ["vocals", "music", "studio", "vertical"],
    description: "Raw vocal performance, single take.",
    quality: "2160×4096 · 25fps",
  },
  {
    id: "v7",
    title: "The Hague — city walk in 4K",
    channelId: "c4",
    src: "https://videos.pexels.com/video-files/27571839/12172003_3840_2160_30fps.mp4",
    poster: "https://images.pexels.com/videos/27571839/bachata-beach-celebration-city-27571839.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    duration: 35,
    views: 305_400,
    publishedDaysAgo: 80,
    kind: "video",
    tags: ["city", "walk", "netherlands", "4k"],
    description: "A calm walk through The Hague, South Holland.",
    quality: "3840×2160 · 30fps",
  },
  {
    id: "m2",
    title: "Bass line study — neon session II",
    channelId: "c3",
    src: "https://videos.pexels.com/video-files/34668819/14694799_1080_1920_30fps.mp4",
    poster: "https://images.pexels.com/videos/34668819/electric-guitar-34668819.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    duration: 16,
    views: 612_000,
    publishedDaysAgo: 20,
    kind: "music",
    tags: ["bass", "music", "neon", "session"],
    description: "Second take from the neon session, bass-forward mix.",
    quality: "1080×1920 · 30fps",
  },
];

export const THEME_IMAGES = {
  aurora: THEMES[0].image,
  ocean: THEMES[1].image,
  sunset: THEMES[2].image,
  emerald: THEMES[3].image,
  mono: THEMES[4].image,
  neon: THEMES[5].image,
  royal: THEMES[6].image,
  sakura: THEMES[7].image,
};

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  if (bytes >= 1_073_741_824) return `${(bytes / 1_073_741_824).toFixed(2)} GiB`;
  if (bytes >= 1_048_576) return `${(bytes / 1_048_576).toFixed(1)} MiB`;
  if (bytes >= 1024) return `${(bytes / 1024).toFixed(1)} KiB`;
  return `${Math.round(bytes)} B`;
}

export function formatSpeed(bytesPerSecond: number): string {
  if (!Number.isFinite(bytesPerSecond) || bytesPerSecond <= 0) return "—";
  return `${formatBytes(bytesPerSecond)}/s`;
}

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function formatClock(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function compactNumber(value: number, lang: Lang): string {
  if (value >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(1)}${lang === "ar" ? " مليار" : "B"}`;
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}${lang === "ar" ? " مليون" : "M"}`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(1)}${lang === "ar" ? " ألف" : "K"}`;
  return String(value);
}

export function relativeDays(days: number, lang: Lang): string {
  if (days <= 0) return lang === "ar" ? "اليوم" : "today";
  if (days === 1) return lang === "ar" ? "أمس" : "yesterday";
  if (days < 30) return lang === "ar" ? `قبل ${days} يوم` : `${days} days ago`;
  const months = Math.round(days / 30);
  if (months < 12) return lang === "ar" ? `قبل ${months} شهر` : `${months} months ago`;
  const years = Math.round(months / 12);
  return lang === "ar" ? `قبل ${years} سنة` : `${years} years ago`;
}

export function channelById(id: string): Channel {
  return CHANNELS.find((c) => c.id === id) ?? CHANNELS[0];
}

/** Real URL normalization + provider detection. */
export interface ParsedLink {
  url: URL;
  raw: string;
  host: string;
  isMedia: boolean;
  mediaType: MediaKind | null;
  provider: "youtube" | "youtu.be" | "tiktok" | "instagram" | "vimeo" | "twitter" | "direct" | "unknown";
  youtubeId: string | null;
}

const MEDIA_EXT = /\.(mp4|mkv|webm|mov|m4v|avi|mp3|m4a|aac|opus|ogg|flac|wav|jpe?g|png|webp|avif|gif|pdf|zip|rar|7z|apk|iso|json|srt|vtt)(\?|#|$)/i;
const IMAGE_EXT = /\.(jpe?g|png|webp|avif|gif)(\?|#|$)/i;
const AUDIO_EXT = /\.(mp3|m4a|aac|opus|ogg|flac|wav)(\?|#|$)/i;
const VIDEO_EXT = /\.(mp4|mkv|webm|mov|m4v|avi)(\?|#|$)/i;

export function parseLink(input: string): ParsedLink | null {
  const raw = input.trim();
  if (!raw) return null;
  let candidate = raw;
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(candidate)) candidate = `https://${candidate}`;
  let url: URL;
  try {
    url = new URL(candidate);
  } catch {
    return null;
  }
  const host = url.hostname.replace(/^www\./, "");
  const path = url.pathname;
  let provider: ParsedLink["provider"] = "unknown";
  if (/(^|\.)youtube\.com$/i.test(host)) provider = "youtube";
  else if (/^youtu\.be$/i.test(host)) provider = "youtu.be";
  else if (/tiktok\.com$/i.test(host)) provider = "tiktok";
  else if (/instagram\.com$/i.test(host)) provider = "instagram";
  else if (/vimeo\.com$/i.test(host)) provider = "vimeo";
  else if (/(twitter|x)\.com$/i.test(host)) provider = "twitter";
  else if (MEDIA_EXT.test(path)) provider = "direct";

  let youtubeId: string | null = null;
  if (provider === "youtube") {
    const v = url.searchParams.get("v");
    if (v) youtubeId = v;
    else {
      const m = path.match(/\/(shorts|embed|live|v)\/([A-Za-z0-9_-]{6,})/);
      if (m) youtubeId = m[2];
    }
  } else if (provider === "youtu.be") {
    const m = path.match(/\/([A-Za-z0-9_-]{6,})/);
    if (m) youtubeId = m[1];
  }

  const mediaType: MediaKind | null = IMAGE_EXT.test(path)
    ? "image"
    : AUDIO_EXT.test(path)
      ? "audio"
      : VIDEO_EXT.test(path)
        ? "video"
        : MEDIA_EXT.test(path)
          ? "file"
          : null;

  return {
    url,
    raw: url.toString(),
    host,
    isMedia: mediaType !== null,
    mediaType,
    provider,
    youtubeId,
  };
}

export function youtubeThumb(id: string, kind: "hq" | "max" = "hq"): string {
  return kind === "max"
    ? `https://i.ytimg.com/vi/${id}/maxresdefault.jpg`
    : `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
}

export function deterministicSeed(text: string): number {
  let hash = 2166136261;
  for (let i = 0; i < text.length; i += 1) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return Math.abs(hash);
}

export function seededRandom(seed: number): () => number {
  let state = seed || 1;
  return () => {
    state = (state * 1664525 + 1013904223) % 4294967296;
    return state / 4294967296;
  };
}
