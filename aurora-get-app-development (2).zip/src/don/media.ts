/**
 * DON — real media utilities built on browser APIs only.
 * No mocks: every function performs an actual operation and reports real results.
 */

export interface ProbeResult {
  ok: boolean;
  status?: number;
  size?: number;
  contentType?: string;
  rangeSupported: boolean;
  error?: string;
}

/** Real HEAD (falling back to a 1-byte ranged GET) to read the true file size. */
export async function probeRemote(url: string, signal?: AbortSignal): Promise<ProbeResult> {
  try {
    const res = await fetch(url, { method: "HEAD", signal, cache: "no-store" });
    const rangeSupported =
      (res.headers.get("Accept-Ranges") || "").toLowerCase().includes("bytes") || res.status === 206;
    const lengthHeader = res.headers.get("Content-Length");
    if (res.ok && lengthHeader) {
      return {
        ok: true,
        status: res.status,
        size: Number(lengthHeader),
        contentType: res.headers.get("Content-Type") || undefined,
        rangeSupported,
      };
    }
    // Fallback: ranged GET reads the real total from Content-Range.
    const ranged = await fetch(url, { headers: { Range: "bytes=0-0" }, signal, cache: "no-store" });
    const contentRange = ranged.headers.get("Content-Range") || "";
    const totalMatch = contentRange.match(/\/(\d+)\s*$/);
    const lengthFallback = ranged.headers.get("Content-Length");
    const size = totalMatch ? Number(totalMatch[1]) : lengthFallback ? Number(lengthFallback) : undefined;
    if (!ranged.ok && ranged.status !== 206) {
      return { ok: false, status: ranged.status, rangeSupported: false, error: `HTTP ${ranged.status}` };
    }
    return {
      ok: true,
      status: ranged.status,
      size,
      contentType: ranged.headers.get("Content-Type") || undefined,
      rangeSupported: ranged.status === 206 || rangeSupported,
    };
  } catch (error) {
    return {
      ok: false,
      rangeSupported: false,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

export interface PageMeta {
  ok: boolean;
  title?: string;
  description?: string;
  image?: string;
  videos: string[];
  audios: string[];
  error?: string;
  status?: number;
}

/** Real document fetch + parse: OpenGraph, <video>, <source>, <audio>, media links. */
export async function readPageMeta(url: string, signal?: AbortSignal): Promise<PageMeta> {
  try {
    const res = await fetch(url, { signal, cache: "no-store", redirect: "follow" });
    if (!res.ok) return { ok: false, status: res.status, videos: [], audios: [], error: `HTTP ${res.status}` };
    const type = res.headers.get("Content-Type") || "";
    if (!type.includes("html") && !type.includes("xml") && !type.includes("text")) {
      return { ok: false, status: res.status, videos: [], audios: [], error: `content-type: ${type}` };
    }
    const html = await res.text();
    const doc = new DOMParser().parseFromString(html, "text/html");
    const meta = (property: string) =>
      doc.querySelector(`meta[property="${property}"]`)?.getAttribute("content") ||
      doc.querySelector(`meta[name="${property}"]`)?.getAttribute("content") ||
      undefined;
    const absolute = (value: string | null | undefined) => {
      if (!value) return undefined;
      try {
        return new URL(value, url).toString();
      } catch {
        return undefined;
      }
    };

    const videos = new Set<string>();
    const audios = new Set<string>();
    doc.querySelectorAll("video[src], video source[src]").forEach((el) => {
      const src = absolute(el.getAttribute("src"));
      if (src) videos.add(src);
    });
    doc.querySelectorAll("audio[src], audio source[src]").forEach((el) => {
      const src = absolute(el.getAttribute("src"));
      if (src) audios.add(src);
    });
    [meta("og:video"), meta("og:video:url"), meta("og:video:secure_url"), meta("twitter:player:stream")]
      .map(absolute)
      .forEach((src) => src && videos.add(src));
    doc.querySelectorAll('a[href]').forEach((el) => {
      const href = absolute(el.getAttribute("href"));
      if (!href) return;
      if (/\.(mp4|webm|mkv|mov|m4v)(\?|#|$)/i.test(href)) videos.add(href);
      if (/\.(mp3|m4a|aac|opus|ogg|flac|wav)(\?|#|$)/i.test(href)) audios.add(href);
    });

    return {
      ok: true,
      status: res.status,
      title: meta("og:title") || doc.querySelector("title")?.textContent?.trim() || undefined,
      description: meta("og:description") || meta("description") || undefined,
      image: absolute(meta("og:image")),
      videos: [...videos],
      audios: [...audios],
    };
  } catch (error) {
    return {
      ok: false,
      videos: [],
      audios: [],
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

/* ------------------------------------------------------------------ */
/* IndexedDB — real local persistence for blobs (no server, no DB)     */
/* ------------------------------------------------------------------ */

const DB_NAME = "don-store";
const DB_VERSION = 1;
const STORE = "blobs";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function idbPut(key: string, blob: Blob): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(blob, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
}

export async function idbGet(key: string): Promise<Blob | undefined> {
  const db = await openDb();
  const result = await new Promise<Blob | undefined>((resolve, reject) => {
    const tx = db.transaction(STORE, "readonly");
    const request = tx.objectStore(STORE).get(key);
    request.onsuccess = () => resolve(request.result as Blob | undefined);
    request.onerror = () => reject(request.error);
  });
  db.close();
  return result;
}

export async function idbDelete(key: string): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
}

export async function idbEstimate(): Promise<{ usage: number; quota: number }> {
  if (navigator.storage?.estimate) {
    const estimate = await navigator.storage.estimate();
    return { usage: estimate.usage ?? 0, quota: estimate.quota ?? 0 };
  }
  return { usage: 0, quota: 0 };
}

/* ------------------------------------------------------------------ */
/* real media processing                                               */
/* ------------------------------------------------------------------ */

/** Grabs real frames from a video element into a filmstrip of data URLs. */
export async function captureFilmstrip(
  video: HTMLVideoElement,
  from: number,
  to: number,
  count: number,
): Promise<{ frames: string[]; tainted: boolean }> {
  const frames: string[] = [];
  let tainted = false;
  const canvas = document.createElement("canvas");
  canvas.width = 120;
  canvas.height = Math.max(1, Math.round((video.videoHeight / Math.max(1, video.videoWidth)) * 120)) || 68;
  const ctx = canvas.getContext("2d");
  const previousTime = video.currentTime;
  const wasPaused = video.paused;
  if (!wasPaused) video.pause();

  for (let i = 0; i < count; i += 1) {
    const time = from + ((to - from) * i) / Math.max(1, count - 1);
    try {
      await seekTo(video, Math.min(Math.max(0, time), video.duration || time));
      if (!ctx) break;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      frames.push(canvas.toDataURL("image/jpeg", 0.6));
    } catch {
      tainted = true;
      break;
    }
  }
  try {
    video.currentTime = previousTime;
  } catch {
    /* ignore */
  }
  return { frames, tainted };
}

export function seekTo(video: HTMLVideoElement, time: number): Promise<void> {
  return new Promise((resolve) => {
    const done = () => {
      video.removeEventListener("seeked", done);
      resolve();
    };
    video.addEventListener("seeked", done);
    try {
      video.currentTime = time;
    } catch {
      resolve();
    }
    window.setTimeout(() => {
      video.removeEventListener("seeked", done);
      resolve();
    }, 2500);
  });
}

export interface RecordOptions {
  from: number;
  to: number;
  audioOnly?: boolean;
  videoBitsPerSecond?: number;
  audioBitsPerSecond?: number;
  onProgress?: (ratio: number) => void;
  signal?: AbortSignal;
}

/**
 * Real segment export: captures the playing element with MediaRecorder.
 * Produces an actual file the user can keep (webm container).
 */
export async function recordSegment(video: HTMLVideoElement, options: RecordOptions): Promise<Blob> {
  const { from, to, audioOnly = false, videoBitsPerSecond, audioBitsPerSecond = 128_000, onProgress, signal } = options;
  const capturable = video as HTMLVideoElement & {
    captureStream?: () => MediaStream;
    mozCaptureStream?: () => MediaStream;
  };
  if (typeof capturable.captureStream !== "function" && typeof capturable.mozCaptureStream !== "function") {
    throw new Error("capture-stream-unsupported");
  }
  const stream: MediaStream = capturable.captureStream
    ? capturable.captureStream()
    : (capturable.mozCaptureStream as () => MediaStream)();

  if (audioOnly) {
    stream.getVideoTracks().forEach((track) => track.stop());
  }
  const mime = pickMime(audioOnly);
  const recorder = new MediaRecorder(stream, {
    mimeType: mime,
    videoBitsPerSecond: audioOnly ? undefined : videoBitsPerSecond,
    audioBitsPerSecond: audioBitsPerSecond,
  });
  const chunks: BlobPart[] = [];
  recorder.ondataavailable = (event) => {
    if (event.data.size > 0) chunks.push(event.data);
  };

  await seekTo(video, from);
  const finished = new Promise<Blob>((resolve, reject) => {
    recorder.onstop = () => resolve(new Blob(chunks, { type: mime }));
    recorder.onerror = () => reject(new Error("recorder-error"));
  });

  recorder.start(250);
  const previousRate = video.playbackRate;
  await video.play();

  const duration = Math.max(0.2, to - from);
  const startedAt = performance.now();
  const ticker = window.setInterval(() => {
    const elapsed = (performance.now() - startedAt) / 1000;
    onProgress?.(Math.min(0.99, elapsed / duration));
  }, 200);

  const abortHandler = () => {
    if (recorder.state !== "inactive") recorder.stop();
  };
  signal?.addEventListener("abort", abortHandler);

  await new Promise<void>((resolve) => {
    const check = () => {
      if (signal?.aborted || video.currentTime >= to || video.ended) {
        resolve();
        return;
      }
      window.setTimeout(check, 80);
    };
    check();
  });

  window.clearInterval(ticker);
  video.pause();
  video.playbackRate = previousRate;
  if (recorder.state !== "inactive") recorder.stop();
  signal?.removeEventListener("abort", abortHandler);
  const blob = await finished;
  stream.getTracks().forEach((track) => track.stop());
  onProgress?.(1);
  return blob;
}

function pickMime(audioOnly: boolean): string {
  const candidates = audioOnly
    ? ["audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus", "audio/mp4"]
    : ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm", "video/mp4"];
  for (const candidate of candidates) {
    if (typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported?.(candidate)) return candidate;
  }
  return audioOnly ? "audio/webm" : "video/webm";
}

/** Real image transcode/compress through canvas — returns an actual new blob. */
export async function processImage(
  source: Blob,
  type: "image/jpeg" | "image/png" | "image/webp",
  quality: number,
  maxEdge?: number,
): Promise<{ blob: Blob; width: number; height: number }> {
  const bitmapUrl = URL.createObjectURL(source);
  try {
    const image = await loadImage(bitmapUrl);
    let { width, height } = image;
    if (maxEdge && Math.max(width, height) > maxEdge) {
      const ratio = maxEdge / Math.max(width, height);
      width = Math.round(width * ratio);
      height = Math.round(height * ratio);
    }
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("canvas-2d-unavailable");
    if (type === "image/jpeg") {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, width, height);
    }
    ctx.drawImage(image, 0, 0, width, height);
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, type, quality));
    if (!blob) throw new Error("encode-failed");
    return { blob, width, height };
  } finally {
    URL.revokeObjectURL(bitmapUrl);
  }
}

export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("image-load-failed"));
    image.src = src;
  });
}

/** Real file save to the user's device. */
export function saveBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    /* fall through to legacy path */
  }
  try {
    const area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "true");
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    const ok = document.execCommand("copy");
    area.remove();
    return ok;
  } catch {
    return false;
  }
}

export async function readClipboard(): Promise<string | null> {
  try {
    if (navigator.clipboard?.readText) {
      const text = await navigator.clipboard.readText();
      return text?.trim() ? text.trim() : null;
    }
  } catch {
    return null;
  }
  return null;
}

export async function shareData(title: string, text: string, url?: string): Promise<boolean> {
  try {
    if (navigator.share) {
      await navigator.share({ title, text, url });
      return true;
    }
  } catch {
    return false;
  }
  return false;
}

export function guessKindFromMime(contentType?: string, filename?: string): "video" | "audio" | "image" | "file" {
  const type = (contentType || "").toLowerCase();
  if (type.startsWith("video/")) return "video";
  if (type.startsWith("audio/")) return "audio";
  if (type.startsWith("image/")) return "image";
  const name = (filename || "").toLowerCase();
  if (/\.(mp4|webm|mkv|mov|m4v|avi)$/.test(name)) return "video";
  if (/\.(mp3|m4a|aac|opus|ogg|flac|wav|weba)$/.test(name)) return "audio";
  if (/\.(jpe?g|png|webp|avif|gif|bmp)$/.test(name)) return "image";
  return "file";
}

export function safeFilename(url: string, fallback = "don-file"): string {
  try {
    const parsed = new URL(url);
    const last = parsed.pathname.split("/").filter(Boolean).pop();
    if (last && last.includes(".")) return decodeURIComponent(last).slice(0, 120);
    return `${fallback}${parsed.pathname.replace(/[^a-z0-9]/gi, "-").slice(0, 40) || ""}`;
  } catch {
    return fallback;
  }
}
