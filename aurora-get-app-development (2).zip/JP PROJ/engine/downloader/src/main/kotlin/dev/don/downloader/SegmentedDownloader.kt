package dev.don.downloader

import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import timber.log.Timber
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min

/** Immutable description of one download request. */
data class DownloadRequest(
    val id: String,
    val url: String,
    val destination: File,
    val headers: Map<String, String> = emptyMap(),
    val maxSegments: Int = 16,
    val minSegmentBytes: Long = 2L * 1024 * 1024,
    val bufferSize: Int = 512 * 1024,
    val expectedEtag: String? = null,
    val expectedLastModified: String? = null,
)

data class SegmentState(
    val index: Int,
    val start: Long,
    var endInclusive: Long,
    var written: Long = 0L,
)

sealed interface DownloadEvent {
    data class Probed(val total: Long, val rangeSupported: Boolean, val etag: String?, val lastModified: String?) : DownloadEvent
    data class Progress(val received: Long, val total: Long, val bytesPerSecond: Double, val segments: Int) : DownloadEvent
    data object Paused : DownloadEvent
    data object Completed : DownloadEvent
    data class Failed(val reason: String) : DownloadEvent
}

/**
 * Segmented parallel downloader.
 *
 * - probes the resource (HEAD, then a 1-byte ranged GET when HEAD is refused),
 * - pre-allocates the destination file and writes each segment at its own offset
 *   through a single FileChannel (no temp concatenation, no extra copies),
 * - resumes from persisted segment offsets after pause, process death or reboot,
 * - validates ETag / Last-Modified before resuming so a changed file is never mixed,
 * - reports real throughput measured over a sliding window.
 */
class SegmentedDownloader(
    private val client: OkHttpClient,
    private val io: CoroutineDispatcher = Dispatchers.IO,
    private val segmentStore: SegmentStore,
) {

    private val paused = MutableStateFlow<Set<String>>(emptySet())
    val pausedTasks: StateFlow<Set<String>> = paused.asStateFlow()

    fun pause(id: String) {
        paused.value = paused.value + id
    }

    fun resume(id: String) {
        paused.value = paused.value - id
    }

    fun cancel(id: String) {
        paused.value = paused.value + id
        segmentStore.clear(id)
    }

    suspend fun download(
        request: DownloadRequest,
        onEvent: (DownloadEvent) -> Unit,
    ): Result<File> = withContext(io) {
        runCatching {
            val probe = probe(request)
            onEvent(DownloadEvent.Probed(probe.total, probe.rangeSupported, probe.etag, probe.lastModified))

            // Refuse to resume into a file that changed on the server.
            val persisted = segmentStore.load(request.id)
            val sourceChanged = persisted.isNotEmpty() &&
                ((request.expectedEtag != null && request.expectedEtag != probe.etag) ||
                    (request.expectedLastModified != null && request.expectedLastModified != probe.lastModified))
            if (sourceChanged) {
                segmentStore.clear(request.id)
                request.destination.delete()
            }

            if (!probe.rangeSupported || probe.total <= 0L) {
                singleConnection(request, probe.total, onEvent)
                return@runCatching request.destination
            }

            segmented(request, probe, persisted, onEvent)
            request.destination
        }.onFailure { error ->
            Timber.e(error, "download failed: %s", request.url)
            onEvent(DownloadEvent.Failed(error.message ?: error.javaClass.simpleName))
        }
    }

    private suspend fun probe(request: DownloadRequest): Probe = coroutineScope {
        val headRequest = Request.Builder().url(request.url).head().applyHeaders(request.headers).build()
        client.newCall(headRequest).await().use { response ->
            val length = response.header("Content-Length")?.toLongOrNull() ?: 0L
            val accepts = response.header("Accept-Ranges")?.contains("bytes", ignoreCase = true) == true
            if (response.isSuccessful && length > 0L) {
                return@coroutineScope Probe(
                    total = length,
                    rangeSupported = accepts,
                    etag = response.header("ETag"),
                    lastModified = response.header("Last-Modified"),
                    contentType = response.header("Content-Type"),
                )
            }
        }
        // Fallback: 1-byte ranged GET, total comes from Content-Range.
        val rangeRequest = Request.Builder()
            .url(request.url)
            .header("Range", "bytes=0-0")
            .applyHeaders(request.headers)
            .build()
        client.newCall(rangeRequest).await().use { response ->
            val total = response.header("Content-Range")
                ?.substringAfter('/', "")
                ?.toLongOrNull()
                ?: response.header("Content-Length")?.toLongOrNull()
                ?: 0L
            Probe(
                total = total,
                rangeSupported = response.code == 206,
                etag = response.header("ETag"),
                lastModified = response.header("Last-Modified"),
                contentType = response.header("Content-Type"),
            )
        }
    }

    private suspend fun segmented(
        request: DownloadRequest,
        probe: Probe,
        persisted: List<SegmentState>,
        onEvent: (DownloadEvent) -> Unit,
    ) = coroutineScope {
        val total = probe.total
        val segmentCount = chooseSegmentCount(total, request.maxSegments, request.minSegmentBytes)
        val size = total / segmentCount

        val segments = if (persisted.size == segmentCount && persisted.all { it.endInclusive < total }) {
            persisted
        } else {
            (0 until segmentCount).map { index ->
                val start = index * size
                val end = if (index == segmentCount - 1) total - 1 else start + size - 1
                SegmentState(index, start, end)
            }
        }

        RandomAccessFile(request.destination, "rw").use { raf ->
            raf.setLength(total)
            val channel: FileChannel = raf.channel
            val received = AtomicLong(segments.sumOf { it.written })
            val windowBytes = AtomicLong(0)
            var windowStart = System.nanoTime()
            val gate = Semaphore(segmentCount.coerceAtMost(request.maxSegments))

            suspend fun publishProgress(activeSegments: Int) {
                val now = System.nanoTime()
                val elapsedSeconds = (now - windowStart) / 1_000_000_000.0
                if (elapsedSeconds >= 0.4) {
                    val speed = windowBytes.getAndSet(0) / elapsedSeconds
                    windowStart = now
                    onEvent(
                        DownloadEvent.Progress(
                            received = received.get(),
                            total = total,
                            bytesPerSecond = speed,
                            segments = activeSegments,
                        ),
                    )
                }
            }

            suspend fun transferSegment(segment: SegmentState) {
                var current = segment.start + segment.written
                while (current <= segment.endInclusive) {
                    if (paused.value.contains(request.id)) {
                        segmentStore.save(request.id, segments)
                        onEvent(DownloadEvent.Paused)
                        return
                    }
                    // Work stealing: never ask for more than what is left in this segment.
                    val rangeEnd = min(segment.endInclusive, current + (8L * 1024 * 1024) - 1)
                    val rangeRequest = Request.Builder()
                        .url(request.url)
                        .header("Range", "bytes=$current-$rangeEnd")
                        .applyHeaders(request.headers)
                        .build()

                    client.newCall(rangeRequest).await().use { response ->
                        if (response.code != 206 && !response.isSuccessful) {
                            throw IllegalStateException("segment ${segment.index} failed: HTTP ${response.code}")
                        }
                        val body = response.body ?: throw IllegalStateException("empty body")
                        body.byteStream().use { input ->
                            val buffer = ByteArray(request.bufferSize)
                            var offset = current
                            while (true) {
                                if (paused.value.contains(request.id)) {
                                    segment.written = offset - segment.start
                                    segmentStore.save(request.id, segments)
                                    onEvent(DownloadEvent.Paused)
                                    return
                                }
                                val read = input.read(buffer)
                                if (read <= 0) break
                                val writeOffset = offset
                                val writeLength = read
                                gate.withPermit {
                                    channel.write(ByteBuffer.wrap(buffer, 0, writeLength), writeOffset)
                                }
                                offset += writeLength
                                received.addAndGet(writeLength.toLong())
                                windowBytes.addAndGet(writeLength.toLong())
                            }
                            segment.written = offset - segment.start
                            current = offset
                        }
                    }
                    publishProgress(segmentCount)
                }
            }

            segments.map { segment ->
                launch { transferSegment(segment) }
            }.forEach { it.join() }

            channel.force(true)
            segmentStore.clear(request.id)
            onEvent(DownloadEvent.Progress(received.get(), total, 0.0, 0))
            onEvent(DownloadEvent.Completed)
        }
    }

    private suspend fun singleConnection(
        request: DownloadRequest,
        total: Long,
        onEvent: (DownloadEvent) -> Unit,
    ) {
        val offset = if (request.destination.exists()) request.destination.length() else 0L
        val builder = Request.Builder().url(request.url).applyHeaders(request.headers)
        if (offset > 0) builder.header("Range", "bytes=$offset-")
        client.newCall(builder.build()).await().use { response ->
            if (!response.isSuccessful && response.code != 206) {
                throw IllegalStateException("HTTP ${response.code}")
            }
            val body = response.body ?: throw IllegalStateException("empty body")
            RandomAccessFile(request.destination, "rw").use { raf ->
                raf.seek(offset)
                val received = AtomicLong(offset)
                val windowBytes = AtomicLong(0)
                var windowStart = System.nanoTime()
                body.byteStream().use { input ->
                    val buffer = ByteArray(request.bufferSize)
                    while (true) {
                        if (paused.value.contains(request.id)) {
                            onEvent(DownloadEvent.Paused)
                            return
                        }
                        val read = input.read(buffer)
                        if (read <= 0) break
                        raf.write(buffer, 0, read)
                        received.addAndGet(read.toLong())
                        windowBytes.addAndGet(read.toLong())
                        val now = System.nanoTime()
                        val elapsed = (now - windowStart) / 1_000_000_000.0
                        if (elapsed >= 0.4) {
                            onEvent(DownloadEvent.Progress(received.get(), max(total, received.get()), windowBytes.getAndSet(0) / elapsed, 1))
                            windowStart = now
                        }
                    }
                }
            }
        }
        onEvent(DownloadEvent.Completed)
    }

    /** Adapts the segment count to the file size so small files are not over-split. */
    private fun chooseSegmentCount(total: Long, maxSegments: Int, minSegmentBytes: Long): Int {
        if (total <= 0) return 1
        val bySize = (total / minSegmentBytes).toInt()
        return bySize.coerceIn(1, maxSegments)
    }

    private data class Probe(
        val total: Long,
        val rangeSupported: Boolean,
        val etag: String?,
        val lastModified: String?,
        val contentType: String?,
    )
}

private fun Request.Builder.applyHeaders(headers: Map<String, String>): Request.Builder = apply {
    headers.forEach { (key, value) -> header(key, value) }
}

private suspend fun Semaphore.withPermit(block: suspend () -> Unit) {
    acquire()
    try {
        block()
    } finally {
        release()
    }
}

private suspend fun okhttp3.Call.await(): Response = suspendCancellableCoroutine { continuation: CancellableContinuation<Response> ->
    enqueue(object : okhttp3.Callback {
        override fun onFailure(call: okhttp3.Call, e: java.io.IOException) {
            if (continuation.isActive) continuation.resumeWith(Result.failure(e))
        }

        override fun onResponse(call: okhttp3.Call, response: Response) {
            continuation.resume(response) { response.close() }
        }
    })
    continuation.invokeOnCancellation { runCatching { cancel() } }
}

/** Persists segment offsets so resume survives process death and reboot. */
interface SegmentStore {
    fun save(taskId: String, segments: List<SegmentState>)
    fun load(taskId: String): List<SegmentState>
    fun clear(taskId: String)
}

/** Emits a Flow of events for collectors (UI, notifications, WorkManager). */
fun SegmentedDownloader.events(
    request: DownloadRequest,
    scope: CoroutineScope,
): Flow<DownloadEvent> = callbackFlow {
    val job = scope.launch {
        download(request) { event ->
            trySend(event)
            if (event is DownloadEvent.Completed || event is DownloadEvent.Failed) close()
        }
    }
    awaitClose { job.cancel() }
}


/** Convenience alias used by the queue worker. */
typealias DownloadOutcome = Result<File>
