package dev.don.designsystem.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * DON design tokens. One theme object drives colors, shape, blur, grain and
 * motion physics for every screen — the same contract the running UI preview uses.
 *
 * No Material dependency: this module only uses compose.ui / compose.foundation.
 */
@Immutable
data class DonColors(
    val c1: Color,
    val c2: Color,
    val c3: Color,
    val background: Color,
    val backgroundSoft: Color,
    val surface: Color,
    val surfaceAlt: Color,
    val border: Color,
    val text: Color,
    val textDim: Color,
    val textMute: Color,
    val success: Color = Color(0xFF67E8C7),
    val warning: Color = Color(0xFFF5CE8A),
    val danger: Color = Color(0xFFFF9D9D),
    val isDark: Boolean,
)

@Immutable
data class DonShape(
    val card: Dp = 24.dp,
    val control: Dp = 14.dp,
    val sheet: Dp = 30.dp,
    val pill: Dp = 999.dp,
)

@Immutable
data class DonGlass(
    val blur: Dp = 22.dp,
    val grain: Float = 0.20f,
    val specularAlpha: Float = 0.28f,
    val wallpaperDim: Float = 0.16f,
)

@Immutable
data class DonMotion(
    val stiffness: Float = 320f,
    val damping: Float = 28f,
    val screenFadeMillis: Int = 260,
    val reduceMotion: Boolean = false,
)

@Immutable
data class DonThemeTokens(
    val id: String,
    val colors: DonColors,
    val shape: DonShape,
    val glass: DonGlass,
    val motion: DonMotion,
    val wallpaper: String?,
)

val LocalDonColors = staticCompositionLocalOf { DonThemes.Aurora.colors }
val LocalDonShape = staticCompositionLocalOf { DonThemes.Aurora.shape }
val LocalDonGlass = staticCompositionLocalOf { DonThemes.Aurora.glass }
val LocalDonMotion = staticCompositionLocalOf { DonThemes.Aurora.motion }
val LocalDonWallpaper = staticCompositionLocalOf<String?> { DonThemes.Aurora.wallpaper }

/** The eight themes shipped in the app; values match the live preview exactly. */
object DonThemes {

    val Aurora = DonThemeTokens(
        id = "aurora",
        colors = DonColors(
            c1 = Color(0xFF4285F4),
            c2 = Color(0xFF9B72CB),
            c3 = Color(0xFFD96570),
            background = Color(0xFF07080D),
            backgroundSoft = Color(0xFF0C0E16),
            surface = Color(0x0EFFFFFF),
            surfaceAlt = Color(0x07FFFFFF),
            border = Color(0x17FFFFFF),
            text = Color(0xFFF4F6FB),
            textDim = Color(0x9EF4F6FB),
            textMute = Color(0x57F4F6FB),
            isDark = true,
        ),
        shape = DonShape(card = 24.dp, control = 14.dp),
        glass = DonGlass(blur = 22.dp, grain = 0.20f),
        motion = DonMotion(stiffness = 320f, damping = 28f),
        wallpaper = "wallpaper_aurora.webp",
    )

    val Ocean = Aurora.copy(
        id = "ocean",
        colors = Aurora.colors.copy(
            c1 = Color(0xFF22D3EE),
            c2 = Color(0xFF2563EB),
            c3 = Color(0xFF818CF8),
            background = Color(0xFF04121A),
            backgroundSoft = Color(0xFF071C26),
            text = Color(0xFFEAF9FF),
            textDim = Color(0x9EEAF9FF),
            textMute = Color(0x54EAF9FF),
        ),
        shape = DonShape(card = 26.dp, control = 15.dp),
        glass = DonGlass(blur = 26.dp, grain = 0.16f),
        motion = DonMotion(stiffness = 280f, damping = 30f),
        wallpaper = "wallpaper_ocean.webp",
    )

    val Sunset = Aurora.copy(
        id = "sunset",
        colors = Aurora.colors.copy(
            c1 = Color(0xFFFB923C),
            c2 = Color(0xFFF43F5E),
            c3 = Color(0xFFE879F9),
            background = Color(0xFF150A0C),
            backgroundSoft = Color(0xFF1E0F10),
            text = Color(0xFFFFF4EE),
            textDim = Color(0xA3FFF4EE),
            textMute = Color(0x57FFF4EE),
        ),
        shape = DonShape(card = 22.dp, control = 13.dp),
        glass = DonGlass(blur = 20.dp, grain = 0.22f),
        motion = DonMotion(stiffness = 360f, damping = 26f),
        wallpaper = "wallpaper_sunset.webp",
    )

    val Emerald = Aurora.copy(
        id = "emerald",
        colors = Aurora.colors.copy(
            c1 = Color(0xFF34D399),
            c2 = Color(0xFF0D9488),
            c3 = Color(0xFFA3E635),
            background = Color(0xFF04120D),
            backgroundSoft = Color(0xFF071A13),
            text = Color(0xFFECFDF5),
            textDim = Color(0x9EECFDF5),
            textMute = Color(0x52ECFDF5),
        ),
        shape = DonShape(card = 28.dp, control = 16.dp),
        glass = DonGlass(blur = 24.dp, grain = 0.18f),
        motion = DonMotion(stiffness = 300f, damping = 32f),
        wallpaper = "wallpaper_emerald.webp",
    )

    val Mono = Aurora.copy(
        id = "mono",
        colors = Aurora.colors.copy(
            c1 = Color(0xFFF4F4F5),
            c2 = Color(0xFFA1A1AA),
            c3 = Color(0xFF71717A),
            background = Color(0xFF09090B),
            backgroundSoft = Color(0xFF111114),
            text = Color(0xFFFAFAFA),
            textDim = Color(0x99FAFAFA),
            textMute = Color(0x52FAFAFA),
        ),
        shape = DonShape(card = 18.dp, control = 11.dp),
        glass = DonGlass(blur = 16.dp, grain = 0.28f),
        motion = DonMotion(stiffness = 420f, damping = 34f),
        wallpaper = "wallpaper_mono.webp",
    )

    val Neon = Aurora.copy(
        id = "neon",
        colors = Aurora.colors.copy(
            c1 = Color(0xFFD946EF),
            c2 = Color(0xFF8B5CF6),
            c3 = Color(0xFF22D3EE),
            background = Color(0xFF0A0512),
            backgroundSoft = Color(0xFF120A1E),
            text = Color(0xFFFDF4FF),
            textDim = Color(0xA8FDF4FF),
            textMute = Color(0x5CFDF4FF),
        ),
        shape = DonShape(card = 20.dp, control = 12.dp),
        glass = DonGlass(blur = 28.dp, grain = 0.24f),
        motion = DonMotion(stiffness = 400f, damping = 22f),
        wallpaper = "wallpaper_neon.webp",
    )

    val Royal = Aurora.copy(
        id = "royal",
        colors = Aurora.colors.copy(
            c1 = Color(0xFF818CF8),
            c2 = Color(0xFF6D28D9),
            c3 = Color(0xFFF5D78E),
            background = Color(0xFF080A1C),
            backgroundSoft = Color(0xFF0E1130),
            text = Color(0xFFEEF2FF),
            textDim = Color(0xA3EEF2FF),
            textMute = Color(0x57EEF2FF),
        ),
        shape = DonShape(card = 30.dp, control = 17.dp),
        glass = DonGlass(blur = 30.dp, grain = 0.14f),
        motion = DonMotion(stiffness = 260f, damping = 26f),
        wallpaper = "wallpaper_royal.webp",
    )

    val Sakura = Aurora.copy(
        id = "sakura",
        colors = Aurora.colors.copy(
            c1 = Color(0xFFF472B6),
            c2 = Color(0xFFA855F7),
            c3 = Color(0xFF38BDF8),
            background = Color(0xFFFBF7FA),
            backgroundSoft = Color(0xFFF4EDF3),
            surface = Color(0xB8FFFFFF),
            surfaceAlt = Color(0x80FFFFFF),
            border = Color(0x1F50283C),
            text = Color(0xFF2A1B28),
            textDim = Color(0xA82A1B28),
            textMute = Color(0x6B2A1B28),
            isDark = false,
        ),
        shape = DonShape(card = 26.dp, control = 15.dp),
        glass = DonGlass(blur = 24.dp, grain = 0.10f, wallpaperDim = 0.10f),
        motion = DonMotion(stiffness = 320f, damping = 28f),
        wallpaper = "wallpaper_sakura.webp",
    )

    val all: List<DonThemeTokens> = listOf(Aurora, Ocean, Sunset, Emerald, Mono, Neon, Royal, Sakura)

    fun byId(id: String): DonThemeTokens = all.firstOrNull { it.id == id } ?: Aurora
}
