# DON — Android package (JP PROJ)

Native Android implementation of the same product the running UI preview shows.
The web preview in this repository is a **real, working app** (real downloads, real
IndexedDB storage, real MediaRecorder/Canvas processing). This folder contains the
Kotlin + Jetpack Compose project that ships the same screens as an APK, adding the
native-only engines (yt-dlp, FFmpeg, Cronet/HTTP-3, foreground service, biometrics).

```
JP PROJ/
├── settings.gradle.kts                 module graph (17 modules)
├── gradle/libs.versions.toml           version catalog — no Material artifact anywhere
├── app/
│   ├── build.gradle.kts                application module, R8, ABI splits, desugaring
│   └── src/main/AndroidManifest.xml    permissions, service types, share target, tile, widget
├── core/
│   ├── common/                         dispatchers, result types, formatters, clock
│   ├── designsystem/                   DonThemes (8 themes), glass, motion, dock, sheets
│   ├── network/                        OkHttp + Cronet, DoH, DNS cache, encrypted CookieJar
│   └── database/                       Room entities: tasks, segments, library, history, notes
├── engine/
│   ├── downloader/                     SegmentedDownloader, queue worker, foreground service
│   ├── extractors/                     yt-dlp wrapper + native fast-path extractors
│   └── media/                          FFmpeg wrapper (mux, transcode, metadata, subtitles)
└── feature/
    ├── home/  tube/  downloads/  browser/  files/  tools/  player/  settings/
```

## Build

```bash
cd "JP PROJ"
./gradlew :app:assembleDebug           # debug APK
./gradlew :app:assembleRelease         # signed release (DON_KEYSTORE env vars)
./gradlew test lint                    # unit tests + lint
./gradlew :app:dependencies | grep -i material   # must print nothing
```

Requirements: JDK 17, Android SDK 35, NDK r27 (for aria2c/FFmpeg/libtorrent4j ABIs).

## Screen parity with the running preview

| Preview screen | Android module | Native additions |
|---|---|---|
| Home (real link analysis) | `:feature:home` | yt-dlp stage 3, Jsoup fallback, clipboard chip, Share Intent |
| DON Tube | `:feature:tube` | Room-backed feed, local profile export/import, MediaStore import |
| Downloads | `:feature:downloads` + `:engine:downloader` | Foreground `dataSync` service, rich notifications, WorkManager scheduling, boot resume |
| Browser | `:feature:browser` | WebView + `shouldInterceptRequest` sniffer, adblock-rust lists, Cloudflare cookie handoff |
| Library | `:feature:files` | MediaStore/SAF, biometric vault (AES + Security-Crypto) |
| Tools | `:feature:tools` | FFmpeg/MediaCodec HEVC-AV1, VMAF/SSIM gate, mozjpeg/oxipng/zopfli |
| Player | `:feature:player` | Media3 ExoPlayer, PiP, MediaSession, background audio, subtitle tracks |
| Settings | `:feature:settings` | DataStore prefs, yt-dlp auto-update, backup/restore JSON |

## Design system

`core/designsystem/.../DonThemes.kt` defines the eight themes (Aurora, Ocean, Sunset,
Emerald, Mono, Neon, Royal, Sakura). Each token set carries colors **and** corner radius,
blur, grain and spring physics, so switching a theme re-shapes every screen — the same
contract the preview implements through CSS custom properties.

Built on `compose.foundation` / `compose.ui` / `compose.animation` plus Compose Unstyled and
Haze. No `androidx.compose.material*`, no Material Components, no Material Icons.

## Legal

No DRM (Widevine/FairPlay/PlayReady) circumvention and no paywall bypass. The app shows a
copyright notice and the user is responsible for respecting the rights of content owners.
