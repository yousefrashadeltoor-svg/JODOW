pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Compose Unstyled + Haze + youtubedl-android artifacts
        maven("https://jitpack.io")
    }
}

rootProject.name = "DON"

include(":app")
include(":core:common")
include(":core:designsystem")
include(":core:network")
include(":core:database")
include(":engine:downloader")
include(":engine:extractors")
include(":engine:media")
include(":feature:home")
include(":feature:tube")
include(":feature:downloads")
include(":feature:browser")
include(":feature:files")
include(":feature:tools")
include(":feature:player")
include(":feature:settings")
