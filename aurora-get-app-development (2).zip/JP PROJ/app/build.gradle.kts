plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}

android {
    namespace = "dev.don.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.don.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 30
        versionName = "3.0.0"
        resourceConfigurations += listOf("ar", "en")
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64") }
    }

    signingConfigs {
        create("releaseLocal") {
            storeFile = file(System.getenv("DON_KEYSTORE") ?: "don.keystore")
            storePassword = System.getenv("DON_STORE_PASS") ?: ""
            keyAlias = System.getenv("DON_KEY_ALIAS") ?: "don"
            keyPassword = System.getenv("DON_KEY_PASS") ?: ""
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("releaseLocal")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging {
        resources.excludes += setOf("META-INF/*.kotlin_module", "DebugProbesKt.bin")
        jniLibs.useLegacyPackaging = false
    }
}

dependencies {
    implementation(project(":core:common"))
    implementation(project(":core:designsystem"))
    implementation(project(":core:network"))
    implementation(project(":core:database"))
    implementation(project(":engine:downloader"))
    implementation(project(":engine:extractors"))
    implementation(project(":engine:media"))
    implementation(project(":feature:home"))
    implementation(project(":feature:tube"))
    implementation(project(":feature:downloads"))
    implementation(project(":feature:browser"))
    implementation(project(":feature:files"))
    implementation(project(":feature:tools"))
    implementation(project(":feature:player"))
    implementation(project(":feature:settings"))

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.splashscreen)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.work)
    implementation(libs.hilt.work)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.timber)
    implementation(libs.compose.foundation)
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.animation)
    implementation(libs.compose.unstyled)
    implementation(libs.haze)
    implementation(libs.coil.compose)
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}
