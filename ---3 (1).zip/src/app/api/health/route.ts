// Static health endpoint — this project has NO backend and NO database by design.
export const dynamic = "force-static";

export function GET() {
  return Response.json({ status: "ok", app: "JO DON", backend: "none", database: "none" });
}
