"use client";

import { motion } from "framer-motion";
import {
  Fingerprint,
  Globe,
  Gauge,
  Layers,
  Link2,
  Minimize2,
  Palette,
  Play,
  ShieldCheck,
  Sparkles,
  Video,
  Zap,
} from "lucide-react";
import HomeScreen from "@/components/showcase/screens/HomeScreen";
import Showcase from "@/components/showcase/Showcase";
import { ThemeProvider, ThemeGallery } from "@/components/showcase/theme";
import { spring, springSoft } from "@/components/showcase/ui";

const features = [
  { icon: Video, title: "يوتيوب داخل التطبيق", desc: "واجهة أصلية كاملة: الرئيسية، شورتس، اشتراكات، بحث بمقترحات، اقتراحات لا متناهية حسب مشاهداتك، زر تحميل ونسخ رابط تحت كل فيديو، وملف محلي يُصدَّر ويُستورد — بلا تسجيل دخول." },
  { icon: Palette, title: "٧ ثيمات تتحكم بكل شيء", desc: "كل ثيم يعيد تعريف الخلفية والزجاج والألوان وأنماط الأنيميشن والتوهج وسرعة الزنبرك — داخل التطبيق بصور معاينة حقيقية لكل ثيم." },
  { icon: Zap, title: "محرّك مجزّأ حتى 32 اتصالًا", desc: "تقسيم ديناميكي + Work-Stealing، HTTP/2 وHTTP/3 عبر Cronet، تحميل مقاطع HLS/DASH بالتوازي، واستكمال دقيق بعد إعادة التشغيل." },
  { icon: Link2, title: "تحليل مرحلي فائق", desc: "خمس مراحل متوازية: تنظيف فوري، HEAD/Range لحجم حقيقي، Native Fast Path، ثم yt-dlp الكامل — بدون حجب الواجهة." },
  { icon: Globe, title: "متصفح يصطاد الملفات", desc: "Sniffer حقيقي لـ video/audio/m3u8/blob، حجب إعلانات بقوائم EasyList، وتمرير cf_clearance والكوكيز إلى محرك التحميل." },
  { icon: Minimize2, title: "تصغير صادق", desc: "Lossless أو شفاف الجودة الموثق بـ SSIM ≥ 0.95، مقارنة قبل/بعد بالسحب، ولا ناتج أكبر من الأصل أبدًا." },
  { icon: Layers, title: "مشغّل محلي متقدم", desc: "قص مرئي بمقابض على الإطارات، مؤقت نوم، تكرار (مقطع/الكل)، سرعات، مؤثرات صوتية حقيقية عبر Visualizer، وتعيين نغمة رنين." },
  { icon: Fingerprint, title: "خصوصية مطلقة", desc: "قبو مشفر بالبصمة AES-256-GCM، صفر Analytics وصفر Tracking، وكل البيانات على جهازك." },
];

const pipeline = [
  { t: "< 50ms", label: "تنظيف + دومين + Preconnect" },
  { t: "< 300ms", label: "HEAD/Range + حجم حقيقي" },
  { t: "< 1.5s", label: "Native Fast Path" },
  { t: "حتى 4s", label: "yt-dlp: كل الصيغ" },
  { t: "خلفي", label: "Jsoup / WebView Sniffer" },
];

export default function Page() {
  return (
    <ThemeProvider>
      <main className="relative min-h-screen overflow-hidden">
        <div className="pointer-events-none fixed inset-0 -z-10">
          <div className="animate-blob absolute top-[-10%] right-[-10%] h-[42rem] w-[42rem] rounded-full opacity-20 blur-[130px]" style={{ background: "var(--c1)" }} />
          <div className="animate-blob absolute top-[30%] left-[-14%] h-[38rem] w-[38rem] rounded-full opacity-20 blur-[130px] [animation-delay:-8s]" style={{ background: "var(--c2)" }} />
          <div className="animate-blob absolute bottom-[-14%] right-[20%] h-[36rem] w-[36rem] rounded-full opacity-16 blur-[130px] [animation-delay:-14s]" style={{ background: "var(--c3)" }} />
        </div>

        <header className="sticky top-0 z-50 px-5 pt-4 sm:px-10">
          <div className="glass-deep specular mx-auto flex max-w-7xl items-center gap-3 rounded-full px-5 py-3">
            <span className="aurora-gradient grid h-9 w-9 place-items-center rounded-xl">
              <Sparkles size={16} className="text-white" />
            </span>
            <div className="leading-none">
              <p className="text-sm font-bold">𝒥𝒪 DON</p>
              <p className="text-[10px] text-[#6b7386] font-[family-name:var(--font-outfit-src)]" dir="ltr">JO DON</p>
            </div>
            <nav className="mx-auto hidden items-center gap-6 text-xs text-[#a7aec2] sm:flex">
              <a href="#showcase" className="transition-colors hover:text-white">جولة الشاشات</a>
              <a href="#themes" className="transition-colors hover:text-white">الثيمات</a>
              <a href="#features" className="transition-colors hover:text-white">المحرك</a>
            </nav>
            <span className="glass hidden rounded-full px-3.5 py-1.5 text-[11px] font-semibold text-[#a7aec2] sm:block">
              واجهة حقيقية · بلا قاعدة بيانات
            </span>
          </div>
        </header>

        <section className="relative mx-auto grid max-w-7xl items-center gap-12 px-5 pt-16 pb-20 sm:px-10 lg:grid-cols-2 lg:pt-24">
          <div>
            <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={springSoft} className="glass specular flex w-fit items-center gap-2 rounded-full px-4 py-2">
              <span className="relative flex h-2 w-2">
                <span className="aurora-gradient absolute h-2 w-2 animate-ping rounded-full opacity-75" />
                <span className="aurora-gradient h-2 w-2 rounded-full" />
              </span>
              <span className="text-xs font-semibold text-[#a7aec2]">مدير تحميلات + يوتيوب محلي + مشغل متقدم</span>
            </motion.div>

            <motion.h1 initial={{ opacity: 0, y: 26, filter: "blur(12px)" }} animate={{ opacity: 1, y: 0, filter: "blur(0px)" }} transition={{ ...springSoft, delay: 0.1 }} className="mt-6 text-4xl font-bold leading-[1.25] sm:text-6xl sm:leading-[1.15]">
              <span className="aurora-gradient-text">𝒥𝒪 DON</span>
              <br />
              حمّل، شاهد، واصنع.
            </motion.h1>

            <motion.p initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ ...springSoft, delay: 0.24 }} className="mt-5 max-w-lg text-sm leading-8 text-[#a7aec2] sm:text-base">
              تطبيق أندرويد واحد: محرك تحميل مجزّأ بمستوى احترافي، يوتيوب مدمج بهوية محلية بلا حساب،
              ومشغّل موسيقى وفيديو بأدوات قص ونغمة رنين ومؤقت نوم — بسبعة ثيمات كاملة تتحكم في كل شيء.
            </motion.p>

            <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ ...springSoft, delay: 0.36 }} className="mt-8 flex flex-wrap items-center gap-3">
              <a href="#showcase" className="aurora-gradient flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-bold text-white transition-transform hover:scale-[1.03]">
                <Play size={15} className="flip-rtl" />
                جرّب الشاشات الآن
              </a>
              <a href="#themes" className="glass specular flex items-center gap-2 rounded-full px-6 py-3.5 text-sm font-semibold text-[var(--fg)]">
                <Palette size={14} style={{ color: "var(--c2)" }} />
                الثيمات السبعة
              </a>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ ...springSoft, delay: 0.48 }} className="mt-10 grid max-w-md grid-cols-3 gap-3">
              {[
                { v: "1800+", l: "موقع مدعوم" },
                { v: "×32", l: "اتصال متوازٍ" },
                { v: "7", l: "ثيمات كاملة" },
              ].map((s) => (
                <div key={s.l} className="glass specular rounded-2xl p-3.5 text-center">
                  <p className="aurora-gradient-text text-xl font-bold font-[family-name:var(--font-outfit-src)]" dir="ltr">{s.v}</p>
                  <p className="mt-1 text-[10px] text-[#6b7386]">{s.l}</p>
                </div>
              ))}
            </motion.div>
          </div>

          <div className="relative mx-auto lg:mx-0">
            <div className="breathe absolute -inset-12 -z-10 rounded-full opacity-25 blur-[100px]" style={{ background: "var(--glow)" }} />
            <motion.div initial={{ opacity: 0, y: 46, rotate: 2, filter: "blur(16px)" }} animate={{ opacity: 1, y: 0, rotate: 0, filter: "blur(0px)" }} transition={{ ...springSoft, delay: 0.3, mass: 0.8 }} className="animate-float">
              <HomeScreen />
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ ...spring, delay: 0.9 }} className="glass-deep specular absolute top-[14%] -left-6 hidden items-center gap-2 rounded-2xl px-3.5 py-2.5 sm:flex">
              <Video size={15} style={{ color: "var(--c2)" }} />
              <div className="leading-tight">
                <p className="text-[10px] font-bold">JO DON · يوتيوب محلي</p>
                <p className="text-[8.5px] text-[#6b7386]">بلا تسجيل دخول</p>
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ ...spring, delay: 1.1 }} className="glass-deep specular absolute right-[-14px] bottom-[22%] hidden items-center gap-2 rounded-2xl px-3.5 py-2.5 sm:flex">
              <Gauge size={15} style={{ color: "var(--c1)" }} />
              <div className="leading-tight">
                <p className="text-[10px] font-bold" dir="ltr">24.6 MB/s</p>
                <p className="text-[8.5px] text-[#6b7386]">عبْر 16 اتصالًا</p>
              </div>
            </motion.div>
          </div>
        </section>

        <section id="pipeline" className="relative mx-auto max-w-7xl px-5 pb-8 sm:px-10">
          <div className="glass-deep specular overflow-hidden rounded-[32px] p-7 sm:p-10">
            <p className="text-center text-sm font-semibold" style={{ color: "var(--c2)" }}>خط التحليل المتوازي</p>
            <h2 className="mx-auto mt-2 max-w-xl text-center text-2xl font-bold leading-snug sm:text-3xl">كل مرحلة تُبث نتيجتها فورًا</h2>
            <div className="mt-8 grid gap-3 sm:grid-cols-5">
              {pipeline.map((p, i) => (
                <motion.div key={p.t} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ ...spring, delay: i * 0.08 }} className="glass specular rounded-2xl p-4 text-center">
                  <p className="aurora-gradient-text text-sm font-bold font-[family-name:var(--font-outfit-src)]" dir="ltr">{p.t}</p>
                  <p className="mt-1.5 text-[11px] leading-relaxed text-[#a7aec2]">{p.label}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <Showcase />

        <section id="themes" className="relative mx-auto max-w-7xl px-5 py-16 sm:px-10">
          <div className="mb-10 text-center">
            <p className="text-sm font-semibold" style={{ color: "var(--c2)" }}>الثيمات</p>
            <h2 className="aurora-gradient-text mx-auto mt-3 max-w-2xl text-3xl font-bold sm:text-4xl">سبعة ثيمات · صورة واقعية لكل ثيم</h2>
            <p className="mx-auto mt-3 max-w-xl text-sm leading-7 text-[#a7aec2]">
              اضغط أي ثيم فورًا تتبدّل ألوان الموقع والشاشات والتوهج — نفس السلوك داخل التطبيق، حيث يغيّر الثيم
              الخلفية والزجاج وألوان الأنواع وسرعة الأنيميشن.
            </p>
          </div>
          <ThemeGallery />
        </section>

        <section id="features" className="relative mx-auto max-w-7xl px-5 py-16 sm:px-10">
          <div className="mb-12 text-center">
            <p className="text-sm font-semibold" style={{ color: "var(--c2)" }}>المحرك والميزات</p>
            <h2 className="aurora-gradient-text mx-auto mt-3 max-w-2xl text-3xl font-bold sm:text-4xl">ثمانية أنظمة في تطبيق واحد</h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((f, i) => (
              <motion.div key={f.title} initial={{ opacity: 0, y: 26 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-40px" }} transition={{ ...spring, delay: (i % 4) * 0.07 }} className="glass specular group rounded-3xl p-6 transition-transform duration-300 hover:-translate-y-1.5">
                <span className="aurora-gradient grid h-11 w-11 place-items-center rounded-2xl transition-transform duration-300 group-hover:scale-110" style={{ boxShadow: "0 0 26px -6px var(--glow)" }}>
                  <f.icon size={19} className="text-white" />
                </span>
                <h3 className="mt-4 text-sm font-bold leading-6">{f.title}</h3>
                <p className="mt-2 text-xs leading-6 text-[#a7aec2]">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </section>

        <footer className="border-t border-white/5 px-5 py-10 sm:px-10">
          <div className="mx-auto flex max-w-7xl flex-col items-center gap-4 text-center">
            <span className="aurora-gradient grid h-10 w-10 place-items-center rounded-2xl">
              <Sparkles size={17} className="text-white" />
            </span>
            <p className="text-sm font-bold">𝒥𝒪 DON</p>
            <p className="flex flex-wrap items-center justify-center gap-3 text-[11px] text-[#6b7386]">
              <span className="flex items-center gap-1"><ShieldCheck size={11} /> بلا تتبع</span>
              <span className="flex items-center gap-1"><ShieldCheck size={11} /> بلا قاعدة بيانات</span>
              <span className="flex items-center gap-1"><ShieldCheck size={11} /> Offline-first</span>
            </p>
            <p className="max-w-lg text-[11px] leading-6 text-[#6b7386]">
              الكود الأصلي الكامل (Kotlin + Compose Foundation فقط، صفر Material) موجود في مجلد
              <b className="text-[#a7aec2]"> JP PROJ</b>. المسؤولية على المستخدم في احترام حقوق النشر —
              لا تجاوز لـ DRM أو Paywall.
            </p>
          </div>
        </footer>
      </main>
    </ThemeProvider>
  );
}
