import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Outfit, IBM_Plex_Sans_Arabic } from "next/font/google";
import "./globals.css";

const outfit = Outfit({ subsets: ["latin"], variable: "--font-outfit-src", weight: ["300","400","500","600","700"] });
const plexArabic = IBM_Plex_Sans_Arabic({ subsets: ["arabic"], variable: "--font-plex-src", weight: ["300","400","500","600","700"] });

export const metadata: Metadata = {
  title: "𝒥𝒪 DON · التطبيق الكامل",
  description:
    "𝒥𝒪 DON — مدير تحميلات زجاجي فائق السرعة مع يوتيوب محلي ومشغل متقدم. واجهة تفاعلية حقيقية بدون محاكاة وبدون قاعدة بيانات.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={`${outfit.variable} ${plexArabic.variable}`}>
      <body className="bg-[#0b0d12] text-[#f2f4fa] antialiased font-[family-name:var(--font-plex-src)]">
        {children}
      </body>
    </html>
  );
}
