"use client";

import { motion } from "framer-motion";
import {
  BatteryFull,
  Download,
  File,
  Globe,
  Home,
  Image as ImageIcon,
  Music4,
  Play,
  Settings,
  Signal,
  Video,
  Wifi,
} from "lucide-react";
import type { ReactNode } from "react";

/** Phone frame wrapping a screen with the mesh-gradient backdrop + status bar. */
export function Phone({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={`phone-shadow relative aspect-[9.4/19.5] w-[300px] overflow-hidden rounded-[44px] bg-[#0b0d12] sm:w-[320px] ${className}`}
    >
      {/* mesh gradient blobs */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="animate-blob absolute -top-16 -right-16 h-64 w-64 rounded-full bg-[#4e8cff]/25 blur-[70px]" />
        <div className="animate-blob absolute top-1/3 -left-20 h-72 w-72 rounded-full bg-[#9b72cb]/22 blur-[80px] [animation-delay:-6s]" />
        <div className="animate-blob absolute -bottom-10 right-0 h-64 w-64 rounded-full bg-[#e0668c]/18 blur-[75px] [animation-delay:-12s]" />
      </div>
      <div className="noise absolute inset-0" />

      {/* status bar */}
      <div className="relative z-10 flex items-center justify-between px-6 pt-3 text-[10px] text-[#a7aec2]">
        <span className="font-[family-name:var(--font-outfit-src)] font-semibold tracking-wide">9:41</span>
        <div className="flex items-center gap-1.5">
          <Signal size={11} strokeWidth={2.4} />
          <Wifi size={11} strokeWidth={2.4} />
          <BatteryFull size={13} strokeWidth={2} />
        </div>
      </div>

      {/* punch-hole camera */}
      <div className="absolute top-3 left-1/2 z-20 h-5 w-5 -translate-x-1/2 rounded-full bg-black shadow-[inset_0_0_4px_rgba(255,255,255,.15)]" />

      <div className="relative z-10 h-[calc(100%-28px)] overflow-hidden">{children}</div>
    </div>
  );
}

/** Floating glass dock with a morphing pill indicator. */
export function Dock({ active }: { active: "home" | "downloads" | "youtube" | "browser" | "files" | "settings" }) {
  const items = [
    { id: "home", icon: Home, label: "الرئيسية" },
    { id: "downloads", icon: Download, label: "التحميلات" },
    { id: "youtube", icon: Play, label: "يوتيوب" },
    { id: "browser", icon: Globe, label: "المتصفح" },
    { id: "files", icon: File, label: "الملفات" },
    { id: "settings", icon: Settings, label: "الإعدادات" },
  ] as const;
  return (
    <div
      className="glass-deep specular absolute inset-x-4 bottom-4 z-30 flex items-center justify-around rounded-full px-2 py-2.5"
    >
      {items.map((it) => {
        const on = active === it.id;
        return (
          <div key={it.id} className="relative grid place-items-center px-2 py-1">
            {on && (
              <motion.span
                layoutId="dock-indicator"
                transition={{ type: "spring", damping: 20, stiffness: 320 }}
                className="aurora-gradient absolute inset-0 -z-0 rounded-full opacity-40 blur-[1px]"
                style={{ borderRadius: 999 }}
              />
            )}
            <it.icon
              size={19}
              strokeWidth={on ? 2.4 : 1.8}
              className={on ? "relative text-white drop-shadow-[0_0_6px_rgba(224,102,140,.8)]" : "text-[#6b7386]"}
            />
            {it.id === "downloads" && !on && (
              <span className="absolute -top-0.5 -left-0.5 grid h-3 w-3 place-items-center rounded-full bg-[#e0668c] text-[7px] font-bold text-white">
                3
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
}

export const TYPE_META = {
  audio: { label: "صوت", icon: Music4, color: "#3ec6d3" },
  image: { label: "صور", icon: ImageIcon, color: "#e0668c" },
  video: { label: "فيديو", icon: Video, color: "#7c6cff" },
  file: { label: "ملفات", icon: File, color: "#f2a45c" },
} as const;

export { Play };
