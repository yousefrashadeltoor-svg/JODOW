"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  Download,
  File,
  Gauge,
  Home,
  Minimize2,
  MonitorSmartphone,
  Palette,
  Play,
  RefreshCcw,
  Settings,
  Sparkles,
  Tv,
  Video,
} from "lucide-react";
import { useState } from "react";
import { spring } from "./ui";
import { THEMES, ThemeGallery, useTheme } from "./theme";
import BrowserScreen from "./screens/BrowserScreen";
import CompressorScreen from "./screens/CompressorScreen";
import ConverterScreen from "./screens/ConverterScreen";
import DownloadsScreen from "./screens/DownloadsScreen";
import FilesScreen from "./screens/FilesScreen";
import HomeScreen from "./screens/HomeScreen";
import OnboardingScreen from "./screens/OnboardingScreen";
import PlayerScreen from "./screens/PlayerScreen";
import SettingsScreen from "./screens/SettingsScreen";
import YouTubeScreen from "./screens/YouTubeScreen";

type ScreenDef = {
  id: string;
  label: string;
  icon: any;
  el: () => React.ReactElement;
  title: string;
  desc: string;
};

const screens: ScreenDef[] = [
  { id: "home", label: "الرئيسية", icon: Home, el: HomeScreen, title: "تحليل فوري وأزرار ذكية", desc: "الصق رابطًا فيظهر التحليل تدريجيًا فورًا، والأزرار الأربعة لا تظهر إلا بمحتوى فعلي من نوعها." },
  { id: "youtube", label: "يوتيوب", icon: Video, el: YouTubeScreen, title: "يوتيوب محلي داخل التطبيق", desc: "واجهة أصلية بشورتس وحسابي وبحث واقتراحات لا متناهية، وزر تحميل تحت كل فيديو، وملف محلي قابل للتصدير والاستيراد — بلا تسجيل دخول." },
  { id: "downloads", label: "التحميلات", icon: Download, el: DownloadsScreen, title: "محرك مجزّأ يقود نفسه", desc: "حتى 32 اتصالًا متوازيًا مع Work-Stealing واستكمال دقيق، وضغط زر الإيقاف/الإكمال يعمل فعليًا." },
  { id: "browser", label: "المتصفح", icon: MonitorSmartphone, el: BrowserScreen, title: "اصطياد ذكي في الصفحة", desc: "اصغط زر الاصطياد فتظهر قائمة الملفات المكتشفة مع أحجامها وزر التحميل." },
  { id: "converter", label: "المحوّل", icon: RefreshCcw, el: ConverterScreen, title: "تحويل دفعي", desc: "اختر الصيغة الهدف وتُضاف مهامك للطابور — Stream Copy عند الإمكان." },
  { id: "compressor", label: "الضاغط", icon: Minimize2, el: CompressorScreen, title: "تصغير صادق", desc: "اسحب الفاصل على الصورة لمقارنة قبل/بعد بنفسك، وبدّل بين Lossless وشفاف الجودة." },
  { id: "player", label: "المشغل", icon: Tv, el: PlayerScreen, title: "مشغل محلي متقدم", desc: "اسحب مقابضي القص على الإطارات، اضبط مؤقت النوم، كرّر مقطعًا أو الكل، وسرعات ومؤثرات — كلها تعمل داخل هذه المعاينة." },
  { id: "files", label: "الملفات", icon: File, el: FilesScreen, title: "مكتبة منظمة", desc: "بدّل بين الشبكة والقائمة ورشّح حسب النوع؛ كل ملف يتلوّن بلون نوعه." },
  { id: "settings", label: "الإعدادات", icon: Settings, el: SettingsScreen, title: "تحكم دقيق", desc: "بدّل الثيم من الأعلى وشاهد كل الشاشات تتغير فورًا بلون الثيم الجديد." },
  { id: "onboarding", label: "الترحيب", icon: Sparkles, el: OnboardingScreen, title: "انبثاقة أولى", desc: "Orb نابض وعناوين متدرجة وجرعة قانونية صادقة." },
];

export default function Showcase() {
  const [currentId, setCurrentId] = useState("home");
  const [showThemes, setShowThemes] = useState(false);
  const { theme, setTheme } = useTheme();
  const current = screens.find((s) => s.id === currentId)!;
  const ScreenEl = current.el;

  return (
    <section id="showcase" className="relative mx-auto max-w-7xl px-5 py-24 sm:px-10">
      <div className="mb-10 text-center">
        <p className="text-sm font-semibold" style={{ color: "var(--c2)" }}>جولة تفاعلية حقيقية</p>
        <h2 className="aurora-gradient-text mx-auto mt-3 max-w-2xl text-3xl font-bold leading-tight sm:text-5xl">
          كل شاشة تعمل فعليًا
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-sm leading-7 text-[#a7aec2]">
          لا محاكاة ولا دورات تلقائية — اضغط، اسحب، بدّل الثيم، حمّل، صدّر ملفك الشخصي، واسحب مقابض القص.
        </p>
      </div>

      {/* live theme control */}
      <div className="mb-8 flex flex-wrap items-center justify-center gap-2">
        <button
          onClick={() => setShowThemes((s) => !s)}
          className="glass flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold"
        >
          <Palette size={14} style={{ color: "var(--c2)" }} />
          الثيمات ({THEMES.length})
          <span className="aurora-gradient-text font-bold">{THEMES.find((t) => t.id === theme)?.name}</span>
        </button>
        {THEMES.map((t) => (
          <button
            key={t.id}
            onClick={() => setTheme(t.id)}
            title={t.name}
            className={`h-7 w-7 rounded-full ring-2 transition-transform hover:scale-110 ${theme === t.id ? "ring-white" : "ring-white/20"}`}
            style={{ backgroundImage: `url(${t.img})`, backgroundSize: "cover" }}
          />
        ))}
      </div>

      <AnimatePresence>
        {showThemes && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-10 overflow-hidden"
          >
            <ThemeGallery />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid items-center gap-10 lg:grid-cols-[1fr_auto_1fr]">
        <div className="order-2 flex flex-col gap-3 lg:order-1">
          {screens.slice(0, 5).map((s) => (
            <Selector key={s.id} s={s} active={current.id === s.id} onClick={() => setCurrentId(s.id)} />
          ))}
        </div>

        <div className="animate-float order-1 mx-auto lg:order-2">
          <div className="relative">
            <div className="breathe absolute -inset-10 -z-10 rounded-full opacity-25 blur-[90px]" style={{ background: "var(--glow)" }} />
            <AnimatePresence mode="wait">
              <motion.div
                key={current.id}
                initial={{ opacity: 0, scale: 0.92, y: 24, filter: "blur(14px)" }}
                animate={{ opacity: 1, scale: 1, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, scale: 0.94, y: -16, filter: "blur(10px)" }}
                transition={{ ...spring, mass: 0.9 }}
              >
                <ScreenEl />
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        <div className="order-3 flex flex-col gap-3">
          {screens.slice(5).map((s) => (
            <Selector key={s.id} s={s} active={current.id === s.id} onClick={() => setCurrentId(s.id)} />
          ))}
          <div className="glass specular rounded-3xl p-5">
            <div className="flex items-center gap-2" style={{ color: "var(--c2)" }}>
              <Gauge size={16} />
              <p className="text-sm font-bold">أداء مقاس بالأرقام</p>
            </div>
            <ul className="mt-3 flex flex-col gap-2 text-xs text-[#a7aec2]">
              <li className="flex justify-between"><span>أول معلومة بعد اللصق</span><b className="aurora-gradient-text" dir="ltr">&lt; 300ms</b></li>
              <li className="flex justify-between"><span>كل الجودات (مواقع شائعة)</span><b className="aurora-gradient-text" dir="ltr">&lt; 1.5s</b></li>
              <li className="flex justify-between"><span>استغلال سرعة الخط</span><b className="aurora-gradient-text" dir="ltr">≥ 90%</b></li>
              <li className="flex justify-between"><span>الإطارات</span><b className="aurora-gradient-text" dir="ltr">60/120fps</b></li>
            </ul>
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={current.id + "-caption"}
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="mx-auto mt-10 max-w-xl text-center"
        >
          <h3 className="text-lg font-bold">{current.title}</h3>
          <p className="mt-2 text-sm leading-7 text-[#a7aec2]">{current.desc}</p>
        </motion.div>
      </AnimatePresence>
    </section>
  );
}

function Selector({ s, active, onClick }: { s: ScreenDef; active: boolean; onClick: () => void }) {
  const Icon = s.icon;
  return (
    <motion.button
      onClick={onClick}
      whileTap={{ scale: 0.98 }}
      transition={spring}
      className={`specular group flex items-center gap-4 rounded-3xl p-4 text-right transition-colors ${active ? "glass" : "hover:bg-white/[.03]"}`}
      style={active ? { boxShadow: "inset 0 1px 0 rgba(255,255,255,.14), 0 0 40px -14px var(--glow)" } : undefined}
    >
      <span
        className={`grid h-11 w-11 shrink-0 place-items-center rounded-2xl transition-all ${active ? "aurora-gradient text-white" : "bg-white/6 text-[#a7aec2]"}`}
        style={active ? { boxShadow: "0 0 24px -4px var(--glow)" } : undefined}
      >
        <Icon size={19} />
      </span>
      <span className="min-w-0">
        <span className={`block text-sm font-bold ${active ? "text-white" : "text-[#a7aec2]"}`}>{s.label}</span>
        <span className="mt-0.5 block truncate text-xs text-[#6b7386]">{s.title}</span>
      </span>
      {active && <motion.span layoutId="sel-dot" className="aurora-gradient mr-auto h-2 w-2 rounded-full" />}
    </motion.button>
  );
}
