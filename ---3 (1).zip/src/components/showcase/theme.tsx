"use client";

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { motion } from "framer-motion";

export type ThemeId = "aurora" | "ocean" | "sunset" | "emerald" | "mono" | "neon" | "light";

export const THEMES: {
  id: ThemeId;
  name: string;
  en: string;
  tagline: string;
  img: string;
  motion: string;
}[] = [
  { id: "aurora", name: "أورورا", en: "Aurora", tagline: "أزرق → بنفسجي → وردي", img: "/themes/aurora.jpg", motion: "زنبرك 320 · توهج 3.2s" },
  { id: "ocean", name: "المحيط", en: "Ocean", tagline: "سماوي → تركوازي", img: "/themes/ocean.jpg", motion: "زنبرك 260 · توهج 4.2s" },
  { id: "sunset", name: "الغروب", en: "Sunset", tagline: "كهرماني → مرجاني", img: "/themes/sunset.jpg", motion: "زنبرك 380 · توهج 2.6s" },
  { id: "emerald", name: "الزمرد", en: "Emerald", tagline: "أخضر → ليموني", img: "/themes/emerald.jpg", motion: "زنبرك 240 · توهج 5s" },
  { id: "mono", name: "أحادي", en: "Mono", tagline: "فضي → جرافيت", img: "/themes/mono.jpg", motion: "زنبرك 420 · بلا جزيئات" },
  { id: "neon", name: "نيون", en: "Neon", tagline: "سماوي كهربي → بنفسجي", img: "/themes/neon.jpg", motion: "زنبرك 460 · توهج 2s" },
  { id: "light", name: "فاتح", en: "Light", tagline: "نهاري متكامل", img: "/themes/aurora.jpg", motion: "زنبرك 320 · توهج 3.2s" },
];

type Ctx = { theme: ThemeId; setTheme: (t: ThemeId) => void };
const ThemeCtx = createContext<Ctx>({ theme: "aurora", setTheme: () => {} });

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<ThemeId>("aurora");

  useEffect(() => {
    const saved = (typeof window !== "undefined" && window.localStorage.getItem("jodon-theme")) as ThemeId | null;
    if (saved && THEMES.some((t) => t.id === saved)) setTheme(saved);
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    window.localStorage.setItem("jodon-theme", theme);
  }, [theme]);

  return <ThemeCtx.Provider value={{ theme, setTheme }}>{children}</ThemeCtx.Provider>;
}

export const useTheme = () => useContext(ThemeCtx);

/** Full-bleed theme gallery — each card shows the real theme artwork bundled in the APK. */
export function ThemeGallery({ compact = false }: { compact?: boolean }) {
  const { theme, setTheme } = useTheme();
  return (
    <div className={compact ? "grid grid-cols-3 gap-2" : "grid gap-4 sm:grid-cols-2 lg:grid-cols-3"}>
      {THEMES.map((t, i) => {
        const active = theme === t.id;
        return (
          <motion.button
            key={t.id}
            onClick={() => setTheme(t.id)}
            whileTap={{ scale: 0.97 }}
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ type: "spring", damping: 20, stiffness: 240, delay: i * 0.05 }}
            className={`specular group relative overflow-hidden rounded-3xl text-right transition-all ${
              active ? "ring-2 ring-white/70" : "ring-1 ring-white/10"
            }`}
            style={{ boxShadow: active ? `0 0 50px -12px var(--glow)` : undefined }}
          >
            <img
              src={t.img}
              alt={t.name}
              className={`w-full object-cover transition-transform duration-500 group-hover:scale-105 ${
                compact ? "h-16" : "h-36"
              }`}
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
            <div className={`absolute inset-x-0 bottom-0 ${compact ? "p-2" : "p-4"}`}>
              <p className={`font-bold text-white ${compact ? "text-[10px]" : "text-sm"}`}>{t.name}</p>
              {!compact && <p className="mt-0.5 text-[11px] text-white/70">{t.tagline}</p>}
              {!compact && <p className="mt-1 text-[10px] text-white/50" dir="ltr">{t.motion}</p>}
            </div>
            {active && (
              <span className="aurora-gradient absolute top-2 left-2 rounded-full px-2 py-0.5 text-[9px] font-bold text-white">
                مفعّل
              </span>
            )}
          </motion.button>
        );
      })}
    </div>
  );
}
