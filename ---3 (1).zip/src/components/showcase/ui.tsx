"use client";

import { motion } from "framer-motion";
import type { CSSProperties, ReactNode } from "react";

export const spring = { type: "spring", damping: 18, stiffness: 210 } as const;
export const springSoft = { type: "spring", damping: 22, stiffness: 140 } as const;

export function glassPanel(extra?: CSSProperties): CSSProperties {
  return {
    background: "linear-gradient(180deg, rgba(255,255,255,.085), rgba(255,255,255,.04))",
    backdropFilter: "blur(22px) saturate(140%)",
    WebkitBackdropFilter: "blur(22px) saturate(140%)",
    boxShadow:
      "inset 0 1px 0 rgba(255,255,255,.13), inset 0 0 0 1px rgba(255,255,255,.05), 0 14px 40px -14px rgba(0,0,0,.6)",
    ...extra,
  };
}

export function Glass({
  children,
  radius = 20,
  className = "",
  style,
}: {
  children: ReactNode;
  radius?: number;
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <div
      className={`specular relative ${className}`}
      style={{ borderRadius: radius, ...glassPanel(), ...style }}
    >
      {children}
    </div>
  );
}

export function Chip({
  children,
  active = false,
  onClick,
}: {
  children: ReactNode;
  active?: boolean;
  onClick?: () => void;
}) {
  return (
    <motion.button
      whileTap={{ scale: 0.93 }}
      transition={spring}
      onClick={onClick}
      className={`shrink-0 rounded-full px-3.5 py-1.5 text-[11px] font-medium transition-colors ${
        active
          ? "aurora-gradient text-white shadow-[0_0_18px_-4px_rgba(155,114,203,.8)]"
          : "glass text-[#a7aec2]"
      }`}
    >
      {children}
    </motion.button>
  );
}

export function Toggle({ on }: { on: boolean }) {
  return (
    <div
      className={`relative h-[26px] w-[46px] rounded-full transition-colors duration-300 ${
        on ? "aurora-gradient" : "bg-white/10"
      }`}
    >
      <motion.span
        animate={{ x: on ? -22 : 0 }}
        transition={spring}
        className="absolute top-[3px] right-[3px] block h-5 w-5 rounded-full bg-white shadow"
      />
    </div>
  );
}

export function ProgressBar({ value }: { value: number }) {
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/10">
      <motion.div
        initial={false}
        animate={{ width: `${Math.min(100, value * 100)}%` }}
        transition={springSoft}
        className="progress-gradient h-full rounded-full shadow-[0_0_12px_rgba(224,102,140,.6)]"
      />
    </div>
  );
}

export function ProgressRing({
  value,
  size = 46,
  stroke = 4,
}: {
  value: number;
  size?: number;
  stroke?: number;
}) {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="rgba(255,255,255,.08)"
          strokeWidth={stroke}
        />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="url(#ringGrad)"
          strokeWidth={stroke}
          strokeLinecap="round"
          initial={false}
          animate={{ strokeDashoffset: circ - circ * Math.min(1, value) }}
          transition={springSoft}
          strokeDasharray={circ}
          style={{ filter: "drop-shadow(0 0 5px rgba(155,114,203,.7))" }}
        />
        <defs>
          <linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#4e8cff" />
            <stop offset="50%" stopColor="#9b72cb" />
            <stop offset="100%" stopColor="#e0668c" />
          </linearGradient>
        </defs>
      </svg>
      <span className="absolute inset-0 grid place-items-center text-[9px] font-bold text-[#f2f4fa]">
        {Math.round(value * 100)}%
      </span>
    </div>
  );
}

export function Sparkline({
  points,
  className = "",
}: {
  points: number[];
  className?: string;
}) {
  const w = 100;
  const h = 24;
  const max = Math.max(...points, 1);
  const d = points
    .map(
      (p, i) =>
        `${i === 0 ? "M" : "L"}${((i / (points.length - 1)) * w).toFixed(1)},${(
          h - (p / max) * (h - 3)).toFixed(1)}`
    )
    .join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className={className} preserveAspectRatio="none">
      <defs>
        <linearGradient id="spk" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#4e8cff" />
          <stop offset="60%" stopColor="#9b72cb" />
          <stop offset="100%" stopColor="#e0668c" />
        </linearGradient>
      </defs>
      <path d={d} fill="none" stroke="url(#spk)" strokeWidth={1.6} strokeLinecap="round" />
    </svg>
  );
}

export function WordReveal({ text, delay = 0 }: { text: string; delay?: number }) {
  return (
    <span className="inline">
      {text.split(" ").map((w, i) => (
        <motion.span
          key={i}
          initial={{ opacity: 0, y: 14, filter: "blur(8px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          transition={{ ...springSoft, delay: delay + i * 0.06 }}
          className="inline-block"
        >
          {w}&nbsp;
        </motion.span>
      ))}
    </span>
  );
}
