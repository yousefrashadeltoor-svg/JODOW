"use client";

import { motion } from "framer-motion";
import { Fingerprint, RefreshCcw, ShieldCheck } from "lucide-react";
import { Dock, Phone } from "../Phone";
import { Glass, Toggle, spring } from "../ui";
import { THEMES, useTheme } from "../theme";

const themes = [
  { name: "Aurora", g: "linear-gradient(120deg,#4e8cff,#9b72cb,#e0668c)" },
  { name: "Ocean", g: "linear-gradient(120deg,#38bdf8,#2dd4bf,#818cf8)" },
  { name: "Sunset", g: "linear-gradient(120deg,#f59e0b,#ef4444,#ec4899)" },
  { name: "Emerald", g: "linear-gradient(120deg,#34d399,#10b981,#84cc16)" },
  { name: "Mono", g: "linear-gradient(120deg,#e5e7eb,#9ca3af,#6b7280)" },
  { name: "Neon", g: "linear-gradient(120deg,#00e5ff,#b388ff,#ff4ecd)" },
];

/** Settings replica: themes row, toggles, engines, legal note. */
export default function SettingsScreen() {
  const { theme, setTheme } = useTheme();
  return (
    <Phone>
      <div className="flex h-full flex-col gap-2.5 overflow-hidden px-4 pt-3 pb-24">
        <h2 className="aurora-gradient-text text-[20px] font-bold">الإعدادات</h2>

        <p className="text-[9px] font-semibold text-[#6b7386]">المظهر</p>
        <Glass radius={20} className="p-3">
          <p className="text-[10.5px] font-bold">الثيم · {THEMES.length} ثيمات كاملة</p>
          <div className="mt-2 flex gap-1.5 overflow-x-auto pb-1 [scrollbar-width:none]">
            {THEMES.map((t, i) => (
              <motion.button
                key={t.id}
                onClick={() => setTheme(t.id)}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ ...spring, delay: 0.05 + i * 0.04 }}
                title={t.name}
                className={`relative h-11 w-9 shrink-0 overflow-hidden rounded-lg ring-2 ${theme === t.id ? "ring-white" : "ring-white/15"}`}
              >
                <img src={t.img} alt={t.name} className="h-full w-full object-cover" />
                {theme === t.id && <span className="aurora-gradient absolute inset-x-0 bottom-0 py-[1px] text-[5.5px] font-bold text-white">مفعّل</span>}
              </motion.button>
            ))}
          </div>
        </Glass>

        <p className="mt-1 text-[9px] font-semibold text-[#6b7386]">التحميل</p>
        <Glass radius={20} className="flex flex-col gap-2.5 p-3">
          <Row title="الاتصالات لكل تحميل" value="16 · حتى 32" />
          <RowToggle title="شبكة Wi-Fi فقط" on={false} />
          <RowToggle title="إيقاف عند ضعف البطارية" on />
          <RowToggle title="فحص SHA-256 بعد الاكتمال" on />
        </Glass>

        <p className="mt-1 text-[9px] font-semibold text-[#6b7386]">الخصوصية والحماية</p>
        <Glass radius={20} className="flex flex-col gap-2.5 p-3">
          <RowToggle title="حجب الإعلانات (EasyList)" on />
          <RowToggle title="DNS عبر HTTPS" on={false} />
          <Row icon={Fingerprint} title="القبو الخاص بالبصمة" value="١٢ ملفًا مشفرًا" />
        </Glass>

        <Glass radius={20} className="mt-1 p-3">
          <Row icon={RefreshCcw} title="yt-dlp · قوائم الحجب" value="محدَّث الآن ✔" accent />
          <p className="mt-1.5 flex items-start gap-1.5 text-[8px] leading-relaxed text-[#fbbf24]">
            <ShieldCheck size={10} className="mt-0.5 shrink-0" />
            المسؤولية على المستخدم في احترام حقوق النشر. لا تجاوز لـ DRM أو Paywall.
          </p>
        </Glass>
      </div>
      <Dock active="settings" />
    </Phone>
  );
}

function Row({
  title,
  value,
  icon: Icon,
  accent = false,
}: {
  title: string;
  value: string;
  icon?: any;
  accent?: boolean;
}) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        {Icon && <Icon size={12} className="text-[#9b72cb]" />}
        <span className="text-[10px] font-medium">{title}</span>
      </div>
      <span className={`text-[9px] ${accent ? "text-[#4ade80]" : "text-[#6b7386]"}`}>{value}</span>
    </div>
  );
}

function RowToggle({ title, on }: { title: string; on: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-[10px] font-medium">{title}</span>
      <Toggle on={on} />
    </div>
  );
}
