"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  CheckCheck,
  ClipboardPaste,
  FileText,
  Link2,
  Music4,
  Image as ImageIcon,
  Video,
  X,
} from "lucide-react";
import { useState } from "react";
import { Dock, Phone, TYPE_META } from "../Phone";
import { Glass, ProgressBar, spring, springSoft, WordReveal } from "../ui";

/**
 * Home screen replica — auto-plays the staged pipeline in a loop:
 * paste → shimmer skeleton → info card materializes → 4 smart buttons pop-in.
 */
export default function HomeScreen() {
  const [stage, setStage] = useState(0); // 0 idle → 3 fully analysed

  // Real interaction: paste analyses the link step by step (never auto-looped).
  const analyze = () => {
    setStage(1);
    setTimeout(() => setStage(2), 650);
    setTimeout(() => setStage(3), 1250);
  };
  const reset = () => setStage(0);

  return (
    <Phone>
      <div className="flex h-full flex-col gap-3 px-4 pt-3 pb-24">
        {/* greeting */}
        <div>
          <motion.h2
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={spring}
            className="aurora-gradient-text text-[22px] font-bold leading-tight"
          >
            أورورا غِت
          </motion.h2>
          <p className="mt-0.5 text-[10.5px] leading-relaxed text-[#a7aec2]">
            <WordReveal text="حمّل فيديو وصوتًا وصورًا وملفات من آلاف المواقع." delay={0.3} />
          </p>
        </div>

        {/* hero paste field with rotating Gemini glow */}
        <div className="relative">
          <div className={`glow-ring ${stage === 0 ? "idle" : ""}`} />
          <div className="specular relative z-10 flex items-center gap-2 rounded-[28px] px-3.5 py-3">
            <Link2 size={16} className="shrink-0 text-[#9b72cb]" />
            <div className="min-w-0 flex-1">
              {stage === 0 ? (
                <span className="text-[12px] text-[#6b7386]">الصق رابطك هنا…</span>
              ) : (
                <motion.span
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="block truncate text-[10.5px] text-[#f2f4fa] font-[family-name:var(--font-outfit-src)]"
                  dir="ltr"
                >
                  tiktok.com/@creator/video/721…
                </motion.span>
              )}
            </div>
            <motion.button
              onClick={stage === 0 ? analyze : reset}
              whileTap={{ scale: 0.9 }}
              transition={spring}
              className="glass flex items-center gap-1.5 rounded-2xl px-3 py-2 text-[10px] font-semibold text-[#f2f4fa]"
            >
              <ClipboardPaste size={13} className="text-[#9b72cb]" />
              لصق
            </motion.button>
          </div>
        </div>

        {/* detected site chip */}
        <AnimatePresence>
          {stage >= 1 && (
            <motion.div
              initial={{ opacity: 0, y: 8, scale: 0.92, filter: "blur(6px)" }}
              animate={{ opacity: 1, y: 0, scale: 1, filter: "blur(0px)" }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={spring}
              className="glass specular flex w-fit items-center gap-2 rounded-full px-3 py-1.5"
            >
              <span className="grid h-4 w-4 place-items-center rounded-full bg-[#ff0050]">
                <Music4 size={9} className="text-white" />
              </span>
              <span className="text-[9.5px] text-[#a7aec2]">رابط مكتشف · tiktok.com</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* info card / skeleton */}
        <AnimatePresence mode="wait">
          {stage === 1 && <SkeletonCard key="skeleton" />}
          {stage >= 2 && <InfoCard key="card" showButtons={stage >= 3} />}
        </AnimatePresence>

        {/* recent downloads */}
        <div className="mt-auto flex flex-col gap-2">
          <p className="text-[10px] font-semibold text-[#6b7386]">آخر التحميلات</p>
          <Glass radius={16} className="flex items-center gap-2.5 p-2.5">
            <div className="relative h-9 w-9 shrink-0 overflow-hidden rounded-xl">
              <img src="/showcase/cover-music.jpg" alt="" className="h-full w-full object-cover" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[10.5px] font-semibold">Neon Skyline — Embers.opus</p>
              <div className="mt-1 flex items-center gap-1.5">
                <ProgressBar value={0.72} />
              </div>
            </div>
            <span className="text-[9px] text-[#3ec6d3] font-[family-name:var(--font-outfit-src)]" dir="ltr">
              18.4 MB/s
            </span>
          </Glass>
          <Glass radius={16} className="flex items-center gap-2.5 p-2.5">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[#7c6cff]/15">
              <CheckCheck size={15} className="text-[#4ade80]" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[10.5px] font-semibold">Ocean Drone 4K.mp4</p>
              <p className="text-[9px] text-[#6b7386]">اكتمل · 148.4 MB</p>
            </div>
          </Glass>
        </div>
      </div>
      <Dock active="home" />
    </Phone>
  );
}

function SkeletonCard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10, filter: "blur(8px)" }}
      transition={springSoft}
    >
      <Glass radius={24} className="flex flex-col gap-2.5 p-4">
        <div className="shimmer h-24 w-full rounded-2xl" />
        <div className="shimmer h-3.5 w-3/4 rounded-full" />
        <div className="shimmer h-2.5 w-1/2 rounded-full" />
        <div className="mt-1 flex justify-between">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="shimmer h-12 w-12 rounded-2xl" />
          ))}
        </div>
      </Glass>
    </motion.div>
  );
}

function InfoCard({ showButtons }: { showButtons: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16, scale: 0.96, filter: "blur(10px)" }}
      animate={{ opacity: 1, y: 0, scale: 1, filter: "blur(0px)" }}
      transition={{ ...spring, mass: 0.9 }}
    >
      <Glass radius={24} className="p-3.5" style={{ boxShadow: "inset 0 1px 0 rgba(255,255,255,.14), 0 0 48px -14px rgba(124,108,255,.5)" }}>
        {/* site row */}
        <div className="flex items-center gap-2">
          <span className="grid h-7 w-7 place-items-center rounded-lg bg-[#ff0050]">
            <Music4 size={13} className="text-white" />
          </span>
          <div className="min-w-0">
            <p className="text-[11px] font-bold leading-none">TikTok</p>
            <p className="text-[8.5px] text-[#6b7386] font-[family-name:var(--font-outfit-src)]" dir="ltr">
              tiktok.com
            </p>
          </div>
          <span className="glass mr-auto rounded-full px-2 py-0.5 text-[8.5px] font-semibold text-[#7c6cff]">
            فيديو
          </span>
        </div>

        {/* thumbnail */}
        <div className="relative mt-2.5 h-[104px] overflow-hidden rounded-2xl">
          <img src="/showcase/thumb-video.jpg" alt="" className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <span className="absolute right-2 bottom-2 rounded-md bg-black/70 px-1.5 py-0.5 text-[8.5px] font-bold backdrop-blur font-[family-name:var(--font-outfit-src)]">
            0:47
          </span>
          <motion.span
            whileTap={{ scale: 0.85 }}
            className="glass absolute top-1/2 left-1/2 grid h-9 w-9 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full"
          >
            <Video size={15} className="text-white" />
          </motion.span>
        </div>

        <p className="mt-2 line-clamp-1 text-[11.5px] font-semibold leading-snug">
          أمواج المحيط من الأعلى — 4K بدون علامة مائية
        </p>
        <div className="mt-1 flex items-center gap-3 text-[9px] text-[#6b7386]">
          <span>@ocean_cinema</span>
          <span>≈ 38.2 MB</span>
          <span className="aurora-gradient-text font-bold">1080p60</span>
        </div>

        {/* the four smart buttons */}
        <div className="mt-3 flex items-start justify-between px-1">
          {(
            [
              { k: "audio", n: 3, available: true },
              { k: "image", n: 5, available: true },
              { k: "video", n: 7, available: true },
              { k: "file", n: 4, available: true },
            ] as const
          ).map((b, i) => {
            const meta = TYPE_META[b.k];
            const Icon = meta.icon;
            return (
              <motion.div
                key={b.k}
                initial={{ opacity: 0, scale: 0.4, y: 18, filter: "blur(8px)" }}
                animate={showButtons ? { opacity: 1, scale: 1, y: 0, filter: "blur(0px)" } : { opacity: 0 }}
                transition={{ ...spring, delay: i * 0.09 }}
                className="flex flex-col items-center gap-1"
              >
                <motion.button
                  whileTap={{ scale: 0.82 }}
                  transition={spring}
                  className="relative grid h-[52px] w-[52px] place-items-center rounded-[20px]"
                  style={{ background: `${meta.color}24`, boxShadow: `0 0 22px -6px ${meta.color}66, inset 0 1px 0 rgba(255,255,255,.15)` }}
                >
                  <Icon size={20} style={{ color: meta.color }} />
                  <span
                    className="absolute -top-1 -left-1 grid h-[17px] w-[17px] place-items-center rounded-full text-[8.5px] font-bold text-white"
                    style={{ background: meta.color, border: "2px solid #12141c" }}
                  >
                    {b.n}
                  </span>
                </motion.button>
                <span className="text-[9.5px] font-medium text-[#a7aec2]">{meta.label}</span>
              </motion.div>
            );
          })}
        </div>
      </Glass>
    </motion.div>
  );
}
