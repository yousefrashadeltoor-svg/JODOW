"use client";

import { motion } from "framer-motion";
import { ArrowLeftRight, FileVideo, Scissors, Wand2 } from "lucide-react";
import { useState } from "react";
import { Phone } from "../Phone";
import { Glass, ProgressBar, spring } from "../ui";

const videoFormats = ["MP4", "MKV", "WEBM", "MOV", "GIF"];
const audioFormats = ["MP3", "M4A", "OPUS", "OGG", "FLAC", "WAV"];

/** Batch converter replica: target chips, per-job options, queue progress. */
export default function ConverterScreen() {
  const [target, setTarget] = useState("OPUS");

  return (
    <Phone>
      <div className="flex h-full flex-col gap-3 px-4 pt-3 pb-8">
        <div>
          <h2 className="aurora-gradient-text text-[20px] font-bold">المحوّل</h2>
          <p className="mt-0.5 text-[9.5px] text-[#a7aec2]">حوّل عدة ملفات في دفعة واحدة</p>
        </div>

        {/* picked file card */}
        <Glass radius={20} className="flex items-center gap-2.5 p-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#7c6cff]/15">
            <FileVideo size={17} className="text-[#7c6cff]" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[10.5px] font-bold" dir="ltr">Ocean Drone 4K.mp4</p>
            <p className="text-[8.5px] text-[#6b7386]">148.4 MB · 0:47 · AVC → نسخ الصوت بدون إعادة ترميز</p>
          </div>
        </Glass>

        {/* format chips */}
        <div>
          <p className="mb-1.5 text-[9px] font-semibold text-[#6b7386]">فيديو</p>
          <div className="flex flex-wrap gap-1.5">
            {videoFormats.map((f) => (
              <FmtChip key={f} label={f} active={target === f} onClick={() => setTarget(f)} />
            ))}
          </div>
          <p className="mt-2.5 mb-1.5 text-[9px] font-semibold text-[#6b7386]">صوت</p>
          <div className="flex flex-wrap gap-1.5">
            {audioFormats.map((f) => (
              <FmtChip key={f} label={f} active={target === f} onClick={() => setTarget(f)} />
            ))}
          </div>
        </div>

        {/* options */}
        <div className="flex gap-1.5">
          <Opt icon={Scissors} label="قص 00:10→00:35" />
          <Opt icon={Wand2} label="جودة شفافة" />
          <Opt icon={ArrowLeftRight} label="Bitrate 160k" />
        </div>

        {/* queue */}
        <div className="flex flex-col gap-2">
          <p className="text-[9px] font-semibold text-[#6b7386]">طابور التحويل</p>
          <Glass radius={18} className="p-3">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold" dir="ltr">…/Ocean Drone 4K.opus</p>
              <span className="text-[8.5px] text-[#9b72cb]" dir="ltr">64%</span>
            </div>
            <div className="mt-2">
              <ProgressBar value={0.64} />
            </div>
          </Glass>
          <Glass radius={18} className="flex items-center justify-between p-3 opacity-70">
            <p className="text-[10px]" dir="ltr">Sunrise Timelapse.mov</p>
            <span className="text-[8.5px] text-[#6b7386]">في الانتظار</span>
          </Glass>
        </div>

        <motion.button
          whileTap={{ scale: 0.95 }}
          transition={spring}
          className="aurora-gradient mt-auto w-full rounded-full py-3 text-[12px] font-bold text-white shadow-[0_12px_32px_-8px_rgba(155,114,203,.7)]"
        >
          ابدأ التحويل (٢)
        </motion.button>
      </div>
    </Phone>
  );
}

function FmtChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <motion.button
      onClick={onClick}
      whileTap={{ scale: 0.9 }}
      transition={spring}
      className={`rounded-full px-3 py-1.5 text-[9.5px] font-bold tracking-wide font-[family-name:var(--font-outfit-src)] ${
        active ? "aurora-gradient text-white shadow-[0_0_16px_-4px_rgba(155,114,203,.8)]" : "glass text-[#a7aec2]"
      }`}
    >
      {label}
    </motion.button>
  );
}

function Opt({ icon: Icon, label }: { icon: any; label: string }) {
  return (
    <span className="glass flex items-center gap-1 rounded-full px-2.5 py-1.5">
      <Icon size={10} className="text-[#9b72cb]" />
      <span className="text-[8.5px] text-[#a7aec2]">{label}</span>
    </span>
  );
}
