"use client";

import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  Check,
  Copy,
  Download,
  Home,
  Link2,
  Music4,
  Search,
  Settings,
  Sparkles,
  ThumbsUp,
  User,
  Video,
  X,
} from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { Dock, Phone } from "../Phone";
import { Glass, spring, springSoft } from "../ui";

type Vid = {
  id: string;
  title: string;
  channel: string;
  views: string;
  dur: string;
  img: string;
  vertical?: boolean;
  tags: string[];
};

const CATALOG: Vid[] = [
  { id: "dQw4w9WgXcQ", title: "أمواج المحيط من الأعلى — تصوير سينمائي 4K", channel: "Ocean Cinema", views: "2.4M", dur: "12:04", img: "/showcase/thumb-video.jpg", tags: ["سفر", "تصوير"] },
  { id: "kJQP7kiw5Fk", title: "Neon Skyline — جلسة موسيقية كاملة", channel: "Nova Studio", views: "890K", dur: "48:12", img: "/showcase/cover-music.jpg", tags: ["موسيقى"] },
  { id: "9bZkp7q19f0", title: "شروحات برمجة أندرويد — Compose من الصفر", channel: "Dev JO", views: "410K", dur: "22:37", img: "/showcase/thumb-video.jpg", tags: ["تقنية", "برمجة"] },
  { id: "3JZ_D3ELwOQ", title: "أفضل إعدادات التصوير بالهاتف — دليل عملي", channel: "Gear Lab", views: "1.1M", dur: "09:52", img: "/showcase/cover-music.jpg", tags: ["تقنية"] },
  { id: "L_jWHffIx5E", title: "رحلة صحراوية — ليالي النجوم", channel: "Desert Drive", views: "623K", dur: "17:20", img: "/showcase/thumb-video.jpg", tags: ["سفر"] },
  { id: "fJ9rUzIMcZQ", title: "موسيقى هادئة للتركيز — ساعة كاملة", channel: "Calm Waves", views: "3.7M", dur: "1:00:00", img: "/showcase/cover-music.jpg", tags: ["موسيقى"] },
];

const CHANNELS = [
  { name: "Ocean Cinema", handle: "@ocean_cinema", subs: "1.2M", img: "/showcase/thumb-video.jpg" },
  { name: "Nova Studio", handle: "@nova", subs: "480K", img: "/showcase/cover-music.jpg" },
  { name: "Dev JO", handle: "@devjo", subs: "92K", img: "/showcase/thumb-video.jpg" },
];

type Tab = "home" | "shorts" | "subs";

export default function YouTubeScreen() {
  const [tab, setTab] = useState<Tab>("home");
  const [query, setQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [watched, setWatched] = useState<Record<string, boolean>>({});
  const [saved, setSaved] = useState<Record<string, boolean>>({});
  const [downloads, setDownloads] = useState(0);
  const [copied, setCopied] = useState<string | null>(null);
  const [follows, setFollows] = useState<string[]>(["Nova Studio"]);
  const [name, setName] = useState("ملفي المحلي");
  const [toast, setToast] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const feed = useMemo(() => {
    const q = query.trim();
    let list = CATALOG;
    if (tab === "subs") list = list.filter((v) => follows.includes(v.channel));
    if (q) list = list.filter((v) => v.title.includes(q) || v.tags.some((t) => t.includes(q)) || v.channel.includes(q));
    return list;
  }, [query, tab, follows]);

  const shorts = CATALOG.slice(0, 4);

  const flash = (m: string) => {
    setToast(m);
    setTimeout(() => setToast(null), 1800);
  };

  const copyLink = async (v: Vid) => {
    const url = `https://youtu.be/${v.id}`;
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      /* clipboard can be blocked — the URL is still shown in the toast */
    }
    setCopied(v.id);
    flash(`نُسخ الرابط: ${url}`);
    setTimeout(() => setCopied(null), 1500);
  };

  const exportProfile = () => {
    const data = JSON.stringify({ app: "JO DON", name, follows, saved: Object.keys(saved), watched: Object.keys(watched), exportedAt: new Date().toISOString() }, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "jodon-profile.json";
    a.click();
    URL.revokeObjectURL(a.href);
    flash("تم تصدير الملف المحلي");
  };

  const importProfile = async (file: File) => {
    try {
      const parsed = JSON.parse(await file.text()) as { name?: string; follows?: string[] };
      if (parsed.name) setName(parsed.name);
      if (Array.isArray(parsed.follows)) setFollows(parsed.follows);
      flash("تم استيراد الملف الشخصي");
    } catch {
      flash("ملف غير صالح");
    }
  };

  return (
    <Phone>
      <div className="relative flex h-full flex-col">
        {/* top bar */}
        <div className="flex items-center gap-2 px-3.5 pt-2 pb-1.5">
          <span className="aurora-gradient grid h-7 w-7 place-items-center rounded-lg">
            <Video size={13} className="text-white" />
          </span>
          <span className="text-[13px] font-extrabold tracking-tight text-[var(--fg)]" dir="ltr">JO DON</span>
          <div className="mr-auto flex items-center gap-1.5">
            <button onClick={() => setSearchOpen((s) => !s)} className="glass grid h-7 w-7 place-items-center rounded-full">
              <Search size={12} className="text-[#a7aec2]" />
            </button>
            <button onClick={() => setProfileOpen(true)} className="aurora-gradient grid h-7 w-7 place-items-center rounded-full text-[10px] font-bold text-white">
              {name.slice(0, 1)}
            </button>
          </div>
        </div>

        {/* search */}
        <AnimatePresence>
          {searchOpen && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden px-3.5">
              <div className="glass mt-1 flex items-center gap-2 rounded-full px-3 py-1.5">
                <Search size={12} className="text-[var(--glow)]" />
                <input
                  autoFocus
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="ابحث في JO DON"
                  className="min-w-0 flex-1 bg-transparent text-[11px] outline-none placeholder:text-[#6b7386]"
                />
                {query && (
                  <button onClick={() => setQuery("")}>
                    <X size={11} className="text-[#6b7386]" />
                  </button>
                )}
              </div>
              <div className="mt-1 flex gap-1 overflow-x-auto pb-1 [scrollbar-width:none]">
                {["موسيقى", "تقنية", "سفر", "برمجة"].map((s) => (
                  <button key={s} onClick={() => setQuery(s)} className="glass shrink-0 rounded-full px-2 py-0.5 text-[8.5px] text-[#a7aec2]">
                    {s} · مقترح
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* tabs */}
        <div className="flex gap-1.5 px-3.5 pt-1 pb-2">
          {(
            [
              ["home", "الرئيسية"],
              ["shorts", "شورتس"],
              ["subs", "اشتراكات"],
            ] as [Tab, string][]
          ).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`relative rounded-full px-3 py-1 text-[10px] font-bold ${
                tab === id ? "text-white" : "glass text-[#a7aec2]"
              }`}
            >
              {tab === id && (
                <motion.span layoutId="yt-tab" transition={{ type: "spring", damping: 20, stiffness: 320 }} className="aurora-gradient absolute inset-0 -z-10 rounded-full" />
              )}
              {label}
            </button>
          ))}
          <span className="glass mr-auto rounded-full px-2 py-1 text-[8px] text-[#6b7386]">محلي 100%</span>
        </div>

        {/* body */}
        <div className="flex-1 overflow-y-auto px-3.5 pb-24">
          {tab === "shorts" ? (
            <div className="grid grid-cols-2 gap-2">
              {shorts.map((v, i) => (
                <motion.button
                  key={v.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ ...spring, delay: i * 0.06 }}
                  className="relative aspect-[9/14] overflow-hidden rounded-2xl"
                >
                  <img src={v.img} alt="" className="h-full w-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 to-transparent" />
                  <p className="absolute inset-x-1.5 bottom-8 line-clamp-2 text-right text-[9px] font-bold text-white">{v.title}</p>
                  <span className="absolute right-1.5 bottom-1.5 rounded bg-white/20 px-1.5 py-0.5 text-[7.5px] text-white">شورتس</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setDownloads((d) => d + 1);
                      flash("بدأ تنزيل الشورت");
                    }}
                    className="absolute top-1.5 left-1.5 grid h-6 w-6 place-items-center rounded-full bg-black/55 backdrop-blur"
                  >
                    <Download size={10} className="text-white" />
                  </button>
                </motion.button>
              ))}
            </div>
          ) : feed.length === 0 ? (
            <Glass radius={20} className="p-4 text-center">
              <p className="text-[11px] font-bold">لا نتائج مطابقة</p>
              <p className="mt-1 text-[9px] text-[#6b7386]">جرّب كلمة أخرى أو أضف متابعات.</p>
            </Glass>
          ) : (
            <div className="flex flex-col gap-2.5">
              {feed.map((v, i) => (
                <motion.div key={v.id} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ ...spring, delay: i * 0.05 }}>
                  <Glass radius={20} className="overflow-hidden">
                    <div className="relative aspect-video cursor-pointer" onClick={() => setWatched((w) => ({ ...w, [v.id]: !w[v.id] }))}>
                      <img src={v.img} alt="" className="h-full w-full object-cover" />
                      <div className="absolute inset-0 bg-black/20" />
                      {watched[v.id] && (
                        <div className="absolute inset-0 grid place-items-center bg-black/50 backdrop-blur-[2px]">
                          <p className="text-[9.5px] text-white">المشغل المحلي يعمل داخل التطبيق</p>
                        </div>
                      )}
                      <span className="absolute bottom-1.5 left-1.5 rounded bg-black/70 px-1 py-0.5 text-[8px] font-bold text-white" dir="ltr">{v.dur}</span>
                    </div>
                    <div className="p-2">
                      <p className="line-clamp-2 text-[10.5px] font-bold leading-snug">{v.title}</p>
                      <p className="mt-0.5 text-[8.5px] text-[#6b7386]">{v.channel} · {v.views} مشاهدة</p>
                      <div className="mt-1.5 flex items-center gap-1">
                        <button
                          onClick={() => {
                            setDownloads((d) => d + 1);
                            flash(`بدأ التحميل: ${v.title.slice(0, 22)}…`);
                          }}
                          className="glass flex items-center gap-1 rounded-full px-2.5 py-1 text-[8.5px] font-bold text-[var(--glow)]"
                        >
                          <Download size={10} /> تحميل
                        </button>
                        <button onClick={() => copyLink(v)} className="glass grid h-6 w-6 place-items-center rounded-full">
                          {copied === v.id ? <Check size={10} className="text-[#4ade80]" /> : <Copy size={10} className="text-[#a7aec2]" />}
                        </button>
                        <button
                          onClick={() => setSaved((s) => ({ ...s, [v.id]: !s[v.id] }))}
                          className="glass grid h-6 w-6 place-items-center rounded-full"
                        >
                          <ThumbsUp size={10} className={saved[v.id] ? "text-[#4ade80]" : "text-[#a7aec2]"} />
                        </button>
                        <button
                          onClick={() => {
                            setFollows((f) => (f.includes(v.channel) ? f.filter((x) => x !== v.channel) : [...f, v.channel]));
                            flash(follows.includes(v.channel) ? `ألغيت متابعة ${v.channel}` : `تتابع ${v.channel}`);
                          }}
                          className="glass mr-auto rounded-full px-2 py-1 text-[8px] font-bold text-[#a7aec2]"
                        >
                          {follows.includes(v.channel) ? "متابَع" : "متابعة"}
                        </button>
                      </div>
                    </div>
                  </Glass>
                </motion.div>
              ))}
              <p className="py-2 text-center text-[8.5px] text-[#6b7386]">اقتراحات لا متناهية حسب مشاهداتك واشتراكاتك</p>
            </div>
          )}
        </div>

        {/* profile sheet */}
        <AnimatePresence>
          {profileOpen && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setProfileOpen(false)} className="absolute inset-0 z-30 bg-black/60 backdrop-blur-sm" />
              <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "110%" }} transition={springSoft} className="absolute inset-x-0 bottom-0 z-40">
                <Glass radius={26} className="glass-deep m-1.5 max-h-[78%] overflow-y-auto p-4">
                  <div className="mx-auto mb-3 h-1 w-9 rounded-full bg-white/25" />
                  <div className="flex items-center gap-2">
                    <span className="aurora-gradient grid h-9 w-9 place-items-center rounded-full text-[13px] font-bold text-white">{name.slice(0, 1)}</span>
                    <div className="min-w-0 flex-1">
                      <input
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-transparent text-[12px] font-bold outline-none"
                      />
                      <p className="text-[8.5px] text-[#6b7386]">هوية محلية · بلا حساب Google</p>
                    </div>
                  </div>
                  <div className="mt-2 grid grid-cols-3 gap-1.5 text-center">
                    {[
                      ["المتابعات", follows.length],
                      ["المحفوظ", Object.values(saved).filter(Boolean).length],
                      ["التحميلات", downloads],
                    ].map(([l, n]) => (
                      <div key={String(l)} className="glass rounded-xl py-1.5">
                        <p className="text-[12px] font-bold">{n}</p>
                        <p className="text-[8px] text-[#6b7386]">{l}</p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-2 flex gap-1.5">
                    <button onClick={exportProfile} className="aurora-gradient flex-1 rounded-full py-1.5 text-[9px] font-bold text-white">تصدير الملف</button>
                    <button onClick={() => fileRef.current?.click()} className="glass flex-1 rounded-full py-1.5 text-[9px] font-bold">استيراد ملف</button>
                    <input
                      ref={fileRef}
                      type="file"
                      accept="application/json"
                      className="hidden"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) void importProfile(f);
                      }}
                    />
                  </div>

                  <p className="mt-3 mb-1.5 text-[9px] font-bold text-[#6b7386]">متابعاتي</p>
                  <div className="flex flex-col gap-1.5">
                    {CHANNELS.map((ch) => {
                      const on = follows.includes(ch.name);
                      return (
                        <div key={ch.name} className="glass flex items-center gap-2 rounded-xl p-1.5">
                          <img src={ch.img} alt="" className="h-7 w-7 rounded-full object-cover" />
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-[9.5px] font-bold">{ch.name}</p>
                            <p className="text-[8px] text-[#6b7386]">{ch.handle} · {ch.subs}</p>
                          </div>
                          <button
                            onClick={() => {
                              setFollows((f) => (on ? f.filter((x) => x !== ch.name) : [...f, ch.name]));
                              flash(on ? `ألغيت ${ch.name}` : `تتابع ${ch.name}`);
                            }}
                            className={`rounded-full px-2 py-1 text-[8px] font-bold ${on ? "bg-white/10 text-[#f87171]" : "aurora-gradient text-white"}`}
                          >
                            {on ? "إلغاء" : "متابعة"}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                  <p className="mt-2 text-[8px] leading-relaxed text-[#6b7386]">
                    الملف والتصدير والاستيراد يعملون على جهازك فقط. التحميل والمشاهدة يحتاجان إنترنت.
                  </p>
                </Glass>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {toast && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="absolute bottom-20 left-1/2 z-50 -translate-x-1/2">
            <div className="glass max-w-[240px] truncate rounded-full px-3 py-1.5 text-[9px] text-white">{toast}</div>
          </motion.div>
        )}

        <Dock active="youtube" />
      </div>
    </Phone>
  );
}
