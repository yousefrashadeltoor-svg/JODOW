"use client";

import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import { Phone } from "../Phone";
import { spring, springSoft } from "../ui";

/** Onboarding replica: pulsing aurora orb + gradient headline + dots + CTA. */
export default function OnboardingScreen() {
  return (
    <Phone>
      <div className="flex h-full flex-col items-center px-6 pt-16 pb-8 text-center">
        {/* orb */}
        <div className="relative mt-6">
          <motion.div
            className="breathe aurora-gradient h-36 w-36 rounded-[48px]"
            style={{ borderRadius: "38% 62% 55% 45% / 45% 42% 58% 55%" }}
            animate={{
              borderRadius: [
                "38% 62% 55% 45% / 45% 42% 58% 55%",
                "55% 45% 40% 60% / 60% 55% 45% 40%",
                "38% 62% 55% 45% / 45% 42% 58% 55%",
              ],
            }}
            transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
          />
          <div className="breathe absolute inset-0 -z-10 rounded-full bg-[#9b72cb]/40 blur-[70px]" />
          {/* sparkles */}
          {[0, 1, 2, 3, 4].map((i) => (
            <span
              key={i}
              className="sparkle-particle absolute h-1.5 w-1.5 rounded-full"
              style={{
                background: ["#4e8cff", "#9b72cb", "#e0668c", "#fff", "#4e8cff"][i],
                right: `${15 + i * 16}%`,
                bottom: "-20px",
                animationDelay: `${i * 0.5}s`,
              }}
            />
          ))}
          <Sparkles size={26} className="absolute top-1/2 right-1/2 translate-x-1/2 -translate-y-1/2 text-white drop-shadow-[0_0_12px_rgba(255,255,255,.8)]" />
        </div>

        <motion.h1
          initial={{ opacity: 0, y: 20, filter: "blur(10px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          transition={{ ...springSoft, delay: 0.2 }}
          className="aurora-gradient-text mt-12 text-[30px] font-bold leading-tight"
        >
          أورورا غِت
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...springSoft, delay: 0.35 }}
          className="mt-2 max-w-[220px] text-[11px] leading-relaxed text-[#a7aec2]"
        >
          حمّل أي شيء. من أي مكان.
          <br />
          فيديو · صوت · صور · ملفات — من 1800+ موقع.
        </motion.p>

        <div className="mt-8 flex gap-1.5">
          <span className="aurora-gradient h-2 w-6 rounded-full" />
          <span className="h-2 w-2 rounded-full bg-white/20" />
          <span className="h-2 w-2 rounded-full bg-white/20" />
        </div>

        <motion.button
          whileTap={{ scale: 0.94 }}
          transition={spring}
          className="aurora-gradient mt-auto w-full rounded-full py-3.5 text-[13px] font-bold text-white shadow-[0_14px_36px_-8px_rgba(155,114,203,.8)]"
        >
          ابدأ الآن
        </motion.button>
        <p className="mt-3 max-w-[240px] text-[8px] leading-relaxed text-[#6b7386]">
          بالمتابعة أنت تقر بمسؤوليتك عن احترام حقوق النشر وشروط كل موقع.
        </p>
      </div>
    </Phone>
  );
}
