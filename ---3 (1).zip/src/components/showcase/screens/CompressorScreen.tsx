"use client";

import { motion } from "framer-motion";
import { BadgeCheck, ChevronsDown, Minimize2, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { Phone } from "../Phone";
import { Glass, spring, springSoft } from "../ui";

/** Smart compressor replica: dual mode cards + before/after slider + savings. */
export default function CompressorScreen() {
  const [mode, setMode] = useState<"lossless" | "transparent">("transparent");
  const [x, setX] = useState(0.55);

  return (
    <Phone>
      <div className="flex h-full flex-col gap-3 px-4 pt-3 pb-8">
        <div>
          <h2 className="aurora-gradient-text text-[20px] font-bold">التصغير الذكي</h2>
          <p className="mt-0.5 text-[9.5px] text-[#a7aec2]">Lossless أو شفاف الجودة — الأصل محفوظ دائمًا</p>
        </div>

        {/* mode cards */}
        <div className="flex gap-2">
          <ModeCard
            title="بدون أي فقد"
            sub="Lossless"
            active={mode === "lossless"}
            accent="#4ade80"
            icon={<ShieldCheck size={13} />}
            onClick={() => setMode("lossless")}
          />
          <ModeCard
            title="شفاف الجودة"
            sub="SSIM ≥ 0.95"
            active={mode === "transparent"}
            accent="#fbbf24"
            icon={<Minimize2 size={13} />}
            onClick={() => setMode("transparent")}
          />
        </div>

        {/* before/after slider */}
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={spring}>
          <Glass radius={22} className="p-3">
            <div
              className="relative h-[150px] cursor-ew-resize overflow-hidden rounded-2xl"
              onPointerMove={(e) => {
                if (e.buttons !== 1) return;
                const r = e.currentTarget.getBoundingClientRect();
                setX(Math.min(0.95, Math.max(0.05, (r.right - e.clientX) / r.width)));
              }}
            >
              <img src="/showcase/thumb-video.jpg" alt="بعد" className="absolute inset-0 h-full w-full object-cover" />
              <div className="absolute inset-0 overflow-hidden" style={{ width: `${x * 100}%` }}>
                <img
                  src="/showcase/thumb-video.jpg"
                  alt="قبل"
                  className="h-full w-full object-cover saturate-50 contrast-75"
                  style={{ filter: "brightness(.75) blur(.4px)", width: 260 }}
                />
              </div>
              <div
                className="aurora-gradient absolute top-0 bottom-0 w-[3px] shadow-[0_0_14px_rgba(224,102,140,.9)]"
                style={{ right: `${x * 100}%` }}
              />
              <span className="glass absolute top-2 right-2 rounded-full px-2 py-0.5 text-[8px] font-bold">قبل · 148.4 MB</span>
              <span className="glass absolute bottom-2 left-2 rounded-full px-2 py-0.5 text-[8px] font-bold">بعد · 46.9 MB</span>
            </div>

            <div className="mt-3 flex items-center justify-between">
              <div>
                <p className="text-[16px] font-bold text-[#4ade80]" dir="ltr">− 68.4%</p>
                <p className="text-[8.5px] text-[#6b7386]">وفّرت 101.5 MB</p>
              </div>
              <div className="text-left" dir="ltr">
                <p className="text-[9px] text-[#6b7386]">148,372,910 → 46,865,088 bytes</p>
                <p className="flex items-center justify-end gap-1 text-[8.5px] font-bold text-[#fbbf24]">
                  <BadgeCheck size={10} /> SSIM 0.972 · HEVC
                </p>
              </div>
            </div>
          </Glass>
        </motion.div>

        {/* honest note + suggestions */}
        <Glass radius={18} className="flex items-center gap-2.5 p-3">
          <span className="aurora-gradient grid h-8 w-8 shrink-0 place-items-center rounded-xl">
            <ChevronsDown size={14} className="text-white" />
          </span>
          <p className="text-[9.5px] leading-relaxed text-[#a7aec2]">
            اكتشفنا أن «Vacation Final.mp4» يمكن أن يوفّر <b className="text-[#4ade80]">212 MB</b> — وفّر الآن؟
          </p>
        </Glass>

        <div className="mt-auto">
          <motion.button
            whileTap={{ scale: 0.95 }}
            transition={spring}
            className="aurora-gradient w-full rounded-full py-3 text-[12px] font-bold text-white shadow-[0_12px_32px_-8px_rgba(155,114,203,.7)]"
          >
            اضغط الآن — الأصل يبقى افتراضيًا
          </motion.button>
          <p className="mt-2 text-center text-[8.5px] leading-relaxed text-[#6b7386]">
            إن لم يصغر الملف فعليًا سيخبرك التطبيق بصدق ولن يعرض ناتجًا أكبر.
          </p>
        </div>
      </div>
    </Phone>
  );
}

function ModeCard({
  title,
  sub,
  active,
  accent,
  icon,
  onClick,
}: {
  title: string;
  sub: string;
  active: boolean;
  accent: string;
  icon: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <motion.button
      onClick={onClick}
      whileTap={{ scale: 0.94 }}
      transition={spring}
      className={`specular flex-1 rounded-[20px] p-3 text-right transition-all ${
        active ? "glass" : "bg-white/[.04]"
      }`}
      style={active ? { boxShadow: `inset 0 0 0 1.5px ${accent}55, 0 0 24px -8px ${accent}66` } : undefined}
    >
      <div className="flex items-center gap-1.5">
        <span className="grid h-5 w-5 place-items-center rounded-full" style={{ background: `${accent}25`, color: accent }}>
          {icon}
        </span>
        <p className="text-[10.5px] font-bold">{title}</p>
      </div>
      <p className="mt-1 text-[8px] text-[#6b7386]" dir="ltr">
        {sub}
      </p>
    </motion.button>
  );
}
