"use client";

import { motion } from "framer-motion";
import { Copy, FolderOpen, Pause, Play, RefreshCcw, Share2, Trash2, X } from "lucide-react";
import { useState } from "react";
import { Dock, Phone } from "../Phone";
import { Chip, Glass, ProgressBar, ProgressRing, Sparkline, spring } from "../ui";

const tabs = ["الكل", "جارٍ", "في الانتظار", "مكتمل", "فاشل"];

/** Download manager replica: tabs, rich cards, live rings, sparkline, drag handle. */
export default function DownloadsScreen() {
  const [tab, setTab] = useState("الكل");
  const [p, setP] = useState(52);

  return (
    <Phone>
      <div className="flex h-full flex-col gap-3 px-4 pt-3 pb-24">
        <h2 className="aurora-gradient-text text-[20px] font-bold">التحميلات</h2>

        {/* tabs */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 [scrollbar-width:none]">
          {tabs.map((t, i) => (
            <Chip key={t} active={tab === t} onClick={() => setTab(t)}>
              {t}
              {i === 1 && (
                <span className="mr-1 inline-grid h-3.5 w-3.5 place-items-center rounded-full bg-white/25 text-[8px]">3</span>
              )}
            </Chip>
          ))}
        </div>

        {/* kind filters */}
        <div className="flex gap-1.5">
          {["فيديو", "صوت", "صور", "ملفات"].map((k) => (
            <span key={k} className="glass rounded-full px-2.5 py-1 text-[9px] text-[#a7aec2]">
              {k}
            </span>
          ))}
        </div>

        <div className="flex flex-col gap-2.5 overflow-hidden">
          {/* active card — hero */}
          <ActiveCard p={p} onTick={() => setP((v) => (v >= 97 ? 41 : v + 2))} />

          {/* queued card */}
          <Glass radius={20} className="flex items-center gap-2.5 p-3">
            <div className="grid h-9 w-9 place-items-center rounded-full bg-white/8">
              <Play size={14} className="text-[#4ade80]" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[10.5px] font-semibold">Lo-Fi Mix 2024 — Full Album.m4a</p>
              <p className="text-[8.5px] text-[#6b7386]">في الانتظار · أولوية عالية · اسحب لإعادة الترتيب</p>
            </div>
            <div className="flex flex-col gap-1">
              {[0, 1, 2].map((i) => (
                <span key={i} className="block h-0.5 w-3.5 rounded-full bg-white/25" />
              ))}
            </div>
          </Glass>

          {/* done card */}
          <Glass radius={20} className="flex items-center gap-2.5 p-3">
            <div className="relative h-9 w-9 overflow-hidden rounded-xl">
              <img src="/showcase/cover-music.jpg" alt="" className="h-full w-full object-cover" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[10.5px] font-semibold">Neon Skyline — Embers.opus</p>
              <p className="text-[8.5px] text-[#4ade80]">اكتمل · 24.1 MB · SHA-256 ✔</p>
            </div>
            <div className="flex gap-1">
              <IconBtn icon={FolderOpen} />
              <IconBtn icon={Share2} />
              <IconBtn icon={Trash2} danger />
            </div>
          </Glass>

          {/* failed card */}
          <Glass radius={20} className="flex items-center gap-2.5 p-3">
            <div className="grid h-9 w-9 place-items-center rounded-full bg-[#f87171]/15">
              <X size={14} className="text-[#f87171]" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[10.5px] font-semibold">story_highlight.zip</p>
              <p className="text-[8.5px] text-[#f87171]">403 — الرابط انتهت صلاحيته · سيجدَّد تلقائيًا</p>
            </div>
            <IconBtn icon={RefreshCcw} accent />
          </Glass>
        </div>

        <p className="mt-auto text-center text-[8.5px] text-[#6b7386]">
          3 نشطة · بحد أقصى 3 متزامنة · استئناف تلقائي بعد أي انقطاع
        </p>
      </div>
      <Dock active="downloads" />
    </Phone>
  );
}

function ActiveCard({ p, onTick }: { p: number; onTick: () => void }) {
  const [points] = useState(() => Array.from({ length: 28 }, (_, i) => 4 + Math.sin(i / 3) * 2 + Math.random() * 3));
  return (
    <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={spring}>
      <Glass
        radius={22}
        className="p-3.5"
        style={{ boxShadow: "inset 0 1px 0 rgba(255,255,255,.14), 0 0 40px -12px rgba(124,108,255,.55)" }}
      >
        <div className="flex items-center gap-3">
          <ProgressRing value={p / 100} size={52} stroke={4.5} />
          <div className="min-w-0 flex-1">
            <p className="truncate text-[11px] font-bold">أمواج المحيط من الأعلى — 4K.mp4</p>
            <p className="mt-0.5 text-[9px] text-[#a7aec2]" dir="ltr">
              {((p * 1.484) | 0) / 10 * 10} MB / 148.4 MB
            </p>
            <div className="mt-1 flex items-center gap-2 text-[8.5px]">
              <span className="text-[#4e8cff]" dir="ltr">24.6 MB/s</span>
              <span className="text-[#6b7386]">متبقٍ 00:15</span>
              <span className="rounded bg-[#9b72cb]/20 px-1.5 py-0.5 font-bold text-[#9b72cb]" dir="ltr">16 اتصال</span>
            </div>
          </div>
          <div className="flex flex-col gap-1.5">
            <button onClick={onTick} className="grid h-8 w-8 place-items-center rounded-full bg-[#9b72cb]/15 text-[#9b72cb]">
              <Pause size={13} />
            </button>
            <IconBtn icon={X} danger />
          </div>
        </div>
        <div className="mt-2.5">
          <ProgressBar value={p / 100} />
        </div>
        <Sparkline points={points} className="mt-2 h-6 w-full opacity-80" />
      </Glass>
    </motion.div>
  );
}

function IconBtn({ icon: Icon, danger = false, accent = false }: { icon: any; danger?: boolean; accent?: boolean }) {
  return (
    <motion.button
      whileTap={{ scale: 0.85 }}
      transition={spring}
      className={`grid h-8 w-8 place-items-center rounded-full ${
        danger ? "bg-[#f87171]/15 text-[#f87171]" : accent ? "bg-[#9b72cb]/15 text-[#9b72cb]" : "bg-white/8 text-[#a7aec2]"
      }`}
    >
      <Icon size={13} />
    </motion.button>
  );
}
