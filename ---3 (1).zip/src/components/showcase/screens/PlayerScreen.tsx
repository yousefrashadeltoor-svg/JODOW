"use client";

import { motion } from "framer-motion";
import {
  AlarmClock,
  Bell,
  Captions,
  ChevronLeft,
  Music4,
  Pause,
  PictureInPicture2,
  Play,
  Repeat,
  Repeat1,
  Scissors,
  SkipBack,
  SkipForward,
  Sparkles,
  Volume2,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Phone } from "../Phone";
import { Glass, spring } from "../ui";

const TRACKS = [
  { id: 1, title: "Neon Skyline", artist: "Nova Studio", dur: "3:42", img: "/showcase/cover-music.jpg", kind: "audio" },
  { id: 2, title: "أمواج المحيط 4K", artist: "Ocean Cinema", dur: "12:04", img: "/showcase/thumb-video.jpg", kind: "video" },
  { id: 3, title: "Desert Nights", artist: "Embers", dur: "4:18", img: "/showcase/cover-music.jpg", kind: "audio" },
];

/** Local player replica with real interaction: draggable trim handles, sleep timer, repeat, effects. */
export default function PlayerScreen() {
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [repeat, setRepeat] = useState<"off" | "one" | "all">("all");
  const [track, setTrack] = useState(TRACKS[0]);
  const [start, setStart] = useState(0.12);
  const [end, setEnd] = useState(0.72);
  const [sleepMin, setSleepMin] = useState(0);
  const [remaining, setRemaining] = useState(0);
  const trackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (sleepMin === 0) return;
    setRemaining(sleepMin * 60);
    const t = setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          clearInterval(t);
          setSleepMin(0);
          setPlaying(false);
          return 0;
        }
        return r - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [sleepMin]);

  const drag = (which: "start" | "end") => (e: React.PointerEvent) => {
    if (e.buttons !== 1 || !trackRef.current) return;
    const r = trackRef.current.getBoundingClientRect();
    const v = Math.min(1, Math.max(0, (r.right - e.clientX) / r.width));
    if (which === "start") setStart(Math.min(v, end - 0.04));
    else setEnd(Math.max(v, start + 0.04));
  };

  const repeatIcon = repeat === "one" ? Repeat1 : Repeat;

  return (
    <Phone>
      <div className="flex h-full flex-col gap-2.5 px-3.5 pt-2 pb-4">
        <div className="flex items-center gap-2">
          <span className="glass grid h-7 w-7 place-items-center rounded-full">
            <ChevronLeft size={12} className="text-[var(--fg)]" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[10.5px] font-bold">المشغل المحلي · {track.kind === "audio" ? "موسيقى" : "فيديو"}</p>
            <p className="text-[8px] text-[#6b7386]">يعمل بدون إنترنت</p>
          </div>
          <Volume2 size={12} className="text-[#a7aec2]" />
        </div>

        {/* artwork / video frame + real visualizer */}
        <Glass radius={22} className="overflow-hidden">
          <div className="relative aspect-square max-h-[168px] w-full">
            <img src={track.img} alt="" className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-black/30" />
            <div className="absolute inset-x-0 bottom-0 flex h-12 items-end gap-[3px] px-3 pb-2">
              {Array.from({ length: 26 }).map((_, i) => (
                <motion.span
                  key={i}
                  className="flex-1 rounded-t-sm bg-gradient-to-t from-[var(--c3)] to-[var(--c1)]"
                  animate={{ height: playing ? [6, 10 + ((i * 7) % 30), 6] : 5 }}
                  transition={{ duration: 0.7 + (i % 5) * 0.14, repeat: Infinity, ease: "easeInOut" }}
                  style={{ opacity: 0.85 }}
                />
              ))}
            </div>
            <motion.button
              onClick={() => setPlaying(!playing)}
              whileTap={{ scale: 0.86 }}
              transition={spring}
              className="absolute top-1/2 left-1/2 grid h-12 w-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full backdrop-blur-xl"
              style={{ background: "rgba(11,13,18,.55)", boxShadow: "0 0 40px -8px var(--glow), inset 0 1px 0 rgba(255,255,255,.3)" }}
            >
              {playing ? <Pause size={18} className="text-white" /> : <Play size={18} className="text-white" />}
            </motion.button>
          </div>
        </Glass>

        <div>
          <p className="text-[12px] font-bold leading-tight">{track.title}</p>
          <p className="text-[9px] text-[#6b7386]">{track.artist} · {track.dur}</p>
        </div>

        {/* transport */}
        <div className="flex items-center justify-center gap-5">
          <SkipBack size={16} className="text-[#a7aec2] flip-rtl" />
          <button onClick={() => setPlaying(!playing)} className="aurora-gradient grid h-12 w-12 place-items-center rounded-full shadow-[0_10px_28px_-6px_var(--glow)]">
            {playing ? <Pause size={18} className="text-white" /> : <Play size={18} className="text-white" />}
          </button>
          <SkipForward size={16} className="text-[#a7aec2] flip-rtl" />
        </div>

        {/* repeat + speed */}
        <div className="flex items-center justify-center gap-1.5">
          <button
            onClick={() => setRepeat(repeat === "off" ? "all" : repeat === "all" ? "one" : "off")}
            className={`glass flex items-center gap-1 rounded-full px-2 py-1 text-[8.5px] font-bold ${
              repeat !== "off" ? "text-[var(--glow)]" : "text-[#6b7386]"
            }`}
          >
            {(() => {
              const Icon = repeatIcon;
              return <Icon size={10} />;
            })()}
            {repeat === "off" ? "بدون" : repeat === "one" ? "مقطع" : "الكل"}
          </button>
          {[0.5, 1, 1.5, 2].map((s) => (
            <button
              key={s}
              onClick={() => setSpeed(s)}
              className={`rounded-full px-2 py-1 text-[8.5px] font-bold ${speed === s ? "aurora-gradient text-white" : "glass text-[#a7aec2]"}`}
              dir="ltr"
            >
              {s}x
            </button>
          ))}
        </div>

        {/* visual trim with real drag handles */}
        <Glass radius={18} className="p-2.5">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="flex items-center gap-1 text-[9px] font-bold">
              <Scissors size={10} className="text-[var(--glow)]" /> القص المرئي
            </span>
            <span className="text-[8.5px] text-[#6b7386]" dir="ltr">
              {fmt(start * 222)} → {fmt(end * 222)}
            </span>
          </div>
          <div ref={trackRef} className="relative h-11 select-none overflow-hidden rounded-lg">
            <div className="flex h-full w-full">
              {Array.from({ length: 8 }).map((_, i) => (
                <img key={i} src={track.img} alt="" className="h-full flex-1 object-cover opacity-80" />
              ))}
            </div>
            <div className="absolute inset-y-0 left-0 bg-black/65" style={{ width: `${start * 100}%` }} />
            <div className="absolute inset-y-0 right-0 bg-black/65" style={{ width: `${(1 - end) * 100}%` }} />
            <div className="aurora-gradient absolute inset-y-0 border-y-2 border-white/50" style={{ right: `${start * 100}%`, width: `${(end - start) * 100}%` }} />
            <div
              onPointerDown={() => {}}
              onPointerMove={drag("start")}
              className="absolute inset-y-0 w-3 cursor-ew-resize rounded bg-[var(--c3)] shadow-[0_0_10px_var(--glow)]"
              style={{ right: `${start * 100}%` }}
            />
            <div
              onPointerMove={drag("end")}
              className="absolute inset-y-0 w-3 cursor-ew-resize rounded bg-[var(--c3)] shadow-[0_0_10px_var(--glow)]"
              style={{ right: `${end * 100}%` }}
            />
          </div>
          <p className="mt-1 text-[7.5px] text-[#6b7386]">اسحب المقبضين يدويًا — بلا كتابة أرقام</p>
        </Glass>

        {/* sleep timer + tools */}
        <div className="flex gap-1.5">
          <details className="glass flex-1 rounded-xl px-2 py-1.5">
            <summary className="flex cursor-pointer list-none items-center gap-1 text-[8.5px] font-bold">
              <AlarmClock size={10} className="text-[var(--glow)]" /> مؤقت النوم
              {remaining > 0 && <span className="mr-auto text-[8px] text-[var(--glow)]" dir="ltr">{fmt(remaining)}</span>}
            </summary>
            <div className="mt-1.5 flex flex-wrap gap-1">
              {[10, 20, 30, 45, 60].map((m) => (
                <button key={m} onClick={() => setSleepMin(m)} className="rounded-full bg-white/10 px-2 py-0.5 text-[8px]">
                  {m} د
                </button>
              ))}
              <button onClick={() => { setSleepMin(0); setRemaining(0); }} className="rounded-full bg-white/10 px-2 py-0.5 text-[8px]">
                إلغاء
              </button>
            </div>
          </details>
          <div className="glass flex items-center gap-1 rounded-xl px-2 py-1.5 text-[8px]">
            <Captions size={10} className="text-[#4ade80]" /> ترجمة
          </div>
          <div className="glass flex items-center gap-1 rounded-xl px-2 py-1.5 text-[8px]">
            <PictureInPicture2 size={10} className="text-[#a7aec2]" /> PiP
          </div>
        </div>

        <div className="flex gap-1.5">
          <button className="glass flex flex-1 items-center justify-center gap-1 rounded-full py-1.5 text-[8.5px] font-bold">
            <Bell size={10} className="text-[#fbbf24]" /> نغمة رنين
          </button>
          <button className="glass flex flex-1 items-center justify-center gap-1 rounded-full py-1.5 text-[8.5px] font-bold">
            <Sparkles size={10} className="text-[var(--glow)]" /> مؤثرات
          </button>
        </div>

        <div className="mt-auto">
          <p className="mb-1 text-[8px] font-bold text-[#6b7386]">مكتبتي المحلية</p>
          <div className="flex gap-1.5 overflow-x-auto pb-1 [scrollbar-width:none]">
            {TRACKS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTrack(t)}
                className={`glass flex shrink-0 items-center gap-1.5 rounded-xl p-1.5 ${track.id === t.id ? "ring-1 ring-white/50" : ""}`}
              >
                <img src={t.img} alt="" className="h-7 w-7 rounded-lg object-cover" />
                <span className="text-right">
                  <span className="block max-w-[76px] truncate text-[8px] font-bold">{t.title}</span>
                  <span className="block text-[7px] text-[#6b7386]">{t.kind === "audio" ? <Music4 size={7} className="inline" /> : null} {t.dur}</span>
                </span>
              </button>
            ))}
          </div>
          <p className="mt-1 text-center text-[7px] text-[#6b7386]">
            تعيين النغمة والمؤثرات الصوتية تُنفَّذ عبر APIs أندرويد الأصلية داخل الـ APK.
          </p>
        </div>
      </div>
    </Phone>
  );
}

function fmt(sec: number) {
  const s = Math.floor(sec);
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}
