"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowRight,
  File,
  Globe,
  Image as ImageIcon,
  Lock,
  MonitorSmartphone,
  Music4,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Video,
} from "lucide-react";
import { useState } from "react";
import { Phone } from "../Phone";
import { Glass, spring, springSoft } from "../ui";

/** Internal browser replica: glass address bar, sniffed-media FAB, catch sheet. */
export default function BrowserScreen() {
  const [sheet, setSheet] = useState(false);
  const [blocked, setBlocked] = useState(18);

  const sniffed = [
    { icon: Video, name: "photo_mode_slides_04.mp4", meta: "video/mp4 · 12.8 MB · 16 اتصال", color: "#7c6cff" },
    { icon: Music4, name: "original_track.opus", meta: "audio/ogg · 3.1 MB", color: "#3ec6d3" },
    { icon: ImageIcon, name: "slide_02_2048.jpg", meta: "image/jpeg · 1.4 MB", color: "#e0668c" },
    { icon: File, name: "playlist.m3u8", meta: "HLS · 47 مقطعًا", color: "#f2a45c" },
  ];

  return (
    <Phone>
      <div className="flex h-full flex-col">
        {/* glass address bar */}
        <div className="px-3 pt-2">
          <Glass radius={22} className="flex items-center gap-1.5 px-2 py-1.5">
            <RoundMini icon={ArrowRight} />
            <RoundMini icon={RotateCcw} />
            <div className="glass flex min-w-0 flex-1 items-center gap-1.5 rounded-full px-2.5 py-1.5">
              <Lock size={9} className="shrink-0 text-[#4ade80]" />
              <span className="truncate text-[9px] text-[#a7aec2] font-[family-name:var(--font-outfit-src)]" dir="ltr">
                tiktok.com/@ocean_cinema
              </span>
            </div>
            <div className="glass flex items-center gap-1 rounded-full px-2 py-1.5">
              <ShieldCheck size={10} className="text-[#f87171]" />
              <motion.span
                key={blocked}
                initial={{ scale: 1.6, color: "#e0668c" }}
                animate={{ scale: 1, color: "#a7aec2" }}
                className="text-[9px] font-bold"
              >
                {blocked}
              </motion.span>
            </div>
          </Glass>
        </div>

        {/* fake page */}
        <div className="relative mx-3 mt-2.5 flex-1 overflow-hidden rounded-[20px] bg-[#12141c]">
          <img src="/showcase/thumb-video.jpg" alt="" className="absolute inset-0 h-full w-full object-cover opacity-80" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0b0d12] via-transparent to-[#0b0d12]/40" />
          <div className="absolute right-2.5 bottom-3 left-2.5">
            <p className="text-[11px] font-bold">Ocean Cinema</p>
            <p className="text-[8.5px] text-white/70">2.4M مشاهدة · كل الصور في الأسفل…</p>
          </div>
          <div className="absolute top-2.5 left-2.5 flex items-center gap-1 rounded-full bg-black/50 px-2 py-1 backdrop-blur">
            <MonitorSmartphone size={9} className="text-white/80" />
            <span className="text-[7.5px] text-white/80">وضع سطح المكتب</span>
          </div>
          <div className="absolute top-2.5 right-2.5 rounded-full bg-[#4ade80]/20 px-2 py-1 text-[7.5px] font-bold text-[#4ade80] backdrop-blur">
            cf_clearance ✔
          </div>

          {/* bottom sheet of caught files */}
          <AnimatePresence>
            {sheet && (
              <motion.div
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "110%" }}
                transition={{ ...springSoft, mass: 0.8 }}
                className="absolute inset-x-0 bottom-0 z-20"
              >
                <Glass
                  radius={24}
                  className="glass-deep mx-1.5 mb-1.5 max-h-[62%] overflow-hidden rounded-b-[22px] p-3"
                >
                  <div className="mx-auto mb-2.5 h-1 w-9 rounded-full bg-white/25" />
                  <div className="mb-2 flex items-center justify-between">
                    <p className="aurora-gradient-text text-[12px] font-bold">الملفات المكتشفة</p>
                    <span className="text-[8.5px] text-[#6b7386]">يُحمَّل بمحرك التطبيق · الكوكيز تُنقل تلقائيًا</span>
                  </div>
                  <div className="flex flex-col gap-1.5 overflow-y-auto">
                    {sniffed.map((f, i) => (
                      <motion.div
                        key={f.name}
                        initial={{ opacity: 0, x: 18 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ ...spring, delay: 0.08 + i * 0.07 }}
                        className="glass flex items-center gap-2 rounded-2xl p-2"
                      >
                        <span className="grid h-8 w-8 place-items-center rounded-xl" style={{ background: `${f.color}22` }}>
                          <f.icon size={13} style={{ color: f.color }} />
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[9.5px] font-semibold" dir="ltr">{f.name}</p>
                          <p className="text-[7.5px] text-[#6b7386]">{f.meta}</p>
                        </div>
                        <span className="aurora-gradient rounded-full px-2.5 py-1 text-[8px] font-bold text-white">
                          تحميل
                        </span>
                      </motion.div>
                    ))}
                  </div>
                </Glass>
              </motion.div>
            )}
          </AnimatePresence>

          {/* catch FAB */}
          <motion.button
            onClick={() => { setSheet((s) => !s); setBlocked((b) => b + 1); }}
            whileTap={{ scale: 0.88 }}
            transition={spring}
            className="aurora-gradient absolute bottom-3 left-1/2 z-30 flex -translate-x-1/2 items-center gap-1.5 rounded-full px-4 py-2.5 shadow-[0_10px_30px_-8px_rgba(224,102,140,.7)]"
          >
            <Sparkles size={13} className="text-white" />
            <span className="text-[10px] font-bold text-white">اصطُيِد ٧ ملفات</span>
          </motion.button>
        </div>

        <p className="py-2 text-center text-[8px] text-[#6b7386]">
          حَجَب الإعلان {blocked} عنصرًا · Popups وTrackers محظورة
        </p>
      </div>
    </Phone>
  );
}

function RoundMini({ icon: Icon }: { icon: any }) {
  return (
    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-white/8">
      <Icon size={11} className="text-[#a7aec2]" />
    </span>
  );
}
