"use client";

import { motion } from "framer-motion";
import { File, Image as ImageIcon, LayoutGrid, List, Music4, Video } from "lucide-react";
import { useState } from "react";
import { Dock, Phone } from "../Phone";
import { Glass, spring } from "../ui";

const files = [
  { name: "Ocean Drone 4K.mp4", size: "148.4 MB", kind: "video", thumb: "/showcase/thumb-video.jpg" },
  { name: "Neon Skyline.opus", size: "24.1 MB", kind: "audio", thumb: "/showcase/cover-music.jpg" },
  { name: "slide_02_2048.jpg", size: "1.4 MB", kind: "image", thumb: "/showcase/thumb-video.jpg" },
  { name: "wallpaper_pack.zip", size: "86.2 MB", kind: "file", thumb: null },
  { name: "Desert Drive.mp4", size: "92.8 MB", kind: "video", thumb: "/showcase/thumb-video.jpg" },
  { name: "subtitles_ar.srt", size: "41 KB", kind: "file", thumb: null },
];

const KIND = {
  video: { icon: Video, color: "#7c6cff" },
  audio: { icon: Music4, color: "#3ec6d3" },
  image: { icon: ImageIcon, color: "#e0668c" },
  file: { icon: File, color: "#f2a45c" },
} as const;

/** Library grid replica. */
export default function FilesScreen() {
  const [grid, setGrid] = useState(true);
  const [filter, setFilter] = useState<string>("الكل");

  return (
    <Phone>
      <div className="flex h-full flex-col gap-3 px-4 pt-3 pb-24">
        <div className="flex items-center justify-between">
          <h2 className="aurora-gradient-text text-[20px] font-bold">الملفات</h2>
          <motion.button
            whileTap={{ scale: 0.88 }}
            transition={spring}
            onClick={() => setGrid(!grid)}
            className="glass grid h-8 w-8 place-items-center rounded-full"
          >
            {grid ? <List size={13} className="text-[#a7aec2]" /> : <LayoutGrid size={13} className="text-[#a7aec2]" />}
          </motion.button>
        </div>

        <div className="flex gap-1.5">
          {["الكل", "فيديو", "صوت", "صور", "ملفات"].map((f) => (
            <motion.button
              key={f}
              onClick={() => setFilter(f)}
              whileTap={{ scale: 0.92 }}
              transition={spring}
              className={`rounded-full px-2.5 py-1 text-[9px] font-medium ${
                filter === f ? "aurora-gradient text-white" : "glass text-[#a7aec2]"
              }`}
            >
              {f}
            </motion.button>
          ))}
        </div>

        <div className={`grid gap-2.5 ${grid ? "grid-cols-2" : "grid-cols-1"}`}>
          {files.map((f, i) => {
            const meta = KIND[f.kind as keyof typeof KIND];
            const Icon = meta.icon;
            return (
              <motion.div
                key={f.name}
                initial={{ opacity: 0, y: 18, scale: 0.94 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ ...spring, delay: i * 0.06 }}
              >
                <Glass radius={20} className="overflow-hidden">
                  <div className={`relative ${grid ? "aspect-[4/2.6]" : "hidden"}`}>
                    {f.thumb ? (
                      <img src={f.thumb} alt="" className="h-full w-full object-cover" />
                    ) : (
                      <div className="grid h-full w-full place-items-center" style={{ background: `${meta.color}12` }}>
                        <span className="grid h-11 w-11 place-items-center rounded-[16px]" style={{ background: `${meta.color}28`, boxShadow: `0 0 24px -6px ${meta.color}55` }}>
                          <Icon size={18} style={{ color: meta.color }} />
                        </span>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/55 to-transparent" />
                    <span
                      className="absolute top-1.5 right-1.5 grid h-5 w-5 place-items-center rounded-md"
                      style={{ background: "rgba(11,13,18,.6)", backdropFilter: "blur(8px)" }}
                    >
                      <Icon size={10} style={{ color: meta.color }} />
                    </span>
                  </div>
                  <div className="p-2.5">
                    <p className="truncate text-[10px] font-bold" dir="ltr">{f.name}</p>
                    <p className="text-[8px] text-[#6b7386]" dir="ltr">{f.size}</p>
                  </div>
                </Glass>
              </motion.div>
            );
          })}
        </div>
      </div>
      <Dock active="files" />
    </Phone>
  );
}
