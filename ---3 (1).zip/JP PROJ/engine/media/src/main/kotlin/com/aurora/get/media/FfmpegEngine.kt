package com.aurora.get.media

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * FFmpeg execution engine (spec §8). Prefers stream copy whenever the codec allows it —
 * no wasted re-encode. Every long operation reports progress as a 0..1 flow.
 */
@Singleton
class FfmpegEngine @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress

    private suspend fun run(args: List<String>, durationSec: Float = 0f): Boolean =
        withContext(Dispatchers.IO) {
            try {
                FFmpeg.getInstance().execute(args.toTypedArray()) { rc ->
                    if (rc != 0) Timber.w("ffmpeg exited with rc=$rc")
                }
                _progress.value = 1f
                true
            } catch (t: Throwable) {
                Timber.e(t, "ffmpeg failed: ${args.joinToString(" ")}")
                false
            }
        }

    /** Merge DASH video-only + best audio without re-encoding (-c copy). */
    suspend fun merge(videoFile: File, audioFile: File, output: File): Boolean =
        run(listOf(
            "-y", "-i", videoFile.absolutePath, "-i", audioFile.absolutePath,
            "-c", "copy", "-map", "0:v:0", "-map", "1:a:0", output.absolutePath,
        ))

    /**
     * Extract audio from video. Stream copy when the container already carries the target
     * codec (e.g. mp4 + aac → m4a), otherwise decode to the requested format.
     */
    suspend fun extractAudio(
        input: File, output: File, format: AudioFormat, bitrateK: Int = 192,
    ): Boolean {
        val copyable = when (format) {
            AudioFormat.AAC_M4A -> input.extension.lowercase() in listOf("mp4", "m4v", "mov", "m4a")
            AudioFormat.OPUS -> input.extension.lowercase() in listOf("webm", "mkv", "opus")
            else -> false
        }
        val codecArgs = if (copyable) listOf("-c:a", "copy") else listOf(
            "-c:a", format.ffmpegCodec, "-b:a", "${bitrateK}k",
        )
        return run(listOf("-y", "-i", input.absolutePath, "-vn") + codecArgs + output.absolutePath)
    }

    /** Remux/convert container: mp4/mkv/webm/mov; re-encode only when the target demands it. */
    suspend fun convertVideo(
        input: File,
        output: File,
        targetCodec: String? = null,     // "copy" | "libx265" | "libvpx-vp9"...
        crf: Int = 23,
        trimStartSec: Double? = null,
        trimDurationSec: Double? = null,
        burnSubtitle: File? = null,
        metadata: Map<String, String> = emptyMap(),
    ): Boolean {
        val args = mutableListOf("-y")
        trimStartSec?.let { args += listOf("-ss", it.toString()) }
        args += listOf("-i", input.absolutePath)
        trimDurationSec?.let { args += listOf("-t", it.toString()) }
        burnSubtitle?.let { args += listOf("-vf", "subtitles='${it.absolutePath}'") }
        when (targetCodec) {
            null, "copy" -> args += listOf("-c", "copy")
            else -> args += listOf("-c:v", targetCodec, "-crf", crf.toString(), "-c:a", "copy")
        }
        metadata.forEach { (k, v) -> args += listOf("-metadata", "$k=$v") }
        args += output.absolutePath
        return run(args)
    }

    /** Embed cover art + ID3-style metadata into an audio file. */
    suspend fun embedMetadata(
        input: File, output: File, cover: File?,
        tags: Map<String, String>,
    ): Boolean {
        val args = mutableListOf("-y", "-i", input.absolutePath)
        if (cover != null) args += listOf("-i", cover.absolutePath, "-map", "0:a", "-map", "1:v", "-c:v:1", "mjpeg")
        else args += listOf("-map", "0")
        args += listOf("-c", "copy")
        tags.forEach { (k, v) -> args += listOf("-metadata", "$k=$v") }
        args += output.absolutePath
        return run(args)
    }

    /**
     * Transparent-quality re-encode (spec §9): HEVC at computed CRF, then SSIM verification.
     * If SSIM < 0.95 the output is rejected and retried at a lower CRF (higher quality).
     */
    suspend fun compressVideoTransparent(
        input: File, output: File, target: VideoCodec = VideoCodec.HEVC,
    ): TransparentResult {
        var crf = 26
        repeat(3) { attempt ->
            val ok = convertVideo(input, output, targetCodec = target.ffmpegCodec, crf = crf)
            if (!ok) return TransparentResult(false, output, 0f, crf)
            if (output.length() >= input.length()) {
                // Honest rule: never return a bigger file
                output.delete()
                return TransparentResult(false, input, ssim = 1f, crf = crf, note = "الملف أصغر من أن يُضغط — لم يتغير شيء")
            }
            val ssim = measureSsim(input, output) ?: 0f
            if (ssim >= 0.95f) return TransparentResult(true, output, ssim, crf)
            crf -= 3 // raise quality and retry
        }
        output.delete()
        return TransparentResult(false, input, 0f, 0, "تعذر بلوغ عتبة الشفافية — أُبقي الأصل")
    }

    /** SSIM via ffmpeg's filter graph. Returns mean SSIM 0..1 or null when unsupported. */
    suspend fun measureSsim(reference: File, candidate: File): Float? = withContext(Dispatchers.IO) {
        val log = StringBuilder()
        runCatching {
            FFmpeg.getInstance().execute(
                arrayOf(
                    "-i", candidate.absolutePath, "-i", reference.absolutePath,
                    "-lavfi", "ssim", "-f", "null", "-",
                )
            ) { rc -> Timber.d("ssim rc=$rc\n$log") }
        }
        // youtubedl-android's FFmpeg streams stats to stderr; parse the All line.
        Regex("All:(\\d+\\.\\d+)").find(log)?.groupValues?.get(1)?.toFloatOrNull()
    }

    data class TransparentResult(
        val success: Boolean,
        val output: File,
        val ssim: Float,
        val crf: Int,
        val note: String = "",
    )

    enum class AudioFormat(val ffmpegCodec: String, val ext: String) {
        MP3("libmp3lame", "mp3"), AAC_M4A("aac", "m4a"), OPUS("libopus", "opus"),
        OGG("libvorbis", "ogg"), FLAC("flac", "flac"), WAV("pcm_s16le", "wav"),
    }

    enum class VideoCodec(val ffmpegCodec: String) {
        H264("libx264"), HEVC("libx265"), AV1("libaom-av1"), VP9("libvpx-vp9"),
    }
}
