package com.aurora.get.downloader

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.content.Intent
import android.content.IntentFilter
import com.aurora.get.db.DownloadDao
import com.aurora.get.db.DownloadEntity
import com.aurora.get.db.SegmentDao
import com.aurora.get.network.PersistentCookieJar
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Priority queue with configurable concurrency, drag-drop ordering, scheduling
 * (exact time), Wi-Fi-only / charging-only / low-battery-pause policies.
 */
@Singleton
class DownloadQueue @Inject constructor(
    @ApplicationContext private val context: Context,
    private val downloadDao: DownloadDao,
    private val segmentDao: SegmentDao,
    private val cookieJar: PersistentCookieJar,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _running = MutableStateFlow<Map<String, SegmentedDownloader.Progress>>(emptyMap())
    val running: StateFlow<Map<String, SegmentedDownloader.Progress>> = _running

    var maxConcurrent = 3
        set(value) { field = value.coerceIn(1, 8) }
    private val semaphore = Semaphore(maxConcurrent)

    private val paused = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val cancelled = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    fun enqueue(entity: DownloadEntity) {
        scope.launch {
            downloadDao.upsert(entity.copy(status = "QUEUED"))
            pump()
        }
    }

    fun pause(id: String) { paused += id; scope.launch { downloadDao.setStatus(id, "PAUSED") } }
    fun resume(id: String) { paused -= id; scope.launch { pump() } }
    suspend fun cancel(id: String) {
        cancelled += id
        downloadDao.setStatus(id, "FAILED")
        segmentDao.clearFor(id)
    }

    suspend fun reorder(orderedIds: List<String>) {
        orderedIds.forEachIndexed { index, id -> downloadDao.reorder(id, index) }
    }

    private suspend fun policiesSatisfied(d: DownloadEntity): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val onWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        if (d.wifiOnly && !onWifi) return false
        if (d.chargingOnly) {
            val battery: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let {
                context.registerReceiver(null, it)
            }
            val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            if (!charging) return false
            val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level >= 0 && scale > 0 && level * 100 / scale < 15) return false // low battery pause
        }
        if (d.scheduledAt > System.currentTimeMillis()) return false
        return true
    }

    private fun pump() {
        scope.launch {
            val queue = downloadDao.byStatus("QUEUED")
                .filter { it.id !in paused && it.id !in cancelled }
                .sortedWith(compareByDescending<DownloadEntity> { it.priority }.thenBy { it.sortOrder })
            queue.forEach { entity ->
                if (!policiesSatisfied(entity)) return@forEach
                scope.launch {
                    semaphore.withPermit {
                        downloadDao.setStatus(entity.id, "RUNNING")
                        try {
                            val engine = SegmentedDownloader(
                                client = com.aurora.get.network.NetworkModule.okHttpClient(context,
                                    com.aurora.get.network.CachingDns(), cookieJar),
                                segmentDao = segmentDao,
                            )
                            val headers = buildHeaders(entity)
                            val result = engine.download(
                                entity = entity,
                                url = entity.directUrl ?: entity.url,
                                headers = headers,
                                connections = entity.segments.takeIf { it > 0 } ?: 16,
                                speedLimit = entity.speedLimitBps,
                                shouldPause = { entity.id in paused || entity.id in cancelled },
                            )
                            handleTerminal(entity, result)
                        } catch (t: Throwable) {
                            when (t) {
                                is kotlinx.coroutines.CancellationException ->
                                    downloadDao.setStatus(entity.id, if (entity.id in cancelled) "FAILED" else "PAUSED")
                                else -> {
                                    Timber.e(t, "Download failed: ${entity.id}")
                                    downloadDao.setStatus(entity.id, "FAILED")
                                    // 403/410 → the URL expired; re-extraxctor handles refresh upstream
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun buildHeaders(entity: DownloadEntity): MutableMap<String, String> {
        val h = mutableMapOf<String, String>()
        entity.headersJson?.let { json ->
            runCatching {
                kotlinx.serialization.json.Json.parseToJsonElement(json).jsonObject
                    .forEach { (k, v) -> h[k] = v.toString().trim('"') }
            }
        }
        entity.siteDomain?.let { host ->
            cookieJar.loadForRequest(
                okhttp3.HttpUrl.Builder().scheme("https").host(host).build()
            ).takeIf { it.isNotEmpty() }?.let { cookies ->
                h.merge("Cookie", cookies.joinToString("; ") { "${it.name}=${it.value}" }) { a, b -> "$a; $b" }
            }
        }
        return h
    }

    private suspend fun handleTerminal(entity: DownloadEntity, result: SegmentedDownloader.Progress) {
        if (result.finished) {
            if (entity.needsMerge && entity.audioUrl != null) {
                downloadDao.setStatus(entity.id, "MERGING")
                // MergeEngine (:engine:media) performs -c copy merge, then marks COMPLETED.
            }
            downloadDao.progress(entity.id, result.total, "COMPLETED")
        } else if (result.failed) {
            downloadDao.progress(entity.id, result.downloaded, "FAILED")
        }
    }
}
