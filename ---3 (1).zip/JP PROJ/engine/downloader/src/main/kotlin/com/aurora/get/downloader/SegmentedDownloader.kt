package com.aurora.get.downloader

import com.aurora.get.common.SizeInfo
import com.aurora.get.db.DownloadEntity
import com.aurora.get.db.SegmentDao
import com.aurora.get.db.SegmentEntity
import com.aurora.get.network.SizeResolver
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.io.File
import java.io.RandomAccessFile
import java.nio.channels.FileChannel
import java.util.concurrent.ConcurrentLinkedDeque
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

/**
 * Segmented parallel download engine (spec §7):
 *  - dynamic segmentation (8..32 connections, adapts to server + network),
 *  - work-stealing: a finished connection splits the slowest remaining segment,
 *  - pre-allocation (RandomAccessFile.setLength) + positioned write via FileChannel,
 *  - large buffers (256KB..1MB), no excess copying,
 *  - per-segment resume state in Room (offsets, ETag, Last-Modified) — resumes after
 *    pause / network loss / process death / reboot,
 *  - exponential backoff with jitter, retry policy,
 *  - smart fallback to single-connection when the server lacks Accept-Ranges.
 */
class SegmentedDownloader(
    private val client: OkHttpClient,
    private val segmentDao: SegmentDao,
) {
    companion object {
        const val MIN_CONNECTIONS = 8
        const val MAX_CONNECTIONS = 32
        const val MIN_SEGMENT_SIZE = 512L * 1024        // 512KB — don't segment tiny files
        const val BUFFER_SIZE = 256 * 1024              // 256KB write buffer
    }

    data class Progress(
        val downloaded: Long,
        val total: Long,
        val speedBytesPerSec: Double,
        val activeConnections: Int,
        val finished: Boolean,
        val failed: Boolean = false,
        val error: String? = null,
    )

    /** Live progress for one download (backed by the service). */
    private val _progress = MutableStateFlow(Progress(0, -1, 0.0, 0, finished = false))
    val progress: StateFlow<Progress> = _progress

    /**
     * A work unit that yields byte ranges. Work-stealing: when a worker finishes,
     * it takes the largest remaining segment and splits it in half.
     */
    private inner class WorkPool(segments: List<SegmentEntity>, private val raf: RandomAccessFile) {
        private val pending = ConcurrentLinkedDeque(segments.filter { !it.done }.toMutableList())
        private val lock = Any()
        private val _largestRemainder = java.util.concurrent.atomic.AtomicReference<SegmentEntity?>(null)

        fun poll(downloadId: String): SegmentEntity? = synchronized(lock) {
            pending.poll()?.also { _largestRemainder.set(pending.maxByOrNull { rem -> rem.end - rem.start - rem.written }) }
        }

        /** Steal: split the currently-largest pending segment in half. */
        fun steal(downloadId: String): SegmentEntity? = synchronized(lock) {
            val largest = pending.maxByOrNull { it.end - it.start - it.written } ?: return null
            val remaining = largest.end - largest.start + 1 - largest.written
            if (remaining < MIN_SEGMENT_SIZE) return null
            pending.remove(largest)
            val writtenAbs = largest.start + largest.written
            val mid = writtenAbs + remaining / 2
            val first = largest.copy(end = mid - 1)
            val second = largest.copy(index = largest.index + 10_000, start = mid, written = 0)
            pending.addFirst(first)
            pending.addLast(second)
            null // worker should loop and poll again
        }
    }

    /**
     * Downloads [entity] to disk. Idempotent: if prior segment rows exist, it resumes
     * exactly where they stopped after verifying ETag/Last-Modified.
     *
     * @param connectionHint adaptive connection count from SpeedAdvisor.
     * @param speedLimit 0 = unlimited; otherwise bytes/sec cap (token bucket per worker).
     */
    suspend fun download(
        entity: DownloadEntity,
        url: String,
        headers: Map<String, String>,
        connections: Int,
        speedLimit: Long = 0,
        shouldPause: () -> Boolean = { false },
    ): Progress = coroutineScope {
        val dest = File(entity.destDir, entity.fileName).also { it.parentFile?.mkdirs() }
        var aborted: String? = null

        // ── Probe server & validate previous resume state
        val probe = SizeResolver(client).resolve(url, headers)
        val total = probe.size?.bytes ?: entity.totalBytes
        val supportsRanges = probe.supportsRanges && total > 0

        if (entity.etag != null && probe.etag != null && entity.etag != probe.etag) {
            // File changed server-side since we started → refuse blind resume
            aborted = "ETag changed"
            _progress.value = Progress(0, total, 0.0, 0, finished = false, failed = true, error = aborted)
            return@coroutineScope _progress.value
        }

        // ── Build / restore segments
        var segments = segmentDao.forDownload(entity.id)
        if (segments.isEmpty()) {
            segments = if (supportsRanges && total > MIN_SEGMENT_SIZE * 2) {
                val count = connections.coerceIn(MIN_CONNECTIONS, MAX_CONNECTIONS)
                val each = total / count
                (0 until count).map { i ->
                    val start = i * each
                    val end = if (i == count - 1) total - 1 else (i + 1) * each - 1
                    SegmentEntity(entity.id, i, start, end)
                }
            } else {
                listOf(SegmentEntity(entity.id, 0, 0, max(0, total - 1)))
            }
            segmentDao.upsertAll(segments)
        }

        // ── Pre-allocate the file at final size (no fragmentation, positioned writes)
        if (supportsRanges && total > 0) RandomAccessFile(dest, "rw").use { it.setLength(total) }

        val raf = RandomAccessFile(dest, "rw")
        val channel: FileChannel = raf.channel
        val workPool = WorkPool(segments, raf)
        val activeCount = java.util.concurrent.atomic.AtomicInteger(0)
        val downloadedAtStart = segmentDao.writtenBytes(entity.id) ?: 0
        val downloadedCounter = java.util.concurrent.atomic.AtomicLong(downloadedAtStart)
        val windowBytes = java.util.concurrent.atomic.AtomicLong(0)
        val speedState = java.util.concurrent.atomic.AtomicReference(0.0)

        // Speed reporter — EMA over 500ms windows
        val reporter = async(Dispatchers.Default) {
            var last = System.nanoTime()
            while (isActive) {
                delay(500)
                val now = System.nanoTime()
                val bytes = windowBytes.getAndSet(0)
                val secs = (now - last) / 1e9
                last = now
                val instant = bytes / secs
                val old = speedState.get()
                speedState.set(if (old == 0.0) instant else old * 0.6 + instant * 0.4)
                _progress.value = Progress(
                    downloaded = downloadedCounter.get(),
                    total = total,
                    speedBytesPerSec = speedState.get(),
                    activeConnections = activeCount.get(),
                    finished = false,
                )
            }
        }

        val workerCount = if (supportsRanges) connections.coerceIn(MIN_CONNECTIONS, MAX_CONNECTIONS) else 1
        try {
            val workers: List<Deferred<Unit>> = (0 until workerCount).map { workerId ->
                async(Dispatchers.IO) {
                    var retries = 0
                    while (isActive && aborted == null) {
                        if (shouldPause()) throw CancellationException("paused")
                        val seg = workPool.poll(entity.id) ?: break
                        activeCount.incrementAndGet()
                        try {
                            runSegment(entity, url, headers, seg, channel, speedLimit,
                                onBytes = { n ->
                                    downloadedCounter.addAndGet(n)
                                    windowBytes.addAndGet(n)
                                })
                            segmentDao.upsert(seg.copy(done = true, written = seg.end - seg.start + 1))
                            retries = 0
                        } catch (ce: CancellationException) {
                            throw ce
                        } catch (t: Throwable) {
                            retries++
                            Timber.w(t, "Segment ${seg.index} failed (retry $retries)")
                            // exponential backoff + jitter, max 5 tries
                            if (retries > 5) throw t
                            segmentDao.upsert(seg) // persist exact byte offset for resume
                            delay(backoffMs(retries))
                            workPool.steal(entity.id) // let another worker split the slowest part
                        } finally {
                            activeCount.decrementAndGet()
                        }
                    }
                }
            }
            workers.awaitAll()
        } catch (ce: CancellationException) {
            reporter.cancel()
            raf.close()
            _progress.value = Progress(downloadedCounter.get(), total, 0.0, 0, finished = false)
            throw ce
        } catch (t: Throwable) {
            aborted = t.message
        } finally {
            reporter.cancel()
            raf.close()
        }

        val ok = aborted == null && downloadedCounter.get() >= total - 1
        _progress.value = Progress(
            downloaded = downloadedCounter.get(),
            total = total,
            speedBytesPerSec = 0.0,
            activeConnections = 0,
            finished = ok,
            failed = !ok,
            error = aborted,
        )
        _progress.value
    }

    /** Streams one byte-range and writes it at its absolute position via FileChannel. */
    private suspend fun runSegment(
        entity: DownloadEntity,
        url: String,
        headers: Map<String, String>,
        seg: SegmentEntity,
        channel: FileChannel,
        speedLimit: Long,
        onBytes: (Long) -> Unit,
    ) {
        val rangeStart = seg.start + seg.written
        if (rangeStart > seg.end) return

        val req = Request.Builder().url(url)
            .apply {
                if (seg.end >= seg.start) header("Range", "bytes=$rangeStart-${seg.end}")
                entity.etag?.let { header("If-Range", it) }
                entity.lastModified?.let { header("If-Unmodified-Since", it) }
                headers.forEach { (k, v) -> header(k, v) }
            }
            .get()
            .build()

        client.newCall(req).execute().use { res ->
            if (res.code !in listOf(200, 206)) error("HTTP ${res.code}")
            if (res.code == 200 && seg.written > 0 && seg.start > 0) {
                // Server ignored the Range → cannot resume this segment; restart it
                error("Server ignored Range")
            }
            val body = res.body
            val input = body.byteStream()
            val buf = ByteArray(BUFFER_SIZE)
            val writeBuffer = java.nio.ByteBuffer.allocateDirect(BUFFER_SIZE)
            var pos = rangeStart
            var segWritten = seg.written

            // token bucket for optional speed limit
            val bucket = TokenBucket(if (speedLimit > 0) speedLimit / 8 else Long.MAX_VALUE)

            while (true) {
                val read = input.read(buf)
                if (read == -1) break
                bucket.await(read.toLong())
                writeBuffer.clear()
                writeBuffer.put(buf, 0, read)
                writeBuffer.flip()
                synchronized(channel) { channel.write(writeBuffer, pos) }
                pos += read
                segWritten += read
                onBytes(read.toLong())
            }
        }
    }

    private fun backoffMs(attempt: Int): Long =
        (min(30_000.0, 500.0 * 2.0.pow(attempt - 1)) * (0.75 + Random.nextDouble() * 0.5)).toLong()
}

/** Simple async token bucket: allows [permitsPerSecond] bytes per second. */
private class TokenBucket(private val permitsPerSecond: Long) {
    private var allowance = permitsPerSecond.toDouble()
    private var lastCheck = System.nanoTime()
    private val mutex = Mutex()

    suspend fun await(units: Long) {
        if (permitsPerSecond == Long.MAX_VALUE) return
        mutex.withLock {
            val now = System.nanoTime()
            val elapsed = (now - lastCheck) / 1e9
            lastCheck = now
            allowance += elapsed * permitsPerSecond
            if (allowance > permitsPerSecond) allowance = permitsPerSecond.toDouble()
            if (allowance < units) {
                val deficit = units - allowance
                val waitMs = (deficit / permitsPerSecond * 1000).toLong()
                allowance = 0.0
                kotlinx.coroutines.delay(waitMs.coerceAtLeast(1))
            } else {
                allowance -= units
            }
        }
    }
}

/**
 * Adaptive connection advisor: suggests the best segment count from measured throughput
 * and server behavior (spec §7.1 "يتكيف العدد تلقائيًا").
 */
@Singleton
class SpeedAdvisor @Inject constructor() {
    fun suggestConnections(speedBytesPerSec: Double, supportsRanges: Boolean): Int {
        if (!supportsRanges) return 1
        return when {
            speedBytesPerSec <= 0 -> 16                 // unknown yet — balanced start
            speedBytesPerSec < 512 * 1024 -> 8          // slow link
            speedBytesPerSec < 4 * 1024 * 1024 -> 16
            speedBytesPerSec < 20 * 1024 * 1024 -> 24
            else -> 32                                  // very fast link, use everything
        }
    }
}
