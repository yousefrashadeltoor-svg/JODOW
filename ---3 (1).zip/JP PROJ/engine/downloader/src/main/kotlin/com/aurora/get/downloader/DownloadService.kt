package com.aurora.get.downloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.aurora.get.common.Bytes
import com.aurora.get.db.DownloadDao
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Foreground service (type = dataSync) driving the queue.
 * Rich grouped notifications: per-download progress with Pause/Resume/Cancel actions,
 * plus a combined summary with aggregate speed.
 */
@AndroidEntryPoint
class DownloadService : Service() {

    @Inject lateinit var queue: DownloadQueue
    @Inject lateinit var downloads: DownloadDao

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    companion object {
        const val CHANNEL_ID = "aurora_downloads"
        const val GROUP_KEY = "aurora_group"
        const val ACTION_PAUSE = "com.aurora.get.action.PAUSE"
        const val ACTION_RESUME = "com.aurora.get.action.RESUME"
        const val ACTION_CANCEL = "com.aurora.get.action.CANCEL"
        const val EXTRA_ID = "download_id"
        private const val SUMMARY_ID = 9001
        const val FOREGROUND_ID = 9000

        fun start(context: Context) {
            val i = Intent(context, DownloadService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
    }

    private val nm by lazy { getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val n = baseNotification().setContentTitle(getStringSafe("Downloads running")).build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(FOREGROUND_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(FOREGROUND_ID, n)
        }
        observe()
    }

    private fun getStringSafe(s: String) = s // strings live in :app resources; service is UI-free

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra(EXTRA_ID)
        when (intent?.action) {
            ACTION_PAUSE -> id?.let { queue.pause(it) }
            ACTION_RESUME -> id?.let { queue.resume(it) }
            ACTION_CANCEL -> id?.let { scope.launch { queue.cancel(it) } }
        }
        return START_STICKY
    }

    private fun observe() {
        scope.launch {
            queue.running.collectLatest { map ->
                map.forEach { (id, p) -> renderProgress(id, p) }
                renderSummary(map)
                if (map.isEmpty()) stopSelf()
            }
        }
    }

    private fun renderProgress(id: String, p: SegmentedDownloader.Progress) {
        val title = id.take(12) // replaced with fileName from DB in the real binding
        val progressPercent = if (p.total > 0) (p.downloaded * 100 / p.total).toInt() else 0
        val text = buildString {
            append("${Bytes.format(p.downloaded)} / ${if (p.total > 0) Bytes.format(p.total) else "—"}")
            append("  ·  ${Bytes.speed(p.speedBytesPerSec)}")
            append("  ·  ${Bytes.eta(p.total - p.downloaded, p.speedBytesPerSec)}")
            if (p.activeConnections > 0) append("  ·  ${p.activeConnections}⚡")
        }
        val notification = baseNotification()
            .setContentTitle(title)
            .setContentText(text)
            .setGroup(GROUP_KEY)
            .setProgress(100, progressPercent, p.total <= 0)
            .addAction(0, "Pause", pendingAction(ACTION_PAUSE, id))
            .addAction(0, "Cancel", pendingAction(ACTION_CANCEL, id))
            .setOngoing(true)
            .build()
        nm.notify(id.hashCode(), notification)
    }

    private fun renderSummary(map: Map<String, SegmentedDownloader.Progress>) {
        if (map.isEmpty()) { nm.cancel(SUMMARY_ID); return }
        val totalSpeed = map.values.sumOf { it.speedBytesPerSec }
        val summary = baseNotification()
            .setContentTitle("Aurora Get")
            .setContentText("${map.size} downloads · ${Bytes.speed(totalSpeed)}")
            .setGroup(GROUP_KEY)
            .setGroupSummary(true)
            .build()
        nm.notify(SUMMARY_ID, summary)
    }

    private fun pendingAction(action: String, id: String): PendingIntent {
        val intent = Intent(this, DownloadService::class.java)
            .setAction(action).putExtra(EXTRA_ID, id)
        return PendingIntent.getService(
            this, (action + id).hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun baseNotification(): NotificationCompat.Builder =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setPriority(NotificationCompat.PRIORITY_LOW)

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Downloads", NotificationManager.IMPORTANCE_LOW,
        ).apply { description = "Active downloads"; setShowBadge(true) }
        nm.createNotificationChannel(channel)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        // Nothing is lost — Room already has the exact segment offsets; resume on restart.
    }
}
