package com.aurora.get.extractors.ytdlp

import android.content.Context
import com.aurora.get.common.MediaKind
import com.aurora.get.common.SizeInfo
import com.aurora.get.extractors.model.EngineKind
import com.aurora.get.extractors.model.ExtractedMedia
import com.aurora.get.extractors.model.FormatOption
import com.aurora.get.extractors.model.PlaylistEntry
import com.aurora.get.extractors.model.SubtitleTrack
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.mapper.VideoFormat
import com.yausername.youtubedl_android.mapper.VideoInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * yt-dlp full-extraction path (Stage 3 — up to 4s). Supports 1800+ sites.
 * aria2c is registered as the external downloader with -x16 -s16 -k1M for raw speed
 * (spec §7.1); our own segmented engine takes over whenever it wins.
 */
@Singleton
class YtDlpExtractor @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val initMutex = Mutex()
    private var ready = false

    private suspend fun ensureInit() = initMutex.withLock {
        if (ready) return
        withContext(Dispatchers.IO) {
            YoutubeDL.getInstance().init(context)
            // FFmpeg ships with the same artifact set; aria2c binary registers by option.
            com.yausername.ffmpeg.FFmpeg.getInstance().init(context)
            runCatching { com.yausername.aria2c.Aria2c.getInstance().init(context) }
                // VERIFY: youtubedl-android exposes Aria2c init similarly; package name may differ.
            ready = true
        }
    }

    /** Background auto-update of yt-dlp (called on app start + from Settings). */
    suspend fun updateEngine(): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            ensureInit()
            YoutubeDL.getInstance().updateYoutubeDL(
                context,
                com.yausername.youtubedl_android.YoutubeDL.UpdateChannel.STABLE,
            )
        }.onFailure { Timber.w(it, "yt-dlp update failed") }.isSuccess
    }

    suspend fun extract(url: String, cookies: Map<String, String> = emptyMap()): ExtractedMedia =
        withContext(Dispatchers.IO) {
            ensureInit()
            val request = YoutubeDLRequest(url).apply {
                addOption("--no-playlist")
                addOption("--socket-timeout", "12")
                addOption("--no-check-certificates")
                // cookies as Netscape file would be ideal; header passthrough keeps it simple.
                if (cookies.isNotEmpty()) {
                    val header = cookies.entries.joinToString("; ") { "${it.key}=${it.value}" }
                    addOption("--add-headers", "Cookie:$header")
                }
            }
            val info: VideoInfo = YoutubeDL.getInstance().getInfo(request)
            info.toExtractedMedia(url)
        }

    /** Executes a download through aria2c (when our engine isn't already handling it). */
    fun aria2cRequest(url: String, outputDir: String, headers: Map<String, String>): YoutubeDLRequest =
        YoutubeDLRequest(url).apply {
            addOption("--downloader", "aria2c")
            addOption("--downloader-args", "aria2c:-x16 -s16 -k1M --file-allocation=none")
            addOption("-P", outputDir)
            headers.forEach { (k, v) -> addOption("--add-headers", "$k:$v") }
        }

    // ───────────────────────── mapping ─────────────────────────

    private fun VideoInfo.toExtractedMedia(sourceUrl: String): ExtractedMedia {
        val formats = formats.orEmpty().map { it.toOption() }
        val videoFormats = formats.filter { it.kind == MediaKind.VIDEO }
        val bestAudio = formats.filter { it.kind == MediaKind.AUDIO }
            .maxByOrNull { it.bitrateKbps }

        // DASH video-only formats become merge candidates with best audio
        val merged = videoFormats.map { v ->
            if (!v.hasAudio && bestAudio != null) {
                v.copy(
                    needsMerge = true,
                    mergeAudioId = bestAudio.id,
                    size = combineSizes(v.size, bestAudio.size),
                )
            } else v
        }

        // Subtitles are resolved by the caller through yt-dlp's own JSON dump when needed;
        // the mapper types differ across versions, so this stays empty instead of guessing.
        val subs: List<SubtitleTrack> = emptyList()

        return ExtractedMedia(
            sourceUrl = sourceUrl,
            resolvedUrl = webpageUrl ?: sourceUrl,
            domain = runCatching { java.net.URI(webpageUrl ?: sourceUrl).host.orEmpty() }.getOrDefault(""),
            siteName = extractor ?: extractorKey ?: "",
            title = title.orEmpty(),
            description = description,
            thumbnailUrl = thumbnail,
            previewUrl = url,
            kind = if (merged.isNotEmpty()) MediaKind.VIDEO else MediaKind.AUDIO,
            durationSec = duration ?: 0,
            uploader = uploader ?: channel,
            uploadDate = uploadDate,
            formats = merged + formats.filter { it.kind == MediaKind.AUDIO },
            subtitles = subs,
            isPlaylist = false,
            playlistEntries = emptyList(),
            engineUsed = EngineKind.YTDLP,
        )
    }

    private fun VideoFormat.toOption(): FormatOption {
        val vcodec = vcodec?.takeIf { it != "none" }
        val acodecValue = acodec?.takeIf { it != "none" }
        val isVideoOnly = vcodec != null && acodecValue == null
        val isAudioOnly = vcodec == null && acodecValue != null
        val kind = when {
            isAudioOnly -> MediaKind.AUDIO
            vcodec != null -> MediaKind.VIDEO
            else -> MediaKind.FILE
        }
        val size = when {
            fileSize > 0 -> FormatOption.sizeExact(fileSize)               // confirmed
            fileSizeApproximate > 0 -> FormatOption.sizeApprox(fileSizeApproximate) // ≈ only
            else -> null
        }
        return FormatOption(
            id = formatId ?: ext.orEmpty(),
            kind = kind,
            label = labelFor(this, kind),
            container = ext ?: "bin",
            codec = vcodec ?: acodecValue,
            width = width, height = height,
            fps = fps.toInt(), bitrateKbps = (tbr ?: abr).toInt(),
            url = url,
            size = size,
            hasAudio = !isVideoOnly,
            qualityRank = (height * 10_000) + fps.toInt(),
        )
    }

    private fun labelFor(f: VideoFormat, kind: MediaKind): String = when (kind) {
        MediaKind.VIDEO -> buildString {
            append(if (f.height > 0) "${f.height}p" else (f.formatNote ?: f.formatId.orEmpty()))
            if (f.fps > 30) append("${f.fps.toInt()}")
        }
        MediaKind.AUDIO -> buildString {
            append(f.ext?.uppercase() ?: "AUDIO")
            val br = (f.abr ?: f.tbr).toInt()
            if (br > 0) append(" ${br}k")
        }
        else -> f.ext?.uppercase() ?: "FILE"
    }

    /** Size of a merge = video + audio exact parts; ≈ if any side is approximate. */
    private fun combineSizes(a: SizeInfo?, b: SizeInfo?): SizeInfo? {
        if (a == null && b == null) return null
        val bytes = (a?.bytes ?: 0) + (b?.bytes ?: 0)
        val approx = (a?.isApproximate ?: true) || (b?.isApproximate ?: true)
        return SizeInfo(bytes, approx)
    }
}
