package com.aurora.get.extractors.model

import com.aurora.get.common.MediaKind
import com.aurora.get.common.SizeInfo
import kotlinx.serialization.Serializable

/** One downloadable variant shown in a smart-button sheet. */
@Serializable
data class FormatOption(
    val id: String,
    val kind: MediaKind,
    val label: String,              // "1080p60" / "Opus 128k" / "2048px"
    val container: String,          // mp4 / webm / m4a / jpg / srt...
    val codec: String? = null,      // avc1 / vp9 / av01 / opus / aac
    val width: Int = 0,
    val height: Int = 0,
    val fps: Int = 0,
    val bitrateKbps: Int = 0,
    val url: String? = null,        // direct URL if already known
    val size: SizeInfo? = null,     // exact vs approximate enforced by type
    val hasAudio: Boolean = true,
    val needsMerge: Boolean = false,      // DASH video-only → merge with best audio
    val mergeAudioId: String? = null,
    val isWatermarkFree: Boolean? = null, // TikTok-style flag
    val qualityRank: Int = 0,
) {
    companion object {
        fun sizeExact(b: Long) = SizeInfo.exact(b)
        fun sizeApprox(b: Long) = SizeInfo.approx(b)
    }
}

@Serializable
data class SubtitleTrack(
    val lang: String,
    val ext: String,                // srt / vtt / ass
    val url: String,
)

/** Everything the analyzer has learned about a link — arrives progressively per stage. */
data class ExtractedMedia(
    val sourceUrl: String,
    val resolvedUrl: String? = null,
    val domain: String = "",
    val siteName: String = "",
    val faviconUrl: String? = null,       // apple-touch-icon → manifest → og:logo → favicon service
    val title: String = "",
    val originalFileName: String? = null, // editable before download
    val description: String? = null,
    val thumbnailUrl: String? = null,
    val previewUrl: String? = null,       // playable preview stream (Media3)
    val kind: MediaKind = MediaKind.FILE,
    val durationSec: Int = 0,
    val uploader: String? = null,
    val uploadDate: String? = null,
    val formats: List<FormatOption> = emptyList(),
    val subtitles: List<SubtitleTrack> = emptyList(),
    val isPlaylist: Boolean = false,
    val playlistEntries: List<PlaylistEntry> = emptyList(),
    val requiredHeaders: Map<String, String> = emptyMap(),
    val engineUsed: EngineKind = EngineKind.DIRECT,
)

data class PlaylistEntry(
    val id: String,
    val title: String,
    val thumbnailUrl: String?,
    val durationSec: Int,
    val selected: Boolean = true,
)

enum class EngineKind { DIRECT, NATIVE_FAST_PATH, YTDLP, SNIFFER }

/** What the four smart buttons should show: only non-empty groups become buttons. */
data class SmartButtons(
    val audio: List<FormatOption>,
    val images: List<FormatOption>,
    val video: List<FormatOption>,
    val files: List<FormatOption>,
) {
    val anyVisible: Boolean
        get() = audio.isNotEmpty() || images.isNotEmpty() || video.isNotEmpty() || files.isNotEmpty()

    fun forKind(kind: MediaKind): List<FormatOption> = when (kind) {
        MediaKind.AUDIO -> audio
        MediaKind.IMAGE -> images
        MediaKind.VIDEO -> video
        MediaKind.FILE -> files
    }

    companion object {
        fun fromFormats(formats: List<FormatOption>, extras: List<FormatOption> = emptyList()): SmartButtons {
            val all = formats + extras
            return SmartButtons(
                audio = all.filter { it.kind == MediaKind.AUDIO }.sortedByDescending { it.bitrateKbps },
                images = all.filter { it.kind == MediaKind.IMAGE }.sortedByDescending { it.width },
                video = all.filter { it.kind == MediaKind.VIDEO }.sortedByDescending { it.height * 10_000 + it.fps },
                files = all.filter { it.kind == MediaKind.FILE },
            )
        }
    }
}
