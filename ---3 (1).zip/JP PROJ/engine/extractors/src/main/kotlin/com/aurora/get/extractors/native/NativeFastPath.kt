package com.aurora.get.extractors.extractors_native

import com.aurora.get.common.MediaKind
import com.aurora.get.common.SizeInfo
import com.aurora.get.extractors.model.EngineKind
import com.aurora.get.extractors.model.ExtractedMedia
import com.aurora.get.extractors.model.FormatOption
import com.aurora.get.extractors.model.SmartButtons
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Native fast-path extractors (Stage 2 — < 1.5s on popular sites).
 * These use official oEmbed endpoints / OpenGraph metadata only — fast and honest.
 * Heavy lifting (every quality/codec) still lands via yt-dlp in Stage 3.
 */
@Singleton
class NativeFastPath @Inject constructor(
    private val client: OkHttpClient,
    private val json: Json,
) {
    /** Returns domain → whether we have a fast path for it. */
    fun supports(domain: String): Boolean = FAST_DOMAINS.any { domain.endsWith(it) }

    suspend fun extract(url: String, domain: String): ExtractedMedia? = withContext(Dispatchers.IO) {
        when {
            domain.contains("youtube.com") || domain.contains("youtu.be") -> youtube(url)
            domain.contains("tiktok.com") -> tiktok(url)
            domain.contains("soundcloud.com") -> oEmbed(url, "soundcloud", MediaKind.AUDIO)
            domain.contains("vimeo.com") -> oEmbed(url, "vimeo", MediaKind.VIDEO)
            domain.contains("twitter.com") || domain.contains("x.com") -> twitter(url)
            domain.contains("reddit.com") -> oEmbed(url, "reddit", MediaKind.VIDEO)
            domain.contains("pinterest.") -> pinterest(url)
            else -> openGraph(url, domain)
        }
    }

    // ── YouTube: oEmbed (official) + thumbnail ladder (maxres..default) ──
    private suspend fun youtube(url: String): ExtractedMedia? = runCatching {
        val id = videoId(url) ?: return null
        val oembed = "https://www.youtube.com/oembed?url=$url&format=json"
        val body = get(oembed) ?: return null
        val obj = json.parseToJsonElement(body).jsonObject
        val title = obj["title"]?.jsonPrimitive?.content ?: ""
        val author = obj["author_name"]?.jsonPrimitive?.content

        val thumbs = listOf(
            "maxresdefault" to 1280, "sddefault" to 640,
            "hqdefault" to 480, "mqdefault" to 320, "default" to 120,
        ).map { (name, w) ->
            FormatOption(
                id = "yt_thumb_$name", kind = MediaKind.IMAGE, label = "${w}px JPG",
                container = "jpg", width = w,
                url = "https://i.ytimg.com/vi/$id/$name.jpg",
                qualityRank = w,
            )
        }

        ExtractedMedia(
            sourceUrl = url,
            resolvedUrl = url,
            domain = "youtube.com",
            siteName = "YouTube",
            faviconUrl = "https://www.youtube.com/s/desktop/favicon.ico",
            title = title,
            uploader = author,
            thumbnailUrl = "https://i.ytimg.com/vi/$id/hqdefault.jpg",
            kind = MediaKind.VIDEO,
            formats = thumbs,
            engineUsed = EngineKind.NATIVE_FAST_PATH,
        )
    }.onFailure { Timber.v("YouTube fast path: ${it.message}") }.getOrNull()

    private fun videoId(url: String): String? {
        Regex("(?:v=|youtu\\.be/|shorts/)([A-Za-z0-9_-]{11})").find(url)?.let { return it.groupValues[1] }
        return null
    }

    // ── TikTok: oEmbed (official). Watermark-free variants resolve in Stage 3 via yt-dlp ──
    private suspend fun tiktok(url: String): ExtractedMedia? = runCatching {
        val body = get("https://www.tiktok.com/oembed?url=$url") ?: return null
        val obj = json.parseToJsonElement(body).jsonObject
        ExtractedMedia(
            sourceUrl = url,
            resolvedUrl = url,
            domain = "tiktok.com",
            siteName = "TikTok",
            faviconUrl = "https://www.tiktok.com/favicon.ico",
            title = obj["title"]?.jsonPrimitive?.content ?: "",
            uploader = obj["author_name"]?.jsonPrimitive?.content,
            thumbnailUrl = obj["thumbnail_url"]?.jsonPrimitive?.content,
            kind = MediaKind.VIDEO,
            engineUsed = EngineKind.NATIVE_FAST_PATH,
        )
    }.getOrNull()

    // ── Twitter/X: publish.twitter.com oEmbed (official) ──
    private suspend fun twitter(url: String): ExtractedMedia? = runCatching {
        val body = get("https://publish.twitter.com/oembed?url=$url") ?: return null
        val obj = json.parseToJsonElement(body).jsonObject
        val html = obj["html"]?.jsonPrimitive?.content.orEmpty()
        val text = Jsoup.parse(html).text()
        ExtractedMedia(
            sourceUrl = url, resolvedUrl = url,
            domain = "x.com", siteName = "X",
            title = text.take(140),
            kind = MediaKind.VIDEO,
            engineUsed = EngineKind.NATIVE_FAST_PATH,
        )
    }.getOrNull()

    // ── Pinterest / generic OpenGraph reader ──
    private suspend fun pinterest(url: String): ExtractedMedia? = openGraph(url, "pinterest.com")

    suspend fun openGraph(url: String, domain: String): ExtractedMedia? = runCatching {
        val html = get(url) ?: return null
        val doc = Jsoup.parse(html)
        fun prop(name: String) = doc.selectFirst("meta[property=og:$name]")?.attr("content")

        val ogImage = prop("image")
        val ogVideo = prop("video") ?: prop("video:url")
        val ogAudio = prop("audio")
        val kind = when {
            ogVideo != null -> MediaKind.VIDEO
            ogAudio != null -> MediaKind.AUDIO
            ogImage != null -> MediaKind.IMAGE
            else -> MediaKind.FILE
        }
        val extras = buildList {
            ogVideo?.let { v ->
                add(FormatOption("og_video", MediaKind.VIDEO, "فيديو الصفحة", "mp4", url = v))
            }
            ogAudio?.let { a ->
                add(FormatOption("og_audio", MediaKind.AUDIO, "صوت الصفحة", "mp3", url = a))
            }
            ogImage?.let { i ->
                add(FormatOption("og_image", MediaKind.IMAGE, "صورة بارزة", "jpg", url = i))
            }
        }
        ExtractedMedia(
            sourceUrl = url,
            resolvedUrl = url,
            domain = domain,
            siteName = prop("site_name") ?: domain,
            faviconUrl = doc.selectFirst("link[rel~=icon]")?.absUrl("href"),
            title = prop("title") ?: doc.title(),
            description = prop("description"),
            thumbnailUrl = ogImage,
            kind = kind,
            formats = extras,
            engineUsed = EngineKind.NATIVE_FAST_PATH,
        )
    }.getOrNull()

    private suspend fun oEmbed(url: String, provider: String, kind: MediaKind): ExtractedMedia? =
        openGraph(url, provider)?.copy(kind = kind)

    private fun get(url: String): String? = runCatching {
        val req = Request.Builder().url(url)
            .header("User-Agent", DESKTOP_UA)
            .build()
        client.newCall(req).execute().use { res ->
            if (res.isSuccessful) res.body.string() else null
        }
    }.onFailure { Timber.v("fast-path GET failed: $url") }.getOrNull()

    companion object {
        private const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"

        private val FAST_DOMAINS = listOf(
            "youtube.com", "youtu.be", "tiktok.com", "instagram.com", "facebook.com",
            "twitter.com", "x.com", "reddit.com", "pinterest.com", "vimeo.com",
            "soundcloud.com", "twitch.tv", "dailymotion.com", "t.me", "bilibili.com",
        )
    }
}
