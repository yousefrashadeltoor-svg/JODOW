// Aurora Get — root build file
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.android.library) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.kotlin.serialization) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.hilt) apply false
}

subprojects {
    // Global guardrail: fail the build if any Material artifact sneaks in as a transitive dep.
    configurations.all {
        resolutionStrategy {
            eachDependency {
                val g = requested.group
                val n = requested.name
                if (g.startsWith("androidx.compose.material") ||
                    g.startsWith("com.google.android.material") ||
                    (g == "androidx.compose.material3")
                ) {
                    throw GradleException(
                        "Material dependency is forbidden in Aurora Get: $g:$n. " +
                            "Use the custom Aurora design system instead."
                    )
                }
            }
        }
    }
}
