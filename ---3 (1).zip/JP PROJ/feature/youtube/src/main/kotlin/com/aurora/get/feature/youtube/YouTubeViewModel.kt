package com.aurora.get.feature.youtube

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.common.MediaKind
import com.aurora.get.db.DownloadDao
import com.aurora.get.db.DownloadEntity
import com.aurora.get.downloader.DownloadQueue
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

/**
 * Drives the fully-local YouTube experience: real network reads (search/trending/RSS),
 * infinite personalized feed, local profile (follows/history/saved), and hand-off to the
 * download engine + Media3 player. No Google sign-in, no backend, no database server.
 */
@HiltViewModel
class YouTubeViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repo: YouTubeRepository,
    private val downloads: DownloadDao,
    private val queue: DownloadQueue,
) : ViewModel() {

    enum class Tab(val label: String) { HOME("الرئيسية"), SHORTS("شورتس"), SUBS("اشتراكات") }

    data class UiState(
        val tab: Tab = Tab.HOME,
        val feed: List<VideoItem> = emptyList(),
        val shorts: List<VideoItem> = emptyList(),
        val profile: LocalProfile = LocalProfile(),
        val loading: Boolean = false,
        val loadingMore: Boolean = false,
        val query: String = "",
        val suggestions: List<String> = emptyList(),
        val searchResults: List<VideoItem> = emptyList(),
        val searching: Boolean = false,
        val activeWatch: YouTubeRepository.WatchPage? = null,
        val stream: YouTubeRepository.StreamInfo? = null,
        val resolvingStream: Boolean = false,
        val message: String? = null,
        val showProfile: Boolean = false,
        val showSearch: Boolean = false,
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state
    private var page = 0

    init {
        viewModelScope.launch {
            repo.profileFlow.collect { p -> _state.update { it.copy(profile = p) } }
        }
        refresh()
    }

    fun setTab(tab: Tab) {
        _state.update { it.copy(tab = tab) }
        if (tab == Tab.SHORTS && _state.value.shorts.isEmpty()) loadShorts()
        if (tab == Tab.SUBS && _state.value.feed.isEmpty()) refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val profile = _state.value.profile
            val feed = repo.recommendations(profile).ifEmpty { repo.trending() }
            page = 1
            _state.update { it.copy(feed = feed, loading = false) }
        }
    }

    /** Infinite suggestions: next personalized batch keeps appending. */
    fun loadMore() {
        if (_state.value.loadingMore || _state.value.loading) return
        viewModelScope.launch {
            _state.update { it.copy(loadingMore = true) }
            val p = _state.value.profile
            val seeds = p.interests.entries.sortedByDescending { it.value }.map { it.key }
                .ifEmpty { listOf("موسيقى", "تقنية", "سفر", "ألعاب") }
            val seed = seeds[page % seeds.size]
            val next = repo.search(seed).ifEmpty { repo.trending().shuffled().take(10) }
            page += 1
            _state.update { s ->
                val merged = (s.feed + next).distinctBy { it.id }
                s.copy(feed = merged, loadingMore = false)
            }
        }
    }

    fun loadShorts() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val list = repo.shorts()
            _state.update { it.copy(shorts = list, loading = false) }
        }
    }

    // ── Search ──
    fun openSearch() = _state.update { it.copy(showSearch = true) }

    fun closeSearch() = _state.update {
        it.copy(showSearch = false, query = "", suggestions = emptyList(), searchResults = emptyList())
    }

    fun onQueryChange(q: String) {
        _state.update { it.copy(query = q) }
        viewModelScope.launch {
            val s = if (q.length >= 2) repo.suggestions(q) else emptyList()
            _state.update { it.copy(suggestions = s) }
        }
    }

    fun submitSearch(q: String = _state.value.query) {
        if (q.isBlank()) return
        viewModelScope.launch {
            _state.update { it.copy(searching = true, query = q) }
            val results = repo.search(q)
            val current = _state.value.profile
            val interests = current.interests.toMutableMap()
            q.split(" ").filter { it.length > 2 }.forEach { interests[it] = (interests[it] ?: 0) + 1 }
            persist(current.copy(interests = interests))
            _state.update { it.copy(searchResults = results, searching = false) }
        }
    }

    // ── Watch ──
    fun openVideo(video: VideoItem) {
        viewModelScope.launch {
            _state.update {
                it.copy(
                    activeWatch = YouTubeRepository.WatchPage(video),
                    resolvingStream = true, stream = null, showSearch = false,
                )
            }
            val pageData = repo.watchPage(video.id)
            _state.update { it.copy(activeWatch = pageData ?: it.activeWatch) }

            val stream = repo.streamUrl("https://www.youtube.com/watch?v=${video.id}")
            _state.update { it.copy(stream = stream, resolvingStream = false) }

            recordHistory(video)
        }
    }

    fun closeVideo() = _state.update { it.copy(activeWatch = null, stream = null) }

    private suspend fun recordHistory(video: VideoItem) {
        val p = _state.value.profile
        val history = (listOf(video) + p.history).distinctBy { it.id }.take(200)
        val interests = p.interests.toMutableMap()
        val key = video.channel.ifBlank { video.title.take(20) }
        interests[key] = (interests[key] ?: 0) + 2
        persist(p.copy(history = history, interests = interests))
    }

    // ── Profile ──
    fun toggleProfile() = _state.update { it.copy(showProfile = !it.showProfile) }

    fun renameProfile(name: String) = persist(_state.value.profile.copy(displayName = name))

    fun follow(channel: ChannelItem) {
        val p = _state.value.profile
        if (p.follows.any { it.id == channel.id && it.name == channel.name }) {
            persist(p.copy(follows = p.follows.filterNot { it.name == channel.name }))
            toast("أُلغي المتابعة: ${channel.name}")
        } else {
            persist(p.copy(follows = p.follows + channel))
            toast("تتابع الآن: ${channel.name}")
        }
    }

    fun followByHandle(handle: String) {
        viewModelScope.launch {
            val ch = repo.resolveChannel(handle)
            if (ch == null) toast("لم يُعثر على القناة") else follow(ch)
        }
    }

    fun unfollow(name: String) = persist(
        _state.value.profile.copy(follows = _state.value.profile.follows.filterNot { it.name == name })
    )

    fun toggleSave(video: VideoItem) {
        val p = _state.value.profile
        val saved = if (p.saved.any { it.id == video.id }) p.saved.filterNot { it.id == video.id }
        else p.saved + video
        persist(p.copy(saved = saved))
    }

    private fun persist(p: LocalProfile) {
        _state.update { it.copy(profile = p) }
        viewModelScope.launch { repo.saveProfile(p) }
    }

    // ── Export / Import (file text passed by the UI through SAF) ──
    fun exportProfile(): String = repo.exportJson(_state.value.profile)

    fun importProfile(raw: String) {
        val p = repo.importJson(raw)
        if (p == null) toast("ملف غير صالح") else {
            persist(p.copy(createdAt = System.currentTimeMillis()))
            toast("تم استيراد الملف الشخصي")
        }
    }

    // ── Actions ──
    fun copyLink(video: VideoItem) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val url = "https://youtu.be/${video.id}"
        cm.setPrimaryClip(ClipData.newPlainText("video", url))
        toast("نُسخ الرابط: $url")
    }

    fun download(video: VideoItem) {
        viewModelScope.launch {
            val direct = _state.value.stream?.takeIf { it.videoMatches(video) }
            val entity = DownloadEntity(
                id = UUID.randomUUID().toString(),
                url = "https://www.youtube.com/watch?v=${video.id}",
                directUrl = direct?.url,
                fileName = video.title.replace(Regex("[\\\\/:*?\"<>|]"), "-").take(60) + ".mp4",
                destDir = "Movies/JO DON",
                kind = MediaKind.VIDEO,
                totalBytes = -1,
                siteDomain = "youtube.com",
                headersJson = direct?.headers?.let {
                    kotlinx.serialization.json.Json.encodeToString(it)
                },
            )
            downloads.upsert(entity)
            queue.enqueue(entity)
            toast("أُضيف للتحميل: ${video.title.take(32)}")
        }
    }

    fun downloadAudio(video: VideoItem) {
        viewModelScope.launch {
            val entity = DownloadEntity(
                id = UUID.randomUUID().toString(),
                url = "https://www.youtube.com/watch?v=${video.id}",
                fileName = video.title.replace(Regex("[\\\\/:*?\"<>|]"), "-").take(60) + ".m4a",
                destDir = "Music/JO DON",
                kind = MediaKind.AUDIO,
                siteDomain = "youtube.com",
            )
            downloads.upsert(entity)
            queue.enqueue(entity)
            toast("تنزيل صوتي بدأ")
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null) }

    private fun toast(msg: String) = _state.update { it.copy(message = msg) }

    private fun YouTubeRepository.StreamInfo.videoMatches(v: VideoItem) =
        url.contains(v.id) || title.isNotBlank()
}
