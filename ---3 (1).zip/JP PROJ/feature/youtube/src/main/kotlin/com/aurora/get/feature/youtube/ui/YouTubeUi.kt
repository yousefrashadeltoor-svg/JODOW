package com.aurora.get.feature.youtube.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import com.aurora.get.designsystem.components.AuroraGlassButton
import com.aurora.get.designsystem.components.AuroraIcon
import com.aurora.get.designsystem.components.GlassBottomSheet
import com.aurora.get.designsystem.components.GradientText
import com.aurora.get.designsystem.components.pressableScale
import com.aurora.get.designsystem.glass.GlassChip
import com.aurora.get.designsystem.glass.GlassPanel
import com.aurora.get.designsystem.glass.rememberGlassBackgroundState
import com.aurora.get.designsystem.icons.AuroraIcons
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import com.aurora.get.designsystem.theme.LocalAuroraTypography
import com.aurora.get.feature.youtube.ChannelItem
import com.aurora.get.feature.youtube.VideoItem
import com.aurora.get.feature.youtube.YouTubeViewModel
import dev.chrisbanes.haze.hazeSource

/**
 * JO DON · YouTube — built-in, native-feeling surface with its own local identity.
 * Real network reads only where required (feeds/search/watch); everything else is local.
 */
@Composable
fun YouTubeScreen(viewModel: YouTubeViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val haze = rememberGlassBackgroundState()
    val listState = rememberLazyListState()

    // Infinite personalized feed: prefetch when near the end.
    LaunchedEffect(listState, state.feed.size) {
        val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
        if (lastVisible >= state.feed.size - 3 && state.feed.isNotEmpty()) viewModel.loadMore()
    }

    Box(Modifier.fillMaxSize()) {
        com.aurora.get.designsystem.effects.MeshGradientBackground(Modifier.matchParentSize().hazeSource(state = haze))

        Column(Modifier.fillMaxSize()) {
            YouTubeTopBar(
                onSearch = viewModel::openSearch,
                onAccount = viewModel::toggleProfile,
                profileName = state.profile.displayName,
            )
            TabsRow(selected = state.tab, onSelect = viewModel::setTab)

            when (state.tab) {
                YouTubeViewModel.Tab.HOME -> FeedList(
                    state.feed, state.loading, state.loadingMore,
                    onOpen = viewModel::openVideo,
                    onDownload = viewModel::download,
                    onCopy = viewModel::copyLink,
                    onSave = viewModel::toggleSave,
                    savedIds = state.profile.saved.map { it.id }.toSet(),
                    haze = haze,
                )
                YouTubeViewModel.Tab.SHORTS -> ShortsList(state.shorts, viewModel)
                YouTubeViewModel.Tab.SUBS -> FeedList(
                    state.feed.filter { v ->
                        state.profile.follows.any { f -> f.name == v.channel || f.id == v.channelId }
                    }.ifEmpty { state.feed },
                    state.loading, false,
                    onOpen = viewModel::openVideo,
                    onDownload = viewModel::download,
                    onCopy = viewModel::copyLink,
                    onSave = viewModel::toggleSave,
                    savedIds = state.profile.saved.map { it.id }.toSet(),
                    haze = haze,
                )
            }
        }

        if (state.showProfile) {
            GlassBottomSheet(visible = true, onDismiss = viewModel::toggleProfile, hazeState = haze) {
                LocalProfileSheet(
                    state = state,
                    onRename = viewModel::renameProfile,
                    onFollow = viewModel::followByHandle,
                    onUnfollow = viewModel::unfollow,
                    onExport = viewModel::exportProfile,
                    onImport = viewModel::importProfile,
                    onOpen = { v -> viewModel.closeVideo(); viewModel.openVideo(v) },
                )
            }
        }

        if (state.showSearch) {
            SearchSheet(state, viewModel)
        }

        state.activeWatch?.let { page ->
            WatchOverlay(page, state, viewModel)
        }

        state.message?.let { msg ->
            LaunchedEffect(msg) {
                kotlinx.coroutines.delay(2600)
                viewModel.clearMessage()
            }
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 96.dp),
            ) {
                GlassChip {
                    BasicText(
                        msg, Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        style = t.labelLarge.copy(color = c.textPrimary),
                    )
                }
            }
        }
    }
}

// ───────────────────────── Chrome ─────────────────────────

@Composable
private fun YouTubeTopBar(onSearch: () -> Unit, onAccount: () -> Unit, profileName: String) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // JO DON logo mark with a YouTube-red play glyph
        Box(
            Modifier.size(34.dp).background(c.brandGradient, LocalAuroraShapes.current.small),
            contentAlignment = Alignment.Center,
        ) {
            AuroraIcon(AuroraIcons.Play, "JO DON", tint = Color.White, modifier = Modifier.size(16.dp))
        }
        Spacer(Modifier.width(8.dp))
        BasicText("JO DON", style = t.titleLarge.copy(color = c.textPrimary, fontSize = 17.sp))
        Spacer(Modifier.weight(1f))
        IconAction(AuroraIcons.Search, "بحث", onSearch)
        Spacer(Modifier.width(6.dp))
        IconAction(AuroraIcons.Files, "الاشتراكات والملف") { }
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier.size(32.dp).background(c.brandPurple.copy(alpha = 0.35f), LocalAuroraShapes.current.full)
                .pressableScale(onAccount),
            contentAlignment = Alignment.Center,
        ) {
            BasicText(
                profileName.take(1),
                style = t.labelLarge.copy(color = c.textPrimary, fontSize = 13.sp),
            )
        }
    }
}

@Composable
private fun TabsRow(selected: YouTubeViewModel.Tab, onSelect: (YouTubeViewModel.Tab) -> Unit) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        YouTubeViewModel.Tab.entries.forEach { tab ->
            val active = tab == selected
            Box(
                Modifier
                    .pressableScale({ onSelect(tab) })
                    .background(
                        if (active) c.brandGradient else SolidColor(Color.White.copy(alpha = 0.06f)),
                        LocalAuroraShapes.current.full,
                    )
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                BasicText(
                    tab.label,
                    style = t.labelLarge.copy(color = if (active) c.onAccent else c.textSecondary),
                )
            }
        }
        Spacer(Modifier.weight(1f))
        GlassChip {
            BasicText(
                "محلي 100%", Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                style = t.labelMedium.copy(color = c.textTertiary),
            )
        }
    }
}

@Composable
private fun IconAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit,
) {
    Box(Modifier.size(34.dp).pressableScale(onClick), contentAlignment = Alignment.Center) {
        AuroraIcon(icon, label, tint = AuroraTheme.colors.textSecondary, modifier = Modifier.size(19.dp))
    }
}

// ───────────────────────── Feed ─────────────────────────

@Composable
private fun FeedList(
    feed: List<VideoItem>,
    loading: Boolean,
    loadingMore: Boolean,
    onOpen: (VideoItem) -> Unit,
    onDownload: (VideoItem) -> Unit,
    onCopy: (VideoItem) -> Unit,
    onSave: (VideoItem) -> Unit,
    savedIds: Set<String>,
    haze: dev.chrisbanes.haze.HazeState,
) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    if (loading && feed.isEmpty()) {
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(3) {
                GlassPanel(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.White.copy(0.06f)))
                        Spacer(Modifier.height(10.dp))
                        Box(Modifier.fillMaxWidth(0.8f).height(14.dp).background(Color.White.copy(0.07f)))
                    }
                }
            }
        }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 120.dp),
    ) {
        items(feed.size) { i ->
            val v = feed[i]
            Box(Modifier.padding(horizontal = 14.dp)) {
                VideoCard(
                    v,
                    isSaved = v.id in savedIds,
                    onOpen = { onOpen(v) },
                    onDownload = { onDownload(v) },
                    onCopy = { onCopy(v) },
                    onSave = { onSave(v) },
                )
            }
        }
        if (loadingMore) {
            item {
                Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                    com.aurora.get.designsystem.components.AuroraProgressRing(
                        progress = 0.6f, size = 28.dp, stroke = 3.dp,
                    )
                }
            }
        }
    }
}

@Composable
private fun VideoCard(
    v: VideoItem,
    isSaved: Boolean,
    onOpen: () -> Unit,
    onDownload: () -> Unit,
    onCopy: () -> Unit,
    onSave: () -> Unit,
) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    GlassPanel(glowColor = c.typeVideo.copy(alpha = 0.5f)) {
        Column(Modifier.fillMaxWidth()) {
            // thumbnail (tap → play)
            Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).pressableScale(onOpen)) {
                AsyncImage(
                    model = v.thumbnail, contentDescription = v.title,
                    modifier = Modifier.fillMaxSize().clip(LocalAuroraShapes.current.medium),
                )
                if (v.durationText.isNotBlank()) {
                    Box(
                        Modifier.align(Alignment.BottomEnd).padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.7f), LocalAuroraShapes.current.small)
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                    ) {
                        BasicText(v.durationText, style = t.labelMedium.copy(color = Color.White))
                    }
                }
                Box(
                    Modifier.align(Alignment.Center).size(44.dp)
                        .background(Color.Black.copy(alpha = 0.45f), LocalAuroraShapes.current.full),
                    contentAlignment = Alignment.Center,
                ) { AuroraIcon(AuroraIcons.Play, "تشغيل", tint = Color.White, modifier = Modifier.size(20.dp)) }
            }

            Column(Modifier.padding(12.dp)) {
                BasicText(
                    v.title, style = t.titleMedium.copy(color = c.textPrimary),
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(3.dp))
                BasicText(
                    listOf(v.channel, v.viewsText, v.publishedText).filter { it.isNotBlank() }.joinToString(" · "),
                    style = t.labelMedium.copy(color = c.textTertiary),
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(9.dp))

                // download button directly under each video (as requested) + quick actions
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AuroraGlassButton(onClick = onDownload) {
                        Row(
                            Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AuroraIcon(AuroraIcons.Download, "تحميل", tint = c.brandPurple, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(6.dp))
                            BasicText("تحميل", style = t.labelLarge.copy(color = c.textPrimary))
                        }
                    }
                    IconAction(AuroraIcons.Link, "نسخ الرابط", onCopy)
                    IconAction(
                        if (isSaved) AuroraIcons.Check else AuroraIcons.Sparkle,
                        "حفظ", onSave,
                    )
                    Spacer(Modifier.weight(1f))
                    GlassChip {
                        BasicText(
                            "قص · نغمة · تحويل", Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            style = t.labelMedium.copy(color = c.textSecondary),
                        )
                    }
                }
            }
        }
    }
}

// ───────────────────────── Shorts ─────────────────────────

@Composable
private fun ShortsList(shorts: List<VideoItem>, vm: YouTubeViewModel) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    if (shorts.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            GlassPanel {
                BasicText(
                    "جاري تحميل الشورتس…", Modifier.padding(24.dp),
                    style = t.bodyLarge.copy(color = c.textSecondary),
                )
            }
        }
        return
    }
    androidx.compose.foundation.pager.VerticalPager(
        state = androidx.compose.foundation.pager.rememberPagerState(pageCount = { shorts.size }),
        modifier = Modifier.fillMaxSize(),
    ) { page ->
        val v = shorts[page]
        Box(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 6.dp)) {
            AsyncImage(
                model = v.thumbnail, contentDescription = v.title,
                modifier = Modifier.fillMaxSize().clip(LocalAuroraShapes.current.large),
            )
            Box(
                Modifier.fillMaxSize().clip(LocalAuroraShapes.current.large)
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f)),
                        )
                    )
            )
            Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                BasicText(v.title, style = t.titleLarge.copy(color = Color.White), maxLines = 2)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AuroraGlassButton(onClick = { vm.download(v) }) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            AuroraIcon(AuroraIcons.Download, "تحميل", tint = Color.White, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(6.dp))
                            BasicText("تحميل", style = t.labelMedium.copy(color = Color.White))
                        }
                    }
                    AuroraGlassButton(onClick = { vm.copyLink(v) }) {
                        BasicText(
                            "نسخ الرابط", Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            style = t.labelMedium.copy(color = Color.White),
                        )
                    }
                }
            }
        }
    }
}

// ───────────────────────── Search ─────────────────────────

@Composable
private fun SearchSheet(state: YouTubeViewModel.UiState, vm: YouTubeViewModel) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val haze = rememberGlassBackgroundState()
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxSize().background(c.scrim)
                .pressableScale(vm::closeSearch, pressedScale = 1f, haptics = false),
        )
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Spacer(Modifier.height(40.dp))
            com.aurora.get.designsystem.effects.GlowRing(
                shape = LocalAuroraShapes.current.large,
                active = state.searching,
                modifier = Modifier.fillMaxWidth().height(60.dp),
            )
            GlassPanel(Modifier.fillMaxWidth(), shape = LocalAuroraShapes.current.large) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AuroraIcon(AuroraIcons.Search, "بحث", tint = c.brandPurple, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    BasicTextField(
                        value = state.query,
                        onValueChange = vm::onQueryChange,
                        textStyle = t.bodyLarge.copy(color = c.textPrimary),
                        cursorBrush = SolidColor(c.brandPurple),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            if (state.query.isEmpty()) {
                                BasicText("ابحث في JO DON", style = t.bodyLarge.copy(color = c.textTertiary))
                            }
                            inner()
                        },
                    )
                    AuroraGlassButton(onClick = { vm.submitSearch() }) {
                        BasicText(
                            "بحث", Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = t.labelMedium.copy(color = c.textPrimary),
                        )
                    }
                }
            }
            if (state.suggestions.isNotEmpty() && state.searchResults.isEmpty()) {
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.suggestions.size) { i ->
                        GlassChip(Modifier.pressableScale({ vm.submitSearch(state.suggestions[i]) })) {
                            BasicText(
                                state.suggestions[i],
                                Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                style = t.labelMedium.copy(color = c.textSecondary),
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(state.searchResults.size) { i ->
                    val v = state.searchResults[i]
                    GlassPanel(Modifier.pressableScale({ vm.openVideo(v) })) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(
                                model = v.thumbnail, contentDescription = null,
                                modifier = Modifier.size(width = 108.dp, height = 62.dp)
                                    .clip(LocalAuroraShapes.current.small),
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                BasicText(v.title, style = t.titleMedium.copy(color = c.textPrimary), maxLines = 2)
                                BasicText(
                                    listOf(v.channel, v.durationText, v.viewsText).filter { it.isNotBlank() }.joinToString(" · "),
                                    style = t.labelMedium.copy(color = c.textTertiary),
                                )
                            }
                            IconAction(AuroraIcons.Download, "تحميل") { vm.download(v) }
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── Watch overlay ─────────────────────────

@Composable
private fun WatchOverlay(
    page: YouTubeRepository_WatchPageAlias,
    state: YouTubeViewModel.UiState,
    vm: YouTubeViewModel,
) {
    val context = LocalContext.current
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val stream = state.stream

    val player = remember(stream?.url) {
        if (stream == null) null else {
            val headers = stream.headers
            val http = DefaultHttpDataSource.Factory().apply {
                if (headers.isNotEmpty()) setDefaultRequestProperties(headers)
                setUserAgent("Mozilla/5.0 (Linux; Android 14)")
            }
            val factory = DefaultMediaSourceFactory(DefaultDataSource.Factory(context, http))
            ExoPlayer.Builder(context).setMediaSourceFactory(factory).build().apply {
                setMediaItem(MediaItem.fromUri(stream.url))
                prepare()
                playWhenReady = true
                repeatMode = ExoPlayer.REPEAT_MODE_OFF
            }
        }
    }
    androidx.compose.runtime.DisposableEffect(player) {
        onDispose { player?.release() }
    }

    Box(Modifier.fillMaxSize().background(c.background)) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconAction(AuroraIcons.ArrowBack, "رجوع", vm::closeVideo)
                Spacer(Modifier.weight(1f))
                IconAction(AuroraIcons.Download, "تحميل") { vm.download(page.video) }
                IconAction(AuroraIcons.Link, "نسخ") { vm.copyLink(page.video) }
            }
            if (player != null) {
                GlassPanel(Modifier.fillMaxWidth()) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                this.player = player
                                useController = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                            .clip(LocalAuroraShapes.current.medium),
                    )
                }
            } else {
                Box(
                    Modifier.fillMaxWidth().aspectRatio(16f / 9f),
                    contentAlignment = Alignment.Center,
                ) {
                    com.aurora.get.designsystem.components.AuroraProgressRing(progress = 0.7f, size = 44.dp)
                    BasicText(
                        if (state.resolvingStream) "يجهّز البث…" else "تعذّر تجهيز البث",
                        style = t.labelMedium.copy(color = c.textSecondary),
                    )
                }
            }
            Column(Modifier.padding(16.dp)) {
                BasicText(page.video.title, style = t.headlineMedium.copy(color = c.textPrimary))
                Spacer(Modifier.height(4.dp))
                BasicText(
                    "JO DON · ${page.video.viewsText} · ${page.video.publishedText}",
                    style = t.labelMedium.copy(color = c.textTertiary),
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AuroraGlassButton(onClick = { vm.toggleSave(page.video) }) {
                        BasicText(
                            if (state.profile.saved.any { it.id == page.video.id }) "محفوظ" else "حفظ",
                            Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            style = t.labelMedium.copy(color = c.textPrimary),
                        )
                    }
                    AuroraGlassButton(onClick = { vm.downloadAudio(page.video) }) {
                        BasicText(
                            "تحميل صوتي", Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            style = t.labelMedium.copy(color = c.textPrimary),
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                BasicText(page.description.take(400), style = t.bodySmall.copy(color = c.textSecondary))
            }
            LazyColumn(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(page.related.size) { i ->
                    val v = page.related[i]
                    Box(Modifier.padding(horizontal = 16.dp)) {
                        GlassPanel(Modifier.pressableScale({ vm.openVideo(v) })) {
                            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(
                                    model = v.thumbnail, contentDescription = null,
                                    modifier = Modifier.size(width = 92.dp, height = 54.dp)
                                        .clip(LocalAuroraShapes.current.small),
                                )
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    BasicText(v.title, style = t.labelMedium.copy(color = c.textPrimary), maxLines = 2)
                                    BasicText(v.channel, style = t.labelSmallStyle(c.textTertiary))
                                }
                                IconAction(AuroraIcons.Download, "تحميل") { vm.download(v) }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun com.aurora.get.designsystem.theme.AuroraTypography.labelSmallStyle(color: Color) =
    bodySmall.copy(color = color)

// ───────────────────────── Local profile sheet ─────────────────────────

@Composable
private fun LocalProfileSheet(
    state: YouTubeViewModel.UiState,
    onRename: (String) -> Unit,
    onFollow: (String) -> Unit,
    onUnfollow: (String) -> Unit,
    onExport: () -> String,
    onImport: (String) -> Unit,
    onOpen: (VideoItem) -> Unit,
) {
    val context = LocalContext.current
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    var name by remember { mutableStateOf(state.profile.displayName) }
    var handle by remember { mutableStateOf("") }

    val exporter = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri: Uri? ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(onExport().toByteArray()) }
        }
    }
    val importer = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri: Uri? ->
        if (uri != null) runCatching {
            val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText()
            if (text != null) onImport(text)
        }
    }

    Column {
        GradientText("ملفي المحلي", t.headlineMedium)
        BasicText(
            "هوية محلية بالكامل — لا حساب Google ولا تسجيل دخول.",
            style = t.bodySmall.copy(color = c.textSecondary),
        )
        Spacer(Modifier.height(12.dp))

        GlassPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                BasicText("الاسم", style = t.labelMedium.copy(color = c.textTertiary))
                BasicTextField(
                    value = name, onValueChange = { name = it; onRename(it) },
                    textStyle = t.bodyLarge.copy(color = c.textPrimary),
                    cursorBrush = SolidColor(c.brandPurple),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                )
                BasicText(
                    "${state.profile.follows.size} متابعة · ${state.profile.history.size} في السجل · ${state.profile.saved.size} محفوظ",
                    style = t.labelMedium.copy(color = c.textTertiary),
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AuroraGlassButton(onClick = { exporter.launch("jo-don-profile.json") }) {
                        BasicText(
                            "تصدير الملف", Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            style = t.labelMedium.copy(color = c.textPrimary),
                        )
                    }
                    AuroraGlassButton(onClick = { importer.launch(arrayOf("application/json", "text/plain")) }) {
                        BasicText(
                            "استيراد ملف", Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            style = t.labelMedium.copy(color = c.textPrimary),
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        BasicText("متابعة قناة (اكتب @handle أو UC…)", style = t.labelMedium.copy(color = c.textTertiary))
        Row(verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(
                value = handle, onValueChange = { handle = it },
                textStyle = t.bodyMedium.copy(color = c.textPrimary),
                cursorBrush = SolidColor(c.brandPurple),
                modifier = Modifier.weight(1f).padding(vertical = 8.dp),
                decorationBox = { inner ->
                    if (handle.isEmpty()) BasicText("@handle", style = t.bodyMedium.copy(color = c.textTertiary))
                    inner()
                },
            )
            AuroraGlassButton(onClick = {
                if (handle.isNotBlank()) { onFollow(handle); handle = "" }
            }) {
                BasicText(
                    "متابعة", Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    style = t.labelMedium.copy(color = c.textPrimary),
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.height(300.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(state.profile.follows.size) { i ->
                val ch = state.profile.follows[i]
                GlassPanel {
                    Row(
                        Modifier.fillMaxWidth().padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AsyncImage(
                            model = ch.avatar, contentDescription = null,
                            modifier = Modifier.size(32.dp).clip(LocalAuroraShapes.current.full),
                        )
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            BasicText(ch.name, style = t.titleMedium.copy(color = c.textPrimary), maxLines = 1)
                            BasicText(
                                listOf(ch.handle, ch.subscribers).filter { it.isNotBlank() }.joinToString(" · "),
                                style = t.labelMedium.copy(color = c.textTertiary),
                            )
                        }
                        GlassChip(Modifier.pressableScale({ onUnfollow(ch.name) })) {
                            BasicText(
                                "إلغاء", Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                style = t.labelMedium.copy(color = c.error),
                            )
                        }
                    }
                }
            }
            if (state.profile.follows.isEmpty()) {
                item {
                    BasicText(
                        "لا متابعات بعد — أضف قناة بالأعلى.",
                        Modifier.padding(vertical = 10.dp),
                        style = t.bodySmall.copy(color = c.textTertiary),
                    )
                }
            }
            item {
                BasicText("سجل المشاهدة", Modifier.padding(top = 8.dp), style = t.titleMedium.copy(color = c.textPrimary))
            }
            items(state.profile.history.take(12).size) { i ->
                val v = state.profile.history[i]
                GlassPanel(Modifier.pressableScale({ onOpen(v) })) {
                    BasicText(
                        v.title, Modifier.padding(10.dp),
                        style = t.bodyMedium.copy(color = c.textSecondary), maxLines = 1,
                    )
                }
            }
        }
    }
}

/** Alias keeps the watch signature readable while the repository type stays qualified. */
private typealias YouTubeRepository_WatchPageAlias = com.aurora.get.feature.youtube.YouTubeRepository.WatchPage
