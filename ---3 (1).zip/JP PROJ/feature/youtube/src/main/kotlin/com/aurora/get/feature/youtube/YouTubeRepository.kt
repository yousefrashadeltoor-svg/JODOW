package com.aurora.get.feature.youtube

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.aurora.get.extractors.ytdlp.YtDlpExtractor
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import timber.log.Timber
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

// ───────────────────────── Model ─────────────────────────

@Serializable
data class VideoItem(
    val id: String,
    val title: String,
    val channel: String = "",
    val channelId: String = "",
    val durationText: String = "",
    val viewsText: String = "",
    val publishedText: String = "",
    val thumbnail: String = "",
    val isShort: Boolean = false,
    val isLive: Boolean = false,
)

@Serializable
data class ChannelItem(
    val id: String = "",
    val name: String,
    val handle: String = "",
    val avatar: String = "",
    val subscribers: String = "",
    val followedAt: Long = System.currentTimeMillis(),
)

/** 100% local profile — nothing is tied to a Google account. Exportable/importable as JSON. */
@Serializable
data class LocalProfile(
    val displayName: String = "ملفي المحلي",
    val handle: String = "@local",
    val avatarSeed: String = "jo",
    val follows: List<ChannelItem> = emptyList(),
    val history: List<VideoItem> = emptyList(),
    val saved: List<VideoItem> = emptyList(),
    val interests: Map<String, Int> = emptyMap(),
    val themeId: String = "AURORA",
    val createdAt: Long = System.currentTimeMillis(),
)

// ───────────────────────── Repository ─────────────────────────

private val Context.youtubeStore by preferencesDataStore("jo_local_youtube")

@Singleton
class YouTubeRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val client: OkHttpClient,
    private val ytDlp: YtDlpExtractor,
    private val json: Json,
) {
    companion object {
        private const val UA =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36"
        private const val PROFILE_KEY = "profile_json"
        private const val BASE = "https://www.youtube.com"
        private const val CONSENT = "CONSENT=YES+cb; SOCS=CAI"
    }

    // ── Low-level fetch (real network; nothing mocked) ──
    private suspend fun get(url: String, headers: Map<String, String> = emptyMap()): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                val req = Request.Builder().url(url)
                    .header("User-Agent", UA)
                    .header("Accept-Language", "ar,en;q=0.8")
                    .header("Cookie", CONSENT)
                    .apply { headers.forEach { (k, v) -> header(k, v) } }
                    .build()
                client.newCall(req).execute().use { res ->
                    if (res.isSuccessful) res.body.string() else null
                }
            }.onFailure { Timber.w(it, "fetch failed: $url") }.getOrNull()
        }

    /** Extracts the ytInitialData JSON object from a YouTube HTML page. */
    private fun extractInitialData(html: String): JsonObject? {
        val markers = listOf(
            "var ytInitialData = ", "ytInitialData = ", "window[\"ytInitialData\"] = ",
        )
        for (m in markers) {
            val start = html.indexOf(m)
            if (start < 0) continue
            val from = start + m.length
            val end = html.indexOf(";</script>", from).takeIf { it > 0 } ?: html.indexOf("};", from)
            if (end <= from) continue
            val raw = html.substring(from, end + 1)
            runCatching { return json.parseToJsonElement(raw).jsonObject }.onFailure {
                Timber.v("ytInitialData parse failed: ${it.message}")
            }
        }
        return null
    }

    private fun JsonObject.text(path: String): String {
        var cur: kotlinx.serialization.json.JsonElement = this
        path.split('.').forEach { key ->
            cur = when (cur) {
                is JsonObject -> cur[key] ?: return ""
                is JsonArray -> cur.getOrNull(key.toIntOrNull() ?: 0) ?: return ""
                else -> return ""
            }
        }
        return when (cur) {
            is JsonObject -> cur["simpleText"]?.jsonPrimitive?.contentOrNull
                ?: cur["content"]?.jsonPrimitive?.contentOrNull
                ?: cur["runs"]?.jsonArray?.firstOrNull()?.jsonObject?.get("text")
                    ?.jsonPrimitive?.contentOrNull
                ?: ""
            else -> cur.jsonPrimitive.contentOrNull ?: ""
        }
    }

    // ── Search suggestions (real public endpoint) ──
    suspend fun suggestions(query: String): List<String> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        runCatching {
            val url = "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&hl=ar&q=" +
                URLEncoder.encode(query, "UTF-8")
            val body = get(url) ?: return@withContext emptyList()
            val root = json.parseToJsonElement(body).jsonArray
            // ["query", ["s1","s2",...]]
            root.getOrNull(1)?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull } ?: emptyList()
        }.getOrDefault(emptyList())
    }

    // ── Search results (parse ytInitialData videoRenderer) ──
    suspend fun search(query: String): List<VideoItem> {
        val url = "$BASE/results?search_query=${URLEncoder.encode(query, "UTF-8")}&hl=ar&gl=SA&sp=EgIQAQ%253D%253D"
        val html = get(url) ?: return emptyList()
        val data = extractInitialData(html) ?: return emptyList()
        return collectVideoRenderers(data)
    }

    // ── Trending / home feed ──
    suspend fun trending(): List<VideoItem> {
        val html = get("$BASE/feed/trending?hl=ar&gl=SA") ?: return emptyList()
        val data = extractInitialData(html) ?: return emptyList()
        return collectVideoRenderers(data)
    }

    // ── Shorts feed ──
    suspend fun shorts(): List<VideoItem> {
        val html = get("$BASE/shorts/?hl=ar&gl=SA") ?: return emptyList()
        val data = extractInitialData(html) ?: return emptyList()
        val out = mutableListOf<VideoItem>()
        walk(data) { obj ->
            val short = obj["shortsLockupViewModel"] as? JsonObject
                ?: obj["reelItemRenderer"] as? JsonObject
            if (short != null) {
                val id = short.text("onTap.innertubeCommand.reelWatchEndpoint.videoId")
                    .ifBlank { short.text("videoId") }
                val title = short.text("overlayMetadata.primaryText.content")
                    .ifBlank { short.text("headline.simpleText") }
                if (id.isNotBlank()) {
                    out += VideoItem(
                        id = id, title = title,
                        thumbnail = "https://i.ytimg.com/vi/$id/oar2.jpg",
                        isShort = true,
                    )
                }
            }
        }
        return out.distinctBy { it.id }
    }

    // ── Channel feed through the public RSS feed (no API key, exact data) ──
    suspend fun channelUploads(channelId: String): List<VideoItem> {
        val xml = get("$BASE/feeds/videos.xml?channel_id=$channelId") ?: return emptyList()
        val doc = Jsoup.parse(xml, "", org.jsoup.parser.Parser.xmlParser())
        val channelName = doc.selectFirst("author > name")?.text().orEmpty()
        return doc.select("entry").map { e ->
            VideoItem(
                id = e.selectFirst("yt:videoId")?.text().orEmpty(),
                title = e.selectFirst("title")?.text().orEmpty(),
                channel = channelName,
                channelId = channelId,
                thumbnail = "https://i.ytimg.com/vi/${e.selectFirst("yt:videoId")?.text()}/hqdefault.jpg",
                publishedText = e.selectFirst("published")?.text().orEmpty(),
            )
        }.filter { it.id.isNotBlank() }
    }

    /** Channel meta + follow lookup by handle (real oEmbed-less scrape of the channel page). */
    suspend fun resolveChannel(handleOrUrl: String): ChannelItem? {
        val clean = handleOrUrl.trim().removePrefix("@")
        val url = if (clean.startsWith("http")) clean
        else if (clean.startsWith("UC")) "$BASE/channel/$clean"
        else "$BASE/@$clean"
        val html = get(url) ?: return null
        val doc = Jsoup.parse(html)
        val title = doc.selectFirst("meta[property=og:title]")?.attr("content") ?: return null
        val avatar = doc.selectFirst("meta[property=og:image]")?.attr("content").orEmpty()
        val channelId = Regex("\"channelId\":\"(UC[\\w-]{20,})\"").find(html)?.groupValues?.get(1).orEmpty()
        val subs = Regex("([\\d.,]+\\s?[KMB]?)\\s?(subscribers|مشترك)").find(html)?.groupValues?.get(1).orEmpty()
        return ChannelItem(
            id = channelId,
            name = title,
            handle = if (clean.startsWith("UC")) "" else "@$clean",
            avatar = avatar,
            subscribers = subs,
        )
    }

    /** Recommendations: built from the local profile's interests + followed channels. */
    suspend fun recommendations(profile: LocalProfile): List<VideoItem> {
        val seeds = profile.interests.entries.sortedByDescending { it.value }.take(4).map { it.key }
        val collected = mutableListOf<VideoItem>()
        // followed channels' newest uploads first — infinite-ish surface
        profile.follows.take(3).forEach { ch ->
            if (ch.id.isNotBlank()) collected += channelUploads(ch.id).take(6)
        }
        seeds.forEach { seed ->
            collected += search(seed).take(8)
        }
        if (collected.isEmpty()) collected += trending()
        return collected.distinctBy { it.id }
    }

    /** Google publishes best-effort watch pages; the player streams via yt-dlp (direct URL). */
    suspend fun watchPage(videoId: String): WatchPage? {
        val url = "$BASE/watch?v=$videoId&hl=ar"
        val html = get(url) ?: return null
        val doc = Jsoup.parse(html)
        fun meta(vararg keys: String): String {
            for (k in keys) {
                doc.selectFirst("meta[property=$k]")?.attr("content")?.takeIf { it.isNotBlank() }?.let { return it }
                doc.selectFirst("meta[name=$k]")?.attr("content")?.takeIf { it.isNotBlank() }?.let { return it }
            }
            return ""
        }
        val related = extractInitialData(html)?.let { collectVideoRenderers(it).filter { v -> v.id != videoId } }
            ?: emptyList()
        return WatchPage(
            video = VideoItem(
                id = videoId,
                title = meta("og:title", "title"),
                channel = meta("og:site_name"),
                thumbnail = "https://i.ytimg.com/vi/$videoId/maxresdefault.jpg",
                viewsText = Regex("\"viewCount\":\"(\\d+)\"").find(html)?.groupValues?.get(1).orEmpty(),
                publishedText = meta("og:video:release_date", "datePublished"),
            ),
            description = meta("og:description", "description"),
            related = related,
        )
    }

    /** Direct playable stream (Media3-friendly) + headers, via the existing yt-dlp engine. */
    suspend fun streamUrl(videoUrl: String): StreamInfo? = withContext(Dispatchers.IO) {
        runCatching {
            val media = ytDlp.extract(videoUrl)
            val progressive = media.formats
                .filter { it.kind == com.aurora.get.common.MediaKind.VIDEO && it.hasAudio && it.url != null }
                .maxByOrNull { it.height }
            val videoOnly = media.formats
                .filter { it.kind == com.aurora.get.common.MediaKind.VIDEO && it.url != null }
                .maxByOrNull { it.height }
            val url = progressive?.url ?: videoOnly?.url ?: media.formats.firstOrNull { it.url != null }?.url
            url?.let {
                StreamInfo(
                    url = it,
                    title = media.title,
                    audioOnlyFallback = progressive == null,
                    headers = media.requiredHeaders,
                )
            }
        }.onFailure { Timber.e(it, "stream resolve failed") }.getOrNull()
    }

    data class StreamInfo(
        val url: String,
        val title: String,
        val audioOnlyFallback: Boolean,
        val headers: Map<String, String>,
    )

    @Serializable
    data class WatchPage(
        val video: VideoItem,
        val description: String = "",
        val related: List<VideoItem> = emptyList(),
    )

    // ── Profile persistence (DataStore JSON, no backend, no account) ──
    val profileFlow: Flow<LocalProfile> = context.youtubeStore.data.map { prefs ->
        prefs[stringPreferencesKey(PROFILE_KEY)]?.let { raw ->
            runCatching { json.decodeFromString<LocalProfile>(raw) }.getOrNull()
        } ?: LocalProfile()
    }

    suspend fun saveProfile(profile: LocalProfile) {
        context.youtubeStore.edit { it[stringPreferencesKey(PROFILE_KEY)] = json.encodeToString(profile) }
    }

    fun exportJson(profile: LocalProfile): String = json.encodeToString(profile)

    fun importJson(raw: String): LocalProfile? = runCatching {
        json.decodeFromString<LocalProfile>(raw)
    }.getOrNull()

    // ── Extraction helpers ──

    /** Iterative walk so deeply nested ytInitialData structures are all visited safely. */
    private fun walk(root: JsonObject, onObject: (JsonObject) -> Unit) {
        val stack = ArrayDeque<kotlinx.serialization.json.JsonElement>()
        stack.add(root)
        var guard = 0
        while (stack.isNotEmpty() && guard < 20000) {
            guard++
            when (val node = stack.removeLast()) {
                is JsonObject -> {
                    onObject(node)
                    node.values.forEach { stack.add(it) }
                }
                is JsonArray -> node.forEach { stack.add(it) }
                else -> Unit
            }
        }
    }

    private fun collectVideoRenderers(root: JsonObject): List<VideoItem> {
        val out = mutableListOf<VideoItem>()
        walk(root) { obj ->
            val v = obj["videoRenderer"] as? JsonObject
            if (v != null) {
                val id = v.text("videoId")
                if (id.isNotBlank()) {
                    out += VideoItem(
                        id = id,
                        title = v.text("title"),
                        channel = v.text("ownerText"),
                        channelId = v.text("ownerText.runs.0.navigationEndpoint.browseEndpoint.browseId"),
                        durationText = v.text("lengthText"),
                        viewsText = v.text("viewCountText"),
                        publishedText = v.text("publishedTimeText"),
                        thumbnail = v.text("thumbnail.thumbnails.2.url")
                            .ifBlank { v.text("thumbnail.thumbnails.0.url") }
                            .ifBlank { "https://i.ytimg.com/vi/$id/hqdefault.jpg" },
                        isLive = v["badges"]?.toString()?.contains("LIVE") == true,
                    )
                }
            }
            val compact = obj["compactVideoRenderer"] as? JsonObject
            if (compact != null) {
                val id = compact.text("videoId")
                if (id.isNotBlank()) {
                    out += VideoItem(
                        id = id,
                        title = compact.text("title"),
                        channel = compact.text("longBylineText"),
                        durationText = compact.text("lengthText"),
                        viewsText = compact.text("shortViewCountText"),
                        thumbnail = "https://i.ytimg.com/vi/$id/hqdefault.jpg",
                    )
                }
            }
        }
        return out.distinctBy { it.id }
    }
}
