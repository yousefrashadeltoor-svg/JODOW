package com.aurora.get.feature.home.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import coil3.compose.AsyncImage
import com.aurora.get.common.Bytes
import com.aurora.get.common.MediaKind
import com.aurora.get.designsystem.components.AuroraGlassButton
import com.aurora.get.designsystem.components.AuroraIcon
import com.aurora.get.designsystem.components.AuroraProgressBar
import com.aurora.get.designsystem.components.GlassBottomSheet
import com.aurora.get.designsystem.components.GradientText
import com.aurora.get.designsystem.components.pressableScale
import com.aurora.get.designsystem.effects.GlowRing
import com.aurora.get.designsystem.effects.MeshGradientBackground
import com.aurora.get.designsystem.glass.GlassChip
import com.aurora.get.designsystem.glass.GlassPanel
import com.aurora.get.designsystem.glass.rememberGlassBackgroundState
import com.aurora.get.designsystem.icons.AuroraIcons
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import com.aurora.get.designsystem.theme.LocalAuroraTypography
import com.aurora.get.extractors.model.FormatOption
import com.aurora.get.feature.home.HomeViewModel
import com.valentinilk.shimmer.shimmer
import dev.chrisbanes.haze.hazeSource
import androidx.compose.runtime.collectAsState

/**
 * Home (spec §10.4-1): hero paste field with rotating Gemini glow, discovered-site chip,
 * progressive info card, the four smart buttons, and recent downloads.
 */
@Composable
fun HomeScreen(
    onNavigateBrowser: (String) -> Unit,
    viewModel: HomeViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    val clipboard = LocalClipboardManager.current
    val t = LocalAuroraTypography.current
    val c = AuroraTheme.colors
    val haze = rememberGlassBackgroundState()

    Box(Modifier.fillMaxSize()) {
        MeshGradientBackground(Modifier.matchParentSize().hazeSource(state = haze))

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
        ) {
            Spacer(Modifier.height(28.dp))

            // ── Greeting ──
            GradientText("أورورا غِت", t.displayMedium)
            BasicText(
                "حمّل فيديو وصوتًا وصورًا وملفات من آلاف المواقع — بسرعة البرق.",
                style = t.bodyMedium.copy(color = c.textSecondary),
            )
            Spacer(Modifier.height(24.dp))

            // ── Hero paste field with rotating glow ──
            Box {
                GlowRing(
                    shape = LocalAuroraShapes.current.large,
                    active = state.analyzing,
                    modifier = Modifier.fillMaxWidth().height(92.dp),
                )
                GlassPanel(
                    hazeState = haze,
                    shape = LocalAuroraShapes.current.large,
                    glowColor = if (state.analyzing) c.glow else Color.Unspecified,
                    modifier = Modifier.fillMaxWidth().padding(2.dp),
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AuroraIcon(AuroraIcons.Link, contentDescription = null, tint = c.brandPurple)
                        Spacer(Modifier.width(12.dp))
                        Box(Modifier.weight(1f)) {
                            BasicTextField(
                                value = state.rawInput,
                                onValueChange = { viewModel.dispatch(HomeViewModel.Intent.InputChanged(it)) },
                                textStyle = t.bodyLarge.copy(color = c.textPrimary),
                                cursorBrush = SolidColor(c.brandPurple),
                                modifier = Modifier.fillMaxWidth(),
                                decorationBox = { inner ->
                                    if (state.rawInput.isEmpty()) {
                                        BasicText(
                                            "الصق رابطك هنا…",
                                            style = t.bodyLarge.copy(color = c.textTertiary),
                                        )
                                    }
                                    inner()
                                },
                            )
                        }
                        AuroraGlassButton(onClick = {
                            clipboard.getText()?.text
                                ?.let { viewModel.dispatch(HomeViewModel.Intent.InputChanged(it)) }
                        }, shape = LocalAuroraShapes.current.small) {
                            Row(
                                Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                AuroraIcon(AuroraIcons.Paste, "لصق", tint = c.textPrimary)
                                Spacer(Modifier.width(8.dp))
                                BasicText("لصق", style = t.labelLarge.copy(color = c.textPrimary))
                            }
                        }
                    }
                }
            }

            // ── Floating "link detected" chip (non-intrusive) ──
            AnimatedVisibility(
                visible = state.media != null && state.rawInput.isBlank().not(),
                enter = fadeIn() + scaleIn(spring(dampingRatio = Spring.DampingRatioMediumBouncy)),
                exit = fadeOut() + scaleOut(),
            ) {
                state.media?.let { media ->
                    GlassChip(
                        Modifier.padding(top = 14.dp).pressableScale({})
                    ) {
                        Row(
                            Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AsyncImage(
                                model = media.faviconUrl, contentDescription = null,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(Modifier.width(8.dp))
                            BasicText(
                                "رابط مكتشف · ${media.domain}",
                                style = t.labelMedium.copy(color = c.textSecondary),
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(22.dp))

            // ── Progressive info card ──
            when {
                state.analyzing && state.media == null -> AnalysisSkeleton()
                state.media != null -> InfoCard(state, viewModel, haze)
                state.fallbackSuggestion != null -> FallbackCard(state.fallbackSuggestion!!) {
                    viewModel.dispatch(HomeViewModel.Intent.OpenInBrowser)
                }
                else -> EmptyOrb()
            }

            Spacer(Modifier.height(100.dp)) // clearance for the floating dock
        }
    }

    // ── Smart-button sheet (formats list) ──
    state.openSheetFor?.let { kind ->
        val items = state.buttons?.forKind(kind).orEmpty()
        GlassBottomSheet(visible = true, onDismiss = { viewModel.dispatch(HomeViewModel.Intent.CloseSheet) }, hazeState = haze) {
            FormatList(kindLabel(kind), items, onDownload = {
                viewModel.dispatch(HomeViewModel.Intent.Download(it))
            })
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Progressive info card: site, title, thumbnail, duration, size, four buttons
// ─────────────────────────────────────────────────────────────

@Composable
private fun InfoCard(
    state: HomeViewModel.UiState,
    viewModel: HomeViewModel,
    haze: dev.chrisbanes.haze.HazeState,
) {
    val media = state.media ?: return
    val t = LocalAuroraTypography.current
    val c = AuroraTheme.colors

    GlassPanel(hazeState = haze, glowColor = c.glow, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // site logo + name + domain
                AsyncImage(
                    model = media.faviconUrl, contentDescription = null,
                    modifier = Modifier.size(34.dp),
                )
                Spacer(Modifier.width(10.dp))
                Column {
                    BasicText(media.siteName.ifBlank { media.domain },
                        style = t.titleMedium.copy(color = c.textPrimary))
                    BasicText(media.domain,
                        style = t.labelMedium.copy(color = c.textTertiary))
                }
                Spacer(Modifier.weight(1f))
                KindBadge(media.kind)
            }

            Spacer(Modifier.height(14.dp))

            // thumbnail + title
            media.thumbnailUrl?.let { thumb ->
                AsyncImage(
                    model = thumb, contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(c.surfaceHigh, LocalAuroraShapes.current.medium),
                )
                Spacer(Modifier.height(12.dp))
            }
            if (media.title.isNotBlank()) {
                BasicText(
                    media.title,
                    style = t.titleLarge.copy(color = c.textPrimary),
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
            }

            // meta row
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                media.durationSec.takeIf { it > 0 }?.let { d ->
                    MetaItem("المدة", formatDuration(d))
                }
                media.uploader?.let { MetaItem("قناة", it) }
                state.directSize?.let { size ->
                    MetaItem("الحجم", size.short) // ≈ handled inside SizeInfo
                }
            }

            // ── The four smart buttons — only shown when content exists for them ──
            val buttons = state.buttons
            if (buttons != null && buttons.anyVisible) {
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SmartButton(MediaKind.AUDIO, "صوت", AuroraIcons.Music, buttons.audio.size) {
                        viewModel.dispatch(HomeViewModel.Intent.OpenSheet(MediaKind.AUDIO))
                    }
                    SmartButton(MediaKind.IMAGE, "صور", AuroraIcons.Image, buttons.images.size) {
                        viewModel.dispatch(HomeViewModel.Intent.OpenSheet(MediaKind.IMAGE))
                    }
                    SmartButton(MediaKind.VIDEO, "فيديو", AuroraIcons.Video, buttons.video.size) {
                        viewModel.dispatch(HomeViewModel.Intent.OpenSheet(MediaKind.VIDEO))
                    }
                    SmartButton(MediaKind.FILE, "ملفات", AuroraIcons.FileDoc, buttons.files.size) {
                        viewModel.dispatch(HomeViewModel.Intent.OpenSheet(MediaKind.FILE))
                    }
                }
            }

            if (state.analyzing) {
                Spacer(Modifier.height(14.dp))
                BasicText(
                    when (state.stage) {
                        0 -> "يتعرف على الموقع…"
                        1 -> "يقيس الحجم الحقيقي…"
                        2 -> "يحلل المحتوى…"
                        else -> "يجلب كل الجودات والصيغ…"
                    },
                    style = t.labelMedium.copy(color = c.textTertiary),
                )
                Spacer(Modifier.height(8.dp))
                AuroraProgressBar(progress = (state.stage + 1) / 4f, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

/**
 * One smart button — appears only when [count] > 0 (spec §4.4).
 * Entry: spring + scale + fade + blur-in; carries a count badge.
 */
@Composable
private fun SmartButton(
    kind: MediaKind, label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    count: Int, onClick: () -> Unit,
) {
    if (count <= 0) return            // never render an empty button
    val c = AuroraTheme.colors
    val accent = kindColor(kind)
    var blurIn by remember { mutableStateOf(true) }
    val blurAlpha by animateFloatAsState(if (blurIn) 0f else 1f, label = "smartBtn")
    androidx.compose.runtime.LaunchedEffect(Unit) { blurIn = false }

    AnimatedVisibility(
        visible = count > 0,
        enter = scaleIn(spring(dampingRatio = Spring.DampingRatioMediumBouncy)) + fadeIn(),
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .alpha(blurAlpha)
                .blur(if (blurIn) 12.dp else 0.dp),
        ) {
            Box(
                Modifier
                    .size(58.dp)
                    .pressableScale(onClick)
                    .background(accent.copy(alpha = 0.16f), LocalAuroraShapes.current.squircle),
                contentAlignment = Alignment.Center,
            ) {
                AuroraIcon(icon, label, tint = accent)
                // count badge
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .background(c.background, LocalAuroraShapes.current.full)
                        .padding(1.5.dp),
                ) {
                    Box(
                        Modifier
                            .size(18.dp)
                            .background(accent, LocalAuroraShapes.current.full),
                        contentAlignment = Alignment.Center,
                        ) {
                            BasicText(
                                count.toString(),
                                style = LocalAuroraTypography.current.labelMedium.copy(
                                    color = Color.White, fontSize = 9.sp,
                                ),
                            )
                        }
                }
            }
            Spacer(Modifier.height(6.dp))
            BasicText(label, style = LocalAuroraTypography.current.labelMedium.copy(color = c.textSecondary))
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Format list in the glass sheet — quality/codec/fps/size + direct download
// ─────────────────────────────────────────────────────────────

@Composable
private fun FormatList(title: String, items: List<FormatOption>, onDownload: (FormatOption) -> Unit) {
    val t = LocalAuroraTypography.current
    val c = AuroraTheme.colors
    Column {
        GradientText(title, t.headlineMedium)
        Spacer(Modifier.height(12.dp))
        androidx.compose.foundation.lazy.LazyColumn(
            Modifier.height(420.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(items.size) { i ->
                val f = items[i]
                GlassPanel(shape = LocalAuroraShapes.current.medium) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                BasicText(f.label, style = t.titleMedium.copy(color = c.textPrimary))
                                if (f.needsMerge) MergeBadge()
                                if (f.isWatermarkFree == true) {
                                    Spacer(Modifier.width(6.dp))
                                    BasicText("بدون علامة", style = t.labelMedium.copy(color = c.success))
                                }
                            }
                            BasicText(
                                buildString {
                                    append(f.container.uppercase())
                                    f.codec?.let { append(" · $it") }
                                    if (f.fps > 0) append(" · ${f.fps}fps")
                                    if (f.bitrateKbps > 0) append(" · ${f.bitrateKbps}kbps")
                                },
                                style = t.labelMedium.copy(color = c.textTertiary),
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            f.size?.let { BasicText(it.short, style = t.mono.copy(color = c.textSecondary)) }
                            Spacer(Modifier.height(6.dp))
                            AuroraGlassButton(onClick = { onDownload(f) }) {
                                Row(
                                    Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    AuroraIcon(AuroraIcons.Download, null, tint = c.brandPurple)
                                    Spacer(Modifier.width(6.dp))
                                    BasicText("تحميل", style = t.labelLarge.copy(color = c.textPrimary))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MergeBadge() {
    val c = AuroraTheme.colors
    GlassChip(Modifier.padding(start = 8.dp)) {
        BasicText(
            "دمج تلقائي",
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            style = LocalAuroraTypography.current.labelMedium.copy(color = c.brandPurple),
        )
    }
}

// ─────────────────────────────────────────────────────────────
// Skeleton / fallback / empty states
// ─────────────────────────────────────────────────────────────

@Composable
private fun AnalysisSkeleton() {
    val t = LocalAuroraTypography.current
    GlassPanel {
        Column(Modifier.fillMaxWidth().padding(18.dp).shimmer()) {
            Box(Modifier.fillMaxWidth().height(180.dp).background(Color.White.copy(0.06f), LocalAuroraShapes.current.medium))
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth(0.7f).height(20.dp).background(Color.White.copy(0.07f), LocalAuroraShapes.current.full))
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth(0.4f).height(14.dp).background(Color.White.copy(0.05f), LocalAuroraShapes.current.full))
        }
    }
}

@Composable
private fun FallbackCard(reason: String, onOpenBrowser: () -> Unit) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    GlassPanel {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            BasicText(reason, style = t.bodyMedium.copy(color = c.textSecondary))
            Spacer(Modifier.height(12.dp))
            AuroraGlassButton(onClick = onOpenBrowser) {
                Row(
                    Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AuroraIcon(AuroraIcons.Browser, null, tint = c.brandPurple)
                    Spacer(Modifier.width(8.dp))
                    BasicText("افتح في المتصفح الداخلي لاصطياد الملفات", style = t.labelLarge.copy(color = c.textPrimary))
                }
            }
        }
    }
}

@Composable
private fun EmptyOrb() {
    val c = AuroraTheme.colors
    Box(Modifier.fillMaxWidth().padding(vertical = 30.dp), contentAlignment = Alignment.Center) {
        // pulsing liquid orb
        OrbPulse()
    }
}

@Composable
private fun OrbPulse() {
    val c = AuroraTheme.colors
    val scale by androidx.compose.animation.core.rememberInfiniteTransition(label = "orb")
        .animateFloat(
            0.85f, 1.1f,
            androidx.compose.animation.core.infiniteRepeatable(
                androidx.compose.animation.core.tween(2400, easing = androidx.compose.animation.core.FastOutSlowInEasing),
                androidx.compose.animation.core.RepeatMode.Reverse,
            ),
            label = "orbScale",
        )
    Box(
        Modifier
            .size(140.dp * scale / 1f)
            .background(c.brandGradient, LocalAuroraShapes.current.full)
            .alpha(0.5f),
    )
}

// ── helpers ──

@Composable
private fun kindColor(kind: MediaKind): Color = when (kind) {
    MediaKind.VIDEO -> AuroraTheme.colors.typeVideo
    MediaKind.AUDIO -> AuroraTheme.colors.typeAudio
    MediaKind.IMAGE -> AuroraTheme.colors.typeImage
    MediaKind.FILE -> AuroraTheme.colors.typeFile
}

private fun kindLabel(kind: MediaKind): String = when (kind) {
    MediaKind.VIDEO -> "الفيديو"
    MediaKind.AUDIO -> "الصوت"
    MediaKind.IMAGE -> "الصور"
    MediaKind.FILE -> "الملفات"
}

@Composable
private fun KindBadge(kind: MediaKind) {
    val label = kindLabel(kind)
    GlassChip {
        BasicText(
            label,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            style = LocalAuroraTypography.current.labelMedium.copy(color = kindColor(kind)),
        )
    }
}

@Composable
private fun MetaItem(label: String, value: String) {
    val t = LocalAuroraTypography.current
    val c = AuroraTheme.colors
    Column {
        BasicText(label, style = t.labelMedium.copy(color = c.textTertiary))
        BasicText(value, style = t.bodyMedium.copy(color = c.textSecondary), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

private fun formatDuration(sec: Int): String {
    val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
