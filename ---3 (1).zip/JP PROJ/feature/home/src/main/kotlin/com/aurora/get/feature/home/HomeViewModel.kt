package com.aurora.get.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.analyzer.LinkAnalyzer
import com.aurora.get.common.MediaKind
import com.aurora.get.common.SizeInfo
import com.aurora.get.db.DownloadDao
import com.aurora.get.db.DownloadEntity
import com.aurora.get.downloader.DownloadQueue
import com.aurora.get.extractors.model.ExtractedMedia
import com.aurora.get.extractors.model.FormatOption
import com.aurora.get.extractors.model.SmartButtons
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

/**
 * MVI for Home (paste → staged analysis → smart buttons → download).
 * Debounce 150ms; any URL change cancels the in-flight analysis (collectLatest upstream).
 */
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val analyzer: LinkAnalyzer,
    private val downloads: DownloadDao,
    private val queue: DownloadQueue,
) : ViewModel() {

    data class UiState(
        val rawInput: String = "",
        val analyzing: Boolean = false,
        val stage: Int = 0,                       // 0..3 for shimmer skeleton
        val media: ExtractedMedia? = null,
        val buttons: SmartButtons? = null,
        val directSize: SizeInfo? = null,
        val fallbackSuggestion: String? = null,
        val openSheetFor: MediaKind? = null,      // which smart-button sheet is open
        val confirmMerge: FormatOption? = null,   // merge dialog target
        val error: String? = null,
    )

    sealed interface Intent {
        data class InputChanged(val text: String) : Intent
        data object PasteFromClipboard : Intent
        data object Clear : Intent
        data class OpenSheet(val kind: MediaKind) : Intent
        data object CloseSheet : Intent
        data class Download(val option: FormatOption) : Intent
        data class EditFileName(val name: String) : Intent
        data object OpenInBrowser : Intent
    }

    sealed interface Effect {
        data class Toast(val message: String) : Effect
        data class NavigateToBrowser(val url: String) : Effect
    }

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private val _effects = Channel<Effect>(Channel.BUFFERED)
    val effects = _effects.receiveAsFlow()

    private val inputFlow = MutableStateFlow("")

    init {
        watchInput()
    }

    fun dispatch(intent: Intent) {
        when (intent) {
            is Intent.InputChanged -> {
                _state.update { it.copy(rawInput = intent.text) }
                inputFlow.value = intent.text
            }
            Intent.PasteFromClipboard -> viewModelScope.launch {
                // read by the composable (ClipboardManager) and sent back via InputChanged
            }
            Intent.Clear -> {
                inputFlow.value = ""
                _state.value = UiState()
            }
            is Intent.OpenSheet -> _state.update { it.copy(openSheetFor = intent.kind) }
            Intent.CloseSheet -> _state.update { it.copy(openSheetFor = null) }
            is Intent.Download -> startDownload(intent.option)
            is Intent.EditFileName -> renameOnMedia(intent.name)
            Intent.OpenInBrowser -> _state.value.media?.let {
                _effects.trySend(Effect.NavigateToBrowser(it.resolvedUrl ?: it.sourceUrl))
            }
        }
    }

    @OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
    private fun watchInput() {
        viewModelScope.launch {
            inputFlow
                .debounce(150)                       // spec: 150ms debounce
                .distinctUntilChanged()
                .filter { it.isNotBlank() }
                .collectLatest { text ->             // new link cancels the old analysis
                    analyze(text)
                }
        }
    }

    private suspend fun analyze(link: String) {
        _state.update { it.copy(analyzing = true, stage = 0, fallbackSuggestion = null, error = null) }
        analyzer.analyze(link).collectLatest { event ->
            when (event) {
                is LinkAnalyzer.Event.DomainReady -> _state.update {
                    it.copy(stage = 0, media = event.snapshot.media)
                }
                is LinkAnalyzer.Event.Probed -> _state.update {
                    it.copy(
                        stage = 1, media = event.snapshot.media,
                        buttons = event.snapshot.smartButtons,
                        directSize = event.snapshot.directProbe?.size,
                    )
                }
                is LinkAnalyzer.Event.FastPath -> _state.update {
                    it.copy(stage = 2, media = event.snapshot.media, buttons = event.snapshot.smartButtons)
                }
                is LinkAnalyzer.Event.Full -> _state.update {
                    it.copy(
                        stage = 3, analyzing = false, media = event.snapshot.media,
                        buttons = event.snapshot.smartButtons,
                    )
                }
                is LinkAnalyzer.Event.FallbackSuggestion -> _state.update {
                    it.copy(analyzing = false, fallbackSuggestion = event.reason)
                }
                is LinkAnalyzer.Event.Failed -> _state.update {
                    it.copy(analyzing = false, error = event.cause.message)
                }
            }
        }
    }

    private fun startDownload(option: FormatOption) {
        val media = _state.value.media ?: return
        viewModelScope.launch {
            val fileName = media.originalFileName ?: guessFileName(media, option)
            val entity = DownloadEntity(
                id = UUID.randomUUID().toString(),
                url = media.resolvedUrl ?: media.sourceUrl,
                directUrl = option.url,
                fileName = fileName,
                destDir = destFor(option.kind),
                kind = option.kind,
                totalBytes = option.size?.bytes ?: -1,
                sizeApprox = option.size?.isApproximate ?: false,
                needsMerge = option.needsMerge,
                audioUrl = null, // resolved by the engine using mergeAudioId
                siteDomain = media.domain,
                headersJson = if (media.requiredHeaders.isEmpty()) null
                else kotlinx.serialization.json.Json.encodeToString(media.requiredHeaders),
            )
            downloads.upsert(entity)
            queue.enqueue(entity)
            _effects.send(Effect.Toast("بدأ التحميل: $fileName"))
            _state.update { it.copy(openSheetFor = null) }
        }
    }

    private fun renameOnMedia(name: String) {
        _state.update { s -> s.copy(media = s.media?.copy(originalFileName = name)) }
    }

    private fun guessFileName(media: ExtractedMedia, option: FormatOption): String {
        val base = (media.title.ifBlank { "aurora" })
            .replace(Regex("[\\\\/:*?\"<>|]"), "-").take(60)
        return "$base.${option.container}"
    }

    private fun destFor(kind: MediaKind): String = when (kind) {
        MediaKind.VIDEO -> "Movies/Aurora"
        MediaKind.AUDIO -> "Music/Aurora"
        MediaKind.IMAGE -> "Pictures/Aurora"
        MediaKind.FILE -> "Download/Aurora"
    }
}
