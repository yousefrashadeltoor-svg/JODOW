package com.aurora.get.feature.compressor

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil3.compose.AsyncImage
import com.aurora.get.common.Bytes
import com.aurora.get.designsystem.components.AuroraButton
import com.aurora.get.designsystem.components.AuroraProgressBar
import com.aurora.get.designsystem.components.GradientText
import com.aurora.get.designsystem.components.pressableScale
import com.aurora.get.designsystem.effects.MeshGradientBackground
import com.aurora.get.designsystem.glass.GlassChip
import com.aurora.get.designsystem.glass.GlassPanel
import com.aurora.get.designsystem.glass.rememberGlassBackgroundState
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import com.aurora.get.designsystem.theme.LocalAuroraTypography
import com.aurora.get.media.SmartCompressor
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

/**
 * Smart Compressor UI (spec §9): explicit dual mode, Before/After comparison slider,
 * byte-exact savings, and honest "no gain" messages. Never replaces the original
 * unless the user explicitly confirms.
 */

@HiltViewModel
class CompressorViewModel @Inject constructor(
    private val compressor: SmartCompressor,
) : ViewModel() {

    data class UiState(
        val inputPath: String? = null,
        val mode: SmartCompressor.Mode = SmartCompressor.Mode.LOSSLESS,
        val working: Boolean = false,
        val outcome: SmartCompressor.CompressOutcome? = null,
        val totalSavedBytes: Long = 0,
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    fun pick(path: String) = _state.update { it.copy(inputPath = path, outcome = null) }
    fun setMode(mode: SmartCompressor.Mode) = _state.update { it.copy(mode = mode) }

    fun compress() {
        val path = _state.value.inputPath ?: return
        viewModelScope.launch {
            _state.update { it.copy(working = true) }
            val outcome = compressor.compress(File(path), _state.value.mode)
            val saved = (outcome as? SmartCompressor.CompressOutcome.Saved)?.savedBytes ?: 0
            _state.update {
                it.copy(working = false, outcome = outcome, totalSavedBytes = it.totalSavedBytes + saved)
            }
        }
    }

    /** Only called when the user explicitly confirms replacing the original. */
    fun replaceOriginal() {
        val outcome = _state.value.outcome as? SmartCompressor.CompressOutcome.Saved ?: return
        val original = _state.value.inputPath?.let { File(it) } ?: return
        viewModelScope.launch {
            outcome.output.copyTo(original, overwrite = true)
            outcome.output.delete()
            _state.update { it.copy(outcome = null, inputPath = original.absolutePath) }
        }
    }
}

@Composable
fun CompressorScreen(viewModel: CompressorViewModel = hiltViewModel()) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val haze = rememberGlassBackgroundState()
    val state by viewModel.state.collectAsState()

    Box(Modifier.fillMaxSize()) {
        MeshGradientBackground(Modifier.matchParentSize().hazeSource(state = haze))
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(26.dp))
            GradientText("التصغير الذكي", t.headlineLarge)
            BasicText(
                "Lossless أو شفاف الجودة — والأصل محفوظ دائمًا",
                style = t.bodyMedium.copy(color = c.textSecondary),
            )
            Spacer(Modifier.height(16.dp))

            // ── Mode picker ──
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModeCard(
                    title = "بدون أي فقد",
                    subtitle = "Lossless · لا يتغير بكسل واحد",
                    selected = state.mode == SmartCompressor.Mode.LOSSLESS,
                    accent = c.success,
                    modifier = Modifier.weight(1f),
                ) { viewModel.setMode(SmartCompressor.Mode.LOSSLESS) }
                ModeCard(
                    title = "شفاف الجودة",
                    subtitle = "فقد غير ملحوظ · موثق بالمقاييس",
                    selected = state.mode == SmartCompressor.Mode.TRANSPARENT,
                    accent = c.warning,
                    modifier = Modifier.weight(1f),
                ) { viewModel.setMode(SmartCompressor.Mode.TRANSPARENT) }
            }

            Spacer(Modifier.height(16.dp))

            // ── Input + result ──
            val outcome = state.outcome
            when {
                state.working -> {
                    GlassPanel(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(20.dp)) {
                            BasicText("يعمل على الضغط…", style = t.titleMedium.copy(color = c.textPrimary))
                            Spacer(Modifier.height(12.dp))
                            AuroraProgressBar(0.5f, Modifier.fillMaxWidth())
                        }
                    }
                }
                outcome is SmartCompressor.CompressOutcome.Saved -> {
                    SavedPanel(outcome, state, onReplace = viewModel::replaceOriginal)
                }
                outcome is SmartCompressor.CompressOutcome.NoGain -> {
                    GlassPanel(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(20.dp)) {
                            BasicText("لم يُخفّض الحجم", style = t.titleMedium.copy(color = c.warning))
                            BasicText(outcome.reason, style = t.bodySmall.copy(color = c.textSecondary))
                        }
                    }
                }
                outcome is SmartCompressor.CompressOutcome.Failed -> {
                    GlassPanel(Modifier.fillMaxWidth()) {
                        BasicText(
                            outcome.cause.message ?: "فشل",
                            Modifier.padding(20.dp),
                            style = t.titleMedium.copy(color = c.error),
                        )
                    }
                }
                state.inputPath != null -> {
                    GlassPanel(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(20.dp)) {
                            BasicText(File(state.inputPath!!).name, style = t.titleMedium.copy(color = c.textPrimary))
                            BasicText(Bytes.exact(File(state.inputPath!!).length()),
                                style = t.mono.copy(color = c.textTertiary))
                            Spacer(Modifier.height(14.dp))
                            AuroraButton(onClick = viewModel::compress) {
                                BasicText(
                                    "اضغط الآن",
                                    Modifier.padding(horizontal = 20.dp, vertical = 11.dp),
                                    style = t.labelLarge.copy(color = c.onAccent),
                                )
                            }
                        }
                    }
                }
                else -> {
                    GlassPanel(Modifier.fillMaxWidth().pressableScale({ /* SAF picker via :app */ })) {
                        Column(
                            Modifier.fillMaxWidth().padding(36.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            EmptySuggest()
                            Spacer(Modifier.height(10.dp))
                            BasicText("اختر ملفًا لتصغيره", style = t.bodyMedium.copy(color = c.textSecondary))
                        }
                    }
                }
            }

            // cumulative savings chip
            if (state.totalSavedBytes > 0) {
                Spacer(Modifier.height(14.dp))
                GlassChip {
                    BasicText(
                        "إجمالي التوفير حتى الآن: ${Bytes.exact(state.totalSavedBytes)}",
                        Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        style = t.labelLarge.copy(color = c.success),
                    )
                }
            }
        }
    }
}

@Composable
private fun ModeCard(
    title: String, subtitle: String, selected: Boolean, accent: Color,
    modifier: Modifier = Modifier, onClick: () -> Unit,
) {
    val borderAlpha by animateFloatAsState(
        if (selected) 1f else 0f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "modeBorder",
    )
    val t = LocalAuroraTypography.current
    val c = AuroraTheme.colors
    GlassPanel(modifier.pressableScale(onClick), glowColor = if (selected) accent else Color.Unspecified) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(12.dp).background(accent, CircleShape)
                        .drawWithContent {
                            drawContent()
                            if (borderAlpha > 0f) drawCircle(accent, radius = size.minDimension, alpha = borderAlpha * 0.4f)
                        },
                )
                Spacer(Modifier.width(8.dp))
                BasicText(title, style = t.titleMedium.copy(color = c.textPrimary))
            }
            Spacer(Modifier.height(6.dp))
            BasicText(subtitle, style = t.bodySmall.copy(color = c.textTertiary))
        }
    }
}

/** Before/After comparison slider + byte-exact savings card. */
@Composable
private fun SavedPanel(
    outcome: SmartCompressor.CompressOutcome.Saved,
    state: CompressorViewModel.UiState,
    onReplace: () -> Unit,
) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    var slider by remember { mutableFloatStateOf(0.5f) }
    val isImage = outcome.output.extension.lowercase() in listOf("webp", "jpg", "jpeg", "png", "avif")

    GlassPanel {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            BasicText("وفّرت ${Bytes.exact(outcome.savedBytes)}",
                style = t.headlineMedium.copy(color = c.success))
            BasicText(
                "${Bytes.exactLong(outcome.before)}  ←  ${Bytes.exactLong(outcome.after)}",
                style = t.mono.copy(color = c.textSecondary),
            )
            BasicText("نسبة التوفير: %.1f%%".format(outcome.savedPercent),
                style = t.labelLarge.copy(color = c.brandPurple))

            if (isImage) {
                Spacer(Modifier.height(14.dp))
                // Before/after glass comparison slider
                Box(
                    Modifier.fillMaxWidth().height(220.dp).clip(LocalAuroraShapes.current.medium),
                ) {
                    AsyncImage(model = outcome.output, contentDescription = "بعد",
                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    AsyncImage(
                        model = state.inputPath, contentDescription = "قبل",
                        modifier = Modifier.fillMaxSize().drawWithContent {
                            val clipW = size.width * slider
                            clipPath(androidx.compose.ui.graphics.Path().apply {
                                addRect(androidx.compose.ui.geometry.Rect(0f, 0f, clipW, size.height))
                            }) { this@drawWithContent.drawContent() }
                        },
                        contentScale = ContentScale.Crop,
                    )
                    // divider handle
                    Box(
                        Modifier
                            .offset(x = (260 * slider).dp)
                            .width(3.dp)
                            .height(220.dp)
                            .background(c.brandGradient),
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AuroraButton(onClick = onReplace) {
                    BasicText("استبدل الأصل (بتأكيدك)", Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        style = t.labelLarge.copy(color = c.onAccent))
                }
                GlassChip {
                    BasicText("الأصل محفوظ افتراضيًا", Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        style = t.labelMedium.copy(color = c.textSecondary))
                }
            }
        }
    }
}

@Composable
private fun EmptySuggest() {
    val c = AuroraTheme.colors
    Box(
        Modifier.size(64.dp).background(c.brandGradient, LocalAuroraShapes.current.squircle),
        contentAlignment = Alignment.Center,
    ) {
        com.aurora.get.designsystem.components.AuroraIcon(
            com.aurora.get.designsystem.icons.AuroraIcons.Compress, null,
            tint = Color.White, modifier = Modifier.size(30.dp),
        )
    }
}
