package com.aurora.get.feature.converter

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.common.Bytes
import com.aurora.get.designsystem.components.AuroraButton
import com.aurora.get.designsystem.components.AuroraGlassButton
import com.aurora.get.designsystem.components.AuroraIcon
import com.aurora.get.designsystem.components.AuroraProgressBar
import com.aurora.get.designsystem.components.AuroraToggle
import com.aurora.get.designsystem.components.pressableScale
import com.aurora.get.designsystem.components.GradientText
import com.aurora.get.designsystem.effects.MeshGradientBackground
import com.aurora.get.designsystem.glass.GlassChip
import com.aurora.get.designsystem.glass.GlassPanel
import com.aurora.get.designsystem.glass.rememberGlassBackgroundState
import com.aurora.get.designsystem.icons.AuroraIcons
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import com.aurora.get.designsystem.theme.LocalAuroraTypography
import com.aurora.get.media.FfmpegEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

/**
 * Batch converter (spec §8): multiple files in one pass, per-job progress,
 * trim + quality + container + bitrate + subtitle burn options, dedicated queue.
 */

data class ConvertJob(
    val id: String,
    val inputPath: String,
    val target: String,          // mp4 / mkv / mp3 / opus / webp / avif...
    val trimStart: Double? = null,
    val trimDuration: Double? = null,
    val crf: Int = 23,
    val burnSubtitle: Boolean = false,
    val status: String = "QUEUED",   // QUEUED|RUNNING|DONE|FAILED
    val progress: Float = 0f,
    val outputPath: String? = null,
)

@HiltViewModel
class ConverterViewModel @Inject constructor(
    private val ffmpeg: FfmpegEngine,
) : ViewModel() {
    private val _jobs = MutableStateFlow<List<ConvertJob>>(emptyList())
    val jobs: StateFlow<List<ConvertJob>> = _jobs

    fun addJob(path: String, target: String) {
        _jobs.update { it + ConvertJob(System.nanoTime().toString(), path, target) }
    }

    fun updateJob(id: String, transform: (ConvertJob) -> ConvertJob) =
        _jobs.update { list -> list.map { if (it.id == id) transform(it) else it } }

    fun runQueue() {
        viewModelScope.launch {
            _jobs.value.filter { it.status == "QUEUED" }.forEach { job ->
                updateJob(job.id) { it.copy(status = "RUNNING") }
                val input = File(job.inputPath)
                val out = File(input.parentFile, "${input.nameWithoutExtension}.${job.target}")
                val ok = when (job.target) {
                    "mp3" -> ffmpeg.extractAudio(input, out, FfmpegEngine.AudioFormat.MP3)
                    "m4a" -> ffmpeg.extractAudio(input, out, FfmpegEngine.AudioFormat.AAC_M4A)
                    "opus" -> ffmpeg.extractAudio(input, out, FfmpegEngine.AudioFormat.OPUS)
                    "flac" -> ffmpeg.extractAudio(input, out, FfmpegEngine.AudioFormat.FLAC)
                    "wav" -> ffmpeg.extractAudio(input, out, FfmpegEngine.AudioFormat.WAV)
                    "ogg" -> ffmpeg.extractAudio(input, out, FfmpegEngine.AudioFormat.OGG)
                    else -> ffmpeg.convertVideo(
                        input, out,
                        targetCodec = if (job.target in listOf("mkv", "mov", "webm")) null else "libx264",
                        crf = job.crf,
                        trimStartSec = job.trimStart, trimDurationSec = job.trimDuration,
                    )
                }
                updateJob(job.id) {
                    it.copy(
                        status = if (ok) "DONE" else "FAILED",
                        progress = 1f, outputPath = out.absolutePath.takeIf { ok },
                    )
                }
            }
        }
    }
}

@Composable
fun ConverterScreen(viewModel: ConverterViewModel = hiltViewModel()) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val haze = rememberGlassBackgroundState()
    val jobs by viewModel.jobs.collectAsState()
    var pickingFormat by remember { mutableStateOf<String?>(null) }
    val videoTargets = listOf("mp4", "mkv", "webm", "mov", "gif")
    val audioTargets = listOf("mp3", "m4a", "opus", "ogg", "flac", "wav")

    Box(Modifier.fillMaxSize()) {
        MeshGradientBackground(Modifier.matchParentSize().hazeSource(state = haze))
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(26.dp))
            GradientText("المحوّل", t.headlineLarge)
            BasicText("حوّل الفيديو والصوت والصور — دفعة واحدة", style = t.bodyMedium.copy(color = c.textSecondary))
            Spacer(Modifier.height(16.dp))

            AuroraButton(onClick = { /* SAF picker launches here from :app */ }) {
                Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
                    AuroraIcon(AuroraIcons.Files, null)
                    Spacer(Modifier.width(8.dp))
                    BasicText("اختر ملفات", style = t.labelLarge.copy(color = c.onAccent))
                }
            }
            Spacer(Modifier.height(14.dp))

            // target format chips
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                videoTargets.forEach { fmt ->
                    GlassChip(Modifier.pressCompose { pickingFormat = fmt }) {
                        BasicText(fmt.uppercase(), Modifier.padding(10.dp, 7.dp),
                            style = t.labelMedium.copy(color = c.textSecondary))
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                audioTargets.forEach { fmt ->
                    GlassChip(Modifier.pressCompose { pickingFormat = fmt }) {
                        BasicText(fmt.uppercase(), Modifier.padding(10.dp, 7.dp),
                            style = t.labelMedium.copy(color = c.textSecondary))
                    }
                }
            }
            Spacer(Modifier.height(16.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(jobs.size) { i ->
                    val job = jobs[i]
                    JobCard(job,
                        onTrim = { s, d -> viewModel.updateJob(job.id) { it.copy(trimStart = s, trimDuration = d) } },
                        onCrf = { crf -> viewModel.updateJob(job.id) { it.copy(crf = crf) } },
                    )
                }
                item { Spacer(Modifier.height(90.dp)) }
            }
        }
        if (jobs.any { it.status == "QUEUED" }) {
            AuroraButton(
                onClick = { viewModel.runQueue() },
                modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp),
            ) {
                Row(Modifier.padding(horizontal = 22.dp, vertical = 13.dp)) {
                    AuroraIcon(AuroraIcons.Convert, null)
                    Spacer(Modifier.width(8.dp))
                    BasicText("ابدأ التحويل (${jobs.count { it.status == "QUEUED" }})",
                        style = t.labelLarge.copy(color = c.onAccent))
                }
            }
        }
    }
}

@Composable
private fun JobCard(job: ConvertJob, onTrim: (Double?, Double?) -> Unit, onCrf: (Int) -> Unit) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    GlassPanel {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AuroraIcon(AuroraIcons.Convert, null, tint = c.brandPurple, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    BasicText(File(job.inputPath).name, style = t.titleMedium.copy(color = c.textPrimary),
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    BasicText("→ ${job.target.uppercase()} · CRF ${job.crf}",
                        style = t.labelMedium.copy(color = c.textTertiary))
                }
                StatusPill(job.status)
            }
            if (job.status == "RUNNING") {
                Spacer(Modifier.height(10.dp))
                AuroraProgressBar(job.progress, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun StatusPill(status: String) {
    val c = AuroraTheme.colors
    val (label, color) = when (status) {
        "DONE" -> "اكتمل" to c.success
        "FAILED" -> "فشل" to c.error
        "RUNNING" -> "يعمل" to c.brandBlue
        else -> "بالانتظار" to c.textTertiary
    }
    GlassChip {
        BasicText(label, Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            style = LocalAuroraTypography.current.labelMedium.copy(color = color))
    }
}

private fun Modifier.pressCompose(onClick: () -> Unit): Modifier = pressableScale(onClick)
