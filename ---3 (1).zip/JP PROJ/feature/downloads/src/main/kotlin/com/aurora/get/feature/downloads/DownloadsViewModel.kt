package com.aurora.get.feature.downloads

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.common.MediaKind
import com.aurora.get.db.DownloadDao
import com.aurora.get.db.DownloadEntity
import com.aurora.get.downloader.DownloadQueue
import com.aurora.get.downloader.SegmentedDownloader
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    private val downloads: DownloadDao,
    private val queue: DownloadQueue,
) : ViewModel() {

    enum class Tab(val label: String) {
        ALL("الكل"), RUNNING("جارٍ"), QUEUED("في الانتظار"), COMPLETED("مكتمل"), FAILED("فاشل");

        fun matches(status: String): Boolean = when (this) {
            ALL -> true
            RUNNING -> status in listOf("RUNNING", "MERGING")
            QUEUED -> status == "QUEUED"
            COMPLETED -> status == "COMPLETED"
            FAILED -> status == "FAILED"
        }
    }

    enum class KindFilter(val label: String?) {
        ALL(null), VIDEO("فيديو"), AUDIO("صوت"), IMAGE("صور"), FILE("ملفات");

        fun matches(kind: MediaKind): Boolean = when (this) {
            ALL -> true
            VIDEO -> kind == MediaKind.VIDEO
            AUDIO -> kind == MediaKind.AUDIO
            IMAGE -> kind == MediaKind.IMAGE
            FILE -> kind == MediaKind.FILE
        }
    }

    data class UiState(
        val items: List<DownloadEntity> = emptyList(),
        val running: Map<String, SegmentedDownloader.Progress> = emptyMap(),
        val tab: Tab = Tab.ALL,
        val kind: KindFilter = KindFilter.ALL,
        val maxConcurrent: Int = 3,
    )

    private val tab = MutableStateFlow(Tab.ALL)
    private val kind = MutableStateFlow(KindFilter.ALL)

    val state: StateFlow<UiState> = combine(
        downloads.observeAll(), queue.running, tab, kind,
    ) { list, running, t, k ->
        UiState(
            items = list.filter { t.matches(it.status) && k.matches(it.kind) },
            running = running, tab = t, kind = k,
            maxConcurrent = queue.maxConcurrent,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState())

    fun selectTab(t: Tab) { tab.value = t }
    fun selectKind(k: KindFilter) { kind.value = k }

    fun pause(id: String) = queue.pause(id)
    fun resume(id: String) = queue.resume(id)
    fun cancel(id: String) = viewModelScope.launch { queue.cancel(id) }
    fun retry(id: String) = viewModelScope.launch {
        downloads.setStatus(id, "QUEUED"); queue.resume(id)
    }
    fun remove(id: String) = viewModelScope.launch {
        downloads.byId(id)?.let { downloads.delete(it) }
    }
    fun reorder(ids: List<String>) = viewModelScope.launch { queue.reorder(ids) }
    fun setMaxConcurrent(n: Int) { queue.maxConcurrent = n }
    fun clearFinished() = viewModelScope.launch {
        downloads.byStatus("COMPLETED").forEach { downloads.delete(it) }
    }
}
