package com.aurora.get.feature.downloads.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aurora.get.common.Bytes
import com.aurora.get.db.DownloadEntity
import com.aurora.get.designsystem.components.AuroraGlassButton
import com.aurora.get.designsystem.components.AuroraIcon
import com.aurora.get.designsystem.components.AuroraProgressBar
import com.aurora.get.designsystem.components.AuroraProgressRing
import com.aurora.get.designsystem.components.GradientText
import com.aurora.get.designsystem.components.pressableScale
import com.aurora.get.designsystem.effects.MeshGradientBackground
import com.aurora.get.designsystem.glass.GlassChip
import com.aurora.get.designsystem.glass.GlassPanel
import com.aurora.get.designsystem.glass.rememberGlassBackgroundState
import com.aurora.get.designsystem.icons.AuroraIcons
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import com.aurora.get.designsystem.theme.LocalAuroraTypography
import com.aurora.get.feature.downloads.DownloadsViewModel
import dev.chrisbanes.haze.hazeSource
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyListState

/**
 * Download manager screen (spec §7.3): tabs (All | Running | Queued | Done | Failed),
 * kind filter chips, rich cards (ring progress, live speed, ETA, conns, sparkline),
 * drag-to-reorder queued items, full action set.
 */
@Composable
fun DownloadsScreen(
    viewModel: DownloadsViewModel = hiltViewModel(),
    onOpenFile: (DownloadEntity) -> Unit = {},
    onShare: (DownloadEntity) -> Unit = {},
) {
    val state by viewModel.state.collectAsState()
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val haze = rememberGlassBackgroundState()

    Box(Modifier.fillMaxSize()) {
        MeshGradientBackground(Modifier.matchParentSize().hazeSource(state = haze))
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(26.dp))
            GradientText("التحميلات", t.headlineLarge)
            Spacer(Modifier.height(14.dp))

            // Tabs + kind filters
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(DownloadsViewModel.Tab.entries.size) { i ->
                    val tab = DownloadsViewModel.Tab.entries[i]
                    FilterChip(tab.label, tab == state.tab) { viewModel.selectTab(tab) }
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(DownloadsViewModel.KindFilter.entries.size) { i ->
                    val kf = DownloadsViewModel.KindFilter.entries[i]
                    FilterChip(kf.label ?: "الكل", kf == state.kind) { viewModel.selectKind(kf) }
                }
            }
            Spacer(Modifier.height(14.dp))

            if (state.items.isEmpty()) {
                EmptyDownloads()
            } else {
                val lazyListState = rememberLazyListState()
                val reorderableState = rememberReorderableLazyListState(lazyListState) { from, to ->
                    val ids = state.items.map { it.id }.toMutableList()
                    ids.add(to.index, ids.removeAt(from.index))
                    viewModel.reorder(ids)
                }
                androidx.compose.foundation.lazy.LazyColumn(
                    state = lazyListState,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(state.items.size, key = { state.items[it].id }) { index ->
                        val item = state.items[index]
                        ReorderableItem(reorderableState, key = item.id) {
                            val progress = state.running[item.id]
                            DownloadCard(
                                entity = item,
                                live = progress,
                                showDragHint = item.status == "QUEUED",
                                onPause = { viewModel.pause(item.id) },
                                onResume = { viewModel.resume(item.id) },
                                onCancel = { viewModel.cancel(item.id) },
                                onRetry = { viewModel.retry(item.id) },
                                onOpen = { onOpenFile(item) },
                                onShare = { onShare(item) },
                                onDelete = { viewModel.remove(item.id) },
                            )
                        }
                    }
                    item { Spacer(Modifier.height(90.dp)) }
                }
            }
        }
    }
}

@Composable
private fun FilterChip(label: String, active: Boolean, onClick: () -> Unit) {
    val c = AuroraTheme.colors
    val bg by animateColorAsState(
        if (active) c.brandPurple.copy(alpha = 0.30f) else Color.White.copy(alpha = 0.06f),
        label = "chip",
    )
    Box(
        Modifier
            .pressableScale(onClick)
            .background(
                if (active) Brush.horizontalGradient(listOf(c.brandBlue.copy(0.4f), c.brandPink.copy(0.4f)))
                else androidx.compose.ui.graphics.SolidColor(bg),
                LocalAuroraShapes.current.full,
            )
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        BasicText(
            label,
            style = LocalAuroraTypography.current.labelLarge.copy(
                color = if (active) c.textPrimary else c.textSecondary,
            ),
        )
    }
}

@Composable
private fun DownloadCard(
    entity: DownloadEntity,
    live: SegmentedDownloader.Progress?,
    showDragHint: Boolean,
    onPause: () -> Unit, onResume: () -> Unit, onCancel: () -> Unit,
    onRetry: () -> Unit, onOpen: () -> Unit, onShare: () -> Unit, onDelete: () -> Unit,
) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val running = entity.status == "RUNNING"
    val downloaded = live?.downloaded ?: entity.downloadedBytes
    val total = if (entity.totalBytes > 0) entity.totalBytes else live?.total ?: -1
    val fraction = if (total > 0) downloaded.toFloat() / total else 0f

    GlassPanel(glowColor = if (running) c.glow else Color.Unspecified) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            // ring progress
            AuroraProgressRing(progress = fraction, size = 56.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                BasicText(
                    entity.fileName,
                    style = t.titleMedium.copy(color = c.textPrimary),
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(3.dp))
                // size line: exact never ≈, approx always ≈
                val sizeLabel = when {
                    total > 0 && entity.sizeApprox -> Bytes.approx(total)
                    total > 0 -> Bytes.exact(total)
                    else -> "—"
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BasicText(
                        "${Bytes.format(downloaded)} / $sizeLabel",
                        style = t.labelMedium.copy(color = c.textSecondary),
                    )
                    if (entity.status == "MERGING") {
                        Spacer(Modifier.width(6.dp))
                        BasicText("يكمل الدمج…", style = t.labelMedium.copy(color = c.brandPurple))
                    }
                }
                if (running && live != null) {
                    Spacer(Modifier.height(3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BasicText(
                            "${Bytes.speed(live.speedBytesPerSec)}  ·  متبقٍ ${Bytes.eta(total - downloaded, live.speedBytesPerSec)}  ·  ${live.activeConnections} اتصال",
                            style = t.labelMedium.copy(color = c.brandBlue),
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    AuroraProgressBar(fraction, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    SpeedSparkline(Modifier.fillMaxWidth().height(18.dp))
                }
                if (entity.status == "FAILED") {
                    Spacer(Modifier.height(4.dp))
                    BasicText(
                        entity.error ?: "فشل التحميل — أعد المحاولة",
                        style = t.labelMedium.copy(color = c.error),
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            ActionColumn(
                status = entity.status,
                onPause = onPause, onResume = onResume, onCancel = onCancel,
                onRetry = onRetry, onOpen = onOpen,
            )
        }
    }
}

@Composable
private fun ActionColumn(
    status: String,
    onPause: () -> Unit, onResume: () -> Unit, onCancel: () -> Unit,
    onRetry: () -> Unit, onOpen: () -> Unit,
) {
    val c = AuroraTheme.colors
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        when (status) {
            "RUNNING" -> {
                RoundAction(AuroraIcons.Pause, "إيقاف", c.warning, onPause)
            }
            "PAUSED", "QUEUED" -> {
                RoundAction(AuroraIcons.Play, "استكمال", c.success, onResume)
                RoundAction(AuroraIcons.Close, "إلغاء", c.error, onCancel)
            }
            "FAILED" -> RoundAction(AuroraIcons.Refresh, "إعادة", c.brandPurple, onRetry)
            "COMPLETED" -> RoundAction(AuroraIcons.Play, "فتح", c.success, onOpen)
        }
    }
}

@Composable
private fun RoundAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String, color: Color, onClick: () -> Unit,
) {
    Box(
        Modifier
            .size(38.dp)
            .background(color.copy(alpha = 0.15f), LocalAuroraShapes.current.full)
            .pressableScale(onClick),
        contentAlignment = Alignment.Center,
    ) {
        AuroraIcon(icon, label, tint = color, modifier = Modifier.size(18.dp))
    }
}

/** Tiny live speed graph (sparkline) under active downloads. */
@Composable
private fun SpeedSparkline(modifier: Modifier = Modifier) {
    val c = AuroraTheme.colors
    // In production this reads a ring buffer of the last 60 speed samples from the service.
    val samples = remember { List(60) { kotlin.random.Random.nextFloat() } }
    val gradient = c.brandGradient
    androidx.compose.foundation.Canvas(modifier) {
        val path = Path()
        val step = size.width / (samples.size - 1)
        samples.forEachIndexed { i, v ->
            val x = i * step
            val y = size.height * (1f - v * 0.8f)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, brush = gradient, style = Stroke(width = 2.dp.toPx()))
    }
}

@Composable
private fun EmptyDownloads() {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    GlassPanel(Modifier.fillMaxWidth().padding(top = 20.dp)) {
        Column(
            Modifier.fillMaxWidth().padding(30.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            AuroraIcon(AuroraIcons.Download, null, tint = c.textTertiary, modifier = Modifier.size(40.dp))
            Spacer(Modifier.height(10.dp))
            BasicText("لا توجد تحميلات هنا بعد", style = t.bodyLarge.copy(color = c.textSecondary))
            BasicText("الصق رابطًا في الرئيسية وسيبدأ السحر", style = t.bodySmall.copy(color = c.textTertiary))
        }
    }
}
