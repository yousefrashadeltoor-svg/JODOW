package com.aurora.get.feature.settings

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.designsystem.components.AuroraIcon
import com.aurora.get.designsystem.components.AuroraToggle
import com.aurora.get.designsystem.components.GradientText
import com.aurora.get.designsystem.components.pressableScale
import com.aurora.get.designsystem.effects.MeshGradientBackground
import com.aurora.get.designsystem.glass.GlassPanel
import com.aurora.get.designsystem.glass.rememberGlassBackgroundState
import com.aurora.get.designsystem.icons.AuroraIcons
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.AuroraThemeId
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import com.aurora.get.designsystem.theme.LocalAuroraTypography
import com.aurora.get.designsystem.theme.paletteFor
import com.aurora.get.designsystem.theme.AuroraThemes
import com.aurora.get.designsystem.theme.ThemeController
import com.aurora.get.designsystem.theme.previewFor
import coil3.compose.AsyncImage
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.layout.ContentScale
import com.aurora.get.extractors.ytdlp.YtDlpExtractor
import com.aurora.get.feature.browser.AdBlockEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

private val Context.auroraDataStore by preferencesDataStore("aurora_settings")

/** All user preferences — DataStore-backed, offline, private. */
data class AuroraPrefs(
    val theme: AuroraThemeId = AuroraThemeId.AURORA,
    val dynamicColor: Boolean = true,           // tint UI from dominant artwork color
    val connections: Int = 16,
    val wifiOnly: Boolean = false,
    val chargingOnly: Boolean = false,
    val lowBatteryPause: Boolean = true,
    val dataSaver: Boolean = false,
    val dnsOverHttps: Boolean = false,
    val adBlock: Boolean = true,
    val blockCookieBanners: Boolean = true,
    val haptics: Boolean = true,
    val clipboardWatch: Boolean = true,
    val downloadDirPerSite: Boolean = true,
    val autoUpdateYtDlp: Boolean = true,
    val autoUpdateBlocklists: Boolean = true,
    val hashCheck: Boolean = false,              // MD5/SHA-256 post-download verify
    val arabic: Boolean = true,
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val ytDlp: YtDlpExtractor,
    private val adBlock: AdBlockEngine,
) : ViewModel() {

    private val _prefs = MutableStateFlow(AuroraPrefs())
    val prefs: StateFlow<AuroraPrefs> = _prefs
    private val _engineStatus = MutableStateFlow("جاهز")
    val engineStatus: StateFlow<String> = _engineStatus

    init {
        viewModelScope.launch {
            context.auroraDataStore.data.collect { p ->
                _prefs.value = AuroraPrefs(
                    theme = runCatching {
                        AuroraThemeId.valueOf(p[stringPreferencesKey("theme")] ?: "AURORA")
                    }.getOrDefault(AuroraThemeId.AURORA),
                    dynamicColor = p[booleanPreferencesKey("dyn")] ?: true,
                    connections = p[intPreferencesKey("conn")] ?: 16,
                    wifiOnly = p[booleanPreferencesKey("wifi")] ?: false,
                    chargingOnly = p[booleanPreferencesKey("charging")] ?: false,
                    lowBatteryPause = p[booleanPreferencesKey("battery")] ?: true,
                    dataSaver = p[booleanPreferencesKey("saver")] ?: false,
                    dnsOverHttps = p[booleanPreferencesKey("doh")] ?: false,
                    adBlock = p[booleanPreferencesKey("adblock")] ?: true,
                    blockCookieBanners = p[booleanPreferencesKey("cookiebanners")] ?: true,
                    haptics = p[booleanPreferencesKey("haptics")] ?: true,
                    clipboardWatch = p[booleanPreferencesKey("clipboard")] ?: true,
                    downloadDirPerSite = p[booleanPreferencesKey("persite")] ?: true,
                    autoUpdateYtDlp = p[booleanPreferencesKey("ytdlpupdate")] ?: true,
                    autoUpdateBlocklists = p[booleanPreferencesKey("listupdate")] ?: true,
                    hashCheck = p[booleanPreferencesKey("hash")] ?: false,
                    arabic = p[booleanPreferencesKey("arabic")] ?: true,
                )
            }
        }
    }

    fun update(t: (AuroraPrefs) -> AuroraPrefs) {
        val next = t(_prefs.value)
        _prefs.value = next
        viewModelScope.launch {
            context.auroraDataStore.edit { p ->
                p[stringPreferencesKey("theme")] = next.theme.name
                p[booleanPreferencesKey("dyn")] = next.dynamicColor
                p[intPreferencesKey("conn")] = next.connections
                p[booleanPreferencesKey("wifi")] = next.wifiOnly
                p[booleanPreferencesKey("charging")] = next.chargingOnly
                p[booleanPreferencesKey("battery")] = next.lowBatteryPause
                p[booleanPreferencesKey("saver")] = next.dataSaver
                p[booleanPreferencesKey("doh")] = next.dnsOverHttps
                p[booleanPreferencesKey("adblock")] = next.adBlock
                p[booleanPreferencesKey("cookiebanners")] = next.blockCookieBanners
                p[booleanPreferencesKey("haptics")] = next.haptics
                p[booleanPreferencesKey("clipboard")] = next.clipboardWatch
                p[booleanPreferencesKey("persite")] = next.downloadDirPerSite
                p[booleanPreferencesKey("ytdlpupdate")] = next.autoUpdateYtDlp
                p[booleanPreferencesKey("listupdate")] = next.autoUpdateBlocklists
                p[booleanPreferencesKey("hash")] = next.hashCheck
                p[booleanPreferencesKey("arabic")] = next.arabic
            }
            adBlock.setEnabled(next.adBlock)
        }
    }

    fun updateEngineNow() {
        viewModelScope.launch {
            _engineStatus.value = "يحدّث yt-dlp…"
            val ok = ytDlp.updateEngine()
            _engineStatus.value = if (ok) "تم التحديث" else "تعذر التحديث — تحقق من الشبكة"
        }
    }

    fun updateBlocklistsNow() {
        viewModelScope.launch {
            _engineStatus.value = "يحدّث قوائم الحجب…"
            val count = adBlock.updateLists()
            _engineStatus.value = "القوائم تضم $count مضيفًا"
        }
    }
}

@Composable
fun SettingsScreen(viewModel: SettingsViewModel = hiltViewModel()) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val haze = rememberGlassBackgroundState()
    val prefs by viewModel.prefs.collectAsState()
    val engineStatus by viewModel.engineStatus.collectAsState()

    Box(Modifier.fillMaxSize()) {
        MeshGradientBackground(Modifier.matchParentSize().hazeSource(state = haze))
        Column(
            Modifier.fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp),
        ) {
            Spacer(Modifier.height(26.dp))
            GradientText("الإعدادات", t.headlineLarge)
            Spacer(Modifier.height(16.dp))

            // ── Themes ──
            SectionHeader("المظهر")
            GlassPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    BasicText("الثيم", style = t.titleMedium.copy(color = c.textPrimary))
                    Spacer(Modifier.height(10.dp))
                    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(AuroraThemes.size) { i ->
                            val spec = AuroraThemes[i]
                            ThemeCard(
                                spec = spec,
                                selected = prefs.theme == spec.id,
                            ) {
                                ThemeController.select(spec.id)
                                viewModel.update { it.copy(theme = spec.id) }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    BasicText(
                        "كل ثيم يتحكم في الخلفية والألوان والزجاج وألوان الأنواع وسرعة الأنيميشن.",
                        style = t.labelMedium.copy(color = c.textTertiary),
                    )
                    Spacer(Modifier.height(6.dp))
                    ToggleRow("تلوين الواجهة من الغلاف", "Dynamic color from artwork palette",
                        prefs.dynamicColor) { v -> viewModel.update { it.copy(dynamicColor = v) } }
                }
            }

            Spacer(Modifier.height(14.dp))

            // ── Downloads ──
            SectionHeader("التحميل")
            GlassPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    BasicText("الاتصالات لكل تحميل: ${prefs.connections}", style = t.titleMedium.copy(color = c.textPrimary))
                    BasicText("من 8 إلى 32 — يتكيف مع السرعة تلقائيًا", style = t.bodySmall.copy(color = c.textTertiary))
                    Spacer(Modifier.height(10.dp))
                    ToggleRow("شبكة Wi-Fi فقط", null, prefs.wifiOnly) { v -> viewModel.update { it.copy(wifiOnly = v) } }
                    ToggleRow("أثناء الشحن فقط", null, prefs.chargingOnly) { v -> viewModel.update { it.copy(chargingOnly = v) } }
                    ToggleRow("إيقاف عند ضعف البطارية", null, prefs.lowBatteryPause) { v -> viewModel.update { it.copy(lowBatteryPause = v) } }
                    ToggleRow("فحص السلامة بالتجزئة (Hash)", "SHA-256 عند اكتمال أي ملف", prefs.hashCheck) { v -> viewModel.update { it.copy(hashCheck = v) } }
                    ToggleRow("مجلد لكل موقع", null, prefs.downloadDirPerSite) { v -> viewModel.update { it.copy(downloadDirPerSite = v) } }
                }
            }

            Spacer(Modifier.height(14.dp))

            // ── Network & privacy ──
            SectionHeader("الشبكة والخصوصية")
            GlassPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    ToggleRow("توفير البيانات", "يحد من الاتصالات والمعاينات", prefs.dataSaver) { v -> viewModel.update { it.copy(dataSaver = v) } }
                    ToggleRow("DNS عبر HTTPS", null, prefs.dnsOverHttps) { v -> viewModel.update { it.copy(dnsOverHttps = v) } }
                    ToggleRow("مراقبة الحافظة", "شارة غير مزعجة عند اكتشاف رابط", prefs.clipboardWatch) { v -> viewModel.update { it.copy(clipboardWatch = v) } }
                }
            }

            Spacer(Modifier.height(14.dp))

            // ── AdBlock & engine updates ──
            SectionHeader("حجب الإعلانات والتحديثات")
            GlassPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    ToggleRow("حجب الإعلانات", "EasyList + EasyPrivacy", prefs.adBlock) { v -> viewModel.update { it.copy(adBlock = v) } }
                    ToggleRow("إخفاء لافتات الكوكيز", null, prefs.blockCookieBanners) { v -> viewModel.update { it.copy(blockCookieBanners = v) } }
                    basicDivider()
                    RowItem("تحديث yt-dlp الآن", engineStatus) { viewModel.updateEngineNow() }
                    RowItem("تحديث قوائم الحجب", null) { viewModel.updateBlocklistsNow() }
                    BasicText("يُحدَّث تلقائيًا في الخلفية عند بدء التطبيق",
                        style = t.bodySmall.copy(color = c.textTertiary))
                }
            }

            Spacer(Modifier.height(14.dp))

            // ── Legal reminder ──
            GlassPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    BasicText("المسؤولية القانونية", style = t.titleMedium.copy(color = c.warning))
                    BasicText(
                        "المسؤولية على المستخدم في احترام حقوق النشر وشروط كل موقع. لا يتجاوز التطبيق أي حماية DRM أو اشتراك مدفوع.",
                        style = t.bodySmall.copy(color = c.textSecondary),
                    )
                }
            }
            Spacer(Modifier.height(110.dp))
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    BasicText(
        title, Modifier.padding(bottom = 8.dp, start = 4.dp),
        style = LocalAuroraTypography.current.labelLarge.copy(color = AuroraTheme.colors.textTertiary),
    )
}

@Composable
private fun ToggleRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            BasicText(title, style = t.bodyLarge.copy(color = c.textPrimary))
            subtitle?.let { BasicText(it, style = t.bodySmall.copy(color = c.textTertiary)) }
        }
        AuroraToggle(checked, onChange)
    }
}

@Composable
private fun RowItem(title: String, value: String?, onClick: () -> Unit) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp).pressableScale(onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BasicText(title, style = t.bodyLarge.copy(color = c.textPrimary), modifier = Modifier.weight(1f))
        value?.let { BasicText(it, style = t.bodySmall.copy(color = c.textTertiary)) }
        AuroraIcon(AuroraIcons.Refresh, null, tint = c.textTertiary, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun ThemeDot(
    brush: androidx.compose.ui.graphics.Brush, selected: Boolean, dark: Boolean, onClick: () -> Unit,
) {
    val c = AuroraTheme.colors
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(brush)
            .pressableScale(onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Box(Modifier.size(14.dp).clip(CircleShape).background(if (dark) Color.White else c.background))
        }
    }
}

@Composable
private fun basicDivider() {
    Box(
        Modifier.fillMaxWidth().padding(vertical = 8.dp).height(1.dp)
            .background(Color.White.copy(alpha = 0.08f)),
    )
}


/** Theme card with a real photographic preview bundled in the APK. */
@Composable
private fun ThemeCard(
    spec: com.aurora.get.designsystem.theme.AuroraThemeSpec,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val t = LocalAuroraTypography.current
    val c = AuroraTheme.colors
    Box(
        Modifier
            .width(132.dp)
            .pressableScale(onClick),
    ) {
        GlassPanel(
            shape = LocalAuroraShapes.current.medium,
            glowColor = if (selected) spec.colors.glow else Color.Unspecified,
        ) {
            Column {
                AsyncImage(
                    model = previewFor(spec.id),
                    contentDescription = spec.nameAr,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(78.dp),
                )
                Column(Modifier.padding(10.dp)) {
                    BasicText(spec.nameAr, style = t.titleMedium.copy(color = c.textPrimary))
                    BasicText(spec.tagline, style = t.labelMedium.copy(color = c.textTertiary), maxLines = 1)
                }
            }
        }
        if (selected) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .background(c.brandGradient, LocalAuroraShapes.current.full)
                    .padding(horizontal = 8.dp, vertical = 3.dp),
            ) {
                BasicText("مفعّل", style = t.labelMedium.copy(color = c.onAccent))
            }
        }
    }
}
