package com.aurora.get.analyzer

import com.aurora.get.common.MediaKind
import com.aurora.get.common.SizeInfo
import com.aurora.get.db.AnalysisCacheDao
import com.aurora.get.db.AnalysisCacheEntity
import com.aurora.get.extractors.extractors_native.NativeFastPath
import com.aurora.get.extractors.model.EngineKind
import com.aurora.get.extractors.model.ExtractedMedia
import com.aurora.get.extractors.model.FormatOption
import com.aurora.get.extractors.model.SmartButtons
import com.aurora.get.extractors.ytdlp.YtDlpExtractor
import com.aurora.get.network.Preconnect
import com.aurora.get.network.RedirectResolver
import com.aurora.get.network.SizeResolver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import timber.log.Timber
import java.net.URI
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The 5-stage parallel analysis pipeline (spec §4.2).
 * Every stage emits its partial result as soon as it lands; later stages enrich the card.
 * A new link cancels the previous analysis instantly (collectLatest upstream).
 */
class LinkAnalyzer @Inject constructor(
    private val sizeResolver: SizeResolver,
    private val redirectResolver: RedirectResolver,
    private val nativeFastPath: NativeFastPath,
    private val ytDlp: YtDlpExtractor,
    private val preconnect: Preconnect,
    private val cache: AnalysisCacheDao,
    private val json: Json,
) {
    /** UI consumes these in order; each event carries a monotonically merging snapshot. */
    sealed interface Event {
        /** Stage 0 — instant: cleaned URL, domain, cached logo. */
        data class DomainReady(val snapshot: AnalysisSnapshot) : Event
        /** Stage 1 — HEAD/Range probe: real size/type + OpenGraph basics. */
        data class Probed(val snapshot: AnalysisSnapshot) : Event
        /** Stage 2 — fast native extraction on popular sites. */
        data class FastPath(val snapshot: AnalysisSnapshot) : Event
        /** Stage 3 — full yt-dlp: all formats/codecs/subtitles/merge info. */
        data class Full(val snapshot: AnalysisSnapshot) : Event
        /** Stage 4 fallback suggestions (open in internal browser etc.). */
        data class FallbackSuggestion(val reason: String, val canSniffInBrowser: Boolean) : Event
        data class Failed(val cause: Throwable) : Event
    }

    data class AnalysisSnapshot(
        val media: ExtractedMedia,
        val directProbe: SizeResolver.ProbeResult? = null,
        val smartButtons: SmartButtons = SmartButtons(emptyList(), emptyList(), emptyList(), emptyList()),
        val resolvedSizes: Map<String, SizeInfo> = emptyMap(), // formatId → real size
        val stage: Int = 0,
    )

    fun analyze(rawInput: String): Flow<Event> = channelFlow {
        val cleaned = cleanUrl(rawInput) ?: run {
            send(Event.FallbackSuggestion("لا يبدو رابطًا صالحًا", canSniffInBrowser = false))
            return@channelFlow
        }

        // ── Cache hit (TTL-guarded) short-circuits everything ──
        cache.get(cleaned)?.takeIf { it.createdAt + it.ttlMs > System.currentTimeMillis() }?.let { hit ->
            runCatching {
                val media = json.decodeFromString<ExtractedMediaSurrogate>(hit.resultJson).toMedia()
                val buttons = SmartButtons.fromFormats(media.formats)
                send(Event.Full(AnalysisSnapshot(media, smartButtons = buttons, stage = 3)))
                return@channelFlow
            }
        }

        val domain = runCatching { URI(cleaned).host?.removePrefix("www.").orEmpty() }.getOrDefault("")

        // ── Stage 0 (< 50ms): normalize, domain, cached favicon — instant ──
        val stage0 = ExtractedMedia(
            sourceUrl = cleaned, domain = domain,
            siteName = domain, faviconUrl = faviconCandidates(domain).firstOrNull(),
            kind = kindFromExtension(URI(cleaned).path.orEmpty()),
        )
        send(Event.DomainReady(AnalysisSnapshot(stage0, stage = 0)))
        launch { preconnect.warm(domain) } // spec: TCP/TLS preconnect on domain discovery

        coroutineScope {
            // ── Stage 1: HEAD / Range probe + OpenGraph — parallel with later stages ──
            val probeJob = async {
                val probe = sizeResolver.resolve(cleaned)
                if (probe.size != null || probe.mimeType != null) {
                    val kind = kindFromMime(probe.mimeType, cleaned)
                    val isDirectFile = probe.mimeType != null && probe.mimeType != "text/html"
                    val media = stage0.copy(
                        kind = kind,
                        title = probe.fileName ?: fileNameFromUrl(cleaned),
                        originalFileName = probe.fileName,
                    )
                    val formats = if (isDirectFile) listOf(
                        FormatOption(
                            id = "direct", kind = kind, label = "الملف الأصلي",
                            container = cleaned.substringAfterLast('.', "bin"),
                            url = probe.finalUrl, size = probe.size,
                        )
                    ) else emptyList()
                    val snap = AnalysisSnapshot(
                        media = media, directProbe = probe,
                        smartButtons = SmartButtons.fromFormats(formats), stage = 1,
                    )
                    send(Event.Probed(snap))
                    if (isDirectFile) {
                        // Direct file — yt-dlp is unnecessary; finish early.
                        persist(cleaned, media)
                        send(Event.Full(snap))
                        return@async true
                    }
                }
                false
            }

            // ── Stage 2: native fast path for popular sites ──
            val fastJob = async {
                if (!nativeFastPath.supports(domain)) return@async false
                withTimeoutOrNull(1500) {
                    nativeFastPath.extract(cleaned, domain)?.let { media ->
                        val buttons = SmartButtons.fromFormats(media.formats)
                        send(Event.FastPath(AnalysisSnapshot(media, smartButtons = buttons, stage = 2)))
                        return@withTimeoutOrNull true
                    }
                } ?: false
            }

            // ── Stage 3: full yt-dlp (cap 4s for UI freshness, formats keep streaming) ──
            val isDone = probeJob.await()
            if (!isDone) {
                fastJob.await()
                val full = runCatching { ytDlp.extract(cleaned) }.getOrNull()
                if (full != null) {
                    val enriched = full.copy(
                        faviconUrl = full.faviconUrl ?: faviconCandidates(domain).firstOrNull(),
                    )
                    // Enrich key formats with their REAL sizes via parallel HEAD pool
                    val exactMap = resolveExactSizes(enriched)
                    val finalFormats = enriched.formats.map { f ->
                        exactMap[f.id]?.let { f.copy(size = it) } ?: f
                    }
                    val finalMedia = enriched.copy(formats = finalFormats)
                    val buttons = SmartButtons.fromFormats(finalFormats) +
                        subtitleExtras(finalMedia)
                    send(
                        Event.Full(
                            AnalysisSnapshot(
                                media = finalMedia, smartButtons = buttons,
                                resolvedSizes = exactMap, stage = 3,
                            )
                        )
                    )
                    persist(cleaned, finalMedia)
                } else {
                    // ── Stage 4: graceful fallback → internal browser sniffer ──
                    send(
                        Event.FallbackSuggestion(
                            reason = "تعذّر تحليل الرابط مباشرة — جرّب الاصطياد من داخل المتصفح",
                            canSniffInBrowser = true,
                        )
                    )
                }
            }
        }
    }

    /** Adds file-kind extras: subtitles + description JSON (spec §5, "ملفات"). */
    private fun subtitleExtras(media: ExtractedMedia): SmartButtons {
        val files = media.subtitles.map { sub ->
            FormatOption(
                id = "sub_${sub.lang}_${sub.ext}",
                kind = MediaKind.FILE,
                label = "ترجمة ${sub.lang.uppercase()} (${sub.ext.uppercase()})",
                container = sub.ext,
                url = sub.url,
            )
        }
        return SmartButtons(emptyList(), emptyList(), emptyList(), files)
    }

    /** Real size per direct format via bounded parallel HEAD (spec §4.5 step 4-lite). */
    private suspend fun resolveExactSizes(media: ExtractedMedia): Map<String, SizeInfo> =
        coroutineScope {
            media.formats.filter { it.url != null && it.size == null }
                .take(24)
                .map { f ->
                    async(Dispatchers.IO) {
                        f.id to runCatching {
                            sizeResolver.resolve(f.url!!, media.requiredHeaders).size
                        }.getOrNull()
                    }
                }
                .mapNotNull { it.await().let { (id, size) -> if (size != null) id to size else null } }
                .toMap()
        }

    // ── Stage 0 helpers ──

    fun cleanUrl(raw: String): String? {
        val trimmed = raw.trim()
        Regex("https?://\\S+").find(trimmed)?.value?.let { return it }
        if (Regex("^[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}(/\\S*)?$").matches(trimmed)) return "https://$trimmed"
        return null
    }

    /** apple-touch-icon → manifest icons → og:logo → public favicon service (spec §4.3). */
    fun faviconCandidates(domain: String): List<String> = listOf(
        "https://$domain/apple-touch-icon.png",
        "https://$domain/favicon.ico",
        "https://www.google.com/s2/favicons?domain=$domain&sz=128",
    )

    private fun kindFromExtension(path: String): MediaKind = when {
        path.endsWith(".mp4", true) || path.endsWith(".mkv", true) || path.endsWith(".webm", true) ||
            path.endsWith(".mov", true) || path.endsWith(".m3u8", true) || path.endsWith(".mpd", true) -> MediaKind.VIDEO
        path.endsWith(".mp3", true) || path.endsWith(".m4a", true) || path.endsWith(".flac", true) ||
            path.endsWith(".wav", true) || path.endsWith(".opus", true) -> MediaKind.AUDIO
        path.endsWith(".jpg", true) || path.endsWith(".jpeg", true) || path.endsWith(".png", true) ||
            path.endsWith(".webp", true) || path.endsWith(".avif", true) -> MediaKind.IMAGE
        else -> MediaKind.FILE
    }

    private fun kindFromMime(mime: String?, url: String): MediaKind = when {
        mime == null -> kindFromExtension(url)
        mime.startsWith("video/") -> MediaKind.VIDEO
        mime.startsWith("audio/") -> MediaKind.AUDIO
        mime.startsWith("image/") -> MediaKind.IMAGE
        else -> MediaKind.FILE
    }

    private fun fileNameFromUrl(url: String): String =
        URI(url).path?.substringAfterLast('/')?.ifBlank { null } ?: "file"

    private suspend fun persist(url: String, media: ExtractedMedia) {
        runCatching {
            cache.put(AnalysisCacheEntity(url, json.encodeToString(media.toSurrogate())))
        }
    }

    @Serializable
    private data class ExtractedMediaSurrogate(
        val sourceUrl: String, val resolvedUrl: String?, val domain: String, val siteName: String,
        val faviconUrl: String?, val title: String, val originalFileName: String?,
        val thumbnailUrl: String?, val kind: String, val durationSec: Int,
        val uploader: String?, val uploadDate: String?, val formats: List<FormatOption>,
    )

    private fun ExtractedMedia.toSurrogate() = ExtractedMediaSurrogate(
        sourceUrl, resolvedUrl, domain, siteName, faviconUrl, title, originalFileName,
        thumbnailUrl, kind.name, durationSec, uploader, uploadDate, formats,
    )

    private fun ExtractedMediaSurrogate.toMedia() = ExtractedMedia(
        sourceUrl = sourceUrl, resolvedUrl = resolvedUrl, domain = domain, siteName = siteName,
        faviconUrl = faviconUrl, title = title, originalFileName = originalFileName,
        thumbnailUrl = thumbnailUrl, kind = MediaKind.valueOf(kind), durationSec = durationSec,
        uploader = uploader, uploadDate = uploadDate, formats = formats, engineUsed = EngineKind.DIRECT,
    )
}
