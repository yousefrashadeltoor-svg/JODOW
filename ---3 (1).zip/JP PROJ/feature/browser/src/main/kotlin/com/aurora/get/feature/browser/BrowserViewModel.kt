package com.aurora.get.feature.browser

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.common.MediaKind
import com.aurora.get.db.SiteSessionDao
import com.aurora.get.db.SiteSessionEntity
import com.aurora.get.network.PersistentCookieJar
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BrowserViewModel @Inject constructor(
    val sniffer: MediaSniffer,
    val adBlock: AdBlockEngine,
    private val cookieJar: PersistentCookieJar,
    private val sessions: SiteSessionDao,
    private val queue: com.aurora.get.downloader.DownloadQueue,
) : ViewModel() {

    private val _blockedCount = MutableStateFlow(0)
    val blockedCount: StateFlow<Int> = _blockedCount

    fun onBlocked(host: String) {
        _blockedCount.value += 1
    }

    fun toggleSiteAllowlist(host: String) {
        adBlock.setSiteAllowed(host, !adBlock.isSiteAllowed(host))
    }

    /** WebView cookies → CookieJar + Room session row (cf_clearance rides along). */
    fun exportSessionCookies(url: String, cookieHeader: String) {
        viewModelScope.launch {
            val host = runCatching { java.net.URI(url).host.orEmpty() }.getOrDefault("")
            if (host.isBlank()) return@launch
            cookieJar.importHeader(host, cookieHeader)
            sessions.put(SiteSessionEntity(host, cookieHeader, DESKTOP_UA))
        }
    }

    fun syncCookies(url: String) = exportSessionCookies(url,
        android.webkit.CookieManager.getInstance().getCookie(url) ?: "")

    /** Sniffed file → engine — cookies/UA/Referer travel with the download (never WebView's). */
    fun download(file: MediaSniffer.SniffedFile) {
        viewModelScope.launch {
            val host = runCatching { java.net.URI(file.url).host.orEmpty() }.getOrDefault("")
            queue.enqueue(
                com.aurora.get.db.DownloadEntity(
                    id = java.util.UUID.randomUUID().toString(),
                    url = file.url,
                    directUrl = file.url,
                    fileName = file.fileName ?: host + "_" + file.url.substringAfterLast('/').take(32),
                    destDir = when (file.kind) {
                        MediaKind.VIDEO -> "Movies/Aurora"
                        MediaKind.AUDIO -> "Music/Aurora"
                        MediaKind.IMAGE -> "Pictures/Aurora"
                        MediaKind.FILE -> "Download/Aurora"
                    },
                    kind = file.kind,
                    totalBytes = file.size?.bytes ?: -1,
                    sizeApprox = file.size?.isApproximate ?: false,
                    siteDomain = host,
                    headersJson = kotlinx.serialization.json.Json.encodeToString(file.headers),
                )
            )
        }
    }

    companion object {
        private const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
    }
}
