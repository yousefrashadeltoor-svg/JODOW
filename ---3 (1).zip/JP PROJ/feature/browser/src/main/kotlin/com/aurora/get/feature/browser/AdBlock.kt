package com.aurora.get.feature.browser

import android.content.Context
import android.webkit.WebResourceResponse
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.io.ByteArrayInputStream
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Ad-blocking (spec §6). Loads EasyList + EasyPrivacy and matches requests even offline.
 *
 * VERIFY: brave/adblock-rust exposes a Rust C-API; to use it on Android you build the
 * `adblock` crate as a cdylib and call it over JNI (or use heroic's Kotlin bindings).
 * That integration plugs into [Engine] below — the interface stays identical.
 *
 * Until the native engine is compiled in, the guaranteed-working [HostFilterEngine]
 * below already blocks ads/trackers/popups using the same list subscriptions.
 */
@Singleton
class AdBlockEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val client: OkHttpClient,
) : Engine {

    interface Engine {
        val enabled: Boolean
        suspend fun setEnabled(value: Boolean)
        suspend fun updateLists(): Int        // returns blocked-rule count
        fun shouldBlock(url: String, pageHost: String): Boolean
        fun emptyResponse(): WebResourceResponse
        val cosmeticCss: String
    }

    private val delegate = HostFilterEngine(context, client)
    private val mutex = Mutex()

    override val enabled: Boolean get() = delegate.enabled
    override suspend fun setEnabled(value: Boolean) = delegate.setEnabled(value)
    override suspend fun updateLists(): Int = mutex.withLock { delegate.updateLists() }
    override fun shouldBlock(url: String, pageHost: String): Boolean =
        enabled && delegate.shouldBlock(url, pageHost)
    override fun emptyResponse(): WebResourceResponse = delegate.emptyResponse()
    override val cosmeticCss: String get() = delegate.cosmeticCss

    /** Per-site allowlist (tap the shield → "استثناء هذا الموقع"). */
    private val allowlist = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    fun setSiteAllowed(host: String, allowed: Boolean) {
        if (allowed) allowlist += host else allowlist -= host
    }

    fun isSiteAllowed(host: String) = host in allowlist

    fun shouldBlockFiltered(url: String, pageHost: String): Boolean =
        !isSiteAllowed(pageHost) && shouldBlock(url, pageHost)
}

/**
 * Fast offline matcher: suffix-hash set of blocked hosts (O(1) lookups) +
 * a few high-value regex patterns from the subscriptions.
 */
class HostFilterEngine(
    private val context: Context,
    private val client: OkHttpClient,
) : AdBlockEngine.Engine {

    private val blockedHosts = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private var enabledFlag = true

    override val enabled: Boolean get() = enabledFlag

    private val lists = listOf(
        "https://easylist.to/easylist/easylist.txt",
        "https://easylist.to/easylist/easyprivacy.txt",
    )

    init {
        // Load a cached parse instantly; fresh lists land via [updateLists].
        context.getSharedPreferences("adblock", Context.MODE_PRIVATE)
            .getStringSet("hosts", emptySet())?.let { blockedHosts += it }
    }

    override suspend fun setEnabled(value: Boolean) {
        enabledFlag = value
    }

    override suspend fun updateLists(): Int = withContext(Dispatchers.IO) {
        val hosts = mutableSetOf<String>()
        lists.forEach { listUrl ->
            runCatching {
                client.newCall(Request.Builder().url(listUrl).build()).execute().use { res ->
                    res.body.string().lineSequence().forEach { line ->
                        // EasyList host-rule form: ||ads.example.com^
                        if (line.startsWith("||")) {
                            val host = line.removePrefix("||").substringBefore("^")
                                .substringBefore("/").trim()
                            if (host.matches(Regex("^[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"))) hosts += host
                        }
                    }
                }
            }.onFailure { Timber.w(it, "list fetch failed: $listUrl") }
        }
        blockedHosts.clear(); blockedHosts += hosts
        context.getSharedPreferences("adblock", Context.MODE_PRIVATE)
            .edit().putStringSet("hosts", hosts).apply()
        Timber.i("AdBlock lists updated: ${hosts.size} hosts")
        hosts.size
    }

    override fun shouldBlock(url: String, pageHost: String): Boolean {
        val host = runCatching { java.net.URI(url).host }.getOrNull() ?: return false
        if (host == null || host.endsWith(pageHost)) return false
        // walk up the suffix chain: cdn.ads.site.com → ads.site.com → site.com
        var probe = host
        while (probe.count { it == '.' } >= 1) {
            if (blockedHosts.contains(probe)) return true
            probe = probe.substringAfter('.')
        }
        return POPUP_PATTERNS.any { url.contains(it) } ||
            TRACKER_PATH_MARKERS.any { url.contains(it) }
    }

    override fun emptyResponse(): WebResourceResponse = WebResourceResponse(
        "text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)),
    )

    /** Cosmetic filtering injected as CSS (cookie banners, fake download overlays...). */
    override val cosmeticCss: String = """
        .ads, .ad, .advert, [class*="cookie-banner"], [id*="cookie-consent"],
        .popup, .popunder, .modal-backdrop [class*="ads"],
        a[href*="download"][class*="btn-fake"] { display: none !important; }
    """.trimIndent()

    companion object {
        private val POPUP_PATTERNS = listOf("/popunder", "/popup.php", "onclick=window.open")
        private val TRACKER_PATH_MARKERS = listOf(
            "/analytics.", "/gtag/", "/pixel?", "/collect?", "/beacon", "/track/",
        )
    }
}
