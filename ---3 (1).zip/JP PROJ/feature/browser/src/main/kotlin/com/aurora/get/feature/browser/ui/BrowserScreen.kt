package com.aurora.get.feature.browser.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import com.aurora.get.common.MediaKind
import com.aurora.get.common.SizeInfo
import com.aurora.get.designsystem.components.AuroraGlassButton
import com.aurora.get.designsystem.components.AuroraIcon
import com.aurora.get.designsystem.components.GlassBottomSheet
import com.aurora.get.designsystem.components.pressableScale
import com.aurora.get.designsystem.glass.GlassChip
import com.aurora.get.designsystem.glass.GlassPanel
import com.aurora.get.designsystem.glass.rememberGlassBackgroundState
import com.aurora.get.designsystem.icons.AuroraIcons
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import com.aurora.get.designsystem.theme.LocalAuroraTypography
import com.aurora.get.feature.browser.AdBlockEngine
import com.aurora.get.feature.browser.BrowserViewModel
import com.aurora.get.feature.browser.MediaSniffer
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Internal browser (spec §6): tabs, glass address bar, desktop mode, private mode,
 * sniffer FAB with live count, AdBlock with per-site allowlist, Cloudflare clearance
 * passthrough, and cookie export into the app's engine.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(
    startUrl: String,
    viewModel: BrowserViewModel = hiltViewModel(),
    onBack: () -> Unit = {},
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val haze = rememberGlassBackgroundState()
    val sniffer: MediaSniffer = viewModel.sniffer
    val adBlock: AdBlockEngine = viewModel.adBlock

    var webView by remember { mutableStateOf<WebView?>(null) }
    var url by remember { mutableStateOf(startUrl) }
    var title by remember { mutableStateOf("") }
    var progress by remember { mutableIntStateOf(0) }
    var desktopMode by remember { mutableStateOf(false) }
    var privateMode by remember { mutableStateOf(false) }
    var showCatchSheet by remember { mutableStateOf(false) }
    val blockedCount by viewModel.blockedCount.collectAsState()
    val detected by sniffer.detected.collectAsState()
    val detectedCount = detected.size

    Box(Modifier.fillMaxSize().background(c.background)) {
        Column(Modifier.fillMaxSize()) {
            // ── Glass address bar ──
            GlassPanel(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                hazeState = haze, shape = LocalAuroraShapes.current.full,
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    NavIcon(AuroraIcons.ArrowBack, "رجوع") { if (webView?.canGoBack() == true) webView?.goBack() else onBack() }
                    NavIcon(AuroraIcons.Refresh, "تحديث") { webView?.reload() }
                    Spacer(Modifier.width(6.dp))
                    GlassChip(Modifier.weight(1f)) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AuroraIcon(AuroraIcons.Shield, "آمن", tint = c.success, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(6.dp))
                            BasicText(
                                text = title.ifBlank { url },
                                style = t.bodySmall.copy(color = c.textSecondary),
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    Spacer(Modifier.width(6.dp))
                    // Blocked-counter button → per-site allowlist sheet
                    GlassChip(Modifier.pressableScale({ viewModel.toggleSiteAllowlist(hostOf(url)) })) {
                        Row(
                            Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AuroraIcon(AuroraIcons.Shield, "حجب", tint = c.error, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            BasicText(blockedCount.toString(), style = t.labelMedium.copy(color = c.textSecondary))
                        }
                    }
                }
            }

            // progress hairline
            if (progress in 1..99) {
                Box(
                    Modifier.fillMaxWidth(fraction = progress / 100f).height(2.dp)
                        .background(c.brandGradient)
                )
            }

            // ── WebView ──
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = !privateMode
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.userAgentString = if (desktopMode) DESKTOP_UA else MOBILE_UA

                        addJavascriptInterface(object {
                            @JavascriptInterface
                            fun capture(rawUrl: String, mime: String) {
                                sniffer.captureFromJs(rawUrl, mime.ifBlank { null }, url, settings.userAgentString)
                            }
                        }, "AuroraSniffer")

                        webViewClient = object : WebViewClient() {
                            override fun shouldInterceptRequest(
                                view: WebView, request: WebResourceRequest,
                            ): WebResourceResponse? {
                                val reqUrl = request.url.toString()
                                val host = hostOf(view.url ?: url)
                                if (adBlock.shouldBlockFiltered(reqUrl, host)) {
                                    viewModel.onBlocked(host)
                                    return adBlock.emptyResponse()
                                }
                                sniffer.maybeCapture(request, view.url ?: url, settings.userAgentString)
                                return null
                            }

                            override fun onPageStarted(view: WebView, u: String, favicon: Bitmap?) {
                                url = u
                            }

                            override fun onPageFinished(view: WebView, u: String) {
                                url = u
                                title = view.title ?: ""
                                // Cosmetic filtering + re-run the sniffer after dynamic loads
                                view.evaluateJavascript(
                                    "(function(){var s=document.createElement('style');" +
                                        "s.textContent=" + android.util.Base64.encodeToString(
                                            adBlock.cosmeticCss.toByteArray(),
                                            android.util.Base64.DEFAULT,
                                        ).let { "atob('${it.replace("\n", "")}')" } +
                                        ";document.head.appendChild(s);})();",
                                    null,
                                )
                                view.evaluateJavascript(MediaSniffer.SNIFFER_JS, null)
                                exportCloudflareClearance(u, viewModel)
                                viewModel.syncCookies(u)
                            }
                        }
                        webChromeClient = object : WebChromeClient() {
                            var titleCb: (String) -> Unit = {}
                            override fun onProgressChanged(view: WebView, newProgress: Int) {
                                progress = newProgress
                            }
                            override fun onReceivedTitle(view: WebView, t: String) { title = t }
                        }

                        // Direct downloads from the page → our engine (never WebView's manager)
                        setDownloadListener(DownloadListener { dUrl, ua, contentDisposition, mime, _ ->
                            val headers = mapOf("User-Agent" to ua, "Referer" to url)
                            sniffer.captureDownload(dUrl, contentDisposition, mime, headers)
                            showCatchSheet = true
                        })

                        loadUrl(startUrl)
                    }
                },
                modifier = Modifier.fillMaxSize(),
                update = { webView = it },
            )
        }

        // ── Floating catch FAB with count ──
        if (detectedCount > 0) {
            GlassPanel(
                Modifier
                    .align(Alignment.BottomEnd)
                    .navigationBarsPadding()
                    .padding(end = 18.dp, bottom = 24.dp)
                    .pressableScale({ showCatchSheet = true }),
                hazeState = haze, shape = LocalAuroraShapes.current.full, glowColor = c.glow,
            ) {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AuroraIcon(AuroraIcons.Sparkle, null, tint = c.brandPink)
                    Spacer(Modifier.width(8.dp))
                    BasicText("اصطُيِد $detectedCount", style = t.labelLarge.copy(color = c.textPrimary))
                }
            }
        }
    }

    // ── Caught-files sheet (same card style as the smart buttons) ──
    if (showCatchSheet) {
        GlassBottomSheet(visible = true, onDismiss = { showCatchSheet = false }, hazeState = haze) {
            Column {
                GradientTitleRow()
                Spacer(Modifier.height(10.dp))
                LazyColumn(Modifier.height(420.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(detected.values.toList().size) { i ->
                        val file = detected.values.toList()[i]
                        SniffedRow(file = file, onDownload = { viewModel.download(file) })
                    }
                }
            }
        }
    }
}

@Composable
private fun GradientTitleRow() {
    com.aurora.get.designsystem.components.GradientText(
        "الملفات المكتشفة", LocalAuroraTypography.current.headlineMedium,
    )
}

@Composable
private fun SniffedRow(file: MediaSniffer.SniffedFile, onDownload: () -> Unit) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    GlassPanel(shape = LocalAuroraShapes.current.medium) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            AuroraIcon(
                when (file.kind) {
                    MediaKind.VIDEO -> AuroraIcons.Video
                    MediaKind.AUDIO -> AuroraIcons.Music
                    MediaKind.IMAGE -> AuroraIcons.Image
                    MediaKind.FILE -> AuroraIcons.FileDoc
                }, null,
                tint = c.brandPurple, modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                BasicText(
                    file.fileName ?: file.url.substringAfterLast('/').take(40),
                    style = t.titleMedium.copy(color = c.textPrimary),
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                BasicText(
                    buildString {
                        append(file.mimeType ?: file.kind.name.lowercase())
                        file.size?.let { append("  ·  ${it.short}") }
                        if (file.viaBlob) append("  ·  blob")
                    },
                    style = t.labelMedium.copy(color = c.textTertiary),
                )
            }
            AuroraGlassButton(onClick = onDownload) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    AuroraIcon(AuroraIcons.Download, "تحميل", tint = c.brandPurple)
                }
            }
        }
    }
}

@Composable
private fun NavIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String, onClick: () -> Unit,
) {
    Box(
        Modifier.size(36.dp).pressableScale(onClick),
        contentAlignment = Alignment.Center,
    ) {
        AuroraIcon(icon, label, tint = AuroraTheme.colors.textSecondary, modifier = Modifier.size(20.dp))
    }
}

private fun hostOf(url: String): String =
    runCatching { java.net.URI(url).host.orEmpty() }.getOrDefault("")

/**
 * After a Cloudflare / Turnstile challenge resolves inside the real WebView, we read
 * cf_clearance + sibling cookies + the UA the page negotiated, and push them into the
 * app's PersistentCookieJar so OkHttp/Cronet requests travel with the same identity
 * (spec: Cloudflare the legitimate way — no DRM/paywall bypass).
 */
private fun exportCloudflareClearance(url: String, viewModel: BrowserViewModel) {
    val cookies = CookieManager.getInstance().getCookie(url) ?: return
    if ("cf_clearance" in cookies) viewModel.exportSessionCookies(url, cookies)
}

private const val DESKTOP_UA =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
private const val MOBILE_UA =
    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36"
