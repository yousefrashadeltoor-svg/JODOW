package com.aurora.get.feature.browser

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import com.aurora.get.common.MediaKind
import com.aurora.get.common.SizeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import timber.log.Timber
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Media Sniffer (spec §6): catches every playable/downloadable candidate the page asks for.
 * Runs in parallel with rendering; nothing reaches the UI unless it's genuinely media.
 */
@Singleton
class MediaSniffer @Inject constructor() {

    data class SniffedFile(
        val url: String,
        val mimeType: String? = null,
        val kind: MediaKind,
        val fileName: String? = null,         // from Content-Disposition when known
        val size: SizeInfo? = null,           // filled via SizeResolver lazily
        val headers: Map<String, String> = emptyMap(), // cookies/UA/referer for our engine
        val viaBlob: Boolean = false,
    )

    private val _detected = MutableStateFlow<Map<String, SniffedFile>>(emptyMap())
    val detected: StateFlow<Map<String, SniffedFile>> = _detected

    fun clear() { _detected.value = emptyMap() }

    /** Called from WebViewClient.shouldInterceptRequest on the render thread. */
    fun maybeCapture(request: WebResourceRequest, pageUrl: String, userAgent: String) {
        if (request.method.uppercase() != "GET") return
        val url = request.url.toString()
        val kind = classifyUrl(url) ?: return
        report(url, kind, mimeFromUrl(url), requestHeaders(request, pageUrl, userAgent))
    }

    /** Called by JS bridge for blob:/MediaSource/MediaElement sources. */
    fun captureFromJs(rawUrl: String, mime: String?, pageUrl: String, userAgent: String) {
        val kind = mime?.let { mimeKind(it) } ?: classifyUrl(rawUrl) ?: return
        report(
            rawUrl, kind, mime,
            mapOf(
                "User-Agent" to userAgent,
                "Referer" to pageUrl,
            ),
            viaBlob = rawUrl.startsWith("blob:"),
        )
    }

    /** DownloadListener hook (direct file links clicked in-page). */
    fun captureDownload(url: String, contentDisposition: String?, mime: String?, headers: Map<String, String>) {
        report(
            url,
            mime?.let { mimeKind(it) } ?: classifyUrl(url) ?: MediaKind.FILE,
            mime, headers, fileName = dispositionName(contentDisposition),
        )
    }

    private fun report(
        url: String, kind: MediaKind, mime: String?,
        headers: Map<String, String>, viaBlob: Boolean = false, fileName: String? = null,
    ) {
        if (url.length > 2048) return // junk guard
        _detected.update { it + (url to SniffedFile(url, mime, kind, fileName, headers = headers, viaBlob = viaBlob)) }
        Timber.d("sniffed ${kind.name}: ${url.take(90)}")
    }

    fun classifyUrl(url: String): MediaKind? {
        val path = url.substringBefore('?').lowercase()
        val ext = path.substringAfterLast('.', "")
        return when (ext) {
            "mp4", "mkv", "webm", "mov", "m4v", "ts", "m3u8", "mpd" -> MediaKind.VIDEO
            "mp3", "m4a", "aac", "opus", "ogg", "flac", "wav" -> MediaKind.AUDIO
            "jpg", "jpeg", "png", "webp", "avif", "gif" -> MediaKind.IMAGE
            "zip", "rar", "7z", "apk", "pdf", "iso", "exe", "dmg", "gz", "tar", "xz" -> MediaKind.FILE
            else -> null
        }
    }

    fun mimeKind(mime: String): MediaKind? = when {
        mime.startsWith("video/") || mime == "application/vnd.apple.mpegurl" ||
            mime == "application/dash+xml" -> MediaKind.VIDEO
        mime.startsWith("audio/") -> MediaKind.AUDIO
        mime.startsWith("image/") -> MediaKind.IMAGE
        mime == "application/octet-stream" || mime.contains("zip") || mime == "application/pdf" -> MediaKind.FILE
        else -> null
    }

    private fun mimeFromUrl(url: String): String? = when (classifyUrl(url)) {
        MediaKind.VIDEO -> if (url.contains(".m3u8")) "application/vnd.apple.mpegurl" else "video/mp4"
        MediaKind.AUDIO -> "audio/*"
        MediaKind.IMAGE -> "image/*"
        MediaKind.FILE -> "application/octet-stream"
        null -> null
    }

    private fun requestHeaders(request: WebResourceRequest, pageUrl: String, ua: String): Map<String, String> =
        buildMap {
            put("User-Agent", ua)
            put("Referer", pageUrl)
            request.requestHeaders?.forEach { (k, v) -> put(k, v) }
        }

    private fun dispositionName(disposition: String?): String? =
        disposition?.let { Regex("filename=\"?([^\";]+)\"?").find(it)?.groupValues?.get(1) }

    companion object {
        /**
         * JS hook — injected on every page (spec §6.3): wraps fetch + XHR + createObjectURL +
         * MediaSource and reports every media URL to the native side via [JSBridge].
         */
        const val SNIFFER_JS: String = """
            (function() {
                if (window.__auroraSniffed) return; window.__auroraSniffed = true;
                var report = function(url, mime) {
                    try { AuroraSniffer.capture(String(url), String(mime || '')); } catch(e) {}
                };
                ['fetch'].forEach(function(k) {
                    var orig = window[k];
                    window[k] = function(u, opts) {
                        var p = orig.apply(this, arguments);
                        try {
                            p.then(function(r) {
                                var m = r.headers.get('content-type') || '';
                                if (/^(video|audio|image)\//.test(m) || /\.(m3u8|mpd|mp4|webm|mp3)(\?|$)/i.test(String(u))) {
                                    report(typeof u === 'string' ? u : u.url, m);
                                }
                            });
                        } catch(e) {}
                        return p;
                    };
                });
                var origOpen = XMLHttpRequest.prototype.open;
                XMLHttpRequest.prototype.open = function(m, u) {
                    if (/\.(m3u8|mpd|mp4|webm|ts|mp3|m4a)(\?|$)/i.test(String(u))) report(u, '');
                    return origOpen.apply(this, arguments);
                };
                var origBlob = URL.createObjectURL;
                URL.createObjectURL = function(obj) {
                    var u = origBlob.apply(this, arguments);
                    try { if (obj && obj.type && /^(video|audio)\//.test(obj.type)) report(u, obj.type); } catch(e) {}
                    return u;
                };
                document.querySelectorAll('video, audio').forEach(function(el) {
                    if (el.currentSrc) report(el.currentSrc, el.tagName === 'VIDEO' ? 'video/*' : 'audio/*');
                    el.querySelectorAll('source').forEach(function(s) { if (s.src) report(s.src, s.type); });
                });
            })();
        """
    }
}
