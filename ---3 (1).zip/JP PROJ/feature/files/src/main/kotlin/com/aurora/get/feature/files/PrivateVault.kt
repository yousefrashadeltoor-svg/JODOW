package com.aurora.get.feature.files

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

/**
 * Private Vault (spec §11): files are sealed with AES-256-GCM; the key lives in the
 * Android Keystore and is gated by a biometric prompt. Nothing leaves the device.
 */
@Singleton
class PrivateVault @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val vaultDir: File = File(context.filesDir, "vault").apply { mkdirs() }

    companion object {
        private const val KEY_ALIAS = "aurora_vault_v1"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        ks.getKey(KEY_ALIAS, null)?.let { return it as SecretKey }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setUserAuthenticationRequired(true)   // biometric gate enforced by Keystore
                .setUserAuthenticationValidityDurationSeconds(30)
                .build()
        )
        return generator.generateKey()
    }

    /** Gate: biometric dialog (system-managed), caller passes a FragmentActivity. */
    suspend fun authenticate(activity: FragmentActivity): Boolean = suspendCancellableCoroutine { cont ->
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    cont.resume(true)
                }
                override fun onAuthenticationError(code: Int, errString: CharSequence) {
                    cont.resume(false)
                }
                override fun onAuthenticationFailed() { /* keep waiting */ }
            },
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("القبو الخاص")
            .setSubtitle("أثبت هويتك للوصول إلى ملفاتك المشفرة")
            .setNegativeButtonText("إلغاء")
            .build()
        prompt.authenticate(info)
    }

    /** Encrypt + move a file into the vault (original stays until the caller deletes it). */
    suspend fun seal(source: File): File? = withContext(Dispatchers.IO) {
        runCatching {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, key())
            val iv = cipher.iv
            val out = File(vaultDir, source.name + ".vault")
            out.outputStream().use { os ->
                os.write(iv.size); os.write(iv)
                os.write(cipher.doFinal(source.readBytes()))
            }
            out
        }.onFailure { Timber.e(it, "vault seal failed") }.getOrNull()
    }

    /** Decrypt for playback/preview (temp file, wiped after). */
    suspend fun open(vaultFile: File): File? = withContext(Dispatchers.IO) {
        runCatching {
            val bytes = vaultFile.readBytes()
            val ivLen = bytes[0].toInt()
            val iv = bytes.copyOfRange(1, 1 + ivLen)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            val plain = cipher.doFinal(bytes.copyOfRange(1 + ivLen, bytes.size))
            File(vaultDir, "tmp_" + vaultFile.name.removeSuffix(".vault")).apply {
                writeBytes(plain); deleteOnExit()
            }
        }.getOrNull()
    }

    fun list(): List<File> = vaultDir.listFiles()?.filter { it.name.endsWith(".vault") } ?: emptyList()

    fun remove(vaultFile: File) { vaultFile.delete() }
}
