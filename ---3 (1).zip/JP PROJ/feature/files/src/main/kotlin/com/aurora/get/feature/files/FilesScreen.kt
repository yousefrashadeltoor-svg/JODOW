package com.aurora.get.feature.files

import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil3.compose.AsyncImage
import com.aurora.get.common.Bytes
import com.aurora.get.common.MediaKind
import com.aurora.get.db.HistoryDao
import com.aurora.get.designsystem.components.AuroraIcon
import com.aurora.get.designsystem.components.GradientText
import com.aurora.get.designsystem.components.pressableScale
import com.aurora.get.designsystem.effects.MeshGradientBackground
import com.aurora.get.designsystem.glass.GlassChip
import com.aurora.get.designsystem.glass.GlassPanel
import com.aurora.get.designsystem.glass.rememberGlassBackgroundState
import com.aurora.get.designsystem.icons.AuroraIcons
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import com.aurora.get.designsystem.theme.LocalAuroraTypography
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

/** Library: grid/list of downloaded files grouped by Aurora folders (MediaStore + SAF). */

data class LibraryItem(
    val path: String, val name: String, val kind: MediaKind,
    val bytes: Long, val modified: Long,
)

@HiltViewModel
class FilesViewModel @Inject constructor(
    private val history: HistoryDao,
) : ViewModel() {

    data class UiState(
        val items: List<LibraryItem> = emptyList(),
        val grid: Boolean = true,
        val filter: MediaKind? = null,
        val totalSavedBytes: Long = 0,
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    init { scan() }

    fun toggleGrid() = _state.update { it.copy(grid = !it.grid) }
    fun setFilter(kind: MediaKind?) = _state.update { it.copy(filter = kind) }

    fun scan() {
        viewModelScope.launch(Dispatchers.IO) {
            val roots = listOf(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            ).mapNotNull { it?.let { root -> File(root, "Aurora") } }

            val items = roots.flatMap { root ->
                root.walkTopDown().filter { it.isFile }.map { f ->
                    LibraryItem(
                        path = f.absolutePath,
                        name = f.name,
                        kind = classify(f.extension),
                        bytes = f.length(),
                        modified = f.lastModified(),
                    )
                }
            }.sortedByDescending { it.modified }

            _state.update { it.copy(items = items) }
        }
    }

    private fun classify(ext: String): MediaKind = when (ext.lowercase()) {
        "mp4", "mkv", "webm", "mov", "gif" -> MediaKind.VIDEO
        "mp3", "m4a", "opus", "ogg", "flac", "wav" -> MediaKind.AUDIO
        "jpg", "jpeg", "png", "webp", "avif" -> MediaKind.IMAGE
        else -> MediaKind.FILE
    }
}

@Composable
fun FilesScreen(
    viewModel: FilesViewModel = hiltViewModel(),
    onOpen: (LibraryItem) -> Unit = {},
) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val haze = rememberGlassBackgroundState()
    val state by viewModel.state.collectAsState()

    Box(Modifier.fillMaxSize()) {
        MeshGradientBackground(Modifier.matchParentSize().hazeSource(state = haze))
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(26.dp))
            GradientText("الملفات", t.headlineLarge)
            Spacer(Modifier.height(12.dp))

            // kind filters
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf<MediaKind?>(null, MediaKind.VIDEO, MediaKind.AUDIO, MediaKind.IMAGE, MediaKind.FILE)
                    .forEach { kind ->
                        val label = when (kind) {
                            null -> "الكل"; MediaKind.VIDEO -> "فيديو"; MediaKind.AUDIO -> "صوت"
                            MediaKind.IMAGE -> "صور"; MediaKind.FILE -> "ملفات"
                        }
                        val active = state.filter == kind
                        GlassChip(Modifier.pressableScale({ viewModel.setFilter(kind) })) {
                            BasicText(
                                label, Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                style = t.labelLarge.copy(color = if (active) c.brandPurple else c.textSecondary),
                            )
                        }
                    }
            }
            Spacer(Modifier.height(14.dp))

            val visible = state.items.filter { state.filter == null || it.kind == state.filter }
            LazyVerticalGrid(
                columns = GridCells.Fixed(if (state.grid) 2 else 1),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(visible.size) { i ->
                    val item = visible[i]
                    FileCard(item, onOpen = { onOpen(item) })
                }
                item { Spacer(Modifier.height(90.dp)) }
            }
        }
    }
}

@Composable
private fun FileCard(item: LibraryItem, onOpen: () -> Unit) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val accent = when (item.kind) {
        MediaKind.VIDEO -> c.typeVideo; MediaKind.AUDIO -> c.typeAudio
        MediaKind.IMAGE -> c.typeImage; MediaKind.FILE -> c.typeFile
    }
    GlassPanel(
        modifier = Modifier.pressableScale(onOpen),
        glowColor = accent,
    ) {
        Column(Modifier.fillMaxWidth()) {
            // thumbnail / icon tile
            Box(
                Modifier.fillMaxWidth().aspectRatio(1.6f),
                contentAlignment = Alignment.Center,
            ) {
                if (item.kind == MediaKind.IMAGE) {
                    AsyncImage(
                        model = File(item.path), contentDescription = null,
                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                    )
                } else {
                    Box(
                        Modifier.size(46.dp).background(accent.copy(alpha = 0.15f), LocalAuroraShapes.current.squircle),
                        contentAlignment = Alignment.Center,
                    ) {
                        AuroraIcon(
                            when (item.kind) {
                                MediaKind.VIDEO -> AuroraIcons.Video
                                MediaKind.AUDIO -> AuroraIcons.Music
                                MediaKind.FILE -> AuroraIcons.FileDoc
                                MediaKind.IMAGE -> AuroraIcons.Image
                            }, null, tint = accent, modifier = Modifier.size(24.dp),
                        )
                    }
                }
            }
            Column(Modifier.padding(12.dp)) {
                BasicText(item.name, style = t.titleMedium.copy(color = c.textPrimary),
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                BasicText(Bytes.exact(item.bytes), style = t.labelMedium.copy(color = c.textTertiary))
            }
        }
    }
}
