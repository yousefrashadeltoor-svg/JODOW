package com.aurora.get.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.aurora.get.designsystem.components.AuroraGlassButton
import com.aurora.get.designsystem.components.AuroraIcon
import com.aurora.get.designsystem.components.AuroraProgressBar
import com.aurora.get.designsystem.components.pressableScale
import com.aurora.get.designsystem.glass.GlassChip
import com.aurora.get.designsystem.glass.GlassPanel
import com.aurora.get.designsystem.icons.AuroraIcons
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import com.aurora.get.designsystem.theme.LocalAuroraTypography
import com.aurora.get.player.RepeatMode
import com.aurora.get.player.exoRepeatFor

/**
 * Built-in video/audio player (spec §11): Media3 with HLS + DASH, PiP (system gesture),
 * background audio (PlaybackService), speeds, subtitles, and gesture-area hints.
 * UI is custom glass (never Material).
 */
@Composable
fun PlayerScreen(
    source: String,            // file path or http(s) url (m3u8/mpd supported natively)
    title: String,
    audioOnly: Boolean = false,
    onClose: () -> Unit = {},
) {
    val context = LocalContext.current
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current

    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(source))
            prepare()
            playWhenReady = true
        }
    }
    var isPlaying by remember { mutableStateOf(true) }
    var speed by remember { mutableFloatStateOf(1f) }
    var subtitleOn by remember { mutableStateOf(true) }
    var repeat by remember { mutableStateOf(RepeatMode.OFF) }
    var positionMs by remember { mutableLongStateOf(0) }
    var durationMs by remember { mutableLongStateOf(0) }

    DisposableEffect(Unit) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); player.release() }
    }

    Box(Modifier.fillMaxSize().background(c.background)) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            // header
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                AuroraGlassButton(onClick = onClose) {
                    Box(Modifier.padding(10.dp)) { AuroraIcon(AuroraIcons.ArrowBack, "رجوع", tint = c.textPrimary) }
                }
                Spacer(Modifier.width(10.dp))
                BasicText(title, style = t.titleLarge.copy(color = c.textPrimary),
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))

            // ── video surface / audio art ──
            if (!audioOnly) {
                GlassPanel {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                this.player = player
                                useController = false      // custom glass controls
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(LocalAuroraShapes.current.medium),
                    )
                }
            } else {
                GlassPanel(glowColor = c.glow) {
                    Column(
                        Modifier.fillMaxWidth().height(220.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        AuroraIcon(AuroraIcons.Music, null, tint = c.brandPurple, modifier = Modifier.size(56.dp))
                        Spacer(Modifier.height(10.dp))
                        BasicText(title, style = t.titleMedium.copy(color = c.textPrimary),
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))

            // ── transport: progress + play + speed + subtitle ──
            val fraction = if (durationMs > 0) positionMs.toFloat() / durationMs else 0f
            AuroraProgressBar(fraction, Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                BasicText(fmt(positionMs), style = t.mono.copy(color = c.textTertiary))
                BasicText(fmt(durationMs), style = t.mono.copy(color = c.textTertiary))
            }
            Spacer(Modifier.height(16.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // morphing play/pause (spring scale)
                Box(
                    Modifier
                        .size(64.dp)
                        .background(c.brandGradient, LocalAuroraShapes.current.full)
                        .pressableScale({ if (player.isPlaying) player.pause() else player.play() }),
                    contentAlignment = Alignment.Center,
                ) {
                    AuroraIcon(
                        if (isPlaying) AuroraIcons.Pause else AuroraIcons.Play,
                        "تشغيل/إيقاف", tint = c.onAccent, modifier = Modifier.size(28.dp),
                    )
                }
            }
            Spacer(Modifier.height(18.dp))

            // repeat + sleep timer + audio-reactive visualizer (real APIs)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                RepeatMode.entries.forEach { m ->
                    GlassChip(Modifier.pressableScale({
                        repeat = m; player.repeatMode = exoRepeatFor(m)
                    })) {
                        BasicText(
                            m.label, Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            style = t.labelMedium.copy(color = if (repeat == m) c.brandPurple else c.textTertiary),
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            SleepTimerControl(onExpire = { player.pause() })
            Spacer(Modifier.height(10.dp))
            AudioVisualizer(player.audioSessionId, Modifier.fillMaxWidth().height(52.dp))
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0.5f, 1f, 1.5f, 2f).forEach { s ->
                    GlassChip(Modifier.pressableScale({ speed = s; player.setPlaybackSpeed(s) })) {
                        BasicText(
                            "${s}x", Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            style = t.labelLarge.copy(color = if (speed == s) c.brandPurple else c.textSecondary),
                        )
                    }
                }
                Spacer(Modifier.weight(1f))
                GlassChip(Modifier.pressableScale({
                    subtitleOn = !subtitleOn
                    player.trackSelectionParameters = player.trackSelectionParameters
                        .buildUpon().setTrackTypeDisabled(
                            androidx.media3.common.C.TRACK_TYPE_TEXT, !subtitleOn,
                        ).build()
                })) {
                    BasicText(
                        "الترجمة", Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        style = t.labelLarge.copy(color = if (subtitleOn) c.success else c.textTertiary),
                    )
                }
                GlassChip {
                    BasicText("PiP", Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        style = t.labelLarge.copy(color = c.textSecondary))
                }
            }
        }
    }
}

private fun fmt(ms: Long): String {
    val s = ms / 1000; val m = s / 60; val h = m / 60
    return if (h > 0) "%d:%02d:%02d".format(h, m % 60, s % 60) else "%02d:%02d".format(m % 60, s % 60)
}
