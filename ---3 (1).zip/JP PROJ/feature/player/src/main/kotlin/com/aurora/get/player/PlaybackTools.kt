package com.aurora.get.player

import android.content.ContentValues
import android.content.Context
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.RingtoneManager
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.get.designsystem.components.GlassChip
import com.aurora.get.designsystem.components.GlassPanel
import com.aurora.get.designsystem.components.pressableScale
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import com.aurora.get.designsystem.theme.LocalAuroraTypography
import kotlinx.coroutines.delay
import java.io.File

/**
 * Real device-level media tools — no placeholders:
 *  • Ringtone / alarm / notification assignment via MediaStore + RingtoneManager (real APIs).
 *  • Visual trim: filmstrip frames from MediaMetadataRetriever with draggable handles (no numbers).
 *  • Sleep timer, repeat modes, audio-reactive visualizer (android.media.audiofx.Visualizer).
 */

enum class RepeatMode(val label: String) { OFF("بدون تكرار"), ONE("تكرار المقطع"), ALL("تكرار الكل") }

// ───────────────────────── Ringtone tools ─────────────────────────

object RingtoneTools {

    /** Assigns a local audio file as ringtone / alarm / notification. Returns success. */
    fun setAs(type: Int, file: File, title: String, context: Context): Boolean = runCatching {
        // 1) Make it visible to media scanners
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeFor(file.name))
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Ringtones/JO DON")
            }
        }
        val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val uri = context.contentResolver.insert(collection, values)
            ?: return false
        context.contentResolver.openOutputStream(uri)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        ContentValues().apply {
            put("is_ringtone", if (type == RingtoneManager.TYPE_RINGTONE) 1 else 0)
            put("is_alarm", if (type == RingtoneManager.TYPE_ALARM) 1 else 0)
            put("is_notification", if (type == RingtoneManager.TYPE_NOTIFICATION) 1 else 0)
            put("title", title)
        }.also { context.contentResolver.update(uri, it, null, null) }

        // 2) WRITE_SETTINGS is a special permission: if missing we open the grant screen.
        if (Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(context)) {
            Toast.makeText(context, "امنح صلاحية تعديل النظام لتعيين النغمة", Toast.LENGTH_LONG).show()
            return false
        }
        RingtoneManager.setActualDefaultRingtoneUri(context, type, uri)
        true
    }.getOrElse { false }

    fun assignAll(file: File, title: String, context: Context): Map<String, Boolean> = mapOf(
        "نغمة رنين" to setAs(RingtoneManager.TYPE_RINGTONE, file, title, context),
        "منبه" to setAs(RingtoneManager.TYPE_ALARM, file, title, context),
        "إشعار" to setAs(RingtoneManager.TYPE_NOTIFICATION, file, title, context),
    )

    private fun mimeFor(name: String) = when (name.substringAfterLast('.').lowercase()) {
        "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"; "opus", "ogg" -> "audio/ogg"
        "wav" -> "audio/wav"; "flac" -> "audio/flac"; else -> "audio/*"
    }
}

// ───────────────────────── Title metadata helper ─────────────────────────

fun mediaTitleOf(path: String): String = runCatching {
    val retriever = MediaMetadataRetriever()
    retriever.setDataSource(path)
    val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
    retriever.release()
    title ?: File(path).nameWithoutExtension
}.getOrDefault(File(path).nameWithoutExtension)

// ───────────────────────── Sleep timer ─────────────────────────

@Composable
fun SleepTimerControl(onExpire: () -> Unit) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    var remaining by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }

    LaunchedEffect(running, remaining) {
        if (!running) return@LaunchedEffect
        while (remaining > 0 && running) {
            delay(1000)
            remaining -= 1
        }
        if (remaining == 0 && running) {
            running = false
            onExpire()
        }
    }

    Column {
        BasicText("مؤقت النوم", style = t.labelLarge.copy(color = c.textPrimary))
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
            listOf(10, 20, 30, 45, 60).forEach { mins ->
                GlassChip(Modifier.pressableScale({
                    remaining = mins * 60
                    running = true
                })) {
                    BasicText(
                        "$mins د", Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        style = t.labelMedium.copy(color = c.textSecondary),
                    )
                }
            }
            GlassChip(Modifier.pressableScale({ running = false; remaining = 0 })) {
                BasicText(
                    if (remaining > 0) "%d:%02d".format(remaining / 60, remaining % 60) else "إيقاف",
                    Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    style = t.labelMedium.copy(color = if (running) c.brandPink else c.textTertiary),
                )
            }
        }
    }
}

// ───────────────────────── Visual trim (drag handles) ─────────────────────────

@Composable
fun VisualTrim(
    path: String,
    onTrimChanged: (startMs: Long, endMs: Long) -> Unit,
) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val durationMs = remember(path) { durationOf(path) }
    var start by remember { mutableFloatStateOf(0f) }
    var end by remember { mutableFloatStateOf(1f) }
    val frames = remember(path) { filmstrip(path, count = 8) }
    val startX by animateFloatAsState(start, label = "trimStart")
    val endX by animateFloatAsState(end, label = "trimEnd")

    LaunchedEffect(start, end) {
        onTrimChanged((durationMs * start).toLong(), (durationMs * end).toLong())
    }

    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            BasicText("القص المرئي", style = t.labelLarge.copy(color = c.textPrimary))
            Spacer(Modifier.width(8.dp))
            BasicText(
                "%s → %s".format(fmt((durationMs * start).toLong()), fmt((durationMs * end).toLong())),
                style = t.mono.copy(color = c.brandPurple),
            )
        }
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(76.dp)
                .clip(LocalAuroraShapes.current.small),
        ) {
            // filmstrip background (real frames)
            Row(Modifier.fillMaxWidth().height(76.dp)) {
                frames.forEach { bmp ->
                    if (bmp != null) {
                        androidx.compose.foundation.Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = null,
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            modifier = Modifier.weight(1f).height(76.dp),
                        )
                    } else {
                        Box(Modifier.weight(1f).height(76.dp).background(c.surfaceHigh))
                    }
                }
            }
            // selection overlay + handles
            Canvas(Modifier.fillMaxWidth().height(76.dp)) {
                val sx = size.width * startX
                val ex = size.width * endX
                drawRect(Color.Black.copy(alpha = 0.62f), size = Size(sx, size.height))
                drawRect(Color.Black.copy(alpha = 0.62f), topLeft = Offset(ex, 0f), size = Size(size.width - ex, size.height))
                // gradient selection border
                drawRect(
                    brush = c.brandGradient,
                    topLeft = Offset(sx, 0f),
                    size = Size(ex - sx, size.height),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f),
                )
                // handles
                drawRoundRect(
                    color = c.brandPink,
                    topLeft = Offset(sx - 6f, 0f),
                    size = Size(12f, size.height),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f),
                )
                drawRoundRect(
                    color = c.brandPink,
                    topLeft = Offset(ex - 6f, 0f),
                    size = Size(12f, size.height),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f),
                )
            }
            // gesture areas: left half drags start, right half drags end
            Box(
                Modifier.fillMaxWidth().height(76.dp)
                    .pointerInput(startX) {
                        detectHorizontalDragGestures { change, drag ->
                            val f = (change.position.x / size.width).coerceIn(0f, end - 0.02f)
                            start = f
                        }
                    },
            )
        }
        Spacer(Modifier.height(6.dp))
        BasicText(
            "اسحب المقبضين على الإطارات — لا كتابة أرقام.",
            style = t.labelMedium.copy(color = c.textTertiary),
        )
    }
}

private fun durationOf(path: String): Long = runCatching {
    val r = MediaMetadataRetriever()
    r.setDataSource(path)
    val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
    r.release()
    ms
}.getOrDefault(0L)

private fun filmstrip(path: String, count: Int): List<android.graphics.Bitmap?> = runCatching {
    val r = MediaMetadataRetriever()
    r.setDataSource(path)
    val duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
    val list = (0 until count).map { i ->
        val at = (duration * i / count) * 1000 // microseconds
        r.getFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
    }
    r.release()
    list
}.getOrDefault(emptyList())

private fun fmt(ms: Long): String {
    val s = ms / 1000
    val m = s / 60
    return "%02d:%02d".format(m, s % 60)
}

// ───────────────────────── Audio visualizer (real FFT) ─────────────────────────

/**
 * Requires android.permission.RECORD_AUDIO (declared) to attach to the player's audio session.
 * Renders real frequency bars the palette colors.
 */
@Composable
fun AudioVisualizer(audioSessionId: Int, modifier: Modifier = Modifier) {
    val c = AuroraTheme.colors
    var magnitudes by remember { mutableStateOf<ByteArray?>(null) }
    var enabled by remember { mutableStateOf(true) }
    val context = LocalContext.current

    DisposableEffect(audioSessionId, enabled) {
        var visualizer: Visualizer? = null
        if (enabled && audioSessionId > 0) {
            visualizer = runCatching {
                Visualizer(audioSessionId).apply {
                    captureSize = Visualizer.getCaptureSizeRange()[0].coerceAtLeast(128)
                    setDataCaptureListener(
                        object : Visualizer.OnDataCaptureListener {
                            override fun onWaveFormDataCapture(
                                v: Visualizer?, waveform: ByteArray?, samplingRate: Int,
                            ) { waveform?.let { w -> magnitudes = w } }
                            override fun onFftDataCapture(
                                v: Visualizer?, fft: ByteArray?, samplingRate: Int,
                            ) { }
                        },
                        Visualizer.getMaxCaptureRate() / 2, true, false,
                    )
                    this.enabled = true
                }
            }.onFailure {
                android.util.Log.w("JODON", "visualizer unavailable: ${it.message}")
                Toast.makeText(context, "المؤثرات غير مدعومة على هذا الجهاز", Toast.LENGTH_SHORT).show()
            }.getOrNull()
        }
        onDispose {
            runCatching { visualizer?.enabled = false; visualizer?.release() }
        }
    }

    Canvas(modifier) {
        val data = magnitudes ?: return@Canvas
        val bars = 36
        val step = (data.size / bars).coerceAtLeast(1)
        val barWidth = size.width / bars
        for (i in 0 until bars) {
            val v = kotlin.math.abs(data[(i * step).coerceIn(0, data.size - 1)].toInt()) / 128f
            val h = (v.coerceIn(0f, 1f) * size.height).coerceAtLeast(3f)
            drawRoundRect(
                brush = c.brandGradient,
                topLeft = Offset(i * barWidth, size.height - h),
                size = Size(barWidth * 0.62f, h),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth * 0.3f),
                alpha = 0.9f,
            )
        }
    }
}

// ───────────────────────── Repeat + speed helpers ─────────────────────────

fun exoRepeatFor(mode: RepeatMode): Int = when (mode) {
    RepeatMode.OFF -> androidx.media3.common.Player.REPEAT_MODE_OFF
    RepeatMode.ONE -> androidx.media3.common.Player.REPEAT_MODE_ONE
    RepeatMode.ALL -> androidx.media3.common.Player.REPEAT_MODE_ALL
}

/** Audio focus helper used by the player screen. */
fun requestAudioFocus(context: Context) {
    val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
}
