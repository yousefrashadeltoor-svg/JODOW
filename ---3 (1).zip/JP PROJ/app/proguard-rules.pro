# Aurora Get — R8/ProGuard rules

# Coroutines / Serialization
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.serialization.json.** { *; }
-keepclasseswithmembers class * {
    @kotlinx.serialization.Serializable <init>(...);
}
-keep,includedescriptorclasses class com.aurora.get.**$$serializer { *; }
-keepclassmembers class com.aurora.get.** {
    *** Companion;
}

# yt-dlp / youtubedl-android (native helpers + python zip assets)
-keep class com.yausername.youtubedl_android.** { *; }
-keep class com.yausername.ffmpeg.** { *; }
-keep class com.yausername.aria2c.** { *; }
-dontwarn com.yausername.**

# OkHttp / Okio
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**

# Cronet (optional)
-dontwarn org.chromium.net.**

# Coil / Haze / Lottie
-dontwarn coil3.**
-dontwarn dev.chrisbanes.haze.**
-dontwarn com.airbnb.lottie.**

# zstd-jni / brotli native
-keep class com.github.luben.zstd.** { *; }
-dontwarn org.brotli.**

# Room / WorkManager / Hilt are covered by their own aar rules.
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
