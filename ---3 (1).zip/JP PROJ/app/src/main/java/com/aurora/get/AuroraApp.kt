package com.aurora.get

import android.app.Application
import com.aurora.get.extractors.ytdlp.YtDlpExtractor
import com.aurora.get.feature.browser.AdBlockEngine
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@HiltAndroidApp
class AuroraApp : Application() {

    @Inject lateinit var ytDlp: YtDlpExtractor
    @Inject lateinit var adBlock: AdBlockEngine

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) Timber.plant(Timber.DebugTree())

        // Background auto-updates on cold start (spec §5, §11).
        appScope.launch {
            launch { ytDlp.updateEngine() }        // yt-dlp itself (1800+ extractors)
            launch { adBlock.updateLists() }       // EasyList / EasyPrivacy
        }
    }
}
