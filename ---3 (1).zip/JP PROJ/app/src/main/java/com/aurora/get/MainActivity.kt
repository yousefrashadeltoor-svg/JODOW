package com.aurora.get

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.aurora.get.designsystem.components.DockItem
import com.aurora.get.designsystem.components.GlassDock
import com.aurora.get.designsystem.icons.AuroraIcons
import com.aurora.get.designsystem.theme.LocalAuroraColors
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import com.aurora.get.designsystem.theme.localAuroraTypographyProvider
import com.aurora.get.designsystem.theme.paletteFor
import com.aurora.get.designsystem.theme.AuroraThemeId
import com.aurora.get.feature.browser.ui.BrowserScreen
import com.aurora.get.feature.compressor.CompressorScreen
import com.aurora.get.feature.converter.ConverterScreen
import com.aurora.get.feature.downloads.ui.DownloadsScreen
import com.aurora.get.feature.files.FilesScreen
import com.aurora.get.feature.home.ui.HomeScreen
import com.aurora.get.feature.settings.SettingsScreen
import com.aurora.get.feature.youtube.ui.YouTubeScreen
import com.aurora.get.designsystem.theme.LocalAuroraMotion
import com.aurora.get.designsystem.theme.ThemeController
import com.aurora.get.designsystem.theme.motionFor
import com.aurora.get.onboarding.OnboardingScreen
import dagger.hilt.android.AndroidEntryPoint
import java.net.URLDecoder
import java.net.URLEncoder

/**
 * Root activity: Splash → Onboarding (first run) → Glass host with floating dock.
 * Predictive Back is enabled manifest-side; transitions are Fade-Through + Scale + Blur.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val sharedText = extractSharedLink(intent)

        setContent {
            // RTL-first: Arabic default layout direction (both languages supported).
            AuroraAppRoot(initialLink = sharedText)
        }
    }

    // Share target / VIEW intents land here (singleTask + onNewIntent).
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        extractSharedLink(intent)?.let { pendingSharedLink = it }
    }

    private fun extractSharedLink(intent: Intent?): String? {
        if (intent == null) return null
        return when (intent.action) {
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> intent.dataString
            else -> null
        }?.let { Regex("https?://\\S+").find(it)?.value }
    }

    companion object {
        /** Bridges share intents into Compose state. */
        var pendingSharedLink: String? = null
    }
}

private object Routes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val DOWNLOADS = "downloads"
    const val BROWSER = "browser?url={url}"
    const val CONVERTER = "converter"
    const val COMPRESSOR = "compressor"
    const val FILES = "files"
    const val SETTINGS = "settings"
    const val YOUTUBE = "jo-tube"
}

@Composable
fun AuroraAppRoot(initialLink: String?) {
    val nav = rememberNavController()
    val themeId by ThemeController.id
    var onboarded by remember { mutableStateOf(false) }
    val colors = paletteFor(themeId)
    val motion = motionFor(themeId)

    CompositionLocalProvider(
        LocalAuroraColors provides colors,
        LocalAuroraMotion provides motion,
        LocalLayoutDirection provides LayoutDirection.Rtl,
        localAuroraTypographyProvider(),
    ) {
        Box(Modifier.fillMaxSize()) {
            NavHost(
                navController = nav,
                startDestination = if (onboarded) Routes.HOME else Routes.ONBOARDING,
                enterTransition = { fadeIn() + scaleIn(initialScale = 0.94f) + slideInVertically { it / 18 } },
                exitTransition = { fadeOut() + scaleOut(targetScale = 0.96f) },
                popEnterTransition = { fadeIn() + scaleIn(initialScale = 0.96f) },
                popExitTransition = { fadeOut() + scaleOut(targetScale = 0.94f) + slideOutVertically { it / 20 } },
            ) {
                composable(Routes.ONBOARDING) {
                    OnboardingScreen(onDone = {
                        onboarded = true
                        nav.navigate(Routes.HOME) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                    })
                }
                composable(Routes.HOME) {
                    HomeScreen(
                        onNavigateBrowser = { url ->
                            nav.navigate("browser?url=${URLEncoder.encode(url, "UTF-8")}")
                        },
                    )
                    // shared → paste into the field
                    LaunchedEffect(initialLink, MainActivity.pendingSharedLink) {
                        (MainActivity.pendingSharedLink ?: initialLink)?.let {
                            MainActivity.pendingSharedLink = null
                        }
                    }
                }
                composable(Routes.DOWNLOADS) { DownloadsScreen() }
                composable(
                    Routes.BROWSER,
                    arguments = listOf(navArgument("url") { type = NavType.StringType; defaultValue = "https://www.google.com" }),
                ) { backStack ->
                    val url = backStack.arguments?.getString("url")
                        ?.let { URLDecoder.decode(it, "UTF-8") } ?: "about:blank"
                    BrowserScreen(startUrl = url, onBack = { nav.popBackStack() })
                }
                composable(Routes.CONVERTER) { ConverterScreen() }
                composable(Routes.COMPRESSOR) { CompressorScreen() }
                composable(Routes.YOUTUBE) { YouTubeScreen() }
                composable(Routes.FILES) { FilesScreen() }
                composable(Routes.SETTINGS) { SettingsScreen() }
            }

            // Floating glass dock — hidden on browser to give pages full space
            val backStack by nav.currentBackStackEntryAsState()
            val current = backStack?.destination?.route
            if (current != null && !current.startsWith("browser") && current != Routes.ONBOARDING) {
                GlassDock(
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
                    items = listOf(
                        DockItem("home", AuroraIcons.Home, "الرئيسية"),
                        DockItem("downloads", AuroraIcons.Download, "التحميلات", badge = 0),
                        DockItem("youtube", AuroraIcons.Play, "يوتيوب"),
                        DockItem("browser", AuroraIcons.Browser, "المتصفح"),
                        DockItem("files", AuroraIcons.Files, "الملفات"),
                        DockItem("settings", AuroraIcons.Settings, "الإعدادات"),
                    ),
                    selectedId = when (current) {
                        Routes.YOUTUBE -> "youtube"
                        Routes.DOWNLOADS -> "downloads"
                        Routes.FILES -> "files"
                        Routes.SETTINGS -> "settings"
                        else -> "home"
                    },
                    onSelect = { id ->
                        val route = when (id) {
                            "home" -> Routes.HOME
                            "downloads" -> Routes.DOWNLOADS
                            "youtube" -> Routes.YOUTUBE
                            "browser" -> "browser?url=${URLEncoder.encode("https://www.google.com", "UTF-8")}"
                            "files" -> Routes.FILES
                            else -> Routes.SETTINGS
                        }
                        nav.navigate(route) {
                            popUpTo(Routes.HOME) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                )
            }
        }
    }
}
