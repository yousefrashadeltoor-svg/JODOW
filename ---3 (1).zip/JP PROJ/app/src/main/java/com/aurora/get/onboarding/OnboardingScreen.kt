package com.aurora.get.onboarding

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.aurora.get.designsystem.components.AuroraButton
import com.aurora.get.designsystem.components.AuroraIcon
import com.aurora.get.designsystem.components.GradientText
import com.aurora.get.designsystem.effects.MeshGradientBackground
import com.aurora.get.designsystem.icons.AuroraIcons
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import com.aurora.get.designsystem.theme.LocalAuroraTypography
import kotlinx.coroutines.launch

/**
 * Quick onboarding (spec §10.4-7): three wordless beats + legal note, physics swipes,
 * gradient headline, pulsing orb logo.
 */
@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val pages = listOf(
        Triple(AuroraIcons.Link, "الصق أي رابط",
            "من أكثر من 1800 موقع — فيديو وصوت وصور وملفات. أول معلومة تظهر خلال أقل من ثلث ثانية."),
        Triple(AuroraIcons.Download, "سرعة البرق",
            "حتى 32 اتصالًا متوازيًا تقتسم العمل ذاتيًا، واستكمال دقيق بعد أي انقطاع."),
        Triple(AuroraIcons.Shield, "خصوصية مطلقة",
            "لا تتبع ولا حسابات. كل شيء على جهازك، والكوكيز مشفرة. المسؤولية في احترام حقوق النشر عليك."),
    )
    val pager = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()

    Box(Modifier.fillMaxSize()) {
        MeshGradientBackground(Modifier.matchParentSize())
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Spacer(Modifier.height(46.dp))
            GradientText("أورورا غِت", t.displayLarge, Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(8.dp))
            BasicText("حمّل أي شيء. من أي مكان.",
                style = t.bodyLarge.copy(color = c.textSecondary),
                modifier = Modifier.align(Alignment.CenterHorizontally))

            HorizontalPager(
                state = pager,
                modifier = Modifier.weight(1f),
            ) { i ->
                val (icon, headline, body) = pages[i]
                Page(icon = icon, headline = headline, body = body, active = pager.currentPage == i)
            }

            // dots + CTA
            Row(Modifier.align(Alignment.CenterHorizontally), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(pages.size) { i ->
                    val active = pager.currentPage == i
                    val w by animateFloatAsState(if (active) 26f else 8f,
                        spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "dot")
                    Box(
                        Modifier
                            .size(width = w.dp, height = 8.dp)
                            .background(
                                if (active) c.brandPurple else c.textTertiary.copy(alpha = 0.4f),
                                LocalAuroraShapes.current.full,
                            ),
                    )
                }
            }
            Spacer(Modifier.height(26.dp))
            AuroraButton(
                onClick = {
                    if (pager.currentPage < pages.size - 1) {
                        scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                    } else onDone()
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                BasicText(
                    if (pager.currentPage < pages.size - 1) "التالي" else "ابدأ الآن",
                    Modifier.padding(vertical = 14.dp),
                    style = t.labelLarge.copy(color = c.onAccent),
                )
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun Page(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    headline: String, body: String, active: Boolean,
) {
    val c = AuroraTheme.colors
    val t = LocalAuroraTypography.current
    val scale by animateFloatAsState(
        if (active) 1f else 0.86f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "page",
    )
    Column(
        Modifier.fillMaxWidth().graphicsLayer { scaleX = scale; scaleY = scale },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(20.dp))
        Box(
            Modifier.size(150.dp).background(c.brandGradient, LocalAuroraShapes.current.squircle).alpha(0.85f),
            contentAlignment = Alignment.Center,
        ) {
            AuroraIcon(icon, null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(58.dp))
        }
        Spacer(Modifier.height(28.dp))
        GradientText(headline, t.headlineLarge)
        Spacer(Modifier.height(10.dp))
        BasicText(
            body, style = t.bodyLarge.copy(color = c.textSecondary),
            modifier = Modifier.padding(horizontal = 12.dp),
        )
        Spacer(Modifier.height(20.dp))
    }
}
