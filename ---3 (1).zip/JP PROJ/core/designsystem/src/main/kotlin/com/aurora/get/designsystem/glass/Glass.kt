package com.aurora.get.designsystem.glass

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import kotlin.random.Random

/**
 * Real Glassmorphism pipeline:
 *  content/blur source (hazeSource) -> glass panel (hazeEffect) ->
 *  translucent gradient fill -> 1dp specular inner border -> soft multi-layer shadow ->
 *  faint noise granules.
 *
 * VERIFY: haze 1.x modifier names (hazeSource/hazeEffect). Older 0.x used haze/hazeChild.
 */

/** Remember a shared blur source state for a screen. Apply [hazeSource] on the background. */
@Composable
fun rememberGlassBackgroundState(): HazeState = remember { HazeState() }

/** True blur behind the panel using the shared haze state. */
fun Modifier.glassBlur(
    hazeState: HazeState,
    shape: Shape,
): Modifier = this.hazeEffect(state = hazeState) { }.clip(shape)

/** Layered translucent fill — brightens toward the top like actual glass. */
fun Modifier.glassSurface(
    shape: Shape,
    fill: Color? = null,
): Modifier = drawWithCache {
    val f = fill ?: Color(0x14FFFFFF)
    val brush = Brush.verticalGradient(
        listOf(f.copy(alpha = minOf(1f, f.alpha * 1.6f)), f)
    )
    onDrawBehind { drawRect(brush) }
}.glassAmbientShadow(shape)

/** Soft multi-layer shadow with a colored glow option. */
fun Modifier.glassAmbientShadow(
    shape: Shape,
    glowColor: Color = Color.Unspecified,
    elevation: Dp = 14.dp,
): Modifier = drawBehind {
    val glow = if (glowColor == Color.Unspecified) Color.Black else glowColor
    val layers = 3
    repeat(layers) { i ->
        val t = (i + 1) / layers.toFloat()
        val radius = elevation.toPx() * (1f + t * 1.8f)
        val alpha = if (glowColor == Color.Unspecified) 0.16f * (1f - t) + 0.04f else 0.10f * (1f - t)
        drawCircle(
            color = glow.copy(alpha = alpha),
            radius = radius,
            center = Offset(size.width / 2f, size.height / 2f + elevation.toPx() * t * 0.6f),
            blendMode = BlendMode.SrcOver,
        )
    }
}

/**
 * 1dp inner "specular" border drawn as a gradient: strong top-left light, fading bottom-right.
 * This is the key detail that sells the glass look.
 */
fun Modifier.specularBorder(
    shape: Shape,
    color: Color = Color.White,
    baseAlpha: Float = 0.22f,
): Modifier = drawWithCache {
    val strokeWidth = 1.dp.toPx()
    val brush = Brush.linearGradient(
        0.0f to color.copy(alpha = baseAlpha * 2f),
        0.35f to color.copy(alpha = baseAlpha),
        1.0f to color.copy(alpha = 0.04f),
        start = Offset.Zero,
        end = Offset(size.width, size.height),
    )
    onDrawWithContent {
        drawContent()
        drawOutlineBorder(shape, brush, strokeWidth)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawOutlineBorder(
    shape: Shape,
    brush: Brush,
    strokeWidth: Float,
) {
    val outline = shape.createOutline(size, layoutDirection, this)
    when (outline) {
        is androidx.compose.ui.graphics.Outline.Rounded ->
            drawRoundRect(
                brush = brush,
                topLeft = Offset(outline.roundRect.left, outline.roundRect.top),
                size = androidx.compose.ui.geometry.Size(
                    outline.roundRect.width, outline.roundRect.height
                ),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(outline.roundRect.topLeftCornerRadius.x),
                style = Stroke(width = strokeWidth),
            )
        is androidx.compose.ui.graphics.Outline.Rectangle ->
            drawRect(brush = brush, style = Stroke(width = strokeWidth))
        is androidx.compose.ui.graphics.Outline.Generic ->
            drawPath(outline.path, brush = brush, style = Stroke(width = strokeWidth))
    }
}

/** Faint static-noise granules — extremely subtle texture on glass surfaces. */
fun Modifier.noiseOverlay(alpha: Float = 0.028f, grain: Dp = 3.dp): Modifier = drawWithCache {
    val step = grain.toPx().toInt().coerceAtLeast(2)
    val rnd = Random(42)
    onDrawWithContent {
        drawContent()
        var x = 0
        while (x < size.width) {
            var y = 0
            while (y < size.height) {
                if (rnd.nextFloat() < 0.07f) {
                    val v = rnd.nextFloat()
                    drawRect(
                        color = (if (v > 0.5f) Color.White else Color.Black).copy(alpha = alpha),
                        topLeft = Offset(x.toFloat(), y.toFloat()),
                        size = androidx.compose.ui.geometry.Size(step / 2f, step / 2f),
                    )
                }
                y += step
            }
            x += step
        }
    }
}

/** All-in-one glass panel. The workhorse of the Aurora Glass design system. */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    hazeState: HazeState? = null,
    shape: Shape? = null,
    glowColor: Color = Color.Unspecified,
    content: @Composable BoxScope.() -> Unit,
) {
    val s = shape ?: LocalAuroraShapes.current.medium
    val fill = AuroraTheme.colors.glassFill
    val borderColor = AuroraTheme.colors.glassBorder
    Box(
        modifier
            .clip(s)
            .then(if (hazeState != null) Modifier.hazeEffect(state = hazeState) {} else Modifier)
            .glassSurface(s, fill)
            .specularBorder(s, borderColor)
            .noiseOverlay()
            .then(
                if (glowColor != Color.Unspecified) Modifier.glassAmbientShadow(s, glowColor)
                else Modifier
            ),
        content = content,
    )
}

/** Light-weight glass chip (no blur) for dense lists. */
@Composable
fun GlassChip(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(percent = 50),
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier
            .clip(shape)
            .glassSurface(shape)
            .specularBorder(shape, AuroraTheme.colors.glassBorder, baseAlpha = 0.16f),
        content = content,
    )
}
