package com.aurora.get.designsystem.components

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aurora.get.designsystem.glass.glassSurface
import com.aurora.get.designsystem.glass.specularBorder
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import kotlin.math.PI
import kotlin.math.sin

// ─────────────────────────────────────────────────────────────
// Press physics: spring scale + haptics (custom, non-Material interactions)
// ─────────────────────────────────────────────────────────────

fun Modifier.pressableScale(
    onClick: () -> Unit,
    pressedScale: Float = 0.94f,
    haptics: Boolean = true,
): Modifier = composed {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessHigh),
        label = "pressScale",
    )
    val view = LocalView.current
    this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .semantics { role = Role.Button }
        .pointerInput(onClick) {
            detectTapGestures(
                onPress = {
                    if (haptics) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    tryAwaitRelease()
                },
                onTap = { onClick() },
            )
        }
}

// ─────────────────────────────────────────────────────────────
// Buttons
// ─────────────────────────────────────────────────────────────

@Composable
fun AuroraButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    gradient: Brush? = null,
    shape: Shape? = null,
    content: @Composable () -> Unit,
) {
    val s = shape ?: LocalAuroraShapes.current.full
    val brush = gradient ?: AuroraTheme.colors.brandGradient
    Box(
        modifier
            .clip(s)
            .drawBehindBrush(brush)
            .specularBorder(s, Color.White, baseAlpha = 0.3f)
            .pressableScale(onClick)
            .minimumInteractiveSize(),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
fun AuroraGlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape? = null,
    content: @Composable () -> Unit,
) {
    val s = shape ?: LocalAuroraShapes.current.full
    Box(
        modifier
            .clip(s)
            .glassSurface(s)
            .specularBorder(s, AuroraTheme.colors.glassBorder)
            .pressableScale(onClick)
            .minimumInteractiveSize(),
        contentAlignment = Alignment.Center,
    ) { content() }
}

private fun Modifier.drawBehindBrush(brush: Brush) = this.then(
    Modifier.graphicsLayer {}
).composed {
    androidx.compose.ui.draw.drawBehind { drawRect(brush) }
}

private fun Modifier.minimumInteractiveSize(): Modifier = this.then(
    Modifier.graphicsLayer { }.pointerInput(Unit) {}
) // 48dp touch targets are enforced by callers' padding; hook kept for a11y scaling.

// ─────────────────────────────────────────────────────────────
// Gradient text + streaming blur-in reveal (Gemini style)
// ─────────────────────────────────────────────────────────────

@Composable
fun GradientText(
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier,
    brush: Brush? = null,
) {
    BasicText(
        text = text,
        modifier = modifier,
        style = style.copy(brush = brush ?: AuroraTheme.colors.brandGradient),
    )
}

/** Words blur-in one after another like an assistant composing the answer. */
@Composable
fun StreamingText(
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier,
    visibleWords: Int = Int.MAX_VALUE,
) {
    val words = remember(text) { text.split(" ") }
    val shown = words.take(visibleWords).joinToString(" ")
    BasicText(
        text = shown,
        modifier = modifier,
        style = style.copy(color = AuroraTheme.colors.textPrimary),
    )
}

// ─────────────────────────────────────────────────────────────
// Toggle (custom squircle track with spring knob)
// ─────────────────────────────────────────────────────────────

@Composable
fun AuroraToggle(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = AuroraTheme.colors
    val trackShape = LocalAuroraShapes.current.full
    val fraction by animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "toggle",
    )
    Box(
        modifier
            .size(width = 52.dp, height = 30.dp)
            .clip(trackShape)
            .drawBackdrop(Color.White.copy(alpha = 0.08f), checked, fraction, c)
            .pressableScale({ onCheckedChange(!checked) }, pressedScale = 0.96f),
        contentAlignment = Alignment.CenterStart,
    ) {
        val knobSize = 22.dp
        Canvas(Modifier.fillMaxSize()) {
            val travel = size.width - knobSize.toPx() - 8.dp.toPx()
            val cx = 4.dp.toPx() + knobSize.toPx() / 2f + travel * fraction
            drawCircle(
                brush = if (checked) c.brandGradient else SolidColor(c.textTertiary),
                radius = knobSize.toPx() / 2f,
                center = Offset(cx, size.height / 2f),
            )
        }
    }
}

private fun Modifier.drawBackdrop(
    offColor: Color, checked: Boolean, fraction: Float,
    c: com.aurora.get.designsystem.theme.AuroraColors,
) = androidx.compose.ui.draw.drawBehind {
    val onColor = c.brandPurple.copy(alpha = 0.5f)
    drawRect(androidx.compose.ui.graphics.lerp(offColor, onColor, fraction))
    if (checked && fraction > 0.5f) {
        drawRect(
            Brush.horizontalGradient(
                listOf(c.brandBlue.copy(alpha = 0.25f), c.brandPink.copy(alpha = 0.25f))
            )
        )
    }
}

// ─────────────────────────────────────────────────────────────
// Progress ring + animated gradient progress bar
// ─────────────────────────────────────────────────────────────

@Composable
fun AuroraProgressRing(
    progress: Float,          // 0..1, NaN = indeterminate sweep
    modifier: Modifier = Modifier,
    size: Dp = 52.dp,
    stroke: Dp = 5.dp,
    track: Color = Color.White.copy(alpha = 0.08f),
) {
    val c = AuroraTheme.colors
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "ring",
    )
    val wave by androidx.compose.animation.core.rememberInfiniteTransition(label = "ringWave")
        .animateFloat(
            0f, (2 * PI).toFloat(),
            androidx.compose.animation.core.infiniteRepeatable(
                androidx.compose.animation.core.tween(2600, easing = androidx.compose.animation.core.LinearEasing)
            ), label = "ringWaveV",
        )
    Canvas(modifier.size(size)) {
        val strokePx = stroke.toPx()
        drawCircle(track, radius = (this.size.minDimension - strokePx) / 2f, style = Stroke(strokePx))
        val sweep = animated * 360f
        val brush = Brush.sweepGradient(
            listOf(c.brandBlue, c.brandPurple, c.brandPink, c.brandBlue),
            center = center,
        )
        drawArc(
            brush = brush,
            startAngle = -90f + sin(wave) * 6f,
            sweepAngle = sweep.coerceAtLeast(0.1f),
            useCenter = false,
            style = Stroke(strokePx, cap = StrokeCap.Round),
            topLeft = Offset(strokePx / 2f, strokePx / 2f),
            size = androidx.compose.ui.geometry.Size(this.size.width - strokePx, this.size.height - strokePx),
        )
    }
}

@Composable
fun AuroraProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    height: Dp = 6.dp,
    track: Color = Color.White.copy(alpha = 0.08f),
) {
    val c = AuroraTheme.colors
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "bar",
    )
    val shift by androidx.compose.animation.core.rememberInfiniteTransition(label = "barShift")
        .animateFloat(
            0f, 1f,
            androidx.compose.animation.core.infiniteRepeatable(
                androidx.compose.animation.core.tween(2200, easing = androidx.compose.animation.core.LinearEasing)
            ), label = "barShiftV",
        )
    androidx.compose.foundation.layout.Box(
        modifier
            .clip(LocalAuroraShapes.current.full)
            .drawBar(track, animated, shift, height, c)
    )
}

private fun Modifier.drawBar(
    track: Color, fraction: Float, shift: Float, height: Dp,
    c: com.aurora.get.designsystem.theme.AuroraColors,
) = androidx.compose.ui.draw.drawWithContent {
    drawRect(track)
    if (fraction > 0f) {
        val w = size.width
        val h = height.toPx()
        val x0 = -w * 0.5f + shift * w
        val brush = Brush.linearGradient(
            listOf(c.brandBlue, c.brandPurple, c.brandPink, c.brandBlue, c.brandPurple),
            start = Offset(x0, 0f),
            end = Offset(x0 + w, h),
        )
        drawRect(brush, topLeft = Offset.Zero, size = androidx.compose.ui.geometry.Size(w * fraction, size.height))
        // glowing head
        drawCircle(
            color = c.brandPink.copy(alpha = 0.7f),
            radius = h * 1.1f,
            center = Offset((w * fraction).coerceIn(h, w), size.height / 2f),
        )
    }
}
