package com.aurora.get.designsystem.effects

import android.graphics.RuntimeShader
import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.aurora.get.designsystem.theme.AuroraTheme
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ─────────────────────────────────────────────────────────────
// Animated Mesh Gradient background (AGSL RuntimeShader on 33+, Brush fallback below)
// ─────────────────────────────────────────────────────────────

private const val MESH_SHADER = """
uniform float2 iResolution;
uniform float iTime;
uniform float3 cA;   // blue
uniform float3 cB;   // purple
uniform float3 cC;   // pink
uniform float3 base; // background

float blob(float2 uv, float2 p, float r) {
    return smoothstep(r, 0.0, length(uv - p));
}

half4 main(float2 fragCoord) {
    float2 uv = fragCoord / iResolution.xy;
    float t = iTime * 0.18;

    float2 p1 = float2(0.5 + 0.35 * cos(t),        0.34 + 0.25 * sin(t * 1.3));
    float2 p2 = float2(0.5 + 0.4  * cos(t * 0.7 + 2.1), 0.7 + 0.28 * sin(t * 0.9));
    float2 p3 = float2(0.5 + 0.3  * cos(t * 1.1 + 4.2), 0.5 + 0.38 * sin(t * 0.6 + 1.0));

    float b1 = blob(uv, p1, 0.55);
    float b2 = blob(uv, p2, 0.60);
    float b3 = blob(uv, p3, 0.65);

    float3 col = base;
    col = mix(col, cA, b1 * 0.55);
    col = mix(col, cB, b2 * 0.50);
    col = mix(col, cC, b3 * 0.45);
    // vignette to keep edges deep
    float vig = smoothstep(1.1, 0.35, length(uv - 0.5));
    col *= mix(0.72f, 1.0f, vig);
    return half4(col, 1.0);
}
"""

@Composable
fun MeshGradientBackground(modifier: Modifier = Modifier) {
    val c = AuroraTheme.colors
    val time by rememberInfiniteTransition(label = "mesh").animateFloat(
        initialValue = 0f, targetValue = 1000f,
        animationSpec = infiniteRepeatable(tween(120_000, easing = LinearEasing)),
        label = "meshTime",
    )
    if (Build.VERSION.SDK_INT >= 33) {
        val shader = remember { RuntimeShader(MESH_SHADER) }
        Canvas(modifier.fillMaxSize()) {
            shader.setFloatUniform("iResolution", size.width, size.height)
            shader.setFloatUniform("iTime", time)
            shader.setFloatUniform("cA", c.brandBlue.red, c.brandBlue.green, c.brandBlue.blue)
            shader.setFloatUniform("cB", c.brandPurple.red, c.brandPurple.green, c.brandPurple.blue)
            shader.setFloatUniform("cC", c.brandPink.red, c.brandPink.green, c.brandPink.blue)
            shader.setFloatUniform("base", c.background.red, c.background.green, c.background.blue)
            drawRect(brush = ShaderBrush(shader))
        }
    } else {
        // Fallback: three drifting radial blobs via linear/radial brushes.
        val t = time * 0.18f
        val p1 = Offset(0.5f + 0.35f * cos(t), 0.34f + 0.25f * sin(t * 1.3f))
        val p2 = Offset(0.5f + 0.4f * cos(t * 0.7f + 2.1f), 0.7f + 0.28f * sin(t * 0.9f))
        Canvas(modifier.fillMaxSize()) {
            drawRect(c.background)
            drawCircle(
                Brush.radialGradient(
                    listOf(c.brandBlue.copy(alpha = 0.35f), Color.Transparent),
                    center = Offset(p1.x * size.width, p1.y * size.height),
                    radius = size.maxDimension * 0.6f,
                )
            )
            drawCircle(
                Brush.radialGradient(
                    listOf(c.brandPurple.copy(alpha = 0.30f), Color.Transparent),
                    center = Offset(p2.x * size.width, p2.y * size.height),
                    radius = size.maxDimension * 0.65f,
                )
            )
            drawCircle(
                Brush.radialGradient(
                    listOf(c.brandPink.copy(alpha = 0.22f), Color.Transparent),
                    center = Offset(size.width * 0.5f, size.height * 0.55f),
                    radius = size.maxDimension * 0.7f,
                )
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Gemini-style rotating glow border (active while processing)
// ─────────────────────────────────────────────────────────────

/**
 * Draws a rotating conic (sweep) gradient stroke around [shape].
 * When [active] is false the glow gently idles at low alpha.
 */
/** Kept for API symmetry: the actual painting happens in [GlowRing]. */
fun Modifier.glowBorder(shape: Shape, active: Boolean): Modifier = this

@Composable
fun GlowRing(
    shape: Shape,
    active: Boolean,
    modifier: Modifier = Modifier,
) {
    val c = AuroraTheme.colors
    val alphaAnim = remember { Animatable(0.25f) }
    LaunchedEffect(active) {
        alphaAnim.animateTo(
            if (active) 1f else 0.25f,
            spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow),
        )
    }
    val rotation by rememberInfiniteTransition(label = "glowRot").animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (active) 2600 else 9000, easing = LinearEasing)),
        label = "glowRotVal",
    )
    Canvas(modifier) {
        val alpha = alphaAnim.value * 0.9f
        rotate(rotation) {
            val brush = Brush.sweepGradient(
                listOf(
                    c.brandBlue.copy(alpha = alpha),
                    c.brandPurple.copy(alpha = alpha),
                    c.brandPink.copy(alpha = alpha),
                    c.brandBlue.copy(alpha = alpha),
                ),
                center = center,
            )
            drawOutlineStroke(shape, brush, 3f)
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawOutlineStroke(
    shape: Shape, brush: Brush, widthDp: Float,
) {
    val outline = shape.createOutline(size, layoutDirection, this)
    val stroke = Stroke(width = widthDp * density)
    when (outline) {
        is androidx.compose.ui.graphics.Outline.Rounded ->
            drawRoundRect(
                brush,
                topLeft = Offset(outline.roundRect.left, outline.roundRect.top),
                size = androidx.compose.ui.geometry.Size(outline.roundRect.width, outline.roundRect.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(outline.roundRect.topLeftCornerRadius.x),
                style = stroke,
            )
        is androidx.compose.ui.graphics.Outline.Generic -> drawPath(outline.path, brush, style = stroke)
        else -> drawRect(brush, style = stroke)
    }
}

// ─────────────────────────────────────────────────────────────
// Completion particles (sparkles drifting upward)
// ─────────────────────────────────────────────────────────────

data class Particle(
    val x: Float, val speed: Float, val size: Float, val color: Color, val phase: Float,
)

@Composable
fun rememberParticles(count: Int = 18): List<Particle> {
    val c = AuroraTheme.colors
    return remember(count) {
        List(count) {
            Particle(
                x = kotlin.random.Random.nextFloat(),
                speed = 0.4f + kotlin.random.Random.nextFloat() * 0.9f,
                size = 2f + kotlin.random.Random.nextFloat() * 4f,
                color = listOf(c.brandBlue, c.brandPurple, c.brandPink, Color.White).random(),
                phase = kotlin.random.Random.nextFloat() * (2f * PI.toFloat()),
            )
        }
    }
}

@Composable
fun CompletionSparkles(modifier: Modifier = Modifier, particles: List<Particle> = rememberParticles()) {
    val t by rememberInfiniteTransition(label = "sparkle").animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3400, easing = LinearEasing)),
        label = "sparkleT",
    )
    Canvas(modifier) {
        particles.forEach { p ->
            val y = size.height * (1f - ((t * p.speed + p.phase / (2 * PI.toFloat())) % 1f))
            val x = size.width * p.x + sin((t * 2 + p.phase).toDouble()).toFloat() * 14f
            drawCircle(p.color.copy(alpha = 0.8f), radius = p.size, center = Offset(x, y))
        }
    }
}

/** Ticker used for shimmer-wave style delays in staggered reveals. */
@Composable
fun rememberStaggerDelay(index: Int, stepMs: Int = 55): Boolean {
    val visible = remember { androidx.compose.runtime.mutableStateOf(false) }
    LaunchedEffect(index) {
        delay((index * stepMs).toLong())
        visible.value = true
    }
    return visible.value
}
