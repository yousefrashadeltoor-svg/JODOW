package com.aurora.get.designsystem.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Aurora's custom outline icon set (24dp stroke icons, Lucide/Phosphor flavor).
 * Hand-drawn as ImageVector — these are NOT Material icons.
 */
object AuroraIcons {

    private fun builder(name: String) = ImageVector.Builder(
        name = name,
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
    )

    private fun strokePath(build: ImageVector.Builder.() -> ImageVector.Builder) =
        build.path(
            fill = SolidColor(Color.Transparent),
            stroke = SolidColor(Color.White),
            strokeLineWidth = 2f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
        ) {}.let { build }

    val Download: ImageVector = builder("Download").apply {
        strokePath { this }.run {}
        path(
            fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
            strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
        ) {
            moveTo(12f, 3f); lineTo(12f, 14f)
            moveTo(7f, 10f); lineTo(12f, 15f); lineTo(17f, 10f)
            moveTo(4f, 19f); lineTo(20f, 19f)
        }
    }.build()

    val Music: ImageVector = builder("Music").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(9f, 18f); moveTo(9f, 5f); lineTo(21f, 3f); lineTo(21f, 16f)
        addPath(oval(6f, 15f, 3f))
        addPath(oval(18f, 13f, 3f))
    }.build()

    val Image: ImageVector = builder("Image").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        addPath(rect(3f, 3f, 18f, 18f, 4f))
        moveTo(8.5f, 10f); addPath(oval(7f, 8.5f, 1.5f))
        moveTo(21f, 15f); lineTo(16f, 10f); lineTo(5f, 21f)
    }.build()

    val Video: ImageVector = builder("Video").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        addPath(rect(2f, 5f, 15f, 14f, 3f))
        moveTo(17f, 10f); lineTo(22f, 7f); lineTo(22f, 17f); lineTo(17f, 14f)
    }.build()

    val FileDoc: ImageVector = builder("File").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(14f, 2f); lineTo(6f, 2f); lineTo(6f, 22f); lineTo(18f, 22f); lineTo(18f, 6f); close()
        moveTo(14f, 2f); lineTo(14f, 6f); lineTo(18f, 6f)
    }.build()

    val Link: ImageVector = builder("Link").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(10f, 13f); curveTo(10f, 13f, 12.5f, 15.5f, 15f, 15.5f); curveToRelative(2.5f, 0f, 4f, -1.5f, 4f, -4f)
        moveTo(14f, 11f); curveTo(14f, 11f, 11.5f, 8.5f, 9f, 8.5f); curveTo(6.5f, 8.5f, 5f, 10f, 5f, 12.5f)
        moveTo(8f, 16f); lineTo(5f, 19f); moveTo(16f, 8f); lineTo(19f, 5f)
    }.build()

    val Paste: ImageVector = builder("Paste").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        addPath(rect(8f, 2f, 8f, 4f, 2f))
        moveTo(16f, 4f); lineTo(18f, 4f); quadToRelative(2f, 0f, 2f, 2f); lineTo(20f, 20f); quadToRelative(0f, 2f, -2f, 2f)
        lineTo(6f, 22f); quadToRelative(-2f, 0f, -2f, -2f); lineTo(4f, 6f); quadToRelative(0f, -2f, 2f, -2f); lineTo(8f, 4f)
    }.build()

    val Home: ImageVector = builder("Home").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(3f, 10.5f); lineTo(12f, 3f); lineTo(21f, 10.5f)
        moveTo(5f, 9.5f); lineTo(5f, 21f); lineTo(19f, 21f); lineTo(19f, 9.5f)
        moveTo(9.5f, 21f); lineTo(9.5f, 15f); lineTo(14.5f, 15f); lineTo(14.5f, 21f)
    }.build()

    val Browser: ImageVector = builder("Browser").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        addPath(rect(3f, 4f, 18f, 16f, 3f))
        moveTo(3f, 9f); lineTo(21f, 9f)
        moveTo(6.5f, 6.5f); lineTo(7f, 6.5f); moveTo(9.5f, 6.5f); lineTo(10f, 6.5f)
    }.build()

    val Convert: ImageVector = builder("Convert").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(4f, 8f); lineTo(20f, 8f); moveTo(16f, 4f); lineTo(20f, 8f); lineTo(16f, 12f)
        moveTo(20f, 16f); lineTo(4f, 16f); moveTo(8f, 12f); lineTo(4f, 16f); lineTo(8f, 20f)
    }.build()

    val Compress: ImageVector = builder("Compress").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(12f, 2f); lineTo(12f, 8f); moveTo(9f, 5.5f); lineTo(12f, 8f); lineTo(15f, 5.5f)
        moveTo(12f, 22f); lineTo(12f, 16f); moveTo(9f, 18.5f); lineTo(12f, 16f); lineTo(15f, 18.5f)
        moveTo(3f, 10f); lineTo(8f, 10f); lineTo(8f, 14f); lineTo(3f, 14f); close()
        moveTo(16f, 10f); lineTo(21f, 10f); lineTo(21f, 14f); lineTo(16f, 14f); close()
    }.build()

    val Files: ImageVector = builder("Files").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(3f, 7f); lineTo(3f, 19f); quadToRelative(0f, 2f, 2f, 2f); lineTo(19f, 21f); quadToRelative(2f, 0f, 2f, -2f)
        lineTo(21f, 7f); quadToRelative(0f, -2f, -2f, -2f); lineTo(12f, 5f); lineTo(10f, 3f); lineTo(5f, 3f); quadToRelative(-2f, 0f, -2f, 2f); close()
    }.build()

    val Settings: ImageVector = builder("Settings").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        addPath(oval(9f, 9f, 3f))
        moveTo(12f, 2f); lineTo(12f, 4f); moveTo(12f, 20f); lineTo(12f, 22f)
        moveTo(2f, 12f); lineTo(4f, 12f); moveTo(20f, 12f); lineTo(22f, 12f)
        moveTo(4.9f, 4.9f); lineTo(6.3f, 6.3f); moveTo(17.7f, 17.7f); lineTo(19.1f, 19.1f)
        moveTo(19.1f, 4.9f); lineTo(17.7f, 6.3f); moveTo(6.3f, 17.7f); lineTo(4.9f, 19.1f)
    }.build()

    val Play: ImageVector = builder("Play").path(
        fill = SolidColor(Color.White), stroke = null, pathFillType = PathFillType.NonZero,
    ) {
        moveTo(8f, 5f); lineTo(19f, 12f); lineTo(8f, 19f); close()
    }.build()

    val Pause: ImageVector = builder("Pause").path(
        fill = SolidColor(Color.White), stroke = null, pathFillType = PathFillType.NonZero,
    ) {
        addPath(rect(6f, 4f, 4f, 16f, 1.2f))
        addPath(rect(14f, 4f, 4f, 16f, 1.2f))
    }.build()

    val Sparkle: ImageVector = builder("Sparkle").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(12f, 3f); lineTo(13.6f, 9.2f); lineTo(20f, 12f); lineTo(13.6f, 14.8f); lineTo(12f, 21f)
        lineTo(10.4f, 14.8f); lineTo(4f, 12f); lineTo(10.4f, 9.2f); close()
    }.build()

    val Shield: ImageVector = builder("Shield").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(12f, 2f); lineTo(20f, 5.5f); lineTo(20f, 11f)
        curveTo(20f, 17f, 16f, 20f, 12f, 22f); curveTo(8f, 20f, 4f, 17f, 4f, 11f)
        lineTo(4f, 5.5f); close()
        moveTo(9f, 11.5f); lineTo(11.2f, 13.5f); lineTo(15.2f, 9.5f)
    }.build()

    val Fingerprint: ImageVector = builder("Fingerprint").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 1.8f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(7f, 5f); curveTo(8.5f, 4f, 10f, 3.5f, 12f, 3.5f); curveToRelative(5f, 0f, 8.5f, 3.5f, 8.5f, 8.5f)
        curveToRelative(0f, 3f, -0.5f, 6f, -1.5f, 8.5f)
        moveTo(3.5f, 12f); curveToRelative(0f, -4.7f, 3.8f, -8.5f, 8.5f, -8.5f)
        moveTo(6f, 12f); curveToRelative(0f, 4f, -0.8f, 6.5f, -2.5f, 9f)
        moveTo(12f, 8f); curveToRelative(2.5f, 0f, 4f, 1.7f, 4f, 4f); curveToRelative(0f, 3.2f, -0.7f, 6.4f, -2f, 9f)
        moveTo(12f, 12f); curveToRelative(0f, 3.5f, -0.7f, 6.8f, -2f, 9.5f)
    }.build()

    val ArrowBack: ImageVector = builder("Back").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(19f, 12f); lineTo(5f, 12f); moveTo(11f, 18f); lineTo(5f, 12f); lineTo(11f, 6f)
    }.build()

    val Close: ImageVector = builder("Close").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(6f, 6f); lineTo(18f, 18f); moveTo(18f, 6f); lineTo(6f, 18f)
    }.build()

    val Refresh: ImageVector = builder("Refresh").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(21f, 12f); curveTo(21f, 7f, 17f, 3f, 12f, 3f); curveTo(7.5f, 3f, 4f, 6f, 3.3f, 10f)
        moveTo(3f, 12f); curveTo(3f, 17f, 7f, 21f, 12f, 21f); curveTo(16.5f, 21f, 20f, 18f, 20.7f, 14f)
        moveTo(3f, 5f); lineTo(3.3f, 10f); lineTo(8f, 9f)
        moveTo(21f, 19f); lineTo(20.7f, 14f); lineTo(16f, 15f)
    }.build()

    val Check: ImageVector = builder("Check").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2.4f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        moveTo(4f, 12.5f); lineTo(9.5f, 18f); lineTo(20f, 6.5f)
    }.build()

    val Search: ImageVector = builder("Search").path(
        fill = null, stroke = SolidColor(Color.White), strokeLineWidth = 2f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
    ) {
        addPath(oval(7f, 7f, 7f)); moveTo(17f, 17f); lineTo(21.5f, 21.5f)
    }.build()

    val More: ImageVector = builder("More").path(
        fill = SolidColor(Color.White), stroke = null, pathFillType = PathFillType.NonZero,
    ) {
        addPath(oval(10.5f, 4.5f, 1.6f)); addPath(oval(10.5f, 10.5f, 1.6f)); addPath(oval(10.5f, 18f, 1.6f))
    }.build()

    private fun ImageVector.Builder.oval(x: Float, y: Float, r: Float): androidx.compose.ui.graphics.PathData {
        return androidx.compose.ui.graphics.PathParser().parsePathString(
            "M${x}f,${y}f a${r}f,${r}f 0 1,0 ${r * 2}f,0f a${r}f,${r}f 0 1,0 ${-r * 2}f,0f"
        ).toNodes().let { androidx.compose.ui.graphics.PathData(it) }
    }

    private fun ImageVector.Builder.rect(
        x: Float, y: Float, w: Float, h: Float, r: Float,
    ): androidx.compose.ui.graphics.PathData = androidx.compose.ui.graphics.PathData(
        androidx.compose.ui.graphics.PathParser().parsePathString(
            "M${x + r}f,${y}f h${w - 2 * r}f a$r f,$r f 0 0,1 $r f,$r f v${h - 2 * r}f " +
                "a$r f,$r f 0 0,1 ${-r}f,$r f h${-w + 2 * r}f a$r f,$r f 0 0,1 ${-r}f,${-r}f v${-h + 2 * r}f a$r f,$r f 0 0,1 $r f,${-r}f z"
        ).toNodes()
    )
}
