package com.aurora.get.designsystem.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * JO DON · Aurora Glass color system.
 * Every theme fully redefines surfaces, text, brand stops, type accents AND motion.
 * Nothing is inherited from another theme — each palette is complete and independent.
 */
@Immutable
data class AuroraColors(
    val background: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val glassFill: Color,
    val glassBorder: Color,
    val scrim: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val brandBlue: Color,
    val brandPurple: Color,
    val brandPink: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
    val info: Color,
    val typeVideo: Color,
    val typeAudio: Color,
    val typeImage: Color,
    val typeFile: Color,
    val glow: Color,
    val onAccent: Color,
) {
    val brandGradient: Brush
        get() = Brush.linearGradient(listOf(brandBlue, brandPurple, brandPink))
}

/** Motion identity per theme — animation speed/springiness travels with the palette. */
@Immutable
data class AuroraMotion(
    val springDamping: Float = 0.62f,
    val springStiffness: Float = 320f,
    val screenFadeMs: Int = 260,
    val shimmerMs: Int = 1500,
    val glowSpinMs: Int = 3200,
    val particlesEnabled: Boolean = true,
)

@Immutable
data class AuroraThemeSpec(
    val id: AuroraThemeId,
    val nameAr: String,
    val nameEn: String,
    val tagline: String,
    val colors: AuroraColors,
    val motion: AuroraMotion,
)

@Immutable
enum class AuroraThemeId(val isDark: Boolean) {
    AURORA(true), OCEAN(true), SUNSET(true), EMERALD(true), MONO(true), NEON(true), LIGHT(false)
}

val LocalAuroraColors = staticCompositionLocalOf { AuroraDark }
val LocalAuroraMotion = staticCompositionLocalOf { DefaultMotion }

// ───────────────────────── 1 · Aurora (default) ─────────────────────────
val AuroraDark = AuroraColors(
    background = Color(0xFF0B0D12), surface = Color(0xFF12141C), surfaceHigh = Color(0xFF1A1E2A),
    glassFill = Color(0x14FFFFFF), glassBorder = Color(0x33FFFFFF), scrim = Color(0xB3060810),
    textPrimary = Color(0xFFF2F4FA), textSecondary = Color(0xFFA7AEC2), textTertiary = Color(0xFF6B7386),
    brandBlue = Color(0xFF4E8CFF), brandPurple = Color(0xFF9B72CB), brandPink = Color(0xFFE0668C),
    success = Color(0xFF4ADE80), warning = Color(0xFFFBBF24), error = Color(0xFFF87171), info = Color(0xFF60A5FA),
    typeVideo = Color(0xFF7C6CFF), typeAudio = Color(0xFF3EC6D3), typeImage = Color(0xFFE0668C), typeFile = Color(0xFFF2A45C),
    glow = Color(0xFF7C6CFF), onAccent = Color.White,
)

// ───────────────────────── 2 · Ocean ─────────────────────────
val OceanDark = AuroraColors(
    background = Color(0xFF04121A), surface = Color(0xFF08202B), surfaceHigh = Color(0xFF0D2C39),
    glassFill = Color(0x16CFEFFF), glassBorder = Color(0x3ACFEFFF), scrim = Color(0xB3020B12),
    textPrimary = Color(0xFFEAFBFF), textSecondary = Color(0xFF9FC7D4), textTertiary = Color(0xFF5F8794),
    brandBlue = Color(0xFF38BDF8), brandPurple = Color(0xFF2DD4BF), brandPink = Color(0xFF818CF8),
    success = Color(0xFF34D399), warning = Color(0xFFFCD34D), error = Color(0xFFFB7185), info = Color(0xFF67E8F9),
    typeVideo = Color(0xFF38BDF8), typeAudio = Color(0xFF22D3EE), typeImage = Color(0xFFA78BFA), typeFile = Color(0xFF7DD3FC),
    glow = Color(0xFF2DD4BF), onAccent = Color(0xFF04121A),
)

// ───────────────────────── 3 · Sunset ─────────────────────────
val SunsetDark = AuroraColors(
    background = Color(0xFF14090A), surface = Color(0xFF21100F), surfaceHigh = Color(0xFF2E1715),
    glassFill = Color(0x18FFD9C2), glassBorder = Color(0x3AFFD9C2), scrim = Color(0xB30D0504),
    textPrimary = Color(0xFFFFF3EC), textSecondary = Color(0xFFD8B4A6), textTertiary = Color(0xFF9A776C),
    brandBlue = Color(0xFFF59E0B), brandPurple = Color(0xFFEF4444), brandPink = Color(0xFFEC4899),
    success = Color(0xFF84CC16), warning = Color(0xFFFBBF24), error = Color(0xFFFF6B6B), info = Color(0xFFFB923C),
    typeVideo = Color(0xFFF97316), typeAudio = Color(0xFFFBBF24), typeImage = Color(0xFFEC4899), typeFile = Color(0xFFFCA5A5),
    glow = Color(0xFFEF4444), onAccent = Color(0xFF14090A),
)

// ───────────────────────── 4 · Emerald ─────────────────────────
val EmeraldDark = AuroraColors(
    background = Color(0xFF05130D), surface = Color(0xFF0A2016), surfaceHigh = Color(0xFF102C1F),
    glassFill = Color(0x16CFFFE0), glassBorder = Color(0x3ACFFFE0), scrim = Color(0xB3020F08),
    textPrimary = Color(0xFFE9FFF3), textSecondary = Color(0xFF9FD4B6), textTertiary = Color(0xFF5E8B72),
    brandBlue = Color(0xFF34D399), brandPurple = Color(0xFF10B981), brandPink = Color(0xFF84CC16),
    success = Color(0xFF4ADE80), warning = Color(0xFFFDE047), error = Color(0xFFF87171), info = Color(0xFF2DD4BF),
    typeVideo = Color(0xFF34D399), typeAudio = Color(0xFF2DD4BF), typeImage = Color(0xFFA3E635), typeFile = Color(0xFF86EFAC),
    glow = Color(0xFF10B981), onAccent = Color(0xFF05130D),
)

// ───────────────────────── 5 · Mono ─────────────────────────
val MonoDark = AuroraColors(
    background = Color(0xFF08090B), surface = Color(0xFF14161A), surfaceHigh = Color(0xFF1E2126),
    glassFill = Color(0x16FFFFFF), glassBorder = Color(0x33FFFFFF), scrim = Color(0xB3000000),
    textPrimary = Color(0xFFF5F6F8), textSecondary = Color(0xFFA9AFB8), textTertiary = Color(0xFF6E747D),
    brandBlue = Color(0xFFE5E7EB), brandPurple = Color(0xFF9CA3AF), brandPink = Color(0xFF6B7280),
    success = Color(0xFF9CA3AF), warning = Color(0xFFD1D5DB), error = Color(0xFFB0B5BD), info = Color(0xFFCBD0D6),
    typeVideo = Color(0xFFD1D5DB), typeAudio = Color(0xFFA9AFB8), typeImage = Color(0xFFE5E7EB), typeFile = Color(0xFF8B9199),
    glow = Color(0xFF9CA3AF), onAccent = Color(0xFF08090B),
)

// ───────────────────────── 6 · Neon ─────────────────────────
val NeonDark = AuroraColors(
    background = Color(0xFF05050C), surface = Color(0xFF0C0B18), surfaceHigh = Color(0xFF141226),
    glassFill = Color(0x1AB9F7FF), glassBorder = Color(0x44B9F7FF), scrim = Color(0xB3030210),
    textPrimary = Color(0xFFF4F0FF), textSecondary = Color(0xFFB3A8E0), textTertiary = Color(0xFF7266A8),
    brandBlue = Color(0xFF00E5FF), brandPurple = Color(0xFFB388FF), brandPink = Color(0xFFFF4ECD),
    success = Color(0xFF39FF88), warning = Color(0xFFFFE45E), error = Color(0xFFFF4D6D), info = Color(0xFF00E5FF),
    typeVideo = Color(0xFFB388FF), typeAudio = Color(0xFF00E5FF), typeImage = Color(0xFFFF4ECD), typeFile = Color(0xFFFFE45E),
    glow = Color(0xFF00E5FF), onAccent = Color(0xFF05050C),
)

// ───────────────────────── 7 · Light ─────────────────────────
val AuroraLight = AuroraColors(
    background = Color(0xFFF6F7FB), surface = Color(0xFFFFFFFF), surfaceHigh = Color(0xFFFFFFFF),
    glassFill = Color(0x99FFFFFF), glassBorder = Color(0x330B0D12), scrim = Color(0x990B0D12),
    textPrimary = Color(0xFF14171F), textSecondary = Color(0xFF4A5164), textTertiary = Color(0xFF8A92A6),
    brandBlue = Color(0xFF4285F4), brandPurple = Color(0xFF9B72CB), brandPink = Color(0xFFD96570),
    success = Color(0xFF16A34A), warning = Color(0xFFD97706), error = Color(0xFFDC2626), info = Color(0xFF2563EB),
    typeVideo = Color(0xFF6D5DF6), typeAudio = Color(0xFF0891B2), typeImage = Color(0xFFDB2777), typeFile = Color(0xFFEA580C),
    glow = Color(0xFF6D5DF6), onAccent = Color.White,
)

// ───────────────────────── Motion profiles ─────────────────────────
val DefaultMotion = AuroraMotion()
val OceanMotion = AuroraMotion(0.7f, 260f, 320, 1900, 4200, true)
val SunsetMotion = AuroraMotion(0.55f, 380f, 240, 1300, 2600, true)
val EmeraldMotion = AuroraMotion(0.75f, 240f, 340, 1700, 5000, false)
val MonoMotion = AuroraMotion(0.9f, 420f, 180, 2200, 0, false)
val NeonMotion = AuroraMotion(0.5f, 460f, 200, 1100, 2000, true)

// ───────────────────────── Registry ─────────────────────────
val AuroraThemes: List<AuroraThemeSpec> = listOf(
    AuroraThemeSpec(AuroraThemeId.AURORA, "أورورا", "Aurora", "أزرق → بنفسجي → وردي", AuroraDark, DefaultMotion),
    AuroraThemeSpec(AuroraThemeId.OCEAN, "المحيط", "Ocean", "سماوي → تركوازي", OceanDark, OceanMotion),
    AuroraThemeSpec(AuroraThemeId.SUNSET, "الغروب", "Sunset", "كهرماني → مرجاني", SunsetDark, SunsetMotion),
    AuroraThemeSpec(AuroraThemeId.EMERALD, "الزمرد", "Emerald", "أخضر → ليموني", EmeraldDark, EmeraldMotion),
    AuroraThemeSpec(AuroraThemeId.MONO, "أحادي", "Mono", "فضي → جرافيت", MonoDark, MonoMotion),
    AuroraThemeSpec(AuroraThemeId.NEON, "نيون", "Neon", "سماوي كهربي → بنفسجي", NeonDark, NeonMotion),
    AuroraThemeSpec(AuroraThemeId.LIGHT, "فاتح", "Light", "خفيف نهاري متكامل", AuroraLight, DefaultMotion),
)

fun specFor(id: AuroraThemeId): AuroraThemeSpec =
    AuroraThemes.firstOrNull { it.id == id } ?: AuroraThemes.first()

fun paletteFor(id: AuroraThemeId): AuroraColors = specFor(id).colors
fun motionFor(id: AuroraThemeId): AuroraMotion = specFor(id).motion

object AuroraTheme {
    val colors: AuroraColors
        @Composable get() = LocalAuroraColors.current
    val motion: AuroraMotion
        @Composable get() = LocalAuroraMotion.current
}


/** Single source of truth for the live theme (whole app re-themes instantly). */
object ThemeController {
    val id = androidx.compose.runtime.mutableStateOf(AuroraThemeId.AURORA)
    fun select(newId: AuroraThemeId) { id.value = newId }
}

/** Drawable preview per theme, bundled in the APK. */
@androidx.annotation.DrawableRes
fun previewFor(id: AuroraThemeId): Int = when (id) {
    AuroraThemeId.AURORA -> com.aurora.get.designsystem.R.drawable.theme_aurora
    AuroraThemeId.OCEAN -> com.aurora.get.designsystem.R.drawable.theme_ocean
    AuroraThemeId.SUNSET -> com.aurora.get.designsystem.R.drawable.theme_sunset
    AuroraThemeId.EMERALD -> com.aurora.get.designsystem.R.drawable.theme_emerald
    AuroraThemeId.MONO -> com.aurora.get.designsystem.R.drawable.theme_mono
    AuroraThemeId.NEON -> com.aurora.get.designsystem.R.drawable.theme_neon
    AuroraThemeId.LIGHT -> com.aurora.get.designsystem.R.drawable.theme_light
}
