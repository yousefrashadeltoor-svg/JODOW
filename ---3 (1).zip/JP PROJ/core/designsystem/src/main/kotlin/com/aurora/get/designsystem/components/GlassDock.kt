package com.aurora.get.designsystem.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.aurora.get.designsystem.glass.GlassPanel
import com.aurora.get.designsystem.theme.AuroraDimens
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import dev.chrisbanes.haze.HazeState

data class DockItem(
    val id: String,
    val icon: ImageVector,
    val label: String,
    val badge: Int = 0,
)

/**
 * Floating Glass Dock — pill-shaped, elevated above the screen edge, with a morphing
 * indicator that springs between items. Not a Material NavigationBar.
 */
@Composable
fun GlassDock(
    items: List<DockItem>,
    selectedId: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    hazeState: HazeState? = null,
) {
    val c = AuroraTheme.colors
    val selectedIndex = items.indexOfFirst { it.id == selectedId }.coerceAtLeast(0)
    val indicatorAnim by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "dockIndicator",
    )
    val density = LocalDensity.current

    GlassPanel(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 18.dp, vertical = 10.dp)
            .height(AuroraDimens.dockHeight),
        hazeState = hazeState,
        shape = LocalAuroraShapes.current.full,
        glowColor = c.glow,
    ) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
            // Morphing indicator pill (width springs wider on the active item)
            Box(
                Modifier
                    .layout { measurable, constraints ->
                        val placeable = measurable.measure(constraints)
                        val itemWidth = constraints.maxWidth.toFloat() / items.size
                        layout(constraints.maxWidth, constraints.maxHeight) {
                            val x = indicatorAnim * itemWidth + itemWidth * 0.08f
                            placeable.place(x.toInt(), ((constraints.maxHeight - placeable.height) / 2))
                        }
                    }
                    .size(width = 64.dp, height = 44.dp)
                    .drawWithContent {
                        drawRoundRect(
                            brush = c.brandGradient,
                            topLeft = Offset.Zero,
                            size = Size(size.width, size.height),
                            cornerRadius = CornerRadius(size.height / 2f),
                            alpha = 0.32f,
                        )
                        drawContent()
                    },
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                items.forEach { item ->
                    val active = item.id == selectedId
                    val iconScale by animateFloatAsState(
                        targetValue = if (active) 1.15f else 1f,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                        label = "dockIconScale",
                    )
                    Box(
                        Modifier
                            .size(48.dp)
                            .pressableScale({ onSelect(item.id) }),
                        contentAlignment = Alignment.Center,
                    ) {
                        AuroraIcon(
                            imageVector = item.icon,
                            contentDescription = item.label,
                            tint = if (active) c.textPrimary else c.textTertiary,
                            modifier = Modifier
                                .size(24.dp)
                                .graphicsLayer { scaleX = iconScale; scaleY = iconScale },
                        )
                        if (item.badge > 0) {
                            Box(
                                Modifier
                                    .align(Alignment.TopEnd)
                                    .size(16.dp)
                                    .background(c.brandPink, LocalAuroraShapes.current.full),
                                contentAlignment = Alignment.Center,
                            ) {
                                BasicLabel(text = if (item.badge > 9) "9+" else item.badge.toString())
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BasicLabel(text: String) {
    androidx.compose.foundation.text.BasicText(
        text = text,
        style = com.aurora.get.designsystem.theme.LocalAuroraTypography.current.labelMedium.copy(
            color = Color.White, fontSize = androidx.compose.ui.unit.sp(9f),
        ),
    )
}

@Composable
fun AuroraIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = AuroraTheme.colors.textPrimary,
) {
    androidx.compose.foundation.Canvas(modifier.size(24.dp)) {} // a11y placeholder under semantics
    IconPainter(imageVector, contentDescription, modifier, tint)
}

@Composable
private fun IconPainter(
    imageVector: ImageVector, contentDescription: String?, modifier: Modifier, tint: Color,
) {
    val painter = androidx.compose.ui.graphics.vector.rememberVectorPainter(imageVector)
    androidx.compose.foundation.Image(
        painter = painter,
        contentDescription = contentDescription,
        modifier = modifier.alpha(1f),
        colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(tint),
    )
}
