package com.aurora.get.designsystem.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.aurora.get.designsystem.glass.GlassPanel
import com.aurora.get.designsystem.theme.AuroraTheme
import com.aurora.get.designsystem.theme.LocalAuroraShapes
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Glass bottom sheet with physical drag (spring settle), progressive background dim,
 * and blur on both the sheet and the dimmed content behind it.
 */
@Composable
fun GlassBottomSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    hazeState: HazeState? = null,
    dragHint: Boolean = true,
    content: @Composable BoxScope.() -> Unit,
) {
    val scope = rememberCoroutineScope()
    var dragOffset by remember { mutableFloatStateOf(0f) }

    val dim by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "sheetDim",
    )

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(spring(stiffness = Spring.StiffnessMedium)),
        exit = fadeOut(spring(stiffness = Spring.StiffnessHigh)),
    ) {
        Box(Modifier.fillMaxSize()) {
            // Dim + blur layer (tap to dismiss)
            androidx.compose.foundation.layout.Box(
                Modifier
                    .fillMaxSize()
                    .alpha(dim)
                    .background(AuroraTheme.colors.scrim)
                    .pressableScalePlain(onDismiss)
            )
            androidx.compose.foundation.layout.Box(Modifier.fillMaxSize())
        }
    }

    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
            initialOffsetY = { it },
        ) + fadeIn(),
        exit = slideOutVertically(
            animationSpec = spring(stiffness = Spring.StiffnessHigh),
            targetOffsetY = { it },
        ) + fadeOut(),
        modifier = modifier,
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
            GlassPanel(
                hazeState = hazeState,
                shape = shape,
                modifier = Modifier
                    .fillMaxWidth()
                    .offset { IntOffset(0, dragOffset.roundToInt()) }
                    .draggable(
                        orientation = Orientation.Vertical,
                        state = rememberDraggableState { delta ->
                            dragOffset = (dragOffset + delta).coerceAtLeast(0f)
                        },
                        onDragStopped = {
                            scope.launch {
                                if (dragOffset > 260f) {
                                    onDismiss()
                                }
                                // Spring back to rest
                                androidx.compose.animation.core.animate(
                                    initialValue = dragOffset, targetValue = 0f,
                                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                                ) { value, _ -> dragOffset = value }
                            }
                        },
                    )
                    .navigationBarsPadding()
                    .padding(horizontal = 10.dp)
                    .padding(bottom = 10.dp),
            ) {
                Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
                    if (dragHint) {
                        Box(
                            Modifier
                                .align(Alignment.CenterHorizontally)
                                .size(width = 42.dp, height = 5.dp)
                                .background(
                                    AuroraTheme.colors.textTertiary.copy(alpha = 0.4f),
                                    LocalAuroraShapes.current.full,
                                )
                        )
                        Spacer(Modifier.height(14.dp))
                    }
                    Box(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 20.dp)) {
                        content()
                    }
                }
            }
        }
    }
}

private fun Modifier.pressableScalePlain(onClick: () -> Unit): Modifier =
    this.then(
        Modifier.pointerInputWrap(onClick)
    )

/** Local helper keeps the tap target without importing Material ripples. */
private fun Modifier.pointerInputWrap(onClick: () -> Unit): Modifier =
    this.pointerInput(onClick) {
        androidx.compose.foundation.gestures.detectTapGestures(onTap = { onClick() })
    }

@Composable
private fun rememberMutableInteraction() =
    remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
