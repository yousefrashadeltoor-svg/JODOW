package com.aurora.get.designsystem.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

/**
 * Squircle (superellipse, n = 4 — close to Apple's continuous corner).
 * No hard corners anywhere in Aurora Glass.
 */
class SquircleShape(private val smoothing: Float = 0.6f) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val path = Path().apply {
            val w = size.width
            val h = size.height
            val s = smoothing.coerceIn(0.4f, 1.0f)
            val rx = w / 2f
            val ry = h / 2f
            // Superellipse: |x/rx|^n + |y/ry|^n = 1 with n = 4
            val n = 2f / (1f - s * 0.5f) + 2f
            val steps = 96
            for (i in 0..steps) {
                val t = (Math.PI * 2 * i / steps)
                val cosT = kotlin.math.cos(t)
                val sinT = kotlin.math.sin(t)
                val px = rx + rx * signedPow(cosT, 2f / n)
                val py = ry + ry * signedPow(sinT, 2f / n)
                if (i == 0) moveTo(px.toFloat(), py.toFloat()) else lineTo(px.toFloat(), py.toFloat())
            }
            close()
        }
        return Outline.Generic(path)
    }

    private fun signedPow(v: Double, p: Float): Double =
        Math.signum(v) * Math.pow(kotlin.math.abs(v), p.toDouble())
}

@Immutable
data class AuroraShapes(
    /** 20dp — chips, small buttons */
    val small: Shape,
    /** 24dp — cards, fields */
    val medium: Shape,
    /** 28dp — bottom sheets */
    val large: Shape,
    /** 32dp — hero elements */
    val xLarge: Shape,
    /** true squircle — icon tiles, avatars */
    val squircle: Shape,
    /** pill */
    val full: Shape,
)

val DefaultAuroraShapes = AuroraShapes(
    small = RoundedCornerShape(20.dp),
    medium = RoundedCornerShape(24.dp),
    large = RoundedCornerShape(28.dp),
    xLarge = RoundedCornerShape(32.dp),
    squircle = SquircleShape(),
    full = RoundedCornerShape(percent = 50),
)

val LocalAuroraShapes = staticCompositionLocalOf { DefaultAuroraShapes }

object AuroraDimens {
    val dockHeight: Dp = 68.dp
    val sheetPeekFraction: Float = 0.55f
    val glassBlurRadius: Dp = 28.dp
}
