package com.aurora.get.designsystem.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.aurora.get.designsystem.R
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont

/**
 * Fonts (open licenses only):
 *  - English: Outfit (OFL)
 *  - Arabic: IBM Plex Sans Arabic (OFL)
 * Downloadable fonts keep the APK small; bundling TTFs into res/font is the offline fallback.
 */
private val fontProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = R.array.com_google_android_gms_fonts_certs,
)

private val outfit = GoogleFont("Outfit")
private val plexArabic = GoogleFont("IBM Plex Sans Arabic")
private val readexPro = GoogleFont("Readex Pro")

val AuroraFontFamily = FontFamily(
    Font(googleFont = outfit, fontProvider = fontProvider, weight = FontWeight.Light),
    Font(googleFont = outfit, fontProvider = fontProvider, weight = FontWeight.Normal),
    Font(googleFont = outfit, fontProvider = fontProvider, weight = FontWeight.Medium),
    Font(googleFont = outfit, fontProvider = fontProvider, weight = FontWeight.SemiBold),
    Font(googleFont = outfit, fontProvider = fontProvider, weight = FontWeight.Bold),
)

val AuroraArabicFontFamily = FontFamily(
    Font(googleFont = plexArabic, fontProvider = fontProvider, weight = FontWeight.Light),
    Font(googleFont = plexArabic, fontProvider = fontProvider, weight = FontWeight.Normal),
    Font(googleFont = plexArabic, fontProvider = fontProvider, weight = FontWeight.Medium),
    Font(googleFont = plexArabic, fontProvider = fontProvider, weight = FontWeight.SemiBold),
    Font(googleFont = plexArabic, fontProvider = fontProvider, weight = FontWeight.Bold),
)

val AuroraDisplayFontFamily = FontFamily(
    Font(googleFont = readexPro, fontProvider = fontProvider, weight = FontWeight.Medium),
    Font(googleFont = readexPro, fontProvider = fontProvider, weight = FontWeight.SemiBold),
    Font(googleFont = readexPro, fontProvider = fontProvider, weight = FontWeight.Bold),
)

@Immutable
data class AuroraTypography(
    val displayLarge: TextStyle,
    val displayMedium: TextStyle,
    val headlineLarge: TextStyle,
    val headlineMedium: TextStyle,
    val titleLarge: TextStyle,
    val titleMedium: TextStyle,
    val bodyLarge: TextStyle,
    val bodyMedium: TextStyle,
    val bodySmall: TextStyle,
    val labelLarge: TextStyle,
    val labelMedium: TextStyle,
    val mono: TextStyle, // for byte-exact sizes and stats
)

private fun style(size: TextUnit, weight: FontWeight, lineHeight: TextUnit, family: FontFamily) =
    TextStyle(fontFamily = family, fontWeight = weight, fontSize = size, lineHeight = lineHeight)

val DefaultAuroraTypography = AuroraTypography(
    displayLarge = style(38.sp, FontWeight.Bold, 44.sp, AuroraDisplayFontFamily),
    displayMedium = style(30.sp, FontWeight.Bold, 36.sp, AuroraDisplayFontFamily),
    headlineLarge = style(26.sp, FontWeight.Bold, 32.sp, AuroraArabicFontFamily),
    headlineMedium = style(21.sp, FontWeight.SemiBold, 28.sp, AuroraArabicFontFamily),
    titleLarge = style(18.sp, FontWeight.SemiBold, 25.sp, AuroraArabicFontFamily),
    titleMedium = style(16.sp, FontWeight.Medium, 22.sp, AuroraArabicFontFamily),
    bodyLarge = style(16.sp, FontWeight.Normal, 24.sp, AuroraArabicFontFamily),
    bodyMedium = style(14.sp, FontWeight.Normal, 20.sp, AuroraArabicFontFamily),
    bodySmall = style(12.sp, FontWeight.Normal, 17.sp, AuroraArabicFontFamily),
    labelLarge = style(14.sp, FontWeight.SemiBold, 18.sp, AuroraArabicFontFamily),
    labelMedium = style(12.sp, FontWeight.Medium, 15.sp, AuroraArabicFontFamily),
    mono = style(13.sp, FontWeight.Medium, 18.sp, AuroraFontFamily),
)

val LocalAuroraTypography = staticCompositionLocalOf { DefaultAuroraTypography }

/** Convenience provider for CompositionLocalProvider at the app root. */
fun localAuroraTypographyProvider() = LocalAuroraTypography provides DefaultAuroraTypography

fun localAuroraMotionProvider(id: AuroraThemeId) = LocalAuroraMotion provides motionFor(id)

/** Shapes provider (kept next to typography for a single import site). */
fun localAuroraShapesProvider() = LocalAuroraShapes provides DefaultAuroraShapes
