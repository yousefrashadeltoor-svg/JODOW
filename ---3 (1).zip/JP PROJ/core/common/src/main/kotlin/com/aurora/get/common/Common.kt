package com.aurora.get.common

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import java.text.DecimalFormat
import java.util.Locale
import javax.inject.Inject

/** App-wide dispatchers (injectable for tests). */
class AuroraDispatchers @Inject constructor() {
    val io: CoroutineDispatcher = Dispatchers.IO
    val default: CoroutineDispatcher = Dispatchers.Default
    val main: CoroutineDispatcher = Dispatchers.Main
}

/** Result type used across the app. */
sealed interface AuroraResult<out T> {
    data class Success<T>(val value: T) : AuroraResult<T>
    data class Failure(val cause: Throwable, val message: String? = cause.message) : AuroraResult<Nothing>

    val isSuccess get() = this is Success
    fun getOrNull(): T? = (this as? Success)?.value
}

/**
 * Byte-exact size formatting. Rules:
 *  - exact sizes are rendered as e.g. "141.5 MB" (short) or "148,372,910 B (141.5 MiB)" (long)
 *  - approximate sizes ALWAYS carry the "≈" prefix — never mix the two.
 */
object Bytes {

    /** Exact size known for certain. */
    fun exact(bytes: Long): String = format(bytes)

    /** Approximate size — always shows "≈". */
    fun approx(bytes: Long): String = "≈ " + format(bytes)

    /** Long-press detail: "148,372,910 bytes (141.5 MiB)". */
    fun exactLong(bytes: Long): String =
        "%,d bytes (%s)".format(Locale.US, bytes, formatBinary(bytes))

    fun approxLong(bytes: Long): String = "≈ " + exactLong(bytes)

    /** Human readable in decimal SI (MB) */
    fun format(bytes: Long): String = when {
        bytes < 0 -> "—"
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> df.format(bytes / 1024.0) + " KB"
        bytes < 1024L * 1024 * 1024 -> df.format(bytes / (1024.0 * 1024.0)) + " MB"
        else -> df.format(bytes / (1024.0 * 1024.0 * 1024.0)) + " GB"
    }

    /** Binary (MiB) for the technical long form. */
    fun formatBinary(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> df.format(bytes / 1024.0) + " KiB"
        bytes < 1024L * 1024 * 1024 -> df.format(bytes / (1024.0 * 1024.0)) + " MiB"
        else -> df.format(bytes / (1024.0 * 1024.0 * 1024.0)) + " GiB"
    }

    /** Speed like "24.6 MB/s" */
    fun speed(bytesPerSec: Double): String = format(bytesPerSec.toLong()) + "/s"

    /** Remaining time like "03:12" */
    fun eta(remainingBytes: Long, bytesPerSec: Double): String {
        if (bytesPerSec <= 0) return "—"
        val secs = (remainingBytes / bytesPerSec).toLong()
        val m = secs / 60; val s = secs % 60
        val h = m / 60
        return if (h > 0) "%d:%02d:%02d".format(h, m % 60, s) else "%02d:%02d".format(m, s)
    }

    private val df = DecimalFormat("#.#")
}

/** Smart kind of media used by the four smart buttons. */
enum class MediaKind { VIDEO, AUDIO, IMAGE, FILE }

/** Wrapper carrying size confidence. */
@kotlinx.serialization.Serializable
data class SizeInfo(val bytes: Long, val isApproximate: Boolean) {
    val short: String get() = if (isApproximate) Bytes.approx(bytes) else Bytes.exact(bytes)
    val long: String get() = if (isApproximate) Bytes.approxLong(bytes) else Bytes.exactLong(bytes)

    companion object {
        fun exact(bytes: Long) = SizeInfo(bytes, isApproximate = false)
        fun approx(bytes: Long) = SizeInfo(bytes, isApproximate = true)
    }
}
