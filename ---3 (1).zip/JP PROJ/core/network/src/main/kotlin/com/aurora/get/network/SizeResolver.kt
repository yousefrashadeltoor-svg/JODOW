package com.aurora.get.network

import com.aurora.get.common.SizeInfo
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Exact size ladder (spec §4.5):
 *  1. HEAD → Content-Length
 *  2. GET Range: bytes=0-0 → Content-Range: bytes 0-0/TOTAL
 *  3. Chunked/unknown → multi-range probes to discover range support
 *  4. HLS/DASH sources → parallel HEAD over all segments (large pool) + init segment
 *  5. yt-dlp `filesize` preferred; `filesize_approx` only as last resort (≈ in UI)
 *
 * Exact sizes never carry "≈", approximate ones always do — they are never mixed.
 */
@Singleton
class SizeResolver @Inject constructor(
    private val client: OkHttpClient,
) {
    /** Full probe headers needed to identify one resource. */
    data class ProbeResult(
        val size: SizeInfo?,          // null if truly unknowable
        val mimeType: String?,
        val supportsRanges: Boolean,
        val etag: String?,
        val lastModified: String?,
        val fileName: String?,
        val finalUrl: String,
    )

    /**
     * Resolves the size/type of [url]. [headers] carries cookies/UA/Referer so protected
     * resources (sniffed from the internal browser) can be probed with the same identity.
     */
    suspend fun resolve(url: String, headers: Map<String, String> = emptyMap()): ProbeResult {
        // Stage 1: HEAD
        head(url, headers)?.let { return it }
        // Stage 2: Range 0-0
        rangeProbe(url, headers)?.let { return it }
        // Stage 3: give up gracefully — size unknown (UI will show "—" or ≈ from extractor)
        return ProbeResult(null, null, supportsRanges = false, null, null, null, url)
    }

    private fun head(url: String, headers: Map<String, String>): ProbeResult? = runCatching {
        val req = Request.Builder().url(url).head().apply { headers.forEach { (k, v) -> header(k, v) } }.build()
        client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) return null
            val len = res.header("Content-Length")?.toLongOrNull()
            ProbeResult(
                size = len?.let { SizeInfo.exact(it) },
                mimeType = res.header("Content-Type")?.substringBefore(";"),
                supportsRanges = res.header("Accept-Ranges")?.equals("bytes", true) == true,
                etag = res.header("ETag"),
                lastModified = res.header("Last-Modified"),
                fileName = contentDispositionName(res.header("Content-Disposition")),
                finalUrl = res.request.url.toString(),
            )
        }.takeIf { it.size != null }
    }.getOrNull()

    private fun rangeProbe(url: String, headers: Map<String, String>): ProbeResult? = runCatching {
        val req = Request.Builder().url(url).get()
            .header("Range", "bytes=0-0")
            .apply { headers.forEach { (k, v) -> header(k, v) } }
            .build()
        client.newCall(req).execute().use { res ->
            val contentRange = res.header("Content-Range") ?: return null
            // "bytes 0-0/148372910"
            val total = contentRange.substringAfter("/", "").toLongOrNull() ?: return null
            res.body.close()
            ProbeResult(
                size = SizeInfo.exact(total),
                mimeType = res.header("Content-Type")?.substringBefore(";"),
                supportsRanges = res.code == 206,
                etag = res.header("ETag"),
                lastModified = res.header("Last-Modified"),
                fileName = contentDispositionName(res.header("Content-Disposition")),
                finalUrl = res.request.url.toString(),
            )
        }
    }.getOrNull()

    fun contentDispositionName(disposition: String?): String? {
        if (disposition == null) return null
        // filename*=UTF-8''name.mp4 takes precedence per RFC 5987
        val star = Regex("filename\\*=UTF-8''([^;]+)", RegexOption.IGNORE_CASE).find(disposition)
        if (star != null) return java.net.URLDecoder.decode(star.groupValues[1], Charsets.UTF_8.name())
        return Regex("filename=\"?([^\";]+)\"?", RegexOption.IGNORE_CASE)
            .find(disposition)?.groupValues?.get(1)
    }

    /**
     * Sums the sizes of HLS/DASH segments via a parallel HEAD pool (up to 32 in flight),
     * including the init segment. Returns approximate=true if any segment hides its length.
     */
    suspend fun resolveSegmentedManifest(
        segmentUrls: List<String>,
        headers: Map<String, String> = emptyMap(),
        maxParallel: Int = 32,
    ): SizeInfo = coroutineScope {
        var anyUnknown = false
        val semaphore = kotlinx.coroutines.sync.Semaphore(maxParallel)
        val total = segmentUrls.map { seg ->
            async {
                semaphore.acquire()
                try {
                    val req = Request.Builder().url(seg).head()
                        .apply { headers.forEach { (k, v) -> header(k, v) } }.build()
                    client.newCall(req).execute().use { res ->
                        val len = res.header("Content-Length")?.toLongOrNull()
                        if (len == null) anyUnknown = true
                        len ?: 0L
                    }
                } catch (t: Throwable) {
                    Timber.v("Segment HEAD failed: $seg")
                    anyUnknown = true
                    0L
                } finally {
                    semaphore.release()
                }
            }
        }.awaitAll().sum()
        if (anyUnknown) SizeInfo.approx(total) else SizeInfo.exact(total)
    }
}
