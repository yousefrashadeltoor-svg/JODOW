package com.aurora.get.network

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Cache
import okhttp3.ConnectionSpec
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.Dns
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import timber.log.Timber
import java.io.File
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * DNS with in-memory TTL cache. Optional DNS-over-HTTPS can be toggled in Settings;
 * VERIFY: okhttp-dnsoverhttps artifact ("com.squareup.okhttp3:okhttp-dnsoverhttps").
 */
class CachingDns @Inject constructor() : Dns {
    private data class Entry(val addresses: List<InetAddress>, val expiresAt: Long)
    private val cache = ConcurrentHashMap<String, Entry>()
    private val ttlMs = 5 * 60 * 1000L

    override fun lookup(hostname: String): List<InetAddress> {
        val now = System.currentTimeMillis()
        cache[hostname]?.let { if (it.expiresAt > now) return it.addresses else cache.remove(hostname) }
        val addresses = Dns.SYSTEM.lookup(hostname)
        cache[hostname] = Entry(addresses, now + ttlMs)
        return addresses
    }

    fun preconnectWarming(hostname: String) {
        // Proactively resolves DNS so the first real request skips the lookup.
        try { lookup(hostname) } catch (t: Throwable) { Timber.v("DNS warm failed for $hostname") }
    }
}

/**
 * CookieJar with encrypted persistence (EncryptedSharedPreferences).
 * Sessions exported from the internal browser (including cf_clearance) are stored here,
 * so OkHttp requests carry the exact same identity the WebView negotiated.
 */
@Singleton
class PersistentCookieJar @Inject constructor(
    @ApplicationContext context: Context,
) : CookieJar {

    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        EncryptedSharedPreferences.create(
            "aurora_cookies", masterKey, context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    private val store = ConcurrentHashMap<String, MutableList<Cookie>>()

    init { restore() }

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        val list = store.getOrPut(url.host) { mutableListOf() }
        synchronized(list) {
            cookies.forEach { new ->
                list.removeAll { it.name == new.name && it.domain == new.domain }
                if (new.expiresAt > System.currentTimeMillis()) list.add(new)
            }
        }
        persist(url.host)
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        val now = System.currentTimeMillis()
        return (store[url.host] ?: emptyList())
            .filter { it.expiresAt > now && it.matches(url) }
    }

    /** Import raw "a=b; c=d" cookie header (e.g. exported from WebView after Cloudflare). */
    fun importHeader(host: String, header: String) {
        val base = HttpUrl.Builder().scheme("https").host(host).build()
        val cookies = header.split(";").mapNotNull { Cookie.parse(base, it.trim()) }
        if (cookies.isNotEmpty()) saveFromResponse(base, cookies)
    }

    private fun persist(host: String) {
        val header = store[host]?.joinToString("; ") { "${it.name}=${it.value}" } ?: return
        prefs.edit().putString(host, header).apply()
    }

    private fun restore() {
        prefs.all.forEach { (host, v) -> if (v is String) importHeader(host, v) }
    }
}

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun dns(): CachingDns = CachingDns()

    @Provides
    @Singleton
    fun okHttpClient(
        @ApplicationContext context: Context,
        dns: CachingDns,
        cookieJar: PersistentCookieJar,
    ): OkHttpClient {
        val cacheDir = File(context.cacheDir, "http").apply { mkdirs() }
        val builder = OkHttpClient.Builder()
            .dns(dns)
            .cookieJar(cookieJar)
            .cache(Cache(cacheDir, 32L * 1024 * 1024))
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .connectionSpecs(listOf(ConnectionSpec.MODERN_TLS, ConnectionSpec.CLEARTEXT))
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            // HTTP/2 multiplexing is on by default for TLS connections.
        if (BuildConfig.DEBUG) {
            builder.addInterceptor(
                okhttp3.logging.HttpLoggingInterceptor { msg -> Timber.tag("HTTP").v(msg) }
                    .apply { level = okhttp3.logging.HttpLoggingInterceptor.Level.BASIC }
            )
        }
        return builder.build()
    }
}

/**
 * Optional Cronet engine (HTTP/3 + QUIC).
 * If the provider is unavailable on the device the app keeps using OkHttp — no behavior change.
 */
@Singleton
class CronetEngine @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    val isAvailable: Boolean by lazy {
        // VERIFY: prefer play-services-cronet dynamic provider; embedded build also possible.
        runCatching {
            org.chromium.net.CronetEngine.Builder(context)
                .enableHttp2(true)
                .enableQuic(true)
                .build()
        }.onFailure { Timber.i("Cronet unavailable, using OkHttp fallback: ${it.message}") }
            .isSuccess
    }
}

/** TCP/TLS preconnect on domain discovery (Stage 0 of the link analyzer). */
class Preconnect @Inject constructor(private val client: OkHttpClient, private val dns: CachingDns) {
    suspend fun warm(host: String) = withContext(Dispatchers.IO) {
        runCatching {
            dns.preconnectWarming(host)
            // A 1-byte request forces full handshake & keeps the connection in the pool.
            val req = okhttp3.Request.Builder()
                .url("https://$host/")
                .head()
                .header("Cache-Control", "no-cache")
                .build()
            client.newBuilder().connectTimeout(4, TimeUnit.SECONDS).build()
                .newCall(req).execute().close()
        }
    }
}
