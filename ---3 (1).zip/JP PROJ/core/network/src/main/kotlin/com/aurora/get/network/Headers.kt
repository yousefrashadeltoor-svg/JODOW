package com.aurora.get.network

import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.net.URI
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Follows redirects of short links (t.co, bit.ly, vt.tiktok.com, instagram share URLs...)
 * before analysis. HEAD-first, GET fallback for servers that hate HEAD.
 */
@Singleton
class RedirectResolver @Inject constructor(
    private val client: OkHttpClient,
) {
    suspend fun resolve(url: String, maxHops: Int = 8): String {
        var current = url
        repeat(maxHops) {
            val next = runCatching { followOnce(current) }.getOrNull() ?: return current
            if (next == current) return current
            current = next
        }
        return current
    }

    private fun followOnce(url: String): String {
        val req = Request.Builder().url(url).head().build()
        client.newBuilder().followRedirects(false).followSslRedirects(false).build()
            .newCall(req).execute().use { res ->
                val loc = res.header("Location")
                return if (res.code in 300..399 && loc != null) {
                    absolutize(url, loc)
                } else res.request.url.toString()
            }
    }

    private fun absolutize(base: String, location: String): String = runCatching {
        URI(base).resolve(location).toString()
    }.getOrDefault(location).also { Timber.v("Redirect → $it") }
}
