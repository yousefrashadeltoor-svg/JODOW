package com.aurora.get.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import android.content.Context
import com.aurora.get.common.MediaKind
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.Flow
import javax.inject.Singleton

// ───────────────────────── Entities ─────────────────────────

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String,
    val url: String,
    val finalUrl: String? = null,
    val directUrl: String? = null,
    val fileName: String,
    val destDir: String,
    val mimeType: String? = null,
    val kind: MediaKind = MediaKind.FILE,
    val totalBytes: Long = -1,           // -1 = unknown
    val sizeApprox: Boolean = false,     // true ⇒ UI shows ≈
    val downloadedBytes: Long = 0,
    val status: String = "QUEUED",       // QUEUED|RUNNING|PAUSED|COMPLETED|FAILED|MERGING
    val error: String? = null,
    val segments: Int = 0,
    val supportsRanges: Boolean = true,
    val etag: String? = null,
    val lastModified: String? = null,
    val priority: Int = 0,
    val sortOrder: Int = 0,
    val headersJson: String? = null,     // cookies/UA/referer transferred to engine
    val needsMerge: Boolean = false,
    val audioUrl: String? = null,        // companion audio for DASH merge
    val speedLimitBps: Long = 0,         // 0 = unlimited
    val scheduledAt: Long = 0,           // 0 = now
    val wifiOnly: Boolean = false,
    val chargingOnly: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long = 0,
    val siteDomain: String? = null,
    val sha256: String? = null,
)

/** Per-segment resume state — survives process death / reboot. */
@Entity(tableName = "segments", primaryKeys = ["downloadId", "index"])
data class SegmentEntity(
    val downloadId: String,
    val index: Int,
    val start: Long,
    val end: Long,               // inclusive
    val written: Long = 0,       // bytes written within this segment
    val done: Boolean = false,
)

/** Analysis cache with TTL (Stage results). */
@Entity(tableName = "analysis_cache")
data class AnalysisCacheEntity(
    @PrimaryKey val url: String,
    val resultJson: String,
    val createdAt: Long = System.currentTimeMillis(),
    val ttlMs: Long = 6 * 60 * 60 * 1000,
)

/** Per-site browser data (cookies exported from internal browser). */
@Entity(tableName = "site_sessions")
data class SiteSessionEntity(
    @PrimaryKey val domain: String,
    val cookies: String,          // encrypted at rest by DataStore layer; here plain header form
    val userAgent: String,
    val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey val id: String,
    val url: String,
    val title: String,
    val domain: String,
    val kind: MediaKind,
    val bytes: Long,
    val timestamp: Long = System.currentTimeMillis(),
)

// ───────────────────────── DAOs ─────────────────────────

@Dao
interface DownloadDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(d: DownloadEntity)
    @Update suspend fun update(d: DownloadEntity)
    @Delete suspend fun delete(d: DownloadEntity)
    @Query("SELECT * FROM downloads ORDER BY sortOrder ASC, createdAt DESC") fun observeAll(): Flow<List<DownloadEntity>>
    @Query("SELECT * FROM downloads WHERE id = :id") suspend fun byId(id: String): DownloadEntity?
    @Query("SELECT * FROM downloads WHERE status = :status") suspend fun byStatus(status: String): List<DownloadEntity>
    @Query("UPDATE downloads SET status = :status WHERE id = :id") suspend fun setStatus(id: String, status: String)
    @Query("UPDATE downloads SET downloadedBytes = :bytes, status = :status WHERE id = :id")
    suspend fun progress(id: String, bytes: Long, status: String)
    @Query("UPDATE downloads SET sortOrder = :ord WHERE id = :id") suspend fun reorder(id: String, ord: Int)
    @Query("DELETE FROM downloads") suspend fun clear()
}

@Dao
interface SegmentDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(list: List<SegmentEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(s: SegmentEntity)
    @Query("SELECT * FROM segments WHERE downloadId = :id ORDER BY `index`") suspend fun forDownload(id: String): List<SegmentEntity>
    @Query("DELETE FROM segments WHERE downloadId = :id") suspend fun clearFor(id: String)
    @Query("SELECT SUM(written) FROM segments WHERE downloadId = :id") suspend fun writtenBytes(id: String): Long?
}

@Dao
interface AnalysisCacheDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(e: AnalysisCacheEntity)
    @Query("SELECT * FROM analysis_cache WHERE url = :url") suspend fun get(url: String): AnalysisCacheEntity?
    @Query("DELETE FROM analysis_cache WHERE createdAt + ttlMs < :now") suspend fun evict(now: Long)
}

@Dao
interface SiteSessionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(e: SiteSessionEntity)
    @Query("SELECT * FROM site_sessions WHERE domain = :domain") suspend fun get(domain: String): SiteSessionEntity?
}

@Dao
interface HistoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(e: HistoryEntity)
    @Query("SELECT * FROM history ORDER BY timestamp DESC LIMIT :limit") fun observe(limit: Int = 200): Flow<List<HistoryEntity>>
    @Query("SELECT SUM(bytes) FROM history") fun totalBytes(): Flow<Long?>
}

// ───────────────────────── Converters / DB ─────────────────────────

class MediaKindConverter {
    @TypeConverter fun toKind(v: String): MediaKind = MediaKind.valueOf(v)
    @TypeConverter fun fromKind(k: MediaKind): String = k.name
}

@Database(
    entities = [
        DownloadEntity::class,
        SegmentEntity::class,
        AnalysisCacheEntity::class,
        SiteSessionEntity::class,
        HistoryEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
@TypeConverters(MediaKindConverter::class)
abstract class AuroraDatabase : RoomDatabase() {
    abstract fun downloads(): DownloadDao
    abstract fun segments(): SegmentDao
    abstract fun analysisCache(): AnalysisCacheDao
    abstract fun siteSessions(): SiteSessionDao
    abstract fun history(): HistoryDao
}

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides
    @Singleton
    fun provideDb(@ApplicationContext context: Context): AuroraDatabase =
        Room.databaseBuilder(context, AuroraDatabase::class.java, "aurora.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun downloadsDao(db: AuroraDatabase) = db.downloads()
    @Provides fun segmentsDao(db: AuroraDatabase) = db.segments()
    @Provides fun analysisCacheDao(db: AuroraDatabase) = db.analysisCache()
    @Provides fun siteSessionDao(db: AuroraDatabase) = db.siteSessions()
    @Provides fun historyDao(db: AuroraDatabase) = db.history()
}
