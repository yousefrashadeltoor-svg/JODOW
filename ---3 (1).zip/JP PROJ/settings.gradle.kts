// Aurora Get — settings
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        maven("https://jitpack.io") // youtubedl-android + community libs
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
        maven("https://jitpack.io")
    }
}

rootProject.name = "AuroraGet"

include(":app")

include(":core:common")
include(":core:designsystem")
include(":core:database")
include(":core:network")

include(":engine:downloader")
include(":engine:extractors")
include(":engine:media")

include(":feature:home")
include(":feature:youtube")
include(":feature:analyzer")
include(":feature:downloads")
include(":feature:browser")
include(":feature:converter")
include(":feature:compressor")
include(":feature:player")
include(":feature:files")
include(":feature:settings")
