# Aurora Get — مدير التحميلات فائق السرعة

> **تنبيه قانوني:** التطبيق أداة تقنية محايدة. المسؤولية على المستخدم في احترام حقوق النشر
> وشروط استخدام كل موقع. التطبيق لا يتجاوز DRM (Widevine / FairPlay / PlayReady) ولا أي Paywall.

---

## 1) المعمارية (Modules + تدفق البيانات)

```
                    ┌────────────────────────── :app ──────────────────────────┐
                    │  Navigation · Onboarding · Widget · Tile · Shortcuts     │
                    └───────────────┬──────────────────────────────────────────┘
          ┌───────────────┬─────────┴───────┬───────────────┬────────────────┐
   :feature:home   :feature:downloads  :feature:browser  :feature:player  :feature:settings
   (لصق + تحليل)    (الطابور والمدير)   (Sniffer+AdBlock)  (Media3)         (DataStore)
          │                 │                 │                 │
   :feature:analyzer  :feature:converter  :feature:compressor  :feature:files
          │                 │                 │
          ▼                 ▼                 ▼
   :engine:extractors  :engine:media    :engine:downloader
   (yt-dlp + Native)   (FFmpeg+Images)  (Segmented + Resume + Service)
          │                 │                 │
          └────────┬────────┴────────┬────────┘
                   ▼                 ▼
            :core:network      :core:database
            (OkHttp+Cronet,    (Room: downloads,
             DNS cache,        segments, cache,
             CookieJar,        queue state)
             SizeResolver)
                   │
                   ▼
            :core:designsystem   ← Aurora Glass (بدون أي Material)
            :core:common         ← Result / Dispatchers / Bytes
```

**تدفق البيانات (MVI):** كل شاشة لها `ViewModel` يستقبل `Intent` ويُصدر `State` (StateFlow)
و`Effect` (Channel لمرة واحدة). التحليل يتدفق عبر Flow تدريجي المراحل
(Stage 0 → 4) فتظهر المعلومات فور وصول كل جزء دون حجب الواجهة.

## 2) البناء والتشغيل

```bash
# المتطلبات: JDK 17+، Android SDK 35، NDK (لأدوات الضغط الأصلية اختياريًا)
git clone <repo> aurora-get && cd aurora-get
./gradlew assembleDebug          # بناء نسخة التصحيح
./gradlew installDebug           # تثبيت على جهاز/محاكي
./gradlew test                   # اختبارات الوحدة (التحميل/التجزئة/الحجم)
./gradlew connectedDebugAndroidTest  # اختبارات الأجهزة (اختياري)
./gradlew dependencies --configuration releaseRuntimeClasspath | grep -i material
```

آخر أمر يجب أن يُرجع **صفر نتائج** — المشروع خالٍ من Material بالكامل (فحص إلزامي).

## 3) قائمة VERIFY (بنود تحتاج تأكيدًا قبل الإنتاج)

| البند | السبب |
|---|---|
| `youtubedl-android` version 0.16.1 + package `aria2c` | تحقق من آخر إصدار على JitPack |
| Cronet OkHttp interceptor artifact | البديل المؤكد: OkHttp وحده (الكود يعمل بدون Cronet) |
| adblock-rust JNI bindings | لا توجد حزمة Android رسمية؛ يوجد Fallback كامل (HostFilterEngine) يعمل فورًا |
| oxipng/zopfli/mozjpeg كمكتبات Android جاهزة | البديل المؤكد موجود: WebP/PNG عبر Bitmap + Zstd عبر zstd-jni |
| `libtorrent4j` | اختياري ومعزول خلف واجهة `TorrentEngine` |
| حزم الخطوط القابلة للتنزيل (Outfit / IBM Plex Sans Arabic) | عبر `ui-text-google-fonts`، بديل مؤكد: وضع ملفات TTF في res/font |
| Haze 1.x API (`hazeSource`/`hazeEffect`) | تحقق من README المكتبة عند الترقية |

## 4) الخصوصية

Offline-first بالكامل: لا Firebase، لا Analytics، لا Tracking. الكوكيز مشفرة عبر
EncryptedSharedPreferences، والقبو الخاص محمي بالبصمة (AES-GCM عبر Android Keystore).
