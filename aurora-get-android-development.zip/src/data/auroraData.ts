export type ThemePresetId = "aurora" | "ocean" | "sunset" | "emerald" | "mono" | "neon";

export interface AuroraThemeConfig {
  id: ThemePresetId;
  nameAr: string;
  nameEn: string;
  c1: string;
  c2: string;
  c3: string;
}

export const AURORA_THEMES: Record<ThemePresetId, AuroraThemeConfig> = {
  aurora: { id: "aurora", nameAr: "أورورا (Gemini)", nameEn: "Aurora", c1: "#4285F4", c2: "#9B72CB", c3: "#D96570" },
  ocean: { id: "ocean", nameAr: "المحيط", nameEn: "Ocean", c1: "#0EA5E9", c2: "#2DD4BF", c3: "#6366F1" },
  sunset: { id: "sunset", nameAr: "الغروب", nameEn: "Sunset", c1: "#FB7185", c2: "#F97316", c3: "#A855F7" },
  emerald: { id: "emerald", nameAr: "الزمرد", nameEn: "Emerald", c1: "#10B981", c2: "#06B6D4", c3: "#34D399" },
  mono: { id: "mono", nameAr: "أحادي", nameEn: "Mono", c1: "#E2E8F0", c2: "#94A3B8", c3: "#64748B" },
  neon: { id: "neon", nameAr: "نيون", nameEn: "Neon", c1: "#00F5D4", c2: "#9B5DE5", c3: "#F15BB5" },
};

export type BucketKey = "audio" | "images" | "video" | "files";

export interface FormatOption {
  id: string;
  bucket: BucketKey;
  quality: string;
  ext: string;
  codec: string;
  extraMeta: string;
  bytes: number;
  isExact: boolean;
  sizeSource: string;
  autoMergeDash?: boolean;
  watermarkFree?: boolean;
}

export interface AnalyzedSample {
  id: string;
  url: string;
  domain: string;
  siteName: string;
  siteBadgeColor: string;
  siteInitials: string;
  titleAr: string;
  titleEn: string;
  fileName: string;
  author: string;
  duration?: string;
  publishDate: string;
  primaryTypeAr: string;
  primaryTypeEn: string;
  artworkGradient: string;
  artworkTint: string;
  requiresBrowserSniffer?: boolean;
  buckets: Record<BucketKey, FormatOption[]>;
}

export const ANALYZER_SAMPLES: AnalyzedSample[] = [
  {
    id: "youtube",
    url: "https://youtube.com/watch?v=aurora8kHDR",
    domain: "youtube.com",
    siteName: "YouTube",
    siteBadgeColor: "#EF4444",
    siteInitials: "YT",
    titleAr: "أضواء الشفق القطبي في آيسلندا 8K HDR — 60 إطارًا بالثانية",
    titleEn: "Aurora Borealis Iceland 8K HDR 60fps — Spatial Mastering",
    fileName: "Aurora_Borealis_Iceland_8K_HDR",
    author: "Nordic Cinema 8K",
    duration: "08:42",
    publishDate: "2026-02-14",
    primaryTypeAr: "فيديو 8K HDR",
    primaryTypeEn: "8K HDR Video",
    artworkGradient: "linear-gradient(135deg, #0F2027 0%, #203A43 45%, #4285F4 75%, #9B72CB 100%)",
    artworkTint: "#4285F4",
    buckets: {
      video: [
        { id: "yt-8k", bucket: "video", quality: "4320p 8K HDR", ext: "WEBM", codec: "AV1", extraMeta: "60fps • 54 Mbps", bytes: 1_842_910_208, isExact: true, sizeSource: "HEAD+DASH Audio Sum", autoMergeDash: true },
        { id: "yt-4k", bucket: "video", quality: "2160p 4K HDR", ext: "MP4", codec: "AV1", extraMeta: "60fps • 24 Mbps", bytes: 694_218_752, isExact: true, sizeSource: "HEAD+DASH Audio Sum", autoMergeDash: true },
        { id: "yt-2k", bucket: "video", quality: "1440p QHD", ext: "WEBM", codec: "VP9", extraMeta: "60fps • 12 Mbps", bytes: 312_480_120, isExact: true, sizeSource: "Range: bytes=0-0", autoMergeDash: true },
        { id: "yt-1080", bucket: "video", quality: "1080p Full HD", ext: "MP4", codec: "AVC1", extraMeta: "60fps • 6.5 Mbps", bytes: 148_372_910, isExact: true, sizeSource: "HEAD:Content-Length", autoMergeDash: true },
        { id: "yt-720", bucket: "video", quality: "720p HD", ext: "MP4", codec: "AVC1", extraMeta: "30fps • Progressive", bytes: 74_190_848, isExact: true, sizeSource: "HEAD:Content-Length" },
        { id: "yt-480", bucket: "video", quality: "480p SD", ext: "WEBM", codec: "VP9", extraMeta: "30fps • Saver", bytes: 38_920_000, isExact: false, sizeSource: "yt-dlp:filesize_approx" },
      ],
      audio: [
        { id: "yt-a-flac", bucket: "audio", quality: "FLAC Lossless", ext: "FLAC", codec: "FLAC", extraMeta: "960 kbps • 24-bit", bytes: 62_491_024, isExact: true, sizeSource: "HEAD:Content-Length" },
        { id: "yt-a-opus", bucket: "audio", quality: "Opus High", ext: "OPUS", codec: "OPUS", extraMeta: "160 kbps • 48kHz", bytes: 10_485_760, isExact: true, sizeSource: "Range: bytes=0-0" },
        { id: "yt-a-m4a", bucket: "audio", quality: "AAC Studio", ext: "M4A", codec: "MP4A", extraMeta: "128 kbps • 44.1kHz", bytes: 8_392_104, isExact: true, sizeSource: "HEAD:Content-Length" },
        { id: "yt-a-mp3", bucket: "audio", quality: "MP3 320k", ext: "MP3", codec: "LAME", extraMeta: "320 kbps • Post-Conv", bytes: 20_880_000, isExact: false, sizeSource: "Estimated bitrate" },
      ],
      images: [
        { id: "yt-i-max", bucket: "images", quality: "MaxRes 1280×720", ext: "JPG", codec: "JPEG", extraMeta: "Original Cover", bytes: 428_910, isExact: true, sizeSource: "HEAD:Content-Length" },
        { id: "yt-i-webp", bucket: "images", quality: "WebP HD", ext: "WEBP", codec: "VP8", extraMeta: "Thumbnail", bytes: 194_320, isExact: true, sizeSource: "HEAD:Content-Length" },
        { id: "yt-i-sd", bucket: "images", quality: "SD 640×480", ext: "JPG", codec: "JPEG", extraMeta: "Preview", bytes: 88_412, isExact: true, sizeSource: "HEAD:Content-Length" },
      ],
      files: [
        { id: "yt-f-ar", bucket: "files", quality: "الترجمة العربية (AR)", ext: "SRT", codec: "UTF-8", extraMeta: "Synced Subtitles", bytes: 42_180, isExact: true, sizeSource: "HEAD:Content-Length" },
        { id: "yt-f-en", bucket: "files", quality: "English CC (EN)", ext: "VTT", codec: "UTF-8", extraMeta: "WebVTT Captions", bytes: 39_640, isExact: true, sizeSource: "HEAD:Content-Length" },
        { id: "yt-f-meta", bucket: "files", quality: "Metadata & Chapters", ext: "JSON", codec: "JSON", extraMeta: "Info Dump", bytes: 18_920, isExact: true, sizeSource: "yt-dlp metadata" },
      ],
    },
  },
  {
    id: "tiktok",
    url: "https://tiktok.com/@auroradesign/video/74892014",
    domain: "tiktok.com",
    siteName: "TikTok",
    siteBadgeColor: "#EC4899",
    siteInitials: "TT",
    titleAr: "مراجعة تصميم الزجاج السائل على أندرويد 15 — بدون علامة مائية",
    titleEn: "Liquid Glass UI Motion Study on Android 15 — Clean Feed",
    fileName: "TikTok_LiquidGlass_UI_Clean",
    author: "@auroradesign",
    duration: "00:48",
    publishDate: "2026-03-01",
    primaryTypeAr: "فيديو قصير",
    primaryTypeEn: "Short Video",
    artworkGradient: "linear-gradient(135deg, #1F1135 0%, #9B72CB 50%, #D96570 100%)",
    artworkTint: "#D96570",
    buckets: {
      video: [
        { id: "tt-1080", bucket: "video", quality: "1080p بدون علامة", ext: "MP4", codec: "HEVC", extraMeta: "60fps • Clean HD", bytes: 24_819_200, isExact: true, sizeSource: "HEAD:Content-Length", watermarkFree: true },
        { id: "tt-720", bucket: "video", quality: "720p بدون علامة", ext: "MP4", codec: "AVC1", extraMeta: "30fps • Fast", bytes: 12_410_880, isExact: true, sizeSource: "Range: bytes=0-0", watermarkFree: true },
        { id: "tt-wm", bucket: "video", quality: "720p أصلي", ext: "MP4", codec: "AVC1", extraMeta: "With Watermark", bytes: 13_102_400, isExact: true, sizeSource: "HEAD:Content-Length" },
      ],
      audio: [
        { id: "tt-a1", bucket: "audio", quality: "الموسيقى الأصلية", ext: "M4A", codec: "AAC", extraMeta: "192 kbps • Original", bytes: 1_240_920, isExact: true, sizeSource: "HEAD:Content-Length" },
        { id: "tt-a2", bucket: "audio", quality: "MP3 متوافق", ext: "MP3", codec: "LAME", extraMeta: "192 kbps", bytes: 1_190_000, isExact: false, sizeSource: "Estimated" },
      ],
      images: [
        { id: "tt-i1", bucket: "images", quality: "غلاف المقطع HD", ext: "WEBP", codec: "WEBP", extraMeta: "1080×1920", bytes: 218_420, isExact: true, sizeSource: "HEAD:Content-Length" },
      ],
      // Strictly EMPTY -> Files button MUST NOT appear!
      files: [],
    },
  },
  {
    id: "soundcloud",
    url: "https://soundcloud.com/ambient-labs/glass-horizon",
    domain: "soundcloud.com",
    siteName: "SoundCloud",
    siteBadgeColor: "#F97316",
    siteInitials: "SC",
    titleAr: "أفق الزجاج — مقطوعة موسيقية محيطية (Master Audio)",
    titleEn: "Glass Horizon — Spatial Ambient Session (Master)",
    fileName: "AmbientLabs_Glass_Horizon",
    author: "Ambient Labs",
    duration: "04:19",
    publishDate: "2026-01-22",
    primaryTypeAr: "صوت نقي",
    primaryTypeEn: "Audio Track",
    artworkGradient: "linear-gradient(135deg, #2D1B00 0%, #F97316 55%, #EC4899 100%)",
    artworkTint: "#F97316",
    buckets: {
      audio: [
        { id: "sc-opus", bucket: "audio", quality: "Opus High", ext: "OPUS", codec: "OPUS", extraMeta: "160 kbps • HLS Sum", bytes: 5_218_400, isExact: true, sizeSource: "HLS:HEAD_SUM" },
        { id: "sc-mp3", bucket: "audio", quality: "MP3 320k", ext: "MP3", codec: "MP3", extraMeta: "320 kbps • Constant", bytes: 10_360_128, isExact: true, sizeSource: "HEAD:Content-Length" },
        { id: "sc-flac", bucket: "audio", quality: "WAV / FLAC Export", ext: "FLAC", codec: "FLAC", extraMeta: "Lossless Convert", bytes: 28_400_000, isExact: false, sizeSource: "Approx output" },
      ],
      images: [
        { id: "sc-cover", bucket: "images", quality: "Artwork 1000×1000", ext: "JPG", codec: "JPEG", extraMeta: "Square Cover", bytes: 312_900, isExact: true, sizeSource: "HEAD:Content-Length" },
      ],
      // Strictly EMPTY -> Video & Files buttons MUST NOT appear!
      video: [],
      files: [],
    },
  },
  {
    id: "direct",
    url: "https://releases.auroraget.org/builds/AuroraTools_v3.4_arm64.apk",
    domain: "releases.auroraget.org",
    siteName: "Direct Mirror",
    siteBadgeColor: "#10B981",
    siteInitials: "APK",
    titleAr: "حزمة تثبيت مباشرة — AuroraTools_v3.4_arm64.apk",
    titleEn: "Direct Binary — AuroraTools_v3.4_arm64.apk",
    fileName: "AuroraTools_v3.4_arm64",
    author: "Direct HTTPS + HTTP/3",
    publishDate: "2026-03-11",
    primaryTypeAr: "ملف APK مباشر",
    primaryTypeEn: "Direct APK",
    artworkGradient: "linear-gradient(135deg, #06281E 0%, #10B981 60%, #0EA5E9 100%)",
    artworkTint: "#10B981",
    buckets: {
      audio: [],
      images: [],
      video: [],
      files: [
        { id: "dir-apk", bucket: "files", quality: "ARM64-v8a Signed APK", ext: "APK", codec: "ZIP/APK", extraMeta: "Accept-Ranges: 32x", bytes: 148_372_910, isExact: true, sizeSource: "HEAD:Content-Length" },
      ],
    },
  },
  {
    id: "protected",
    url: "https://streamvault.example.net/watch/cinema-doc-4k",
    domain: "streamvault.example.net",
    siteName: "StreamVault",
    siteBadgeColor: "#F59E0B",
    siteInitials: "CF",
    titleAr: "صفحة محمية بـ Cloudflare وبث غير مباشر (HLS/blob)",
    titleEn: "Cloudflare Protected Indirect Stream Page",
    fileName: "cinema_doc_4k",
    author: "WebView Sniffer Needed",
    publishDate: "2026-03-10",
    primaryTypeAr: "صفحة ويب",
    primaryTypeEn: "Web Page",
    artworkGradient: "linear-gradient(135deg, #1E1B4B 0%, #6366F1 55%, #F59E0B 100%)",
    artworkTint: "#F59E0B",
    requiresBrowserSniffer: true,
    buckets: { audio: [], images: [], video: [], files: [] },
  },
];

export interface DownloadItemState {
  id: string;
  fileName: string;
  siteName: string;
  category: "VIDEO" | "AUDIO" | "IMAGE" | "FILE";
  status: "RUNNING" | "PAUSED" | "QUEUED" | "COMPLETED" | "FAILED";
  downloadedBytes: number;
  totalBytes: number;
  isExact: boolean;
  speedBytesPerSec: number;
  connections: number;
  segmentsProgress: number[]; // visualizes parallel segments + work-stealing
  sparkline: number[];
  eTag: string;
  wifiOnly?: boolean;
  sha256?: string;
  workStealingActive?: boolean;
}

export const INITIAL_DOWNLOADS: DownloadItemState[] = [
  {
    id: "dl-1",
    fileName: "Aurora_Borealis_Iceland_4K_HDR.mp4",
    siteName: "YouTube • DASH Merged",
    category: "VIDEO",
    status: "RUNNING",
    downloadedBytes: 428_410_200,
    totalBytes: 694_218_752,
    isExact: true,
    speedBytesPerSec: 38_400_000,
    connections: 24,
    segmentsProgress: [100, 100, 96, 84, 72, 65, 58, 52, 61, 44, 39, 32],
    sparkline: [21, 26, 29, 34, 32, 37, 39, 36, 41, 38, 40, 38.4],
    eTag: "\"yt-dash-9981a\"",
    workStealingActive: true,
  },
  {
    id: "dl-2",
    fileName: "AuroraTools_v3.4_arm64.apk",
    siteName: "Direct HTTP/3 QUIC",
    category: "FILE",
    status: "PAUSED",
    downloadedBytes: 86_110_400,
    totalBytes: 148_372_910,
    isExact: true,
    speedBytesPerSec: 0,
    connections: 16,
    segmentsProgress: [100, 100, 82, 64, 55, 48, 30, 12],
    sparkline: [18, 22, 24, 19, 0, 0],
    eTag: "\"apk-sha256-cf12\"",
    wifiOnly: true,
  },
  {
    id: "dl-3",
    fileName: "Glass_Horizon_Master.flac",
    siteName: "SoundCloud",
    category: "AUDIO",
    status: "COMPLETED",
    downloadedBytes: 62_491_024,
    totalBytes: 62_491_024,
    isExact: true,
    speedBytesPerSec: 0,
    connections: 16,
    segmentsProgress: [100, 100, 100, 100],
    sparkline: [14, 19, 25, 28, 26, 22],
    eTag: "\"sc-flac-004\"",
    sha256: "e3b0c44298fc1c149afbf4c8996fb924",
  },
  {
    id: "dl-4",
    fileName: "TikTok_LiquidGlass_1080p_Clean.mp4",
    siteName: "TikTok • Fast Path",
    category: "VIDEO",
    status: "QUEUED",
    downloadedBytes: 0,
    totalBytes: 24_819_200,
    isExact: true,
    speedBytesPerSec: 0,
    connections: 16,
    segmentsProgress: [0, 0, 0, 0, 0, 0, 0, 0],
    sparkline: [0, 0, 0, 0],
    eTag: "\"tt-clean-71\"",
  },
];

export interface JpProjModuleInfo {
  moduleName: string;
  path: string;
  layer: "App" | "Core" | "Engine" | "Feature";
  summaryAr: string;
  summaryEn: string;
  highlights: string[];
}

export const JP_PROJ_MODULES: JpProjModuleInfo[] = [
  { moduleName: ":app", path: "JP PROJ/app/", layer: "App", summaryAr: "نقطة الدخول، التنقل، Onboarding، Widget، Quick Settings Tile، واختبارات الوحدة.", summaryEn: "Entry point, Navigation, Onboarding, Home Widget, Quick Settings Tile & Unit Tests.", highlights: ["SplashScreen API", "Predictive Back", "Zero Material Theme"] },
  { moduleName: ":core:designsystem", path: "JP PROJ/core/designsystem/", layer: "Core", summaryAr: "نظام Aurora Glass المخصص بالكامل فوق Compose Foundation/UI بدون أي Material.", summaryEn: "100% custom Aurora Glass Design System built strictly on Compose Foundation/UI.", highlights: ["AGSL Mesh Shader", "Haze Blur", "Custom Duotone Icons"] },
  { moduleName: ":core:common", path: "JP PROJ/core/common/", layer: "Core", summaryAr: "حساب البايتات الدقيقة مقابل ≈، تطبيع الروابط، فحص SHA-256، وتنبيه حقوق النشر.", summaryEn: "Exact vs ≈ FileSizeInfo, URL normalizer, SHA-256 verifier, Copyright compliance.", highlights: ["Exact vs Approx", "Batch URL Parser", "SHA-256 / MD5"] },
  { moduleName: ":core:network", path: "JP PROJ/core/network/", layer: "Core", summaryAr: "OkHttp HTTP/2 + Cronet HTTP/3 QUIC، كوكيز مشفرة، DoH، Preconnect، ومحلل الحجم الدقيق.", summaryEn: "OkHttp HTTP/2 + Cronet HTTP/3 QUIC, EncryptedCookieJar, DoH, ExactFileSizeResolver.", highlights: ["HTTP/3 QUIC", "HEAD → Range 0-0", "AES256 CookieJar"] },
  { moduleName: ":core:database", path: "JP PROJ/core/database/", layer: "Core", summaryAr: "Room للمهام والأجزاء والكاش والقبو الخاص والإحصائيات + DataStore والنسخ الاحتياطي JSON.", summaryEn: "Room tasks/segments/cache/vault/stats + DataStore preferences & JSON backup.", highlights: ["Segment Persistence", "TTL Cache", "JSON Backup"] },
  { moduleName: ":engine:downloader", path: "JP PROJ/engine/downloader/", layer: "Engine", summaryAr: "تحميل مجزأ 8–32 اتصالًا مع Work-Stealing وFileChannel وResume وForeground Service.", summaryEn: "8-32 Segmented Download Engine with Work-Stealing, FileChannel, Resume & dataSync Service.", highlights: ["Work-Stealing", "512KiB FileChannel", "403/410 Auto-Refresh"] },
  { moduleName: ":engine:extractors", path: "JP PROJ/engine/extractors/", layer: "Engine", summaryAr: "yt-dlp (1800+ موقع) + aria2c (-x16 -s16) + Fast Path Native + Jsoup Fallback.", summaryEn: "yt-dlp (1800+ sites) + aria2c (-x16 -s16) + Native Fast Path + Jsoup fallback.", highlights: ["youtubedl-android", "Auto-Update", "High-Res Favicon"] },
  { moduleName: ":engine:media", path: "JP PROJ/engine/media/", layer: "Engine", summaryAr: "دمج DASH عبر FFmpeg بدون إعادة ترميز + محرك التصغير الذكي بوضعي Lossless وVMAF/SSIM ≥ 95.", summaryEn: "FFmpeg stream-copy DASH muxing + Smart Compressor (Lossless & VMAF/SSIM >= 95).", highlights: ["Stream Copy -c copy", "SSIM >= 95 Gate", "Non-Destructive"] },
  { moduleName: ":feature:analyzer", path: "JP PROJ/feature/analyzer/", layer: "Feature", summaryAr: "خط تحليل متوازٍ Stage 0→4 عبر Flow مع Debounce 150ms وبناء الأزرار الذكية غير الفارغة.", summaryEn: "Parallel Stage 0→4 Flow pipeline with 150ms debounce & non-empty bucket builder.", highlights: ["<300ms Stage 1", "LRU + Room TTL", "0 Empty Buckets"] },
  { moduleName: ":feature:home", path: "JP PROJ/feature/home/", layer: "Feature", summaryAr: "حقل اللصق المتوهج، مراقب الحافظة، بطاقة المعلومات المتدرجة، والأزرار الأربعة الذكية.", summaryEn: "Gemini-glow paste field, clipboard chip, progressive info card & 4 Smart Buttons.", highlights: ["Gemini Sweep Glow", "Streaming Text", "Glass Bottom Sheet"] },
  { moduleName: ":feature:downloads", path: "JP PROJ/feature/downloads/", layer: "Feature", summaryAr: "مدير التحميلات، السحب لإعادة الترتيب، Sparkline للسرعة، والجدولة.", summaryEn: "Download queue manager, drag-reorder, live sparklines & WorkManager scheduling.", highlights: ["Reorderable Queue", "Live Sparkline", "Wi-Fi / Charging"] },
  { moduleName: ":feature:browser", path: "JP PROJ/feature/browser/", layer: "Feature", summaryAr: "متصفح WebView + Media Sniffer + AdBlock (adblock-rust) + استخراج cf_clearance لـ Cloudflare.", summaryEn: "WebView + JS/Request Media Sniffer + AdBlock + legitimate Cloudflare clearance handoff.", highlights: ["JS Fetch/Blob Hook", "adblock-rust JNI", "Cookies Handoff"] },
  { moduleName: ":feature:converter", path: "JP PROJ/feature/converter/", layer: "Feature", summaryAr: "تحويل جماعي متعدد الصيغ واستخراج صوت بدون إعادة ترميز وقص وتضمين ترجمة.", summaryEn: "Batch multi-format converter, lossless audio stream copy, trim & subtitle embed.", highlights: ["Batch Queue", "Stream Copy Audio", "MP4/MKV/OPUS/FLAC"] },
  { moduleName: ":feature:compressor", path: "JP PROJ/feature/compressor/", layer: "Feature", summaryAr: "واجهة التصغير الذكي مع سلايدر Before/After الزجاجي والتحقق الصادق من التوفير.", summaryEn: "Smart Compressor UI with interactive Before/After Glass Slider & honest savings check.", highlights: ["Before/After Slider", "Lossless / Transparent", "Exact Byte Diff"] },
  { moduleName: ":feature:player", path: "JP PROJ/feature/player/", layer: "Feature", summaryAr: "مشغل Media3 ExoPlayer لـ HLS/DASH مع PiP وسرعات ومعرض صور Pinch-to-Zoom.", summaryEn: "Media3 ExoPlayer (HLS/DASH), PiP, speeds & Pinch-to-Zoom Image Gallery.", highlights: ["Media3 HLS/DASH", "PiP Support", "Pinch Zoom"] },
  { moduleName: ":feature:files", path: "JP PROJ/feature/files/", layer: "Feature", summaryAr: "مدير الملفات المنظم + القبو الخاص المشفر بـ AES-256-GCM وبصمة BiometricPrompt.", summaryEn: "Organized file library + Biometric AES-256-GCM encrypted Private Vault.", highlights: ["BiometricPrompt", "AES-256-GCM", "Scoped Storage"] },
  { moduleName: ":feature:settings", path: "JP PROJ/feature/settings/", layer: "Feature", summaryAr: "الثيمات الستة، RTL عربي/إنجليزي، اختبار السرعة، تحديث yt-dlp، والنسخ الاحتياطي.", summaryEn: "6 Aurora Themes, Arabic RTL/English, Speed Test, yt-dlp auto-update & JSON backup.", highlights: ["6 Glass Themes", "Full Arabic RTL", "Zero Analytics"] },
];

export function formatBytesHuman(bytes: number, isExact = true): string {
  if (bytes < 0) return "—";
  const prefix = isExact ? "" : "≈ ";
  if (bytes < 1024) return `${prefix}${bytes} B`;
  const units = ["B", "KiB", "MiB", "GiB"];
  let val = bytes;
  let i = 0;
  while (val >= 1024 && i < units.length - 1) {
    val /= 1024;
    i++;
  }
  return `${prefix}${val >= 100 ? val.toFixed(0) : val.toFixed(1)} ${units[i]}`;
}

export function formatExactBytesTooltip(bytes: number, isExact: boolean): string {
  const exactStr = bytes.toLocaleString("en-US");
  const human = formatBytesHuman(bytes, true);
  return `${isExact ? "" : "≈ "}${exactStr} bytes (${human})`;
}
