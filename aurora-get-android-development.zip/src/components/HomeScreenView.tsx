import React, { useEffect, useState } from "react";
import {
  Sparkles,
  ClipboardPaste,
  X,
  Music,
  Image as ImageIcon,
  Film,
  FileText,
  Download,
  Wand2,
  Compass,
  CheckCircle2,
  ShieldAlert,
  Play,
  Layers,
  Info,
} from "lucide-react";
import {
  ANALYZER_SAMPLES,
  AnalyzedSample,
  BucketKey,
  FormatOption,
  formatBytesHuman,
  formatExactBytesTooltip,
  AuroraThemeConfig,
} from "../data/auroraData";

interface HomeScreenViewProps {
  isArabic: boolean;
  darkMode: boolean;
  theme: AuroraThemeConfig;
  onArtworkTintChange: (color: string) => void;
  onStartDownload: (sample: AnalyzedSample, format: FormatOption, customName: string) => void;
  onConvertFormat: (sample: AnalyzedSample, format: FormatOption) => void;
  onOpenBrowserSniffer: (url: string) => void;
}

export const HomeScreenView: React.FC<HomeScreenViewProps> = ({
  isArabic,
  darkMode,
  theme,
  onArtworkTintChange,
  onStartDownload,
  onConvertFormat,
  onOpenBrowserSniffer,
}) => {
  const [urlInput, setUrlInput] = useState(ANALYZER_SAMPLES[0].url);
  const [clipboardUrl, setClipboardUrl] = useState<string | null>(ANALYZER_SAMPLES[1].url);
  const [activeSample, setActiveSample] = useState<AnalyzedSample | null>(ANALYZER_SAMPLES[0]);
  const [editableName, setEditableName] = useState(ANALYZER_SAMPLES[0].fileName);
  const [pipelineStage, setPipelineStage] = useState<number>(3); // 0, 1, 2, 3
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [openSheetBucket, setOpenSheetBucket] = useState<BucketKey | null>(null);
  const [exactTooltip, setExactTooltip] = useState<string | null>(null);
  const [previewPlaying, setPreviewPlaying] = useState(false);

  const runParallelPipeline = (sample: AnalyzedSample) => {
    setUrlInput(sample.url);
    setActiveSample(sample);
    setEditableName(sample.fileName);
    setPreviewPlaying(false);
    setOpenSheetBucket(null);
    setExactTooltip(null);
    setIsAnalyzing(true);
    setPipelineStage(0);
    onArtworkTintChange(sample.artworkTint);
  };

  useEffect(() => {
    if (!isAnalyzing || !activeSample) return;
    const t1 = setTimeout(() => setPipelineStage(1), 160);
    const t2 = setTimeout(() => setPipelineStage(2), 480);
    const t3 = setTimeout(() => {
      setPipelineStage(3);
      setIsAnalyzing(false);
    }, 920);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [isAnalyzing, activeSample]);

  const handleManualUrlChange = (val: string) => {
    setUrlInput(val);
    const found = ANALYZER_SAMPLES.find(
      (s) => val.toLowerCase().includes(s.id) || val.toLowerCase().includes(s.domain)
    );
    if (found) {
      runParallelPipeline(found);
    } else if (!val.trim()) {
      setActiveSample(null);
      setIsAnalyzing(false);
    }
  };

  const glassBg = darkMode
    ? "bg-[#131722]/78 border-white/15 text-[#F5F7FF]"
    : "bg-white/78 border-white/85 text-[#0F172A] shadow-[0_8px_28px_rgba(66,133,244,0.10)]";
  const subText = darkMode ? "text-[#B4BCD0]" : "text-[#475569]";
  const mutedText = darkMode ? "text-[#7B849B]" : "text-[#64748B]";

  // Rule 4.4: STRICTLY only construct buttons for buckets that contain >= 1 real item!
  const nonEmptyBuckets: { key: BucketKey; items: FormatOption[] }[] = activeSample
    ? (["audio", "images", "video", "files"] as BucketKey[])
        .map((key) => ({ key, items: activeSample.buckets[key] }))
        .filter((b) => b.items.length > 0)
    : [];

  const primarySizeItem =
    activeSample?.buckets.video[0] ||
    activeSample?.buckets.audio[0] ||
    activeSample?.buckets.files[0] ||
    activeSample?.buckets.images[0];

  const bucketMeta: Record<
    BucketKey,
    { labelAr: string; labelEn: string; icon: React.ReactNode; color: string }
  > = {
    audio: { labelAr: "صوت", labelEn: "Audio", icon: <Music className="w-4 h-4" />, color: theme.c2 },
    images: { labelAr: "صور", labelEn: "Images", icon: <ImageIcon className="w-4 h-4" />, color: theme.c3 },
    video: { labelAr: "فيديو", labelEn: "Video", icon: <Film className="w-4 h-4" />, color: theme.c1 },
    files: { labelAr: "ملفات", labelEn: "Files", icon: <FileText className="w-4 h-4" />, color: "#34D399" },
  };

  return (
    <div className="relative h-full flex flex-col">
      <div className="phone-scroll flex-1 overflow-y-auto px-3.5 pt-2 pb-24 space-y-3">
        {/* Top App Bar */}
        <div className="flex items-center justify-between">
          <div>
            <h1
              className="text-[22px] font-extrabold tracking-tight bg-clip-text text-transparent"
              style={{
                backgroundImage: `linear-gradient(90deg, ${theme.c1}, ${theme.c2}, ${theme.c3})`,
              }}
            >
              Aurora Get
            </h1>
            <p className={`text-[11px] ${subText}`}>
              {isArabic ? "تحليل فوري لآلاف المواقع • سرعة 32x" : "1800+ Sites Parallel Engine • 32x Speed"}
            </p>
          </div>
          <div
            className={`aurora-glass border rounded-full px-2.5 py-1 text-[10px] font-mono-metric font-semibold flex items-center gap-1.5 ${glassBg}`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            HTTP/3 QUIC
          </div>
        </div>

        {/* Non-intrusive Clipboard Detected Floating Chip */}
        {clipboardUrl && (
          <button
            type="button"
            onClick={() => {
              const target = ANALYZER_SAMPLES.find((s) => s.url === clipboardUrl) || ANALYZER_SAMPLES[1];
              setClipboardUrl(null);
              runParallelPipeline(target);
            }}
            className={`w-full aurora-glass border rounded-full px-3 py-2 flex items-center justify-between gap-2 transition-transform active:scale-[0.98] ${glassBg}`}
            style={{ boxShadow: `0 4px 20px ${theme.c2}28` }}
          >
            <span className="flex items-center gap-2 text-[11px] font-medium truncate">
              <Sparkles className="w-3.5 h-3.5 shrink-0" style={{ color: theme.c1 }} />
              <span className="truncate">
                {isArabic ? "رابط مكتشف في الحافظة (TikTok HD)" : "Clipboard link detected (TikTok HD)"}
              </span>
            </span>
            <span
              className="text-[10px] font-semibold px-2 py-0.5 rounded-full text-white shrink-0"
              style={{ background: `linear-gradient(90deg, ${theme.c1}, ${theme.c2})` }}
            >
              {isArabic ? "تحليل" : "Analyze"}
            </span>
          </button>
        )}

        {/* Giant Glowing Gemini-Style Glass Paste Field */}
        <div
          className={`gemini-glow-ring rounded-[26px] ${isAnalyzing ? "gemini-active" : ""}`}
          style={
            {
              "--glow-c1": theme.c1,
              "--glow-c2": theme.c2,
              "--glow-c3": theme.c3,
            } as React.CSSProperties
          }
        >
          <div className={`aurora-glass border rounded-[26px] p-3.5 space-y-2.5 ${glassBg}`}>
            <div className="flex items-center gap-2">
              <input
                type="text"
                dir="ltr"
                value={urlInput}
                onChange={(e) => handleManualUrlChange(e.target.value)}
                placeholder={
                  isArabic
                    ? "الصق رابط فيديو، صوت، صورة، أو عدة روابط..."
                    : "Paste video, audio, image, file, or batch links..."
                }
                className={`w-full bg-transparent outline-none text-[12px] font-mono-metric ${
                  darkMode ? "text-white placeholder:text-slate-500" : "text-slate-900 placeholder:text-slate-400"
                }`}
              />
              {urlInput && (
                <button
                  type="button"
                  onClick={() => {
                    setUrlInput("");
                    setActiveSample(null);
                    setIsAnalyzing(false);
                  }}
                  className="p-1 rounded-full hover:bg-white/10 transition"
                >
                  <X className="w-3.5 h-3.5 opacity-70" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  const nextIdx =
                    (ANALYZER_SAMPLES.findIndex((s) => s.id === activeSample?.id) + 1) % ANALYZER_SAMPLES.length;
                  runParallelPipeline(ANALYZER_SAMPLES[nextIdx]);
                }}
                className="flex-1 py-2 px-3 rounded-[16px] text-white text-[12px] font-semibold flex items-center justify-center gap-1.5 transition-transform active:scale-95 shadow-lg"
                style={{
                  background: `linear-gradient(100deg, ${theme.c1}, ${theme.c2}, ${theme.c3})`,
                }}
              >
                <ClipboardPaste className="w-3.5 h-3.5" />
                {isArabic ? "لصق وتجربة رابط آخر" : "Smart Paste / Next Sample"}
              </button>
            </div>

            {/* Quick Interactive Test Presets demonstrating Smart 4 Buttons dynamically */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 phone-scroll">
              {ANALYZER_SAMPLES.map((sample) => {
                const selected = activeSample?.id === sample.id;
                return (
                  <button
                    key={sample.id}
                    type="button"
                    onClick={() => runParallelPipeline(sample)}
                    className={`shrink-0 px-2.5 py-1 rounded-full text-[10px] font-semibold border transition-all ${
                      selected
                        ? "text-white border-transparent"
                        : darkMode
                          ? "bg-white/5 border-white/10 text-slate-300 hover:bg-white/10"
                          : "bg-slate-900/5 border-slate-900/10 text-slate-700"
                    }`}
                    style={
                      selected
                        ? { background: `linear-gradient(90deg, ${theme.c1}, ${theme.c2})` }
                        : undefined
                    }
                  >
                    {sample.siteName}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Parallel Pipeline Stages Live Telemetry Strip */}
        {activeSample && (
          <div className="grid grid-cols-4 gap-1.5 px-0.5">
            {[
              { st: 0, label: "Stage 0", ms: "18ms" },
              { st: 1, label: "HEAD/OG", ms: "210ms" },
              { st: 2, label: "FastPath", ms: "0.7s" },
              { st: 3, label: "yt-dlp", ms: "Done" },
            ].map((item) => {
              const reached = pipelineStage >= item.st;
              return (
                <div
                  key={item.st}
                  className={`rounded-xl px-2 py-1 border text-center transition-all ${
                    reached
                      ? darkMode
                        ? "bg-white/10 border-white/20"
                        : "bg-white/85 border-blue-200"
                      : "bg-white/5 border-white/5 opacity-40"
                  }`}
                >
                  <div className="text-[9px] font-bold truncate">{item.label}</div>
                  <div className="text-[9px] font-mono-metric" style={{ color: reached ? theme.c1 : undefined }}>
                    {reached ? item.ms : "..."}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Progressive Info Card */}
        {activeSample ? (
          <div
            className={`gemini-glow-ring rounded-[26px] ${isAnalyzing ? "gemini-active" : ""}`}
            style={
              {
                "--glow-c1": activeSample.artworkTint,
                "--glow-c2": theme.c2,
                "--glow-c3": theme.c3,
              } as React.CSSProperties
            }
          >
            <div
              className={`aurora-glass border rounded-[26px] p-3.5 space-y-3 ${glassBg}`}
              style={{ boxShadow: `0 16px 40px ${activeSample.artworkTint}24` }}
            >
              {/* Site Logo + Domain + Type Badge */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center text-white text-[11px] font-extrabold shrink-0 shadow-md"
                    style={{ backgroundColor: activeSample.siteBadgeColor }}
                  >
                    {activeSample.siteInitials}
                  </div>
                  <div className="min-w-0">
                    <div className="text-[12px] font-bold truncate">{activeSample.siteName}</div>
                    <div className={`text-[10px] font-mono-metric truncate ${mutedText}`}>
                      {activeSample.domain}
                    </div>
                  </div>
                </div>
                <span
                  className="px-2.5 py-1 rounded-full text-[10px] font-semibold border shrink-0"
                  style={{
                    backgroundColor: `${activeSample.artworkTint}22`,
                    borderColor: `${activeSample.artworkTint}55`,
                    color: darkMode ? "#F5F7FF" : "#0F172A",
                  }}
                >
                  {isArabic ? activeSample.primaryTypeAr : activeSample.primaryTypeEn}
                </span>
              </div>

              {/* Cover Artwork + Media3 Preview Trigger or Skeleton Shimmer */}
              {pipelineStage < 1 ? (
                <div className="aurora-skeleton h-32 rounded-[20px] w-full" />
              ) : (
                <div
                  className="relative h-32 rounded-[20px] overflow-hidden flex items-end p-3 border border-white/15"
                  style={{ background: activeSample.artworkGradient }}
                >
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent" />
                  {!activeSample.requiresBrowserSniffer && activeSample.buckets.files.length !== 1 && (
                    <button
                      type="button"
                      onClick={() => setPreviewPlaying((p) => !p)}
                      className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-11 h-11 rounded-full aurora-glass bg-white/20 border border-white/40 flex items-center justify-center text-white transition-transform active:scale-90"
                    >
                      <Play className="w-5 h-5 fill-white" />
                    </button>
                  )}
                  <div className="relative z-10 w-full flex items-center justify-between text-white text-[10px]">
                    <span className="bg-black/50 backdrop-blur-md px-2 py-0.5 rounded-full font-medium">
                      {previewPlaying
                        ? isArabic
                          ? "▶ معاينة Media3 نشطة"
                          : "▶ Media3 Preview Live"
                        : activeSample.author}
                    </span>
                    {activeSample.duration && (
                      <span className="bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-full font-mono-metric">
                        {activeSample.duration}
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* Gemini-Style Streaming Text Reveal Title */}
              <div key={activeSample.id} className="animate-stream-reveal">
                <h2 className="text-[14px] font-bold leading-snug">
                  {isArabic ? activeSample.titleAr : activeSample.titleEn}
                </h2>
              </div>

              {/* Metadata & Exact Size Badge (click/hold for exact bytes) */}
              <div className="flex flex-wrap items-center gap-1.5">
                {primarySizeItem && (
                  <button
                    type="button"
                    onClick={() =>
                      setExactTooltip(
                        exactTooltip
                          ? null
                          : `${formatExactBytesTooltip(primarySizeItem.bytes, primarySizeItem.isExact)} • ${primarySizeItem.sizeSource}`
                      )
                    }
                    className={`px-2.5 py-1 rounded-full text-[10px] font-mono-metric font-semibold border flex items-center gap-1 transition active:scale-95 ${
                      primarySizeItem.isExact
                        ? "bg-emerald-500/15 border-emerald-400/35 text-emerald-400"
                        : "bg-amber-500/15 border-amber-400/35 text-amber-400"
                    }`}
                  >
                    <Info className="w-3 h-3" />
                    {formatBytesHuman(primarySizeItem.bytes, primarySizeItem.isExact)}
                    <span className="opacity-75 text-[9px]">
                      ({primarySizeItem.isExact ? (isArabic ? "مؤكد" : "Exact") : isArabic ? "تقريبي" : "Approx"})
                    </span>
                  </button>
                )}
                <span className={`px-2 py-1 rounded-full text-[10px] bg-white/8 ${subText}`}>
                  {activeSample.publishDate}
                </span>
              </div>

              {exactTooltip && (
                <div className="rounded-xl bg-black/45 border border-emerald-400/30 px-2.5 py-1.5 text-[10px] font-mono-metric text-emerald-300">
                  {exactTooltip}
                </div>
              )}

              {/* Editable File Name */}
              <div
                className={`rounded-[16px] px-3 py-1.5 border flex items-center gap-2 ${
                  darkMode ? "bg-black/30 border-white/10" : "bg-slate-900/5 border-slate-900/10"
                }`}
              >
                <span className={`text-[10px] shrink-0 ${mutedText}`}>
                  {isArabic ? "الاسم:" : "File:"}
                </span>
                <input
                  type="text"
                  dir="ltr"
                  value={editableName}
                  onChange={(e) => setEditableName(e.target.value)}
                  className="w-full bg-transparent outline-none text-[11px] font-mono-metric"
                />
              </div>

              {/* THE 4 SMART BUTTONS (ONLY rendered when bucket has >= 1 actual item!) */}
              {activeSample.requiresBrowserSniffer ? (
                <div className="rounded-[20px] p-3 bg-amber-500/12 border border-amber-400/35 space-y-2">
                  <div className="flex items-center gap-2 text-amber-300 text-[11px] font-semibold">
                    <ShieldAlert className="w-4 h-4 shrink-0" />
                    {isArabic
                      ? "تم رصد حماية Cloudflare أو بث غير مباشر في الصفحة"
                      : "Cloudflare challenge or indirect media stream detected"}
                  </div>
                  <button
                    type="button"
                    onClick={() => onOpenBrowserSniffer(activeSample.url)}
                    className="w-full py-2.5 px-3 rounded-[16px] text-white text-[12px] font-bold flex items-center justify-center gap-2 transition active:scale-95"
                    style={{ background: `linear-gradient(90deg, ${theme.c1}, ${theme.c2})` }}
                  >
                    <Compass className="w-4 h-4" />
                    {isArabic
                      ? "افتح في المتصفح الداخلي لاصطياد الملفات"
                      : "Open in Internal Browser to Sniff Files"}
                  </button>
                </div>
              ) : pipelineStage < 2 ? (
                <div className="grid grid-cols-2 gap-2">
                  <div className="aurora-skeleton h-14 rounded-[18px]" />
                  <div className="aurora-skeleton h-14 rounded-[18px]" />
                </div>
              ) : (
                <div className="space-y-1.5">
                  <div className={`text-[10px] flex items-center justify-between ${mutedText}`}>
                    <span>
                      {isArabic
                        ? `الأزرار الذكية المتاحة (${nonEmptyBuckets.length} من 4)`
                        : `Smart Available Buckets (${nonEmptyBuckets.length} of 4)`}
                    </span>
                    <span className="text-[9px] text-emerald-400">
                      {isArabic ? "لا أزرار فارغة ✓" : "Zero empty buttons ✓"}
                    </span>
                  </div>
                  <div
                    className="grid gap-2"
                    style={{
                      gridTemplateColumns: `repeat(${Math.min(nonEmptyBuckets.length, 4)}, minmax(0, 1fr))`,
                    }}
                  >
                    {nonEmptyBuckets.map((bucket, idx) => {
                      const meta = bucketMeta[bucket.key];
                      return (
                        <button
                          key={`${activeSample.id}-${bucket.key}`}
                          type="button"
                          onClick={() => setOpenSheetBucket(bucket.key)}
                          style={{
                            animationDelay: `${idx * 75}ms`,
                            boxShadow: `0 6px 18px ${meta.color}24`,
                            borderColor: `${meta.color}55`,
                          }}
                          className={`animate-smart-pop aurora-glass border rounded-[18px] py-2.5 px-1.5 flex flex-col items-center justify-center gap-1 transition-transform active:scale-92 hover:brightness-110 ${
                            darkMode ? "bg-white/8" : "bg-white/90"
                          }`}
                        >
                          <div className="flex items-center gap-1" style={{ color: meta.color }}>
                            {meta.icon}
                            <span
                              className="text-[10px] font-mono-metric font-bold px-1.5 py-0.2 rounded-full"
                              style={{ backgroundColor: `${meta.color}24`, color: meta.color }}
                            >
                              {bucket.items.length}
                            </span>
                          </div>
                          <span className="text-[11px] font-bold">
                            {isArabic ? meta.labelAr : meta.labelEn}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Empty State Liquid Pulsing Orb */
          <div className={`aurora-glass border rounded-[28px] p-6 text-center space-y-3 ${glassBg}`}>
            <div
              className="w-16 h-16 mx-auto rounded-full animate-pulse flex items-center justify-center"
              style={{
                background: `radial-gradient(circle, ${theme.c1}, ${theme.c2}, transparent 75%)`,
              }}
            >
              <Sparkles className="w-7 h-7 text-white" />
            </div>
            <p className="text-[13px] font-semibold">
              {isArabic ? "الصق أي رابط للبدء فورًا" : "Paste any URL to start instantly"}
            </p>
            <p className={`text-[11px] ${mutedText}`}>
              {isArabic
                ? "يدعم أكثر من 1800 موقع + HLS/DASH + الروابط المباشرة"
                : "Supports 1800+ sites + HLS/DASH + Direct binaries"}
            </p>
          </div>
        )}

        {/* Legal Copyright Disclaimer (Section 1.11) */}
        <p className={`text-[10px] leading-relaxed px-2 text-center ${mutedText}`}>
          {isArabic
            ? "⚖️ المسؤولية تقع بالكامل على المستخدم في احترام حقوق النشر. لا يدعم التطبيق تجاوز DRM أو المحتوى المدفوع."
            : "⚖️ Users are solely responsible for respecting copyright laws. DRM & paywall bypass are strictly unsupported."}
        </p>
      </div>

      {/* Physics Glass Bottom Sheet for Selected Smart Bucket */}
      {openSheetBucket && activeSample && (
        <div
          className="absolute inset-0 z-40 bg-black/55 backdrop-blur-sm flex items-end"
          onClick={() => setOpenSheetBucket(null)}
        >
          <div
            className={`w-full max-h-[76%] aurora-glass border-t rounded-t-[30px] p-4 flex flex-col gap-3 animate-stream-reveal ${
              darkMode
                ? "bg-[#121622]/94 border-white/20 text-white"
                : "bg-white/95 border-blue-200 text-slate-900"
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1 rounded-full bg-white/30 mx-auto" />
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span style={{ color: bucketMeta[openSheetBucket].color }}>
                  {bucketMeta[openSheetBucket].icon}
                </span>
                <h3 className="text-[15px] font-bold">
                  {isArabic ? bucketMeta[openSheetBucket].labelAr : bucketMeta[openSheetBucket].labelEn} (
                  {activeSample.buckets[openSheetBucket].length})
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setOpenSheetBucket(null)}
                className="p-1.5 rounded-full bg-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="phone-scroll overflow-y-auto space-y-2 pb-4">
              {activeSample.buckets[openSheetBucket].map((fmt) => (
                <div
                  key={fmt.id}
                  className={`rounded-[20px] p-3 border flex items-center justify-between gap-2 ${
                    darkMode ? "bg-white/6 border-white/10" : "bg-slate-900/5 border-slate-900/10"
                  }`}
                >
                  <div className="min-w-0 space-y-1">
                    <div className="flex items-center flex-wrap gap-1.5">
                      <span className="text-[12px] font-bold">{fmt.quality}</span>
                      <span className="px-1.5 py-0.5 rounded-md text-[9px] font-mono-metric font-bold bg-white/12">
                        {fmt.ext}
                      </span>
                      <span className="px-1.5 py-0.5 rounded-md text-[9px] font-mono-metric bg-white/8 opacity-80">
                        {fmt.codec}
                      </span>
                      {fmt.autoMergeDash && (
                        <span
                          className="px-1.5 py-0.5 rounded-md text-[9px] font-semibold flex items-center gap-0.5"
                          style={{ backgroundColor: `${theme.c2}30`, color: theme.c2 }}
                        >
                          <Layers className="w-2.5 h-2.5" />
                          {isArabic ? "دمج DASH" : "Auto-Merge"}
                        </span>
                      )}
                      {fmt.watermarkFree && (
                        <span className="px-1.5 py-0.5 rounded-md text-[9px] font-semibold bg-emerald-500/20 text-emerald-400 flex items-center gap-0.5">
                          <CheckCircle2 className="w-2.5 h-2.5" />
                          {isArabic ? "صافي" : "Clean"}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center flex-wrap gap-2 text-[10px]">
                      <span
                        title={formatExactBytesTooltip(fmt.bytes, fmt.isExact)}
                        className={`font-mono-metric font-bold ${
                          fmt.isExact ? "text-emerald-400" : "text-amber-400"
                        }`}
                      >
                        {formatBytesHuman(fmt.bytes, fmt.isExact)}
                      </span>
                      <span className={mutedText}>{fmt.extraMeta}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      title={isArabic ? "تحويل إلى..." : "Convert to..."}
                      onClick={() => {
                        setOpenSheetBucket(null);
                        onConvertFormat(activeSample, fmt);
                      }}
                      className={`p-2 rounded-[14px] border transition active:scale-90 ${
                        darkMode ? "bg-white/8 border-white/15" : "bg-white border-slate-200"
                      }`}
                    >
                      <Wand2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setOpenSheetBucket(null);
                        onStartDownload(activeSample, fmt, editableName);
                      }}
                      className="px-3 py-2 rounded-[14px] text-white text-[11px] font-bold flex items-center gap-1 transition active:scale-92"
                      style={{ background: `linear-gradient(100deg, ${theme.c1}, ${theme.c2})` }}
                    >
                      <Download className="w-3.5 h-3.5" />
                      {isArabic ? "تحميل" : "Get"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
