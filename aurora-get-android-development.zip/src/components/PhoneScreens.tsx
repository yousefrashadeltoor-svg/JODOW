import React, { useRef, useState } from "react";
import {
  Play,
  Pause,
  Trash2,
  Minimize2,
  Wand2,
  Shield,
  ShieldCheck,
  Download,
  Globe,
  RefreshCw,
  Monitor,
  EyeOff,
  Lock,
  Fingerprint,
  FolderOpen,
  CheckCircle2,
  Gauge,
  UploadCloud,
  Sparkles,
  Wifi,
  ChevronLeft,
  ChevronRight,
  SlidersHorizontal,
  Music,
  Film,
  X,
} from "lucide-react";
import {
  AURORA_THEMES,
  AuroraThemeConfig,
  DownloadItemState,
  ThemePresetId,
  formatBytesHuman,
} from "../data/auroraData";

/* ============================================================================
 * 1) DOWNLOADS MANAGER SCREEN (Segmented 8-32x + Work-Stealing + Sparkline)
 * ============================================================================ */
export const DownloadsScreenView: React.FC<{
  downloads: DownloadItemState[];
  isArabic: boolean;
  darkMode: boolean;
  theme: AuroraThemeConfig;
  onTogglePause: (id: string) => void;
  onDelete: (id: string) => void;
  onCompressTask: (task: DownloadItemState) => void;
  onConvertTask: (task: DownloadItemState) => void;
}> = ({ downloads, isArabic, darkMode, theme, onTogglePause, onDelete, onCompressTask, onConvertTask }) => {
  const [tab, setTab] = useState<"ALL" | "RUNNING" | "QUEUED" | "COMPLETED" | "FAILED">("ALL");
  const [catFilter, setCatFilter] = useState<string>("ALL");

  const glassBg = darkMode
    ? "bg-[#131722]/78 border-white/14 text-[#F5F7FF]"
    : "bg-white/82 border-white/90 text-[#0F172A] shadow-sm";
  const mutedText = darkMode ? "text-[#7B849B]" : "text-[#64748B]";

  const filtered = downloads.filter((d) => {
    const tabOk =
      tab === "ALL" ||
      (tab === "RUNNING" && d.status === "RUNNING") ||
      (tab === "QUEUED" && (d.status === "QUEUED" || d.status === "PAUSED")) ||
      (tab === "COMPLETED" && d.status === "COMPLETED") ||
      (tab === "FAILED" && d.status === "FAILED");
    const catOk = catFilter === "ALL" || d.category === catFilter;
    return tabOk && catOk;
  });

  const tabs: { id: typeof tab; ar: string; en: string }[] = [
    { id: "ALL", ar: "الكل", en: "All" },
    { id: "RUNNING", ar: "جارٍ", en: "Active" },
    { id: "QUEUED", ar: "انتظار", en: "Queued" },
    { id: "COMPLETED", ar: "مكتمل", en: "Done" },
    { id: "FAILED", ar: "فاشل", en: "Failed" },
  ];

  return (
    <div className="phone-scroll h-full overflow-y-auto px-3.5 pt-2 pb-24 space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-[18px] font-bold">{isArabic ? "مدير التحميلات" : "Download Manager"}</h2>
          <p className={`text-[10px] ${mutedText}`}>
            {isArabic ? "Work-Stealing متوازٍ + استكمال Room + FileChannel" : "Parallel Work-Stealing + Room Resume + FileChannel"}
          </p>
        </div>
        <span className="px-2.5 py-1 rounded-full text-[10px] font-mono-metric bg-emerald-500/15 text-emerald-400 border border-emerald-400/30">
          {downloads.filter((d) => d.status === "RUNNING").length} {isArabic ? "نشط" : "Active"}
        </span>
      </div>

      {/* Status Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 phone-scroll">
        {tabs.map((t) => {
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`shrink-0 px-3 py-1 rounded-full text-[10px] font-bold border transition ${
                active ? "text-white border-transparent" : `${glassBg}`
              }`}
              style={active ? { background: `linear-gradient(90deg, ${theme.c1}, ${theme.c2})` } : undefined}
            >
              {isArabic ? t.ar : t.en}
            </button>
          );
        })}
      </div>

      {/* Category Filter */}
      <div className="flex items-center gap-1.5 overflow-x-auto phone-scroll">
        {["ALL", "VIDEO", "AUDIO", "IMAGE", "FILE"].map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setCatFilter(c)}
            className={`shrink-0 px-2.5 py-0.5 rounded-full text-[9px] font-mono-metric font-semibold border ${
              catFilter === c
                ? "border-transparent text-white"
                : darkMode
                  ? "bg-white/5 border-white/10 text-slate-400"
                  : "bg-slate-900/5 border-slate-200 text-slate-600"
            }`}
            style={catFilter === c ? { backgroundColor: theme.c2 } : undefined}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Task Cards */}
      <div className="space-y-2.5">
        {filtered.map((task) => {
          const pct = task.totalBytes > 0 ? Math.min(100, (task.downloadedBytes / task.totalBytes) * 100) : 0;
          const etaSec =
            task.status === "RUNNING" && task.speedBytesPerSec > 0
              ? Math.max(1, Math.round((task.totalBytes - task.downloadedBytes) / task.speedBytesPerSec))
              : 0;

          return (
            <div
              key={task.id}
              className={`aurora-glass border rounded-[22px] p-3 space-y-2.5 ${glassBg}`}
              style={
                task.status === "RUNNING"
                  ? { boxShadow: `0 10px 28px ${theme.c1}24`, borderColor: `${theme.c1}55` }
                  : undefined
              }
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="text-[12px] font-bold truncate" dir="ltr">
                    {task.fileName}
                  </div>
                  <div className={`text-[10px] flex items-center gap-1.5 ${mutedText}`}>
                    <span>{task.siteName}</span>
                    <span>•</span>
                    <span className="font-mono-metric">{task.connections}x</span>
                    {task.wifiOnly && <Wifi className="w-3 h-3 text-sky-400" />}
                  </div>
                </div>
                <span
                  className={`shrink-0 px-2 py-0.5 rounded-full text-[9px] font-mono-metric font-bold ${
                    task.status === "RUNNING"
                      ? "bg-blue-500/20 text-blue-300"
                      : task.status === "COMPLETED"
                        ? "bg-emerald-500/20 text-emerald-400"
                        : "bg-white/10 text-slate-300"
                  }`}
                >
                  {pct.toFixed(1)}%
                </span>
              </div>

              {/* Animated Gradient Progress Bar */}
              <div className="h-2 rounded-full bg-black/35 overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-300"
                  style={{
                    width: `${pct}%`,
                    background: `linear-gradient(90deg, ${theme.c1}, ${theme.c2}, ${theme.c3})`,
                  }}
                />
              </div>

              {/* Live Segmented Parallel Lanes Visualization */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[9px]">
                  <span className={mutedText}>
                    {isArabic ? "أجزاء التحميل المتوازية (Segments)" : "Parallel Segments"}
                  </span>
                  {task.workStealingActive && task.status === "RUNNING" && (
                    <span className="text-amber-400 font-semibold">⚡ Work-Stealing</span>
                  )}
                </div>
                <div className="grid grid-cols-12 gap-0.5">
                  {task.segmentsProgress.slice(0, 12).map((seg, idx) => (
                    <div key={idx} className="h-1.5 rounded-sm bg-black/35 overflow-hidden">
                      <div
                        className="h-full transition-all duration-300"
                        style={{
                          width: `${seg}%`,
                          backgroundColor: seg >= 100 ? "#34D399" : idx % 2 === 0 ? theme.c1 : theme.c2,
                        }}
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Speed, ETA, Exact Size & Sparkline */}
              <div className="flex items-center justify-between gap-2">
                <div className="space-y-0.5">
                  <div className="text-[10px] font-mono-metric">
                    {formatBytesHuman(task.downloadedBytes, true)} /{" "}
                    {formatBytesHuman(task.totalBytes, task.isExact)}
                  </div>
                  <div className="text-[10px] font-mono-metric font-semibold" style={{ color: theme.c1 }}>
                    {task.status === "RUNNING"
                      ? `${formatBytesHuman(task.speedBytesPerSec)}/s • ETA ${etaSec}s`
                      : task.status === "COMPLETED"
                        ? `SHA-256 ✓ • ${task.eTag}`
                        : `ETag ${task.eTag} • Resume Ready`}
                  </div>
                </div>
                <MiniSparkline samples={task.sparkline} c1={theme.c1} c2={theme.c3} />
              </div>

              {/* Controls */}
              <div className="flex items-center gap-1.5 pt-0.5">
                {task.status !== "COMPLETED" ? (
                  <button
                    type="button"
                    onClick={() => onTogglePause(task.id)}
                    className="flex-1 py-1.5 px-2.5 rounded-[12px] text-[10px] font-bold text-white flex items-center justify-center gap-1 transition active:scale-95"
                    style={{
                      background:
                        task.status === "RUNNING"
                          ? "rgba(255,255,255,0.12)"
                          : `linear-gradient(90deg, ${theme.c1}, ${theme.c2})`,
                    }}
                  >
                    {task.status === "RUNNING" ? (
                      <>
                        <Pause className="w-3 h-3" /> {isArabic ? "إيقاف مؤقت" : "Pause"}
                      </>
                    ) : (
                      <>
                        <Play className="w-3 h-3" /> {isArabic ? "استكمال" : "Resume"}
                      </>
                    )}
                  </button>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => onCompressTask(task)}
                      className="flex-1 py-1.5 px-2.5 rounded-[12px] text-[10px] font-bold text-white flex items-center justify-center gap-1"
                      style={{ background: `linear-gradient(90deg, ${theme.c1}, ${theme.c2})` }}
                    >
                      <Minimize2 className="w-3 h-3" />
                      {isArabic ? "وفّر 42% بالتصغير" : "Save 42% Compress"}
                    </button>
                    <button
                      type="button"
                      onClick={() => onConvertTask(task)}
                      className="py-1.5 px-2.5 rounded-[12px] text-[10px] font-semibold bg-white/10 flex items-center gap-1"
                    >
                      <Wand2 className="w-3 h-3" />
                      {isArabic ? "تحويل" : "Convert"}
                    </button>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => onDelete(task.id)}
                  className="p-1.5 rounded-[12px] bg-rose-500/15 text-rose-400 hover:bg-rose-500/25"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const MiniSparkline: React.FC<{ samples: number[]; c1: string; c2: string }> = ({ samples, c1, c2 }) => {
  const max = Math.max(...samples, 1);
  const w = 88;
  const h = 28;
  const points = samples
    .map((v, i) => {
      const x = (i / Math.max(samples.length - 1, 1)) * w;
      const y = h - (v / max) * (h - 4) - 2;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  return (
    <svg width={w} height={h} className="overflow-visible shrink-0">
      <defs>
        <linearGradient id="sparkGrad" x1="0" x2="1" y1="0" y2="0">
          <stop offset="0%" stopColor={c1} />
          <stop offset="100%" stopColor={c2} />
        </linearGradient>
      </defs>
      <polyline fill="none" stroke="url(#sparkGrad)" strokeWidth="2.2" strokeLinecap="round" points={points} />
    </svg>
  );
};

/* ============================================================================
 * 2) INTERNAL BROWSER SCREEN (Media Sniffer + AdBlock + Cloudflare Clearance)
 * ============================================================================ */
export const BrowserScreenView: React.FC<{
  initialUrl: string;
  isArabic: boolean;
  darkMode: boolean;
  theme: AuroraThemeConfig;
  onHandoffToEngine: (title: string, ext: string, bytes: number) => void;
}> = ({ initialUrl, isArabic, darkMode, theme, onHandoffToEngine }) => {
  const [urlBar, setUrlBar] = useState(initialUrl || "https://streamvault.example.net/watch/cinema-doc-4k");
  const [desktopMode, setDesktopMode] = useState(false);
  const [privateMode, setPrivateMode] = useState(false);
  const [adBlockEnabled, setAdBlockEnabled] = useState(true);
  const [blockedAdsCount, setBlockedAdsCount] = useState(19);
  const [cfCleared, setCfCleared] = useState(true);
  const [showSniffSheet, setShowSniffSheet] = useState(false);

  const sniffedStreams = [
    { id: "sn-1", title: "master_4k_hevc.m3u8 (HLS Stream)", bucket: "VIDEO", bytes: 418_291_712, ext: "MP4", method: "shouldInterceptRequest" },
    { id: "sn-2", title: "cinema_audio_en.m4a", bucket: "AUDIO", bytes: 14_920_110, ext: "M4A", method: "JS fetch() hook" },
    { id: "sn-3", title: "blob_segment_reconstructed.mp4", bucket: "VIDEO", bytes: 89_410_200, ext: "MP4", method: "MediaSource/blob:" },
    { id: "sn-4", title: "cinema_poster_uhd.webp", bucket: "IMAGE", bytes: 512_400, ext: "WEBP", method: "DOM Scanner" },
  ];

  const glassBg = darkMode
    ? "bg-[#131722]/85 border-white/15 text-[#F5F7FF]"
    : "bg-white/85 border-white/95 text-[#0F172A]";

  return (
    <div className="relative h-full flex flex-col px-3 pt-2 pb-22 space-y-2.5">
      {/* Glass Browser Address Bar */}
      <div className={`aurora-glass border rounded-[22px] p-2.5 space-y-2 ${glassBg}`}>
        <div className="flex items-center gap-1.5">
          <Globe className="w-3.5 h-3.5 shrink-0" style={{ color: theme.c1 }} />
          <input
            type="text"
            dir="ltr"
            value={urlBar}
            onChange={(e) => setUrlBar(e.target.value)}
            className="flex-1 bg-black/25 rounded-full px-2.5 py-1 text-[10px] font-mono-metric outline-none"
          />
          <button
            type="button"
            onClick={() => {
              setCfCleared(false);
              setTimeout(() => {
                setCfCleared(true);
                setBlockedAdsCount((c) => c + 4);
              }, 700);
            }}
            className="p-1.5 rounded-full bg-white/10 active:rotate-180 transition-transform"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-center justify-between gap-1 text-[10px]">
          <div className="flex items-center gap-1">
            <button type="button" className="p-1 rounded-lg bg-white/8">
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
            <button type="button" className="p-1 rounded-lg bg-white/8">
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setDesktopMode((v) => !v)}
              className={`px-2 py-1 rounded-full flex items-center gap-1 font-semibold ${
                desktopMode ? "bg-blue-500/30 text-blue-300" : "bg-white/8 opacity-75"
              }`}
            >
              <Monitor className="w-3 h-3" /> Desktop
            </button>
            <button
              type="button"
              onClick={() => setPrivateMode((v) => !v)}
              className={`px-2 py-1 rounded-full flex items-center gap-1 font-semibold ${
                privateMode ? "bg-purple-500/30 text-purple-300" : "bg-white/8 opacity-75"
              }`}
            >
              <EyeOff className="w-3 h-3" />
            </button>
          </div>
          <button
            type="button"
            onClick={() => setAdBlockEnabled((v) => !v)}
            className={`px-2.5 py-1 rounded-full font-mono-metric font-bold flex items-center gap-1 border ${
              adBlockEnabled
                ? "bg-emerald-500/20 border-emerald-400/40 text-emerald-400"
                : "bg-rose-500/15 border-rose-400/35 text-rose-300"
            }`}
          >
            <Shield className="w-3 h-3" />
            {adBlockEnabled ? `${blockedAdsCount}` : "OFF"}
          </button>
        </div>
      </div>

      {/* Simulated Real Android WebView Viewport */}
      <div className={`flex-1 aurora-glass border rounded-[24px] p-3 overflow-y-auto phone-scroll space-y-2.5 ${glassBg}`}>
        {/* Cloudflare Legitimate WebView Clearance Banner */}
        <div
          className={`rounded-[16px] p-2.5 border text-[10px] flex items-center justify-between gap-2 ${
            cfCleared
              ? "bg-emerald-500/12 border-emerald-400/35 text-emerald-300"
              : "bg-amber-500/15 border-amber-400/35 text-amber-300"
          }`}
        >
          <span className="flex items-center gap-1.5 font-semibold">
            <ShieldCheck className="w-4 h-4 shrink-0" />
            {cfCleared
              ? isArabic
                ? "تم اجتياز Cloudflare وحفظ cf_clearance في CookieJar المشفّر"
                : "Cloudflare cleared • cf_clearance synced to EncryptedCookieJar"
              : isArabic
                ? "جارٍ حل تحدي Cloudflare Turnstile داخل WebView..."
                : "Solving Cloudflare JS Challenge inside real WebView..."}
          </span>
        </div>

        {/* Simulated Video Player DOM inside WebView */}
        <div
          className="h-32 rounded-[18px] relative overflow-hidden flex flex-col justify-between p-3 border border-white/15"
          style={{ background: "linear-gradient(135deg, #1E1B4B, #312E81, #4285F4)" }}
        >
          <span className="self-start px-2 py-0.5 rounded-full bg-black/55 text-white text-[9px] font-mono-metric">
            &lt;video src="blob:https://streamvault..."&gt;
          </span>
          <div className="flex items-center justify-between text-white text-[10px]">
            <span className="font-bold">Cinema Documentary 4K (HLS)</span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/80 text-[9px] font-bold">
              Sniffed ✓
            </span>
          </div>
        </div>

        {/* AdBlock Cosmetic Filtering Visual Proof */}
        <div className="rounded-[16px] p-2.5 border border-dashed border-white/20 bg-black/20 text-[10px] space-y-1">
          <div className="flex items-center justify-between">
            <span className="font-bold flex items-center gap-1 text-emerald-400">
              <Shield className="w-3.5 h-3.5" />
              adblock-rust + EasyList / EasyPrivacy
            </span>
            <span className="font-mono-metric opacity-75">CSS Cosmetic ✓</span>
          </div>
          <p className="opacity-70 leading-relaxed">
            {adBlockEnabled
              ? isArabic
                ? `تم حجب ${blockedAdsCount} عنصرًا: نوافذ منبثقة (Popunders)، متتبعات، و3 أزرار "Download" وهمية مضللة.`
                : `Blocked ${blockedAdsCount} items: popunders, trackers, and 3 deceptive fake "Download" overlays.`
              : isArabic
                ? "تم استثناء هذا الموقع من حجب الإعلانات."
                : "AdBlock paused for this site."}
          </p>
        </div>

        <div className="rounded-[16px] p-2.5 bg-white/5 border border-white/10 text-[10px] space-y-1">
          <div className="font-bold" style={{ color: theme.c1 }}>
            {isArabic ? "بيانات النقل لمحرك التحميل:" : "Headers Passed to Aurora Download Engine:"}
          </div>
          <div className="font-mono-metric text-[9px] opacity-80 leading-relaxed" dir="ltr">
            Cookie: cf_clearance=9a8f...; session=ok
            <br />
            Referer: {urlBar}
            <br />
            User-Agent: {desktopMode ? "Chrome/133 Linux x86_64" : "Chrome/133 Android 15"}
          </div>
        </div>
      </div>

      {/* Floating Glass Media Sniffer FAB */}
      <button
        type="button"
        onClick={() => setShowSniffSheet(true)}
        className="absolute bottom-24 end-5 z-20 px-4 py-3 rounded-full text-white font-bold text-[12px] flex items-center gap-2 shadow-2xl transition-transform active:scale-92 animate-bounce"
        style={{
          background: `linear-gradient(120deg, ${theme.c1}, ${theme.c2}, ${theme.c3})`,
          boxShadow: `0 10px 30px ${theme.c1}66`,
        }}
      >
        <Download className="w-4 h-4" />
        <span>{sniffedStreams.length}</span>
      </button>

      {/* Sniffed Media Glass Bottom Sheet */}
      {showSniffSheet && (
        <div
          className="absolute inset-0 z-40 bg-black/55 backdrop-blur-sm flex items-end"
          onClick={() => setShowSniffSheet(false)}
        >
          <div
            className={`w-full aurora-glass border-t rounded-t-[28px] p-4 space-y-3 ${
              darkMode ? "bg-[#121622]/95 border-white/20 text-white" : "bg-white/95 border-blue-200 text-slate-900"
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="text-[14px] font-bold">
                {isArabic ? `الملفات المصطادة (${sniffedStreams.length})` : `Sniffed Media (${sniffedStreams.length})`}
              </h3>
              <button type="button" onClick={() => setShowSniffSheet(false)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-2 max-h-60 overflow-y-auto phone-scroll">
              {sniffedStreams.map((s) => (
                <div
                  key={s.id}
                  className="rounded-[18px] p-2.5 bg-white/7 border border-white/12 flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <div className="text-[11px] font-bold truncate" dir="ltr">
                      {s.title}
                    </div>
                    <div className="text-[9px] font-mono-metric text-emerald-400">
                      {formatBytesHuman(s.bytes, true)} • {s.method} • Cookies ✓
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setShowSniffSheet(false);
                      onHandoffToEngine(s.title.split(" ")[0], s.ext, s.bytes);
                    }}
                    className="px-2.5 py-1.5 rounded-[12px] text-[10px] font-bold text-white shrink-0"
                    style={{ background: `linear-gradient(90deg, ${theme.c1}, ${theme.c2})` }}
                  >
                    {isArabic ? "حمّل بالمحرك" : "Engine Get"}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* ============================================================================
 * 3) TOOLS SCREEN (Smart Compressor Before/After Slider + Format Converter)
 * ============================================================================ */
export const ToolsScreenView: React.FC<{
  initialSubTab: "compressor" | "converter";
  targetFileName: string;
  isArabic: boolean;
  darkMode: boolean;
  theme: AuroraThemeConfig;
}> = ({ initialSubTab, targetFileName, isArabic, darkMode, theme }) => {
  const [subTab, setSubTab] = useState<"compressor" | "converter">(initialSubTab);
  const [compMode, setCompMode] = useState<"LOSSLESS" | "TRANSPARENT">("TRANSPARENT");
  const [sliderPos, setSliderPos] = useState(50);
  const [alreadyOptimalDemo, setAlreadyOptimalDemo] = useState(false);
  const [convType, setConvType] = useState<"VIDEO" | "AUDIO">("AUDIO");
  const [convTarget, setConvTarget] = useState("OPUS");
  const [streamCopy, setStreamCopy] = useState(true);
  const [convDone, setConvDone] = useState(false);
  const sliderRef = useRef<HTMLDivElement | null>(null);

  const glassBg = darkMode
    ? "bg-[#131722]/78 border-white/15 text-[#F5F7FF]"
    : "bg-white/82 border-white/90 text-[#0F172A]";
  const mutedText = darkMode ? "text-[#7B849B]" : "text-[#64748B]";

  const origBytes = 148_372_910;
  const afterBytes = alreadyOptimalDemo
    ? origBytes
    : compMode === "LOSSLESS"
      ? 121_665_780
      : 68_251_530;
  const savedBytes = origBytes - afterBytes;
  const savedPct = ((savedBytes / origBytes) * 100).toFixed(1);

  const updateSliderFromClientX = (clientX: number) => {
    const rect = sliderRef.current?.getBoundingClientRect();
    if (!rect) return;
    const pct = ((clientX - rect.left) / rect.width) * 100;
    setSliderPos(Math.max(8, Math.min(92, pct)));
  };

  return (
    <div className="phone-scroll h-full overflow-y-auto px-3.5 pt-2 pb-24 space-y-3">
      {/* Sub-tab Switcher */}
      <div className={`aurora-glass border rounded-full p-1 grid grid-cols-2 gap-1 ${glassBg}`}>
        <button
          type="button"
          onClick={() => setSubTab("compressor")}
          className={`py-1.5 rounded-full text-[11px] font-bold transition ${
            subTab === "compressor" ? "text-white" : mutedText
          }`}
          style={
            subTab === "compressor"
              ? { background: `linear-gradient(90deg, ${theme.c1}, ${theme.c2})` }
              : undefined
          }
        >
          {isArabic ? "🗜️ التصغير الذكي" : "🗜️ Smart Compressor"}
        </button>
        <button
          type="button"
          onClick={() => setSubTab("converter")}
          className={`py-1.5 rounded-full text-[11px] font-bold transition ${
            subTab === "converter" ? "text-white" : mutedText
          }`}
          style={
            subTab === "converter"
              ? { background: `linear-gradient(90deg, ${theme.c2}, ${theme.c3})` }
              : undefined
          }
        >
          {isArabic ? "🎞️ تحويل الصيغ" : "🎞️ Converter"}
        </button>
      </div>

      {subTab === "compressor" ? (
        <div className="space-y-3">
          {/* Two Clear Modes: Lossless vs Visually/Audibly Transparent */}
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                setCompMode("LOSSLESS");
                setAlreadyOptimalDemo(false);
              }}
              className={`aurora-glass border rounded-[20px] p-3 text-start space-y-1 transition ${glassBg}`}
              style={
                compMode === "LOSSLESS"
                  ? { borderColor: "#34D399", boxShadow: "0 8px 22px rgba(52,211,153,0.22)" }
                  : undefined
              }
            >
              <div className="text-[11px] font-bold text-emerald-400">
                🟢 {isArabic ? "بدون فقد (Lossless)" : "Lossless"}
              </div>
              <div className={`text-[9px] leading-snug ${mutedText}`}>
                {isArabic ? "mozjpeg / oxipng / zopfli • صفر تغيير بكسل" : "Bit-exact • Zero pixel/sample change"}
              </div>
            </button>
            <button
              type="button"
              onClick={() => {
                setCompMode("TRANSPARENT");
                setAlreadyOptimalDemo(false);
              }}
              className={`aurora-glass border rounded-[20px] p-3 text-start space-y-1 transition ${glassBg}`}
              style={
                compMode === "TRANSPARENT"
                  ? { borderColor: "#FBBF24", boxShadow: "0 8px 22px rgba(251,191,36,0.22)" }
                  : undefined
              }
            >
              <div className="text-[11px] font-bold text-amber-400">
                🟡 {isArabic ? "شفاف بصريًا" : "Transparent"}
              </div>
              <div className={`text-[9px] leading-snug ${mutedText}`}>
                {isArabic ? "HEVC / AV1 • فحص VMAF/SSIM ≥ 95" : "HEVC / AV1 • VMAF/SSIM ≥ 95 Gate"}
              </div>
            </button>
          </div>

          {/* Interactive Draggable Before / After Glass Slider */}
          <div
            ref={sliderRef}
            dir="ltr"
            onPointerMove={(e) => {
              if (e.buttons === 1) updateSliderFromClientX(e.clientX);
            }}
            onPointerDown={(e) => updateSliderFromClientX(e.clientX)}
            className="relative h-40 rounded-[24px] overflow-hidden border border-white/25 cursor-ew-resize select-none touch-none"
          >
            {/* AFTER layer */}
            <div
              className="absolute inset-0 flex flex-col items-end justify-end p-3"
              style={{
                background: "linear-gradient(135deg, #0D1B2A 0%, #1B4332 45%, #4285F4 100%)",
              }}
            >
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/80 text-white text-[9px] font-mono-metric font-bold">
                After: {formatBytesHuman(afterBytes)}
              </span>
            </div>

            {/* BEFORE layer clipped to sliderPos */}
            <div
              className="absolute inset-0 flex flex-col items-start justify-end p-3"
              style={{
                clipPath: `inset(0 ${100 - sliderPos}% 0 0)`,
                background: "linear-gradient(135deg, #1E1B4B 0%, #4C1D95 45%, #D96570 100%)",
              }}
            >
              <span className="px-2 py-0.5 rounded-full bg-black/65 text-white text-[9px] font-mono-metric font-bold">
                Before: {formatBytesHuman(origBytes)}
              </span>
            </div>

            {/* Center filename pill */}
            <div className="absolute top-2.5 inset-x-3 flex items-center justify-between pointer-events-none">
              <span className="px-2 py-0.5 rounded-full bg-black/55 backdrop-blur-md text-white text-[9px] font-mono-metric truncate max-w-[60%]">
                {targetFileName}
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/30 border border-emerald-300/40 backdrop-blur-md text-emerald-200 text-[9px] font-mono-metric font-bold">
                {compMode === "LOSSLESS" ? "Bit-Exact 100%" : "VMAF 97.4 • SSIM 98.6"}
              </span>
            </div>

            {/* Glass Divider Handle */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_12px_white]"
              style={{ left: `${sliderPos}%` }}
            >
              <div
                className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full border-2 border-white flex items-center justify-center text-white text-[11px] font-bold shadow-xl"
                style={{ background: `linear-gradient(135deg, ${theme.c1}, ${theme.c2})` }}
              >
                ⇄
              </div>
            </div>
          </div>

          {/* Honest Savings Report Card */}
          <div className={`aurora-glass border rounded-[22px] p-3.5 space-y-2 ${glassBg}`}>
            {alreadyOptimalDemo ? (
              <div className="text-[11px] text-amber-400 font-semibold leading-relaxed">
                {isArabic
                  ? "ℹ️ هذا الملف مضغوط مسبقًا بأقصى كفاءة ممكنة؛ لم يتم إنشاء نسخة أكبر حفاظًا على الصدق ومساحة جهازك."
                  : "ℹ️ File is already optimally compressed; no larger output was generated."}
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-[12px] font-bold text-emerald-400">
                    {isArabic ? `تم توفير ${savedPct}% (${formatBytesHuman(savedBytes)})` : `Saved ${savedPct}% (${formatBytesHuman(savedBytes)})`}
                  </span>
                  <span className="text-[10px] font-mono-metric px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300">
                    {isArabic ? "نسخة جديدة آمنة ✓" : "Safe New Copy ✓"}
                  </span>
                </div>
                <div className={`text-[10px] font-mono-metric ${mutedText}`} dir="ltr">
                  {origBytes.toLocaleString()} B → {afterBytes.toLocaleString()} B
                </div>
              </>
            )}
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setAlreadyOptimalDemo((v) => !v)}
                className="flex-1 py-2 rounded-[14px] text-[10px] font-semibold bg-white/10"
              >
                {alreadyOptimalDemo
                  ? isArabic
                    ? "عرض ملف قابل للتوفير"
                    : "Show Reducible File"
                  : isArabic
                    ? "اختبار حالة: ملف مضغوط أصلًا"
                    : "Test: Already Optimal File"}
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Format Converter & Stream-Copy Audio Extractor */
        <div className={`aurora-glass border rounded-[24px] p-3.5 space-y-3 ${glassBg}`}>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setConvType("AUDIO");
                setConvTarget("OPUS");
                setConvDone(false);
              }}
              className={`flex-1 py-1.5 rounded-[14px] text-[11px] font-bold flex items-center justify-center gap-1 ${
                convType === "AUDIO" ? "text-white" : "bg-white/8 opacity-75"
              }`}
              style={convType === "AUDIO" ? { backgroundColor: theme.c2 } : undefined}
            >
              <Music className="w-3.5 h-3.5" /> {isArabic ? "استخراج صوت" : "Extract Audio"}
            </button>
            <button
              type="button"
              onClick={() => {
                setConvType("VIDEO");
                setConvTarget("MP4");
                setConvDone(false);
              }}
              className={`flex-1 py-1.5 rounded-[14px] text-[11px] font-bold flex items-center justify-center gap-1 ${
                convType === "VIDEO" ? "text-white" : "bg-white/8 opacity-75"
              }`}
              style={convType === "VIDEO" ? { backgroundColor: theme.c1 } : undefined}
            >
              <Film className="w-3.5 h-3.5" /> {isArabic ? "تحويل فيديو" : "Video Convert"}
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {(convType === "AUDIO"
              ? ["OPUS", "MP3", "M4A", "FLAC", "WAV", "OGG"]
              : ["MP4", "MKV", "WEBM", "MOV", "AVI", "GIF"]
            ).map((fmt) => (
              <button
                key={fmt}
                type="button"
                onClick={() => {
                  setConvTarget(fmt);
                  setConvDone(false);
                }}
                className={`px-3 py-1 rounded-full text-[10px] font-mono-metric font-bold border ${
                  convTarget === fmt ? "text-white border-transparent" : "bg-white/6 border-white/10"
                }`}
                style={convTarget === fmt ? { backgroundColor: theme.c1 } : undefined}
              >
                .{fmt}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setStreamCopy((s) => !s)}
            className="w-full py-2 px-3 rounded-[16px] bg-white/6 border border-white/12 flex items-center justify-between text-[11px]"
          >
            <span>{isArabic ? "استخراج بدون إعادة ترميز (Stream Copy)" : "Lossless Stream Copy (-c copy)"}</span>
            <span className={streamCopy ? "text-emerald-400 font-bold" : mutedText}>
              {streamCopy ? "ON ✓" : "OFF"}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setConvDone(true)}
            className="w-full py-2.5 rounded-[16px] text-white text-[12px] font-bold flex items-center justify-center gap-2 transition active:scale-95"
            style={{ background: `linear-gradient(90deg, ${theme.c1}, ${theme.c2}, ${theme.c3})` }}
          >
            <Wand2 className="w-4 h-4" />
            {isArabic ? `تحويل إلى ${convTarget} الآن` : `Convert to ${convTarget} Now`}
          </button>

          {convDone && (
            <div className="rounded-[16px] p-2.5 bg-emerald-500/15 border border-emerald-400/35 text-emerald-300 text-[10px] font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              {isArabic
                ? `تم التحويل بنجاح عبر FFmpeg + MediaCodec HW إلى .${convTarget}`
                : `Converted cleanly via FFmpeg + MediaCodec HW to .${convTarget}`}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

/* ============================================================================
 * 4) FILES LIBRARY + BUILT-IN MEDIA3 PLAYER + BIOMETRIC PRIVATE VAULT
 * ============================================================================ */
export const FilesAndPlayerView: React.FC<{
  isArabic: boolean;
  darkMode: boolean;
  theme: AuroraThemeConfig;
}> = ({ isArabic, darkMode, theme }) => {
  const [section, setSection] = useState<"LIBRARY" | "VAULT">("LIBRARY");
  const [vaultUnlocked, setVaultUnlocked] = useState(false);
  const [unlocking, setUnlocking] = useState(false);
  const [speed, setSpeed] = useState(1.0);
  const [pipActive, setPipActive] = useState(false);

  const glassBg = darkMode
    ? "bg-[#131722]/78 border-white/15 text-[#F5F7FF]"
    : "bg-white/82 border-white/90 text-[#0F172A]";
  const mutedText = darkMode ? "text-[#7B849B]" : "text-[#64748B]";

  const triggerBiometric = () => {
    setUnlocking(true);
    setTimeout(() => {
      setUnlocking(false);
      setVaultUnlocked(true);
    }, 650);
  };

  return (
    <div className="phone-scroll h-full overflow-y-auto px-3.5 pt-2 pb-24 space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-[17px] font-bold">{isArabic ? "المكتبة والقبو الخاص" : "Library & Private Vault"}</h2>
        <div className="flex gap-1">
          <button
            type="button"
            onClick={() => setSection("LIBRARY")}
            className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
              section === "LIBRARY" ? "text-white" : "bg-white/10"
            }`}
            style={section === "LIBRARY" ? { backgroundColor: theme.c1 } : undefined}
          >
            <FolderOpen className="w-3 h-3 inline me-1" />
            {isArabic ? "الملفات" : "Files"}
          </button>
          <button
            type="button"
            onClick={() => setSection("VAULT")}
            className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
              section === "VAULT" ? "text-white" : "bg-white/10"
            }`}
            style={section === "VAULT" ? { backgroundColor: theme.c2 } : undefined}
          >
            <Lock className="w-3 h-3 inline me-1" />
            {isArabic ? "القبو" : "Vault"}
          </button>
        </div>
      </div>

      {section === "LIBRARY" ? (
        <>
          {/* Built-in Media3 ExoPlayer Preview Card */}
          <div className={`aurora-glass border rounded-[24px] p-3 space-y-2.5 ${glassBg}`}>
            <div
              className="h-32 rounded-[18px] relative overflow-hidden p-3 flex flex-col justify-between"
              style={{ background: "linear-gradient(135deg, #0F2027, #203A43, #4285F4)" }}
            >
              <div className="flex items-center justify-between text-[9px] text-white">
                <span className="px-2 py-0.5 rounded-full bg-black/55 font-mono-metric">Media3 ExoPlayer • HLS/DASH</span>
                {pipActive && <span className="px-2 py-0.5 rounded-full bg-purple-500 font-bold">PiP Active</span>}
              </div>
              <div className="space-y-1">
                <div className="h-1 bg-white/30 rounded-full overflow-hidden">
                  <div className="h-full w-2/3 rounded-full" style={{ backgroundColor: theme.c1 }} />
                </div>
                <div className="flex items-center justify-between text-[9px] font-mono-metric text-white">
                  <span>04:12 / 08:42</span>
                  <span>CC: العربية • {speed}x</span>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-between gap-1">
              <div className="flex items-center gap-1">
                {[0.75, 1.0, 1.5, 2.0].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setSpeed(s)}
                    className={`px-2 py-0.5 rounded-full text-[10px] font-mono-metric font-bold ${
                      speed === s ? "text-white" : "bg-white/10"
                    }`}
                    style={speed === s ? { backgroundColor: theme.c1 } : undefined}
                  >
                    {s}x
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={() => setPipActive((p) => !p)}
                className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-white/12"
              >
                PiP
              </button>
            </div>
          </div>

          {/* Organized Folders */}
          <div className="space-y-2">
            {[
              { name: "Aurora_Borealis_4K_HDR.mp4", folder: "Video / YouTube", size: "662.1 MiB" },
              { name: "Glass_Horizon_Master.flac", folder: "Audio / SoundCloud", size: "59.6 MiB" },
              { name: "AuroraTools_v3.4_arm64.apk", folder: "Files / APK", size: "141.5 MiB" },
            ].map((f) => (
              <div
                key={f.name}
                className={`aurora-glass border rounded-[18px] p-3 flex items-center justify-between ${glassBg}`}
              >
                <div className="min-w-0">
                  <div className="text-[11px] font-bold truncate" dir="ltr">
                    {f.name}
                  </div>
                  <div className={`text-[9px] ${mutedText}`}>
                    {f.folder} • <span className="font-mono-metric">{f.size}</span>
                  </div>
                </div>
                <span className="px-2 py-1 rounded-full text-[9px] bg-white/10 font-semibold">Metadata ✓</span>
              </div>
            ))}
          </div>
        </>
      ) : !vaultUnlocked ? (
        /* Locked Private Vault Biometric Prompt */
        <div className={`aurora-glass border rounded-[26px] p-6 text-center space-y-3 ${glassBg}`}>
          <div
            className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center border border-white/25 ${
              unlocking ? "animate-ping" : ""
            }`}
            style={{ background: `linear-gradient(135deg, ${theme.c1}44, ${theme.c2}55)` }}
          >
            <Fingerprint className="w-8 h-8" style={{ color: theme.c1 }} />
          </div>
          <h3 className="text-[14px] font-bold">
            {isArabic ? "القبو الخاص (AES-256-GCM)" : "Private Vault (AES-256-GCM)"}
          </h3>
          <p className={`text-[11px] ${mutedText}`}>
            {isArabic
              ? "مشفّر بمفتاح Android Keystore ولا يُفتح إلا بالبصمة."
              : "Encrypted via Android Keystore hardware-backed keys."}
          </p>
          <button
            type="button"
            onClick={triggerBiometric}
            className="w-full py-2.5 rounded-[16px] text-white text-[12px] font-bold transition active:scale-95"
            style={{ background: `linear-gradient(90deg, ${theme.c1}, ${theme.c2})` }}
          >
            {unlocking
              ? isArabic
                ? "جارٍ التحقق من البصمة..."
                : "Authenticating Biometrics..."
              : isArabic
                ? "فتح بالبصمة الآن"
                : "Unlock with Biometrics"}
          </button>
        </div>
      ) : (
        <div className="space-y-2">
          <div className="rounded-[16px] p-2.5 bg-emerald-500/15 border border-emerald-400/35 text-emerald-300 text-[11px] font-bold flex items-center justify-between">
            <span>🔓 {isArabic ? "تم فتح القبو المشفر" : "Encrypted Vault Unlocked"}</span>
            <button type="button" onClick={() => setVaultUnlocked(false)} className="underline text-[10px]">
              {isArabic ? "قفل" : "Lock"}
            </button>
          </div>
          {[
            { name: "Private_Project_Archive.zip.auroraenc", size: "248.0 MiB" },
            { name: "Personal_Backup_Keys.pdf.auroraenc", size: "4.2 MiB" },
          ].map((vf) => (
            <div key={vf.name} className={`aurora-glass border rounded-[18px] p-3 flex items-center justify-between ${glassBg}`}>
              <div className="min-w-0">
                <div className="text-[11px] font-bold truncate" dir="ltr">
                  {vf.name}
                </div>
                <div className="text-[9px] font-mono-metric text-emerald-400">AES-256-GCM • {vf.size}</div>
              </div>
              <Lock className="w-4 h-4 text-emerald-400 shrink-0" />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/* ============================================================================
 * 5) SETTINGS SCREEN (6 Themes, Dark/Light, RTL/LTR, Speed Test, yt-dlp Update)
 * ============================================================================ */
export const SettingsScreenView: React.FC<{
  themeId: ThemePresetId;
  darkMode: boolean;
  isArabic: boolean;
  connections: number;
  onChangeTheme: (id: ThemePresetId) => void;
  onToggleDark: () => void;
  onToggleLang: () => void;
  onChangeConnections: (n: number) => void;
  onReplayOnboarding: () => void;
}> = ({
  themeId,
  darkMode,
  isArabic,
  connections,
  onChangeTheme,
  onToggleDark,
  onToggleLang,
  onChangeConnections,
  onReplayOnboarding,
}) => {
  const theme = AURORA_THEMES[themeId];
  const [speedResult, setSpeedResult] = useState<string | null>(null);
  const [ytDlpStatus, setYtDlpStatus] = useState<string | null>(null);
  const [dohEnabled, setDohEnabled] = useState(true);
  const [backupToast, setBackupToast] = useState(false);

  const glassBg = darkMode
    ? "bg-[#131722]/78 border-white/15 text-[#F5F7FF]"
    : "bg-white/82 border-white/90 text-[#0F172A]";
  const mutedText = darkMode ? "text-[#7B849B]" : "text-[#64748B]";

  return (
    <div className="phone-scroll h-full overflow-y-auto px-3.5 pt-2 pb-24 space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-[18px] font-bold flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4" style={{ color: theme.c1 }} />
          {isArabic ? "الإعدادات والمظهر" : "Settings & Themes"}
        </h2>
        <button
          type="button"
          onClick={onReplayOnboarding}
          className="px-2.5 py-1 rounded-full text-[10px] font-semibold bg-white/10"
        >
          {isArabic ? "شاشة الترحيب" : "Onboarding"}
        </button>
      </div>

      {/* 6 Aurora Glass Themes + Dark AMOLED / Light + RTL */}
      <div className={`aurora-glass border rounded-[24px] p-3.5 space-y-3 ${glassBg}`}>
        <div className="text-[12px] font-bold">{isArabic ? "ثيمات Aurora Glass الستة" : "6 Aurora Glass Themes"}</div>
        <div className="grid grid-cols-3 gap-1.5">
          {Object.values(AURORA_THEMES).map((preset) => {
            const active = preset.id === themeId;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => onChangeTheme(preset.id)}
                className={`rounded-[14px] p-2 border text-center transition active:scale-95 ${
                  active ? "border-white bg-white/12" : "border-white/10 bg-white/5"
                }`}
              >
                <div
                  className="h-3 rounded-full mb-1.5"
                  style={{ background: `linear-gradient(90deg, ${preset.c1}, ${preset.c2}, ${preset.c3})` }}
                />
                <div className="text-[10px] font-bold truncate">{isArabic ? preset.nameAr : preset.nameEn}</div>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={onToggleDark}
            className="py-2 px-3 rounded-[14px] text-[11px] font-bold bg-white/10 border border-white/15"
          >
            {darkMode ? "🌙 AMOLED Dark" : "☀️ Light Glass"}
          </button>
          <button
            type="button"
            onClick={onToggleLang}
            className="py-2 px-3 rounded-[14px] text-[11px] font-bold bg-white/10 border border-white/15"
          >
            {isArabic ? "🌐 العربية (RTL)" : "🌐 English (LTR)"}
          </button>
        </div>
      </div>

      {/* Segmented Connections + Speed Test + DoH + yt-dlp Update */}
      <div className={`aurora-glass border rounded-[24px] p-3.5 space-y-3 ${glassBg}`}>
        <div className="flex items-center justify-between text-[12px] font-bold">
          <span>{isArabic ? "عدد الاتصالات المتوازية" : "Parallel Connections"}</span>
          <span className="font-mono-metric" style={{ color: theme.c1 }}>
            {connections}x
          </span>
        </div>
        <div className="grid grid-cols-4 gap-1.5">
          {[8, 16, 24, 32].map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => onChangeConnections(n)}
              className={`py-1.5 rounded-[12px] text-[11px] font-mono-metric font-bold ${
                connections === n ? "text-white" : "bg-white/8"
              }`}
              style={connections === n ? { backgroundColor: theme.c1 } : undefined}
            >
              {n}x
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => setDohEnabled((v) => !v)}
          className="w-full py-2 px-3 rounded-[14px] bg-white/6 flex items-center justify-between text-[11px]"
        >
          <span>DNS-over-HTTPS (Cloudflare DoH)</span>
          <span className={dohEnabled ? "text-emerald-400 font-bold" : mutedText}>
            {dohEnabled ? "ON ✓" : "OFF"}
          </span>
        </button>

        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => {
              setSpeedResult("312 Mbps • Suggested: 24x");
              onChangeConnections(24);
            }}
            className="py-2 px-2.5 rounded-[14px] text-white text-[10px] font-bold flex items-center justify-center gap-1"
            style={{ background: `linear-gradient(90deg, ${theme.c1}, ${theme.c2})` }}
          >
            <Gauge className="w-3.5 h-3.5" />
            {isArabic ? "اختبار السرعة" : "Speed Test"}
          </button>
          <button
            type="button"
            onClick={() => setYtDlpStatus("yt-dlp 2026.03 + EasyList ✓")}
            className="py-2 px-2.5 rounded-[14px] text-[10px] font-bold bg-white/10 flex items-center justify-center gap-1"
          >
            <Sparkles className="w-3.5 h-3.5" />
            {isArabic ? "تحديث yt-dlp" : "Update yt-dlp"}
          </button>
        </div>

        {speedResult && <div className="text-[10px] font-mono-metric text-emerald-400">⚡ {speedResult}</div>}
        {ytDlpStatus && <div className="text-[10px] font-mono-metric text-sky-400">✓ {ytDlpStatus}</div>}
      </div>

      {/* Stats & JSON Backup */}
      <div className={`aurora-glass border rounded-[24px] p-3.5 space-y-2 ${glassBg}`}>
        <div className="text-[12px] font-bold">{isArabic ? "الإحصائيات والنسخ الاحتياطي" : "Stats & JSON Backup"}</div>
        <div className="grid grid-cols-2 gap-2 text-center">
          <div className="rounded-[14px] p-2 bg-white/6">
            <div className="text-[14px] font-mono-metric font-extrabold" style={{ color: theme.c1 }}>
              14.8 GiB
            </div>
            <div className={`text-[9px] ${mutedText}`}>{isArabic ? "إجمالي المحمّل" : "Total Downloaded"}</div>
          </div>
          <div className="rounded-[14px] p-2 bg-white/6">
            <div className="text-[14px] font-mono-metric font-extrabold text-emerald-400">3.9 GiB</div>
            <div className={`text-[9px] ${mutedText}`}>{isArabic ? "التوفير بالتصغير" : "Saved by Compressor"}</div>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setBackupToast(true)}
          className="w-full py-2 rounded-[14px] text-[11px] font-bold bg-white/10 flex items-center justify-center gap-1.5"
        >
          <UploadCloud className="w-3.5 h-3.5" />
          {isArabic ? "تصدير السجل والإعدادات (JSON)" : "Export Settings & History (JSON)"}
        </button>
        {backupToast && (
          <div className="text-[10px] font-mono-metric text-emerald-400">
            ✓ aurora_backup.json exported (Offline-First • Zero Firebase)
          </div>
        )}
      </div>
    </div>
  );
};
