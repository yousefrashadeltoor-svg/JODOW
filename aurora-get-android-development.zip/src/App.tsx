import React, { useEffect, useState } from "react";
import {
  Sparkles,
  Download,
  Compass,
  Wand2,
  Folder,
  Sliders,
  Wifi,
  BatteryCharging,
  Signal,
} from "lucide-react";
import {
  AURORA_THEMES,
  AnalyzedSample,
  DownloadItemState,
  FormatOption,
  INITIAL_DOWNLOADS,
  ThemePresetId,
} from "./data/auroraData";
import { HomeScreenView } from "./components/HomeScreenView";
import {
  BrowserScreenView,
  DownloadsScreenView,
  FilesAndPlayerView,
  SettingsScreenView,
  ToolsScreenView,
} from "./components/PhoneScreens";
import { ProjectInspectorPanel } from "./components/ProjectInspectorPanel";

type AppTab = "home" | "downloads" | "browser" | "tools" | "files" | "settings";

export function App() {
  const [themeId, setThemeId] = useState<ThemePresetId>("aurora");
  const [darkMode, setDarkMode] = useState(true);
  const [isArabic, setIsArabic] = useState(true);
  const [activeTab, setActiveTab] = useState<AppTab>("home");
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [artworkTint, setArtworkTint] = useState<string>("#4285F4");
  const [connections, setConnections] = useState<number>(24);
  const [downloads, setDownloads] = useState<DownloadItemState[]>(INITIAL_DOWNLOADS);
  const [browserInitialUrl, setBrowserInitialUrl] = useState(
    "https://streamvault.example.net/watch/cinema-doc-4k"
  );
  const [toolsSubTab, setToolsSubTab] = useState<"compressor" | "converter">("compressor");
  const [toolsFileName, setToolsFileName] = useState("Aurora_Borealis_Iceland_4K_HDR.mp4");
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const theme = AURORA_THEMES[themeId];

  useEffect(() => {
    document.documentElement.dir = isArabic ? "rtl" : "ltr";
    document.documentElement.lang = isArabic ? "ar" : "en";
  }, [isArabic]);

  // Live Segmented Parallel Download Ticker (simulates Work-Stealing + real-time speed sparklines)
  useEffect(() => {
    const timer = setInterval(() => {
      setDownloads((prev) =>
        prev.map((item) => {
          if (item.status !== "RUNNING") return item;
          const jitter = 0.85 + Math.random() * 0.32;
          const tickSpeed = Math.round(item.connections * 1_650_000 * jitter);
          const nextDownloaded = Math.min(item.totalBytes, item.downloadedBytes + Math.round(tickSpeed * 0.65));
          const completed = nextDownloaded >= item.totalBytes;

          const nextSegments = item.segmentsProgress.map((seg, idx) => {
            if (completed) return 100;
            const boost = idx < 4 ? 4.2 : 2.8 + Math.random() * 3.5;
            return Math.min(100, seg + boost);
          });

          const speedMb = +(tickSpeed / (1024 * 1024)).toFixed(1);
          const nextSpark = [...item.sparkline.slice(-11), completed ? 0 : speedMb];

          return {
            ...item,
            downloadedBytes: nextDownloaded,
            speedBytesPerSec: completed ? 0 : tickSpeed,
            status: completed ? "COMPLETED" : "RUNNING",
            segmentsProgress: nextSegments,
            sparkline: nextSpark,
            sha256: completed ? "a4f901c8e2b77193f10a9d82e3b4f610" : item.sha256,
          };
        })
      );
    }, 650);
    return () => clearInterval(timer);
  }, []);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg((cur) => (cur === msg ? null : cur)), 2800);
  };

  const handleStartDownload = (sample: AnalyzedSample, fmt: FormatOption, customName: string) => {
    const newTask: DownloadItemState = {
      id: `dl-${Date.now()}`,
      fileName: `${customName || sample.fileName}.${fmt.ext.toLowerCase()}`,
      siteName: `${sample.siteName}${fmt.autoMergeDash ? " • DASH Merged" : ""}`,
      category:
        fmt.bucket === "video"
          ? "VIDEO"
          : fmt.bucket === "audio"
            ? "AUDIO"
            : fmt.bucket === "images"
              ? "IMAGE"
              : "FILE",
      status: "RUNNING",
      downloadedBytes: Math.round(fmt.bytes * 0.04),
      totalBytes: fmt.bytes,
      isExact: fmt.isExact,
      speedBytesPerSec: connections * 1_550_000,
      connections,
      segmentsProgress: [16, 14, 11, 9, 12, 8, 6, 9, 7, 5, 4, 3],
      sparkline: [12, 18, 24, 29, 34],
      eTag: `"aurora-${Math.floor(Math.random() * 9000 + 1000)}"`,
      workStealingActive: true,
    };
    setDownloads((prev) => [newTask, ...prev]);
    setActiveTab("downloads");
    showToast(
      isArabic
        ? `⚡ بدأ التحميل المجزأ (${connections}x): ${newTask.fileName}`
        : `⚡ Started ${connections}x Segmented Download: ${newTask.fileName}`
    );
  };

  const handleBrowserHandoff = (title: string, ext: string, bytes: number) => {
    const newTask: DownloadItemState = {
      id: `dl-br-${Date.now()}`,
      fileName: `${title}.${ext.toLowerCase()}`,
      siteName: "WebView Sniffer • Cookies+UA ✓",
      category: ext === "M4A" ? "AUDIO" : ext === "WEBP" ? "IMAGE" : "VIDEO",
      status: "RUNNING",
      downloadedBytes: Math.round(bytes * 0.05),
      totalBytes: bytes,
      isExact: true,
      speedBytesPerSec: connections * 1_450_000,
      connections,
      segmentsProgress: [18, 12, 10, 8, 9, 7, 5, 4, 6, 3, 2, 2],
      sparkline: [14, 20, 26, 31],
      eTag: `"cf-cleared-${Math.floor(Math.random() * 900 + 100)}"`,
      workStealingActive: true,
    };
    setDownloads((prev) => [newTask, ...prev]);
    setActiveTab("downloads");
    showToast(
      isArabic
        ? "🛡️ تم نقل الكوكيز والـ Headers إلى محرك Aurora بنجاح"
        : "🛡️ Transferred Cookies & Headers to Aurora Download Engine"
    );
  };

  const activeRunningCount = downloads.filter((d) => d.status === "RUNNING").length;

  const dockItems: { id: AppTab; ar: string; en: string; icon: React.ReactNode; badge?: number }[] = [
    { id: "home", ar: "الرئيسية", en: "Home", icon: <Sparkles className="w-4 h-4" /> },
    { id: "downloads", ar: "التحميلات", en: "Queue", icon: <Download className="w-4 h-4" />, badge: activeRunningCount },
    { id: "browser", ar: "المتصفح", en: "Sniff", icon: <Compass className="w-4 h-4" /> },
    { id: "tools", ar: "أدوات", en: "Tools", icon: <Wand2 className="w-4 h-4" /> },
    { id: "files", ar: "الملفات", en: "Files", icon: <Folder className="w-4 h-4" /> },
    { id: "settings", ar: "الإعدادات", en: "Prefs", icon: <Sliders className="w-4 h-4" /> },
  ];

  return (
    <div
      dir={isArabic ? "rtl" : "ltr"}
      className={`min-h-screen relative overflow-x-hidden transition-colors duration-500 ${
        darkMode ? "bg-[#0B0D12] text-[#F5F7FF]" : "bg-[#EFF4FC] text-[#0F172A]"
      }`}
    >
      {/* Full Studio Animated Mesh Backdrop */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div
          className="animate-blob-a absolute -top-24 -start-20 w-[440px] h-[440px] rounded-full blur-[120px] opacity-30 transition-colors duration-700"
          style={{ backgroundColor: theme.c1 }}
        />
        <div
          className="animate-blob-b absolute top-1/4 -end-24 w-[460px] h-[460px] rounded-full blur-[130px] opacity-25 transition-colors duration-700"
          style={{ backgroundColor: artworkTint || theme.c2 }}
        />
        <div
          className="animate-blob-c absolute -bottom-24 start-1/3 w-[420px] h-[420px] rounded-full blur-[125px] opacity-25 transition-colors duration-700"
          style={{ backgroundColor: theme.c3 }}
        />
      </div>

      {/* Main Studio Layout: Android 15 Flagship Phone Showcase + JP PROJ Explorer */}
      <main className="relative z-10 max-w-[1380px] mx-auto px-4 py-6 lg:py-8 grid lg:grid-cols-[410px_1fr] gap-8 items-start">
        {/* LEFT/START: Pixel-Faithful Android 15 Interactive Phone Frame */}
        <div className="flex flex-col items-center lg:sticky lg:top-6">
          <div
            className={`relative w-full max-w-[392px] h-[806px] rounded-[50px] p-[11px] border-2 shadow-[0_30px_90px_rgba(0,0,0,0.65)] ${
              darkMode
                ? "bg-[#151821] border-white/15"
                : "bg-[#1E2430] border-slate-300"
            }`}
          >
            {/* Inner Phone Screen Container */}
            <div
              className={`relative w-full h-full rounded-[40px] overflow-hidden flex flex-col transition-colors duration-500 ${
                darkMode ? "bg-[#0B0D12] text-[#F5F7FF]" : "bg-[#F3F6FC] text-[#0F172A]"
              }`}
            >
              {/* AGSL-Style Animated Mesh Inside Phone Screen */}
              <div className="absolute inset-0 pointer-events-none overflow-hidden">
                <div
                  className="animate-blob-a absolute -top-12 -start-10 w-56 h-56 rounded-full blur-[70px] opacity-38 transition-colors duration-700"
                  style={{ backgroundColor: theme.c1 }}
                />
                <div
                  className="animate-blob-b absolute top-44 -end-12 w-56 h-56 rounded-full blur-[72px] opacity-34 transition-colors duration-700"
                  style={{ backgroundColor: artworkTint || theme.c2 }}
                />
                <div
                  className="animate-blob-c absolute bottom-12 start-10 w-52 h-52 rounded-full blur-[75px] opacity-30 transition-colors duration-700"
                  style={{ backgroundColor: theme.c3 }}
                />
              </div>

              {/* Android 15 Edge-to-Edge Status Bar + Punch-Hole Camera */}
              <div
                dir="ltr"
                className="relative z-20 px-6 pt-3 pb-1.5 flex items-center justify-between text-[11px] font-mono-metric font-semibold"
              >
                <span>09:41</span>
                <div className="w-20 h-5 rounded-full bg-black/90 border border-white/10 flex items-center justify-end px-2">
                  <span className="w-2 h-2 rounded-full bg-[#1E293B] border border-blue-400/30" />
                </div>
                <div className="flex items-center gap-1.5">
                  <Signal className="w-3 h-3" />
                  <Wifi className="w-3 h-3" />
                  <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
                </div>
              </div>

              {/* Live In-App Glass Toast */}
              {toastMsg && (
                <div className="absolute top-12 inset-x-4 z-50 aurora-glass bg-black/75 border border-white/20 text-white text-[10px] font-semibold px-3 py-2 rounded-2xl shadow-xl text-center animate-stream-reveal">
                  {toastMsg}
                </div>
              )}

              {/* Active Screen Content OR Onboarding Overlay */}
              <div className="relative z-10 flex-1 overflow-hidden">
                {showOnboarding ? (
                  <div className="h-full p-5 flex items-center justify-center">
                    <div
                      className={`aurora-glass border rounded-[32px] p-6 space-y-4 ${
                        darkMode ? "bg-[#131722]/85 border-white/20" : "bg-white/90 border-blue-200"
                      }`}
                      style={{ boxShadow: `0 20px 50px ${theme.c1}30` }}
                    >
                      <div
                        className="w-14 h-14 rounded-[20px] flex items-center justify-center text-white shadow-xl"
                        style={{ background: `linear-gradient(135deg, ${theme.c1}, ${theme.c2}, ${theme.c3})` }}
                      >
                        <Sparkles className="w-7 h-7" />
                      </div>
                      <h2
                        className="text-[26px] font-extrabold bg-clip-text text-transparent"
                        style={{ backgroundImage: `linear-gradient(90deg, ${theme.c1}, ${theme.c2}, ${theme.c3})` }}
                      >
                        Aurora Get
                      </h2>
                      <p className="text-[13px] leading-relaxed animate-stream-reveal opacity-90">
                        {isArabic
                          ? "محرك تحميل مجزأ حتى 32 اتصالًا مع Work-Stealing، تحليل متوازٍ لـ 1800+ موقع، متصفح صيد وحجب إعلانات، وتصغير ذكي يحافظ على الجودة."
                          : "32-connection Work-Stealing engine, parallel analyzer for 1800+ sites, AdBlock sniffer browser, and SSIM-verified smart compressor."}
                      </p>
                      <p className="text-[10px] opacity-65 leading-relaxed">
                        {isArabic
                          ? "المسؤولية تقع بالكامل على المستخدم في احترام حقوق النشر. لا يوجد تجاوز DRM أو Paywalls."
                          : "Users are solely responsible for respecting copyright laws. Zero DRM or paywall bypass."}
                      </p>
                      <button
                        type="button"
                        onClick={() => setShowOnboarding(false)}
                        className="w-full py-3 rounded-[20px] text-white font-bold text-[13px] shadow-lg transition active:scale-95"
                        style={{ background: `linear-gradient(90deg, ${theme.c1}, ${theme.c2}, ${theme.c3})` }}
                      >
                        {isArabic ? "ابدأ التجربة الزجاجية" : "Launch Aurora Get"}
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    {activeTab === "home" && (
                      <HomeScreenView
                        isArabic={isArabic}
                        darkMode={darkMode}
                        theme={theme}
                        onArtworkTintChange={setArtworkTint}
                        onStartDownload={handleStartDownload}
                        onConvertFormat={(sample, fmt) => {
                          setToolsFileName(`${sample.fileName}.${fmt.ext.toLowerCase()}`);
                          setToolsSubTab("converter");
                          setActiveTab("tools");
                        }}
                        onOpenBrowserSniffer={(url) => {
                          setBrowserInitialUrl(url);
                          setActiveTab("browser");
                        }}
                      />
                    )}
                    {activeTab === "downloads" && (
                      <DownloadsScreenView
                        downloads={downloads}
                        isArabic={isArabic}
                        darkMode={darkMode}
                        theme={theme}
                        onTogglePause={(id) =>
                          setDownloads((prev) =>
                            prev.map((d) =>
                              d.id === id
                                ? {
                                    ...d,
                                    status: d.status === "RUNNING" ? "PAUSED" : "RUNNING",
                                    speedBytesPerSec: d.status === "RUNNING" ? 0 : d.connections * 1_500_000,
                                  }
                                : d
                            )
                          )
                        }
                        onDelete={(id) => setDownloads((prev) => prev.filter((d) => d.id !== id))}
                        onCompressTask={(task) => {
                          setToolsFileName(task.fileName);
                          setToolsSubTab("compressor");
                          setActiveTab("tools");
                        }}
                        onConvertTask={(task) => {
                          setToolsFileName(task.fileName);
                          setToolsSubTab("converter");
                          setActiveTab("tools");
                        }}
                      />
                    )}
                    {activeTab === "browser" && (
                      <BrowserScreenView
                        initialUrl={browserInitialUrl}
                        isArabic={isArabic}
                        darkMode={darkMode}
                        theme={theme}
                        onHandoffToEngine={handleBrowserHandoff}
                      />
                    )}
                    {activeTab === "tools" && (
                      <ToolsScreenView
                        initialSubTab={toolsSubTab}
                        targetFileName={toolsFileName}
                        isArabic={isArabic}
                        darkMode={darkMode}
                        theme={theme}
                      />
                    )}
                    {activeTab === "files" && (
                      <FilesAndPlayerView isArabic={isArabic} darkMode={darkMode} theme={theme} />
                    )}
                    {activeTab === "settings" && (
                      <SettingsScreenView
                        themeId={themeId}
                        darkMode={darkMode}
                        isArabic={isArabic}
                        connections={connections}
                        onChangeTheme={setThemeId}
                        onToggleDark={() => setDarkMode((d) => !d)}
                        onToggleLang={() => setIsArabic((a) => !a)}
                        onChangeConnections={setConnections}
                        onReplayOnboarding={() => setShowOnboarding(true)}
                      />
                    )}
                  </>
                )}
              </div>

              {/* Floating Glass Navigation Dock (Strictly Custom — NOT Material NavigationBar) */}
              {!showOnboarding && (
                <div className="absolute bottom-3 inset-x-3 z-30">
                  <nav
                    className={`aurora-glass border rounded-[28px] px-2 py-1.5 flex items-center justify-between shadow-2xl ${
                      darkMode
                        ? "bg-[#131722]/86 border-white/18"
                        : "bg-white/88 border-white shadow-[0_12px_30px_rgba(66,133,244,0.16)]"
                    }`}
                  >
                    {dockItems.map((item) => {
                      const selected = activeTab === item.id;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setActiveTab(item.id)}
                          className={`relative rounded-full px-2.5 py-2 flex items-center gap-1.5 transition-all duration-300 active:scale-90 ${
                            selected ? "scale-[1.03]" : "opacity-70 hover:opacity-100"
                          }`}
                          style={
                            selected
                              ? {
                                  background: `linear-gradient(120deg, ${theme.c1}38, ${theme.c2}38)`,
                                  color: darkMode ? "#FFFFFF" : "#0F172A",
                                }
                              : undefined
                          }
                        >
                          <span style={{ color: selected ? theme.c1 : undefined }}>{item.icon}</span>
                          {selected && (
                            <span className="text-[10px] font-bold whitespace-nowrap">
                              {isArabic ? item.ar : item.en}
                            </span>
                          )}
                          {item.badge && item.badge > 0 ? (
                            <span
                              className="absolute -top-0.5 -end-0.5 min-w-[15px] h-[15px] px-1 rounded-full text-[9px] font-mono-metric font-bold text-white flex items-center justify-center"
                              style={{ backgroundColor: theme.c3 }}
                            >
                              {item.badge}
                            </span>
                          ) : null}
                        </button>
                      );
                    })}
                  </nav>
                  {/* Android Gesture Bar */}
                  <div className="w-24 h-1 rounded-full bg-white/30 mx-auto mt-1.5" />
                </div>
              )}
            </div>
          </div>
          <span className="mt-3 text-[11px] font-mono-metric opacity-65">
            Aurora Get • Interactive Android 15 Preview (Zero Material UI)
          </span>
        </div>

        {/* RIGHT/END: Full Android Project Explorer (JP PROJ/) + Controls + Acceptance Checklist */}
        <ProjectInspectorPanel
          isArabic={isArabic}
          darkMode={darkMode}
          themeId={themeId}
          theme={theme}
          onSelectTheme={setThemeId}
          onToggleDark={() => setDarkMode((d) => !d)}
          onToggleLang={() => setIsArabic((a) => !a)}
        />
      </main>
    </div>
  );
}

export default App;
