# Aurora Get — Android Multi-Module Architecture & Verification Guide

## 1. المخطط المعماري للوحدات (Module Dependency Graph)

```
                              ┌───────────────┐
                              │     :app      │
                              │ (Nav/Widget/  │
                              │  Tile/Onboard)│
                              └───────┬───────┘
        ┌─────────────┬───────────────┼───────────────┬──────────────┐
        ▼             ▼               ▼               ▼              ▼
  :feature:home  :feature:downloads :feature:browser :feature:converter :feature:compressor
  :feature:files :feature:player    :feature:settings :feature:analyzer
        │             │               │               │              │
        └─────────────┴───────────────┼───────────────┴──────────────┘
                                      ▼
            ┌─────────────────────────┼─────────────────────────┐
            ▼                         ▼                         ▼
    :engine:downloader       :engine:extractors          :engine:media
  (Segmented 8-32 + WS,    (yt-dlp + aria2c + Fast     (FFmpeg StreamCopy,
   HLS/DASH + FG Service)   Native + Jsoup Fallback)    Smart Compressor)
            │                         │                         │
            └─────────────────────────┼─────────────────────────┘
                                      ▼
        ┌───────────────────┬─────────┴─────────┬────────────────────┐
        ▼                   ▼                   ▼                    ▼
 :core:designsystem   :core:network      :core:database        :core:common
 (Aurora Glass UI,    (OkHttp HTTP/2 +   (Room + Segments +   (ExactByteSize,
  AGSL Shader, Zero   Cronet HTTP/3 +    Cache + Vault +      UrlNormalizer,
  Material Design!)   ExactSize + DoH)   DataStore Prefs)     HashVerifier)
```

## 2. تدفق البيانات (MVI + Parallel Flow Pipeline)

1. **الإدخال:** لصق رابط / الحافظة التلقائية / Share Intent / متصفح داخلي Sniffer.
2. **التحليل المتوازي (`:feature:analyzer`):**
   - `Stage 0 (< 50ms)`: تطبيع الرابط، استخراج النطاق، التحقق من الكاش.
   - `Stage 1 (< 300ms)`: `HEAD` / `Range: bytes=0-0` + OpenGraph + Favicon عالي الدقة + Preconnect TCP/TLS.
   - `Stage 2 (< 1.5s)`: المستخرجات الأصلية السريعة (YouTube / TikTok / Instagram / X / Reddit / Direct / HLS / DASH).
   - `Stage 3 (≤ 4s)`: محرك `yt-dlp` الكامل عبر `youtubedl-android` مع `aria2c`.
   - `Stage 4 (Fallback)`: `Jsoup` + Regex أو فتح المتصفح الداخلي المزوّد بـ `MediaSniffer` و`AdBlock` ومعالجة Cloudflare المشروعة.
3. **الأزرار الأربعة الذكية:** يُبنى كل زر ديناميكيًا فقط إذا احتوت قائمته على عنصر واحد فعلي على الأقل (`Audio`, `Images`, `Video`, `Files`).
4. **التحميل الفائق (`:engine:downloader`):** تجزئة ديناميكية 8–32 اتصالاً مع Work-Stealing، وتخصيص مسبق للملف، وكتابة مباشرة عبر `FileChannel`، وحفظ حالة كل جزء في Room لاستكمال مضمون بعد إغلاق التطبيق أو إعادة تشغيل الجهاز.

---

## 3. قائمة البنود التي تحتاج تحقق قبل النشر (`// VERIFY:`)

1. **`libs.versions.toml` — `dev.chrisbanes.haze:haze:1.3.1`**: تحقق من أحدث إصدار متوافق مع Compose BOM `2025.02.00`.
2. **`libs.versions.toml` — `com.composables:composeunstyled:1.20.1`**: تحقق من أحدث إصدار على Maven Central.
3. **`libs.versions.toml` — `io.github.junkfood02.youtubedl-android:0.17.2`**: هذا هو الفرع المُصان والمحدث باستمرار من `yausername/youtubedl-android` على Maven Central (مع `library` و`ffmpeg` و`aria2c`). يمكن التبديل إلى `com.github.yausername.youtubedl-android` عبر JitPack عند الحاجة.
4. **`libs.versions.toml` — `org.chromium.net:cronet-embedded:119.6045.31`**: استُخدمت النسخة مفتوحة المصدر بدون خدمات Google Play لضمان الخصوصية الكاملة؛ تحقق من أحدث نسخة Cronet مستقرة على Maven Central.
5. **NDK Native Bridges (`adblock-rust`, `mozjpeg`, `oxipng`, `zopfli`, `libwebp`, `libavif`, `MuPDF/PdfBox-Android`)**:
   - في `:feature:browser` توجد طبقة JNI جاهزة `AdBlockRustNativeBridge` مع محرك Kotlin فوري متوافق مع EasyList/EasyPrivacy يعمل كبديل فوري حتى يتم تجميع مكتبة `libadblock_rust.so` عبر Cargo-NDK في `src/main/jniLibs/`.
   - في `:engine:media` توجد طبقة `NativeCompressorJniBridge` لـ `mozjpeg`/`oxipng`/`zopfli` مع تنفيذ فعلي كامل لـ FFmpeg و`MediaCodec` و`Zopfli/Deflate` و`Bitmap` كبديل عملي جاهز للبناء الفوري.
   - **ملحوظة قانونية وتقنية حول FFmpegKit**: مكتبة `arthenica/ffmpeg-kit` الرسمية مؤرشفة (Archived). لذلك يعتمد المشروع على حزمة FFmpeg المدمجة ضمن `youtubedl-android:ffmpeg` (أو فرع مُصان مثل `ffmpeg-kit-community`) بدلاً من المكتبة المؤرشفة.
6. **الخطوط (`IBM Plex Sans Arabic` و`Plus Jakarta Sans`)**: أضف ملفات `.ttf` مفتوحة الترخيص (SIL OFL) داخل `core/designsystem/src/main/res/font/`. التطبيق يعمل تلقائيًا على `FontFamily.SansSerif` كبديل آمن إن لم تُنسخ الخطوط بعد.

---

## 4. خطوات البناء والتشغيل والتحقق

```bash
cd "JP PROJ"

# 1. التحقق الصارم من عدم وجود أي مكتبة Material (مباشرة أو غير مباشرة)
./gradlew verifyNoMaterialDependencies

# 2. فحص شجرة التبعيات للتأكيد اليدوي
./gradlew :app:dependencies --configuration debugRuntimeClasspath | grep -i material || echo "CLEAN: Zero Material dependencies!"

# 3. تشغيل الاختبارات الوحدوية (محرك التحميل + الحجم الدقيق + التحليل المتوازي)
./gradlew testDebugUnitTest

# 4. بناء حزمة Debug APK
./gradlew assembleDebug
```
