package com.auroraget.engine.downloader

import com.auroraget.core.database.DownloadSegmentDao
import com.auroraget.core.database.DownloadSegmentEntity
import com.auroraget.core.database.DownloadTaskDao
import com.auroraget.core.database.DownloadTaskEntity
import com.auroraget.core.network.AuroraNetworkFactory
import com.auroraget.core.network.ExactFileSizeResolver
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

/**
 * Callback used when a signed CDN URL expires mid-download (HTTP 403/410) so the extractor
 * can transparently refresh the direct media URL without losing downloaded segments.
 */
fun interface ExpiredUrlRefresher {
    suspend fun refreshDirectUrl(sourceUrl: String, previousDirectUrl: String): String?
}

data class ActiveDownloadTelemetry(
    val taskId: String,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val speedBytesPerSec: Long,
    val activeConnections: Int,
    val sparklineSamples: List<Float>,
    val etaSeconds: Long
)

/**
 * Token-bucket style thread-safe adaptive speed limiter (bytes/sec). 0 = unlimited.
 */
class SpeedLimiter(initialLimitBytesPerSec: Long = 0L) {
    @Volatile
    var limitBytesPerSec: Long = initialLimitBytesPerSec
    private val mutex = Mutex()
    private var windowStartNs = System.nanoTime()
    private var bytesInWindow = 0L

    suspend fun acquire(bytes: Int) {
        val limit = limitBytesPerSec
        if (limit <= 0L || bytes <= 0) return
        val sleepMs = mutex.withLock {
            val now = System.nanoTime()
            val elapsedNs = now - windowStartNs
            if (elapsedNs >= 1_000_000_000L) {
                windowStartNs = now
                bytesInWindow = bytes.toLong()
                0L
            } else {
                bytesInWindow += bytes
                if (bytesInWindow > limit) {
                    val over = bytesInWindow - limit
                    ((over.toDouble() / limit) * 1000.0).toLong().coerceAtMost(250L)
                } else {
                    0L
                }
            }
        }
        if (sleepMs > 0L) delay(sleepMs)
    }
}

/**
 * High-speed Segmented Parallel Download Engine:
 * - Dynamic 8..32 parallel HTTP Range connections
 * - Work-Stealing: finished workers dynamically split the slowest active remaining segment
 * - FileChannel direct positional writing with pre-allocated storage and 512 KiB buffers
 * - Persistent Room segment state for guaranteed Pause/Resume across app kills & device reboots
 * - ETag / If-Range / Last-Modified integrity verification before resuming
 * - Exponential Backoff + Jitter retries + Mirror fallback + 403/410 auto link refresh
 */
class SegmentedDownloadEngine(
    private val okHttpClient: OkHttpClient,
    private val taskDao: DownloadTaskDao,
    private val segmentDao: DownloadSegmentDao,
    private val sizeResolver: ExactFileSizeResolver,
    private val urlRefresher: ExpiredUrlRefresher? = null,
    private val speedLimiter: SpeedLimiter = SpeedLimiter()
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val runningJobs = ConcurrentHashMap<String, Job>()
    private val _telemetry = MutableStateFlow<Map<String, ActiveDownloadTelemetry>>(emptyMap())
    val telemetry: StateFlow<Map<String, ActiveDownloadTelemetry>> = _telemetry.asStateFlow()

    companion object {
        const val BUFFER_SIZE_BYTES = 512 * 1024 // 512 KiB high-throughput buffer
        const val MIN_STEALABLE_CHUNK = 1024L * 1024L * 2L // 2 MiB threshold for Work-Stealing
        const val MAX_RETRY_ATTEMPTS = 6
    }

    fun startOrResume(taskId: String, requestedConnections: Int = 16) {
        if (runningJobs[taskId]?.isActive == true) return
        val job = scope.launch {
            executeTask(taskId, requestedConnections.coerceIn(8, 32))
        }
        runningJobs[taskId] = job
    }

    suspend fun pause(taskId: String) {
        runningJobs.remove(taskId)?.cancel()
        taskDao.updateStatus(taskId, "PAUSED")
    }

    suspend fun cancel(taskId: String, deletePartialFile: Boolean = false) {
        runningJobs.remove(taskId)?.cancel()
        val task = taskDao.getTask(taskId)
        taskDao.updateStatus(taskId, "CANCELED")
        if (deletePartialFile && task != null) {
            runCatching { File(task.outputPath).delete() }
            segmentDao.deleteSegments(taskId)
        }
    }

    private data class MutableSegmentState(
        val segmentId: String,
        val index: Int,
        val startOffset: Long,
        @Volatile var endOffset: Long,
        val currentOffset: AtomicLong,
        @Volatile var completed: Boolean
    ) {
        fun remainingBytes(): Long = (endOffset - currentOffset.get() + 1L).coerceAtLeast(0L)
    }

    private suspend fun executeTask(taskId: String, targetConnections: Int) = withContext(Dispatchers.IO) {
        var task = taskDao.getTask(taskId) ?: return@withContext
        val headers = runCatching { json.decodeFromString<Map<String, String>>(task.headersJson) }
            .getOrDefault(emptyMap())

        taskDao.updateStatus(taskId, "RUNNING")

        try {
            val probe = sizeResolver.probeDirectUrl(task.directUrl, headers, task.totalBytes.takeIf { it > 0L })
            val totalBytes = if (probe.sizeInfo.isKnown) probe.sizeInfo.bytes else task.totalBytes
            val supportsRanges = probe.supportsRanges && totalBytes > 0L

            // Validate ETag/Last-Modified integrity on Resume
            val existingSegments = segmentDao.getSegments(taskId)
            val remoteChanged = existingSegments.isNotEmpty() &&
                ((!task.eTag.isNullOrBlank() && !probe.eTag.isNullOrBlank() && task.eTag != probe.eTag) ||
                    (!task.lastModified.isNullOrBlank() && !probe.lastModified.isNullOrBlank() && task.lastModified != probe.lastModified))

            if (remoteChanged) {
                Timber.w("Remote file changed (ETag/Last-Modified mismatch) for %s; resetting segments", taskId)
                segmentDao.deleteSegments(taskId)
            }

            task = task.copy(
                directUrl = probe.finalUrl,
                totalBytes = totalBytes,
                isSizeExact = probe.sizeInfo.precision == com.auroraget.core.common.SizePrecision.EXACT,
                supportsRanges = supportsRanges,
                eTag = probe.eTag ?: task.eTag,
                lastModified = probe.lastModified ?: task.lastModified,
                status = "RUNNING"
            )
            taskDao.upsertTask(task)

            val outFile = File(task.outputPath).apply { parentFile?.mkdirs() }

            if (!supportsRanges || totalBytes < MIN_STEALABLE_CHUNK) {
                downloadSingleStream(task, outFile, headers)
            } else {
                downloadSegmentedWithWorkStealing(task, outFile, headers, targetConnections, remoteChanged)
            }

            // Optional SHA-256 verification
            if (!task.expectedSha256.isNullOrBlank()) {
                val ok = com.auroraget.core.common.FileHashVerifier.verify(
                    outFile,
                    task.expectedSha256,
                    com.auroraget.core.common.HashAlgorithm.SHA256
                )
                if (!ok) throw IOException("SHA-256 integrity verification failed")
            }

            taskDao.updateStatus(taskId, "COMPLETED")
            _telemetry.value = _telemetry.value - taskId
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            Timber.e(t, "Download failed for task %s", taskId)
            taskDao.updateStatus(taskId, "FAILED", t.message ?: "Download error")
        } finally {
            runningJobs.remove(taskId)
        }
    }

    private suspend fun downloadSegmentedWithWorkStealing(
        initialTask: DownloadTaskEntity,
        outFile: File,
        headers: Map<String, String>,
        targetConnections: Int,
        resetSegments: Boolean
    ) = coroutineScope {
        val totalBytes = initialTask.totalBytes
        // Pre-allocate disk space so OS reduces fragmentation and FileChannel seeks cleanly
        RandomAccessFile(outFile, "rw").use { raf ->
            if (raf.length() != totalBytes) {
                raf.setLength(totalBytes)
            }
        }

        val segmentMutex = Mutex()
        val persisted = if (resetSegments) emptyList() else segmentDao.getSegments(initialTask.id)
        val optimalConnections = computeDynamicConnections(totalBytes, targetConnections)

        val segments: MutableList<MutableSegmentState> = if (persisted.isNotEmpty()) {
            persisted.map {
                MutableSegmentState(
                    segmentId = it.segmentId,
                    index = it.segmentIndex,
                    startOffset = it.startOffset,
                    endOffset = it.endOffset,
                    currentOffset = AtomicLong(it.currentOffset),
                    completed = it.completed
                )
            }.toMutableList()
        } else {
            val chunkSize = totalBytes / optimalConnections
            val created = (0 until optimalConnections).map { idx ->
                val start = idx * chunkSize
                val end = if (idx == optimalConnections - 1) totalBytes - 1L else ((idx + 1) * chunkSize - 1L)
                MutableSegmentState(
                    segmentId = "${initialTask.id}_seg_$idx",
                    index = idx,
                    startOffset = start,
                    endOffset = end,
                    currentOffset = AtomicLong(start),
                    completed = false
                )
            }.toMutableList()
            segmentDao.upsertSegments(created.map { it.toEntity(initialTask.id) })
            created
        }

        val downloadedCounter = AtomicLong(
            segments.sumOf { (it.currentOffset.get() - it.startOffset).coerceAtLeast(0L) }
        )
        val activeWorkerCount = AtomicLong(0L)
        @Volatile var activeUrl = initialTask.directUrl

        // Telemetry reporter loop (updates Room & Sparkline every 350ms)
        val telemetryJob = launch {
            var lastBytes = downloadedCounter.get()
            var lastTime = System.currentTimeMillis()
            val sparkline = ArrayDeque<Float>(24)
            while (isActive) {
                delay(350L)
                val now = System.currentTimeMillis()
                val current = downloadedCounter.get()
                val dtSec = ((now - lastTime).coerceAtLeast(1L)) / 1000.0
                val speed = ((current - lastBytes).coerceAtLeast(0L) / dtSec).toLong()
                lastBytes = current
                lastTime = now

                val mbps = speed / (1024f * 1024f)
                if (sparkline.size >= 24) sparkline.removeFirst()
                sparkline.addLast(mbps)

                val remaining = (totalBytes - current).coerceAtLeast(0L)
                val eta = if (speed > 0L) remaining / speed else -1L
                val conns = activeWorkerCount.get().toInt().coerceAtLeast(1)

                taskDao.updateProgress(initialTask.id, current, speed, conns)
                _telemetry.value = _telemetry.value + (
                    initialTask.id to ActiveDownloadTelemetry(
                        taskId = initialTask.id,
                        downloadedBytes = current,
                        totalBytes = totalBytes,
                        speedBytesPerSec = speed,
                        activeConnections = conns,
                        sparklineSamples = sparkline.toList(),
                        etaSeconds = eta
                    )
                    )
            }
        }

        try {
            val workerQueue = ArrayDeque<MutableSegmentState>()
            segments.filter { !it.completed }.forEach { workerQueue.addLast(it) }

            val workers = (0 until optimalConnections).map {
                async(Dispatchers.IO) {
                    while (isActive) {
                        val segment = segmentMutex.withLock {
                            if (workerQueue.isNotEmpty()) {
                                workerQueue.removeFirst()
                            } else {
                                // Work-Stealing: split the largest active remaining segment in half!
                                stealHalfOfSlowestSegment(initialTask.id, segments)
                            }
                        } ?: break

                        activeWorkerCount.incrementAndGet()
                        try {
                            downloadSegmentLoop(
                                task = initialTask,
                                segment = segment,
                                outFile = outFile,
                                headers = headers,
                                currentUrlProvider = { activeUrl },
                                onUrlRefreshed = { refreshed -> activeUrl = refreshed },
                                downloadedCounter = downloadedCounter
                            )
                        } finally {
                            activeWorkerCount.decrementAndGet()
                        }
                    }
                }
            }
            workers.awaitAll()
        } finally {
            telemetryJob.cancel()
        }
    }

    /**
     * Work-Stealing Core: locates the segment with the largest remaining byte span (> 2 MiB),
     * shrinks its endOffset to the midpoint, and spawns a fresh segment for the upper half.
     */
    private suspend fun stealHalfOfSlowestSegment(
        taskId: String,
        segments: MutableList<MutableSegmentState>
    ): MutableSegmentState? {
        val candidate = segments
            .filter { !it.completed && it.remainingBytes() >= MIN_STEALABLE_CHUNK * 2 }
            .maxByOrNull { it.remainingBytes() }
            ?: return null

        val currentPos = candidate.currentOffset.get()
        val oldEnd = candidate.endOffset
        val mid = currentPos + (oldEnd - currentPos) / 2L
        if (mid <= currentPos || mid >= oldEnd) return null

        candidate.endOffset = mid
        val stolen = MutableSegmentState(
            segmentId = "${taskId}_steal_${UUID.randomUUID().toString().take(8)}",
            index = segments.size,
            startOffset = mid + 1L,
            endOffset = oldEnd,
            currentOffset = AtomicLong(mid + 1L),
            completed = false
        )
        segments.add(stolen)
        segmentDao.upsertSegments(listOf(candidate.toEntity(taskId), stolen.toEntity(taskId)))
        Timber.d("Work-Stealing activated for %s: split %d..%d -> stole %d..%d", taskId, currentPos, oldEnd, mid + 1L, oldEnd)
        return stolen
    }

    private suspend fun downloadSegmentLoop(
        task: DownloadTaskEntity,
        segment: MutableSegmentState,
        outFile: File,
        headers: Map<String, String>,
        currentUrlProvider: () -> String,
        onUrlRefreshed: (String) -> Unit,
        downloadedCounter: AtomicLong
    ) {
        var attempt = 0
        var lastPersistTime = System.currentTimeMillis()
        val byteArray = ByteArray(BUFFER_SIZE_BYTES)

        while (segment.currentOffset.get() <= segment.endOffset) {
            val start = segment.currentOffset.get()
            val end = segment.endOffset
            val urlToUse = if (attempt >= 3 && !task.backupMirrorUrl.isNullOrBlank()) {
                task.backupMirrorUrl
            } else {
                currentUrlProvider()
            }

            try {
                val reqBuilder = Request.Builder()
                    .url(urlToUse)
                    .header("Range", "bytes=$start-$end")
                    .header("User-Agent", headers["User-Agent"] ?: AuroraNetworkFactory.DEFAULT_BROWSER_UA)
                if (!task.eTag.isNullOrBlank()) {
                    reqBuilder.header("If-Range", task.eTag)
                }
                headers.forEach { (k, v) ->
                    if (!k.equals("Range", ignoreCase = true)) reqBuilder.header(k, v)
                }

                okHttpClient.newCall(reqBuilder.build()).execute().use { response ->
                    if (response.code == 403 || response.code == 410) {
                        val refreshed = urlRefresher?.refreshDirectUrl(task.sourceUrl, urlToUse)
                        if (!refreshed.isNullOrBlank()) {
                            onUrlRefreshed(refreshed)
                            throw IOException("Expired CDN URL refreshed (HTTP ${response.code})")
                        }
                    }
                    if (!response.isSuccessful && response.code != 206) {
                        throw IOException("Unexpected HTTP ${response.code} for segment ${segment.index}")
                    }
                    val stream = response.body?.byteStream() ?: throw IOException("Empty response stream")
                    RandomAccessFile(outFile, "rw").use { raf ->
                        val channel = raf.channel
                        var writePos = start
                        while (writePos <= segment.endOffset) {
                            val remaining = (segment.endOffset - writePos + 1L).toInt().coerceAtMost(byteArray.size)
                            val read = stream.read(byteArray, 0, remaining)
                            if (read <= 0) break

                            speedLimiter.acquire(read)
                            val buf = ByteBuffer.wrap(byteArray, 0, read)
                            while (buf.hasRemaining()) {
                                writePos += channel.write(buf, writePos)
                            }
                            segment.currentOffset.set(writePos)
                            downloadedCounter.addAndGet(read.toLong())

                            val now = System.currentTimeMillis()
                            if (now - lastPersistTime >= 600L) {
                                lastPersistTime = now
                                segmentDao.updateSegmentProgress(segment.segmentId, writePos, false)
                            }
                        }
                    }
                }
                if (segment.currentOffset.get() > segment.endOffset) {
                    segment.completed = true
                    segmentDao.updateSegmentProgress(segment.segmentId, segment.currentOffset.get(), true)
                    return
                }
            } catch (ce: CancellationException) {
                segmentDao.updateSegmentProgress(segment.segmentId, segment.currentOffset.get(), false)
                throw ce
            } catch (io: IOException) {
                attempt++
                segmentDao.updateSegmentProgress(segment.segmentId, segment.currentOffset.get(), false)
                if (attempt >= MAX_RETRY_ATTEMPTS) throw io
                // Exponential Backoff + Jitter
                val baseDelayMs = (500.0 * 2.0.pow(attempt - 1)).toLong().coerceAtMost(15_000L)
                val jitterMs = Random.nextLong(0L, 450L)
                delay(baseDelayMs + jitterMs)
            }
        }
    }

    private suspend fun downloadSingleStream(
        task: DownloadTaskEntity,
        outFile: File,
        headers: Map<String, String>
    ) {
        val existingBytes = if (outFile.exists() && task.supportsRanges) outFile.length() else 0L
        val reqBuilder = Request.Builder()
            .url(task.directUrl)
            .header("User-Agent", headers["User-Agent"] ?: AuroraNetworkFactory.DEFAULT_BROWSER_UA)
        if (existingBytes > 0L) reqBuilder.header("Range", "bytes=$existingBytes-")
        headers.forEach { (k, v) -> reqBuilder.header(k, v) }

        okHttpClient.newCall(reqBuilder.build()).execute().use { resp ->
            if (!resp.isSuccessful && resp.code != 206) {
                throw IOException("Single-stream HTTP ${resp.code}")
            }
            val append = resp.code == 206 && existingBytes > 0L
            val input = resp.body?.byteStream() ?: throw IOException("Empty body")
            RandomAccessFile(outFile, "rw").use { raf ->
                if (append) raf.seek(existingBytes) else raf.setLength(0L)
                val buf = ByteArray(BUFFER_SIZE_BYTES)
                var total = if (append) existingBytes else 0L
                var lastReport = System.currentTimeMillis()
                var lastBytes = total
                while (true) {
                    val read = input.read(buf)
                    if (read <= 0) break
                    speedLimiter.acquire(read)
                    raf.write(buf, 0, read)
                    total += read
                    val now = System.currentTimeMillis()
                    if (now - lastReport >= 350L) {
                        val speed = ((total - lastBytes) * 1000L) / (now - lastReport).coerceAtLeast(1L)
                        taskDao.updateProgress(task.id, total, speed, 1)
                        lastReport = now
                        lastBytes = total
                    }
                }
                taskDao.updateProgress(task.id, total, 0L, 1)
            }
        }
    }

    /**
     * Parallel HLS (.m3u8) / DASH (.mpd) segment downloader (up to 32 concurrent segment connections).
     * Returns ordered downloaded segment files ready for lossless FFmpeg '-c copy' muxing.
     */
    suspend fun downloadMediaStreamSegments(
        segmentUrls: List<String>,
        outputDir: File,
        headers: Map<String, String> = emptyMap(),
        parallelism: Int = 24,
        onSegmentCompleted: (completedCount: Int, totalCount: Int) -> Unit = { _, _ -> }
    ): List<File> = coroutineScope {
        outputDir.mkdirs()
        val gate = Semaphore(parallelism.coerceIn(4, 32))
        val done = AtomicLong(0L)

        segmentUrls.mapIndexed { idx, segUrl ->
            async(Dispatchers.IO) {
                gate.withPermit {
                    val out = File(outputDir, String.format("seg_%06d.ts", idx))
                    if (!out.exists() || out.length() == 0L) {
                        val req = Request.Builder().url(segUrl).apply {
                            headers.forEach { (k, v) -> header(k, v) }
                        }.build()
                        okHttpClient.newCall(req).execute().use { resp ->
                            if (!resp.isSuccessful) throw IOException("Segment $idx failed: HTTP ${resp.code}")
                            out.outputStream().use { fos ->
                                resp.body?.byteStream()?.copyTo(fos, BUFFER_SIZE_BYTES)
                            }
                        }
                    }
                    onSegmentCompleted(done.incrementAndGet().toInt(), segmentUrls.size)
                    out
                }
            }
        }.awaitAll()
    }

    fun computeDynamicConnections(totalBytes: Long, preferredMax: Int): Int {
        val clampedMax = preferredMax.coerceIn(8, 32)
        return when {
            totalBytes < 8L * 1024L * 1024L -> min(8, clampedMax)
            totalBytes < 50L * 1024L * 1024L -> min(16, clampedMax)
            totalBytes < 250L * 1024L * 1024L -> min(24, clampedMax)
            else -> clampedMax
        }
    }

    private fun MutableSegmentState.toEntity(taskId: String) = DownloadSegmentEntity(
        segmentId = segmentId,
        taskId = taskId,
        segmentIndex = index,
        startOffset = startOffset,
        endOffset = endOffset,
        currentOffset = currentOffset.get(),
        completed = completed
    )
}
