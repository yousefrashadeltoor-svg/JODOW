package com.auroraget.engine.downloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Foreground Service (foregroundServiceType="dataSync") keeping multi-segment downloads alive
 * with rich Notification controls (Pause / Resume / Cancel).
 */
class DownloadForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "aurora_downloads_channel"
        const val NOTIFICATION_ID = 4201
        const val ACTION_START = "com.auroraget.action.START"
        const val ACTION_PAUSE = "com.auroraget.action.PAUSE"
        const val ACTION_RESUME = "com.auroraget.action.RESUME"
        const val ACTION_CANCEL = "com.auroraget.action.CANCEL"
        const val EXTRA_TASK_ID = "extra_task_id"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_PROGRESS = "extra_progress"
        const val EXTRA_SPEED = "extra_speed"
        const val EXTRA_CONNS = "extra_conns"

        @Volatile
        var actionBridge: ((action: String, taskId: String) -> Unit)? = null

        fun buildStartIntent(
            context: Context,
            taskId: String,
            title: String,
            progressPercent: Int = 0,
            speedLabel: String = "",
            connections: Int = 16
        ): Intent = Intent(context, DownloadForegroundService::class.java).apply {
            action = ACTION_START
            putExtra(EXTRA_TASK_ID, taskId)
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_PROGRESS, progressPercent)
            putExtra(EXTRA_SPEED, speedLabel)
            putExtra(EXTRA_CONNS, connections)
        }
    }

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START
        val taskId = intent?.getStringExtra(EXTRA_TASK_ID).orEmpty()

        when (action) {
            ACTION_PAUSE, ACTION_RESUME, ACTION_CANCEL -> {
                if (taskId.isNotBlank()) actionBridge?.invoke(action, taskId)
                if (action == ACTION_CANCEL) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
                return START_NOT_STICKY
            }
            else -> {
                val title = intent?.getStringExtra(EXTRA_TITLE) ?: "Aurora Get"
                val progress = intent?.getIntExtra(EXTRA_PROGRESS, 0) ?: 0
                val speed = intent?.getStringExtra(EXTRA_SPEED).orEmpty()
                val conns = intent?.getIntExtra(EXTRA_CONNS, 16) ?: 16
                val notification = buildNotification(taskId, title, progress, speed, conns)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Aurora Downloads",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "High-speed segmented downloads progress and controls"
                setShowBadge(false)
            }
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(
        taskId: String,
        title: String,
        progress: Int,
        speed: String,
        connections: Int
    ): Notification {
        val pausePending = serviceActionPendingIntent(ACTION_PAUSE, taskId, 101)
        val resumePending = serviceActionPendingIntent(ACTION_RESUME, taskId, 102)
        val cancelPending = serviceActionPendingIntent(ACTION_CANCEL, taskId, 103)

        val detail = buildString {
            append("$progress%")
            if (speed.isNotBlank()) append(" • $speed")
            append(" • ${connections}x")
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(detail)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, progress.coerceIn(0, 100), progress <= 0)
            .addAction(0, "Pause", pausePending)
            .addAction(0, "Resume", resumePending)
            .addAction(0, "Cancel", cancelPending)
            .build()
    }

    private fun serviceActionPendingIntent(action: String, taskId: String, reqCode: Int): PendingIntent {
        val intent = Intent(this, DownloadForegroundService::class.java).apply {
            this.action = action
            putExtra(EXTRA_TASK_ID, taskId)
        }
        return PendingIntent.getService(
            this,
            reqCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}

/**
 * WorkManager Scheduler for delayed, Wi-Fi-only, Charging-only, and Battery-Not-Low downloads.
 */
class ScheduledDownloadWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val taskId = inputData.getString(DownloadForegroundService.EXTRA_TASK_ID) ?: return Result.failure()
        val title = inputData.getString(DownloadForegroundService.EXTRA_TITLE) ?: "Scheduled Download"
        val startIntent = DownloadForegroundService.buildStartIntent(applicationContext, taskId, title)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            applicationContext.startForegroundService(startIntent)
        } else {
            applicationContext.startService(startIntent)
        }
        DownloadForegroundService.actionBridge?.invoke(DownloadForegroundService.ACTION_RESUME, taskId)
        return Result.success()
    }

    companion object {
        fun enqueue(
            context: Context,
            taskId: String,
            title: String,
            delayMillis: Long,
            wifiOnly: Boolean,
            chargingOnly: Boolean,
            pauseOnLowBattery: Boolean
        ) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
                .setRequiresCharging(chargingOnly)
                .setRequiresBatteryNotLow(pauseOnLowBattery)
                .build()

            val data = Data.Builder()
                .putString(DownloadForegroundService.EXTRA_TASK_ID, taskId)
                .putString(DownloadForegroundService.EXTRA_TITLE, title)
                .build()

            val request = OneTimeWorkRequestBuilder<ScheduledDownloadWorker>()
                .setConstraints(constraints)
                .setInitialDelay(delayMillis.coerceAtLeast(0L), TimeUnit.MILLISECONDS)
                .setInputData(data)
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                "aurora_sched_$taskId",
                ExistingWorkPolicy.REPLACE,
                request
            )
        }
    }
}
