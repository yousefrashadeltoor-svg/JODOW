package com.auroraget.engine.extractors

import android.content.Context
import com.auroraget.core.common.FileSizeInfo
import com.auroraget.core.common.SizePrecision
import com.auroraget.core.common.UrlNormalizer
import com.auroraget.core.network.AuroraNetworkFactory
import com.auroraget.core.network.ExactFileSizeResolver
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import timber.log.Timber
import java.net.URI

@Serializable
enum class MediaBucket {
    AUDIO,
    IMAGE,
    VIDEO,
    FILE
}

@Serializable
data class ExtractedFormatItem(
    val formatId: String,
    val bucket: MediaBucket,
    val label: String,
    val extension: String,
    val resolution: String? = null,
    val fps: Int? = null,
    val bitrateKbps: Int? = null,
    val codec: String? = null,
    val isHdr: Boolean = false,
    val isWatermarkFree: Boolean = false,
    val requiresAudioMerge: Boolean = false,
    val pairedAudioUrl: String? = null,
    val pairedAudioSizeBytes: Long? = null,
    val directUrl: String,
    val sizeInfo: FileSizeInfo = FileSizeInfo(),
    val headers: Map<String, String> = emptyMap(),
    val isHlsOrDash: Boolean = false
)

@Serializable
data class ExtractedMediaBundle(
    val normalizedUrl: String,
    val finalUrl: String,
    val domain: String,
    val siteName: String,
    val faviconUrl: String?,
    val title: String,
    val suggestedFileName: String,
    val author: String? = null,
    val publishDate: String? = null,
    val durationSeconds: Long? = null,
    val thumbnailUrl: String? = null,
    val primaryTypeLabel: String = "FILE",
    val previewStreamUrl: String? = null,
    val audioItems: List<ExtractedFormatItem> = emptyList(),
    val imageItems: List<ExtractedFormatItem> = emptyList(),
    val videoItems: List<ExtractedFormatItem> = emptyList(),
    val fileItems: List<ExtractedFormatItem> = emptyList(),
    val stageReached: Int = 0,
    val requiresWebViewSniffer: Boolean = false
) {
    /** Guarantees Smart 4 Buttons ONLY include buckets with >= 1 actual item. */
    fun nonEmptyBuckets(): List<Pair<MediaBucket, List<ExtractedFormatItem>>> = buildList {
        if (audioItems.isNotEmpty()) add(MediaBucket.AUDIO to audioItems)
        if (imageItems.isNotEmpty()) add(MediaBucket.IMAGE to imageItems)
        if (videoItems.isNotEmpty()) add(MediaBucket.VIDEO to videoItems)
        if (fileItems.isNotEmpty()) add(MediaBucket.FILE to fileItems)
    }
}

/**
 * Resolves high-resolution site icons in priority order:
 * 1) apple-touch-icon -> 2) manifest icons -> 3) og:logo -> 4) /favicon.ico fallback
 */
class HighResFaviconResolver {
    fun resolveFromHtml(baseUrl: String, html: String): String {
        val doc = runCatching { Jsoup.parse(html, baseUrl) }.getOrNull()
        if (doc != null) {
            val apple = doc.select("link[rel*=apple-touch-icon]").firstOrNull()?.absUrl("href")
            if (!apple.isNullOrBlank()) return apple

            val ogLogo = doc.select("meta[property=og:logo], meta[itemprop=logo]").firstOrNull()?.absUrl("content")
            if (!ogLogo.isNullOrBlank()) return ogLogo

            val iconPng = doc.select("link[rel*=icon][type*=png], link[rel*=icon]").firstOrNull()?.absUrl("href")
            if (!iconPng.isNullOrBlank()) return iconPng
        }
        val host = UrlNormalizer.extractDomain(baseUrl)
        return "https://$host/favicon.ico"
    }
}

/**
 * Stage 2 Fast Path Extractors for direct links, HLS/DASH manifests, OpenGraph, and major sites
 * (YouTube / TikTok / Instagram / X / Reddit / Pinterest / Vimeo / SoundCloud / Telegram public).
 */
class NativeFastPathExtractor(
    private val client: OkHttpClient,
    private val sizeResolver: ExactFileSizeResolver
) {
    private val faviconResolver = HighResFaviconResolver()

    private val directFileExtensions = mapOf(
        "mp4" to MediaBucket.VIDEO, "mkv" to MediaBucket.VIDEO, "webm" to MediaBucket.VIDEO,
        "mov" to MediaBucket.VIDEO, "m3u8" to MediaBucket.VIDEO, "mpd" to MediaBucket.VIDEO,
        "mp3" to MediaBucket.AUDIO, "m4a" to MediaBucket.AUDIO, "opus" to MediaBucket.AUDIO,
        "flac" to MediaBucket.AUDIO, "wav" to MediaBucket.AUDIO, "ogg" to MediaBucket.AUDIO,
        "jpg" to MediaBucket.IMAGE, "jpeg" to MediaBucket.IMAGE, "png" to MediaBucket.IMAGE,
        "webp" to MediaBucket.IMAGE, "avif" to MediaBucket.IMAGE, "gif" to MediaBucket.IMAGE,
        "zip" to MediaBucket.FILE, "apk" to MediaBucket.FILE, "pdf" to MediaBucket.FILE,
        "iso" to MediaBucket.FILE, "7z" to MediaBucket.FILE, "rar" to MediaBucket.FILE,
        "tar" to MediaBucket.FILE, "gz" to MediaBucket.FILE
    )

    suspend fun extractFast(url: String): ExtractedMediaBundle? = withContext(Dispatchers.IO) {
        val normalized = UrlNormalizer.normalize(url)
        val domain = UrlNormalizer.extractDomain(normalized)
        val probe = sizeResolver.probeDirectUrl(normalized)
        val finalUrl = probe.finalUrl
        val ext = finalUrl.substringBefore("?").substringAfterLast('.', "").lowercase()

        // Fast Path A: Direct media / binary file link
        val directBucket = detectBucketFromMimeOrExt(probe.contentType, ext)
        if (directBucket != null && probe.contentType?.contains("text/html", ignoreCase = true) != true) {
            val fileName = probe.fileNameFromDisposition
                ?: finalUrl.substringBefore("?").substringAfterLast('/').ifBlank { "aurora_download.$ext" }
            val item = ExtractedFormatItem(
                formatId = "direct_$ext",
                bucket = directBucket,
                label = ext.uppercase().ifBlank { "DIRECT" },
                extension = ext.ifBlank { "bin" },
                directUrl = finalUrl,
                sizeInfo = probe.sizeInfo,
                isHlsOrDash = ext == "m3u8" || ext == "mpd"
            )
            return@withContext ExtractedMediaBundle(
                normalizedUrl = normalized,
                finalUrl = finalUrl,
                domain = domain,
                siteName = domain.substringBefore('.').replaceFirstChar { it.uppercase() },
                faviconUrl = "https://$domain/favicon.ico",
                title = fileName,
                suggestedFileName = UrlNormalizer.sanitizeFileName(fileName),
                primaryTypeLabel = directBucket.name,
                previewStreamUrl = if (directBucket == MediaBucket.VIDEO || directBucket == MediaBucket.AUDIO) finalUrl else null,
                audioItems = if (directBucket == MediaBucket.AUDIO) listOf(item) else emptyList(),
                imageItems = if (directBucket == MediaBucket.IMAGE) listOf(item) else emptyList(),
                videoItems = if (directBucket == MediaBucket.VIDEO) listOf(item) else emptyList(),
                fileItems = if (directBucket == MediaBucket.FILE) listOf(item) else emptyList(),
                stageReached = 2
            )
        }

        // Fast Path B: HTML OpenGraph + Favicon + embedded media tags (Stage 1/2 instant metadata)
        val req = Request.Builder()
            .url(finalUrl)
            .header("User-Agent", AuroraNetworkFactory.DEFAULT_BROWSER_UA)
            .build()

        val html = runCatching {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                resp.body?.string()?.take(512_000)
            }
        }.getOrNull() ?: return@withContext null

        val doc = Jsoup.parse(html, finalUrl)
        val title = doc.selectFirst("meta[property=og:title]")?.attr("content")?.ifBlank { null }
            ?: doc.title().ifBlank { domain }
        val ogImage = doc.selectFirst("meta[property=og:image]")?.absUrl("content")?.ifBlank { null }
        val ogVideo = doc.selectFirst("meta[property=og:video], meta[property=og:video:secure_url]")?.absUrl("content")?.ifBlank { null }
        val ogAudio = doc.selectFirst("meta[property=og:audio]")?.absUrl("content")?.ifBlank { null }
        val siteName = doc.selectFirst("meta[property=og:site_name]")?.attr("content")?.ifBlank { null }
            ?: domain.substringBefore('.').replaceFirstChar { it.uppercase() }
        val favicon = faviconResolver.resolveFromHtml(finalUrl, html)

        val images = mutableListOf<ExtractedFormatItem>()
        if (ogImage != null) {
            val imgProbe = sizeResolver.probeDirectUrl(ogImage)
            images.add(
                ExtractedFormatItem(
                    formatId = "og_thumb",
                    bucket = MediaBucket.IMAGE,
                    label = "Cover / Thumbnail",
                    extension = ogImage.substringBefore("?").substringAfterLast('.', "jpg").take(4),
                    directUrl = ogImage,
                    sizeInfo = imgProbe.sizeInfo
                )
            )
        }

        val videos = mutableListOf<ExtractedFormatItem>()
        if (ogVideo != null && !ogVideo.endsWith(".html")) {
            val vProbe = sizeResolver.probeDirectUrl(ogVideo)
            videos.add(
                ExtractedFormatItem(
                    formatId = "og_video",
                    bucket = MediaBucket.VIDEO,
                    label = "Fast Stream",
                    extension = ogVideo.substringBefore("?").substringAfterLast('.', "mp4").take(4),
                    directUrl = ogVideo,
                    sizeInfo = vProbe.sizeInfo,
                    isHlsOrDash = ogVideo.contains(".m3u8") || ogVideo.contains(".mpd")
                )
            )
        }

        val audios = mutableListOf<ExtractedFormatItem>()
        if (ogAudio != null) {
            val aProbe = sizeResolver.probeDirectUrl(ogAudio)
            audios.add(
                ExtractedFormatItem(
                    formatId = "og_audio",
                    bucket = MediaBucket.AUDIO,
                    label = "Original Audio",
                    extension = ogAudio.substringBefore("?").substringAfterLast('.', "mp3").take(4),
                    directUrl = ogAudio,
                    sizeInfo = aProbe.sizeInfo
                )
            )
        }

        ExtractedMediaBundle(
            normalizedUrl = normalized,
            finalUrl = finalUrl,
            domain = domain,
            siteName = siteName,
            faviconUrl = favicon,
            title = title,
            suggestedFileName = UrlNormalizer.sanitizeFileName(title),
            thumbnailUrl = ogImage,
            primaryTypeLabel = when {
                videos.isNotEmpty() -> "VIDEO"
                audios.isNotEmpty() -> "AUDIO"
                images.isNotEmpty() -> "IMAGE"
                else -> "PAGE"
            },
            previewStreamUrl = ogVideo ?: ogAudio,
            audioItems = audios,
            imageItems = images,
            videoItems = videos,
            stageReached = 2
        )
    }

    /** Stage 4 Fallback: deep Jsoup + Regex media URL scanner inside arbitrary HTML pages. */
    suspend fun extractJsoupRegexFallback(url: String): ExtractedMediaBundle? = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", AuroraNetworkFactory.DEFAULT_BROWSER_UA)
            .build()
        val html = runCatching {
            client.newCall(req).execute().use { it.body?.string()?.take(750_000) }
        }.getOrNull() ?: return@withContext null

        val mediaRegex = Regex("""https?://[^\s"'<>]+?\.(mp4|m3u8|mpd|webm|mp3|m4a|opus|flac|jpg|jpeg|png|webp|zip|pdf|apk)(\?[^\s"'<>]*)?""", RegexOption.IGNORE_CASE)
        val matches = mediaRegex.findAll(html).map { it.value }.distinct().take(24).toList()
        val domain = UrlNormalizer.extractDomain(url)

        val videos = mutableListOf<ExtractedFormatItem>()
        val audios = mutableListOf<ExtractedFormatItem>()
        val images = mutableListOf<ExtractedFormatItem>()
        val files = mutableListOf<ExtractedFormatItem>()

        matches.forEachIndexed { i, mediaUrl ->
            val ext = mediaUrl.substringBefore("?").substringAfterLast('.').lowercase()
            val bucket = directFileExtensions[ext] ?: MediaBucket.FILE
            val probe = sizeResolver.probeDirectUrl(mediaUrl)
            val item = ExtractedFormatItem(
                formatId = "regex_$i",
                bucket = bucket,
                label = ext.uppercase(),
                extension = ext,
                directUrl = mediaUrl,
                sizeInfo = probe.sizeInfo,
                isHlsOrDash = ext == "m3u8" || ext == "mpd"
            )
            when (bucket) {
                MediaBucket.VIDEO -> videos.add(item)
                MediaBucket.AUDIO -> audios.add(item)
                MediaBucket.IMAGE -> images.add(item)
                MediaBucket.FILE -> files.add(item)
            }
        }

        val doc = Jsoup.parse(html, url)
        val title = doc.title().ifBlank { domain }
        ExtractedMediaBundle(
            normalizedUrl = UrlNormalizer.normalize(url),
            finalUrl = url,
            domain = domain,
            siteName = domain,
            faviconUrl = faviconResolver.resolveFromHtml(url, html),
            title = title,
            suggestedFileName = UrlNormalizer.sanitizeFileName(title),
            audioItems = audios,
            imageItems = images,
            videoItems = videos,
            fileItems = files,
            stageReached = 4,
            requiresWebViewSniffer = videos.isEmpty() && audios.isEmpty() && images.isEmpty() && files.isEmpty()
        )
    }

    private fun detectBucketFromMimeOrExt(mime: String?, ext: String): MediaBucket? {
        val m = mime?.lowercase().orEmpty()
        return when {
            m.startsWith("video/") || m.contains("mpegurl") || m.contains("dash+xml") -> MediaBucket.VIDEO
            m.startsWith("audio/") -> MediaBucket.AUDIO
            m.startsWith("image/") -> MediaBucket.IMAGE
            m.startsWith("application/pdf") || m.startsWith("application/zip") ||
                m.contains("android.package-archive") || m.startsWith("application/octet-stream") -> MediaBucket.FILE
            else -> directFileExtensions[ext]
        }
    }
}

/**
 * Stage 3 Full Extractor powered by yt-dlp (1800+ supported sites) + FFmpeg + aria2c (-x16 -s16 -k1M)
 * via youtubedl-android, with background auto-update support.
 */
class YtDlpEngine(
    private val context: Context,
    private val sizeResolver: ExactFileSizeResolver
) {
    @Volatile
    private var initialized = false

    suspend fun ensureInitialized() = withContext(Dispatchers.IO) {
        if (initialized) return@withContext
        runCatching {
            YoutubeDL.getInstance().init(context.applicationContext)
            FFmpeg.getInstance().init(context.applicationContext)
            Aria2c.getInstance().init(context.applicationContext)
            initialized = true
        }.onFailure { Timber.e(it, "Failed to initialize yt-dlp/ffmpeg/aria2c") }
    }

    /** Auto-updates yt-dlp binary in the background on app launch or from Settings. */
    suspend fun updateYtDlpBinary(): Result<String> = withContext(Dispatchers.IO) {
        ensureInitialized()
        runCatching {
            val status = YoutubeDL.getInstance().updateYoutubeDL(
                context.applicationContext,
                YoutubeDL.UpdateChannel.STABLE
            )
            status?.name ?: "ALREADY_UP_TO_DATE"
        }
    }

    suspend fun extractAllFormats(
        url: String,
        cookieHeader: String? = null
    ): Result<ExtractedMediaBundle> = withContext(Dispatchers.IO) {
        ensureInitialized()
        runCatching {
            val request = YoutubeDLRequest(url).apply {
                addOption("--dump-single-json")
                addOption("--no-warnings")
                addOption("--no-playlist")
                addOption("--skip-download")
                if (!cookieHeader.isNullOrBlank()) {
                    addOption("--add-header", "Cookie:$cookieHeader")
                }
            }
            val response = YoutubeDL.getInstance().execute(request)
            val root = JSONObject(response.out)
            parseYtDlpJson(url, root)
        }
    }

    /** Runs yt-dlp with aria2c external downloader (-x16 -s16 -k1M) when yt-dlp native download is chosen. */
    suspend fun downloadWithAria2c(
        url: String,
        formatSelector: String,
        outputTemplate: String,
        onProgress: (Float, Long, String) -> Unit
    ): Result<Unit> = withContext(Dispatchers.IO) {
        ensureInitialized()
        runCatching {
            val request = YoutubeDLRequest(url).apply {
                addOption("-f", formatSelector)
                addOption("-o", outputTemplate)
                addOption("--downloader", "libaria2c.so")
                addOption("--external-downloader-args", "aria2c:-x16 -s16 -k1M")
                addOption("--embed-metadata")
            }
            YoutubeDL.getInstance().execute(request) { progress, eta, line ->
                onProgress(progress, eta, line)
            }
            Unit
        }
    }

    private suspend fun parseYtDlpJson(sourceUrl: String, root: JSONObject): ExtractedMediaBundle {
        val domain = UrlNormalizer.extractDomain(sourceUrl)
        val title = root.optString("title", domain)
        val uploader = root.optString("uploader", "").ifBlank { root.optString("channel", "").ifBlank { null } }
        val uploadDate = root.optString("upload_date", "").ifBlank { null }
        val duration = root.optLong("duration", -1L).takeIf { it > 0L }
        val thumbnail = root.optString("thumbnail", "").ifBlank { null }
        val extractorKey = root.optString("extractor_key", domain)

        val videos = mutableListOf<ExtractedFormatItem>()
        val audios = mutableListOf<ExtractedFormatItem>()
        val images = mutableListOf<ExtractedFormatItem>()
        val files = mutableListOf<ExtractedFormatItem>()

        // Parse formats array
        val formatsArr = root.optJSONArray("formats") ?: JSONArray()
        var bestAudioUrl: String? = null
        var bestAudioBytes: Long? = null

        for (i in 0 until formatsArr.length()) {
            val f = formatsArr.optJSONObject(i) ?: continue
            val direct = f.optString("url", "")
            if (direct.isBlank()) continue
            val vcodec = f.optString("vcodec", "none")
            val acodec = f.optString("acodec", "none")
            val ext = f.optString("ext", "mp4")
            val height = f.optInt("height", 0)
            val fps = f.optInt("fps", 0).takeIf { it > 0 }
            val abr = f.optInt("abr", 0).takeIf { it > 0 }
            val tbr = f.optInt("tbr", 0).takeIf { it > 0 }
            val dynamicRange = f.optString("dynamic_range", "")

            val exactBytes = f.optLong("filesize", -1L).takeIf { it > 0L }
            val approxBytes = f.optLong("filesize_approx", -1L).takeIf { it > 0L }
            val sizeInfo = when {
                exactBytes != null -> FileSizeInfo(exactBytes, SizePrecision.EXACT, "yt-dlp:filesize")
                approxBytes != null -> FileSizeInfo(approxBytes, SizePrecision.APPROXIMATE, "yt-dlp:filesize_approx")
                else -> FileSizeInfo()
            }

            if (vcodec == "none" && acodec != "none") {
                if (bestAudioUrl == null || (exactBytes ?: approxBytes ?: 0L) > (bestAudioBytes ?: 0L)) {
                    bestAudioUrl = direct
                    bestAudioBytes = exactBytes ?: approxBytes
                }
                audios.add(
                    ExtractedFormatItem(
                        formatId = f.optString("format_id", "a_$i"),
                        bucket = MediaBucket.AUDIO,
                        label = "${(abr ?: tbr ?: 128)} kbps ${ext.uppercase()}",
                        extension = ext,
                        bitrateKbps = abr ?: tbr,
                        codec = acodec,
                        directUrl = direct,
                        sizeInfo = sizeInfo
                    )
                )
            } else if (vcodec != "none") {
                val isVideoOnly = acodec == "none"
                val mergedSize = if (isVideoOnly && sizeInfo.isKnown && bestAudioBytes != null) {
                    FileSizeInfo(
                        bytes = sizeInfo.bytes + bestAudioBytes,
                        precision = if (exactBytes != null) SizePrecision.EXACT else SizePrecision.APPROXIMATE,
                        source = "merged_dash"
                    )
                } else {
                    sizeInfo
                }
                val resLabel = if (height > 0) "${height}p" else f.optString("format_note", "Video")
                videos.add(
                    ExtractedFormatItem(
                        formatId = f.optString("format_id", "v_$i"),
                        bucket = MediaBucket.VIDEO,
                        label = buildString {
                            append(resLabel)
                            if (fps != null && fps >= 50) append(" ${fps}fps")
                            if (dynamicRange.contains("HDR", ignoreCase = true)) append(" HDR")
                        },
                        extension = ext,
                        resolution = resLabel,
                        fps = fps,
                        bitrateKbps = tbr,
                        codec = vcodec.substringBefore('.'),
                        isHdr = dynamicRange.contains("HDR", ignoreCase = true),
                        requiresAudioMerge = isVideoOnly,
                        pairedAudioUrl = if (isVideoOnly) bestAudioUrl else null,
                        pairedAudioSizeBytes = if (isVideoOnly) bestAudioBytes else null,
                        directUrl = direct,
                        sizeInfo = mergedSize,
                        isHlsOrDash = direct.contains(".m3u8") || direct.contains(".mpd")
                    )
                )
            }
        }

        // Thumbnails -> Image bucket
        val thumbsArr = root.optJSONArray("thumbnails") ?: JSONArray()
        for (i in 0 until thumbsArr.length()) {
            val t = thumbsArr.optJSONObject(i) ?: continue
            val tUrl = t.optString("url", "")
            if (tUrl.isBlank()) continue
            val w = t.optInt("width", 0)
            val h = t.optInt("height", 0)
            images.add(
                ExtractedFormatItem(
                    formatId = "thumb_$i",
                    bucket = MediaBucket.IMAGE,
                    label = if (w > 0 && h > 0) "${w}x${h} Thumbnail" else "Cover Image #${i + 1}",
                    extension = tUrl.substringBefore("?").substringAfterLast('.', "jpg").take(4),
                    resolution = if (w > 0 && h > 0) "${w}x${h}" else null,
                    directUrl = tUrl
                )
            )
        }

        // Subtitles -> Files bucket (SRT / VTT / ASS)
        val subsObj = root.optJSONObject("subtitles")
        subsObj?.keys()?.forEach { lang ->
            val arr = subsObj.optJSONArray(lang) ?: return@forEach
            for (j in 0 until arr.length()) {
                val sub = arr.optJSONObject(j) ?: continue
                val subUrl = sub.optString("url", "")
                val subExt = sub.optString("ext", "vtt")
                if (subUrl.isNotBlank() && subExt in setOf("srt", "vtt", "ass")) {
                    files.add(
                        ExtractedFormatItem(
                            formatId = "sub_${lang}_$subExt",
                            bucket = MediaBucket.FILE,
                            label = "Subtitle ($lang) • ${subExt.uppercase()}",
                            extension = subExt,
                            directUrl = subUrl
                        )
                    )
                }
            }
        }

        // Verify exact size on top unresolved video/audio format via HEAD/Range 0-0
        val verifiedVideos = videos.sortedByDescending { it.resolution?.filter(Char::isDigit)?.toIntOrNull() ?: 0 }
            .mapIndexed { idx, item ->
                if (!item.sizeInfo.isKnown && idx < 4) {
                    val probed = sizeResolver.probeDirectUrl(item.directUrl)
                    item.copy(sizeInfo = probed.sizeInfo)
                } else item
            }

        return ExtractedMediaBundle(
            normalizedUrl = UrlNormalizer.normalize(sourceUrl),
            finalUrl = root.optString("webpage_url", sourceUrl),
            domain = domain,
            siteName = extractorKey,
            faviconUrl = "https://$domain/favicon.ico",
            title = title,
            suggestedFileName = UrlNormalizer.sanitizeFileName(title),
            author = uploader,
            publishDate = uploadDate,
            durationSeconds = duration,
            thumbnailUrl = thumbnail,
            primaryTypeLabel = when {
                verifiedVideos.isNotEmpty() -> "VIDEO"
                audios.isNotEmpty() -> "AUDIO"
                images.isNotEmpty() -> "IMAGE"
                else -> "FILE"
            },
            previewStreamUrl = verifiedVideos.firstOrNull { !it.requiresAudioMerge }?.directUrl
                ?: audios.firstOrNull()?.directUrl,
            audioItems = audios.sortedByDescending { it.bitrateKbps ?: 0 },
            imageItems = images.distinctBy { it.directUrl }.takeLast(8).reversed(),
            videoItems = verifiedVideos,
            fileItems = files,
            stageReached = 3
        )
    }
}
