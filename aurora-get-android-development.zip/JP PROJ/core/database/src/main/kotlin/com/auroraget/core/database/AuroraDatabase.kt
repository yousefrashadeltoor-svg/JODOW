package com.auroraget.core.database

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Entity(tableName = "download_tasks")
data class DownloadTaskEntity(
    @PrimaryKey val id: String,
    val sourceUrl: String,
    val directUrl: String,
    val backupMirrorUrl: String? = null,
    val fileName: String,
    val outputPath: String,
    val mediaCategory: String, // VIDEO, AUDIO, IMAGE, FILE
    val mimeType: String,
    val siteName: String,
    val thumbnailUrl: String? = null,
    val totalBytes: Long = -1L,
    val isSizeExact: Boolean = false,
    val downloadedBytes: Long = 0L,
    val speedBytesPerSec: Long = 0L,
    val activeConnections: Int = 8,
    val status: String = "QUEUED", // QUEUED, RUNNING, PAUSED, MERGING, COMPLETED, FAILED, CANCELED
    val queueOrder: Int = 0,
    val eTag: String? = null,
    val lastModified: String? = null,
    val supportsRanges: Boolean = true,
    val headersJson: String = "{}",
    val mergeAudioUrl: String? = null,
    val postConvertTarget: String? = null,
    val expectedSha256: String? = null,
    val scheduledEpochMs: Long? = null,
    val wifiOnly: Boolean = false,
    val chargingOnly: Boolean = false,
    val errorMessage: String? = null,
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "download_segments",
    foreignKeys = [
        ForeignKey(
            entity = DownloadTaskEntity::class,
            parentColumns = ["id"],
            childColumns = ["taskId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("taskId")]
)
data class DownloadSegmentEntity(
    @PrimaryKey val segmentId: String,
    val taskId: String,
    val segmentIndex: Int,
    val startOffset: Long,
    val endOffset: Long,
    val currentOffset: Long,
    val completed: Boolean = false
)

@Entity(tableName = "analyzer_cache")
data class AnalyzerCacheEntity(
    @PrimaryKey val normalizedUrl: String,
    val payloadJson: String,
    val cachedAtMs: Long,
    val expiresAtMs: Long
)

@Entity(tableName = "adblock_exceptions")
data class AdBlockExceptionEntity(
    @PrimaryKey val domain: String,
    val addedAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "vault_files")
data class VaultFileEntity(
    @PrimaryKey val id: String,
    val originalName: String,
    val encryptedPath: String,
    val ivBase64: String,
    val sizeBytes: Long,
    val mediaCategory: String,
    val addedAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "app_stats")
data class AppStatsEntity(
    @PrimaryKey val id: Int = 1,
    val totalBytesDownloaded: Long = 0L,
    val totalBytesSavedByCompression: Long = 0L,
    val totalCompletedFiles: Int = 0,
    val totalAdsBlocked: Long = 0L,
    val topDomainsJson: String = "{}"
)

@Dao
interface DownloadTaskDao {
    @Query("SELECT * FROM download_tasks ORDER BY queueOrder ASC, createdAtMs DESC")
    fun observeAllTasks(): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks WHERE id = :id LIMIT 1")
    suspend fun getTask(id: String): DownloadTaskEntity?

    @Query("SELECT * FROM download_tasks WHERE status IN ('QUEUED', 'RUNNING') ORDER BY queueOrder ASC")
    suspend fun getPendingTasks(): List<DownloadTaskEntity>

    @Query("SELECT * FROM download_tasks WHERE directUrl = :url AND status != 'CANCELED' LIMIT 1")
    suspend fun findDuplicateByUrl(url: String): DownloadTaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTask(task: DownloadTaskEntity)

    @Update
    suspend fun updateTask(task: DownloadTaskEntity)

    @Query("UPDATE download_tasks SET queueOrder = :order WHERE id = :id")
    suspend fun updateQueueOrder(id: String, order: Int)

    @Query("UPDATE download_tasks SET downloadedBytes = :downloaded, speedBytesPerSec = :speed, activeConnections = :conns, updatedAtMs = :now WHERE id = :id")
    suspend fun updateProgress(id: String, downloaded: Long, speed: Long, conns: Int, now: Long = System.currentTimeMillis())

    @Query("UPDATE download_tasks SET status = :status, errorMessage = :error, updatedAtMs = :now WHERE id = :id")
    suspend fun updateStatus(id: String, status: String, error: String? = null, now: Long = System.currentTimeMillis())

    @Query("DELETE FROM download_tasks WHERE id = :id")
    suspend fun deleteTask(id: String)
}

@Dao
interface DownloadSegmentDao {
    @Query("SELECT * FROM download_segments WHERE taskId = :taskId ORDER BY segmentIndex ASC")
    suspend fun getSegments(taskId: String): List<DownloadSegmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSegments(segments: List<DownloadSegmentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSegment(segment: DownloadSegmentEntity)

    @Query("UPDATE download_segments SET currentOffset = :offset, completed = :completed WHERE segmentId = :segmentId")
    suspend fun updateSegmentProgress(segmentId: String, offset: Long, completed: Boolean)

    @Query("DELETE FROM download_segments WHERE taskId = :taskId")
    suspend fun deleteSegments(taskId: String)
}

@Dao
interface AnalyzerCacheDao {
    @Query("SELECT * FROM analyzer_cache WHERE normalizedUrl = :url AND expiresAtMs > :now LIMIT 1")
    suspend fun getValid(url: String, now: Long = System.currentTimeMillis()): AnalyzerCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: AnalyzerCacheEntity)

    @Query("DELETE FROM analyzer_cache WHERE expiresAtMs <= :now")
    suspend fun purgeExpired(now: Long = System.currentTimeMillis())
}

@Dao
interface AdBlockExceptionDao {
    @Query("SELECT * FROM adblock_exceptions")
    fun observeAll(): Flow<List<AdBlockExceptionEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM adblock_exceptions WHERE domain = :domain)")
    suspend fun isWhitelisted(domain: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addException(item: AdBlockExceptionEntity)

    @Query("DELETE FROM adblock_exceptions WHERE domain = :domain")
    suspend fun removeException(domain: String)
}

@Dao
interface VaultDao {
    @Query("SELECT * FROM vault_files ORDER BY addedAtMs DESC")
    fun observeVaultFiles(): Flow<List<VaultFileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(file: VaultFileEntity)

    @Query("DELETE FROM vault_files WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface AppStatsDao {
    @Query("SELECT * FROM app_stats WHERE id = 1")
    fun observeStats(): Flow<AppStatsEntity?>

    @Query("SELECT * FROM app_stats WHERE id = 1")
    suspend fun getStats(): AppStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(stats: AppStatsEntity)
}

@Database(
    entities = [
        DownloadTaskEntity::class,
        DownloadSegmentEntity::class,
        AnalyzerCacheEntity::class,
        AdBlockExceptionEntity::class,
        VaultFileEntity::class,
        AppStatsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AuroraDatabase : RoomDatabase() {
    abstract fun downloadTaskDao(): DownloadTaskDao
    abstract fun downloadSegmentDao(): DownloadSegmentDao
    abstract fun analyzerCacheDao(): AnalyzerCacheDao
    abstract fun adBlockExceptionDao(): AdBlockExceptionDao
    abstract fun vaultDao(): VaultDao
    abstract fun appStatsDao(): AppStatsDao

    companion object {
        fun build(context: Context): AuroraDatabase =
            Room.databaseBuilder(context.applicationContext, AuroraDatabase::class.java, "aurora_get.db")
                .fallbackToDestructiveMigration()
                .build()
    }
}

private val Context.auroraDataStore: DataStore<Preferences> by preferencesDataStore(name = "aurora_settings")

@Serializable
data class AuroraUserSettings(
    val themePreset: String = "AURORA",
    val darkTheme: Boolean = true,
    val languageCode: String = "ar",
    val maxConcurrentDownloads: Int = 3,
    val defaultSegments: Int = 16,
    val speedLimitBytesPerSec: Long = 0L,
    val wifiOnly: Boolean = false,
    val chargingOnly: Boolean = false,
    val pauseOnLowBattery: Boolean = true,
    val dohEnabled: Boolean = true,
    val adBlockEnabled: Boolean = true,
    val clipboardMonitorEnabled: Boolean = true,
    val autoUpdateYtDlp: Boolean = true,
    val dataSaverMode: Boolean = false,
    val organizeBySiteAndType: Boolean = true,
    val onboardingCompleted: Boolean = false
)

class AuroraPreferencesRepository(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

    private object Keys {
        val THEME_PRESET = stringPreferencesKey("theme_preset")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val LANGUAGE = stringPreferencesKey("language_code")
        val MAX_CONCURRENT = intPreferencesKey("max_concurrent")
        val DEFAULT_SEGMENTS = intPreferencesKey("default_segments")
        val SPEED_LIMIT = longPreferencesKey("speed_limit")
        val WIFI_ONLY = booleanPreferencesKey("wifi_only")
        val CHARGING_ONLY = booleanPreferencesKey("charging_only")
        val LOW_BATTERY_PAUSE = booleanPreferencesKey("low_battery_pause")
        val DOH_ENABLED = booleanPreferencesKey("doh_enabled")
        val ADBLOCK_ENABLED = booleanPreferencesKey("adblock_enabled")
        val CLIPBOARD_MONITOR = booleanPreferencesKey("clipboard_monitor")
        val AUTO_UPDATE_YTDLP = booleanPreferencesKey("auto_update_ytdlp")
        val DATA_SAVER = booleanPreferencesKey("data_saver")
        val ORGANIZE_FOLDERS = booleanPreferencesKey("organize_folders")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
    }

    val settingsFlow: Flow<AuroraUserSettings> = context.auroraDataStore.data.map { p ->
        AuroraUserSettings(
            themePreset = p[Keys.THEME_PRESET] ?: "AURORA",
            darkTheme = p[Keys.DARK_THEME] ?: true,
            languageCode = p[Keys.LANGUAGE] ?: "ar",
            maxConcurrentDownloads = p[Keys.MAX_CONCURRENT] ?: 3,
            defaultSegments = (p[Keys.DEFAULT_SEGMENTS] ?: 16).coerceIn(8, 32),
            speedLimitBytesPerSec = p[Keys.SPEED_LIMIT] ?: 0L,
            wifiOnly = p[Keys.WIFI_ONLY] ?: false,
            chargingOnly = p[Keys.CHARGING_ONLY] ?: false,
            pauseOnLowBattery = p[Keys.LOW_BATTERY_PAUSE] ?: true,
            dohEnabled = p[Keys.DOH_ENABLED] ?: true,
            adBlockEnabled = p[Keys.ADBLOCK_ENABLED] ?: true,
            clipboardMonitorEnabled = p[Keys.CLIPBOARD_MONITOR] ?: true,
            autoUpdateYtDlp = p[Keys.AUTO_UPDATE_YTDLP] ?: true,
            dataSaverMode = p[Keys.DATA_SAVER] ?: false,
            organizeBySiteAndType = p[Keys.ORGANIZE_FOLDERS] ?: true,
            onboardingCompleted = p[Keys.ONBOARDING_DONE] ?: false
        )
    }

    suspend fun update(transform: (AuroraUserSettings) -> AuroraUserSettings) {
        val current = settingsFlow.first()
        val next = transform(current)
        context.auroraDataStore.edit { p ->
            p[Keys.THEME_PRESET] = next.themePreset
            p[Keys.DARK_THEME] = next.darkTheme
            p[Keys.LANGUAGE] = next.languageCode
            p[Keys.MAX_CONCURRENT] = next.maxConcurrentDownloads.coerceIn(1, 8)
            p[Keys.DEFAULT_SEGMENTS] = next.defaultSegments.coerceIn(8, 32)
            p[Keys.SPEED_LIMIT] = next.speedLimitBytesPerSec.coerceAtLeast(0L)
            p[Keys.WIFI_ONLY] = next.wifiOnly
            p[Keys.CHARGING_ONLY] = next.chargingOnly
            p[Keys.LOW_BATTERY_PAUSE] = next.pauseOnLowBattery
            p[Keys.DOH_ENABLED] = next.dohEnabled
            p[Keys.ADBLOCK_ENABLED] = next.adBlockEnabled
            p[Keys.CLIPBOARD_MONITOR] = next.clipboardMonitorEnabled
            p[Keys.AUTO_UPDATE_YTDLP] = next.autoUpdateYtDlp
            p[Keys.DATA_SAVER] = next.dataSaverMode
            p[Keys.ORGANIZE_FOLDERS] = next.organizeBySiteAndType
            p[Keys.ONBOARDING_DONE] = next.onboardingCompleted
        }
    }

    suspend fun exportBackupJson(): String = json.encodeToString(settingsFlow.first())

    suspend fun importBackupJson(payload: String): Result<Unit> = runCatching {
        val decoded = json.decodeFromString<AuroraUserSettings>(payload)
        update { decoded }
    }
}
