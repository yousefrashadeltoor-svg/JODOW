package com.auroraget.core.designsystem.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.valentinilk.shimmer.shimmer
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.hazeChild
import kotlinx.coroutines.delay

/**
 * Real Glassmorphism container using Haze backdrop blur + semi-transparent gradient +
 * 1dp specular border + subtle colored glow shadow. Zero Material dependencies.
 */
@Composable
fun AuroraGlassSurface(
    modifier: Modifier = Modifier,
    hazeState: HazeState? = null,
    shape: Shape = AuroraTheme.shapes.squircleMedium,
    elevated: Boolean = false,
    glowColor: Color? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val colors = AuroraTheme.colors
    val fillGradient = Brush.verticalGradient(
        colors = if (elevated) {
            listOf(colors.surfaceGlassElevated, colors.surfaceGlass)
        } else {
            listOf(colors.surfaceGlass, colors.surfaceGlass.copy(alpha = 0.72f))
        }
    )
    val specularBorder = Brush.verticalGradient(
        colors = listOf(colors.borderSpecularTop, colors.borderSpecularBottom)
    )

    val hazeMod = if (hazeState != null) {
        Modifier.hazeChild(
            state = hazeState,
            shape = shape,
            style = HazeStyle(
                backgroundColor = colors.background.copy(alpha = 0.35f),
                blurRadius = 24.dp,
                noiseFactor = 0.06f
            )
        )
    } else {
        Modifier
    }

    val shadowMod = if (glowColor != null) {
        Modifier.drawBehind {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(glowColor.copy(alpha = 0.24f), Color.Transparent),
                    radius = size.maxDimension * 0.7f
                )
            )
        }
    } else {
        Modifier
    }

    Box(
        modifier = modifier
            .then(shadowMod)
            .clip(shape)
            .then(hazeMod)
            .background(fillGradient, shape)
            .border(width = 1.dp, brush = specularBorder, shape = shape),
        content = content
    )
}

/**
 * Tactile Spring Button with Press Scale + Haptic Feedback + Custom Glass Fill (zero Material ripple).
 */
@Composable
fun AuroraButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingIcon: (@Composable () -> Unit)? = null,
    accentGradient: Boolean = true,
    enabled: Boolean = true
) {
    val colors = AuroraTheme.colors
    val haptic = LocalHapticFeedback.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "btnScale"
    )

    val bgBrush = if (accentGradient) {
        Brush.horizontalGradient(
            listOf(colors.accentPrimary, colors.accentSecondary, colors.accentTertiary)
        )
    } else {
        Brush.horizontalGradient(
            listOf(colors.surfaceGlassElevated, colors.surfaceGlass)
        )
    }

    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = if (enabled) 1f else 0.45f
            }
            .clip(AuroraTheme.shapes.squircleSmall)
            .background(bgBrush)
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(listOf(colors.borderSpecularTop, colors.borderSpecularBottom)),
                shape = AuroraTheme.shapes.squircleSmall
            )
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null
            ) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(horizontal = 18.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (leadingIcon != null) leadingIcon()
            BasicText(
                text = text,
                style = AuroraTheme.typography.labelLarge.copy(
                    color = if (accentGradient) Color.White else colors.textPrimary
                )
            )
        }
    }
}

/**
 * Gemini-style Streaming Text Reveal: progressively streams words with Blur-to-Sharp entrance.
 */
@Composable
fun StreamingTextReveal(
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier,
    wordDelayMs: Long = 26L
) {
    val words = remember(text) { text.split(" ") }
    var visibleCount by remember(text) { mutableIntStateOf(0) }

    LaunchedEffect(text) {
        visibleCount = 0
        for (i in 1..words.size) {
            visibleCount = i
            delay(wordDelayMs)
        }
    }

    val blurRadius by animateDpAsState(
        targetValue = if (visibleCount >= words.size) 0.dp else 4.dp,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "streamBlur"
    )

    BasicText(
        text = words.take(visibleCount).joinToString(" "),
        style = style,
        modifier = modifier.blur(blurRadius)
    )
}

/**
 * Unified Glass Skeleton Shimmer placeholder while streaming analyzer stages.
 */
@Composable
fun AuroraSkeletonBox(
    modifier: Modifier = Modifier,
    shape: Shape = AuroraTheme.shapes.squircleSmall
) {
    val colors = AuroraTheme.colors
    Box(
        modifier = modifier
            .shimmer()
            .clip(shape)
            .background(colors.textSecondary.copy(alpha = 0.14f))
    )
}

/**
 * Real-time Download Speed Sparkline rendered smoothly via Canvas Path.
 */
@Composable
fun AuroraSpeedSparkline(
    samples: List<Float>,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    Canvas(modifier = modifier) {
        if (samples.size < 2) return@Canvas
        val maxVal = (samples.maxOrNull() ?: 1f).coerceAtLeast(1f)
        val stepX = size.width / (samples.size - 1)
        val linePath = Path()
        val fillPath = Path()

        samples.forEachIndexed { idx, value ->
            val x = idx * stepX
            val y = size.height - (value / maxVal) * size.height * 0.88f
            if (idx == 0) {
                linePath.moveTo(x, y)
                fillPath.moveTo(x, size.height)
                fillPath.lineTo(x, y)
            } else {
                linePath.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }
        fillPath.lineTo(size.width, size.height)
        fillPath.close()

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                listOf(colors.accentPrimary.copy(alpha = 0.32f), Color.Transparent)
            )
        )
        drawPath(
            path = linePath,
            brush = Brush.horizontalGradient(listOf(colors.accentPrimary, colors.accentSecondary, colors.accentTertiary)),
            style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}

/**
 * Interactive Before/After Glass Slider for Smart Compressor verification.
 */
@Composable
fun BeforeAfterGlassSlider(
    beforeLabel: String,
    afterLabel: String,
    beforeContent: @Composable BoxScope.() -> Unit,
    afterContent: @Composable BoxScope.() -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    var splitFraction by remember { mutableFloatStateOf(0.5f) }

    Box(
        modifier = modifier
            .clip(AuroraTheme.shapes.squircleMedium)
            .border(1.dp, colors.borderSpecularTop, AuroraTheme.shapes.squircleMedium)
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, dragAmount ->
                    change.consume()
                    splitFraction = (splitFraction + dragAmount / size.width).coerceIn(0.08f, 0.92f)
                }
            }
    ) {
        Box(modifier = Modifier.fillMaxSize(), content = afterContent)
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(splitFraction)
                .clip(RoundedCornerShape(0.dp)),
            content = beforeContent
        )
        // Luminous glass divider handle
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(splitFraction),
            contentAlignment = Alignment.CenterEnd
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(2.dp)
                    .background(Color.White.copy(alpha = 0.85f))
            )
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(listOf(colors.accentPrimary, colors.accentSecondary))
                    )
                    .border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                BasicText(
                    text = "⇄",
                    style = AuroraTheme.typography.labelLarge.copy(color = Color.White)
                )
            }
        }
        // Corner pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            AuroraGlassPill(beforeLabel)
            AuroraGlassPill(afterLabel)
        }
    }
}

@Composable
fun AuroraGlassPill(
    text: String,
    modifier: Modifier = Modifier,
    tint: Color? = null
) {
    val colors = AuroraTheme.colors
    Box(
        modifier = modifier
            .clip(AuroraTheme.shapes.pill)
            .background((tint ?: colors.surfaceGlassElevated).copy(alpha = 0.85f))
            .border(1.dp, colors.borderSpecularTop, AuroraTheme.shapes.pill)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        BasicText(
            text = text,
            style = AuroraTheme.typography.labelSmall.copy(color = colors.textPrimary)
        )
    }
}

/**
 * Custom Physics Glass Bottom Sheet with backdrop dimming & blur. Zero Material ModalBottomSheet.
 */
@Composable
fun AuroraGlassBottomSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    hazeState: HazeState,
    title: String,
    content: @Composable () -> Unit
) {
    val colors = AuroraTheme.colors
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(spring(stiffness = Spring.StiffnessMediumLow)),
        exit = fadeOut(spring(stiffness = Spring.StiffnessMedium))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.52f))
                .pointerInput(Unit) { detectTapGestures { onDismiss() } },
            contentAlignment = Alignment.BottomCenter
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = slideInVertically(
                    initialOffsetY = { it },
                    animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow)
                ),
                exit = slideOutVertically(
                    targetOffsetY = { it },
                    animationSpec = spring(stiffness = Spring.StiffnessMedium)
                )
            ) {
                AuroraGlassSurface(
                    hazeState = hazeState,
                    elevated = true,
                    shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(Unit) { detectTapGestures { /* absorb click */ } }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .width(42.dp)
                                .height(4.dp)
                                .clip(CircleShape)
                                .background(colors.textMuted.copy(alpha = 0.45f))
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        BasicText(
                            text = title,
                            style = AuroraTheme.typography.titleLarge.copy(color = colors.textPrimary)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        content()
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}

data class AuroraDockDestination(
    val id: String,
    val label: String,
    val icon: ImageVector,
    val badgeCount: Int = 0
)

/**
 * Floating Glass Navigation Dock with morphing active glow pill (STRICTLY NOT Material NavigationBar).
 */
@Composable
fun AuroraFloatingDock(
    destinations: List<AuroraDockDestination>,
    selectedId: String,
    onSelect: (String) -> Unit,
    hazeState: HazeState,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    val haptic = LocalHapticFeedback.current

    AuroraGlassSurface(
        hazeState = hazeState,
        elevated = true,
        shape = AuroraTheme.shapes.squircleHero,
        glowColor = colors.accentPrimary,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            destinations.forEach { dest ->
                val selected = dest.id == selectedId
                val pillScale by animateFloatAsState(
                    targetValue = if (selected) 1.04f else 0.96f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessMedium
                    ),
                    label = "dockScale"
                )
                Box(
                    modifier = Modifier
                        .graphicsLayer { scaleX = pillScale; scaleY = pillScale }
                        .clip(AuroraTheme.shapes.pill)
                        .background(
                            if (selected) {
                                Brush.horizontalGradient(
                                    listOf(
                                        colors.accentPrimary.copy(alpha = 0.28f),
                                        colors.accentSecondary.copy(alpha = 0.28f)
                                    )
                                )
                            } else {
                                Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                            }
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onSelect(dest.id)
                        }
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AuroraVectorIcon(
                            imageVector = dest.icon,
                            tint = if (selected) colors.accentPrimary else colors.textSecondary,
                            size = 20.dp
                        )
                        if (selected) {
                            BasicText(
                                text = dest.label,
                                style = AuroraTheme.typography.labelSmall.copy(color = colors.textPrimary)
                            )
                        }
                        if (dest.badgeCount > 0) {
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(colors.accentTertiary)
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                BasicText(
                                    text = dest.badgeCount.toString(),
                                    style = AuroraTheme.typography.labelSmall.copy(color = Color.White)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AuroraVectorIcon(
    imageVector: ImageVector,
    tint: Color,
    size: Dp = 20.dp,
    modifier: Modifier = Modifier
) {
    androidx.compose.foundation.Image(
        imageVector = imageVector,
        contentDescription = null,
        colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(tint),
        modifier = modifier.size(size)
    )
}
