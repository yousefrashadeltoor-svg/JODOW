package com.auroraget.core.designsystem.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Pure Custom Design System ("Aurora Glass").
 * STRICTLY ZERO Material Design / Material3 / Material Theme imports.
 */
enum class AuroraThemePreset {
    AURORA,
    OCEAN,
    SUNSET,
    EMERALD,
    MONO,
    NEON
}

@Immutable
data class AuroraColorScheme(
    val isDark: Boolean,
    val background: Color,
    val surfaceGlass: Color,
    val surfaceGlassElevated: Color,
    val borderSpecularTop: Color,
    val borderSpecularBottom: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val accentPrimary: Color,
    val accentSecondary: Color,
    val accentTertiary: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
    val dynamicArtworkTint: Color
)

@Immutable
data class AuroraTypography(
    val displayLarge: TextStyle,
    val headlineMedium: TextStyle,
    val titleLarge: TextStyle,
    val titleMedium: TextStyle,
    val bodyLarge: TextStyle,
    val bodyMedium: TextStyle,
    val labelLarge: TextStyle,
    val labelSmall: TextStyle,
    val monoMetric: TextStyle
)

@Immutable
data class AuroraShapes(
    val pill: Shape = RoundedCornerShape(percent = 50),
    val squircleSmall: Shape = RoundedCornerShape(20.dp),
    val squircleMedium: Shape = RoundedCornerShape(24.dp),
    val squircleLarge: Shape = RoundedCornerShape(28.dp),
    val squircleHero: Shape = RoundedCornerShape(32.dp)
)

fun buildAuroraColorScheme(
    preset: AuroraThemePreset,
    darkTheme: Boolean,
    artworkTint: Color? = null
): AuroraColorScheme {
    val (p1, p2, p3) = when (preset) {
        AuroraThemePreset.AURORA -> Triple(Color(0xFF4285F4), Color(0xFF9B72CB), Color(0xFFD96570))
        AuroraThemePreset.OCEAN -> Triple(Color(0xFF0EA5E9), Color(0xFF2DD4BF), Color(0xFF6366F1))
        AuroraThemePreset.SUNSET -> Triple(Color(0xFFFB7185), Color(0xFFF97316), Color(0xFFA855F7))
        AuroraThemePreset.EMERALD -> Triple(Color(0xFF10B981), Color(0xFF06B6D4), Color(0xFF34D399))
        AuroraThemePreset.MONO -> Triple(Color(0xFFE2E8F0), Color(0xFF94A3B8), Color(0xFF64748B))
        AuroraThemePreset.NEON -> Triple(Color(0xFF00F5D4), Color(0xFF9B5DE5), Color(0xFFF15BB5))
    }

    return if (darkTheme) {
        AuroraColorScheme(
            isDark = true,
            background = Color(0xFF0B0D12),
            surfaceGlass = Color(0xCC131722),
            surfaceGlassElevated = Color(0xE61A2030),
            borderSpecularTop = Color(0x40FFFFFF),
            borderSpecularBottom = Color(0x12FFFFFF),
            textPrimary = Color(0xFFF5F7FF),
            textSecondary = Color(0xFFB4BCD0),
            textMuted = Color(0xFF7B849B),
            accentPrimary = p1,
            accentSecondary = p2,
            accentTertiary = p3,
            success = Color(0xFF34D399),
            warning = Color(0xFFFBBF24),
            error = Color(0xFFF87171),
            dynamicArtworkTint = artworkTint ?: p2
        )
    } else {
        AuroraColorScheme(
            isDark = false,
            background = Color(0xFFF3F6FC),
            surfaceGlass = Color(0xCCFFFFFF),
            surfaceGlassElevated = Color(0xEEFFFFFF),
            borderSpecularTop = Color(0xCCFFFFFF),
            borderSpecularBottom = Color(0x284285F4),
            textPrimary = Color(0xFF0F172A),
            textSecondary = Color(0xFF475569),
            textMuted = Color(0xFF64748B),
            accentPrimary = p1,
            accentSecondary = p2,
            accentTertiary = p3,
            success = Color(0xFF059669),
            warning = Color(0xFFD97706),
            error = Color(0xFFDC2626),
            dynamicArtworkTint = artworkTint ?: p1
        )
    }
}

fun buildAuroraTypography(
    // VERIFY: Place SIL OFL Plus Jakarta Sans & IBM Plex Sans Arabic TTF files under res/font/
    bodyFamily: FontFamily = FontFamily.SansSerif,
    monoFamily: FontFamily = FontFamily.Monospace
): AuroraTypography = AuroraTypography(
    displayLarge = TextStyle(fontFamily = bodyFamily, fontWeight = FontWeight.Bold, fontSize = 30.sp, lineHeight = 38.sp),
    headlineMedium = TextStyle(fontFamily = bodyFamily, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 30.sp),
    titleLarge = TextStyle(fontFamily = bodyFamily, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 25.sp),
    titleMedium = TextStyle(fontFamily = bodyFamily, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 21.sp),
    bodyLarge = TextStyle(fontFamily = bodyFamily, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = bodyFamily, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 19.sp),
    labelLarge = TextStyle(fontFamily = bodyFamily, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, lineHeight = 18.sp),
    labelSmall = TextStyle(fontFamily = bodyFamily, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 15.sp),
    monoMetric = TextStyle(fontFamily = monoFamily, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp)
)

val LocalAuroraColors = staticCompositionLocalOf { buildAuroraColorScheme(AuroraThemePreset.AURORA, darkTheme = true) }
val LocalAuroraTypography = staticCompositionLocalOf { buildAuroraTypography() }
val LocalAuroraShapes = staticCompositionLocalOf { AuroraShapes() }

object AuroraTheme {
    val colors: AuroraColorScheme
        @Composable @ReadOnlyComposable get() = LocalAuroraColors.current
    val typography: AuroraTypography
        @Composable @ReadOnlyComposable get() = LocalAuroraTypography.current
    val shapes: AuroraShapes
        @Composable @ReadOnlyComposable get() = LocalAuroraShapes.current
}

@Composable
fun AuroraGlassTheme(
    preset: AuroraThemePreset = AuroraThemePreset.AURORA,
    darkTheme: Boolean = true,
    isRtl: Boolean = true,
    artworkTint: Color? = null,
    content: @Composable () -> Unit
) {
    val colors = buildAuroraColorScheme(preset, darkTheme, artworkTint)
    val typography = buildAuroraTypography()
    val shapes = AuroraShapes()
    val direction = if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(
        LocalAuroraColors provides colors,
        LocalAuroraTypography provides typography,
        LocalAuroraShapes provides shapes,
        LocalLayoutDirection provides direction,
        content = content
    )
}
