package com.auroraget.core.designsystem.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Custom Phosphor/Lucide-inspired Vector Icons built cleanly via ImageVector.Builder.
 * Strictly ZERO Material Icons dependencies.
 */
object AuroraIcons {
    private fun strokeIcon(name: String, block: ImageVector.Builder.() -> Unit): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply(block).build()

    val Sparkle: ImageVector by lazy {
        strokeIcon("Sparkle") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(12f, 3f)
                lineTo(14.4f, 9.6f)
                lineTo(21f, 12f)
                lineTo(14.4f, 14.4f)
                lineTo(12f, 21f)
                lineTo(9.6f, 14.4f)
                lineTo(3f, 12f)
                lineTo(9.6f, 9.6f)
                close()
            }
        }
    }

    val Download: ImageVector by lazy {
        strokeIcon("Download") {
            path(stroke = SolidColor(Color.White), strokeLineWidth = 1.9f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
                moveTo(12f, 3f); lineTo(12f, 15f)
                moveTo(7f, 10f); lineTo(12f, 15f); lineTo(17f, 10f)
                moveTo(4f, 19f); lineTo(20f, 19f)
            }
        }
    }

    val Compass: ImageVector by lazy {
        strokeIcon("Compass") {
            path(stroke = SolidColor(Color.White), strokeLineWidth = 1.9f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
                moveTo(12f, 2f); reflectiveCurveTo(22f, 6.5f, 22f, 12f)
                reflectiveCurveTo(17.5f, 22f, 12f, 22f)
                reflectiveCurveTo(2f, 17.5f, 2f, 12f)
                reflectiveCurveTo(6.5f, 2f, 12f, 2f)
                moveTo(16.2f, 7.8f); lineTo(14.1f, 14.1f); lineTo(7.8f, 16.2f); lineTo(9.9f, 9.9f); close()
            }
        }
    }

    val Wand: ImageVector by lazy {
        strokeIcon("Wand") {
            path(stroke = SolidColor(Color.White), strokeLineWidth = 1.9f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
                moveTo(4f, 20f); lineTo(16f, 8f)
                moveTo(14f, 6f); lineTo(18f, 10f)
                moveTo(18f, 3f); lineTo(18f, 5f)
                moveTo(21f, 6f); lineTo(19f, 6f)
            }
        }
    }

    val Folder: ImageVector by lazy {
        strokeIcon("Folder") {
            path(stroke = SolidColor(Color.White), strokeLineWidth = 1.9f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
                moveTo(3f, 7f); lineTo(9f, 7f); lineTo(11f, 9f); lineTo(21f, 9f)
                lineTo(21f, 19f); lineTo(3f, 19f); close()
            }
        }
    }

    val Sliders: ImageVector by lazy {
        strokeIcon("Sliders") {
            path(stroke = SolidColor(Color.White), strokeLineWidth = 1.9f, strokeLineCap = StrokeCap.Round) {
                moveTo(4f, 7f); lineTo(20f, 7f)
                moveTo(4f, 12f); lineTo(20f, 12f)
                moveTo(4f, 17f); lineTo(20f, 17f)
            }
        }
    }

    val AudioWave: ImageVector by lazy {
        strokeIcon("AudioWave") {
            path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round) {
                moveTo(4f, 10f); lineTo(4f, 14f)
                moveTo(8f, 6f); lineTo(8f, 18f)
                moveTo(12f, 3f); lineTo(12f, 21f)
                moveTo(16f, 7f); lineTo(16f, 17f)
                moveTo(20f, 10f); lineTo(20f, 14f)
            }
        }
    }

    val Film: ImageVector by lazy {
        strokeIcon("Film") {
            path(stroke = SolidColor(Color.White), strokeLineWidth = 1.9f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
                moveTo(3f, 6f); lineTo(21f, 6f); lineTo(21f, 18f); lineTo(3f, 18f); close()
                moveTo(10f, 9.5f); lineTo(15f, 12f); lineTo(10f, 14.5f); close()
            }
        }
    }

    val ImageFrame: ImageVector by lazy {
        strokeIcon("ImageFrame") {
            path(stroke = SolidColor(Color.White), strokeLineWidth = 1.9f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
                moveTo(3f, 5f); lineTo(21f, 5f); lineTo(21f, 19f); lineTo(3f, 19f); close()
                moveTo(4f, 16f); lineTo(9f, 11f); lineTo(14f, 16f)
                moveTo(13f, 14f); lineTo(16f, 11f); lineTo(20f, 15f)
            }
        }
    }

    val FileDoc: ImageVector by lazy {
        strokeIcon("FileDoc") {
            path(stroke = SolidColor(Color.White), strokeLineWidth = 1.9f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
                moveTo(6f, 3f); lineTo(14f, 3f); lineTo(19f, 8f); lineTo(19f, 21f); lineTo(6f, 21f); close()
                moveTo(14f, 3f); lineTo(14f, 8f); lineTo(19f, 8f)
            }
        }
    }

    val Shield: ImageVector by lazy {
        strokeIcon("Shield") {
            path(stroke = SolidColor(Color.White), strokeLineWidth = 1.9f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
                moveTo(12f, 3f); lineTo(20f, 6f); lineTo(20f, 12f)
                curveTo(20f, 16.5f, 16.5f, 19.8f, 12f, 21f)
                curveTo(7.5f, 19.8f, 4f, 16.5f, 4f, 12f)
                lineTo(4f, 6f); close()
            }
        }
    }

    val LockVault: ImageVector by lazy {
        strokeIcon("LockVault") {
            path(stroke = SolidColor(Color.White), strokeLineWidth = 1.9f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
                moveTo(5f, 11f); lineTo(19f, 11f); lineTo(19f, 20f); lineTo(5f, 20f); close()
                moveTo(8f, 11f); lineTo(8f, 7f); curveTo(8f, 4.8f, 16f, 4.8f, 16f, 7f); lineTo(16f, 11f)
            }
        }
    }
}
