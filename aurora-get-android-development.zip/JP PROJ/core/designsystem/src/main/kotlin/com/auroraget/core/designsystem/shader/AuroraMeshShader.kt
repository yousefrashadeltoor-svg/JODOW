package com.auroraget.core.designsystem.shader

import android.graphics.RuntimeShader
import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.auroraget.core.designsystem.theme.AuroraTheme
import kotlin.math.cos
import kotlin.math.sin

private const val AURORA_MESH_AGSL = """
uniform float2 uResolution;
uniform float uTime;
uniform half4 uBg;
uniform half4 uColorA;
uniform half4 uColorB;
uniform half4 uColorC;

half4 main(float2 fragCoord) {
    float2 uv = fragCoord / uResolution;
    float2 p1 = float2(0.22 + 0.14 * sin(uTime * 0.45), 0.20 + 0.12 * cos(uTime * 0.35));
    float2 p2 = float2(0.78 + 0.12 * cos(uTime * 0.40), 0.32 + 0.16 * sin(uTime * 0.50));
    float2 p3 = float2(0.50 + 0.18 * sin(uTime * 0.30 + 1.5), 0.80 + 0.10 * cos(uTime * 0.38));

    float d1 = exp(-5.2 * distance(uv, p1));
    float d2 = exp(-4.8 * distance(uv, p2));
    float d3 = exp(-5.5 * distance(uv, p3));

    half3 col = uBg.rgb;
    col += uColorA.rgb * half(d1 * 0.42);
    col += uColorB.rgb * half(d2 * 0.38);
    col += uColorC.rgb * half(d3 * 0.30);
    return half4(clamp(col, 0.0, 1.0), 1.0);
}
"""

/**
 * Animated Aurora Mesh Gradient backdrop using AGSL RuntimeShader on Android 13+ (API 33+)
 * and an equivalent GPU-cached radial Brush mesh fallback on API 24-32.
 */
@Composable
fun AuroraMeshBackdrop(modifier: Modifier = Modifier) {
    val colors = AuroraTheme.colors
    val infinite = rememberInfiniteTransition(label = "auroraMesh")
    val time by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 62.83185f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 48_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "meshTime"
    )

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        val shader = remember { RuntimeShader(AURORA_MESH_AGSL) }
        Canvas(modifier = modifier.fillMaxSize()) {
            shader.setFloatUniform("uResolution", size.width, size.height)
            shader.setFloatUniform("uTime", time)
            shader.setColorUniform("uBg", colors.background.toArgbCompat())
            shader.setColorUniform("uColorA", colors.accentPrimary.toArgbCompat())
            shader.setColorUniform("uColorB", colors.dynamicArtworkTint.toArgbCompat())
            shader.setColorUniform("uColorC", colors.accentTertiary.toArgbCompat())
            drawRect(brush = ShaderBrush(shader))
        }
    } else {
        Canvas(modifier = modifier.fillMaxSize()) {
            drawRect(color = colors.background)
            val blob1 = Offset(
                x = size.width * (0.24f + 0.12f * sin(time * 0.4f)),
                y = size.height * (0.18f + 0.08f * cos(time * 0.35f))
            )
            val blob2 = Offset(
                x = size.width * (0.78f + 0.10f * cos(time * 0.38f)),
                y = size.height * (0.34f + 0.11f * sin(time * 0.42f))
            )
            val blob3 = Offset(
                x = size.width * (0.50f + 0.14f * sin(time * 0.28f + 1.2f)),
                y = size.height * (0.82f + 0.08f * cos(time * 0.31f))
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(colors.accentPrimary.copy(alpha = 0.30f), Color.Transparent),
                    center = blob1,
                    radius = size.maxDimension * 0.55f
                ),
                center = blob1,
                radius = size.maxDimension * 0.55f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(colors.dynamicArtworkTint.copy(alpha = 0.28f), Color.Transparent),
                    center = blob2,
                    radius = size.maxDimension * 0.52f
                ),
                center = blob2,
                radius = size.maxDimension * 0.52f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(colors.accentTertiary.copy(alpha = 0.24f), Color.Transparent),
                    center = blob3,
                    radius = size.maxDimension * 0.50f
                ),
                center = blob3,
                radius = size.maxDimension * 0.50f
            )
        }
    }
}

private fun Color.toArgbCompat(): Int {
    val a = (alpha * 255f + 0.5f).toInt() and 0xFF
    val r = (red * 255f + 0.5f).toInt() and 0xFF
    val g = (green * 255f + 0.5f).toInt() and 0xFF
    val b = (blue * 255f + 0.5f).toInt() and 0xFF
    return (a shl 24) or (r shl 16) or (g shl 8) or b
}

/**
 * Gemini-style rotating sweepGradient luminous glow around the paste input and active analysis card.
 * Smoothly calms down when analysis completes.
 */
fun Modifier.auroraGeminiGlow(
    active: Boolean,
    cornerRadius: Dp = 28.dp,
    borderWidth: Dp = 2.dp
): Modifier = composed {
    val colors = AuroraTheme.colors
    val infinite = rememberInfiniteTransition(label = "geminiGlow")
    val angle by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (active) 2_200 else 9_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "glowAngle"
    )

    val glowAlpha = if (active) 0.95f else 0.34f
    val gradientColors = listOf(
        colors.accentPrimary.copy(alpha = glowAlpha),
        colors.accentSecondary.copy(alpha = glowAlpha),
        colors.accentTertiary.copy(alpha = glowAlpha),
        colors.accentPrimary.copy(alpha = glowAlpha)
    )

    drawWithCache {
        val radiusPx = cornerRadius.toPx()
        val strokePx = borderWidth.toPx()
        val sweep = Brush.sweepGradient(colors = gradientColors)
        onDrawWithContent {
            drawContent()
            rotate(degrees = angle, pivot = center) {
                drawRoundRect(
                    brush = sweep,
                    cornerRadius = CornerRadius(radiusPx, radiusPx),
                    style = Stroke(width = strokePx)
                )
            }
        }
    }
}
