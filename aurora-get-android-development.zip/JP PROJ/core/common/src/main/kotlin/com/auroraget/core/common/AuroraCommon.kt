package com.auroraget.core.common

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.serialization.Serializable
import java.io.File
import java.io.FileInputStream
import java.net.URI
import java.security.MessageDigest
import java.text.DecimalFormat
import java.text.NumberFormat
import java.util.Locale

data class AuroraDispatchers(
    val io: CoroutineDispatcher = Dispatchers.IO,
    val default: CoroutineDispatcher = Dispatchers.Default,
    val main: CoroutineDispatcher = Dispatchers.Main.immediate
)

enum class SizePrecision {
    EXACT,
    APPROXIMATE,
    UNKNOWN
}

/**
 * Strictly separates verified exact file sizes from approximate estimates.
 * Exact sizes are never prefixed with '≈'; approximate sizes are ALWAYS prefixed with '≈'.
 */
@Serializable
data class FileSizeInfo(
    val bytes: Long = -1L,
    val precision: SizePrecision = SizePrecision.UNKNOWN,
    val source: String = "unknown"
) {
    val isKnown: Boolean get() = bytes >= 0L && precision != SizePrecision.UNKNOWN

    fun formatHuman(locale: Locale = Locale.US): String {
        if (!isKnown) return "—"
        val prefix = if (precision == SizePrecision.APPROXIMATE) "≈ " else ""
        return prefix + ByteFormatters.formatBinaryUnits(bytes, locale)
    }

    /** Exact byte representation displayed on long press, e.g.: 148,372,910 bytes (141.5 MiB) */
    fun formatExactDetail(locale: Locale = Locale.US): String {
        if (!isKnown) return "Unknown size"
        val exactInt = NumberFormat.getIntegerInstance(locale).format(bytes)
        val human = ByteFormatters.formatBinaryUnits(bytes, locale)
        val marker = if (precision == SizePrecision.APPROXIMATE) "≈ " else ""
        return "$marker$exactInt bytes ($human)"
    }

    operator fun plus(other: FileSizeInfo): FileSizeInfo {
        if (!isKnown || !other.isKnown) return FileSizeInfo(-1L, SizePrecision.UNKNOWN, "merged")
        val mergedPrecision = if (precision == SizePrecision.EXACT && other.precision == SizePrecision.EXACT) {
            SizePrecision.EXACT
        } else {
            SizePrecision.APPROXIMATE
        }
        return FileSizeInfo(
            bytes = bytes + other.bytes,
            precision = mergedPrecision,
            source = "$source+${other.source}"
        )
    }
}

object ByteFormatters {
    private val units = arrayOf("B", "KiB", "MiB", "GiB", "TiB")

    fun formatBinaryUnits(bytes: Long, locale: Locale = Locale.US): String {
        if (bytes < 0L) return "—"
        if (bytes < 1024L) return "$bytes B"
        var value = bytes.toDouble()
        var index = 0
        while (value >= 1024.0 && index < units.lastIndex) {
            value /= 1024.0
            index++
        }
        val df = DecimalFormat(if (value >= 100.0) "#,##0" else "#,##0.0").apply {
            decimalFormatSymbols = java.text.DecimalFormatSymbols.getInstance(locale)
        }
        return "${df.format(value)} ${units[index]}"
    }

    fun formatSpeed(bytesPerSecond: Long): String {
        if (bytesPerSecond <= 0L) return "0 B/s"
        return "${formatBinaryUnits(bytesPerSecond)}/s"
    }

    fun formatDuration(seconds: Long): String {
        if (seconds < 0L) return "--:--"
        val hrs = seconds / 3600
        val mins = (seconds % 3600) / 60
        val secs = seconds % 60
        return if (hrs > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hrs, mins, secs)
        } else {
            String.format(Locale.US, "%02d:%02d", mins, secs)
        }
    }
}

object UrlNormalizer {
    private val trackingParams = setOf(
        "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
        "fbclid", "gclid", "si", "igshid", "feature", "ref_src", "ref_url"
    )

    private val urlExtractRegex = Regex(
        pattern = """https?://[^\s<>"']+""",
        option = RegexOption.IGNORE_CASE
    )

    fun extractAllUrls(rawInput: String): List<String> =
        urlExtractRegex.findAll(rawInput).map { normalize(it.value) }.distinct().toList()

    fun normalize(raw: String): String {
        val trimmed = raw.trim().trimEnd('.', ',', ')', ']', '"', '\'')
        val withScheme = when {
            trimmed.startsWith("http://", ignoreCase = true) ||
                trimmed.startsWith("https://", ignoreCase = true) ||
                trimmed.startsWith("magnet:", ignoreCase = true) -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> return trimmed
        }
        return runCatching {
            val uri = URI(withScheme)
            val cleanQuery = uri.rawQuery
                ?.split("&")
                ?.filter { pair ->
                    val key = pair.substringBefore("=").lowercase(Locale.US)
                    key.isNotEmpty() && key !in trackingParams
                }
                ?.joinToString("&")
                ?.takeIf { it.isNotEmpty() }
            URI(
                uri.scheme?.lowercase(Locale.US) ?: "https",
                uri.rawUserInfo,
                uri.host?.lowercase(Locale.US),
                uri.port,
                uri.rawPath,
                cleanQuery,
                null
            ).toASCIIString()
        }.getOrDefault(withScheme)
    }

    fun extractDomain(url: String): String = runCatching {
        URI(normalize(url)).host?.removePrefix("www.") ?: ""
    }.getOrDefault("")

    fun sanitizeFileName(name: String, maxLength: Int = 120): String {
        val cleaned = name
            .replace(Regex("""[\\/:*?"<>|\u0000-\u001F]"""), "_")
            .replace(Regex("""\s+"""), " ")
            .trim()
        return cleaned.take(maxLength).ifEmpty { "aurora_file_${System.currentTimeMillis()}" }
    }
}

enum class HashAlgorithm(val jcaName: String) {
    MD5("MD5"),
    SHA1("SHA-1"),
    SHA256("SHA-256")
}

object FileHashVerifier {
    fun computeHash(file: File, algorithm: HashAlgorithm): String {
        val digest = MessageDigest.getInstance(algorithm.jcaName)
        FileInputStream(file).use { input ->
            val buffer = ByteArray(256 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun verify(file: File, expectedHash: String, algorithm: HashAlgorithm): Boolean =
        computeHash(file, algorithm).equals(expectedHash.trim(), ignoreCase = true)
}

object LegalCompliance {
    const val COPYRIGHT_NOTICE_AR =
        "المسؤولية تقع بالكامل على المستخدم في احترام حقوق النشر وشروط استخدام المواقع. لا يدعم التطبيق تجاوز حماية DRM أو المحتوى المدفوع."
    const val COPYRIGHT_NOTICE_EN =
        "Users are solely responsible for respecting copyright laws and site terms of service. DRM circumvention and paywall bypass are strictly unsupported."
}
