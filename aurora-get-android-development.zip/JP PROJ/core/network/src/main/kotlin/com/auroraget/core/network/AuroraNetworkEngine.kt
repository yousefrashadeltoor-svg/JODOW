package com.auroraget.core.network

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.auroraget.core.common.FileSizeInfo
import com.auroraget.core.common.SizePrecision
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.Dns
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.dnsoverhttps.DnsOverHttps
import org.chromium.net.CronetEngine
import timber.log.Timber
import java.io.File
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Encrypted persistent CookieJar backed by AndroidX Security-Crypto (AES256-GCM).
 * Stores Cloudflare cf_clearance and browser login cookies securely with zero plaintext writes.
 */
class EncryptedAuroraCookieJar(context: Context) : CookieJar {
    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context.applicationContext,
            "aurora_encrypted_cookies",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }
    private val memoryCache = ConcurrentHashMap<String, MutableList<Cookie>>()

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        val host = url.host
        val bucket = memoryCache.getOrPut(host) { mutableListOf() }
        cookies.forEach { incoming ->
            bucket.removeAll { it.name == incoming.name && it.path == incoming.path }
            if (incoming.expiresAt > System.currentTimeMillis()) {
                bucket.add(incoming)
            }
        }
        persistHost(host, bucket)
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        val host = url.host
        val now = System.currentTimeMillis()
        val cached = memoryCache[host] ?: restoreHost(host, url).also { memoryCache[host] = it.toMutableList() }
        return cached.filter { it.expiresAt > now && it.matches(url) }
    }

    /** Imports cookies extracted from WebView (e.g., after Cloudflare Turnstile/JS challenge). */
    fun importWebViewCookieHeader(urlString: String, cookieHeader: String) {
        val httpUrl = runCatching { urlString.toHttpUrl() }.getOrNull() ?: return
        val parsed = cookieHeader.split(";").mapNotNull { pair ->
            Cookie.parse(httpUrl, pair.trim())
        }
        if (parsed.isNotEmpty()) {
            saveFromResponse(httpUrl, parsed)
        }
    }

    private fun persistHost(host: String, cookies: List<Cookie>) {
        val encoded = cookies.joinToString("\n") { it.toString() }
        prefs.edit().putString("host_$host", encoded).apply()
    }

    private fun restoreHost(host: String, url: HttpUrl): List<Cookie> {
        val raw = prefs.getString("host_$host", null) ?: return emptyList()
        return raw.lineSequence().mapNotNull { line -> Cookie.parse(url, line) }.toList()
    }
}

/**
 * In-memory TTL DNS Cache with optional Cloudflare DNS-over-HTTPS (DoH) resolver.
 */
class CachingAuroraDns(
    private val dohEnabledProvider: () -> Boolean,
    private val dohDns: Dns
) : Dns {
    private data class CachedDnsEntry(val addresses: List<InetAddress>, val expiresAtMs: Long)
    private val cache = ConcurrentHashMap<String, CachedDnsEntry>()
    private val ttlMs = 5 * 60 * 1000L

    override fun lookup(hostname: String): List<InetAddress> {
        val now = System.currentTimeMillis()
        cache[hostname]?.takeIf { it.expiresAtMs > now }?.let { return it.addresses }
        val resolved = runCatching {
            if (dohEnabledProvider()) dohDns.lookup(hostname) else Dns.SYSTEM.lookup(hostname)
        }.getOrElse {
            Dns.SYSTEM.lookup(hostname)
        }
        cache[hostname] = CachedDnsEntry(resolved, now + ttlMs)
        return resolved
    }
}

/**
 * Dual-stack HTTP/2 (OkHttp) + HTTP/3 QUIC (Open-Source Embedded Cronet) networking factory.
 */
class AuroraNetworkFactory(
    context: Context,
    dohEnabledProvider: () -> Boolean = { true }
) {
    val cookieJar = EncryptedAuroraCookieJar(context)

    val cronetEngine: CronetEngine by lazy {
        val storageDir = File(context.cacheDir, "cronet_quic_cache").apply { mkdirs() }
        CronetEngine.Builder(context.applicationContext)
            .enableHttp2(true)
            .enableQuic(true)
            .enableBrotli(true)
            .setStoragePath(storageDir.absolutePath)
            .enableHttpCache(CronetEngine.Builder.HTTP_CACHE_DISK_NO_HTTP, 16L * 1024L * 1024L)
            .build()
    }

    private val bootstrapClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .build()

    private val cloudflareDoh: DnsOverHttps by lazy {
        DnsOverHttps.Builder()
            .client(bootstrapClient)
            .url("https://cloudflare-dns.com/dns-query".toHttpUrl())
            .bootstrapDnsHosts(
                InetAddress.getByName("1.1.1.1"),
                InetAddress.getByName("1.0.0.1")
            )
            .build()
    }

    val cachingDns = CachingAuroraDns(dohEnabledProvider, cloudflareDoh)

    val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(ConnectionPool(32, 5, TimeUnit.MINUTES))
            .dns(cachingDns)
            .cookieJar(cookieJar)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    /** Warms up DNS + TCP/TLS socket early as soon as a domain is recognized in Stage 0. */
    suspend fun preconnect(domain: String) = withContext(Dispatchers.IO) {
        if (domain.isBlank()) return@withContext
        runCatching {
            cachingDns.lookup(domain)
            val req = Request.Builder()
                .url("https://$domain/")
                .head()
                .header("User-Agent", DEFAULT_BROWSER_UA)
                .build()
            okHttpClient.newCall(req).execute().close()
        }.onFailure { Timber.v("Preconnect skipped for %s: %s", domain, it.message) }
    }

    companion object {
        const val DEFAULT_BROWSER_UA =
            "Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36"
    }
}

data class ProbeResult(
    val finalUrl: String,
    val sizeInfo: FileSizeInfo,
    val contentType: String?,
    val fileNameFromDisposition: String?,
    val supportsRanges: Boolean,
    val eTag: String?,
    val lastModified: String?
)

/**
 * Exact File Size Resolver implementing Section 4.5 strictly:
 * 1) HEAD -> Content-Length
 * 2) GET with Range: bytes=0-0 -> Content-Range: bytes 0-0/TOTAL
 * 3) Multi-range probe fallback
 * 4) HLS/DASH parallel HEAD segment sum (+ Init segment)
 * 5) yt-dlp filesize (EXACT) vs filesize_approx (APPROXIMATE with '≈')
 */
class ExactFileSizeResolver(private val client: OkHttpClient) {

    suspend fun probeDirectUrl(
        url: String,
        headers: Map<String, String> = emptyMap(),
        fallbackApproxBytes: Long? = null
    ): ProbeResult = withContext(Dispatchers.IO) {
        // Step 1: HEAD request
        val headReq = buildRequest(url, headers).head().build()
        var finalUrl = url
        var contentType: String? = null
        var dispositionName: String? = null
        var supportsRanges = false
        var eTag: String? = null
        var lastModified: String? = null

        runCatching {
            client.newCall(headReq).execute().use { resp ->
                finalUrl = resp.request.url.toString()
                contentType = resp.header("Content-Type")
                dispositionName = parseContentDispositionFileName(resp.header("Content-Disposition"))
                eTag = resp.header("ETag")
                lastModified = resp.header("Last-Modified")
                supportsRanges = resp.header("Accept-Ranges")?.contains("bytes", ignoreCase = true) == true
                val cl = resp.header("Content-Length")?.toLongOrNull()
                if (resp.isSuccessful && cl != null && cl > 0L) {
                    return@withContext ProbeResult(
                        finalUrl = finalUrl,
                        sizeInfo = FileSizeInfo(cl, SizePrecision.EXACT, "HEAD:Content-Length"),
                        contentType = contentType,
                        fileNameFromDisposition = dispositionName,
                        supportsRanges = supportsRanges,
                        eTag = eTag,
                        lastModified = lastModified
                    )
                }
            }
        }

        // Step 2: GET Range: bytes=0-0 -> Content-Range total
        val rangeReq = buildRequest(finalUrl, headers)
            .get()
            .header("Range", "bytes=0-0")
            .build()

        runCatching {
            client.newCall(rangeReq).execute().use { resp ->
                finalUrl = resp.request.url.toString()
                contentType = contentType ?: resp.header("Content-Type")
                dispositionName = dispositionName ?: parseContentDispositionFileName(resp.header("Content-Disposition"))
                eTag = eTag ?: resp.header("ETag")
                lastModified = lastModified ?: resp.header("Last-Modified")
                val contentRange = resp.header("Content-Range")
                val totalFromRange = parseContentRangeTotal(contentRange)
                if (resp.code == 206 && totalFromRange != null && totalFromRange > 0L) {
                    return@withContext ProbeResult(
                        finalUrl = finalUrl,
                        sizeInfo = FileSizeInfo(totalFromRange, SizePrecision.EXACT, "GET:Range0-0"),
                        contentType = contentType,
                        fileNameFromDisposition = dispositionName,
                        supportsRanges = true,
                        eTag = eTag,
                        lastModified = lastModified
                    )
                }
                val cl = resp.header("Content-Length")?.toLongOrNull()
                if (resp.isSuccessful && cl != null && cl > 1L) {
                    return@withContext ProbeResult(
                        finalUrl = finalUrl,
                        sizeInfo = FileSizeInfo(cl, SizePrecision.EXACT, "GET:Content-Length"),
                        contentType = contentType,
                        fileNameFromDisposition = dispositionName,
                        supportsRanges = resp.code == 206 || supportsRanges,
                        eTag = eTag,
                        lastModified = lastModified
                    )
                }
            }
        }

        // Step 3: Multi-range boundary probe for servers ignoring bytes=0-0
        val probePoints = listOf("bytes=0-1", "bytes=1024-1025")
        for (rangeHeader in probePoints) {
            runCatching {
                val r = buildRequest(finalUrl, headers).get().header("Range", rangeHeader).build()
                client.newCall(r).execute().use { resp ->
                    val total = parseContentRangeTotal(resp.header("Content-Range"))
                    if (total != null && total > 0L) {
                        return@withContext ProbeResult(
                            finalUrl = finalUrl,
                            sizeInfo = FileSizeInfo(total, SizePrecision.EXACT, "GET:MultiRange"),
                            contentType = contentType,
                            fileNameFromDisposition = dispositionName,
                            supportsRanges = true,
                            eTag = eTag,
                            lastModified = lastModified
                        )
                    }
                }
            }
        }

        // Fallback approximate only if explicitly provided (strictly marked APPROXIMATE with '≈')
        val fallback = if (fallbackApproxBytes != null && fallbackApproxBytes > 0L) {
            FileSizeInfo(fallbackApproxBytes, SizePrecision.APPROXIMATE, "fallback_approx")
        } else {
            FileSizeInfo(-1L, SizePrecision.UNKNOWN, "unresolved")
        }

        ProbeResult(
            finalUrl = finalUrl,
            sizeInfo = fallback,
            contentType = contentType,
            fileNameFromDisposition = dispositionName,
            supportsRanges = supportsRanges,
            eTag = eTag,
            lastModified = lastModified
        )
    }

    /**
     * Step 4: Exact sum of HLS/DASH media segments + Init segment using parallel HEAD pool.
     */
    suspend fun resolveStreamSegmentsSize(
        segmentUrls: List<String>,
        initSegmentUrl: String? = null,
        headers: Map<String, String> = emptyMap(),
        maxParallelism: Int = 24
    ): FileSizeInfo = coroutineScope {
        val allUrls = buildList {
            if (!initSegmentUrl.isNullOrBlank()) add(initSegmentUrl)
            addAll(segmentUrls)
        }
        if (allUrls.isEmpty()) return@coroutineScope FileSizeInfo(-1L, SizePrecision.UNKNOWN, "empty_manifest")

        val gate = Semaphore(maxParallelism)
        var exactCount = 0
        val sizes = allUrls.map { segUrl ->
            async(Dispatchers.IO) {
                gate.withPermit {
                    val req = buildRequest(segUrl, headers).head().build()
                    runCatching {
                        client.newCall(req).execute().use { resp ->
                            resp.header("Content-Length")?.toLongOrNull() ?: -1L
                        }
                    }.getOrDefault(-1L)
                }
            }
        }.awaitAll()

        var sum = 0L
        sizes.forEach { sz ->
            if (sz > 0L) {
                sum += sz
                exactCount++
            }
        }
        return@coroutineScope when {
            exactCount == allUrls.size && sum > 0L ->
                FileSizeInfo(sum, SizePrecision.EXACT, "HLS_DASH:HEAD_SUM")
            exactCount > 0 && sum > 0L -> {
                val estimatedTotal = (sum.toDouble() / exactCount * allUrls.size).toLong()
                FileSizeInfo(estimatedTotal, SizePrecision.APPROXIMATE, "HLS_DASH:PARTIAL_HEAD")
            }
            else -> FileSizeInfo(-1L, SizePrecision.UNKNOWN, "HLS_DASH:UNRESOLVED")
        }
    }

    private fun buildRequest(url: String, headers: Map<String, String>): Request.Builder {
        val builder = Request.Builder().url(url)
        if (headers.keys.none { it.equals("User-Agent", ignoreCase = true) }) {
            builder.header("User-Agent", AuroraNetworkFactory.DEFAULT_BROWSER_UA)
        }
        headers.forEach { (k, v) -> builder.header(k, v) }
        return builder
    }

    companion object {
        private val contentRangeRegex = Regex("""bytes\s+\d+-\d+/(\d+)""", RegexOption.IGNORE_CASE)
        private val dispositionUtf8Regex = Regex("""filename\*\s*=\s*UTF-8''([^;\r\n]+)""", RegexOption.IGNORE_CASE)
        private val dispositionBasicRegex = Regex("""filename\s*=\s*"?([^";\r\n]+)"?""", RegexOption.IGNORE_CASE)

        fun parseContentRangeTotal(header: String?): Long? {
            if (header.isNullOrBlank()) return null
            return contentRangeRegex.find(header)?.groupValues?.getOrNull(1)?.toLongOrNull()
        }

        fun parseContentDispositionFileName(header: String?): String? {
            if (header.isNullOrBlank()) return null
            dispositionUtf8Regex.find(header)?.groupValues?.getOrNull(1)?.let { encoded ->
                return runCatching { java.net.URLDecoder.decode(encoded, "UTF-8") }.getOrDefault(encoded)
            }
            return dispositionBasicRegex.find(header)?.groupValues?.getOrNull(1)?.trim()
        }
    }
}
