package com.auroraget.feature.browser

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.auroraget.core.common.UrlNormalizer
import com.auroraget.core.designsystem.components.AuroraButton
import com.auroraget.core.designsystem.components.AuroraGlassBottomSheet
import com.auroraget.core.designsystem.components.AuroraGlassPill
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.AuroraVectorIcon
import com.auroraget.core.designsystem.icons.AuroraIcons
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.core.network.EncryptedAuroraCookieJar
import com.auroraget.engine.extractors.MediaBucket
import dev.chrisbanes.haze.HazeState
import java.io.ByteArrayInputStream

/**
 * JNI interface for brave/adblock-rust compiled via cargo-ndk (libadblock_rust.so).
 * VERIFY: Compile brave/adblock-rust JNI wrapper into jniLibs/ for full Rust-speed EasyList/EasyPrivacy;
 * falls back cleanly to built-in AuroraEasyListAdBlocker Kotlin engine so AdBlock works out-of-the-box.
 */
object AdBlockRustNativeBridge {
    @Volatile
    var isNativeLoaded: Boolean = false
        private set

    init {
        isNativeLoaded = runCatching {
            System.loadLibrary("adblock_rust_jni")
            true
        }.getOrDefault(false)
    }

    external fun nativeInitFilterSet(easyListRules: String): Long
    external fun nativeShouldBlock(enginePtr: Long, url: String, sourceUrl: String, requestType: String): Boolean
}

class AuroraAdBlockEngine {
    private val blockedHosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adnxs.com",
        "popads.net", "popcash.net", "propellerads.com", "exoclick.com", "taboola.com",
        "outbrain.com", "mgid.com", "adsterra.com", "juicyads.com", "trafficjunky.net",
        "analytics.google.com", "facebook.net", "scorecardresearch.com"
    )
    private val deceptivePathRegex = Regex("""/(popunder|adclick|banner_ad|fake[-_]?download|tracking_pixel)""", RegexOption.IGNORE_CASE)
    private val whitelistedDomains = mutableSetOf<String>()

    fun toggleWhitelist(domain: String): Boolean {
        return if (whitelistedDomains.contains(domain)) {
            whitelistedDomains.remove(domain)
            false
        } else {
            whitelistedDomains.add(domain)
            true
        }
    }

    fun isWhitelisted(domain: String): Boolean = whitelistedDomains.contains(domain)

    fun shouldBlock(requestUrl: String, pageDomain: String): Boolean {
        if (isWhitelisted(pageDomain)) return false
        val host = UrlNormalizer.extractDomain(requestUrl)
        if (blockedHosts.any { host == it || host.endsWith(".$it") }) return true
        return deceptivePathRegex.containsMatchIn(requestUrl)
    }

    /** Cosmetic filter CSS injected to hide deceptive fake 'Download' overlays & ad containers. */
    val cosmeticFilterCss: String = """
        [id*="google_ads"], [class*="ad-banner"], [class*="popup-overlay"],
        .fake-download-btn, a[href*="popads"], iframe[src*="doubleclick"] {
            display: none !important; visibility: hidden !important; pointer-events: none !important;
        }
    """.trimIndent()
}

data class SniffedMediaItem(
    val url: String,
    val title: String,
    val bucket: MediaBucket,
    val mimeType: String,
    val headers: Map<String, String>,
    val isBlobUrl: Boolean = false
)

/**
 * JavaScript Sniffer injected into every WebView page to intercept:
 * - window.fetch & XMLHttpRequest media calls
 * - MediaSource / blob: streams
 * - <video>, <audio>, and <source> DOM elements
 * - Cosmetic AdBlock CSS injection
 */
private const val MEDIA_SNIFFER_INJECT_JS = """
(function() {
  if (window.__auroraSnifferInstalled) return;
  window.__auroraSnifferInstalled = true;
  const mediaExt = /\.(mp4|m3u8|mpd|webm|mp3|m4a|opus|flac|zip|pdf|apk)(\?|$)/i;
  function report(u, mime) {
    if (!u || typeof u !== 'string') return;
    if (u.startsWith('blob:') || mediaExt.test(u) || (mime && /^(video|audio)\//i.test(mime))) {
      try { AuroraSnifferBridge.onMediaSniffed(u, mime || '', document.title || ''); } catch(e) {}
    }
  }
  const origFetch = window.fetch;
  window.fetch = function(input, init) {
    const url = typeof input === 'string' ? input : (input && input.url);
    report(url, '');
    return origFetch.apply(this, arguments).then(function(resp) {
      try { report(resp.url, resp.headers.get('content-type') || ''); } catch(e) {}
      return resp;
    });
  };
  const origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(method, url) {
    this.__auroraUrl = url;
    report(url, '');
    return origOpen.apply(this, arguments);
  };
  function scanDom() {
    document.querySelectorAll('video, audio, source').forEach(function(el) {
      const src = el.currentSrc || el.src;
      if (src) report(src, el.type || el.tagName.toLowerCase() + '/mp4');
    });
  }
  setInterval(scanDom, 1800);
  scanDom();
})();
"""

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(
    initialUrl: String,
    hazeState: HazeState,
    cookieJar: EncryptedAuroraCookieJar,
    adBlockEngine: AuroraAdBlockEngine,
    isArabic: Boolean,
    onHandoffToDownloader: (SniffedMediaItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    var addressInput by remember(initialUrl) { mutableStateOf(initialUrl.ifBlank { "https://duckduckgo.com" }) }
    var activeUrl by remember(initialUrl) { mutableStateOf(addressInput) }
    var desktopMode by remember { mutableStateOf(false) }
    var privateMode by remember { mutableStateOf(false) }
    var blockedCount by remember { mutableIntStateOf(0) }
    var cfClearanceDetected by remember { mutableStateOf(false) }
    var showSniffedSheet by remember { mutableStateOf(false) }
    val sniffedItems = remember { mutableStateListOf<SniffedMediaItem>() }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    fun recordSniffed(url: String, mime: String, title: String, referer: String, ua: String) {
        if (sniffedItems.any { it.url == url }) return
        val bucket = classifyBucket(url, mime) ?: return
        val cookieHeader = CookieManager.getInstance().getCookie(url).orEmpty()
        val headers = buildMap {
            put("User-Agent", ua)
            if (referer.isNotBlank()) put("Referer", referer)
            if (cookieHeader.isNotBlank()) put("Cookie", cookieHeader)
        }
        sniffedItems.add(
            0,
            SniffedMediaItem(
                url = url,
                title = title.ifBlank { url.substringAfterLast('/').substringBefore('?') },
                bucket = bucket,
                mimeType = mime,
                headers = headers,
                isBlobUrl = url.startsWith("blob:")
            )
        )
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Glass Browser Toolbar
            AuroraGlassSurface(
                hazeState = hazeState,
                elevated = true,
                shape = AuroraTheme.shapes.squircleMedium,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BasicTextField(
                            value = addressInput,
                            onValueChange = { addressInput = it },
                            textStyle = AuroraTheme.typography.bodyMedium.copy(color = colors.textPrimary),
                            cursorBrush = SolidColor(colors.accentPrimary),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .clip(AuroraTheme.shapes.pill)
                                .background(colors.background.copy(alpha = 0.55f))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                        AuroraButton(
                            text = if (isArabic) "انتقال" else "Go",
                            onClick = {
                                activeUrl = UrlNormalizer.normalize(addressInput)
                                webViewRef?.loadUrl(activeUrl)
                            }
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AuroraGlassPill(
                            text = "←",
                            modifier = Modifier.clickable { webViewRef?.goBack() }
                        )
                        AuroraGlassPill(
                            text = "→",
                            modifier = Modifier.clickable { webViewRef?.goForward() }
                        )
                        AuroraGlassPill(
                            text = "↻",
                            modifier = Modifier.clickable { webViewRef?.reload() }
                        )
                        AuroraGlassPill(
                            text = if (desktopMode) "Desktop ✓" else "Mobile",
                            tint = if (desktopMode) colors.accentPrimary.copy(alpha = 0.35f) else null,
                            modifier = Modifier.clickable {
                                desktopMode = !desktopMode
                                webViewRef?.settings?.userAgentString = if (desktopMode) {
                                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
                                } else {
                                    com.auroraget.core.network.AuroraNetworkFactory.DEFAULT_BROWSER_UA
                                }
                                webViewRef?.reload()
                            }
                        )
                        AuroraGlassPill(
                            text = if (privateMode) "Private ✓" else "Private",
                            tint = if (privateMode) colors.accentSecondary.copy(alpha = 0.35f) else null,
                            modifier = Modifier.clickable { privateMode = !privateMode }
                        )
                        AuroraGlassPill(
                            text = "🛡 $blockedCount",
                            tint = colors.success.copy(alpha = 0.3f),
                            modifier = Modifier.clickable {
                                adBlockEngine.toggleWhitelist(UrlNormalizer.extractDomain(activeUrl))
                                webViewRef?.reload()
                            }
                        )
                        if (cfClearanceDetected) {
                            AuroraGlassPill(text = "CF OK", tint = colors.accentPrimary.copy(alpha = 0.35f))
                        }
                    }
                }
            }

            // Real Android WebView (handles Cloudflare Turnstile/JS Challenge legitimately)
            AndroidView(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = !privateMode
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        settings.userAgentString = com.auroraget.core.network.AuroraNetworkFactory.DEFAULT_BROWSER_UA
                        CookieManager.getInstance().setAcceptCookie(!privateMode)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, !privateMode)

                        addJavascriptInterface(
                            object {
                                @JavascriptInterface
                                fun onMediaSniffed(url: String, mime: String, title: String) {
                                    post {
                                        recordSniffed(url, mime, title, activeUrl, settings.userAgentString)
                                    }
                                }
                            },
                            "AuroraSnifferBridge"
                        )

                        setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
                            val name = com.auroraget.core.network.ExactFileSizeResolver
                                .parseContentDispositionFileName(contentDisposition)
                                ?: url.substringAfterLast('/').substringBefore('?')
                            recordSniffed(url, mimetype.orEmpty(), name, activeUrl, userAgent)
                            showSniffedSheet = true
                        }

                        webChromeClient = WebChromeClient()
                        webViewClient = object : WebViewClient() {
                            override fun shouldInterceptRequest(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): WebResourceResponse? {
                                val reqUrl = request?.url?.toString() ?: return null
                                val pageDomain = UrlNormalizer.extractDomain(activeUrl)
                                if (adBlockEngine.shouldBlock(reqUrl, pageDomain)) {
                                    blockedCount++
                                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                                }
                                val accept = request.requestHeaders["Accept"].orEmpty()
                                if (looksLikeMediaUrl(reqUrl) || accept.startsWith("video/") || accept.startsWith("audio/")) {
                                    post {
                                        recordSniffed(
                                            url = reqUrl,
                                            mime = accept,
                                            title = view?.title.orEmpty(),
                                            referer = request.requestHeaders["Referer"] ?: activeUrl,
                                            ua = request.requestHeaders["User-Agent"] ?: settings.userAgentString
                                        )
                                    }
                                }
                                return super.shouldInterceptRequest(view, request)
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                if (!url.isNullOrBlank()) {
                                    activeUrl = url
                                    addressInput = url
                                    // Legitimate Cloudflare cookie transfer to OkHttp/Cronet CookieJar
                                    val cookies = CookieManager.getInstance().getCookie(url).orEmpty()
                                    if (cookies.isNotBlank()) {
                                        cookieJar.importWebViewCookieHeader(url, cookies)
                                        if (cookies.contains("cf_clearance=")) {
                                            cfClearanceDetected = true
                                        }
                                    }
                                }
                                // Inject Media Sniffer + Cosmetic AdBlock CSS
                                view?.evaluateJavascript(MEDIA_SNIFFER_INJECT_JS, null)
                                val css = adBlockEngine.cosmeticFilterCss.replace("\n", " ").replace("'", "\\'")
                                view?.evaluateJavascript(
                                    "var s=document.createElement('style');s.innerHTML='$css';document.head.appendChild(s);",
                                    null
                                )
                            }
                        }
                        loadUrl(activeUrl)
                        webViewRef = this
                    }
                }
            )
            Spacer(modifier = Modifier.height(82.dp))
        }

        // Floating Glass Media Sniffer FAB with count badge
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 100.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(colors.accentPrimary, colors.accentSecondary, colors.accentTertiary)))
                .clickable { showSniffedSheet = true }
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AuroraVectorIcon(AuroraIcons.Download, tint = Color.White, size = 20.dp)
                BasicText(
                    text = "${sniffedItems.size}",
                    style = AuroraTheme.typography.titleMedium.copy(color = Color.White)
                )
            }
        }

        // Sniffed Media Glass Bottom Sheet (same 4-category experience + Cookies/Headers handoff)
        AuroraGlassBottomSheet(
            visible = showSniffedSheet,
            onDismiss = { showSniffedSheet = false },
            hazeState = hazeState,
            title = if (isArabic) "الملفات المصطادة (${sniffedItems.size})" else "Sniffed Media (${sniffedItems.size})"
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().height(320.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(sniffedItems, key = { it.url }) { item ->
                    AuroraGlassSurface(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                BasicText(
                                    text = item.title,
                                    style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary)
                                )
                                BasicText(
                                    text = "${item.bucket.name} • ${if (item.isBlobUrl) "blob:" else "Cookies+Headers ✓"}",
                                    style = AuroraTheme.typography.labelSmall.copy(color = colors.accentPrimary)
                                )
                            }
                            AuroraButton(
                                text = if (isArabic) "تحميل بالمحرك" else "Download",
                                onClick = {
                                    onHandoffToDownloader(item)
                                    showSniffedSheet = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun looksLikeMediaUrl(url: String): Boolean {
    val clean = url.substringBefore('?').lowercase()
    return clean.endsWith(".mp4") || clean.endsWith(".m3u8") || clean.endsWith(".mpd") ||
        clean.endsWith(".webm") || clean.endsWith(".mp3") || clean.endsWith(".m4a") ||
        clean.endsWith(".opus") || clean.endsWith(".flac") || clean.endsWith(".zip") ||
        clean.endsWith(".apk") || clean.endsWith(".pdf")
}

private fun classifyBucket(url: String, mime: String): MediaBucket? {
    val clean = url.substringBefore('?').lowercase()
    val m = mime.lowercase()
    return when {
        m.startsWith("video/") || clean.endsWith(".mp4") || clean.endsWith(".m3u8") ||
            clean.endsWith(".mpd") || clean.endsWith(".webm") -> MediaBucket.VIDEO
        m.startsWith("audio/") || clean.endsWith(".mp3") || clean.endsWith(".m4a") ||
            clean.endsWith(".opus") || clean.endsWith(".flac") -> MediaBucket.AUDIO
        m.startsWith("image/") || clean.endsWith(".jpg") || clean.endsWith(".png") ||
            clean.endsWith(".webp") -> MediaBucket.IMAGE
        clean.endsWith(".zip") || clean.endsWith(".apk") || clean.endsWith(".pdf") -> MediaBucket.FILE
        url.startsWith("blob:") -> MediaBucket.VIDEO
        else -> null
    }
}
