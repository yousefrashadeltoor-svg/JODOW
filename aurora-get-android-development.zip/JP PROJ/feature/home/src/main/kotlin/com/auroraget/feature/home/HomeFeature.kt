package com.auroraget.feature.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil3.compose.AsyncImage
import com.auroraget.core.common.ByteFormatters
import com.auroraget.core.common.LegalCompliance
import com.auroraget.core.common.SizePrecision
import com.auroraget.core.common.UrlNormalizer
import com.auroraget.core.designsystem.components.AuroraButton
import com.auroraget.core.designsystem.components.AuroraGlassBottomSheet
import com.auroraget.core.designsystem.components.AuroraGlassPill
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.AuroraSkeletonBox
import com.auroraget.core.designsystem.components.AuroraVectorIcon
import com.auroraget.core.designsystem.components.StreamingTextReveal
import com.auroraget.core.designsystem.icons.AuroraIcons
import com.auroraget.core.designsystem.shader.auroraGeminiGlow
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.engine.extractors.ExtractedFormatItem
import com.auroraget.engine.extractors.ExtractedMediaBundle
import com.auroraget.engine.extractors.MediaBucket
import com.auroraget.feature.analyzer.AnalyzerEvent
import com.auroraget.feature.analyzer.LinkAnalyzerPipeline
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@Immutable
data class HomeUiState(
    val urlInput: String = "",
    val editableFileName: String = "",
    val clipboardDetectedUrl: String? = null,
    val isAnalyzing: Boolean = false,
    val analyzedBundle: ExtractedMediaBundle? = null,
    val activeSheetBucket: MediaBucket? = null,
    val errorMessage: String? = null,
    val suggestBrowserSniffer: Boolean = false,
    val exactSizeTooltip: String? = null,
    val batchDetectedCount: Int = 0
)

class HomeViewModel(
    private val pipeline: LinkAnalyzerPipeline
) : ViewModel() {
    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()
    private var analyzeJob: Job? = null

    fun onUrlInputChanged(value: String) {
        val urls = UrlNormalizer.extractAllUrls(value)
        _state.update {
            it.copy(
                urlInput = value,
                batchDetectedCount = if (urls.size > 1) urls.size else 0,
                errorMessage = null,
                suggestBrowserSniffer = false
            )
        }
        // 150ms debounce & immediate cancellation of previous analysis (Section 4.2)
        analyzeJob?.cancel()
        val firstUrl = urls.firstOrNull() ?: return
        analyzeJob = viewModelScope.launch {
            delay(150L)
            startAnalysis(firstUrl)
        }
    }

    fun onClipboardDetected(url: String?) {
        if (!url.isNullOrBlank() && url != _state.value.urlInput) {
            _state.update { it.copy(clipboardDetectedUrl = url) }
        }
    }

    fun acceptClipboardUrl() {
        val detected = _state.value.clipboardDetectedUrl ?: return
        _state.update { it.copy(clipboardDetectedUrl = null) }
        onUrlInputChanged(detected)
    }

    fun onFileNameEdited(name: String) {
        _state.update { it.copy(editableFileName = name) }
    }

    fun openBucketSheet(bucket: MediaBucket) {
        _state.update { it.copy(activeSheetBucket = bucket) }
    }

    fun closeBucketSheet() {
        _state.update { it.copy(activeSheetBucket = null) }
    }

    fun showExactSizeDetail(detail: String?) {
        _state.update { it.copy(exactSizeTooltip = detail) }
    }

    fun clearInput() {
        analyzeJob?.cancel()
        _state.update { HomeUiState(clipboardDetectedUrl = it.clipboardDetectedUrl) }
    }

    private suspend fun startAnalysis(url: String) {
        _state.update { it.copy(isAnalyzing = true, errorMessage = null, suggestBrowserSniffer = false) }
        pipeline.analyze(url).collect { event ->
            when (event) {
                is AnalyzerEvent.StageUpdate -> {
                    _state.update { cur ->
                        cur.copy(
                            isAnalyzing = !event.isComplete,
                            analyzedBundle = event.bundle,
                            editableFileName = cur.editableFileName.ifBlank { event.bundle.suggestedFileName },
                            suggestBrowserSniffer = event.bundle.requiresWebViewSniffer
                        )
                    }
                }
                is AnalyzerEvent.Error -> {
                    _state.update {
                        it.copy(
                            isAnalyzing = false,
                            errorMessage = event.message,
                            suggestBrowserSniffer = event.suggestWebViewSniffer
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    state: HomeUiState,
    hazeState: HazeState,
    isArabic: Boolean,
    onInputChanged: (String) -> Unit,
    onPasteFromClipboard: () -> Unit,
    onAcceptClipboardChip: () -> Unit,
    onClear: () -> Unit,
    onFileNameEdited: (String) -> Unit,
    onOpenBucket: (MediaBucket) -> Unit,
    onCloseBucket: () -> Unit,
    onDownloadFormat: (ExtractedFormatItem, String) -> Unit,
    onConvertFormat: (ExtractedFormatItem) -> Unit,
    onOpenInBrowserSniffer: (String) -> Unit,
    onLongPressSize: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    val bundle = state.analyzedBundle

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Spacer(modifier = Modifier.height(12.dp)) }

            // Header with animated Aurora title
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        BasicText(
                            text = "Aurora Get",
                            style = AuroraTheme.typography.displayLarge.copy(
                                brush = Brush.horizontalGradient(
                                    listOf(colors.accentPrimary, colors.accentSecondary, colors.accentTertiary)
                                )
                            )
                        )
                        BasicText(
                            text = if (isArabic) "محرك التحميل الزجاجي الفائق" else "Ultra-Fast Glass Downloader",
                            style = AuroraTheme.typography.bodyMedium.copy(color = colors.textSecondary)
                        )
                    }
                    AuroraGlassPill(text = if (isArabic) "HTTP/3 • 32x" else "HTTP/3 • 32x")
                }
            }

            // Clipboard Auto-Detect Floating Chip (non-intrusive)
            if (!state.clipboardDetectedUrl.isNullOrBlank()) {
                item {
                    AuroraGlassSurface(
                        hazeState = hazeState,
                        shape = AuroraTheme.shapes.pill,
                        glowColor = colors.accentSecondary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onAcceptClipboardChip() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AuroraVectorIcon(AuroraIcons.Sparkle, tint = colors.accentPrimary, size = 18.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                BasicText(
                                    text = if (isArabic) "رابط مكتشف في الحافظة — اضغط للتحليل" else "Link detected in clipboard — Tap to analyze",
                                    style = AuroraTheme.typography.labelLarge.copy(color = colors.textPrimary)
                                )
                            }
                        }
                    }
                }
            }

            // Giant Glowing Gemini-Style Glass Paste Field
            item {
                AuroraGlassSurface(
                    hazeState = hazeState,
                    elevated = true,
                    shape = AuroraTheme.shapes.squircleHero,
                    glowColor = if (state.isAnalyzing) colors.accentPrimary else null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .auroraGeminiGlow(active = state.isAnalyzing, cornerRadius = 32.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        BasicTextField(
                            value = state.urlInput,
                            onValueChange = onInputChanged,
                            textStyle = AuroraTheme.typography.bodyLarge.copy(color = colors.textPrimary),
                            cursorBrush = SolidColor(colors.accentPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            decorationBox = { inner ->
                                if (state.urlInput.isBlank()) {
                                    BasicText(
                                        text = if (isArabic) "الصق رابط فيديو، صوت، صورة، أو عدة روابط دفعة واحدة..." else "Paste video, audio, image, file, or batch links...",
                                        style = AuroraTheme.typography.bodyLarge.copy(color = colors.textMuted)
                                    )
                                }
                                inner()
                            }
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AuroraButton(
                                text = if (isArabic) "لصق ذكي" else "Smart Paste",
                                onClick = onPasteFromClipboard,
                                leadingIcon = { AuroraVectorIcon(AuroraIcons.Sparkle, tint = Color.White, size = 16.dp) },
                                modifier = Modifier.weight(1f)
                            )
                            if (state.urlInput.isNotBlank()) {
                                AuroraButton(
                                    text = if (isArabic) "مسح" else "Clear",
                                    onClick = onClear,
                                    accentGradient = false
                                )
                            }
                        }
                        if (state.batchDetectedCount > 1) {
                            Spacer(modifier = Modifier.height(8.dp))
                            AuroraGlassPill(
                                text = if (isArabic) "تم رصد ${state.batchDetectedCount} روابط دفعة واحدة" else "${state.batchDetectedCount} batch links detected"
                            )
                        }
                    }
                }
            }

            // Progressive Info Card (Stage 0..4)
            if (bundle != null) {
                item {
                    AuroraGlassSurface(
                        hazeState = hazeState,
                        elevated = true,
                        shape = AuroraTheme.shapes.squircleLarge,
                        glowColor = colors.dynamicArtworkTint,
                        modifier = Modifier
                            .fillMaxWidth()
                            .auroraGeminiGlow(active = state.isAnalyzing, cornerRadius = 28.dp, borderWidth = 1.4.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Site logo + name + domain + primary type badge
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    AsyncImage(
                                        model = bundle.faviconUrl,
                                        contentDescription = bundle.siteName,
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(colors.surfaceGlass)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        BasicText(
                                            text = bundle.siteName,
                                            style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary)
                                        )
                                        BasicText(
                                            text = bundle.domain,
                                            style = AuroraTheme.typography.labelSmall.copy(color = colors.textMuted)
                                        )
                                    }
                                }
                                AuroraGlassPill(text = bundle.primaryTypeLabel)
                            }

                            // Thumbnail cover or Skeleton shimmer while streaming
                            if (!bundle.thumbnailUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = bundle.thumbnailUrl,
                                    contentDescription = bundle.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(176.dp)
                                        .clip(AuroraTheme.shapes.squircleMedium)
                                )
                            } else if (state.isAnalyzing) {
                                AuroraSkeletonBox(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(150.dp)
                                )
                            }

                            // Gemini-style Streaming Text Reveal for Title
                            StreamingTextReveal(
                                text = bundle.title,
                                style = AuroraTheme.typography.titleLarge.copy(color = colors.textPrimary)
                            )

                            // Metadata row (Author • Duration • Exact Size)
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                bundle.author?.let { AuroraGlassPill(text = it) }
                                bundle.durationSeconds?.let { AuroraGlassPill(text = ByteFormatters.formatDuration(it)) }
                                val primarySize = bundle.videoItems.firstOrNull()?.sizeInfo
                                    ?: bundle.audioItems.firstOrNull()?.sizeInfo
                                    ?: bundle.fileItems.firstOrNull()?.sizeInfo
                                if (primarySize != null && primarySize.isKnown) {
                                    AuroraGlassPill(
                                        text = primarySize.formatHuman(),
                                        modifier = Modifier.combinedClickable(
                                            onClick = {},
                                            onLongClick = { onLongPressSize(primarySize.formatExactDetail()) }
                                        )
                                    )
                                }
                            }

                            // Editable File Name before Download
                            BasicTextField(
                                value = state.editableFileName,
                                onValueChange = onFileNameEdited,
                                textStyle = AuroraTheme.typography.bodyMedium.copy(color = colors.textSecondary),
                                cursorBrush = SolidColor(colors.accentPrimary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(AuroraTheme.shapes.squircleSmall)
                                    .background(colors.background.copy(alpha = 0.45f))
                                    .border(1.dp, colors.borderSpecularBottom, AuroraTheme.shapes.squircleSmall)
                                    .padding(horizontal = 12.dp, vertical = 9.dp)
                            )

                            // THE FOUR SMART BUTTONS (Audio | Images | Video | Files)
                            // Rule 4.4: STRICTLY ONLY render buttons whose bucket has >= 1 actual item!
                            val activeBuckets = bundle.nonEmptyBuckets()
                            if (activeBuckets.isNotEmpty()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    activeBuckets.forEach { (bucket, items) ->
                                        AnimatedVisibility(
                                            visible = true,
                                            enter = fadeIn() + scaleIn(
                                                spring(dampingRatio = Spring.DampingRatioMediumBouncy)
                                            ),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            SmartBucketButton(
                                                bucket = bucket,
                                                count = items.size,
                                                isArabic = isArabic,
                                                onClick = { onOpenBucket(bucket) }
                                            )
                                        }
                                    }
                                }
                            } else if (state.isAnalyzing) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    AuroraSkeletonBox(modifier = Modifier.weight(1f).height(56.dp))
                                    AuroraSkeletonBox(modifier = Modifier.weight(1f).height(56.dp))
                                }
                            }
                        }
                    }
                }
            }

            // Smart suggestion to open in Internal Browser Media Sniffer
            if (state.suggestBrowserSniffer) {
                item {
                    AuroraGlassSurface(
                        hazeState = hazeState,
                        elevated = true,
                        glowColor = colors.warning,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            BasicText(
                                text = if (isArabic) "رابط صفحة ويب غير مباشر" else "Indirect Web Page Detected",
                                style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary)
                            )
                            AuroraButton(
                                text = if (isArabic) "افتح في المتصفح الداخلي لاصطياد الملفات" else "Open in Internal Browser to Sniff Files",
                                onClick = { onOpenInBrowserSniffer(state.urlInput) },
                                leadingIcon = { AuroraVectorIcon(AuroraIcons.Compass, tint = Color.White, size = 18.dp) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            // Long-press exact bytes banner
            if (!state.exactSizeTooltip.isNullOrBlank()) {
                item {
                    AuroraGlassSurface(
                        hazeState = hazeState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onLongPressSize(null) }
                    ) {
                        BasicText(
                            text = state.exactSizeTooltip,
                            style = AuroraTheme.typography.monoMetric.copy(color = colors.accentPrimary),
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            }

            // Legal Copyright Notice (Section 1.11)
            item {
                BasicText(
                    text = if (isArabic) LegalCompliance.COPYRIGHT_NOTICE_AR else LegalCompliance.COPYRIGHT_NOTICE_EN,
                    style = AuroraTheme.typography.labelSmall.copy(color = colors.textMuted),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                )
            }

            item { Spacer(modifier = Modifier.height(104.dp)) }
        }

        // Glass Bottom Sheet for selected Smart Bucket (Audio / Images / Video / Files)
        val selectedBucket = state.activeSheetBucket
        val bucketItems = when (selectedBucket) {
            MediaBucket.AUDIO -> bundle?.audioItems.orEmpty()
            MediaBucket.IMAGE -> bundle?.imageItems.orEmpty()
            MediaBucket.VIDEO -> bundle?.videoItems.orEmpty()
            MediaBucket.FILE -> bundle?.fileItems.orEmpty()
            null -> emptyList()
        }

        AuroraGlassBottomSheet(
            visible = selectedBucket != null,
            onDismiss = onCloseBucket,
            hazeState = hazeState,
            title = when (selectedBucket) {
                MediaBucket.AUDIO -> if (isArabic) "صوت (${bucketItems.size})" else "Audio (${bucketItems.size})"
                MediaBucket.IMAGE -> if (isArabic) "صور (${bucketItems.size})" else "Images (${bucketItems.size})"
                MediaBucket.VIDEO -> if (isArabic) "فيديو (${bucketItems.size})" else "Video (${bucketItems.size})"
                MediaBucket.FILE -> if (isArabic) "ملفات (${bucketItems.size})" else "Files (${bucketItems.size})"
                null -> ""
            }
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().height(360.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(bucketItems, key = { it.formatId }) { item ->
                    FormatRowGlassCard(
                        item = item,
                        isArabic = isArabic,
                        onDownload = {
                            onDownloadFormat(item, state.editableFileName)
                            onCloseBucket()
                        },
                        onConvert = {
                            onConvertFormat(item)
                            onCloseBucket()
                        },
                        onLongPressSize = { onLongPressSize(item.sizeInfo.formatExactDetail()) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SmartBucketButton(
    bucket: MediaBucket,
    count: Int,
    isArabic: Boolean,
    onClick: () -> Unit
) {
    val colors = AuroraTheme.colors
    val (label, icon, tint) = when (bucket) {
        MediaBucket.AUDIO -> Triple(if (isArabic) "صوت" else "Audio", AuroraIcons.AudioWave, colors.accentSecondary)
        MediaBucket.IMAGE -> Triple(if (isArabic) "صور" else "Images", AuroraIcons.ImageFrame, colors.accentTertiary)
        MediaBucket.VIDEO -> Triple(if (isArabic) "فيديو" else "Video", AuroraIcons.Film, colors.accentPrimary)
        MediaBucket.FILE -> Triple(if (isArabic) "ملفات" else "Files", AuroraIcons.FileDoc, colors.success)
    }

    AuroraGlassSurface(
        shape = AuroraTheme.shapes.squircleSmall,
        glowColor = tint,
        modifier = Modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                AuroraVectorIcon(icon, tint = tint, size = 18.dp)
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(tint.copy(alpha = 0.22f))
                        .padding(horizontal = 6.dp, vertical = 1.dp)
                ) {
                    BasicText(
                        text = count.toString(),
                        style = AuroraTheme.typography.labelSmall.copy(color = tint)
                    )
                }
            }
            BasicText(
                text = label,
                style = AuroraTheme.typography.labelLarge.copy(color = colors.textPrimary)
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FormatRowGlassCard(
    item: ExtractedFormatItem,
    isArabic: Boolean,
    onDownload: () -> Unit,
    onConvert: () -> Unit,
    onLongPressSize: () -> Unit
) {
    val colors = AuroraTheme.colors
    AuroraGlassSurface(
        shape = AuroraTheme.shapes.squircleSmall,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    BasicText(
                        text = item.label,
                        style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary)
                    )
                    AuroraGlassPill(text = item.extension.uppercase())
                    item.codec?.let { AuroraGlassPill(text = it.uppercase()) }
                    if (item.requiresAudioMerge) {
                        AuroraGlassPill(
                            text = if (isArabic) "دمج صوت تلقائي" else "Auto-Merge",
                            tint = colors.accentSecondary.copy(alpha = 0.35f)
                        )
                    }
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val isApprox = item.sizeInfo.precision == SizePrecision.APPROXIMATE
                    BasicText(
                        text = item.sizeInfo.formatHuman(),
                        style = AuroraTheme.typography.monoMetric.copy(
                            color = if (isApprox) colors.warning else colors.success
                        ),
                        modifier = Modifier.combinedClickable(
                            onClick = {},
                            onLongClick = onLongPressSize
                        )
                    )
                    if (isApprox) {
                        AuroraGlassPill(
                            text = if (isArabic) "تقريبي" else "Approx",
                            tint = colors.warning.copy(alpha = 0.25f)
                        )
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AuroraButton(
                    text = if (isArabic) "تحويل" else "Convert",
                    onClick = onConvert,
                    accentGradient = false
                )
                AuroraButton(
                    text = if (isArabic) "تحميل" else "Get",
                    onClick = onDownload
                )
            }
        }
    }
}
