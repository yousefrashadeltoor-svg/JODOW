package com.auroraget.feature.converter

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.auroraget.core.designsystem.components.AuroraButton
import com.auroraget.core.designsystem.components.AuroraGlassPill
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.engine.media.FfmpegMediaProcessor
import com.auroraget.engine.media.TargetAudioFormat
import com.auroraget.engine.media.TargetVideoFormat
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.launch
import java.io.File

data class ConversionBatchJob(
    val id: String,
    val inputFile: File,
    val targetExtension: String,
    val streamCopyAudio: Boolean,
    val status: String
)

@Composable
fun ConverterScreen(
    processor: FfmpegMediaProcessor,
    inputFiles: List<File>,
    outputDir: File,
    hazeState: HazeState,
    isArabic: Boolean,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    val scope = rememberCoroutineScope()
    var modeAudioExtract by remember { mutableStateOf(false) }
    var selectedVideoFormat by remember { mutableStateOf(TargetVideoFormat.MP4) }
    var selectedAudioFormat by remember { mutableStateOf(TargetAudioFormat.OPUS) }
    var preferStreamCopy by remember { mutableStateOf(true) }
    var bitrateKbps by remember { mutableStateOf(192) }
    val batchQueue = remember { mutableStateListOf<ConversionBatchJob>() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Spacer(modifier = Modifier.height(10.dp)) }
        item {
            BasicText(
                text = if (isArabic) "محوّل ومستخرج الصيغ" else "Format Converter & Extractor",
                style = AuroraTheme.typography.headlineMedium.copy(color = colors.textPrimary)
            )
        }

        item {
            AuroraGlassSurface(hazeState = hazeState, elevated = true, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AuroraGlassPill(
                            text = if (isArabic) "تحويل فيديو" else "Video Convert",
                            tint = if (!modeAudioExtract) colors.accentPrimary.copy(alpha = 0.45f) else null,
                            modifier = Modifier.clickable { modeAudioExtract = false }
                        )
                        AuroraGlassPill(
                            text = if (isArabic) "استخراج صوت" else "Extract Audio",
                            tint = if (modeAudioExtract) colors.accentSecondary.copy(alpha = 0.45f) else null,
                            modifier = Modifier.clickable { modeAudioExtract = true }
                        )
                    }

                    if (!modeAudioExtract) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(TargetVideoFormat.entries) { fmt ->
                                AuroraGlassPill(
                                    text = fmt.ext.uppercase(),
                                    tint = if (fmt == selectedVideoFormat) colors.accentPrimary.copy(alpha = 0.45f) else null,
                                    modifier = Modifier.clickable { selectedVideoFormat = fmt }
                                )
                            }
                        }
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(TargetAudioFormat.entries) { fmt ->
                                AuroraGlassPill(
                                    text = fmt.ext.uppercase(),
                                    tint = if (fmt == selectedAudioFormat) colors.accentSecondary.copy(alpha = 0.45f) else null,
                                    modifier = Modifier.clickable { selectedAudioFormat = fmt }
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AuroraGlassPill(
                                text = if (preferStreamCopy) "Stream Copy ✓" else "Re-encode",
                                tint = if (preferStreamCopy) colors.success.copy(alpha = 0.35f) else null,
                                modifier = Modifier.clickable { preferStreamCopy = !preferStreamCopy }
                            )
                            listOf(128, 192, 320).forEach { br ->
                                AuroraGlassPill(
                                    text = "${br}k",
                                    tint = if (bitrateKbps == br) colors.accentPrimary.copy(alpha = 0.35f) else null,
                                    modifier = Modifier.clickable { bitrateKbps = br }
                                )
                            }
                        }
                    }

                    AuroraButton(
                        text = if (isArabic) "بدء التحويل الجماعي (${inputFiles.size})" else "Start Batch Convert (${inputFiles.size})",
                        enabled = inputFiles.isNotEmpty(),
                        onClick = {
                            inputFiles.forEachIndexed { idx, file ->
                                val targetExt = if (modeAudioExtract) selectedAudioFormat.ext else selectedVideoFormat.ext
                                val jobId = "${file.name}_$idx"
                                batchQueue.add(ConversionBatchJob(jobId, file, targetExt, preferStreamCopy, "RUNNING"))
                                scope.launch {
                                    val out = File(outputDir, "${file.nameWithoutExtension}_converted.$targetExt")
                                    val res = if (modeAudioExtract) {
                                        processor.extractAudio(file, out, selectedAudioFormat, bitrateKbps, preferStreamCopy)
                                    } else {
                                        processor.convertVideo(file, out, selectedVideoFormat)
                                    }
                                    val pos = batchQueue.indexOfFirst { it.id == jobId }
                                    if (pos >= 0) {
                                        batchQueue[pos] = batchQueue[pos].copy(
                                            status = if (res.isSuccess) "COMPLETED" else "FAILED"
                                        )
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        items(batchQueue, key = { it.id }) { job ->
            AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        BasicText(job.inputFile.name, style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary))
                        BasicText("→ .${job.targetExtension.uppercase()}", style = AuroraTheme.typography.monoMetric.copy(color = colors.accentSecondary))
                    }
                    AuroraGlassPill(text = job.status)
                }
            }
        }

        item { Spacer(modifier = Modifier.height(104.dp)) }
    }
}
