package com.auroraget.feature.compressor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.auroraget.core.common.ByteFormatters
import com.auroraget.core.designsystem.components.AuroraButton
import com.auroraget.core.designsystem.components.AuroraGlassPill
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.BeforeAfterGlassSlider
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.engine.media.CompressionMode
import com.auroraget.engine.media.SmartCompressionResult
import com.auroraget.engine.media.SmartCompressorEngine
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun CompressorScreen(
    engine: SmartCompressorEngine,
    selectedFile: File?,
    outputDir: File,
    hazeState: HazeState,
    isArabic: Boolean,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(CompressionMode.LOSSLESS) }
    var isRunning by remember { mutableStateOf(false) }
    var lastResult by remember { mutableStateOf<SmartCompressionResult?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(10.dp)) }
        item {
            BasicText(
                text = if (isArabic) "أداة تصغير الحجم الذكية" else "Smart Compressor",
                style = AuroraTheme.typography.headlineMedium.copy(color = colors.textPrimary)
            )
            BasicText(
                text = if (isArabic) "الأصل محفوظ دائمًا ولا يُستبدل إلا بتأكيدك" else "Originals are never overwritten without your explicit confirmation",
                style = AuroraTheme.typography.bodyMedium.copy(color = colors.textSecondary)
            )
        }

        // Mode selector: Lossless vs Visually/Audibly Transparent (VMAF/SSIM >= 95)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AuroraGlassSurface(
                    hazeState = hazeState,
                    elevated = mode == CompressionMode.LOSSLESS,
                    glowColor = if (mode == CompressionMode.LOSSLESS) colors.success else null,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { mode = CompressionMode.LOSSLESS }
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        BasicText(
                            text = if (isArabic) "🟢 بدون فقد (Lossless)" else "🟢 Lossless",
                            style = AuroraTheme.typography.titleMedium.copy(color = colors.success)
                        )
                        BasicText(
                            text = if (isArabic) "صفر تغيير في البكسلات أو الصوت" else "Zero pixel or sample loss",
                            style = AuroraTheme.typography.labelSmall.copy(color = colors.textSecondary)
                        )
                    }
                }
                AuroraGlassSurface(
                    hazeState = hazeState,
                    elevated = mode == CompressionMode.VISUALLY_TRANSPARENT,
                    glowColor = if (mode == CompressionMode.VISUALLY_TRANSPARENT) colors.warning else null,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { mode = CompressionMode.VISUALLY_TRANSPARENT }
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        BasicText(
                            text = if (isArabic) "🟡 شفاف بصريًا" else "🟡 Transparent",
                            style = AuroraTheme.typography.titleMedium.copy(color = colors.warning)
                        )
                        BasicText(
                            text = "VMAF / SSIM ≥ 95",
                            style = AuroraTheme.typography.labelSmall.copy(color = colors.textSecondary)
                        )
                    }
                }
            }
        }

        // Interactive Before/After Glass Slider Preview
        item {
            val origLabel = lastResult?.let { "Before: ${ByteFormatters.formatBinaryUnits(it.originalBytes)}" }
                ?: (if (isArabic) "قبل التصغير" else "Before")
            val afterLabel = lastResult?.let { "After: ${ByteFormatters.formatBinaryUnits(it.compressedBytes)}" }
                ?: (if (isArabic) "بعد التصغير" else "After")

            BeforeAfterGlassSlider(
                beforeLabel = origLabel,
                afterLabel = afterLabel,
                beforeContent = {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Brush.linearGradient(listOf(colors.accentPrimary.copy(alpha = 0.5f), colors.background))),
                        contentAlignment = Alignment.Center
                    ) {
                        BasicText(
                            text = selectedFile?.name ?: (if (isArabic) "اختر ملفًا للمقارنة" else "Select a file to compare"),
                            style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary)
                        )
                    }
                },
                afterContent = {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Brush.linearGradient(listOf(colors.accentSecondary.copy(alpha = 0.5f), colors.background))),
                        contentAlignment = Alignment.Center
                    ) {
                        BasicText(
                            text = lastResult?.qualityMetricLabel ?: "SSIM ≥ 95 Verified",
                            style = AuroraTheme.typography.titleMedium.copy(color = colors.success)
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(176.dp)
            )
        }

        // Trigger Smart Compression
        item {
            AuroraButton(
                text = when {
                    isRunning -> if (isArabic) "جارٍ التحليل والتصغير..." else "Compressing & verifying..."
                    isArabic -> "ابدأ التصغير الذكي (ملف جديد آمن)"
                    else -> "Start Smart Compression (Safe Copy)"
                },
                enabled = selectedFile != null && !isRunning,
                onClick = {
                    val file = selectedFile ?: return@AuroraButton
                    scope.launch {
                        isRunning = true
                        lastResult = engine.compress(file, outputDir, mode)
                        isRunning = false
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Honest result card with exact byte diff
        lastResult?.let { res ->
            item {
                AuroraGlassSurface(
                    hazeState = hazeState,
                    elevated = true,
                    glowColor = if (res.actuallyReduced) colors.success else colors.warning,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        AuroraGlassPill(text = res.qualityMetricLabel)
                        BasicText(
                            text = res.honestReport,
                            style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary)
                        )
                        BasicText(
                            text = "Before: ${res.originalBytes} B  →  After: ${res.compressedBytes} B",
                            style = AuroraTheme.typography.monoMetric.copy(color = colors.textSecondary)
                        )
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(104.dp)) }
    }
}
