package com.auroraget.feature.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.auroraget.core.common.ByteFormatters
import com.auroraget.core.common.LegalCompliance
import com.auroraget.core.database.AppStatsEntity
import com.auroraget.core.database.AuroraUserSettings
import com.auroraget.core.designsystem.components.AuroraButton
import com.auroraget.core.designsystem.components.AuroraGlassPill
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.core.designsystem.theme.AuroraThemePreset
import dev.chrisbanes.haze.HazeState

@Composable
fun SettingsScreen(
    settings: AuroraUserSettings,
    stats: AppStatsEntity?,
    hazeState: HazeState,
    onUpdateSettings: ((AuroraUserSettings) -> AuroraUserSettings) -> Unit,
    onUpdateYtDlp: () -> Unit,
    onRunSpeedTest: () -> Unit,
    onExportBackupJson: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    val isArabic = settings.languageCode == "ar"

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(10.dp)) }
        item {
            BasicText(
                text = if (isArabic) "الإعدادات والمظهر" else "Settings & Aurora Glass",
                style = AuroraTheme.typography.headlineMedium.copy(color = colors.textPrimary)
            )
        }

        // Theme Presets + Dark AMOLED / Light + Arabic RTL / English LTR
        item {
            AuroraGlassSurface(hazeState = hazeState, elevated = true, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    BasicText(
                        text = if (isArabic) "ثيمات Aurora Glass" else "Aurora Glass Themes",
                        style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary)
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(AuroraThemePreset.entries) { preset ->
                            val selected = settings.themePreset == preset.name
                            AuroraGlassPill(
                                text = preset.name,
                                tint = if (selected) colors.accentPrimary.copy(alpha = 0.5f) else null,
                                modifier = Modifier.clickable {
                                    onUpdateSettings { it.copy(themePreset = preset.name) }
                                }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AuroraGlassPill(
                            text = if (settings.darkTheme) "AMOLED Dark ✓" else "Light Mode ✓",
                            tint = colors.accentSecondary.copy(alpha = 0.35f),
                            modifier = Modifier.clickable {
                                onUpdateSettings { it.copy(darkTheme = !it.darkTheme) }
                            }
                        )
                        AuroraGlassPill(
                            text = if (isArabic) "العربية (RTL) ✓" else "English (LTR) ✓",
                            tint = colors.accentPrimary.copy(alpha = 0.35f),
                            modifier = Modifier.clickable {
                                onUpdateSettings { it.copy(languageCode = if (it.languageCode == "ar") "en" else "ar") }
                            }
                        )
                    }
                }
            }
        }

        // Download Engine & Network controls
        item {
            AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    BasicText(
                        text = if (isArabic) "الشبكة ومحرك التجزئة" else "Network & Segmented Engine",
                        style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(8, 16, 24, 32).forEach { segs ->
                            AuroraGlassPill(
                                text = "${segs}x",
                                tint = if (settings.defaultSegments == segs) colors.accentPrimary.copy(alpha = 0.45f) else null,
                                modifier = Modifier.clickable { onUpdateSettings { it.copy(defaultSegments = segs) } }
                            )
                        }
                    }
                    SettingsToggleRow(
                        label = if (isArabic) "DNS-over-HTTPS (خصوصية وسرعة)" else "DNS-over-HTTPS (DoH)",
                        checked = settings.dohEnabled,
                        onToggle = { onUpdateSettings { it.copy(dohEnabled = !it.dohEnabled) } }
                    )
                    SettingsToggleRow(
                        label = if (isArabic) "حجب الإعلانات (adblock-rust + EasyList)" else "AdBlock (adblock-rust + EasyList)",
                        checked = settings.adBlockEnabled,
                        onToggle = { onUpdateSettings { it.copy(adBlockEnabled = !it.adBlockEnabled) } }
                    )
                    SettingsToggleRow(
                        label = if (isArabic) "مراقبة الحافظة الذكية" else "Smart Clipboard Detector",
                        checked = settings.clipboardMonitorEnabled,
                        onToggle = { onUpdateSettings { it.copy(clipboardMonitorEnabled = !it.clipboardMonitorEnabled) } }
                    )
                    SettingsToggleRow(
                        label = if (isArabic) "التحميل عبر Wi-Fi فقط" else "Wi-Fi Only Downloads",
                        checked = settings.wifiOnly,
                        onToggle = { onUpdateSettings { it.copy(wifiOnly = !it.wifiOnly) } }
                    )
                    SettingsToggleRow(
                        label = if (isArabic) "وضع التوفير في البيانات والبطارية" else "Data & Battery Saver",
                        checked = settings.dataSaverMode,
                        onToggle = { onUpdateSettings { it.copy(dataSaverMode = !it.dataSaverMode) } }
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AuroraButton(
                            text = if (isArabic) "اختبار السرعة" else "Speed Test",
                            onClick = onRunSpeedTest,
                            modifier = Modifier.weight(1f)
                        )
                        AuroraButton(
                            text = if (isArabic) "تحديث yt-dlp" else "Update yt-dlp",
                            onClick = onUpdateYtDlp,
                            accentGradient = false,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Statistics & JSON Backup
        item {
            AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    BasicText(
                        text = if (isArabic) "الإحصائيات والنسخ الاحتياطي" else "Stats & JSON Backup",
                        style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary)
                    )
                    BasicText(
                        text = "Downloaded: ${ByteFormatters.formatBinaryUnits(stats?.totalBytesDownloaded ?: 0L)}  •  Saved by Compression: ${ByteFormatters.formatBinaryUnits(stats?.totalBytesSavedByCompression ?: 0L)}",
                        style = AuroraTheme.typography.monoMetric.copy(color = colors.success)
                    )
                    AuroraButton(
                        text = if (isArabic) "تصدير نسخة احتياطية (JSON)" else "Export JSON Backup",
                        onClick = onExportBackupJson,
                        accentGradient = false
                    )
                }
            }
        }

        // Legal Disclaimer
        item {
            AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                BasicText(
                    text = if (isArabic) LegalCompliance.COPYRIGHT_NOTICE_AR else LegalCompliance.COPYRIGHT_NOTICE_EN,
                    style = AuroraTheme.typography.bodyMedium.copy(color = colors.textSecondary),
                    modifier = Modifier.padding(14.dp)
                )
            }
        }

        item { Spacer(modifier = Modifier.height(104.dp)) }
    }
}

@Composable
private fun SettingsToggleRow(
    label: String,
    checked: Boolean,
    onToggle: () -> Unit
) {
    val colors = AuroraTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle() }
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicText(label, style = AuroraTheme.typography.bodyMedium.copy(color = colors.textPrimary))
        AuroraGlassPill(
            text = if (checked) "ON" else "OFF",
            tint = if (checked) colors.success.copy(alpha = 0.35f) else null
        )
    }
}
