package com.auroraget.feature.downloads

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.auroraget.core.common.ByteFormatters
import com.auroraget.core.database.DownloadTaskDao
import com.auroraget.core.database.DownloadTaskEntity
import com.auroraget.core.designsystem.components.AuroraButton
import com.auroraget.core.designsystem.components.AuroraGlassPill
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.AuroraSpeedSparkline
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.engine.downloader.ActiveDownloadTelemetry
import com.auroraget.engine.downloader.SegmentedDownloadEngine
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class DownloadTabFilter { ALL, RUNNING, QUEUED, COMPLETED, FAILED }

data class DownloadsUiState(
    val tasks: List<DownloadTaskEntity> = emptyList(),
    val telemetry: Map<String, ActiveDownloadTelemetry> = emptyMap()
)

class DownloadsViewModel(
    private val taskDao: DownloadTaskDao,
    private val engine: SegmentedDownloadEngine
) : ViewModel() {

    val state: StateFlow<DownloadsUiState> = combine(
        taskDao.observeAllTasks(),
        engine.telemetry
    ) { tasks, telemetry ->
        DownloadsUiState(tasks, telemetry)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DownloadsUiState())

    fun pause(taskId: String) = viewModelScope.launch { engine.pause(taskId) }
    fun resume(taskId: String, segments: Int = 16) = engine.startOrResume(taskId, segments)
    fun cancel(taskId: String) = viewModelScope.launch { engine.cancel(taskId, deletePartialFile = false) }
    fun delete(taskId: String) = viewModelScope.launch {
        engine.cancel(taskId, deletePartialFile = true)
        taskDao.deleteTask(taskId)
    }

    fun reorderQueue(orderedIds: List<String>) = viewModelScope.launch {
        orderedIds.forEachIndexed { index, id ->
            taskDao.updateQueueOrder(id, index)
        }
    }
}

@Composable
fun DownloadsScreen(
    state: DownloadsUiState,
    hazeState: HazeState,
    isArabic: Boolean,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onCancel: (String) -> Unit,
    onDelete: (String) -> Unit,
    onCompressFile: (DownloadTaskEntity) -> Unit,
    onConvertFile: (DownloadTaskEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    var selectedTab by remember { mutableStateOf(DownloadTabFilter.ALL) }
    var selectedType by remember { mutableStateOf("ALL") }

    val filtered = remember(state.tasks, selectedTab, selectedType) {
        state.tasks.filter { task ->
            val statusOk = when (selectedTab) {
                DownloadTabFilter.ALL -> true
                DownloadTabFilter.RUNNING -> task.status == "RUNNING" || task.status == "MERGING"
                DownloadTabFilter.QUEUED -> task.status == "QUEUED" || task.status == "PAUSED"
                DownloadTabFilter.COMPLETED -> task.status == "COMPLETED"
                DownloadTabFilter.FAILED -> task.status == "FAILED"
            }
            val typeOk = selectedType == "ALL" || task.mediaCategory.equals(selectedType, ignoreCase = true)
            statusOk && typeOk
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))
        BasicText(
            text = if (isArabic) "مدير التحميلات" else "Download Manager",
            style = AuroraTheme.typography.headlineMedium.copy(color = colors.textPrimary)
        )

        // Status Tabs: All | Active | Queued | Completed | Failed
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val tabs = listOf(
                DownloadTabFilter.ALL to (if (isArabic) "الكل" else "All"),
                DownloadTabFilter.RUNNING to (if (isArabic) "جارٍ" else "Active"),
                DownloadTabFilter.QUEUED to (if (isArabic) "في الانتظار" else "Queued"),
                DownloadTabFilter.COMPLETED to (if (isArabic) "مكتمل" else "Completed"),
                DownloadTabFilter.FAILED to (if (isArabic) "فاشل" else "Failed")
            )
            items(tabs) { (tab, label) ->
                val active = tab == selectedTab
                AuroraGlassPill(
                    text = label,
                    tint = if (active) colors.accentPrimary.copy(alpha = 0.45f) else null,
                    modifier = Modifier.clickable { selectedTab = tab }
                )
            }
        }

        // Media Category filter
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val cats = listOf("ALL", "VIDEO", "AUDIO", "IMAGE", "FILE")
            items(cats) { cat ->
                val active = cat == selectedType
                AuroraGlassPill(
                    text = cat,
                    tint = if (active) colors.accentSecondary.copy(alpha = 0.4f) else null,
                    modifier = Modifier.clickable { selectedType = cat }
                )
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filtered, key = { it.id }) { task ->
                val live = state.telemetry[task.id]
                val downloaded = live?.downloadedBytes ?: task.downloadedBytes
                val total = live?.totalBytes ?: task.totalBytes
                val speed = live?.speedBytesPerSec ?: task.speedBytesPerSec
                val conns = live?.activeConnections ?: task.activeConnections
                val progress = if (total > 0L) (downloaded.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f

                AuroraGlassSurface(
                    hazeState = hazeState,
                    elevated = task.status == "RUNNING",
                    glowColor = if (task.status == "RUNNING") colors.accentPrimary else null,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            BasicText(
                                text = task.fileName,
                                style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary),
                                modifier = Modifier.weight(1f)
                            )
                            AuroraGlassPill(text = "${conns}x • ${task.status}")
                        }

                        // Animated Gradient Progress Bar
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(99.dp))
                                .background(colors.background.copy(alpha = 0.55f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(progress)
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(99.dp))
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(colors.accentPrimary, colors.accentSecondary, colors.accentTertiary)
                                        )
                                    )
                            )
                        }

                        // Sparkline + speed + ETA + downloaded/total
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                val sizePrefix = if (task.isSizeExact) "" else "≈ "
                                BasicText(
                                    text = "${ByteFormatters.formatBinaryUnits(downloaded)} / $sizePrefix${ByteFormatters.formatBinaryUnits(total)}",
                                    style = AuroraTheme.typography.monoMetric.copy(color = colors.textSecondary)
                                )
                                if (task.status == "RUNNING") {
                                    val eta = live?.etaSeconds?.takeIf { it >= 0 }?.let { ByteFormatters.formatDuration(it) } ?: "--:--"
                                    BasicText(
                                        text = "${ByteFormatters.formatSpeed(speed)} • ETA $eta",
                                        style = AuroraTheme.typography.monoMetric.copy(color = colors.accentPrimary)
                                    )
                                }
                            }
                            if (live != null && live.sparklineSamples.size >= 2) {
                                AuroraSpeedSparkline(
                                    samples = live.sparklineSamples,
                                    modifier = Modifier
                                        .fillMaxWidth(0.38f)
                                        .height(30.dp)
                                )
                            }
                        }

                        // Action Controls
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (task.status == "RUNNING") {
                                AuroraButton(
                                    text = if (isArabic) "إيقاف" else "Pause",
                                    onClick = { onPause(task.id) },
                                    accentGradient = false
                                )
                            } else if (task.status != "COMPLETED") {
                                AuroraButton(
                                    text = if (isArabic) "استكمال" else "Resume",
                                    onClick = { onResume(task.id) }
                                )
                            }
                            if (task.status == "COMPLETED") {
                                AuroraButton(
                                    text = if (isArabic) "تصغير" else "Compress",
                                    onClick = { onCompressFile(task) }
                                )
                                AuroraButton(
                                    text = if (isArabic) "تحويل" else "Convert",
                                    onClick = { onConvertFile(task) },
                                    accentGradient = false
                                )
                            } else {
                                AuroraButton(
                                    text = if (isArabic) "إلغاء" else "Cancel",
                                    onClick = { onCancel(task.id) },
                                    accentGradient = false
                                )
                            }
                            AuroraButton(
                                text = if (isArabic) "حذف" else "Delete",
                                onClick = { onDelete(task.id) },
                                accentGradient = false
                            )
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(104.dp)) }
        }
    }
}
