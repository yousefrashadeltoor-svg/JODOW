package com.auroraget.feature.files

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.auroraget.core.common.ByteFormatters
import com.auroraget.core.database.VaultFileEntity
import com.auroraget.core.designsystem.components.AuroraButton
import com.auroraget.core.designsystem.components.AuroraGlassPill
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.AuroraVectorIcon
import com.auroraget.core.designsystem.icons.AuroraIcons
import com.auroraget.core.designsystem.theme.AuroraTheme
import dev.chrisbanes.haze.HazeState
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Private Vault Crypto Engine using Android Keystore AES-256-GCM + BiometricPrompt gate.
 */
class PrivateVaultCrypto {
    private val keyAlias = "aurora_private_vault_aes256"

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(keyAlias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encryptToVault(source: File, vaultDir: File): Pair<File, String> {
        vaultDir.mkdirs()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        }
        val ivBase64 = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
        val encrypted = File(vaultDir, "${System.currentTimeMillis()}_${source.name}.auroraenc")
        encrypted.writeBytes(cipher.doFinal(source.readBytes()))
        return encrypted to ivBase64
    }

    fun decryptFromVault(encryptedFile: File, ivBase64: String, targetFile: File): File {
        val iv = Base64.decode(ivBase64, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        }
        targetFile.writeBytes(cipher.doFinal(encryptedFile.readBytes()))
        return targetFile
    }

    fun promptBiometricUnlock(
        activity: FragmentActivity,
        title: String,
        onUnlocked: () -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onUnlocked()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle("AES-256-GCM Encrypted Private Vault")
            .setAllowedAuthenticators(
                androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()
        prompt.authenticate(info)
    }
}

@Composable
fun FilesLibraryScreen(
    files: List<File>,
    vaultFiles: List<VaultFileEntity>,
    vaultUnlocked: Boolean,
    hazeState: HazeState,
    isArabic: Boolean,
    onRequestUnlockVault: () -> Unit,
    onMoveToVault: (File) -> Unit,
    onPlayMedia: (File) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    var showVaultTab by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Spacer(modifier = Modifier.height(10.dp)) }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicText(
                    text = if (isArabic) "المكتبة والقبو الخاص" else "Files & Private Vault",
                    style = AuroraTheme.typography.headlineMedium.copy(color = colors.textPrimary)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AuroraGlassPill(
                        text = if (isArabic) "الملفات" else "Files",
                        tint = if (!showVaultTab) colors.accentPrimary.copy(alpha = 0.4f) else null,
                        modifier = Modifier.clickable { showVaultTab = false }
                    )
                    AuroraGlassPill(
                        text = if (isArabic) "القبو 🔒" else "Vault 🔒",
                        tint = if (showVaultTab) colors.accentSecondary.copy(alpha = 0.4f) else null,
                        modifier = Modifier.clickable { showVaultTab = true }
                    )
                }
            }
        }

        if (!showVaultTab) {
            items(files, key = { it.absolutePath }) { file ->
                AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            BasicText(file.name, style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary))
                            BasicText(
                                ByteFormatters.formatBinaryUnits(file.length()),
                                style = AuroraTheme.typography.monoMetric.copy(color = colors.textSecondary)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            AuroraButton(text = if (isArabic) "تشغيل" else "Play", onClick = { onPlayMedia(file) })
                            AuroraButton(
                                text = if (isArabic) "تشفير" else "Vault",
                                onClick = { onMoveToVault(file) },
                                accentGradient = false
                            )
                        }
                    }
                }
            }
        } else if (!vaultUnlocked) {
            item {
                AuroraGlassSurface(hazeState = hazeState, elevated = true, glowColor = colors.accentSecondary, modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        AuroraVectorIcon(AuroraIcons.LockVault, tint = colors.accentSecondary, size = 36.dp)
                        BasicText(
                            text = if (isArabic) "القبو الخاص محمي بالبصمة وتشفير AES-256" else "Private Vault protected by Biometric & AES-256",
                            style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary)
                        )
                        AuroraButton(
                            text = if (isArabic) "فتح بالبصمة" else "Unlock with Biometrics",
                            onClick = onRequestUnlockVault
                        )
                    }
                }
            }
        } else {
            items(vaultFiles, key = { it.id }) { item ->
                AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            BasicText(item.originalName, style = AuroraTheme.typography.titleMedium.copy(color = colors.textPrimary))
                            BasicText("AES-256-GCM • ${ByteFormatters.formatBinaryUnits(item.sizeBytes)}", style = AuroraTheme.typography.monoMetric.copy(color = colors.success))
                        }
                        AuroraGlassPill(text = item.mediaCategory)
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(104.dp)) }
    }
}
