package com.auroraget.feature.analyzer

import android.util.LruCache
import com.auroraget.core.common.UrlNormalizer
import com.auroraget.core.database.AnalyzerCacheDao
import com.auroraget.core.database.AnalyzerCacheEntity
import com.auroraget.core.network.AuroraNetworkFactory
import com.auroraget.engine.extractors.ExtractedMediaBundle
import com.auroraget.engine.extractors.NativeFastPathExtractor
import com.auroraget.engine.extractors.YtDlpEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import timber.log.Timber

sealed interface AnalyzerEvent {
    data class StageUpdate(val bundle: ExtractedMediaBundle, val isComplete: Boolean) : AnalyzerEvent
    data class Error(val url: String, val message: String, val suggestWebViewSniffer: Boolean) : AnalyzerEvent
}

/**
 * Parallel Streaming Link Analyzer Pipeline (Section 4.2):
 * - Stage 0 (< 50ms): URL normalization, domain extraction, cache lookup, TCP/TLS preconnect
 * - Stage 1 & 2 (< 300ms..1.5s): HEAD/Range probe, High-Res Favicon, OpenGraph, Native Fast Path
 * - Stage 3 (<= 4s): Full yt-dlp multi-format extraction (1800+ sites, subtitles, covers)
 * - Stage 4 (Fallback): Jsoup + Regex scanner, else prompts internal WebView Media Sniffer
 */
class LinkAnalyzerPipeline(
    private val networkFactory: AuroraNetworkFactory,
    private val fastPathExtractor: NativeFastPathExtractor,
    private val ytDlpEngine: YtDlpEngine,
    private val cacheDao: AnalyzerCacheDao
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val memoryLru = LruCache<String, Pair<ExtractedMediaBundle, Long>>(64)
    private val cacheTtlMs = 15 * 60 * 1000L

    fun analyze(rawInput: String): Flow<AnalyzerEvent> = channelFlow {
        val normalized = UrlNormalizer.normalize(rawInput)
        val domain = UrlNormalizer.extractDomain(normalized)
        if (domain.isBlank()) {
            send(AnalyzerEvent.Error(rawInput, "Invalid URL", suggestWebViewSniffer = false))
            return@channelFlow
        }

        // Check in-memory LRU & Room TTL Cache first (< 10ms)
        val now = System.currentTimeMillis()
        val lruHit = memoryLru.get(normalized)?.takeIf { it.second > now }?.first
        if (lruHit != null) {
            send(AnalyzerEvent.StageUpdate(lruHit, isComplete = true))
            return@channelFlow
        }
        val dbHit = cacheDao.getValid(normalized, now)
        if (dbHit != null) {
            runCatching { json.decodeFromString<ExtractedMediaBundle>(dbHit.payloadJson) }.getOrNull()?.let { cached ->
                memoryLru.put(normalized, cached to dbHit.expiresAtMs)
                send(AnalyzerEvent.StageUpdate(cached, isComplete = true))
                return@channelFlow
            }
        }

        // Stage 0 (< 50ms): Emit immediate normalized metadata + launch TCP/TLS Preconnect
        val stage0 = ExtractedMediaBundle(
            normalizedUrl = normalized,
            finalUrl = normalized,
            domain = domain,
            siteName = domain.substringBefore('.').replaceFirstChar { it.uppercase() },
            faviconUrl = "https://$domain/favicon.ico",
            title = domain,
            suggestedFileName = UrlNormalizer.sanitizeFileName(domain),
            stageReached = 0
        )
        send(AnalyzerEvent.StageUpdate(stage0, isComplete = false))

        coroutineScope {
            // Parallel TCP/TLS Preconnect warm-up
            launch { networkFactory.preconnect(domain) }

            // Launch Stage 1/2 (Fast Path) and Stage 3 (Full yt-dlp) IN PARALLEL
            val fastDeferred = async { runCatching { fastPathExtractor.extractFast(normalized) }.getOrNull() }
            val ytDlpDeferred = async { ytDlpEngine.extractAllFormats(normalized).getOrNull() }

            var latest = stage0

            // Stream Stage 1/2 as soon as it arrives (< 300ms..1.5s)
            val fastResult = fastDeferred.await()
            if (fastResult != null) {
                latest = fastResult
                val isDirectBinary = fastResult.primaryTypeLabel in setOf("FILE", "IMAGE") &&
                    fastResult.nonEmptyBuckets().isNotEmpty()
                send(AnalyzerEvent.StageUpdate(latest, isComplete = isDirectBinary))
                if (isDirectBinary) {
                    saveToCache(normalized, latest)
                    ytDlpDeferred.cancel()
                    return@coroutineScope
                }
            }

            // Stream Stage 3 full formats from yt-dlp
            val ytResult = ytDlpDeferred.await()
            if (ytResult != null && ytResult.nonEmptyBuckets().isNotEmpty()) {
                val merged = ytResult.copy(
                    faviconUrl = fastResult?.faviconUrl ?: ytResult.faviconUrl
                )
                saveToCache(normalized, merged)
                send(AnalyzerEvent.StageUpdate(merged, isComplete = true))
                return@coroutineScope
            }

            // Stage 4 Fallback: Jsoup + Regex deep scan
            val fallback = runCatching { fastPathExtractor.extractJsoupRegexFallback(latest.finalUrl) }.getOrNull()
            if (fallback != null && fallback.nonEmptyBuckets().isNotEmpty()) {
                saveToCache(normalized, fallback)
                send(AnalyzerEvent.StageUpdate(fallback, isComplete = true))
                return@coroutineScope
            }

            // If still no downloadable formats found -> suggest internal WebView Media Sniffer
            val finalState = latest.copy(stageReached = 4, requiresWebViewSniffer = true)
            if (finalState.nonEmptyBuckets().isNotEmpty()) {
                saveToCache(normalized, finalState)
                send(AnalyzerEvent.StageUpdate(finalState, isComplete = true))
            } else {
                Timber.i("Direct extraction yielded no media for %s; offering WebView Sniffer", normalized)
                send(
                    AnalyzerEvent.Error(
                        url = normalized,
                        message = "Page requires browser media sniffing",
                        suggestWebViewSniffer = true
                    )
                )
            }
        }
    }.flowOn(Dispatchers.IO)

    private suspend fun saveToCache(normalizedUrl: String, bundle: ExtractedMediaBundle) {
        val now = System.currentTimeMillis()
        val expires = now + cacheTtlMs
        memoryLru.put(normalizedUrl, bundle to expires)
        runCatching {
            cacheDao.upsert(
                AnalyzerCacheEntity(
                    normalizedUrl = normalizedUrl,
                    payloadJson = json.encodeToString(bundle),
                    cachedAtMs = now,
                    expiresAtMs = expires
                )
            )
        }
    }
}
