plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.android.library) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.kotlin.serialization) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.hilt) apply false
}

// Strict policy enforcement: forbid ALL Material Design libraries (direct or transitive)
subprojects {
    configurations.all {
        exclude(group = "com.google.android.material")
        exclude(group = "androidx.compose.material")
        exclude(group = "androidx.compose.material3")
    }

    tasks.register("verifyNoMaterialDependencies") {
        group = "verification"
        description = "Fails build if any Material Design dependency slips into the dependency graph."
        doLast {
            configurations.matching { it.isCanBeResolved }.forEach { config ->
                config.resolvedConfiguration.resolvedArtifacts.forEach { artifact ->
                    val id = "${artifact.moduleVersion.id.group}:${artifact.moduleVersion.id.name}"
                    if (id.contains("material", ignoreCase = true)) {
                        throw GradleException("FORBIDDEN MATERIAL DEPENDENCY DETECTED in ${project.path} (${config.name}): $id")
                    }
                }
            }
        }
    }
}
