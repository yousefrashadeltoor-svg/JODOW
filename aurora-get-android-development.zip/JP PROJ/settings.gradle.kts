pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
        maven("https://jitpack.io")
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven("https://jitpack.io")
    }
}

rootProject.name = "AuroraGet"

include(":app")
include(":core:designsystem")
include(":core:common")
include(":core:network")
include(":core:database")
include(":engine:downloader")
include(":engine:extractors")
include(":engine:media")
include(":feature:analyzer")
include(":feature:home")
include(":feature:downloads")
include(":feature:browser")
include(":feature:converter")
include(":feature:compressor")
include(":feature:player")
include(":feature:files")
include(":feature:settings")
