# Aurora Get ProGuard / R8 Rules
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod

# Kotlinx Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.auroraget.**$$serializer { *; }
-keepclassmembers class com.auroraget.** { *** Companion; }

# yt-dlp / youtubedl-android / FFmpeg / aria2c
-keep class com.yausername.** { *; }
-dontwarn com.yausername.**

# JNI Native Bridges (adblock-rust & native compressors)
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class com.auroraget.feature.browser.AdBlockRustNativeBridge { *; }
-keep class com.auroraget.engine.media.NativeCompressorJniBridge { *; }

# Cronet HTTP/3 QUIC
-keep class org.chromium.** { *; }
-dontwarn org.chromium.**

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**

# Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
