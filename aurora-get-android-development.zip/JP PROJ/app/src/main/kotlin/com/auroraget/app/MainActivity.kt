package com.auroraget.app

import android.app.PictureInPictureParams
import android.content.ClipboardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Rational
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import com.auroraget.core.common.LegalCompliance
import com.auroraget.core.common.SizePrecision
import com.auroraget.core.common.UrlNormalizer
import com.auroraget.core.database.AuroraUserSettings
import com.auroraget.core.database.DownloadTaskEntity
import com.auroraget.core.database.VaultFileEntity
import com.auroraget.core.designsystem.components.AuroraButton
import com.auroraget.core.designsystem.components.AuroraDockDestination
import com.auroraget.core.designsystem.components.AuroraFloatingDock
import com.auroraget.core.designsystem.components.AuroraGlassPill
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.StreamingTextReveal
import com.auroraget.core.designsystem.icons.AuroraIcons
import com.auroraget.core.designsystem.shader.AuroraMeshBackdrop
import com.auroraget.core.designsystem.theme.AuroraGlassTheme
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.core.designsystem.theme.AuroraThemePreset
import com.auroraget.engine.downloader.DownloadForegroundService
import com.auroraget.feature.browser.BrowserScreen
import com.auroraget.feature.compressor.CompressorScreen
import com.auroraget.feature.converter.ConverterScreen
import com.auroraget.feature.downloads.DownloadsScreen
import com.auroraget.feature.downloads.DownloadsViewModel
import com.auroraget.feature.files.FilesLibraryScreen
import com.auroraget.feature.home.HomeScreen
import com.auroraget.feature.home.HomeViewModel
import com.auroraget.feature.player.AuroraMediaPlayerView
import com.auroraget.feature.settings.SettingsScreen
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

class MainActivity : FragmentActivity() {

    private val incomingUrlState = mutableStateOf<String?>(null)
    private val initialTabState = mutableStateOf("home")

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIncomingIntent(intent)

        val app = application as AuroraGetApplication
        val homeVm = HomeViewModel(app.analyzerPipeline)
        val downloadsVm = DownloadsViewModel(app.database.downloadTaskDao(), app.downloadEngine)
        val downloadsRoot = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "AuroraGet").apply { mkdirs() }
        val vaultDir = File(filesDir, "aurora_private_vault").apply { mkdirs() }

        setContent {
            val settings by app.preferences.settingsFlow.collectAsState(initial = AuroraUserSettings())
            val stats by app.database.appStatsDao().observeStats().collectAsState(initial = null)
            val vaultFiles by app.database.vaultDao().observeVaultFiles().collectAsState(initial = emptyList())
            val homeState by homeVm.state.collectAsState()
            val downloadsState by downloadsVm.state.collectAsState()
            val scope = rememberCoroutineScope()

            val preset = runCatching { AuroraThemePreset.valueOf(settings.themePreset) }
                .getOrDefault(AuroraThemePreset.AURORA)
            val isArabic = settings.languageCode == "ar"

            AuroraGlassTheme(preset = preset, darkTheme = settings.darkTheme, isRtl = isArabic) {
                val hazeState = remember { HazeState() }
                var selectedTab by remember { mutableStateOf(initialTabState.value) }
                var browserUrl by remember { mutableStateOf("https://duckduckgo.com") }
                var toolsSubTab by remember { mutableStateOf("compressor") }
                var activeToolFile by remember { mutableStateOf<File?>(null) }
                var playingMediaPath by remember { mutableStateOf<String?>(null) }
                var vaultUnlocked by remember { mutableStateOf(false) }

                // React to Share Intent / VIEW Intent
                LaunchedEffect(incomingUrlState.value) {
                    val shared = incomingUrlState.value
                    if (!shared.isNullOrBlank()) {
                        selectedTab = "home"
                        homeVm.onUrlInputChanged(shared)
                        incomingUrlState.value = null
                    }
                }

                // Non-intrusive Clipboard detector on focus
                LaunchedEffect(settings.clipboardMonitorEnabled) {
                    if (settings.clipboardMonitorEnabled) {
                        val cm = getSystemService(CLIPBOARD_SERVICE) as? ClipboardManager
                        val clipText = cm?.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString()
                        val firstLink = clipText?.let { UrlNormalizer.extractAllUrls(it).firstOrNull() }
                        if (!firstLink.isNullOrBlank()) homeVm.onClipboardDetected(firstLink)
                    }
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    // Animated AGSL Mesh Backdrop (with API 24-32 Brush fallback)
                    AuroraMeshBackdrop(modifier = Modifier.fillMaxSize().haze(hazeState))

                    if (!settings.onboardingCompleted) {
                        AuroraOnboardingOverlay(
                            hazeState = hazeState,
                            isArabic = isArabic,
                            onComplete = {
                                scope.launch {
                                    app.preferences.update { it.copy(onboardingCompleted = true) }
                                }
                            }
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .statusBarsPadding()
                        ) {
                            when (selectedTab) {
                                "home" -> HomeScreen(
                                    state = homeState,
                                    hazeState = hazeState,
                                    isArabic = isArabic,
                                    onInputChanged = homeVm::onUrlInputChanged,
                                    onPasteFromClipboard = {
                                        val cm = getSystemService(CLIPBOARD_SERVICE) as? ClipboardManager
                                        val txt = cm?.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString().orEmpty()
                                        if (txt.isNotBlank()) homeVm.onUrlInputChanged(txt)
                                    },
                                    onAcceptClipboardChip = homeVm::acceptClipboardUrl,
                                    onClear = homeVm::clearInput,
                                    onFileNameEdited = homeVm::onFileNameEdited,
                                    onOpenBucket = homeVm::openBucketSheet,
                                    onCloseBucket = homeVm::closeBucketSheet,
                                    onDownloadFormat = { format, customName ->
                                        scope.launch {
                                            val id = UUID.randomUUID().toString()
                                            val safeName = UrlNormalizer.sanitizeFileName(customName.ifBlank { format.label }) + ".${format.extension}"
                                            val categoryDir = File(downloadsRoot, format.bucket.name).apply { mkdirs() }
                                            val outFile = File(categoryDir, safeName)
                                            val task = DownloadTaskEntity(
                                                id = id,
                                                sourceUrl = homeState.analyzedBundle?.normalizedUrl ?: format.directUrl,
                                                directUrl = format.directUrl,
                                                fileName = safeName,
                                                outputPath = outFile.absolutePath,
                                                mediaCategory = format.bucket.name,
                                                mimeType = "${format.bucket.name.lowercase()}/${format.extension}",
                                                siteName = homeState.analyzedBundle?.siteName ?: "Direct",
                                                thumbnailUrl = homeState.analyzedBundle?.thumbnailUrl,
                                                totalBytes = format.sizeInfo.bytes,
                                                isSizeExact = format.sizeInfo.precision == SizePrecision.EXACT,
                                                activeConnections = settings.defaultSegments,
                                                headersJson = Json.encodeToString(format.headers),
                                                mergeAudioUrl = format.pairedAudioUrl,
                                                wifiOnly = settings.wifiOnly,
                                                chargingOnly = settings.chargingOnly
                                            )
                                            app.database.downloadTaskDao().upsertTask(task)
                                            startDownloadForeground(task.id, task.fileName, settings.defaultSegments)
                                            app.downloadEngine.startOrResume(task.id, settings.defaultSegments)
                                            selectedTab = "downloads"
                                        }
                                    },
                                    onConvertFormat = {
                                        toolsSubTab = "converter"
                                        selectedTab = "tools"
                                    },
                                    onOpenInBrowserSniffer = { url ->
                                        browserUrl = url
                                        selectedTab = "browser"
                                    },
                                    onLongPressSize = homeVm::showExactSizeDetail
                                )

                                "downloads" -> DownloadsScreen(
                                    state = downloadsState,
                                    hazeState = hazeState,
                                    isArabic = isArabic,
                                    onPause = downloadsVm::pause,
                                    onResume = { id -> downloadsVm.resume(id, settings.defaultSegments) },
                                    onCancel = downloadsVm::cancel,
                                    onDelete = downloadsVm::delete,
                                    onCompressFile = { task ->
                                        activeToolFile = File(task.outputPath)
                                        toolsSubTab = "compressor"
                                        selectedTab = "tools"
                                    },
                                    onConvertFile = { task ->
                                        activeToolFile = File(task.outputPath)
                                        toolsSubTab = "converter"
                                        selectedTab = "tools"
                                    }
                                )

                                "browser" -> BrowserScreen(
                                    initialUrl = browserUrl,
                                    hazeState = hazeState,
                                    cookieJar = app.networkFactory.cookieJar,
                                    adBlockEngine = app.adBlockEngine,
                                    isArabic = isArabic,
                                    onHandoffToDownloader = { sniffed ->
                                        scope.launch {
                                            val id = UUID.randomUUID().toString()
                                            val safeName = UrlNormalizer.sanitizeFileName(sniffed.title)
                                            val outFile = File(downloadsRoot, safeName)
                                            val task = DownloadTaskEntity(
                                                id = id,
                                                sourceUrl = sniffed.url,
                                                directUrl = sniffed.url,
                                                fileName = safeName,
                                                outputPath = outFile.absolutePath,
                                                mediaCategory = sniffed.bucket.name,
                                                mimeType = sniffed.mimeType,
                                                siteName = UrlNormalizer.extractDomain(sniffed.url),
                                                headersJson = Json.encodeToString(sniffed.headers),
                                                activeConnections = settings.defaultSegments
                                            )
                                            app.database.downloadTaskDao().upsertTask(task)
                                            startDownloadForeground(task.id, task.fileName, settings.defaultSegments)
                                            app.downloadEngine.startOrResume(task.id, settings.defaultSegments)
                                            selectedTab = "downloads"
                                        }
                                    }
                                )

                                "tools" -> Column(modifier = Modifier.fillMaxSize()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        AuroraGlassPill(
                                            text = if (isArabic) "تصغير ذكي" else "Smart Compressor",
                                            tint = if (toolsSubTab == "compressor") AuroraTheme.colors.accentPrimary.copy(alpha = 0.45f) else null,
                                            modifier = Modifier.weight(1f).padding(2.dp)
                                        )
                                        AuroraGlassPill(
                                            text = if (isArabic) "تحويل الصيغ" else "Converter",
                                            tint = if (toolsSubTab == "converter") AuroraTheme.colors.accentSecondary.copy(alpha = 0.45f) else null,
                                            modifier = Modifier.weight(1f).padding(2.dp)
                                        )
                                    }
                                    if (toolsSubTab == "compressor") {
                                        CompressorScreen(
                                            engine = app.smartCompressor,
                                            selectedFile = activeToolFile ?: downloadsRoot.walkTopDown().firstOrNull { it.isFile },
                                            outputDir = File(downloadsRoot, "Compressed"),
                                            hazeState = hazeState,
                                            isArabic = isArabic
                                        )
                                    } else {
                                        ConverterScreen(
                                            processor = app.ffmpegProcessor,
                                            inputFiles = listOfNotNull(activeToolFile),
                                            outputDir = File(downloadsRoot, "Converted"),
                                            hazeState = hazeState,
                                            isArabic = isArabic
                                        )
                                    }
                                }

                                "files" -> Column(modifier = Modifier.fillMaxSize()) {
                                    playingMediaPath?.let { path ->
                                        AuroraMediaPlayerView(
                                            mediaUri = path,
                                            hazeState = hazeState,
                                            onEnterPip = { enterAuroraPip() },
                                            modifier = Modifier.padding(16.dp)
                                        )
                                    }
                                    FilesLibraryScreen(
                                        files = downloadsRoot.walkTopDown().filter { it.isFile }.toList(),
                                        vaultFiles = vaultFiles,
                                        vaultUnlocked = vaultUnlocked,
                                        hazeState = hazeState,
                                        isArabic = isArabic,
                                        onRequestUnlockVault = {
                                            app.vaultCrypto.promptBiometricUnlock(
                                                activity = this@MainActivity,
                                                title = if (isArabic) "فتح القبو الخاص" else "Unlock Private Vault",
                                                onUnlocked = { vaultUnlocked = true }
                                            )
                                        },
                                        onMoveToVault = { file ->
                                            scope.launch {
                                                val (encFile, iv) = app.vaultCrypto.encryptToVault(file, vaultDir)
                                                app.database.vaultDao().insert(
                                                    VaultFileEntity(
                                                        id = UUID.randomUUID().toString(),
                                                        originalName = file.name,
                                                        encryptedPath = encFile.absolutePath,
                                                        ivBase64 = iv,
                                                        sizeBytes = file.length(),
                                                        mediaCategory = file.extension.uppercase()
                                                    )
                                                )
                                            }
                                        },
                                        onPlayMedia = { file -> playingMediaPath = file.toURI().toString() }
                                    )
                                }

                                "settings" -> SettingsScreen(
                                    settings = settings,
                                    stats = stats,
                                    hazeState = hazeState,
                                    onUpdateSettings = { transform -> scope.launch { app.preferences.update(transform) } },
                                    onUpdateYtDlp = { scope.launch { app.ytDlpEngine.updateYtDlpBinary() } },
                                    onRunSpeedTest = {
                                        scope.launch {
                                            app.preferences.update { it.copy(defaultSegments = 24) }
                                        }
                                    },
                                    onExportBackupJson = {
                                        scope.launch {
                                            val jsonPayload = app.preferences.exportBackupJson()
                                            File(downloadsRoot, "aurora_backup.json").writeText(jsonPayload)
                                        }
                                    }
                                )
                            }

                            // Floating Glass Dock Navigation (strictly NOT Material NavigationBar)
                            val activeCount = downloadsState.tasks.count { it.status == "RUNNING" }
                            AuroraFloatingDock(
                                destinations = listOf(
                                    AuroraDockDestination("home", if (isArabic) "الرئيسية" else "Home", AuroraIcons.Sparkle),
                                    AuroraDockDestination("downloads", if (isArabic) "التحميلات" else "Queue", AuroraIcons.Download, activeCount),
                                    AuroraDockDestination("browser", if (isArabic) "المتصفح" else "Sniff", AuroraIcons.Compass),
                                    AuroraDockDestination("tools", if (isArabic) "أدوات" else "Tools", AuroraIcons.Wand),
                                    AuroraDockDestination("files", if (isArabic) "الملفات" else "Files", AuroraIcons.Folder),
                                    AuroraDockDestination("settings", if (isArabic) "الإعدادات" else "Prefs", AuroraIcons.Sliders)
                                ),
                                selectedId = selectedTab,
                                onSelect = { selectedTab = it },
                                hazeState = hazeState,
                                modifier = Modifier.align(Alignment.BottomCenter)
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_SEND -> {
                val shared = intent.getStringExtra(Intent.EXTRA_TEXT)
                val first = shared?.let { UrlNormalizer.extractAllUrls(it).firstOrNull() }
                if (!first.isNullOrBlank()) incomingUrlState.value = first
            }
            Intent.ACTION_VIEW -> {
                intent.dataString?.let { incomingUrlState.value = it }
            }
            "com.auroraget.action.OPEN_DOWNLOADS" -> initialTabState.value = "downloads"
            "com.auroraget.action.OPEN_BROWSER" -> initialTabState.value = "browser"
        }
    }

    private fun startDownloadForeground(taskId: String, title: String, segments: Int) {
        val intent = DownloadForegroundService.buildStartIntent(this, taskId, title, 0, "", segments)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun enterAuroraPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }
}

@Composable
private fun AuroraOnboardingOverlay(
    hazeState: HazeState,
    isArabic: Boolean,
    onComplete: () -> Unit
) {
    val colors = AuroraTheme.colors
    Box(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        AuroraGlassSurface(
            hazeState = hazeState,
            elevated = true,
            shape = AuroraTheme.shapes.squircleHero,
            glowColor = colors.accentPrimary,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                BasicText(
                    text = "Aurora Get",
                    style = AuroraTheme.typography.displayLarge.copy(
                        brush = Brush.horizontalGradient(
                            listOf(colors.accentPrimary, colors.accentSecondary, colors.accentTertiary)
                        )
                    )
                )
                StreamingTextReveal(
                    text = if (isArabic) {
                        "محرك تحميل مجزأ حتى 32 اتصالاً، تحليل متوازٍ لآلاف المواقع، متصفح صيد مع حجب إعلانات، وتصغير ذكي يحفظ الجودة."
                    } else {
                        "32-connection Work-Stealing downloader, parallel analyzer for 1800+ sites, AdBlock Sniffer browser, and SSIM-verified smart compressor."
                    },
                    style = AuroraTheme.typography.bodyLarge.copy(color = colors.textPrimary)
                )
                BasicText(
                    text = if (isArabic) LegalCompliance.COPYRIGHT_NOTICE_AR else LegalCompliance.COPYRIGHT_NOTICE_EN,
                    style = AuroraTheme.typography.labelSmall.copy(color = colors.textSecondary)
                )
                Spacer(modifier = Modifier.height(4.dp))
                AuroraButton(
                    text = if (isArabic) "ابدأ التجربة الزجاجية" else "Enter Aurora Get",
                    onClick = onComplete,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
