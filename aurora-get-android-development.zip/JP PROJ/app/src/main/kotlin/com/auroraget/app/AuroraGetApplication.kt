package com.auroraget.app

import android.app.Application
import com.auroraget.core.database.AuroraDatabase
import com.auroraget.core.database.AuroraPreferencesRepository
import com.auroraget.core.network.AuroraNetworkFactory
import com.auroraget.core.network.ExactFileSizeResolver
import com.auroraget.engine.downloader.DownloadForegroundService
import com.auroraget.engine.downloader.ExpiredUrlRefresher
import com.auroraget.engine.downloader.SegmentedDownloadEngine
import com.auroraget.engine.extractors.NativeFastPathExtractor
import com.auroraget.engine.extractors.YtDlpEngine
import com.auroraget.engine.media.FfmpegMediaProcessor
import com.auroraget.engine.media.SmartCompressorEngine
import com.auroraget.feature.analyzer.LinkAnalyzerPipeline
import com.auroraget.feature.browser.AuroraAdBlockEngine
import com.auroraget.feature.files.PrivateVaultCrypto
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.File

@HiltAndroidApp
class AuroraGetApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var database: AuroraDatabase private set
    lateinit var preferences: AuroraPreferencesRepository private set
    lateinit var networkFactory: AuroraNetworkFactory private set
    lateinit var sizeResolver: ExactFileSizeResolver private set
    lateinit var ytDlpEngine: YtDlpEngine private set
    lateinit var fastPathExtractor: NativeFastPathExtractor private set
    lateinit var analyzerPipeline: LinkAnalyzerPipeline private set
    lateinit var downloadEngine: SegmentedDownloadEngine private set
    lateinit var ffmpegProcessor: FfmpegMediaProcessor private set
    lateinit var smartCompressor: SmartCompressorEngine private set
    lateinit var adBlockEngine: AuroraAdBlockEngine private set
    lateinit var vaultCrypto: PrivateVaultCrypto private set

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }

        database = AuroraDatabase.build(this)
        preferences = AuroraPreferencesRepository(this)
        networkFactory = AuroraNetworkFactory(this)
        sizeResolver = ExactFileSizeResolver(networkFactory.okHttpClient)
        ytDlpEngine = YtDlpEngine(this, sizeResolver)
        fastPathExtractor = NativeFastPathExtractor(networkFactory.okHttpClient, sizeResolver)
        analyzerPipeline = LinkAnalyzerPipeline(
            networkFactory = networkFactory,
            fastPathExtractor = fastPathExtractor,
            ytDlpEngine = ytDlpEngine,
            cacheDao = database.analyzerCacheDao()
        )

        val refresher = ExpiredUrlRefresher { sourceUrl, _ ->
            ytDlpEngine.extractAllFormats(sourceUrl).getOrNull()?.videoItems?.firstOrNull()?.directUrl
        }

        downloadEngine = SegmentedDownloadEngine(
            okHttpClient = networkFactory.okHttpClient,
            taskDao = database.downloadTaskDao(),
            segmentDao = database.downloadSegmentDao(),
            sizeResolver = sizeResolver,
            urlRefresher = refresher
        )

        val ffmpegPath = File(applicationInfo.nativeLibraryDir, "libffmpeg.so").absolutePath
        ffmpegProcessor = FfmpegMediaProcessor { ffmpegPath }
        smartCompressor = SmartCompressorEngine(ffmpegProcessor)
        adBlockEngine = AuroraAdBlockEngine()
        vaultCrypto = PrivateVaultCrypto()

        // Connect Foreground Service notification actions to SegmentedDownloadEngine
        DownloadForegroundService.actionBridge = { action, taskId ->
            appScope.launch {
                when (action) {
                    DownloadForegroundService.ACTION_PAUSE -> downloadEngine.pause(taskId)
                    DownloadForegroundService.ACTION_RESUME -> downloadEngine.startOrResume(taskId)
                    DownloadForegroundService.ACTION_CANCEL -> downloadEngine.cancel(taskId)
                }
            }
        }

        // Background yt-dlp auto-update on startup if enabled
        appScope.launch {
            val prefs = preferences.settingsFlow.first()
            if (prefs.autoUpdateYtDlp) {
                ytDlpEngine.updateYtDlpBinary()
                    .onSuccess { Timber.i("yt-dlp background update status: %s", it) }
            }
        }
    }
}
