package com.auroraget.app

import com.auroraget.core.common.FileSizeInfo
import com.auroraget.core.common.SizePrecision
import com.auroraget.core.common.UrlNormalizer
import com.auroraget.core.network.ExactFileSizeResolver
import com.auroraget.engine.extractors.ExtractedFormatItem
import com.auroraget.engine.extractors.ExtractedMediaBundle
import com.auroraget.engine.extractors.MediaBucket
import kotlinx.coroutines.test.runTest
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AuroraCoreTests {

    @Test
    fun `exact size never shows tilde while approximate size always shows tilde`() {
        val exact = FileSizeInfo(148_372_910L, SizePrecision.EXACT, "HEAD:Content-Length")
        val approx = FileSizeInfo(148_372_910L, SizePrecision.APPROXIMATE, "yt-dlp:filesize_approx")

        assertFalse(exact.formatHuman().contains("≈"))
        assertTrue(approx.formatHuman().startsWith("≈ "))
        assertTrue(exact.formatExactDetail().contains("148,372,910 bytes"))
    }

    @Test
    fun `exact file size resolver falls back from HEAD to GET Range 0-0 Content-Range`() = runTest {
        val server = MockWebServer()
        // 1) HEAD without Content-Length
        server.enqueue(MockResponse().setResponseCode(200))
        // 2) GET Range: bytes=0-0 returning Content-Range total
        server.enqueue(
            MockResponse()
                .setResponseCode(206)
                .setHeader("Content-Range", "bytes 0-0/52428800")
                .setHeader("Accept-Ranges", "bytes")
                .setHeader("ETag", "\"aurora-etag-1\"")
                .setBody("A")
        )
        server.start()
        try {
            val resolver = ExactFileSizeResolver(OkHttpClient())
            val result = resolver.probeDirectUrl(server.url("/video.mp4").toString())
            assertEquals(52_428_800L, result.sizeInfo.bytes)
            assertEquals(SizePrecision.EXACT, result.sizeInfo.precision)
            assertTrue(result.supportsRanges)
            assertEquals("\"aurora-etag-1\"", result.eTag)
        } finally {
            server.shutdown()
        }
    }

    @Test
    fun `smart four buttons strictly omit empty buckets`() {
        val bundle = ExtractedMediaBundle(
            normalizedUrl = "https://tiktok.com/@aurora/video/123",
            finalUrl = "https://tiktok.com/@aurora/video/123",
            domain = "tiktok.com",
            siteName = "TikTok",
            faviconUrl = null,
            title = "Aurora Glass Demo",
            suggestedFileName = "Aurora_Glass_Demo",
            audioItems = listOf(
                ExtractedFormatItem("a1", MediaBucket.AUDIO, "Original Sound", "m4a", directUrl = "https://cdn/a.m4a")
            ),
            videoItems = listOf(
                ExtractedFormatItem("v1", MediaBucket.VIDEO, "1080p No Watermark", "mp4", directUrl = "https://cdn/v.mp4")
            ),
            imageItems = emptyList(),
            fileItems = emptyList()
        )

        val visibleBuckets = bundle.nonEmptyBuckets().map { it.first }
        assertEquals(listOf(MediaBucket.AUDIO, MediaBucket.VIDEO), visibleBuckets)
        assertFalse(MediaBucket.IMAGE in visibleBuckets)
        assertFalse(MediaBucket.FILE in visibleBuckets)
    }

    @Test
    fun `url normalizer strips tracking parameters and extracts batch urls`() {
        val input = "Check https://youtube.com/watch?v=abc123&si=track99&utm_source=x and https://example.com/file.zip?fbclid=777"
        val extracted = UrlNormalizer.extractAllUrls(input)
        assertEquals(2, extracted.size)
        assertEquals("https://youtube.com/watch?v=abc123", extracted[0])
        assertEquals("https://example.com/file.zip", extracted[1])
    }
}
