pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "JO_DON"

include(":app")
include(":core:common")
include(":core:designsystem")
include(":core:network")
include(":core:database")
include(":engine:downloader")
include(":engine:extractors")
include(":engine:media")
include(":feature:analyzer")
include(":feature:home")
include(":feature:youtube")
include(":feature:downloads")
include(":feature:browser")
include(":feature:converter")
include(":feature:compressor")
include(":feature:player")
include(":feature:files")
include(":feature:settings")
