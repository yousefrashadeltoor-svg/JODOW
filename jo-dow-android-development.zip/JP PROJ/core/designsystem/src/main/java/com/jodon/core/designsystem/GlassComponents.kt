package com.jodon.core.designsystem

import android.graphics.RuntimeShader
import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeEffect
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private const val AURORA_AGSL = """
    uniform float2 resolution;
    uniform float time;
    layout(color) uniform half4 bgColor;
    layout(color) uniform half4 c1;
    layout(color) uniform half4 c2;
    layout(color) uniform half4 c3;

    half4 main(float2 fragCoord) {
        float2 uv = fragCoord / max(resolution, float2(1.0));
        float2 p1 = float2(0.22 + 0.14 * sin(time * 0.45), 0.16 + 0.10 * cos(time * 0.35));
        float2 p2 = float2(0.80 + 0.12 * cos(time * 0.40), 0.32 + 0.14 * sin(time * 0.30));
        float2 p3 = float2(0.50 + 0.15 * sin(time * 0.28), 0.85 + 0.10 * cos(time * 0.50));
        float b1 = smoothstep(0.62, 0.0, distance(uv, p1)) * 0.22;
        float b2 = smoothstep(0.58, 0.0, distance(uv, p2)) * 0.18;
        float b3 = smoothstep(0.65, 0.0, distance(uv, p3)) * 0.14;
        half4 col = bgColor;
        col.rgb += c1.rgb * half(b1) + c2.rgb * half(b2) + c3.rgb * half(b3);
        return half4(clamp(col.rgb, half3(0.0), half3(1.0)), 1.0);
    }
"""

/**
 * Real-time AGSL Mesh Gradient on Android 13+ with seamless animated radial Brush fallback on API 24–32.
 */
@Composable
fun AuroraMeshBackground(modifier: Modifier = Modifier) {
    val colors = JoTheme.colors
    val motion = JoTheme.motion
    val infinite = rememberInfiniteTransition(label = "auroraMesh")
    val durationMs = (16000 / motion.ambientSpeed.coerceAtLeast(0.3f)).roundToInt()
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 6.283185f,
        animationSpec = infiniteRepeatable(tween(durationMs, easing = LinearEasing), RepeatMode.Restart),
        label = "meshPhase"
    )

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        val shader = remember { RuntimeShader(AURORA_AGSL) }
        Canvas(modifier = modifier.fillMaxSize()) {
            shader.setFloatUniform("resolution", size.width, size.height)
            shader.setFloatUniform("time", phase)
            shader.setColorUniform("bgColor", android.graphics.Color.valueOf(colors.background.red, colors.background.green, colors.background.blue, 1f))
            shader.setColorUniform("c1", android.graphics.Color.valueOf(colors.accentPrimary.red, colors.accentPrimary.green, colors.accentPrimary.blue, 1f))
            shader.setColorUniform("c2", android.graphics.Color.valueOf(colors.accentSecondary.red, colors.accentSecondary.green, colors.accentSecondary.blue, 1f))
            shader.setColorUniform("c3", android.graphics.Color.valueOf(colors.accentTertiary.red, colors.accentTertiary.green, colors.accentTertiary.blue, 1f))
            drawRect(brush = ShaderBrush(shader))
        }
    } else {
        Canvas(modifier = modifier.fillMaxSize().background(colors.background)) {
            val w = size.width
            val h = size.height
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(colors.accentPrimary.copy(alpha = 0.20f), Color.Transparent),
                    center = Offset(w * (0.25f + 0.1f * sin(phase)), h * (0.18f + 0.08f * cos(phase))),
                    radius = w * 0.72f
                ),
                radius = w * 0.72f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(colors.accentSecondary.copy(alpha = 0.16f), Color.Transparent),
                    center = Offset(w * (0.78f + 0.1f * cos(phase)), h * 0.36f),
                    radius = w * 0.65f
                ),
                radius = w * 0.65f
            )
        }
    }
}

@Composable
fun JoText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = JoTheme.typography.body,
    color: Color = JoTheme.colors.textPrimary,
    maxLines: Int = Int.MAX_VALUE,
    gradient: Boolean = false
) {
    val resolvedStyle = if (gradient) style.copy(brush = JoTheme.colors.signatureBrush) else style.copy(color = color)
    BasicText(
        text = text,
        modifier = modifier,
        style = resolvedStyle,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun StreamingRevealText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = JoTheme.typography.titleMedium
) {
    val alpha by animateFloatAsState(targetValue = 1f, animationSpec = JoTheme.motion.spatialSpring(), label = "revA")
    val blurVal by animateDpAsState(targetValue = 0.dp, animationSpec = JoTheme.motion.spatialSpring(), label = "revB")
    JoText(
        text = text,
        style = style,
        modifier = modifier.graphicsLayer { this.alpha = alpha }.blur(blurVal)
    )
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    hazeState: HazeState? = null,
    shape: Shape = JoTheme.shapes.card,
    elevated: Boolean = false,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = JoTheme.colors
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && onClick != null) 0.975f else 1f,
        animationSpec = JoTheme.motion.snappySpring(),
        label = "cardScale"
    )
    val baseBg = if (elevated) colors.glassElevated else colors.glassSurface
    val blurModifier = if (hazeState != null) Modifier.hazeEffect(state = hazeState) else Modifier

    Column(
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .then(blurModifier)
            .background(baseBg)
            .border(1.dp, colors.specularBorderBrush, shape)
            .then(
                if (onClick != null) {
                    Modifier.clickable(interactionSource = interaction, indication = null) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onClick()
                    }
                } else Modifier
            )
            .padding(contentPadding),
        content = content
    )
}

@Composable
fun GeminiGlowInput(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    isAnalyzing: Boolean,
    modifier: Modifier = Modifier,
    trailing: @Composable (() -> Unit)? = null
) {
    val colors = JoTheme.colors
    val shape = JoTheme.shapes.input
    val infinite = rememberInfiniteTransition(label = "geminiGlow")
    val angle by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart),
        label = "glowAngle"
    )
    val borderWidth by animateDpAsState(
        targetValue = if (isAnalyzing) 2.dp else 1.dp,
        animationSpec = JoTheme.motion.snappySpring(),
        label = "glowWidth"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(colors.glassElevated)
            .drawWithCache {
                val sweep = Brush.sweepGradient(
                    listOf(
                        colors.accentPrimary,
                        colors.accentSecondary,
                        colors.accentTertiary,
                        colors.accentPrimary
                    )
                )
                onDrawWithContent {
                    drawContent()
                    if (isAnalyzing) {
                        rotate(angle) {
                            drawRect(brush = sweep, alpha = 0.22f, style = Stroke(width = borderWidth.toPx() * 2))
                        }
                    }
                }
            }
            .border(
                width = borderWidth,
                brush = if (isAnalyzing) colors.signatureBrush else colors.specularBorderBrush,
                shape = shape
            )
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.weight(1f)) {
            if (value.isEmpty()) {
                JoText(text = placeholder, color = colors.textMuted, style = JoTheme.typography.body)
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = JoTheme.typography.body.copy(color = colors.textPrimary),
                cursorBrush = SolidColor(colors.accentPrimary),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (trailing != null) {
            Spacer(Modifier.width(10.dp))
            trailing()
        }
    }
}

@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = true,
    badgeCount: Int? = null,
    leading: (@Composable () -> Unit)? = null
) {
    val colors = JoTheme.colors
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.94f else 1f,
        animationSpec = JoTheme.motion.snappySpring(),
        label = "btnScale"
    )
    val shape = JoTheme.shapes.button

    Row(
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .then(
                if (primary) Modifier.background(colors.signatureBrush)
                else Modifier.background(colors.glassElevated).border(1.dp, colors.specularBorderBrush, shape)
            )
            .clickable(interactionSource = interaction, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) {
            leading()
            Spacer(Modifier.width(8.dp))
        }
        JoText(
            text = text,
            style = JoTheme.typography.label,
            color = if (primary) Color.White else colors.textPrimary,
            maxLines = 1
        )
        if (badgeCount != null && badgeCount > 0) {
            Spacer(Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(JoTheme.shapes.pill)
                    .background(if (primary) Color.Black.copy(alpha = 0.25f) else colors.accentPrimary.copy(alpha = 0.20f))
                    .padding(horizontal = 7.dp, vertical = 2.dp)
            ) {
                JoText(
                    text = badgeCount.toString(),
                    style = JoTheme.typography.caption,
                    color = if (primary) Color.White else colors.accentPrimary
                )
            }
        }
    }
}

@Composable
fun SmartCategoryButton(
    visible: Boolean,
    label: String,
    count: Int,
    accent: Color,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // STRICT RULE 4.4: Button appears ONLY when count > 0 and visible == true.
    AnimatedVisibility(
        visible = visible && count > 0,
        enter = fadeIn(JoTheme.motion.spatialSpring()) + scaleIn(initialScale = 0.82f, animationSpec = JoTheme.motion.spatialSpring()),
        exit = fadeOut(),
        modifier = modifier
    ) {
        GlassCard(
            onClick = onClick,
            elevated = true,
            contentPadding = PaddingValues(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(JoTheme.shapes.pill)
                        .background(accent.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    JoIcon(icon = icon, tint = accent, size = 18.dp)
                }
                Box(
                    modifier = Modifier
                        .clip(JoTheme.shapes.pill)
                        .background(accent.copy(alpha = 0.22f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    JoText(text = "$count", style = JoTheme.typography.caption, color = accent)
                }
            }
            Spacer(Modifier.height(10.dp))
            JoText(text = label, style = JoTheme.typography.titleMedium, maxLines = 1)
        }
    }
}

@Composable
fun GlassBottomSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    title: String,
    hazeState: HazeState? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = JoTheme.colors
    var dragOffsetY by remember { mutableFloatStateOf(0f) }

    AnimatedVisibility(visible = visible, enter = fadeIn(), exit = fadeOut()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.54f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                ),
            contentAlignment = Alignment.BottomCenter
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = slideInVertically(JoTheme.motion.spatialSpring()) { it },
                exit = slideOutVertically { it }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .offset { IntOffset(0, dragOffsetY.coerceAtLeast(0f).roundToInt()) }
                        .pointerInput(Unit) {
                            detectVerticalDragGestures(
                                onDragEnd = {
                                    if (dragOffsetY > 180f) onDismiss()
                                    dragOffsetY = 0f
                                },
                                onVerticalDrag = { _, amount -> dragOffsetY = (dragOffsetY + amount).coerceAtLeast(0f) }
                            )
                        }
                        .clip(JoTheme.shapes.sheet)
                        .then(if (hazeState != null) Modifier.hazeEffect(state = hazeState) else Modifier)
                        .background(colors.backgroundSecondary.copy(alpha = 0.95f))
                        .border(1.dp, colors.specularBorderBrush, JoTheme.shapes.sheet)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .width(42.dp)
                            .height(4.dp)
                            .clip(JoTheme.shapes.pill)
                            .background(colors.textMuted.copy(alpha = 0.45f))
                    )
                    Spacer(Modifier.height(14.dp))
                    JoText(text = title, style = JoTheme.typography.titleLarge)
                    Spacer(Modifier.height(12.dp))
                    content()
                }
            }
        }
    }
}

@Immutable
data class DockItem(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val badge: Int = 0,
    val accentOverride: Color? = null
)

@Composable
fun FloatingGlassDock(
    items: List<DockItem>,
    selectedRoute: String,
    onSelect: (String) -> Unit,
    hazeState: HazeState? = null,
    modifier: Modifier = Modifier
) {
    val colors = JoTheme.colors
    val haptic = LocalHapticFeedback.current

    Row(
        modifier = modifier
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .fillMaxWidth()
            .clip(JoTheme.shapes.dock)
            .then(if (hazeState != null) Modifier.hazeEffect(state = hazeState) else Modifier)
            .background(colors.backgroundSecondary.copy(alpha = 0.88f))
            .border(1.dp, colors.specularBorderBrush, JoTheme.shapes.dock)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { item ->
            val selected = item.route == selectedRoute
            val activeColor = item.accentOverride ?: colors.accentPrimary
            val scale by animateFloatAsState(
                targetValue = if (selected) 1.05f else 1f,
                animationSpec = JoTheme.motion.snappySpring(),
                label = "dockScale"
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .clip(JoTheme.shapes.button)
                    .background(if (selected) activeColor.copy(alpha = 0.16f) else Color.Transparent)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(item.route)
                    }
                    .padding(vertical = 7.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                JoIcon(
                    icon = item.icon,
                    tint = if (selected) activeColor else colors.textSecondary,
                    size = 21.dp
                )
                Spacer(Modifier.height(3.dp))
                JoText(
                    text = item.label,
                    style = JoTheme.typography.caption,
                    color = if (selected) activeColor else colors.textMuted,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun SpeedSparkline(samples: List<Long>, modifier: Modifier = Modifier.height(28.dp).fillMaxWidth()) {
    val colors = JoTheme.colors
    Canvas(modifier = modifier) {
        if (samples.size < 2) return@Canvas
        val maxVal = (samples.maxOrNull() ?: 1L).coerceAtLeast(1L).toFloat()
        val stepX = size.width / (samples.size - 1)
        val path = Path()
        samples.forEachIndexed { index, value ->
            val x = index * stepX
            val y = size.height - (value / maxVal) * size.height * 0.88f
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path = path, brush = colors.signatureBrush, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round))
    }
}

/**
 * Interactive glass Before/After comparison slider used in Smart Compressor.
 */
@Composable
fun BeforeAfterGlassSlider(
    fraction: Float,
    onFractionChange: (Float) -> Unit,
    beforeContent: @Composable BoxScope.() -> Unit,
    afterContent: @Composable BoxScope.() -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = JoTheme.colors
    var widthPx by remember { mutableFloatStateOf(1f) }
    Box(
        modifier = modifier
            .clip(JoTheme.shapes.card)
            .border(1.dp, colors.specularBorderBrush, JoTheme.shapes.card)
            .onSizeChanged { widthPx = it.width.coerceAtLeast(1).toFloat() }
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, _ ->
                    onFractionChange((change.position.x / widthPx).coerceIn(0.05f, 0.95f))
                }
            }
    ) {
        afterContent()
        Box(modifier = Modifier.fillMaxHeight().fillMaxWidth(fraction).clip(JoTheme.shapes.card), content = beforeContent)
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(2.dp)
                .offset { IntOffset((widthPx * fraction).roundToInt(), 0) }
                .background(Color.White)
        )
    }
}

/**
 * Interactive visual waveform manual trim scrubber (start & end handles + live playhead) — zero number typing required.
 */
@Composable
fun VisualWaveformTrimBar(
    amplitudes: List<Float>,
    startFraction: Float,
    endFraction: Float,
    playheadFraction: Float,
    onRangeChange: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = JoTheme.colors
    var widthPx by remember { mutableFloatStateOf(1f) }
    var draggingStart by remember { mutableFloatStateOf(0f) }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(78.dp)
            .clip(JoTheme.shapes.button)
            .background(colors.glassSurface)
            .border(1.dp, colors.specularBorderBrush, JoTheme.shapes.button)
            .onSizeChanged { widthPx = it.width.coerceAtLeast(1).toFloat() }
            .pointerInput(startFraction, endFraction) {
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        val f = offset.x / widthPx
                        draggingStart = if (kotlin.math.abs(f - startFraction) <= kotlin.math.abs(f - endFraction)) 1f else -1f
                    },
                    onHorizontalDrag = { change, _ ->
                        val f = (change.position.x / widthPx).coerceIn(0f, 1f)
                        if (draggingStart > 0f) {
                            onRangeChange(f.coerceAtMost(endFraction - 0.03f), endFraction)
                        } else {
                            onRangeChange(startFraction, f.coerceAtLeast(startFraction + 0.03f))
                        }
                    }
                )
            }
    ) {
        val count = amplitudes.size.coerceAtLeast(1)
        val barWidth = size.width / count
        amplitudes.forEachIndexed { i, amp ->
            val f = i.toFloat() / count
            val inRange = f in startFraction..endFraction
            val barH = (amp.coerceIn(0.08f, 1f)) * size.height * 0.78f
            val y = (size.height - barH) / 2f
            drawLine(
                color = if (inRange) colors.accentPrimary else colors.textMuted.copy(alpha = 0.28f),
                start = Offset(i * barWidth + barWidth / 2f, y),
                end = Offset(i * barWidth + barWidth / 2f, y + barH),
                strokeWidth = (barWidth * 0.62f).coerceAtLeast(2f),
                cap = StrokeCap.Round
            )
        }
        val sx = startFraction * size.width
        val ex = endFraction * size.width
        val px = playheadFraction * size.width
        drawLine(colors.accentTertiary, Offset(sx, 0f), Offset(sx, size.height), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
        drawLine(colors.accentTertiary, Offset(ex, 0f), Offset(ex, size.height), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
        drawLine(Color.White, Offset(px, 4f), Offset(px, size.height - 4f), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
    }
}
