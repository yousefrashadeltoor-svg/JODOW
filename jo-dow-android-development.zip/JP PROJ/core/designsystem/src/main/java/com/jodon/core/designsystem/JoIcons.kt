package com.jodon.core.designsystem

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Custom non-Material vector icon renderer using pure compose.foundation Canvas.
 */
@Composable
fun JoIcon(
    icon: ImageVector,
    tint: Color = JoTheme.colors.textPrimary,
    size: Dp = 22.dp,
    modifier: Modifier = Modifier
) {
    val painter = rememberVectorPainter(image = icon)
    Canvas(modifier = modifier.size(size)) {
        with(painter) {
            draw(size = this@Canvas.size, colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(tint))
        }
    }
}

object JoIcons {
    private fun strokeIcon(name: String, block: androidx.compose.ui.graphics.vector.ImageVector.Builder.() -> Unit): ImageVector =
        ImageVector.Builder(name = name, defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f)
            .apply(block)
            .build()

    val Home: ImageVector = strokeIcon("Home") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(3f, 10.5f); lineTo(12f, 3f); lineTo(21f, 10.5f); lineTo(21f, 20f)
            lineTo(15f, 20f); lineTo(15f, 14f); lineTo(9f, 14f); lineTo(9f, 20f); lineTo(3f, 20f); close()
        }
    }

    val YouTube: ImageVector = strokeIcon("YouTube") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineJoin = StrokeJoin.Round) {
            moveTo(4f, 6f); lineTo(20f, 6f); quadTo(22f, 6f, 22f, 8.5f); lineTo(22f, 15.5f)
            quadTo(22f, 18f, 20f, 18f); lineTo(4f, 18f); quadTo(2f, 18f, 2f, 15.5f); lineTo(2f, 8.5f)
            quadTo(2f, 6f, 4f, 6f); close()
        }
        path(fill = SolidColor(Color.White), pathFillType = PathFillType.NonZero) {
            moveTo(10f, 9f); lineTo(15.5f, 12f); lineTo(10f, 15f); close()
        }
    }

    val Shorts: ImageVector = strokeIcon("Shorts") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(15.5f, 3f); lineTo(7f, 8f); quadTo(5f, 9.2f, 6.5f, 11.2f); lineTo(8.5f, 12.2f)
            lineTo(7f, 13.5f); quadTo(5f, 15.2f, 7.2f, 17f); lineTo(8.5f, 21f); lineTo(17f, 16f)
            quadTo(19f, 14.8f, 17.5f, 12.8f); lineTo(15.5f, 11.8f); lineTo(17f, 10.5f); close()
        }
        path(fill = SolidColor(Color.White)) { moveTo(10.5f, 9.5f); lineTo(14.5f, 12f); lineTo(10.5f, 14.5f); close() }
    }

    val Download: ImageVector = strokeIcon("Download") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(12f, 3f); lineTo(12f, 15f); moveTo(7f, 10.5f); lineTo(12f, 15.5f); lineTo(17f, 10.5f)
            moveTo(4f, 20f); lineTo(20f, 20f)
        }
    }

    val Video: ImageVector = strokeIcon("Video") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(3f, 6f); lineTo(15f, 6f); lineTo(15f, 18f); lineTo(3f, 18f); close()
            moveTo(15f, 10f); lineTo(21f, 7f); lineTo(21f, 17f); lineTo(15f, 14f)
        }
    }

    val Audio: ImageVector = strokeIcon("Audio") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(9f, 18f); lineTo(9f, 5f); lineTo(20f, 3f); lineTo(20f, 16f)
            moveTo(6f, 18f); quadTo(6f, 16f, 9f, 16f); quadTo(9f, 20f, 6f, 20f); close()
            moveTo(17f, 16f); quadTo(17f, 14f, 20f, 14f); quadTo(20f, 18f, 17f, 18f); close()
        }
    }

    val Image: ImageVector = strokeIcon("Image") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(4f, 4f); lineTo(20f, 4f); lineTo(20f, 20f); lineTo(4f, 20f); close()
            moveTo(4f, 16f); lineTo(9f, 11f); lineTo(14f, 16f); lineTo(17f, 13f); lineTo(20f, 16f)
        }
    }

    val File: ImageVector = strokeIcon("File") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(6f, 3f); lineTo(14f, 3f); lineTo(19f, 8f); lineTo(19f, 21f); lineTo(6f, 21f); close()
            moveTo(14f, 3f); lineTo(14f, 8f); lineTo(19f, 8f)
        }
    }

    val Tools: ImageVector = strokeIcon("Tools") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(4f, 7f); lineTo(20f, 7f); moveTo(8f, 4f); lineTo(8f, 10f)
            moveTo(4f, 17f); lineTo(20f, 17f); moveTo(16f, 14f); lineTo(16f, 20f)
        }
    }

    val Profile: ImageVector = strokeIcon("Profile") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(12f, 4f); quadTo(16f, 4f, 16f, 8f); quadTo(16f, 12f, 12f, 12f)
            quadTo(8f, 12f, 8f, 8f); quadTo(8f, 4f, 12f, 4f); close()
            moveTo(4f, 20f); quadTo(4f, 15f, 12f, 15f); quadTo(20f, 15f, 20f, 20f)
        }
    }

    val Copy: ImageVector = strokeIcon("Copy") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(9f, 9f); lineTo(20f, 9f); lineTo(20f, 20f); lineTo(9f, 20f); close()
            moveTo(5f, 15f); lineTo(4f, 15f); lineTo(4f, 4f); lineTo(15f, 4f); lineTo(15f, 5f)
        }
    }

    val Scissors: ImageVector = strokeIcon("Scissors") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round) {
            moveTo(6f, 6f); lineTo(19f, 19f); moveTo(19f, 6f); lineTo(6f, 19f)
        }
    }

    val Ringtone: ImageVector = strokeIcon("Ringtone") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(18f, 8f); quadTo(18f, 3f, 12f, 3f); quadTo(6f, 3f, 6f, 8f); lineTo(4f, 17f); lineTo(20f, 17f); close()
            moveTo(10f, 20f); lineTo(14f, 20f)
        }
    }

    val Shield: ImageVector = strokeIcon("Shield") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(12f, 3f); lineTo(20f, 6f); lineTo(20f, 12f); quadTo(20f, 18f, 12f, 21f)
            quadTo(4f, 18f, 4f, 12f); lineTo(4f, 6f); close()
        }
    }

    val Settings: ImageVector = strokeIcon("Settings") {
        path(stroke = SolidColor(Color.White), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
            moveTo(12f, 8f); quadTo(16f, 8f, 16f, 12f); quadTo(16f, 16f, 12f, 16f)
            quadTo(8f, 16f, 8f, 12f); quadTo(8f, 8f, 12f, 8f); close()
            moveTo(12f, 2f); lineTo(12f, 5f); moveTo(12f, 19f); lineTo(12f, 22f)
            moveTo(2f, 12f); lineTo(5f, 12f); moveTo(19f, 12f); lineTo(22f, 12f)
        }
    }
}
