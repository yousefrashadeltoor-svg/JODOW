package com.jodon.core.designsystem

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Six complete themes controlling colors, glass blur, specular borders, glows,
 * spring animation physics, and bundled offline realistic preview photography.
 */
enum class JoThemeId(
    val titleAr: String,
    val subtitleAr: String,
    val titleEn: String,
    @DrawableRes val previewRes: Int,
    val dampingRatio: Float,
    val stiffness: Float,
    val ambientSpeed: Float,
    val blurRadiusDp: Float
) {
    AURORA(
        titleAr = "أورورا جيميناي",
        subtitleAr = "شفق قطبي أزرق وبنفسجي ووردي ناعم",
        titleEn = "Aurora Gemini",
        previewRes = R.drawable.theme_aurora,
        dampingRatio = 0.76f,
        stiffness = Spring.StiffnessMediumLow,
        ambientSpeed = 1.0f,
        blurRadiusDp = 28f
    ),
    OCEAN(
        titleAr = "محيط عميق",
        subtitleAr = "أزرق ياقوتي وفيروزي صافي وهادي",
        titleEn = "Ocean Deep",
        previewRes = R.drawable.theme_ocean,
        dampingRatio = 0.82f,
        stiffness = Spring.StiffnessLow,
        ambientSpeed = 0.75f,
        blurRadiusDp = 32f
    ),
    SUNSET(
        titleAr = "غروب الصحراء",
        subtitleAr = "دهبي دافي مع مرجاني شيك ومريح للعين",
        titleEn = "Sunset Desert",
        previewRes = R.drawable.theme_sunset,
        dampingRatio = 0.78f,
        stiffness = Spring.StiffnessMediumLow,
        ambientSpeed = 0.85f,
        blurRadiusDp = 26f
    ),
    EMERALD(
        titleAr = "زمرد النيل",
        subtitleAr = "أخضر زمردي فخم مع إضاءة هادية",
        titleEn = "Emerald Nile",
        previewRes = R.drawable.theme_emerald,
        dampingRatio = 0.80f,
        stiffness = Spring.StiffnessMediumLow,
        ambientSpeed = 0.80f,
        blurRadiusDp = 28f
    ),
    MONO(
        titleAr = "أسود فحمي",
        subtitleAr = "أسود AMOLED صافي مع زجاج فضي راقي",
        titleEn = "Obsidian Mono",
        previewRes = R.drawable.theme_mono,
        dampingRatio = 0.88f,
        stiffness = Spring.StiffnessMedium,
        ambientSpeed = 0.50f,
        blurRadiusDp = 24f
    ),
    NEON(
        titleAr = "نيون ليلي",
        subtitleAr = "ماجنتا وسيان سريع بحركة حيوية",
        titleEn = "Cyber Neon",
        previewRes = R.drawable.theme_neon,
        dampingRatio = 0.68f,
        stiffness = Spring.StiffnessMedium,
        ambientSpeed = 1.35f,
        blurRadiusDp = 30f
    )
}

@Immutable
data class JoColors(
    val background: Color,
    val backgroundSecondary: Color,
    val glassSurface: Color,
    val glassElevated: Color,
    val glassBorderStart: Color,
    val glassBorderEnd: Color,
    val accentPrimary: Color,
    val accentSecondary: Color,
    val accentTertiary: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val success: Color,
    val warning: Color,
    val danger: Color,
    val youtubeRed: Color,
    val isDark: Boolean
) {
    val signatureBrush: Brush
        get() = Brush.linearGradient(listOf(accentPrimary, accentSecondary, accentTertiary))

    val specularBorderBrush: Brush
        get() = Brush.linearGradient(listOf(glassBorderStart, glassBorderEnd, glassBorderStart.copy(alpha = 0.14f)))

    fun tintedWithCover(coverColor: Color?): JoColors {
        if (coverColor == null) return this
        return copy(
            accentPrimary = lerp(accentPrimary, coverColor, 0.35f),
            glassBorderStart = lerp(glassBorderStart, coverColor.copy(alpha = 0.45f), 0.30f)
        )
    }
}

@Immutable
data class JoTypography(
    val hero: TextStyle,
    val titleLarge: TextStyle,
    val titleMedium: TextStyle,
    val body: TextStyle,
    val bodySmall: TextStyle,
    val label: TextStyle,
    val caption: TextStyle
)

@Immutable
data class JoShapes(
    val card: RoundedCornerShape = RoundedCornerShape(26.dp),
    val sheet: RoundedCornerShape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    val input: RoundedCornerShape = RoundedCornerShape(28.dp),
    val button: RoundedCornerShape = RoundedCornerShape(22.dp),
    val pill: RoundedCornerShape = RoundedCornerShape(999.dp),
    val dock: RoundedCornerShape = RoundedCornerShape(30.dp)
)

@Immutable
data class JoMotion(
    val dampingRatio: Float,
    val stiffness: Float,
    val ambientSpeed: Float,
    val blurRadius: Dp
) {
    fun <T> spatialSpring(): SpringSpec<T> = spring(dampingRatio = dampingRatio, stiffness = stiffness)
    fun <T> snappySpring(): SpringSpec<T> = spring(dampingRatio = 0.82f, stiffness = stiffness * 1.4f)
}

fun buildJoColors(themeId: JoThemeId, darkTheme: Boolean): JoColors {
    val (p, s, t, darkBg) = when (themeId) {
        JoThemeId.AURORA -> listOf(Color(0xFF4285F4), Color(0xFF9B72CB), Color(0xFFD96570), Color(0xFF0B0D12))
        JoThemeId.OCEAN -> listOf(Color(0xFF0EA5E9), Color(0xFF38BDF8), Color(0xFF2DD4BF), Color(0xFF060E18))
        JoThemeId.SUNSET -> listOf(Color(0xFFF59E0B), Color(0xFFF97316), Color(0xFFE11D48), Color(0xFF120B0A))
        JoThemeId.EMERALD -> listOf(Color(0xFF10B981), Color(0xFF14B8A6), Color(0xFF34D399), Color(0xFF06110E))
        JoThemeId.MONO -> listOf(Color(0xFFE2E8F0), Color(0xFF94A3B8), Color(0xFFCBD5E1), Color(0xFF000000))
        JoThemeId.NEON -> listOf(Color(0xFF22D3EE), Color(0xFFA855F7), Color(0xFFEC4899), Color(0xFF090612))
    }
    return if (darkTheme) {
        JoColors(
            background = darkBg,
            backgroundSecondary = lerp(darkBg, p, 0.08f),
            glassSurface = Color.White.copy(alpha = 0.065f),
            glassElevated = Color.White.copy(alpha = 0.11f),
            glassBorderStart = Color.White.copy(alpha = 0.24f),
            glassBorderEnd = p.copy(alpha = 0.20f),
            accentPrimary = p,
            accentSecondary = s,
            accentTertiary = t,
            textPrimary = Color(0xFFF5F7FB),
            textSecondary = Color(0xFFB3BCCB),
            textMuted = Color(0xFF778296),
            success = Color(0xFF22C55E),
            warning = Color(0xFFFBBF24),
            danger = Color(0xFFF43F5E),
            youtubeRed = Color(0xFFFF0033),
            isDark = true
        )
    } else {
        val lightAccent = if (themeId == JoThemeId.MONO) Color(0xFF18181B) else p
        JoColors(
            background = Color(0xFFF4F6FB),
            backgroundSecondary = lerp(Color(0xFFFFFFFF), lightAccent, 0.06f),
            glassSurface = Color.White.copy(alpha = 0.74f),
            glassElevated = Color.White.copy(alpha = 0.90f),
            glassBorderStart = Color.White.copy(alpha = 0.92f),
            glassBorderEnd = lightAccent.copy(alpha = 0.22f),
            accentPrimary = lightAccent,
            accentSecondary = if (themeId == JoThemeId.MONO) Color(0xFF52525B) else s,
            accentTertiary = if (themeId == JoThemeId.MONO) Color(0xFF71717A) else t,
            textPrimary = Color(0xFF0E1320),
            textSecondary = Color(0xFF475569),
            textMuted = Color(0xFF7C899E),
            success = Color(0xFF16A34A),
            warning = Color(0xFFD97706),
            danger = Color(0xFFE11D48),
            youtubeRed = Color(0xFFE6002E),
            isDark = false
        )
    }
}

// Open-license system-clean typography family; pair with bundled IBM Plex Sans Arabic / Outfit TTF in :app/res/font.
private fun defaultTypography(fontFamily: FontFamily = FontFamily.SansSerif) = JoTypography(
    hero = TextStyle(fontFamily = fontFamily, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 36.sp),
    titleLarge = TextStyle(fontFamily = fontFamily, fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontFamily = fontFamily, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 23.sp),
    body = TextStyle(fontFamily = fontFamily, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontFamily = fontFamily, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 18.sp),
    label = TextStyle(fontFamily = fontFamily, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, lineHeight = 18.sp),
    caption = TextStyle(fontFamily = fontFamily, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 15.sp)
)

val LocalJoColors = staticCompositionLocalOf { buildJoColors(JoThemeId.AURORA, darkTheme = true) }
val LocalJoTypography = staticCompositionLocalOf { defaultTypography() }
val LocalJoShapes = staticCompositionLocalOf { JoShapes() }
val LocalJoMotion = staticCompositionLocalOf {
    JoMotion(JoThemeId.AURORA.dampingRatio, JoThemeId.AURORA.stiffness, 1f, 28.dp)
}
val LocalJoThemeId = staticCompositionLocalOf { JoThemeId.AURORA }
val LocalIsArabic = staticCompositionLocalOf { true }

object JoTheme {
    val colors: JoColors @Composable get() = LocalJoColors.current
    val typography: JoTypography @Composable get() = LocalJoTypography.current
    val shapes: JoShapes @Composable get() = LocalJoShapes.current
    val motion: JoMotion @Composable get() = LocalJoMotion.current
    val themeId: JoThemeId @Composable get() = LocalJoThemeId.current
    val isArabic: Boolean @Composable get() = LocalIsArabic.current
}

@Composable
fun JoDonTheme(
    themeId: JoThemeId = JoThemeId.AURORA,
    darkTheme: Boolean = true,
    isArabic: Boolean = true,
    dynamicCoverColor: Color? = null,
    blurScale: Float = 1f,
    content: @Composable () -> Unit
) {
    val colors = buildJoColors(themeId, darkTheme).tintedWithCover(dynamicCoverColor)
    val motion = JoMotion(
        dampingRatio = themeId.dampingRatio,
        stiffness = themeId.stiffness,
        ambientSpeed = themeId.ambientSpeed,
        blurRadius = (themeId.blurRadiusDp * blurScale.coerceIn(0.4f, 1.5f)).dp
    )
    val direction = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(
        LocalJoColors provides colors,
        LocalJoTypography provides defaultTypography(),
        LocalJoShapes provides JoShapes(),
        LocalJoMotion provides motion,
        LocalJoThemeId provides themeId,
        LocalIsArabic provides isArabic,
        LocalLayoutDirection provides direction,
        content = content
    )
}
