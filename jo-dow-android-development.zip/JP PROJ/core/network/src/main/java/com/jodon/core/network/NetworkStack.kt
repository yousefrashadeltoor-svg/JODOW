package com.jodon.core.network

import android.content.Context
import android.webkit.CookieManager
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.jodon.core.common.AppDispatchers
import com.jodon.core.common.FileSizeInfo
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.Cache
import okhttp3.ConnectionPool
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.Dispatcher
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.dnsoverhttps.DnsOverHttps
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request as NpRequest
import org.schabi.newpipe.extractor.downloader.Response as NpResponse
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import java.io.File
import java.net.InetAddress
import java.net.URI
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Encrypted CookieJar syncing WebView cookies (including legitimate user-solved Cloudflare cf_clearance)
 * and matching User-Agent per domain for OkHttp, Cronet, and segmented download tasks.
 */
@Singleton
class EncryptedBridgeCookieJar @Inject constructor(
    @ApplicationContext context: Context
) : CookieJar {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "jodon_encrypted_cookies",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val uaPerHost = ConcurrentHashMap<String, String>()

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        if (cookies.isEmpty()) return
        val existing = loadForRequest(url).associateBy { it.name }.toMutableMap()
        cookies.forEach { existing[it.name] = it }
        val encoded = existing.values.joinToString("\n") { it.toString() }
        prefs.edit().putString("ck_${url.host}", encoded).apply()
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        val now = System.currentTimeMillis()
        val raw = prefs.getString("ck_${url.host}", null) ?: return emptyList()
        return raw.lineSequence()
            .mapNotNull { Cookie.parse(url, it) }
            .filter { it.expiresAt > now }
            .toList()
    }

    /**
     * Bridges legitimate WebView session & Cloudflare cf_clearance cookies directly into OkHttp.
     */
    fun importFromWebView(pageUrl: String, userAgent: String) {
        val httpUrl = pageUrl.toHttpUrlOrNull() ?: return
        uaPerHost[httpUrl.host] = userAgent
        prefs.edit().putString("ua_${httpUrl.host}", userAgent).apply()
        val rawCookieHeader = runCatching { CookieManager.getInstance().getCookie(pageUrl) }.getOrNull() ?: return
        val parsed = rawCookieHeader.split(";")
            .mapNotNull { part -> Cookie.parse(httpUrl, part.trim()) }
        saveFromResponse(httpUrl, parsed)
    }

    fun getMatchingUserAgent(url: String): String {
        val host = url.toHttpUrlOrNull()?.host
        if (host != null) {
            uaPerHost[host]?.let { return it }
            prefs.getString("ua_$host", null)?.let {
                uaPerHost[host] = it
                return it
            }
        }
        return DEFAULT_USER_AGENT
    }

    fun buildCookieHeader(url: String): String {
        val httpUrl = url.toHttpUrlOrNull() ?: return ""
        return loadForRequest(httpUrl).joinToString("; ") { "${it.name}=${it.value}" }
    }

    companion object {
        const val DEFAULT_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
    }
}

/**
 * Exact File Size Resolver implementing the strict Section 4.5 cascade:
 * 1) HEAD -> Content-Length
 * 2) GET Range: bytes=0-0 -> Content-Range: bytes 0-0/TOTAL
 * 3) HLS (.m3u8) parallel HEAD summation across all segments + EXT-X-MAP init segment
 * 4) Fallback exact vs approximate distinction ("≈" enforced for approximate).
 */
@Singleton
class ExactSizeResolver @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val cookieJar: EncryptedBridgeCookieJar,
    private val dispatchers: AppDispatchers
) {
    data class RemoteProbe(
        val size: FileSizeInfo,
        val supportsRanges: Boolean,
        val mimeType: String?,
        val fileName: String?,
        val etag: String?,
        val lastModified: String?,
        val finalUrl: String
    )

    suspend fun preconnect(url: String) = withContext(dispatchers.io) {
        val target = url.toHttpUrlOrNull() ?: return@withContext
        runCatching {
            InetAddress.getAllByName(target.host)
            val req = Request.Builder().url(target.newBuilder().encodedPath("/").query(null).build()).head().build()
            okHttpClient.newCall(req).execute().close()
        }
    }

    suspend fun probeExact(url: String, extraHeaders: Map<String, String> = emptyMap()): RemoteProbe =
        withContext(dispatchers.io) {
            val ua = extraHeaders["User-Agent"] ?: cookieJar.getMatchingUserAgent(url)
            fun Request.Builder.applyHeaders(): Request.Builder {
                header("User-Agent", ua)
                extraHeaders.forEach { (k, v) -> header(k, v) }
                return this
            }

            // Step 1: Fast HEAD request
            val headProbe = runCatching {
                okHttpClient.newCall(Request.Builder().url(url).head().applyHeaders().build()).execute().use { res ->
                    val len = res.header("Content-Length")?.toLongOrNull() ?: -1L
                    val accepts = res.header("Accept-Ranges")?.contains("bytes", ignoreCase = true) == true
                    val dispositionName = parseContentDisposition(res.header("Content-Disposition"))
                    if (res.isSuccessful && len > 0L) {
                        RemoteProbe(
                            size = FileSizeInfo(len, isExact = true, source = "HEAD"),
                            supportsRanges = accepts,
                            mimeType = res.header("Content-Type"),
                            fileName = dispositionName,
                            etag = res.header("ETag"),
                            lastModified = res.header("Last-Modified"),
                            finalUrl = res.request.url.toString()
                        )
                    } else null
                }
            }.getOrNull()
            if (headProbe != null) return@withContext headProbe

            // Step 2: GET Range: bytes=0-0 -> parse Content-Range: bytes 0-0/TOTAL
            val rangeProbe = runCatching {
                val req = Request.Builder().url(url).get().applyHeaders().header("Range", "bytes=0-0").build()
                okHttpClient.newCall(req).execute().use { res ->
                    val contentRange = res.header("Content-Range")
                    val total = contentRange?.substringAfterLast("/")?.takeIf { it != "*" }?.toLongOrNull()
                        ?: if (res.code == 200) res.header("Content-Length")?.toLongOrNull() else null
                    val supportsRange = res.code == 206 && total != null && total > 0L
                    RemoteProbe(
                        size = if (total != null && total > 0L) FileSizeInfo(total, isExact = true, source = "RANGE")
                        else FileSizeInfo(0L, isExact = false, source = "UNKNOWN"),
                        supportsRanges = supportsRange,
                        mimeType = res.header("Content-Type"),
                        fileName = parseContentDisposition(res.header("Content-Disposition")),
                        etag = res.header("ETag"),
                        lastModified = res.header("Last-Modified"),
                        finalUrl = res.request.url.toString()
                    )
                }
            }.getOrNull()

            // Step 3: If HLS playlist, sum all segments + init segment in parallel
            if (url.contains(".m3u8", ignoreCase = true) ||
                rangeProbe?.mimeType?.contains("mpegurl", ignoreCase = true) == true
            ) {
                val hlsSize = computeHlsExactSize(rangeProbe?.finalUrl ?: url, extraHeaders)
                if (hlsSize.bytes > 0L) {
                    return@withContext (rangeProbe ?: RemoteProbe(hlsSize, false, "application/vnd.apple.mpegurl", null, null, null, url))
                        .copy(size = hlsSize)
                }
            }

            rangeProbe ?: RemoteProbe(FileSizeInfo(0L, false, "NONE"), false, null, null, null, null, url)
        }

    suspend fun computeHlsExactSize(manifestUrl: String, headers: Map<String, String> = emptyMap()): FileSizeInfo =
        withContext(dispatchers.io) {
            val body = runCatching {
                val req = Request.Builder().url(manifestUrl).apply { headers.forEach { (k, v) -> header(k, v) } }.build()
                okHttpClient.newCall(req).execute().use { if (it.isSuccessful) it.body?.string() else null }
            }.getOrNull() ?: return@withContext FileSizeInfo(0L, false, "HLS")

            val baseUri = URI(manifestUrl)
            val urls = mutableListOf<String>()
            val initRegex = Regex("""#EXT-X-MAP:.*URI="([^"]+)"""")
            body.lineSequence().map { it.trim() }.forEach { line ->
                initRegex.find(line)?.groupValues?.getOrNull(1)?.let { urls += baseUri.resolve(it).toString() }
                if (line.isNotEmpty() && !line.startsWith("#")) {
                    urls += baseUri.resolve(line).toString()
                }
            }
            if (urls.isEmpty()) return@withContext FileSizeInfo(0L, false, "HLS")

            val gate = Semaphore(24)
            var allExact = true
            val total = coroutineScope {
                urls.map { segUrl ->
                    async {
                        gate.withPermit {
                            runCatching {
                                okHttpClient.newCall(Request.Builder().url(segUrl).head().build()).execute().use { r ->
                                    r.header("Content-Length")?.toLongOrNull() ?: -1L
                                }
                            }.getOrDefault(-1L)
                        }
                    }
                }.awaitAll().sumOf { len ->
                    if (len <= 0L) {
                        allExact = false
                        0L
                    } else len
                }
            }
            FileSizeInfo(total, isExact = allExact && total > 0L, source = "HLS_SUM")
        }

    private fun parseContentDisposition(header: String?): String? {
        if (header.isNullOrBlank()) return null
        Regex("""filename\*=UTF-8''([^;\r\n]+)""", RegexOption.IGNORE_CASE).find(header)?.let {
            return java.net.URLDecoder.decode(it.groupValues[1], "UTF-8")
        }
        Regex("""filename="?([^";\r\n]+)"?""", RegexOption.IGNORE_CASE).find(header)?.let {
            return it.groupValues[1].trim()
        }
        return null
    }
}

/**
 * Production OkHttp Downloader implementation for TeamNewPipe/NewPipeExtractor.
 * Provides 100% native YouTube browsing, Shorts, search suggestions, channels, and streams
 * without any official YouTube Data API key, WebView, or Google sign-in.
 */
@Singleton
class NewPipeOkHttpDownloader @Inject constructor(
    private val client: OkHttpClient
) : Downloader() {
    override fun execute(request: NpRequest): NpResponse {
        val method = request.httpMethod()
        val url = request.url()
        val headers = request.headers()
        val data = request.dataToSend()
        val body = data?.toRequestBody(null) ?: if (method == "POST") ByteArray(0).toRequestBody(null) else null

        val builder = Request.Builder()
            .url(url)
            .method(method, body)
            .header("User-Agent", USER_AGENT)

        for ((name, values) in headers) {
            builder.removeHeader(name)
            for (v in values) builder.addHeader(name, v)
        }

        client.newCall(builder.build()).execute().use { response ->
            if (response.code == 429) {
                throw ReCaptchaException("reCaptcha Challenge requested", url)
            }
            val responseBody = response.body?.string()
            val latestUrl = response.request.url.toString()
            return NpResponse(
                response.code,
                response.message,
                response.headers.toMultimap(),
                responseBody,
                latestUrl
            )
        }
    }

    companion object {
        private const val USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"
    }
}

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    @Provides
    @Singleton
    fun provideOkHttpClient(
        @ApplicationContext context: Context,
        cookieJar: EncryptedBridgeCookieJar
    ): OkHttpClient {
        val dispatcher = Dispatcher().apply {
            maxRequests = 128
            maxRequestsPerHost = 32
        }
        return OkHttpClient.Builder()
            .dispatcher(dispatcher)
            .connectionPool(ConnectionPool(32, 5, TimeUnit.MINUTES))
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .cookieJar(cookieJar)
            .cache(Cache(File(context.cacheDir, "jodon_http_cache"), 64L * 1024L * 1024L))
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    fun buildCloudflareDoh(bootstrapClient: OkHttpClient): DnsOverHttps =
        DnsOverHttps.Builder()
            .client(bootstrapClient)
            .url("https://cloudflare-dns.com/dns-query".toHttpUrl())
            .bootstrapDnsHosts(InetAddress.getByName("1.1.1.1"), InetAddress.getByName("1.0.0.1"))
            .build()
}
