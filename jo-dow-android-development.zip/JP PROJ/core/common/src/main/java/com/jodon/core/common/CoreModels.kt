package com.jodon.core.common

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.serialization.Serializable
import java.io.File
import java.io.FileInputStream
import java.net.URI
import java.security.MessageDigest
import java.text.NumberFormat
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.ln
import kotlin.math.pow

@Serializable
enum class MediaKind { VIDEO, AUDIO, IMAGE, FILE }

@Serializable
data class FileSizeInfo(
    val bytes: Long,
    val isExact: Boolean,
    val source: String = "HEAD"
) {
    /**
     * Strictly separates verified exact sizes from approximate sizes (prefixed with "≈").
     */
    fun formatHuman(arabic: Boolean = true): String {
        if (bytes <= 0L) return if (arabic) "غير معروف" else "Unknown"
        val unit = 1024.0
        val exp = (ln(bytes.toDouble()) / ln(unit)).toInt().coerceIn(0, 4)
        val unitsAr = arrayOf("بايت", "ك.ب", "ميجا", "جيجا", "تيرا")
        val unitsEn = arrayOf("B", "KiB", "MiB", "GiB", "TiB")
        val value = bytes / unit.pow(exp.toDouble())
        val formatted = if (exp == 0) "$bytes" else String.format(Locale.US, "%.1f", value)
        val prefix = if (isExact) "" else "≈ "
        return "$prefix$formatted ${if (arabic) unitsAr[exp] else unitsEn[exp]}"
    }

    /**
     * Exact byte representation displayed on long press: e.g. "148,372,910 bytes (141.5 MiB)".
     */
    fun formatExactBytes(arabic: Boolean = true): String {
        if (bytes <= 0L) return if (arabic) "الحجم مش متاح" else "Size unavailable"
        val grouped = NumberFormat.getIntegerInstance(Locale.US).format(bytes)
        val human = formatHuman(arabic)
        val word = if (arabic) "بايت" else "bytes"
        return if (isExact) "$grouped $word ($human)" else "≈ $grouped $word ($human - تقريبي)"
    }

    operator fun plus(other: FileSizeInfo): FileSizeInfo = FileSizeInfo(
        bytes = (bytes.coerceAtLeast(0L) + other.bytes.coerceAtLeast(0L)),
        isExact = this.isExact && other.isExact && this.bytes > 0 && other.bytes > 0,
        source = "MERGED"
    )
}

object Formatters {
    fun formatDuration(seconds: Long): String {
        if (seconds <= 0L) return "0:00"
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    fun formatSpeed(bytesPerSec: Long, arabic: Boolean = true): String {
        if (bytesPerSec <= 0L) return if (arabic) "0 ك.ب/ث" else "0 KiB/s"
        return "${FileSizeInfo(bytesPerSec, true).formatHuman(arabic)}/${if (arabic) "ث" else "s"}"
    }

    fun formatEta(remainingBytes: Long, speedBytesPerSec: Long, arabic: Boolean = true): String {
        if (speedBytesPerSec <= 0L || remainingBytes <= 0L) return if (arabic) "ثواني" else "--"
        val sec = (remainingBytes / speedBytesPerSec).coerceAtMost(86_400L)
        return when {
            sec < 60 -> if (arabic) "فاضل ${sec}ث" else "${sec}s left"
            sec < 3600 -> if (arabic) "فاضل ${sec / 60}د ${sec % 60}ث" else "${sec / 60}m ${sec % 60}s"
            else -> if (arabic) "فاضل ${sec / 3600}س ${(sec % 3600) / 60}د" else "${sec / 3600}h ${(sec % 3600) / 60}m"
        }
    }

    fun formatViewCount(count: Long, arabic: Boolean = true): String {
        if (count < 0) return ""
        return when {
            count >= 1_000_000_000L -> String.format(Locale.US, "%.1f%s", count / 1e9, if (arabic) " مليار مشاهدة" else "B views")
            count >= 1_000_000L -> String.format(Locale.US, "%.1f%s", count / 1e6, if (arabic) " مليون مشاهدة" else "M views")
            count >= 1_000L -> String.format(Locale.US, "%.1f%s", count / 1e3, if (arabic) " ألف مشاهدة" else "K views")
            else -> if (arabic) "$count مشاهدة" else "$count views"
        }
    }
}

object UrlNormalizer {
    private val trackingParams = setOf(
        "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
        "si", "feature", "igshid", "igsh", "fbclid", "gclid", "s", "t_ref"
    )

    fun normalize(raw: String): String {
        val trimmed = raw.trim().removeSurrounding("\"")
        if (trimmed.isEmpty()) return ""
        if (trimmed.startsWith("magnet:?")) return trimmed
        val withScheme = if (!trimmed.contains("://")) "https://$trimmed" else trimmed
        return runCatching {
            val uri = URI(withScheme)
            val cleanQuery = uri.rawQuery
                ?.split("&")
                ?.filter { pair ->
                    val key = pair.substringBefore("=").lowercase(Locale.ROOT)
                    key.isNotBlank() && key !in trackingParams
                }
                ?.joinToString("&")
                ?.ifBlank { null }
            URI(
                uri.scheme?.lowercase(Locale.ROOT) ?: "https",
                uri.userInfo,
                uri.host?.lowercase(Locale.ROOT),
                uri.port,
                uri.rawPath,
                cleanQuery,
                null
            ).toASCIIString()
        }.getOrDefault(withScheme)
    }

    fun extractDomain(url: String): String = runCatching {
        URI(url).host?.lowercase(Locale.ROOT)?.removePrefix("www.")?.removePrefix("m.") ?: ""
    }.getOrDefault("")

    fun extractBatchUrls(raw: String): List<String> {
        val regex = Regex("""(https?://[^\s<>"]+|magnet:\?[^\s<>"]+)""", RegexOption.IGNORE_CASE)
        val matches = regex.findAll(raw).map { normalize(it.value) }.distinct().toList()
        return if (matches.isNotEmpty()) matches else listOfNotNull(normalize(raw).takeIf { it.isNotBlank() })
    }

    fun sanitizeFileName(name: String, fallback: String = "jodon_file"): String {
        val cleaned = name.replace(Regex("""[\\/:*?"<>|\u0000-\u001F]"""), "_")
            .replace(Regex("""\s+"""), " ")
            .trim()
            .take(160)
        return cleaned.ifBlank { fallback }
    }
}

object HashVerifier {
    enum class Algorithm(val digestName: String) {
        MD5("MD5"), SHA1("SHA-1"), SHA256("SHA-256")
    }

    fun computeHash(file: File, algorithm: Algorithm): String {
        val digest = MessageDigest.getInstance(algorithm.digestName)
        val buffer = ByteArray(256 * 1024)
        FileInputStream(file).use { input ->
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun verify(file: File, expectedHex: String, algorithm: Algorithm): Boolean =
        computeHash(file, algorithm).equals(expectedHex.trim(), ignoreCase = true)
}

@Singleton
class AppDispatchers @Inject constructor() {
    val io: CoroutineDispatcher = Dispatchers.IO
    val default: CoroutineDispatcher = Dispatchers.Default
    val main: CoroutineDispatcher = Dispatchers.Main.immediate
}
