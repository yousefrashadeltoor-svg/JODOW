package com.jodon.core.database

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import com.jodon.core.common.AppDispatchers
import com.jodon.core.common.MediaKind
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Serializable
enum class DownloadStatus { QUEUED, RUNNING, PAUSED, MERGING, COMPLETED, FAILED, CANCELED }

@Serializable
data class SegmentState(
    val index: Int,
    val startByte: Long,
    val endByte: Long,
    val downloadedBytes: Long = 0L,
    val completed: Boolean = false
)

@Serializable
data class DownloadRecord(
    val id: String,
    val sourcePageUrl: String,
    val directUrl: String,
    val secondaryAudioUrl: String? = null,
    val fileName: String,
    val destinationPath: String,
    val kind: MediaKind,
    val totalBytes: Long,
    val isExactSize: Boolean,
    val downloadedBytes: Long = 0L,
    val speedBytesPerSec: Long = 0L,
    val speedHistory: List<Long> = emptyList(),
    val activeConnections: Int = 0,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val priority: Int = 0,
    val etag: String? = null,
    val lastModified: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val segments: List<SegmentState> = emptyList(),
    val scheduledAtEpochMs: Long? = null,
    val wifiOnly: Boolean = false,
    val chargingOnly: Boolean = false,
    val expectedSha256: String? = null,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class LocalChannelSub(
    val channelUrl: String,
    val name: String,
    val avatarUrl: String,
    val subscriberCount: Long = -1L,
    val subscribedAt: Long = System.currentTimeMillis()
)

@Serializable
data class LocalVideoEntry(
    val url: String,
    val title: String,
    val uploaderName: String,
    val uploaderUrl: String,
    val thumbnailUrl: String,
    val durationSec: Long,
    val viewCount: Long = 0L,
    val isShort: Boolean = false,
    val watchedAt: Long = System.currentTimeMillis(),
    val resumePositionMs: Long = 0L
)

@Serializable
data class LocalPlaylist(
    val id: String,
    val name: String,
    val items: List<LocalVideoEntry> = emptyList()
)

/**
 * 100% local, privacy-first YouTube profile — zero Google login, zero server, exportable/importable as single JSON.
 */
@Serializable
data class LocalYouTubeProfile(
    val displayName: String = "حسابي المحلي",
    val handle: String = "@jodon_user",
    val bio: String = "مشاهدة وتحميل براحتي من غير حساب رسمي",
    val avatarSeedColor: Long = 0xFF4285F4,
    val regionCode: String = "EG",
    val contentLanguage: String = "ar",
    val subscriptions: List<LocalChannelSub> = emptyList(),
    val watchHistory: List<LocalVideoEntry> = emptyList(),
    val likedVideos: List<LocalVideoEntry> = emptyList(),
    val searchHistory: List<String> = emptyList(),
    val keywordWeights: Map<String, Int> = emptyMap(),
    val playlists: List<LocalPlaylist> = emptyList(),
    val exportedAt: Long = System.currentTimeMillis()
)

@Serializable
data class AppSettingsState(
    val themeName: String = "AURORA",
    val darkTheme: Boolean = true,
    val isArabic: Boolean = true,
    val blurScale: Float = 1.0f,
    val dynamicCoverTint: Boolean = true,
    val onboardingDone: Boolean = false,
    val maxConcurrentDownloads: Int = 3,
    val segmentsPerDownload: Int = 16,
    val speedLimitBytesPerSec: Long = 0L,
    val wifiOnlyDefault: Boolean = false,
    val pauseOnLowBattery: Boolean = true,
    val enableDoh: Boolean = false,
    val clipboardMonitor: Boolean = true,
    val autoUpdateExtractors: Boolean = true,
    val adBlockEnabled: Boolean = true,
    val adBlockWhitelistDomains: Set<String> = emptySet(),
    val totalBytesDownloaded: Long = 0L,
    val totalBytesSavedByCompressor: Long = 0L
)

/**
 * Crash-safe atomic local file store (temp file + fsync + rename) — zero external DB, instant offline startup.
 */
@Singleton
class LocalAppStore @Inject constructor(
    @ApplicationContext private val context: Context,
    private val dispatchers: AppDispatchers
) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = false }
    private val prettyJson = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = true }
    private val mutex = Mutex()
    private val storeDir = File(context.filesDir, "jodon_local_store").apply { mkdirs() }

    private val downloadsFile = File(storeDir, "downloads_v1.json")
    private val profileFile = File(storeDir, "yt_local_profile_v1.json")
    private val settingsFile = File(storeDir, "settings_v1.json")

    private val _downloads = MutableStateFlow(readJson(downloadsFile, emptyList<DownloadRecord>()))
    val downloads: StateFlow<List<DownloadRecord>> = _downloads.asStateFlow()

    private val _profile = MutableStateFlow(readJson(profileFile, LocalYouTubeProfile()))
    val profile: StateFlow<LocalYouTubeProfile> = _profile.asStateFlow()

    private val _settings = MutableStateFlow(readJson(settingsFile, AppSettingsState()))
    val settings: StateFlow<AppSettingsState> = _settings.asStateFlow()

    suspend fun upsertDownload(record: DownloadRecord) {
        _downloads.update { list ->
            val idx = list.indexOfFirst { it.id == record.id }
            if (idx >= 0) list.toMutableList().apply { set(idx, record) } else listOf(record) + list
        }
        persistDownloads()
    }

    suspend fun updateDownload(id: String, transform: (DownloadRecord) -> DownloadRecord) {
        _downloads.update { list -> list.map { if (it.id == id) transform(it) else it } }
        persistDownloads()
    }

    suspend fun removeDownload(id: String) {
        _downloads.update { list -> list.filterNot { it.id == id } }
        persistDownloads()
    }

    suspend fun reorderDownloads(orderedIds: List<String>) {
        _downloads.update { list ->
            val byId = list.associateBy { it.id }
            orderedIds.mapIndexedNotNull { idx, id -> byId[id]?.copy(priority = idx) }
        }
        persistDownloads()
    }

    suspend fun updateSettings(transform: (AppSettingsState) -> AppSettingsState) {
        _settings.update(transform)
        atomicWrite(settingsFile, json.encodeToString(_settings.value))
    }

    suspend fun toggleSubscription(channel: LocalChannelSub) {
        updateProfile { p ->
            val exists = p.subscriptions.any { it.channelUrl == channel.channelUrl }
            val updated = if (exists) p.subscriptions.filterNot { it.channelUrl == channel.channelUrl }
            else listOf(channel) + p.subscriptions
            p.copy(subscriptions = updated)
        }
    }

    suspend fun recordVideoWatch(entry: LocalVideoEntry) {
        updateProfile { p ->
            val words = entry.title
                .split(Regex("""[\s\-_|،,.!؟?()\[\]]+"""))
                .map { it.trim().lowercase() }
                .filter { it.length >= 3 }
                .take(8)
            val updatedWeights = p.keywordWeights.toMutableMap()
            words.forEach { w -> updatedWeights[w] = ((updatedWeights[w] ?: 0) + 2).coerceAtMost(100) }
            if (entry.uploaderName.isNotBlank()) {
                updatedWeights[entry.uploaderName] = ((updatedWeights[entry.uploaderName] ?: 0) + 3).coerceAtMost(120)
            }
            val history = (listOf(entry.copy(watchedAt = System.currentTimeMillis())) +
                p.watchHistory.filterNot { it.url == entry.url }).take(400)
            p.copy(watchHistory = history, keywordWeights = updatedWeights)
        }
    }

    suspend fun toggleLike(entry: LocalVideoEntry) {
        updateProfile { p ->
            val exists = p.likedVideos.any { it.url == entry.url }
            val next = if (exists) p.likedVideos.filterNot { it.url == entry.url } else listOf(entry) + p.likedVideos
            p.copy(likedVideos = next)
        }
    }

    suspend fun recordSearch(query: String) {
        val clean = query.trim()
        if (clean.isBlank()) return
        updateProfile { p ->
            val weights = p.keywordWeights.toMutableMap()
            weights[clean.lowercase()] = ((weights[clean.lowercase()] ?: 0) + 4).coerceAtMost(120)
            p.copy(
                searchHistory = (listOf(clean) + p.searchHistory.filterNot { it.equals(clean, true) }).take(60),
                keywordWeights = weights
            )
        }
    }

    suspend fun updateProfile(transform: (LocalYouTubeProfile) -> LocalYouTubeProfile) {
        _profile.update(transform)
        atomicWrite(profileFile, json.encodeToString(_profile.value))
    }

    fun exportProfileJson(): String =
        prettyJson.encodeToString(_profile.value.copy(exportedAt = System.currentTimeMillis()))

    suspend fun importProfileJson(rawJson: String): Result<LocalYouTubeProfile> = runCatching {
        val imported = json.decodeFromString<LocalYouTubeProfile>(rawJson)
        _profile.value = imported
        atomicWrite(profileFile, json.encodeToString(imported))
        imported
    }

    fun exportFullBackupJson(): String {
        @Serializable
        data class BackupBundle(val settings: AppSettingsState, val profile: LocalYouTubeProfile, val downloads: List<DownloadRecord>)
        return prettyJson.encodeToString(BackupBundle(_settings.value, _profile.value, _downloads.value))
    }

    private suspend fun persistDownloads() {
        atomicWrite(downloadsFile, json.encodeToString(_downloads.value))
    }

    private suspend fun atomicWrite(target: File, content: String) = withContext(dispatchers.io) {
        mutex.withLock {
            val tmp = File(target.parentFile, "${target.name}.tmp")
            tmp.outputStream().use { out ->
                out.write(content.toByteArray(Charsets.UTF_8))
                out.fd.sync()
            }
            if (!tmp.renameTo(target)) {
                tmp.copyTo(target, overwrite = true)
                tmp.delete()
            }
        }
    }

    private inline fun <reified T> readJson(file: File, default: T): T {
        if (!file.exists()) return default
        return runCatching { json.decodeFromString<T>(file.readText(Charsets.UTF_8)) }.getOrDefault(default)
    }
}
