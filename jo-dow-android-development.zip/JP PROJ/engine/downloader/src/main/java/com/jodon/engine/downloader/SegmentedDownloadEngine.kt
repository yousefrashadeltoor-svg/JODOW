package com.jodon.engine.downloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.jodon.core.common.AppDispatchers
import com.jodon.core.common.Formatters
import com.jodon.core.common.HashVerifier
import com.jodon.core.common.MediaKind
import com.jodon.core.common.UrlNormalizer
import com.jodon.core.database.DownloadRecord
import com.jodon.core.database.DownloadStatus
import com.jodon.core.database.LocalAppStore
import com.jodon.core.database.SegmentState
import com.jodon.core.network.EncryptedBridgeCookieJar
import com.jodon.core.network.ExactSizeResolver
import com.jodon.engine.extractors.LinkAnalyzerPipeline
import com.jodon.engine.extractors.MediaOptionItem
import com.jodon.engine.media.MediaProcessingEngine
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.min
import kotlin.random.Random

/**
 * Pure deterministic segment planner & work-stealing splitter (covered by unit tests).
 */
object SegmentPlanner {
    private const val MIN_SEGMENT_SIZE = 512L * 1024L // 512 KiB

    fun createSegments(totalBytes: Long, desiredConnections: Int): List<SegmentState> {
        if (totalBytes <= 0L) return listOf(SegmentState(0, 0L, -1L))
        val clamped = desiredConnections.coerceIn(1, 32)
        val effectiveCount = (totalBytes / MIN_SEGMENT_SIZE).toInt().coerceIn(1, clamped)
        val chunk = totalBytes / effectiveCount
        return (0 until effectiveCount).map { idx ->
            val start = idx * chunk
            val end = if (idx == effectiveCount - 1) totalBytes - 1 else (start + chunk - 1)
            SegmentState(index = idx, startByte = start, endByte = end)
        }
    }

    /**
     * Work-Stealing: picks the incomplete segment with the largest remaining bytes and splits its second half.
     */
    fun stealHalfOfLargest(segments: List<SegmentState>): Pair<SegmentState, SegmentState>? {
        val victim = segments
            .filter { !it.completed && it.endByte > it.startByte }
            .maxByOrNull { (it.endByte - (it.startByte + it.downloadedBytes)) }
            ?: return null
        val currentOffset = victim.startByte + victim.downloadedBytes
        val remaining = victim.endByte - currentOffset + 1
        if (remaining < MIN_SEGMENT_SIZE * 2) return null
        val mid = currentOffset + (remaining / 2)
        val trimmedVictim = victim.copy(endByte = mid - 1)
        val stolen = SegmentState(
            index = segments.size,
            startByte = mid,
            endByte = victim.endByte,
            downloadedBytes = 0L,
            completed = false
        )
        return trimmedVictim to stolen
    }

    fun recommendConnectionsForSpeed(megabitsPerSec: Double): Int = when {
        megabitsPerSec >= 150.0 -> 32
        megabitsPerSec >= 60.0 -> 24
        megabitsPerSec >= 20.0 -> 16
        megabitsPerSec >= 5.0 -> 12
        else -> 8
    }
}

@Singleton
class SegmentedDownloadEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val okHttpClient: OkHttpClient,
    private val cookieJar: EncryptedBridgeCookieJar,
    private val sizeResolver: ExactSizeResolver,
    private val localStore: LocalAppStore,
    private val analyzer: LinkAnalyzerPipeline,
    private val mediaEngine: MediaProcessingEngine,
    private val dispatchers: AppDispatchers
) {
    private val scope = CoroutineScope(SupervisorJob() + dispatchers.io)
    private val runningJobs = ConcurrentHashMap<String, Job>()

    suspend fun enqueueOption(
        sourcePageUrl: String,
        baseFileName: String,
        option: MediaOptionItem,
        extraHeaders: Map<String, String> = emptyMap(),
        wifiOnly: Boolean = localStore.settings.value.wifiOnlyDefault
    ): DownloadRecord {
        val cleanBase = UrlNormalizer.sanitizeFileName(baseFileName.substringBeforeLast("."))
        val fullName = "$cleanBase.${option.formatExt}"
        val subFolder = when (option.kind) {
            MediaKind.VIDEO -> "Videos"
            MediaKind.AUDIO -> "Music"
            MediaKind.IMAGE -> "Pictures"
            MediaKind.FILE -> "Files"
        }
        val baseDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "JO_DON/$subFolder"
        ).apply { mkdirs() }

        // Duplicate detection: append index instead of silently overwriting an existing file
        var target = File(baseDir, fullName)
        var dupIndex = 1
        while (target.exists()) {
            target = File(baseDir, "${cleanBase}_($dupIndex).${option.formatExt}")
            dupIndex++
        }

        val mergedHeaders = buildMap {
            put("User-Agent", cookieJar.getMatchingUserAgent(option.directUrl))
            val ck = cookieJar.buildCookieHeader(option.directUrl)
            if (ck.isNotBlank()) put("Cookie", ck)
            if (sourcePageUrl.startsWith("http")) put("Referer", sourcePageUrl)
            putAll(option.headers)
            putAll(extraHeaders)
        }

        val record = DownloadRecord(
            id = UUID.randomUUID().toString(),
            sourcePageUrl = sourcePageUrl,
            directUrl = option.directUrl,
            secondaryAudioUrl = option.mergeAudioUrl,
            fileName = target.name,
            destinationPath = target.absolutePath,
            kind = option.kind,
            totalBytes = option.size.bytes,
            isExactSize = option.size.isExact,
            status = DownloadStatus.QUEUED,
            headers = mergedHeaders,
            wifiOnly = wifiOnly
        )
        localStore.upsertDownload(record)
        DownloadForegroundService.kick(context)
        pumpQueue()
        return record
    }

    fun pause(id: String) {
        runningJobs.remove(id)?.cancel()
        scope.launch {
            localStore.updateDownload(id) {
                it.copy(status = DownloadStatus.PAUSED, speedBytesPerSec = 0L, activeConnections = 0)
            }
            pumpQueue()
        }
    }

    fun resume(id: String) {
        scope.launch {
            localStore.updateDownload(id) { it.copy(status = DownloadStatus.QUEUED, errorMessage = null) }
            DownloadForegroundService.kick(context)
            pumpQueue()
        }
    }

    fun cancel(id: String, deletePartialFile: Boolean = true) {
        runningJobs.remove(id)?.cancel()
        scope.launch {
            val rec = localStore.downloads.value.firstOrNull { it.id == id }
            if (deletePartialFile && rec != null) {
                File(rec.destinationPath).delete()
                File("${rec.destinationPath}.part").delete()
            }
            localStore.removeDownload(id)
            pumpQueue()
        }
    }

    fun pumpQueue() {
        scope.launch {
            val maxParallel = localStore.settings.value.maxConcurrentDownloads.coerceIn(1, 6)
            val availableSlots = (maxParallel - runningJobs.size).coerceAtLeast(0)
            if (availableSlots == 0) return@launch
            val now = System.currentTimeMillis()
            val queued = localStore.downloads.value
                .filter {
                    it.status == DownloadStatus.QUEUED &&
                        !runningJobs.containsKey(it.id) &&
                        (it.scheduledAtEpochMs == null || it.scheduledAtEpochMs <= now)
                }
                .sortedBy { it.priority }
                .take(availableSlots)

            queued.forEach { record ->
                val job = scope.launch { executeTask(record.id) }
                job.invokeOnCompletion {
                    runningJobs.remove(record.id)
                    pumpQueue()
                }
                runningJobs[record.id] = job
            }
        }
    }

    /**
     * Built-in bandwidth test returning measured Mbps and optimal segmented connection count (8–32).
     */
    suspend fun runSpeedTest(): Result<Pair<Double, Int>> = withContext(dispatchers.io) {
        runCatching {
            val probeUrl = "https://speed.cloudflare.com/__down?bytes=10000000"
            val startNs = System.nanoTime()
            var readTotal = 0L
            val buf = ByteArray(128 * 1024)
            okHttpClient.newCall(Request.Builder().url(probeUrl).build()).execute().use { res ->
                val stream = res.body?.byteStream() ?: error("Empty response")
                while (true) {
                    val n = stream.read(buf)
                    if (n <= 0) break
                    readTotal += n
                }
            }
            val elapsedSec = ((System.nanoTime() - startNs) / 1_000_000_000.0).coerceAtLeast(0.05)
            val mbps = (readTotal * 8.0) / (elapsedSec * 1_000_000.0)
            mbps to SegmentPlanner.recommendConnectionsForSpeed(mbps)
        }
    }

    private suspend fun executeTask(id: String) {
        var record = localStore.downloads.value.firstOrNull { it.id == id } ?: return
        val partFile = File("${record.destinationPath}.part")
        val finalFile = File(record.destinationPath)
        partFile.parentFile?.mkdirs()

        try {
            val probe = sizeResolver.probeExact(record.directUrl, record.headers)
            val totalBytes = if (probe.size.bytes > 0L) probe.size.bytes else record.totalBytes
            val desiredConns = localStore.settings.value.segmentsPerDownload.coerceIn(8, 32)

            // Verify ETag integrity when resuming existing segments
            val etagChanged = record.etag != null && probe.etag != null && record.etag != probe.etag
            val initialSegments = when {
                !probe.supportsRanges || totalBytes <= 0L -> listOf(SegmentState(0, 0L, -1L))
                record.segments.isNotEmpty() && !etagChanged -> record.segments
                else -> SegmentPlanner.createSegments(totalBytes, desiredConns)
            }

            record = record.copy(
                status = DownloadStatus.RUNNING,
                totalBytes = totalBytes,
                isExactSize = probe.size.isExact || record.isExactSize,
                etag = probe.etag ?: record.etag,
                lastModified = probe.lastModified ?: record.lastModified,
                segments = initialSegments,
                activeConnections = initialSegments.count { !it.completed }
            )
            localStore.upsertDownload(record)

            // Pre-allocate file size on disk & use direct positional FileChannel writes (512 KiB buffers)
            downloadFileSegmented(
                id = id,
                url = probe.finalUrl,
                headers = record.headers,
                ifRangeValidator = record.etag ?: record.lastModified,
                totalBytes = totalBytes,
                supportsRanges = probe.supportsRanges,
                segments = initialSegments.toMutableList(),
                targetFile = partFile,
                sourcePageUrl = record.sourcePageUrl
            )

            // Optional DASH audio download + lossless FFmpeg muxing
            val audioUrl = record.secondaryAudioUrl
            if (!audioUrl.isNullOrBlank()) {
                localStore.updateDownload(id) { it.copy(status = DownloadStatus.MERGING, speedBytesPerSec = 0L) }
                val audioTemp = File("${record.destinationPath}.audio.tmp")
                val audioProbe = sizeResolver.probeExact(audioUrl, record.headers)
                val audioSegs = if (audioProbe.supportsRanges && audioProbe.size.bytes > 0) {
                    SegmentPlanner.createSegments(audioProbe.size.bytes, 8).toMutableList()
                } else mutableListOf(SegmentState(0, 0L, -1L))
                downloadFileSegmented(
                    id = id,
                    url = audioProbe.finalUrl,
                    headers = record.headers,
                    ifRangeValidator = null,
                    totalBytes = audioProbe.size.bytes,
                    supportsRanges = audioProbe.supportsRanges,
                    segments = audioSegs,
                    targetFile = audioTemp,
                    sourcePageUrl = record.sourcePageUrl
                )
                mediaEngine.mergeDashVideoAndAudio(partFile, audioTemp, finalFile).getOrThrow()
                partFile.delete()
                audioTemp.delete()
            } else {
                if (!partFile.renameTo(finalFile)) {
                    partFile.copyTo(finalFile, overwrite = true)
                    partFile.delete()
                }
            }

            // Optional SHA-256 integrity check
            record.expectedSha256?.takeIf { it.isNotBlank() }?.let { expected ->
                check(HashVerifier.verify(finalFile, expected, HashVerifier.Algorithm.SHA256)) {
                    "بصمة الملف SHA-256 مش مطابقة!"
                }
            }

            val actualFinalSize = finalFile.length()
            localStore.updateDownload(id) {
                it.copy(
                    status = DownloadStatus.COMPLETED,
                    downloadedBytes = actualFinalSize,
                    totalBytes = actualFinalSize,
                    isExactSize = true,
                    speedBytesPerSec = 0L,
                    activeConnections = 0
                )
            }
            localStore.updateSettings { it.copy(totalBytesDownloaded = it.totalBytesDownloaded + actualFinalSize) }
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            localStore.updateDownload(id) {
                it.copy(
                    status = DownloadStatus.FAILED,
                    speedBytesPerSec = 0L,
                    activeConnections = 0,
                    errorMessage = t.message ?: "حصلت مشكلة في الشبكة، جرّب كمّل تاني"
                )
            }
        }
    }

    private suspend fun downloadFileSegmented(
        id: String,
        url: String,
        headers: Map<String, String>,
        ifRangeValidator: String?,
        totalBytes: Long,
        supportsRanges: Boolean,
        segments: MutableList<SegmentState>,
        targetFile: File,
        sourcePageUrl: String
    ) = coroutineScope {
        var activeUrl = url
        val downloadedCounter = AtomicLong(segments.sumOf { it.downloadedBytes })

        RandomAccessFile(targetFile, "rw").use { raf ->
            if (supportsRanges && totalBytes > 0L && raf.length() < totalBytes) {
                raf.setLength(totalBytes)
            }
            val channel = raf.channel

            // Real-time progress, speed sparkline & state checkpoint loop (every 400ms)
            val reporter = launch {
                var prevBytes = downloadedCounter.get()
                while (isActive) {
                    delay(400)
                    val nowBytes = downloadedCounter.get()
                    val speed = ((nowBytes - prevBytes) * 1000L / 400L).coerceAtLeast(0L)
                    prevBytes = nowBytes
                    localStore.updateDownload(id) { rec ->
                        rec.copy(
                            downloadedBytes = nowBytes,
                            speedBytesPerSec = speed,
                            speedHistory = (rec.speedHistory + speed).takeLast(24),
                            segments = synchronized(segments) { segments.toList() },
                            activeConnections = synchronized(segments) { segments.count { !it.completed } }
                        )
                    }
                }
            }

            try {
                segments.mapIndexed { idx, seg ->
                    async(dispatchers.io) {
                        if (seg.completed) return@async
                        var attempt = 0
                        var localWritten = seg.downloadedBytes
                        while (true) {
                            try {
                                val startOffset = seg.startByte + localWritten
                                val reqBuilder = Request.Builder().url(activeUrl).apply {
                                    headers.forEach { (k, v) -> header(k, v) }
                                    if (supportsRanges && seg.endByte >= startOffset) {
                                        header("Range", "bytes=$startOffset-${seg.endByte}")
                                        if (localWritten > 0L && !ifRangeValidator.isNullOrBlank()) {
                                            header("If-Range", ifRangeValidator)
                                        }
                                    }
                                }
                                okHttpClient.newCall(reqBuilder.build()).execute().use { res ->
                                    // Automatic expired link refresh on 403 / 410
                                    if ((res.code == 403 || res.code == 410) && sourcePageUrl.startsWith("http") && attempt < 2) {
                                        val refreshed = analyzer.analyze(sourcePageUrl).first { it.isComplete }
                                        val candidate = (refreshed.videos + refreshed.audios + refreshed.files).firstOrNull()?.directUrl
                                        if (!candidate.isNullOrBlank()) activeUrl = candidate
                                        error("Refreshing expired URL (${res.code})")
                                    }
                                    if (!res.isSuccessful) error("HTTP ${res.code}")
                                    val stream = res.body?.byteStream() ?: error("Empty stream")
                                    val rawBuf = ByteArray(512 * 1024) // 512 KiB high-throughput buffer
                                    var writePos = startOffset
                                    while (isActive) {
                                        val limit = localStore.settings.value.speedLimitBytesPerSec
                                        val toRead = if (supportsRanges && seg.endByte > 0) {
                                            min(rawBuf.size.toLong(), (seg.endByte - writePos + 1).coerceAtLeast(0L)).toInt()
                                        } else rawBuf.size
                                        if (toRead <= 0) break
                                        val n = stream.read(rawBuf, 0, toRead)
                                        if (n <= 0) break
                                        var written = 0
                                        val bb = ByteBuffer.wrap(rawBuf, 0, n)
                                        while (bb.hasRemaining()) {
                                            written += channel.write(bb, writePos + written)
                                        }
                                        writePos += n
                                        localWritten += n
                                        downloadedCounter.addAndGet(n.toLong())
                                        synchronized(segments) {
                                            segments[idx] = segments[idx].copy(downloadedBytes = localWritten)
                                        }
                                        if (limit > 0L) {
                                            val sleepMs = (n * 1000L / (limit / segments.size.coerceAtLeast(1))).coerceAtMost(500L)
                                            if (sleepMs > 5L) delay(sleepMs)
                                        }
                                    }
                                }
                                synchronized(segments) {
                                    segments[idx] = segments[idx].copy(downloadedBytes = localWritten, completed = true)
                                }
                                break
                            } catch (ce: CancellationException) {
                                throw ce
                            } catch (e: Throwable) {
                                attempt++
                                if (attempt > 5) throw e
                                val backoff = (400L * (1L shl attempt)).coerceAtMost(12_000L) + Random.nextLong(50, 350)
                                delay(backoff)
                            }
                        }
                    }
                }.awaitAll()
                channel.force(true)
            } finally {
                reporter.cancel()
            }
        }
    }
}

@AndroidEntryPoint
class DownloadForegroundService : Service() {
    @Inject lateinit var engine: SegmentedDownloadEngine
    @Inject lateinit var store: LocalAppStore
    @Inject lateinit var dispatchers: AppDispatchers

    private val serviceScope = CoroutineScope(SupervisorJob() + DispatchersHolder.io)

    private object DispatchersHolder {
        val io = kotlinx.coroutines.Dispatchers.IO
    }

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        val initial = buildProgressNotification("𝒥𝒪 DON شغّال", "بيجهّز التحميلات...", 0, true, null)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, initial, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, initial)
        }
        serviceScope.launch {
            store.downloads.collect { list ->
                val running = list.filter { it.status == DownloadStatus.RUNNING || it.status == DownloadStatus.MERGING }
                if (running.isEmpty() && list.none { it.status == DownloadStatus.QUEUED }) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                } else if (running.isNotEmpty()) {
                    val primary = running.first()
                    val pct = if (primary.totalBytes > 0) ((primary.downloadedBytes * 100) / primary.totalBytes).toInt() else 0
                    val totalSpeed = running.sumOf { it.speedBytesPerSec }
                    val subtitle = "${Formatters.formatSpeed(totalSpeed)} • ${running.size} شغّال دلوقتي"
                    val nm = getSystemService(NotificationManager::class.java)
                    nm.notify(NOTIF_ID, buildProgressNotification(primary.fileName, subtitle, pct, primary.totalBytes <= 0, primary.id))
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val targetId = intent?.getStringExtra(EXTRA_ID)
        when (intent?.action) {
            ACTION_PAUSE -> targetId?.let { engine.pause(it) }
            ACTION_RESUME -> targetId?.let { engine.resume(it) }
            ACTION_CANCEL -> targetId?.let { engine.cancel(it) }
            else -> engine.pumpQueue()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "التحميلات النشطة", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildProgressNotification(title: String, text: String, progress: Int, indeterminate: Boolean, id: String?): Notification {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, progress.coerceIn(0, 100), indeterminate)

        if (id != null) {
            val pausePi = PendingIntent.getService(
                this, id.hashCode(),
                Intent(this, DownloadForegroundService::class.java).setAction(ACTION_PAUSE).putExtra(EXTRA_ID, id),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val cancelPi = PendingIntent.getService(
                this, id.hashCode() + 1,
                Intent(this, DownloadForegroundService::class.java).setAction(ACTION_CANCEL).putExtra(EXTRA_ID, id),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(0, "وقّف مؤقت", pausePi)
            builder.addAction(0, "إلغاء", cancelPi)
        }
        return builder.build()
    }

    companion object {
        private const val CHANNEL_ID = "jodon_downloads"
        private const val NOTIF_ID = 1007
        private const val EXTRA_ID = "download_id"
        const val ACTION_PAUSE = "com.jodon.action.PAUSE"
        const val ACTION_RESUME = "com.jodon.action.RESUME"
        const val ACTION_CANCEL = "com.jodon.action.CANCEL"

        fun kick(context: Context) {
            val intent = Intent(context, DownloadForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }
    }
}
