package com.jodon.engine.downloader

import com.jodon.core.common.FileSizeInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SegmentPlannerTest {
    @Test
    fun `segments cover every single byte without overlap or gap`() {
        val total = 148_372_910L
        val segments = SegmentPlanner.createSegments(total, desiredConnections = 16)
        assertEquals(16, segments.size)
        assertEquals(0L, segments.first().startByte)
        assertEquals(total - 1, segments.last().endByte)
        for (i in 1 until segments.size) {
            assertEquals(segments[i - 1].endByte + 1, segments[i].startByte)
        }
        val summed = segments.sumOf { it.endByte - it.startByte + 1 }
        assertEquals(total, summed)
    }

    @Test
    fun `work stealing splits slowest incomplete segment cleanly`() {
        val total = 64L * 1024L * 1024L
        val segments = SegmentPlanner.createSegments(total, 8).mapIndexed { idx, s ->
            if (idx == 0) s.copy(downloadedBytes = 1024L) else s.copy(downloadedBytes = s.endByte - s.startByte + 1, completed = true)
        }
        val split = SegmentPlanner.stealHalfOfLargest(segments)
        assertNotNull(split)
        val (trimmed, stolen) = split!!
        assertEquals(trimmed.endByte + 1, stolen.startByte)
        assertEquals(segments[0].endByte, stolen.endByte)
    }

    @Test
    fun `exact and approximate sizes never mix`() {
        val exact = FileSizeInfo(10_485_760L, isExact = true)
        val approx = FileSizeInfo(5_242_880L, isExact = false)
        assertFalse(exact.formatHuman(true).startsWith("≈"))
        assertTrue(approx.formatHuman(true).startsWith("≈"))
        val merged = exact + approx
        assertFalse(merged.isExact)
        assertEquals(15_728_640L, merged.bytes)
    }
}
