package com.jodon.engine.extractors

import android.content.Context
import com.jodon.core.common.AppDispatchers
import com.jodon.core.common.FileSizeInfo
import com.jodon.core.common.MediaKind
import com.jodon.core.common.UrlNormalizer
import com.jodon.core.database.LocalAppStore
import com.jodon.core.network.EncryptedBridgeCookieJar
import com.jodon.core.network.ExactSizeResolver
import com.jodon.core.network.NewPipeOkHttpDownloader
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import org.jsoup.Jsoup
import org.schabi.newpipe.extractor.ListExtractor
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabInfo
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.Collections
import java.util.LinkedHashMap
import javax.inject.Inject
import javax.inject.Singleton

@Serializable
data class MediaOptionItem(
    val id: String,
    val kind: MediaKind,
    val label: String,
    val formatExt: String,
    val codec: String,
    val fpsOrBitrate: String,
    val directUrl: String,
    val mergeAudioUrl: String? = null,
    val requiresDashMerge: Boolean = false,
    val size: FileSizeInfo,
    val headers: Map<String, String> = emptyMap()
)

@Serializable
data class AnalysisSnapshot(
    val stage: Int,
    val normalizedUrl: String,
    val domain: String,
    val siteName: String,
    val faviconUrl: String,
    val title: String,
    val suggestedFileName: String,
    val thumbnailUrl: String,
    val previewStreamUrl: String? = null,
    val uploader: String = "",
    val uploaderUrl: String = "",
    val durationSec: Long = 0L,
    val primaryKind: MediaKind = MediaKind.VIDEO,
    val videos: List<MediaOptionItem> = emptyList(),
    val audios: List<MediaOptionItem> = emptyList(),
    val images: List<MediaOptionItem> = emptyList(),
    val files: List<MediaOptionItem> = emptyList(),
    val isComplete: Boolean = false,
    val drmProtected: Boolean = false,
    val suggestBrowserSniffer: Boolean = false,
    val errorAr: String? = null
)

data class YouTubeFeedItem(
    val url: String,
    val title: String,
    val uploaderName: String,
    val uploaderUrl: String,
    val uploaderAvatar: String,
    val thumbnailUrl: String,
    val durationSec: Long,
    val viewCount: Long,
    val textualUploadDate: String,
    val isShort: Boolean,
    val isLive: Boolean
)

data class YouTubePagedResult(
    val items: List<YouTubeFeedItem>,
    val nextPage: Page?,
    val contextQuery: String = ""
)

data class YouTubeWatchDetails(
    val url: String,
    val title: String,
    val description: String,
    val uploaderName: String,
    val uploaderUrl: String,
    val uploaderAvatar: String,
    val subscriberCount: Long,
    val viewCount: Long,
    val likeCount: Long,
    val durationSec: Long,
    val thumbnailUrl: String,
    val bestPlayableVideoUrl: String?,
    val bestAudioOnlyUrl: String?,
    val hlsUrl: String?,
    val relatedItems: List<YouTubeFeedItem>,
    val downloadSnapshot: AnalysisSnapshot
)

/**
 * 100% Native Open-Source YouTube Engine powered by TeamNewPipe/NewPipeExtractor.
 * Zero official YouTube API keys, zero WebView, zero Google login, full Arabic/Egypt localization,
 * infinite personalized recommendations from local subscriptions + watch/search history, Shorts, Search & Suggestions.
 */
@Singleton
class NewPipeYouTubeEngine @Inject constructor(
    private val downloader: NewPipeOkHttpDownloader,
    private val localStore: LocalAppStore,
    private val sizeResolver: ExactSizeResolver,
    private val dispatchers: AppDispatchers
) {
    @Volatile
    private var initialized = false

    fun ensureInit() {
        if (!initialized) {
            synchronized(this) {
                if (!initialized) {
                    val profile = localStore.profile.value
                    NewPipe.init(
                        downloader,
                        Localization(profile.contentLanguage, profile.regionCode),
                        ContentCountry(profile.regionCode)
                    )
                    initialized = true
                }
            }
        }
    }

    /**
     * Loads the personalized Home feed by combining:
     * 1) Latest uploads from locally subscribed channels
     * 2) Personalized queries built from user's top local watch/search keywords
     * 3) Regional YouTube Trending kiosk as rich baseline.
     */
    suspend fun loadPersonalizedHome(pageIndex: Int = 0): Result<List<YouTubeFeedItem>> =
        withContext(dispatchers.io) {
            runCatching {
                ensureInit()
                val yt = ServiceList.YouTube
                val profile = localStore.profile.value
                val collected = mutableListOf<YouTubeFeedItem>()

                coroutineScope {
                    val jobs = buildList {
                        // 1. Subscribed channels fresh videos
                        profile.subscriptions.shuffled().take(3).forEach { sub ->
                            add(async { runCatching { loadChannelVideos(sub.channelUrl).take(4) }.getOrDefault(emptyList()) })
                        }
                        // 2. Personalized interest affinity queries (infinite rotation by pageIndex)
                        val topTopics = profile.keywordWeights.entries
                            .sortedByDescending { it.value }
                            .map { it.key }
                            .drop((pageIndex * 2) % (profile.keywordWeights.size.coerceAtLeast(1)))
                            .take(2)
                        topTopics.forEach { topic ->
                            add(async { runCatching { search(topic, null).getOrNull()?.items?.take(8).orEmpty() }.getOrDefault(emptyList()) })
                        }
                        // 3. Trending kiosk on initial page
                        if (pageIndex == 0 || topTopics.isEmpty()) {
                            add(async {
                                runCatching {
                                    val kiosk = yt.kioskList.getDefaultKioskExtractor()
                                    kiosk.fetchPage()
                                    kiosk.initialPage.items.filterIsInstance<StreamInfoItem>().map { it.toFeedItem() }
                                }.getOrDefault(emptyList())
                            })
                        }
                    }
                    jobs.awaitAll().forEach { collected += it }
                }

                val watchedUrls = profile.watchHistory.take(30).map { it.url }.toSet()
                collected
                    .distinctBy { it.url }
                    .filterNot { it.isShort }
                    .sortedByDescending { item ->
                        val subBoost = if (profile.subscriptions.any { it.channelUrl == item.uploaderUrl }) 2 else 0
                        val unwatchedBoost = if (item.url !in watchedUrls) 1 else 0
                        subBoost + unwatchedBoost
                    }
            }
        }

    /**
     * Loads native vertical YouTube Shorts personalized to local interests (no WebView).
     */
    suspend fun loadShortsFeed(seedTopic: String? = null): Result<List<YouTubeFeedItem>> =
        withContext(dispatchers.io) {
            runCatching {
                ensureInit()
                val profile = localStore.profile.value
                val topic = seedTopic ?: profile.keywordWeights.maxByOrNull { it.value }?.key ?: "شورتس مصر"
                val res = search("$topic #shorts", null).getOrThrow()
                res.items.filter { it.isShort || (it.durationSec in 1..65) }.ifEmpty { res.items.take(15) }
            }
        }

    /**
     * Real-time YouTube search autocomplete suggestions directly from NewPipe SuggestionExtractor.
     */
    suspend fun searchSuggestions(query: String): List<String> = withContext(dispatchers.io) {
        if (query.isBlank()) return@withContext localStore.profile.value.searchHistory.take(8)
        runCatching {
            ensureInit()
            ServiceList.YouTube.suggestionExtractor.suggestionList(query.trim()).take(10)
        }.getOrDefault(emptyList())
    }

    /**
     * Accurate native YouTube search with infinite Page continuation.
     */
    suspend fun search(query: String, page: Page? = null): Result<YouTubePagedResult> =
        withContext(dispatchers.io) {
            runCatching {
                ensureInit()
                val yt = ServiceList.YouTube
                val handler = yt.searchQHFactory.fromQuery(query.trim(), emptyList(), "")
                val extractor = yt.getSearchExtractor(handler)
                val infoPage: ListExtractor.InfoItemsPage<*> = if (page == null) {
                    extractor.fetchPage()
                    extractor.initialPage
                } else {
                    extractor.getPage(page)
                }
                YouTubePagedResult(
                    items = infoPage.items.filterIsInstance<StreamInfoItem>().map { it.toFeedItem() },
                    nextPage = infoPage.nextPage,
                    contextQuery = query
                )
            }
        }

    suspend fun loadChannelVideos(channelUrl: String): List<YouTubeFeedItem> = withContext(dispatchers.io) {
        ensureInit()
        val info = ChannelInfo.getInfo(ServiceList.YouTube, channelUrl)
        val firstTab = info.tabs.firstOrNull() ?: return@withContext emptyList()
        val tabInfo = ChannelTabInfo.getInfo(ServiceList.YouTube, firstTab)
        tabInfo.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toFeedItem() }
    }

    /**
     * Extracts full playable streams, related videos, channel metadata, and builds the complete
     * 4-button AnalysisSnapshot (Video 144p..4K/8K, Audio Opus/M4A, Thumbnails, SRT/VTT Subtitles) with exact sizes.
     */
    suspend fun getWatchAndDownloadDetails(videoUrl: String): Result<YouTubeWatchDetails> =
        withContext(dispatchers.io) {
            runCatching {
                ensureInit()
                val info = StreamInfo.getInfo(ServiceList.YouTube, videoUrl)
                val bestAudio = info.audioStreams.maxByOrNull { it.averageBitrate }
                val bestAudioSize = bestAudio?.url?.let { sizeResolver.probeExact(it).size } ?: FileSizeInfo(0L, false)

                val muxedVideos = info.videoStreams.mapNotNull { vs ->
                    val u = vs.content.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                    MediaOptionItem(
                        id = "mux_${vs.itag}",
                        kind = MediaKind.VIDEO,
                        label = vs.resolution,
                        formatExt = vs.format?.suffix ?: "mp4",
                        codec = vs.codec ?: "AVC",
                        fpsOrBitrate = "${vs.fps}fps",
                        directUrl = u,
                        requiresDashMerge = false,
                        size = sizeResolver.probeExact(u).size
                    )
                }

                val dashVideos = info.videoOnlyStreams
                    .sortedByDescending { it.height }
                    .take(8)
                    .mapNotNull { vs ->
                        val u = vs.content.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                        val vSize = sizeResolver.probeExact(u).size
                        MediaOptionItem(
                            id = "dash_${vs.itag}",
                            kind = MediaKind.VIDEO,
                            label = "${vs.resolution}${if (vs.fps >= 60) " 60fps" else ""}",
                            formatExt = vs.format?.suffix ?: "mp4",
                            codec = vs.codec ?: "VP9/AV1",
                            fpsOrBitrate = "${vs.fps}fps • دمج صوت تلقائي",
                            directUrl = u,
                            mergeAudioUrl = bestAudio?.content,
                            requiresDashMerge = bestAudio?.content != null,
                            size = if (bestAudioSize.bytes > 0) vSize + bestAudioSize else vSize
                        )
                    }

                val audios = info.audioStreams
                    .sortedByDescending { it.averageBitrate }
                    .mapNotNull { a ->
                        val u = a.content.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                        MediaOptionItem(
                            id = "aud_${a.itag}",
                            kind = MediaKind.AUDIO,
                            label = "صوت نقي ${a.averageBitrate}kbps",
                            formatExt = a.format?.suffix ?: "m4a",
                            codec = a.codec ?: "opus",
                            fpsOrBitrate = "${a.averageBitrate} kbps",
                            directUrl = u,
                            size = sizeResolver.probeExact(u).size
                        )
                    }

                val images = info.thumbnails.mapIndexed { i, th ->
                    MediaOptionItem(
                        id = "thumb_$i",
                        kind = MediaKind.IMAGE,
                        label = if (th.width > 0) "غلاف ${th.width}×${th.height}" else "صورة الغلاف ${i + 1}",
                        formatExt = "jpg",
                        codec = "JPEG",
                        fpsOrBitrate = "HD",
                        directUrl = th.url,
                        size = sizeResolver.probeExact(th.url).size
                    )
                }

                val subtitles = info.subtitles.mapIndexedNotNull { i, sub ->
                    val u = sub.content.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                    MediaOptionItem(
                        id = "sub_$i",
                        kind = MediaKind.FILE,
                        label = "ترجمة ${sub.displayLanguageName}",
                        formatExt = sub.format?.suffix ?: "vtt",
                        codec = if (sub.isAutoGenerated) "تلقائية" else "أصلية",
                        fpsOrBitrate = sub.languageTag,
                        directUrl = u,
                        size = sizeResolver.probeExact(u).size
                    )
                }

                val thumb = info.thumbnails.maxByOrNull { it.width }?.url.orEmpty()
                val snapshot = AnalysisSnapshot(
                    stage = 2,
                    normalizedUrl = info.url,
                    domain = "youtube.com",
                    siteName = "YouTube",
                    faviconUrl = "https://www.youtube.com/s/desktop/f81b3532/img/favicon_144x144.png",
                    title = info.name,
                    suggestedFileName = UrlNormalizer.sanitizeFileName(info.name),
                    thumbnailUrl = thumb,
                    previewStreamUrl = info.hlsUrl.takeIf { it.isNotBlank() }
                        ?: info.videoStreams.maxByOrNull { it.height }?.content,
                    uploader = info.uploaderName,
                    uploaderUrl = info.uploaderUrl,
                    durationSec = info.duration,
                    primaryKind = MediaKind.VIDEO,
                    videos = (dashVideos + muxedVideos).distinctBy { "${it.label}_${it.codec}" },
                    audios = audios,
                    images = images,
                    files = subtitles,
                    isComplete = true
                )

                YouTubeWatchDetails(
                    url = info.url,
                    title = info.name,
                    description = info.description.content,
                    uploaderName = info.uploaderName,
                    uploaderUrl = info.uploaderUrl,
                    uploaderAvatar = info.uploaderAvatars.maxByOrNull { it.width }?.url.orEmpty(),
                    subscriberCount = info.uploaderSubscriberCount,
                    viewCount = info.viewCount,
                    likeCount = info.likeCount,
                    durationSec = info.duration,
                    thumbnailUrl = thumb,
                    bestPlayableVideoUrl = snapshot.previewStreamUrl,
                    bestAudioOnlyUrl = bestAudio?.content,
                    hlsUrl = info.hlsUrl.takeIf { it.isNotBlank() },
                    relatedItems = info.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toFeedItem() },
                    downloadSnapshot = snapshot
                )
            }
        }

    fun isYouTubeUrl(url: String): Boolean {
        val d = UrlNormalizer.extractDomain(url)
        return d == "youtube.com" || d == "youtu.be" || d.endsWith(".youtube.com") || d == "music.youtube.com"
    }

    private fun StreamInfoItem.toFeedItem(): YouTubeFeedItem = YouTubeFeedItem(
        url = url,
        title = name,
        uploaderName = uploaderName ?: "",
        uploaderUrl = uploaderUrl ?: "",
        uploaderAvatar = uploaderAvatars.firstOrNull()?.url.orEmpty(),
        thumbnailUrl = thumbnails.maxByOrNull { it.width }?.url.orEmpty(),
        durationSec = duration.coerceAtLeast(0L),
        viewCount = viewCount,
        textualUploadDate = textualUploadDate ?: "",
        isShort = isShortFormContent || url.contains("/shorts/"),
        isLive = duration <= 0L && streamType.name.contains("LIVE")
    )
}

/**
 * Universal 1,800+ site extractor powered by yt-dlp + FFmpeg + aria2c (-x16 -s16 -k1M)
 * combined with the 5-stage parallel Link Analyzer pipeline and LRU TTL cache.
 */
@Singleton
class LinkAnalyzerPipeline @Inject constructor(
    @ApplicationContext private val context: Context,
    private val youTubeEngine: NewPipeYouTubeEngine,
    private val sizeResolver: ExactSizeResolver,
    private val cookieJar: EncryptedBridgeCookieJar,
    private val dispatchers: AppDispatchers
) {
    private data class CacheEntry(val snapshot: AnalysisSnapshot, val expiresAt: Long)

    private val memoryCache = Collections.synchronizedMap(
        object : LinkedHashMap<String, CacheEntry>(64, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CacheEntry>?): Boolean = size > 64
        }
    )

    @Volatile
    private var ytdlpReady = false

    suspend fun initAndOptionalUpdate(autoUpdate: Boolean) = withContext(dispatchers.io) {
        if (!ytdlpReady) {
            YoutubeDL.getInstance().init(context)
            FFmpeg.getInstance().init(context)
            Aria2c.getInstance().init(context)
            ytdlpReady = true
        }
        if (autoUpdate) {
            runCatching { YoutubeDL.getInstance().updateYoutubeDL(context, YoutubeDL.UpdateChannel.STABLE) }
        }
    }

    /**
     * Emits progressive Stage 0 -> Stage 4 snapshots without ever blocking the main thread.
     */
    fun analyze(rawUrl: String): Flow<AnalysisSnapshot> = channelFlow {
        val url = UrlNormalizer.normalize(rawUrl)
        if (url.isBlank()) return@channelFlow
        val domain = UrlNormalizer.extractDomain(url)

        memoryCache[url]?.takeIf { it.expiresAt > System.currentTimeMillis() }?.let {
            send(it.snapshot)
            return@channelFlow
        }

        // Stage 0 (<50ms): Instant normalized URL + domain metadata
        var current = AnalysisSnapshot(
            stage = 0,
            normalizedUrl = url,
            domain = domain,
            siteName = domain.substringBefore(".").replaceFirstChar { it.uppercase() },
            faviconUrl = "https://$domain/apple-touch-icon.png",
            title = url.substringAfterLast("/").ifBlank { domain },
            suggestedFileName = UrlNormalizer.sanitizeFileName(url.substringAfterLast("/").substringBefore("?"), "jodon_download"),
            thumbnailUrl = ""
        )
        send(current)

        // Preconnect TCP/TLS immediately
        val probeDeferred = async(dispatchers.io) { sizeResolver.probeExact(url) }

        // Stage 2 Fast Path (<1.5s): Native NewPipeExtractor for all YouTube / Shorts / YT Music URLs
        if (youTubeEngine.isYouTubeUrl(url)) {
            val ytResult = youTubeEngine.getWatchAndDownloadDetails(url).getOrNull()
            if (ytResult != null) {
                memoryCache[url] = CacheEntry(ytResult.downloadSnapshot, System.currentTimeMillis() + 15 * 60_000L)
                send(ytResult.downloadSnapshot)
                return@channelFlow
            }
        }

        // Stage 1 (<300ms): Direct file probe (MP4, MP3, APK, ZIP, PDF, ISO, M3U8, JPG, PNG...)
        val probe = probeDeferred.await()
        val mime = probe.mimeType?.lowercase().orEmpty()
        if (mime.isNotBlank() && !mime.contains("text/html")) {
            val kind = when {
                mime.startsWith("video/") || mime.contains("mpegurl") -> MediaKind.VIDEO
                mime.startsWith("audio/") -> MediaKind.AUDIO
                mime.startsWith("image/") -> MediaKind.IMAGE
                else -> MediaKind.FILE
            }
            val name = probe.fileName ?: current.suggestedFileName
            val ext = name.substringAfterLast(".", mime.substringAfter("/").substringBefore(";").take(4))
            val item = MediaOptionItem(
                id = "direct_0",
                kind = kind,
                label = name,
                formatExt = ext,
                codec = if (probe.supportsRanges) "سريع متعدد الأجزاء" else "مباشر",
                fpsOrBitrate = mime.substringBefore(";"),
                directUrl = probe.finalUrl,
                size = probe.size
            )
            current = current.copy(
                stage = 1,
                title = name,
                suggestedFileName = UrlNormalizer.sanitizeFileName(name),
                previewStreamUrl = if (kind != MediaKind.FILE) probe.finalUrl else null,
                thumbnailUrl = if (kind == MediaKind.IMAGE) probe.finalUrl else "",
                primaryKind = kind,
                videos = if (kind == MediaKind.VIDEO) listOf(item) else emptyList(),
                audios = if (kind == MediaKind.AUDIO) listOf(item) else emptyList(),
                images = if (kind == MediaKind.IMAGE) listOf(item) else emptyList(),
                files = if (kind == MediaKind.FILE) listOf(item) else emptyList(),
                isComplete = true
            )
            memoryCache[url] = CacheEntry(current, System.currentTimeMillis() + 10 * 60_000L)
            send(current)
            return@channelFlow
        }

        // Stage 3 (<=4s): Full yt-dlp extraction across 1,800+ supported sites (TikTok, Instagram, X, Facebook, Reddit, Vimeo, SoundCloud...)
        val ytdlpSnapshot = runCatching { extractWithYtDlp(url, current) }.getOrNull()
        if (ytdlpSnapshot != null) {
            memoryCache[url] = CacheEntry(ytdlpSnapshot, System.currentTimeMillis() + 15 * 60_000L)
            send(ytdlpSnapshot)
            return@channelFlow
        }

        // Stage 4: Jsoup HTML + OpenGraph + <video>/<audio>/<img> inspection + smart Browser Sniffer fallback
        val fallback = runCatching { extractWithJsoup(url, current) }.getOrElse {
            current.copy(
                stage = 4,
                isComplete = true,
                suggestBrowserSniffer = true,
                errorAr = "افتح اللينك في المتصفح الصيّاد وهنلقط كل الملفات منه فوراً"
            )
        }
        send(fallback)
    }

    private suspend fun extractWithYtDlp(url: String, base: AnalysisSnapshot): AnalysisSnapshot =
        withContext(dispatchers.io) {
            initAndOptionalUpdate(autoUpdate = false)
            val req = YoutubeDLRequest(url).apply {
                addOption("--no-playlist")
                addOption("--user-agent", cookieJar.getMatchingUserAgent(url))
                val cookie = cookieJar.buildCookieHeader(url)
                if (cookie.isNotBlank()) addOption("--add-header", "Cookie:$cookie")
            }
            val info = YoutubeDL.getInstance().getInfo(req)
            val formats = info.formats.orEmpty()

            // Refuse DRM-protected content strictly per Legal Rule 11
            if (formats.isNotEmpty() && formats.all { it.url.isNullOrBlank() }) {
                return@withContext base.copy(
                    stage = 3,
                    title = info.title ?: base.title,
                    isComplete = true,
                    drmProtected = true,
                    errorAr = "المحتوى ده محمي بحقوق DRM والتطبيق بيحترم حقوق النشر ومش بيتجاوزها."
                )
            }

            val bestAudio = formats
                .filter { it.vcodec == "none" && it.acodec != "none" && !it.url.isNullOrBlank() }
                .maxByOrNull { it.abr }
            val bestAudioSize = bestAudio?.let {
                if (it.fileSize > 0) FileSizeInfo(it.fileSize, true, "YTDLP")
                else if (it.fileSizeApproximate > 0) FileSizeInfo(it.fileSizeApproximate, false, "YTDLP_APPROX")
                else FileSizeInfo(0L, false)
            } ?: FileSizeInfo(0L, false)

            val videos = formats
                .filter { it.vcodec != null && it.vcodec != "none" && !it.url.isNullOrBlank() }
                .sortedByDescending { it.height }
                .map { f ->
                    val needsMerge = f.acodec == "none" && bestAudio?.url != null
                    val rawSize = when {
                        f.fileSize > 0 -> FileSizeInfo(f.fileSize, true, "YTDLP")
                        f.fileSizeApproximate > 0 -> FileSizeInfo(f.fileSizeApproximate, false, "YTDLP_APPROX")
                        else -> sizeResolver.probeExact(f.url!!).size
                    }
                    MediaOptionItem(
                        id = "v_${f.formatId}",
                        kind = MediaKind.VIDEO,
                        label = f.formatNote?.takeIf { it.isNotBlank() } ?: "${f.height}p",
                        formatExt = f.ext ?: "mp4",
                        codec = f.vcodec?.substringBefore(".") ?: "H.264",
                        fpsOrBitrate = if (f.fps > 0) "${f.fps}fps" else "${f.tbr}k",
                        directUrl = f.url!!,
                        mergeAudioUrl = if (needsMerge) bestAudio?.url else null,
                        requiresDashMerge = needsMerge,
                        size = if (needsMerge && bestAudioSize.bytes > 0) rawSize + bestAudioSize else rawSize,
                        headers = f.httpHeaders.orEmpty()
                    )
                }

            val audios = formats
                .filter { it.vcodec == "none" && it.acodec != null && it.acodec != "none" && !it.url.isNullOrBlank() }
                .sortedByDescending { it.abr }
                .map { f ->
                    val sz = when {
                        f.fileSize > 0 -> FileSizeInfo(f.fileSize, true, "YTDLP")
                        f.fileSizeApproximate > 0 -> FileSizeInfo(f.fileSizeApproximate, false, "YTDLP_APPROX")
                        else -> sizeResolver.probeExact(f.url!!).size
                    }
                    MediaOptionItem(
                        id = "a_${f.formatId}",
                        kind = MediaKind.AUDIO,
                        label = "صوت ${if (f.abr > 0) "${f.abr}kbps" else (f.ext ?: "أصلي")}",
                        formatExt = f.ext ?: "m4a",
                        codec = f.acodec?.substringBefore(".") ?: "AAC",
                        fpsOrBitrate = if (f.abr > 0) "${f.abr} kbps" else "أصلي",
                        directUrl = f.url!!,
                        size = sz,
                        headers = f.httpHeaders.orEmpty()
                    )
                }

            val images = listOfNotNull(info.thumbnail?.takeIf { it.isNotBlank() }).map { thumbUrl ->
                MediaOptionItem(
                    id = "img_cover",
                    kind = MediaKind.IMAGE,
                    label = "صورة الغلاف الأصلية",
                    formatExt = "jpg",
                    codec = "JPEG",
                    fpsOrBitrate = "كاملة",
                    directUrl = thumbUrl,
                    size = sizeResolver.probeExact(thumbUrl).size
                )
            }

            base.copy(
                stage = 3,
                siteName = info.extractorKey ?: base.siteName,
                title = info.title ?: base.title,
                suggestedFileName = UrlNormalizer.sanitizeFileName(info.title ?: base.suggestedFileName),
                thumbnailUrl = info.thumbnail ?: "",
                previewStreamUrl = info.url ?: videos.firstOrNull { !it.requiresDashMerge }?.directUrl,
                uploader = info.uploader ?: "",
                durationSec = info.duration.toLong().coerceAtLeast(0L),
                videos = videos,
                audios = audios,
                images = images,
                isComplete = true,
                suggestBrowserSniffer = videos.isEmpty() && audios.isEmpty() && images.isEmpty()
            )
        }

    private suspend fun extractWithJsoup(url: String, base: AnalysisSnapshot): AnalysisSnapshot =
        withContext(dispatchers.io) {
            val doc = Jsoup.connect(url)
                .userAgent(cookieJar.getMatchingUserAgent(url))
                .timeout(10_000)
                .get()
            val ogTitle = doc.selectFirst("meta[property=og:title]")?.attr("content").orEmpty().ifBlank { doc.title() }
            val ogImage = doc.selectFirst("meta[property=og:image]")?.absUrl("content").orEmpty()
            val icon = doc.selectFirst("link[rel*=apple-touch-icon], link[rel*=icon]")?.absUrl("href").orEmpty().ifBlank { base.faviconUrl }

            val videoSrcs = (doc.select("video[src], video source[src]").map { it.absUrl("src") } +
                listOfNotNull(doc.selectFirst("meta[property=og:video]")?.absUrl("content")))
                .filter { it.startsWith("http") }.distinct()
            val audioSrcs = doc.select("audio[src], audio source[src]").map { it.absUrl("src") }.filter { it.startsWith("http") }.distinct()
            val imageSrcs = (listOf(ogImage) + doc.select("img[src]").map { it.absUrl("src") })
                .filter { it.startsWith("http") }.distinct().take(12)

            val videos = videoSrcs.mapIndexed { i, u ->
                MediaOptionItem("jv_$i", MediaKind.VIDEO, "فيديو ${i + 1}", "mp4", "Web", "مباشر", u, size = sizeResolver.probeExact(u).size)
            }
            val audios = audioSrcs.mapIndexed { i, u ->
                MediaOptionItem("ja_$i", MediaKind.AUDIO, "ملف صوت ${i + 1}", "mp3", "Web", "مباشر", u, size = sizeResolver.probeExact(u).size)
            }
            val images = imageSrcs.mapIndexed { i, u ->
                MediaOptionItem("ji_$i", MediaKind.IMAGE, "صورة ${i + 1}", "jpg", "صورة", "HD", u, size = sizeResolver.probeExact(u).size)
            }

            base.copy(
                stage = 4,
                faviconUrl = icon,
                title = ogTitle.ifBlank { base.title },
                suggestedFileName = UrlNormalizer.sanitizeFileName(ogTitle.ifBlank { base.suggestedFileName }),
                thumbnailUrl = ogImage,
                videos = videos,
                audios = audios,
                images = images,
                isComplete = true,
                suggestBrowserSniffer = videos.isEmpty() && audios.isEmpty()
            )
        }
}
