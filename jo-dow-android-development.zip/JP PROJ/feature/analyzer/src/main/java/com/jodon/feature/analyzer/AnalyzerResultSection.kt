package com.jodon.feature.analyzer

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.jodon.core.common.Formatters
import com.jodon.core.common.MediaKind
import com.jodon.core.designsystem.GlassBottomSheet
import com.jodon.core.designsystem.GlassButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.JoIcons
import com.jodon.core.designsystem.JoText
import com.jodon.core.designsystem.JoTheme
import com.jodon.core.designsystem.SmartCategoryButton
import com.jodon.core.designsystem.StreamingRevealText
import com.jodon.engine.extractors.AnalysisSnapshot
import com.jodon.engine.extractors.MediaOptionItem
import dev.chrisbanes.haze.HazeState

/**
 * Reusable Progressive Info Card + The 4 Smart Category Buttons + Quality Bottom Sheet
 * shared cleanly across Home Screen, Native YouTube Screen, and Browser Sniffer.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AnalyzerResultSection(
    snapshot: AnalysisSnapshot,
    customFileName: String,
    onFileNameChange: (String) -> Unit,
    onDownloadOption: (MediaOptionItem) -> Unit,
    onOpenInBrowserSniffer: ((String) -> Unit)? = null,
    hazeState: HazeState? = null
) {
    val colors = JoTheme.colors
    var activeSheetKind by remember { mutableStateOf<MediaKind?>(null) }
    var expandedExactId by remember { mutableStateOf<String?>(null) }

    GlassCard(hazeState = hazeState, elevated = true) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = snapshot.faviconUrl,
                contentDescription = snapshot.siteName,
                modifier = Modifier.size(22.dp).clip(JoTheme.shapes.pill)
            )
            Spacer(Modifier.width(8.dp))
            JoText(text = snapshot.siteName, style = JoTheme.typography.label, color = colors.accentPrimary)
            Spacer(Modifier.width(6.dp))
            JoText(text = "• ${snapshot.domain}", style = JoTheme.typography.caption, color = colors.textMuted, maxLines = 1)
        }

        if (snapshot.thumbnailUrl.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Box(modifier = Modifier.fillMaxWidth().height(180.dp).clip(JoTheme.shapes.button)) {
                AsyncImage(
                    model = snapshot.thumbnailUrl,
                    contentDescription = snapshot.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.matchParentSize()
                )
                if (snapshot.durationSec > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                            .clip(JoTheme.shapes.pill)
                            .background(Color.Black.copy(alpha = 0.72f))
                            .padding(horizontal = 9.dp, vertical = 4.dp)
                    ) {
                        JoText(Formatters.formatDuration(snapshot.durationSec), style = JoTheme.typography.caption, color = Color.White)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        StreamingRevealText(text = snapshot.title, style = JoTheme.typography.titleMedium)

        if (snapshot.uploader.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            JoText(text = snapshot.uploader, style = JoTheme.typography.bodySmall, color = colors.textSecondary)
        }

        snapshot.errorAr?.let { msg ->
            Spacer(Modifier.height(10.dp))
            JoText(text = msg, style = JoTheme.typography.bodySmall, color = colors.warning)
            if (snapshot.suggestBrowserSniffer && onOpenInBrowserSniffer != null) {
                Spacer(Modifier.height(10.dp))
                GlassButton(
                    text = "افتح في المتصفح الصيّاد",
                    onClick = { onOpenInBrowserSniffer(snapshot.normalizedUrl) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    Spacer(Modifier.height(12.dp))

    // STRICT Section 4.4: The 4 Smart Buttons — each renders ONLY when its list is non-empty.
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (snapshot.videos.isNotEmpty()) {
            SmartCategoryButton(
                visible = true,
                label = "فيديو",
                count = snapshot.videos.size,
                accent = colors.accentPrimary,
                icon = JoIcons.Video,
                onClick = { activeSheetKind = MediaKind.VIDEO },
                modifier = Modifier.weight(1f)
            )
        }
        if (snapshot.audios.isNotEmpty()) {
            SmartCategoryButton(
                visible = true,
                label = "صوت",
                count = snapshot.audios.size,
                accent = colors.accentSecondary,
                icon = JoIcons.Audio,
                onClick = { activeSheetKind = MediaKind.AUDIO },
                modifier = Modifier.weight(1f)
            )
        }
    }
    if (snapshot.images.isNotEmpty() || snapshot.files.isNotEmpty()) {
        Spacer(Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (snapshot.images.isNotEmpty()) {
                SmartCategoryButton(
                    visible = true,
                    label = "صور",
                    count = snapshot.images.size,
                    accent = colors.accentTertiary,
                    icon = JoIcons.Image,
                    onClick = { activeSheetKind = MediaKind.IMAGE },
                    modifier = Modifier.weight(1f)
                )
            }
            if (snapshot.files.isNotEmpty()) {
                SmartCategoryButton(
                    visible = true,
                    label = "ملفات",
                    count = snapshot.files.size,
                    accent = colors.success,
                    icon = JoIcons.File,
                    onClick = { activeSheetKind = MediaKind.FILE },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }

    val sheetItems = when (activeSheetKind) {
        MediaKind.VIDEO -> snapshot.videos
        MediaKind.AUDIO -> snapshot.audios
        MediaKind.IMAGE -> snapshot.images
        MediaKind.FILE -> snapshot.files
        null -> emptyList()
    }
    val sheetTitle = when (activeSheetKind) {
        MediaKind.VIDEO -> "اختار جودة الفيديو"
        MediaKind.AUDIO -> "اختار جودة الصوت"
        MediaKind.IMAGE -> "اختار الصورة"
        MediaKind.FILE -> "الترجمات والملفات"
        null -> ""
    }

    GlassBottomSheet(
        visible = activeSheetKind != null,
        onDismiss = { activeSheetKind = null },
        title = sheetTitle,
        hazeState = hazeState
    ) {
        LazyColumn(
            modifier = Modifier.heightIn(max = 420.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(sheetItems, key = { it.id }) { opt ->
                val showExact = expandedExactId == opt.id
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(JoTheme.shapes.button)
                        .background(colors.glassSurface)
                        .border(1.dp, colors.specularBorderBrush, JoTheme.shapes.button)
                        .combinedClickable(
                            onClick = { onDownloadOption(opt); activeSheetKind = null },
                            onLongClick = { expandedExactId = if (showExact) null else opt.id }
                        )
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        JoText(text = "${opt.label} • ${opt.formatExt.uppercase()}", style = JoTheme.typography.titleMedium)
                        JoText(
                            text = "${opt.codec} • ${opt.fpsOrBitrate}",
                            style = JoTheme.typography.caption,
                            color = colors.textSecondary
                        )
                        JoText(
                            text = if (showExact) opt.size.formatExactBytes(true) else opt.size.formatHuman(true),
                            style = JoTheme.typography.caption,
                            color = if (opt.size.isExact) colors.success else colors.warning
                        )
                    }
                    GlassButton(
                        text = "حمّل",
                        onClick = { onDownloadOption(opt); activeSheetKind = null }
                    )
                }
            }
        }
    }
}
