package com.jodon.feature.youtube

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import com.jodon.core.common.Formatters
import com.jodon.core.database.LocalAppStore
import com.jodon.core.database.LocalChannelSub
import com.jodon.core.database.LocalVideoEntry
import com.jodon.core.database.LocalYouTubeProfile
import com.jodon.core.designsystem.GeminiGlowInput
import com.jodon.core.designsystem.GlassBottomSheet
import com.jodon.core.designsystem.GlassButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.JoIcon
import com.jodon.core.designsystem.JoIcons
import com.jodon.core.designsystem.JoText
import com.jodon.core.designsystem.JoTheme
import com.jodon.engine.downloader.SegmentedDownloadEngine
import com.jodon.engine.extractors.AnalysisSnapshot
import com.jodon.engine.extractors.MediaOptionItem
import com.jodon.engine.extractors.NewPipeYouTubeEngine
import com.jodon.engine.extractors.YouTubeFeedItem
import com.jodon.engine.extractors.YouTubeWatchDetails
import com.jodon.feature.analyzer.AnalyzerResultSection
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.Page
import javax.inject.Inject

enum class YtSubTab { HOME, SHORTS, PROFILE }

data class YouTubeUiState(
    val subTab: YtSubTab = YtSubTab.HOME,
    val searchQuery: String = "",
    val suggestions: List<String> = emptyList(),
    val feed: List<YouTubeFeedItem> = emptyList(),
    val shorts: List<YouTubeFeedItem> = emptyList(),
    val isLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val pageIndex: Int = 0,
    val searchNextPage: Page? = null,
    val activeWatch: YouTubeWatchDetails? = null,
    val playAsAudioOnly: Boolean = false,
    val quickDownloadSnapshot: AnalysisSnapshot? = null,
    val toastMessageAr: String? = null,
    val errorAr: String? = null
)

/**
 * 100% Native Open-Source YouTube Client inside 𝒥𝒪 DON (powered by NewPipeExtractor + Media3).
 * Zero WebView, zero YouTube API key, zero Google login, infinite personalized feed, Shorts, Search,
 * direct Download & Copy Link on every single video, and Local Profile with SAF JSON Export/Import.
 */
@HiltViewModel
class YouTubeViewModel @Inject constructor(
    private val ytEngine: NewPipeYouTubeEngine,
    private val downloadEngine: SegmentedDownloadEngine,
    private val localStore: LocalAppStore
) : ViewModel() {
    private val _state = MutableStateFlow(YouTubeUiState())
    val state: StateFlow<YouTubeUiState> = _state.asStateFlow()
    val profile: StateFlow<LocalYouTubeProfile> = localStore.profile

    private var suggestionJob: Job? = null

    init {
        refreshHome()
    }

    fun selectSubTab(tab: YtSubTab) {
        _state.update { it.copy(subTab = tab, activeWatch = null) }
        if (tab == YtSubTab.SHORTS && _state.value.shorts.isEmpty()) loadShorts()
    }

    fun refreshHome() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, errorAr = null, pageIndex = 0, searchNextPage = null) }
            ytEngine.loadPersonalizedHome(0)
                .onSuccess { list -> _state.update { it.copy(feed = list, isLoading = false) } }
                .onFailure { _state.update { it.copy(isLoading = false, errorAr = "تأكد من النت وجرّب تحدّث الصفحة") } }
        }
    }

    /**
     * Infinite scroll pagination: seamlessly fetches next search Page OR next personalized home batch.
     */
    fun loadMoreInfinite() {
        val s = _state.value
        if (s.isLoading || s.isLoadingMore) return
        viewModelScope.launch {
            _state.update { it.copy(isLoadingMore = true) }
            if (s.searchQuery.isNotBlank() && s.searchNextPage != null) {
                ytEngine.search(s.searchQuery, s.searchNextPage).onSuccess { paged ->
                    _state.update {
                        it.copy(
                            feed = (it.feed + paged.items).distinctBy { v -> v.url },
                            searchNextPage = paged.nextPage,
                            isLoadingMore = false
                        )
                    }
                }.onFailure { _state.update { it.copy(isLoadingMore = false) } }
            } else {
                val nextIdx = s.pageIndex + 1
                ytEngine.loadPersonalizedHome(nextIdx).onSuccess { more ->
                    _state.update {
                        it.copy(
                            feed = (it.feed + more).distinctBy { v -> v.url },
                            pageIndex = nextIdx,
                            isLoadingMore = false
                        )
                    }
                }.onFailure { _state.update { it.copy(isLoadingMore = false) } }
            }
        }
    }

    fun loadShorts() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            ytEngine.loadShortsFeed()
                .onSuccess { list -> _state.update { it.copy(shorts = list, isLoading = false) } }
                .onFailure { _state.update { it.copy(isLoading = false) } }
        }
    }

    fun onSearchInput(q: String) {
        _state.update { it.copy(searchQuery = q) }
        suggestionJob?.cancel()
        if (q.isBlank()) {
            _state.update { it.copy(suggestions = emptyList()) }
            refreshHome()
            return
        }
        suggestionJob = viewModelScope.launch {
            delay(160)
            val list = ytEngine.searchSuggestions(q)
            _state.update { it.copy(suggestions = list) }
        }
    }

    fun executeSearch(query: String) {
        val clean = query.trim()
        if (clean.isBlank()) return
        viewModelScope.launch {
            localStore.recordSearch(clean)
            _state.update { it.copy(searchQuery = clean, suggestions = emptyList(), isLoading = true, subTab = YtSubTab.HOME, activeWatch = null) }
            ytEngine.search(clean, null)
                .onSuccess { paged ->
                    _state.update { it.copy(feed = paged.items, searchNextPage = paged.nextPage, isLoading = false) }
                }
                .onFailure { _state.update { it.copy(isLoading = false, errorAr = "مقدرناش نجيب نتائج البحث دلوقتي") } }
        }
    }

    fun openVideo(url: String, audioOnly: Boolean = false) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, playAsAudioOnly = audioOnly) }
            ytEngine.getWatchAndDownloadDetails(url).onSuccess { details ->
                localStore.recordVideoWatch(
                    LocalVideoEntry(
                        url = details.url,
                        title = details.title,
                        uploaderName = details.uploaderName,
                        uploaderUrl = details.uploaderUrl,
                        thumbnailUrl = details.thumbnailUrl,
                        durationSec = details.durationSec,
                        viewCount = details.viewCount
                    )
                )
                _state.update { it.copy(activeWatch = details, isLoading = false) }
            }.onFailure {
                _state.update { it.copy(isLoading = false, toastMessageAr = "تعذر فتح الفيديو") }
            }
        }
    }

    fun toggleAudioOnlyMode() {
        _state.update { it.copy(playAsAudioOnly = !it.playAsAudioOnly) }
    }

    fun openQuickDownload(videoUrl: String) {
        val cached = _state.value.activeWatch?.takeIf { it.url == videoUrl }?.downloadSnapshot
        if (cached != null) {
            _state.update { it.copy(quickDownloadSnapshot = cached) }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(toastMessageAr = "بنجهّز كل الجودات والأحجام الحقيقية...") }
            ytEngine.getWatchAndDownloadDetails(videoUrl).onSuccess { d ->
                _state.update { it.copy(quickDownloadSnapshot = d.downloadSnapshot, toastMessageAr = null) }
            }
        }
    }

    fun dismissQuickDownload() = _state.update { it.copy(quickDownloadSnapshot = null) }

    fun enqueueDownload(option: MediaOptionItem) {
        val snap = _state.value.quickDownloadSnapshot ?: _state.value.activeWatch?.downloadSnapshot ?: return
        viewModelScope.launch {
            downloadEngine.enqueueOption(snap.normalizedUrl, snap.suggestedFileName, option)
            _state.update { it.copy(quickDownloadSnapshot = null, toastMessageAr = "بدأ تحميل ${option.label} فوراً") }
        }
    }

    fun toggleSubscribe(channelUrl: String, name: String, avatar: String, subs: Long = -1L) {
        viewModelScope.launch {
            localStore.toggleSubscription(LocalChannelSub(channelUrl, name, avatar, subs))
        }
    }

    fun toggleLikeCurrent() {
        val w = _state.value.activeWatch ?: return
        viewModelScope.launch {
            localStore.toggleLike(LocalVideoEntry(w.url, w.title, w.uploaderName, w.uploaderUrl, w.thumbnailUrl, w.durationSec, w.viewCount))
        }
    }

    fun exportProfileJson(): String = localStore.exportProfileJson()

    fun importProfileJson(raw: String) {
        viewModelScope.launch {
            localStore.importProfileJson(raw)
                .onSuccess { _state.update { it.copy(toastMessageAr = "تم استيراد حسابك واشتراكاتك بنجاح") } }
                .onFailure { _state.update { it.copy(toastMessageAr = "ملف الحساب مش سليم") } }
        }
    }

    fun copyVideoLink(context: Context, url: String) {
        val cm = context.getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("JO DON Link", url))
        _state.update { it.copy(toastMessageAr = "اتنسخ اللينك") }
    }
}

@Composable
fun YouTubeScreen(
    hazeState: HazeState,
    viewModel: YouTubeViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val profile by viewModel.profile.collectAsState()
    val context = LocalContext.current
    val colors = JoTheme.colors

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            context.contentResolver.openOutputStream(uri)?.use { it.write(viewModel.exportProfileJson().toByteArray()) }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            if (!raw.isNullOrBlank()) viewModel.importProfileJson(raw)
        }
    }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        // Top native YouTube bar: Logo + Shorts + Local Account
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { viewModel.selectSubTab(YtSubTab.HOME) }) {
                JoIcon(JoIcons.YouTube, tint = colors.youtubeRed, size = 26.dp)
                Spacer(Modifier.width(8.dp))
                JoText("يوتيوب", style = JoTheme.typography.titleLarge)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton(
                    text = "شورتس",
                    primary = state.subTab == YtSubTab.SHORTS,
                    onClick = { viewModel.selectSubTab(YtSubTab.SHORTS) },
                    leading = { JoIcon(JoIcons.Shorts, tint = Color.White, size = 16.dp) }
                )
                GlassButton(
                    text = "حسابي",
                    primary = state.subTab == YtSubTab.PROFILE,
                    onClick = { viewModel.selectSubTab(YtSubTab.PROFILE) },
                    leading = { JoIcon(JoIcons.Profile, tint = Color.White, size = 16.dp) }
                )
            }
        }

        // Watch player when a video is active
        val watch = state.activeWatch
        if (watch != null) {
            NativeYouTubeWatchView(
                watch = watch,
                audioOnly = state.playAsAudioOnly,
                isSubscribed = profile.subscriptions.any { it.channelUrl == watch.uploaderUrl },
                isLiked = profile.likedVideos.any { it.url == watch.url },
                onToggleAudioOnly = viewModel::toggleAudioOnlyMode,
                onToggleSubscribe = { viewModel.toggleSubscribe(watch.uploaderUrl, watch.uploaderName, watch.uploaderAvatar, watch.subscriberCount) },
                onToggleLike = viewModel::toggleLikeCurrent,
                onDownload = { viewModel.openQuickDownload(watch.url) },
                onCopyLink = { viewModel.copyVideoLink(context, watch.url) },
                onSelectRelated = { viewModel.openVideo(it) },
                hazeState = hazeState
            )
        } else when (state.subTab) {
            YtSubTab.HOME -> {
                PaddingBox {
                    GeminiGlowInput(
                        value = state.searchQuery,
                        onValueChange = viewModel::onSearchInput,
                        placeholder = "دوّر في يوتيوب...",
                        isAnalyzing = state.isLoading,
                        trailing = {
                            if (state.searchQuery.isNotBlank()) {
                                GlassButton(text = "بحث", onClick = { viewModel.executeSearch(state.searchQuery) })
                            }
                        }
                    )
                }
                if (state.suggestions.isNotEmpty()) {
                    GlassCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp), hazeState = hazeState) {
                        state.suggestions.take(6).forEach { s ->
                            JoText(
                                text = s,
                                style = JoTheme.typography.body,
                                modifier = Modifier.fillMaxWidth().clickable { viewModel.executeSearch(s) }.padding(vertical = 7.dp)
                            )
                        }
                    }
                }
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 110.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    itemsIndexed(state.feed, key = { _, it -> it.url }) { index, item ->
                        if (index >= state.feed.lastIndex - 3) {
                            LaunchedEffect(index) { viewModel.loadMoreInfinite() }
                        }
                        val isSub = profile.subscriptions.any { it.channelUrl == item.uploaderUrl }
                        GlassCard(hazeState = hazeState, onClick = { viewModel.openVideo(item.url) }) {
                            Box(modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(JoTheme.shapes.button)) {
                                AsyncImage(item.thumbnailUrl, item.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                                if (item.durationSec > 0) {
                                    Box(
                                        modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)
                                            .clip(JoTheme.shapes.pill).background(Color.Black.copy(alpha = 0.75f))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        JoText(Formatters.formatDuration(item.durationSec), style = JoTheme.typography.caption, color = Color.White)
                                    }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            JoText(item.title, style = JoTheme.typography.titleMedium, maxLines = 2)
                            Spacer(Modifier.height(4.dp))
                            JoText(
                                "${item.uploaderName} • ${Formatters.formatViewCount(item.viewCount, true)}",
                                style = JoTheme.typography.caption,
                                color = colors.textSecondary
                            )
                            Spacer(Modifier.height(10.dp))
                            // Direct Download + Copy Link + Play as Song + Local Subscribe under every video
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                GlassButton(
                                    text = "حمّل",
                                    onClick = { viewModel.openQuickDownload(item.url) },
                                    modifier = Modifier.weight(1f),
                                    leading = { JoIcon(JoIcons.Download, Color.White, 15.dp) }
                                )
                                GlassButton(
                                    text = "نسخ اللينك",
                                    primary = false,
                                    onClick = { viewModel.copyVideoLink(context, item.url) },
                                    leading = { JoIcon(JoIcons.Copy, colors.textPrimary, 15.dp) }
                                )
                                if (item.uploaderUrl.isNotBlank()) {
                                    GlassButton(
                                        text = if (isSub) "مشترك" else "اشترك",
                                        primary = false,
                                        onClick = { viewModel.toggleSubscribe(item.uploaderUrl, item.uploaderName, item.uploaderAvatar) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            YtSubTab.SHORTS -> {
                val pagerState = rememberPagerState(pageCount = { state.shorts.size.coerceAtLeast(1) })
                VerticalPager(state = pagerState, modifier = Modifier.fillMaxSize().padding(bottom = 96.dp)) { page ->
                    val short = state.shorts.getOrNull(page) ?: return@VerticalPager
                    Box(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 6.dp).clip(JoTheme.shapes.card)) {
                        AsyncImage(short.thumbnailUrl, short.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        Column(
                            modifier = Modifier.align(Alignment.BottomStart)
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.58f))
                                .padding(16.dp)
                        ) {
                            JoText(short.title, style = JoTheme.typography.titleMedium, color = Color.White, maxLines = 2)
                            JoText(short.uploaderName, style = JoTheme.typography.caption, color = Color.White.copy(alpha = 0.8f))
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                GlassButton("شغّل", onClick = { viewModel.openVideo(short.url) })
                                GlassButton("حمّل", primary = false, onClick = { viewModel.openQuickDownload(short.url) })
                                GlassButton("نسخ", primary = false, onClick = { viewModel.copyVideoLink(context, short.url) })
                            }
                        }
                    }
                }
            }

            YtSubTab.PROFILE -> {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        GlassCard(hazeState = hazeState, elevated = true) {
                            JoText(profile.displayName, style = JoTheme.typography.titleLarge)
                            JoText("ملف محلي 100% على موبايلك من غير تسجيل دخول", style = JoTheme.typography.bodySmall, color = colors.textSecondary)
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                GlassButton(
                                    text = "تصدير حسابي",
                                    onClick = { exportLauncher.launch("jodon_profile.json") },
                                    modifier = Modifier.weight(1f)
                                )
                                GlassButton(
                                    text = "استيراد حسابي",
                                    primary = false,
                                    onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                    item {
                        JoText("القنوات المشترك فيها (${profile.subscriptions.size})", style = JoTheme.typography.titleMedium)
                    }
                    itemsIndexed(profile.subscriptions) { _, sub ->
                        GlassCard(hazeState = hazeState) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                JoText(sub.name, style = JoTheme.typography.titleMedium)
                                GlassButton("إلغاء الاشتراك", primary = false, onClick = { viewModel.toggleSubscribe(sub.channelUrl, sub.name, sub.avatarUrl) })
                            }
                        }
                    }
                    item {
                        JoText("سجل المشاهدة (${profile.watchHistory.size})", style = JoTheme.typography.titleMedium)
                    }
                    itemsIndexed(profile.watchHistory.take(30)) { _, h ->
                        GlassCard(hazeState = hazeState, onClick = { viewModel.openVideo(h.url) }) {
                            JoText(h.title, style = JoTheme.typography.label, maxLines = 1)
                            JoText(h.uploaderName, style = JoTheme.typography.caption, color = colors.textSecondary)
                        }
                    }
                }
            }
        }
    }

    // Download quality Bottom Sheet triggered from ANY YouTube video or Short
    GlassBottomSheet(
        visible = state.quickDownloadSnapshot != null,
        onDismiss = viewModel::dismissQuickDownload,
        title = "تحميل الفيديو أو الصوت",
        hazeState = hazeState
    ) {
        state.quickDownloadSnapshot?.let { snap ->
            AnalyzerResultSection(
                snapshot = snap,
                customFileName = snap.suggestedFileName,
                onFileNameChange = {},
                onDownloadOption = viewModel::enqueueDownload,
                hazeState = hazeState
            )
        }
    }
}

@Composable
private fun PaddingBox(content: @Composable () -> Unit) {
    Box(modifier = Modifier.padding(horizontal = 16.dp)) { content() }
}

@Composable
private fun NativeYouTubeWatchView(
    watch: YouTubeWatchDetails,
    audioOnly: Boolean,
    isSubscribed: Boolean,
    isLiked: Boolean,
    onToggleAudioOnly: () -> Unit,
    onToggleSubscribe: () -> Unit,
    onToggleLike: () -> Unit,
    onDownload: () -> Unit,
    onCopyLink: () -> Unit,
    onSelectRelated: (String) -> Unit,
    hazeState: HazeState
) {
    val context = LocalContext.current
    val streamUrl = if (audioOnly) (watch.bestAudioOnlyUrl ?: watch.bestPlayableVideoUrl) else (watch.bestPlayableVideoUrl ?: watch.hlsUrl)
    val exoPlayer = remember(streamUrl) {
        ExoPlayer.Builder(context).build().apply {
            if (!streamUrl.isNullOrBlank()) {
                setMediaItem(MediaItem.fromUri(streamUrl))
                prepare()
                playWhenReady = true
            }
        }
    }
    DisposableEffect(exoPlayer) { onDispose { exoPlayer.release() } }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            AndroidView(
                factory = { ctx -> PlayerView(ctx).apply { player = exoPlayer } },
                update = { it.player = exoPlayer },
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(JoTheme.shapes.card)
            )
        }
        item {
            JoText(watch.title, style = JoTheme.typography.titleLarge)
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                JoText(watch.uploaderName, style = JoTheme.typography.titleMedium, color = JoTheme.colors.textSecondary)
                GlassButton(text = if (isSubscribed) "مشترك" else "اشترك", primary = !isSubscribed, onClick = onToggleSubscribe)
            }
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("حمّل", onClick = onDownload, modifier = Modifier.weight(1f))
                GlassButton(if (audioOnly) "وضع فيديو" else "كأغنية", primary = false, onClick = onToggleAudioOnly)
                GlassButton("نسخ", primary = false, onClick = onCopyLink)
                GlassButton(if (isLiked) "عجبني ✓" else "أعجبني", primary = false, onClick = onToggleLike)
            }
        }
        itemsIndexed(watch.relatedItems, key = { _, it -> it.url }) { _, rel ->
            GlassCard(hazeState = hazeState, onClick = { onSelectRelated(rel.url) }) {
                JoText(rel.title, style = JoTheme.typography.label, maxLines = 2)
                JoText(rel.uploaderName, style = JoTheme.typography.caption, color = JoTheme.colors.textSecondary)
            }
        }
    }
}
