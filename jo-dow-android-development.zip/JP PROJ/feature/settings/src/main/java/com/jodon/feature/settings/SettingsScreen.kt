package com.jodon.feature.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jodon.core.common.FileSizeInfo
import com.jodon.core.database.AppSettingsState
import com.jodon.core.database.LocalAppStore
import com.jodon.core.designsystem.GlassButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.JoText
import com.jodon.core.designsystem.JoTheme
import com.jodon.core.designsystem.JoThemeId
import com.jodon.engine.downloader.SegmentedDownloadEngine
import com.jodon.engine.extractors.LinkAnalyzerPipeline
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val store: LocalAppStore,
    private val downloadEngine: SegmentedDownloadEngine,
    private val pipeline: LinkAnalyzerPipeline
) : ViewModel() {
    val settings: StateFlow<AppSettingsState> = store.settings
    private val _speedReport = MutableStateFlow<String?>(null)
    val speedReport = _speedReport.asStateFlow()

    fun selectTheme(theme: JoThemeId) {
        viewModelScope.launch { store.updateSettings { it.copy(themeName = theme.name) } }
    }

    fun toggleDarkMode() {
        viewModelScope.launch { store.updateSettings { it.copy(darkTheme = !it.darkTheme) } }
    }

    fun cycleSegments() {
        val steps = listOf(8, 16, 24, 32)
        viewModelScope.launch {
            store.updateSettings { s ->
                val next = steps[(steps.indexOf(s.segmentsPerDownload) + 1) % steps.size]
                s.copy(segmentsPerDownload = next)
            }
        }
    }

    fun runSpeedAdvisor() {
        viewModelScope.launch {
            _speedReport.value = "بنقيس سرعة النت عندك..."
            downloadEngine.runSpeedTest().onSuccess { (mbps, recommended) ->
                store.updateSettings { it.copy(segmentsPerDownload = recommended) }
                _speedReport.value = "سرعتك ${String.format(Locale.US, "%.1f", mbps)} ميجابت/ث • ظبطنالك $recommended اتصال متوازي!"
            }.onFailure {
                _speedReport.value = "تأكد من الاتصال وجرّب تاني"
            }
        }
    }

    fun updateExtractorsNow() {
        viewModelScope.launch {
            _speedReport.value = "بنحدّث محرك المواقع..."
            pipeline.initAndOptionalUpdate(autoUpdate = true)
            _speedReport.value = "المحرك متحدث لآخر إصدار!"
        }
    }
}

@Composable
fun SettingsScreen(
    hazeState: HazeState,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val settings by viewModel.settings.collectAsState()
    val speedMsg by viewModel.speedReport.collectAsState()
    val colors = JoTheme.colors

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            JoText("الإعدادات والثيمات", style = JoTheme.typography.hero)
            Spacer(Modifier.height(6.dp))
            GlassButton(
                text = if (settings.darkTheme) "الوضع الليلي شغّال • حوّل لنهاري" else "الوضع النهاري شغّال • حوّل لليلي",
                primary = false,
                onClick = viewModel::toggleDarkMode
            )
        }

        // Complete Theme Gallery with bundled offline photorealistic preview cards
        items(JoThemeId.entries) { theme ->
            val selected = settings.themeName == theme.name
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(116.dp)
                    .clip(JoTheme.shapes.card)
                    .border(
                        width = if (selected) 2.5.dp else 1.dp,
                        brush = if (selected) colors.signatureBrush else colors.specularBorderBrush,
                        shape = JoTheme.shapes.card
                    )
                    .clickable { viewModel.selectTheme(theme) }
            ) {
                Image(
                    painter = painterResource(id = theme.previewRes),
                    contentDescription = theme.titleAr,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.56f))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        JoText(theme.titleAr, style = JoTheme.typography.titleMedium, color = Color.White)
                        if (selected) JoText("مُفعّل ✓", style = JoTheme.typography.label, color = colors.success)
                    }
                    JoText(theme.subtitleAr, style = JoTheme.typography.caption, color = Color.White.copy(alpha = 0.82f))
                }
            }
        }

        item {
            GlassCard(hazeState = hazeState) {
                JoText("السرعة والمحرك", style = JoTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("الاتصالات: ${settings.segmentsPerDownload}", primary = false, onClick = viewModel::cycleSegments)
                    GlassButton("قياس السرعة", onClick = viewModel::runSpeedAdvisor)
                }
                Spacer(Modifier.height(8.dp))
                GlassButton("تحديث محرك المواقع", primary = false, onClick = viewModel::updateExtractorsNow)
                speedMsg?.let {
                    Spacer(Modifier.height(8.dp))
                    JoText(it, style = JoTheme.typography.caption, color = colors.accentPrimary)
                }
            }
        }

        item {
            GlassCard(hazeState = hazeState) {
                JoText("إحصائياتك على الجهاز", style = JoTheme.typography.titleMedium)
                JoText(
                    "إجمالي التحميل: ${FileSizeInfo(settings.totalBytesDownloaded, true).formatHuman(true)} • وفّرت بالتصغير: ${FileSizeInfo(settings.totalBytesSavedByCompressor, true).formatHuman(true)}",
                    style = JoTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                Spacer(Modifier.height(8.dp))
                JoText(
                    "تنبيه قانوني: المسؤولية على المستخدم في احترام حقوق النشر. التطبيق مش بيتجاوز DRM أو المحتوى المدفوع، وخصوصيتك محفوظة 100% بدون أي تتبع.",
                    style = JoTheme.typography.caption,
                    color = colors.textMuted
                )
            }
        }
    }
}
