package com.jodon.feature.compressor

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jodon.core.common.FileSizeInfo
import com.jodon.core.database.LocalAppStore
import com.jodon.core.designsystem.BeforeAfterGlassSlider
import com.jodon.core.designsystem.GlassButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.JoText
import com.jodon.core.designsystem.JoTheme
import com.jodon.engine.media.CompressionMode
import com.jodon.engine.media.CompressionOutcome
import com.jodon.engine.media.MediaProcessingEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class CompressorViewModel @Inject constructor(
    private val mediaEngine: MediaProcessingEngine,
    private val store: LocalAppStore
) : ViewModel() {
    private val _outcome = MutableStateFlow<CompressionOutcome?>(null)
    val outcome = _outcome.asStateFlow()

    fun compress(path: String, mode: CompressionMode) {
        val f = File(path)
        if (!f.exists()) return
        viewModelScope.launch {
            val res = mediaEngine.compressSmart(f, mode)
            _outcome.value = res
            if (res.savedBytes > 0) {
                store.updateSettings { it.copy(totalBytesSavedByCompressor = it.totalBytesSavedByCompressor + res.savedBytes) }
            }
        }
    }
}

@Composable
fun SmartCompressorCard(
    selectedFilePath: String,
    hazeState: HazeState,
    viewModel: CompressorViewModel = hiltViewModel()
) {
    var mode by remember { mutableStateOf(CompressionMode.LOSSLESS) }
    var split by remember { mutableFloatStateOf(0.5f) }
    val result by viewModel.outcome.collectAsState()
    val colors = JoTheme.colors

    GlassCard(hazeState = hazeState) {
        JoText("تصغير الحجم الذكي", style = JoTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassButton("بدون فقد نهائي", primary = mode == CompressionMode.LOSSLESS, onClick = { mode = CompressionMode.LOSSLESS })
            GlassButton("ذكي شفاف", primary = mode == CompressionMode.VISUALLY_TRANSPARENT, onClick = { mode = CompressionMode.VISUALLY_TRANSPARENT })
        }
        Spacer(Modifier.height(10.dp))
        GlassButton("صغّر الملف كنسخة جديدة", onClick = { viewModel.compress(selectedFilePath, mode) })

        result?.let { out ->
            Spacer(Modifier.height(12.dp))
            BeforeAfterGlassSlider(
                fraction = split,
                onFractionChange = { split = it },
                modifier = Modifier.fillMaxWidth().height(92.dp),
                beforeContent = {
                    Box(Modifier.fillMaxSize().background(colors.glassElevated), contentAlignment = Alignment.Center) {
                        JoText("قبل: ${FileSizeInfo(out.originalBytes, true).formatExactBytes(true)}", style = JoTheme.typography.caption)
                    }
                },
                afterContent = {
                    Box(Modifier.fillMaxSize().background(colors.accentPrimary.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                        JoText("بعد: ${FileSizeInfo(out.compressedBytes, true).formatExactBytes(true)}", style = JoTheme.typography.caption)
                    }
                }
            )
            Spacer(Modifier.height(8.dp))
            JoText(out.messageAr, style = JoTheme.typography.bodySmall, color = if (out.actuallySmaller) colors.success else colors.warning)
        }
    }
}
