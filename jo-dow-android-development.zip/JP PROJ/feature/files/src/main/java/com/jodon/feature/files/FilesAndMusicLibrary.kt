package com.jodon.feature.files

import android.content.Context
import android.provider.MediaStore
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import com.jodon.core.common.AppDispatchers
import com.jodon.core.common.FileSizeInfo
import com.jodon.core.common.Formatters
import com.jodon.core.common.MediaKind
import com.jodon.core.designsystem.GlassButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.JoText
import com.jodon.core.designsystem.JoTheme
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

data class LocalDeviceMedia(
    val path: String,
    val title: String,
    val artistOrFolder: String,
    val album: String,
    val durationSec: Long,
    val sizeBytes: Long,
    val kind: MediaKind
)

/**
 * Real offline Android MediaStore Music/Video scanner + AES-256-GCM Encrypted Private Vault.
 */
@HiltViewModel
class FilesLibraryViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val dispatchers: AppDispatchers
) : ViewModel() {
    private val _songs = MutableStateFlow<List<LocalDeviceMedia>>(emptyList())
    val songs = _songs.asStateFlow()

    private val _videos = MutableStateFlow<List<LocalDeviceMedia>>(emptyList())
    val videos = _videos.asStateFlow()

    private val vaultDir = File(context.filesDir, "private_vault").apply { mkdirs() }

    fun scanDeviceLibrary() {
        viewModelScope.launch(dispatchers.io) {
            _songs.value = queryAudio()
            _videos.value = queryVideo()
        }
    }

    suspend fun moveFileToEncryptedVault(source: File): Result<File> = withContext(dispatchers.io) {
        runCatching {
            val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            val target = File(vaultDir, "${source.name}.vault")
            val enc = EncryptedFile.Builder(
                context, target, key, EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()
            enc.openFileOutput().use { out -> source.inputStream().use { it.copyTo(out) } }
            target
        }
    }

    private fun queryAudio(): List<LocalDeviceMedia> = runCatching {
        val out = mutableListOf<LocalDeviceMedia>()
        val proj = arrayOf(
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE
        )
        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            proj,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0",
            null,
            "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                out += LocalDeviceMedia(
                    path = c.getString(0) ?: continue,
                    title = c.getString(1) ?: "أغنية",
                    artistOrFolder = c.getString(2) ?: "فنان غير معروف",
                    album = c.getString(3) ?: "ألبوم",
                    durationSec = c.getLong(4) / 1000L,
                    sizeBytes = c.getLong(5),
                    kind = MediaKind.AUDIO
                )
            }
        }
        out
    }.getOrDefault(emptyList())

    private fun queryVideo(): List<LocalDeviceMedia> = runCatching {
        val out = mutableListOf<LocalDeviceMedia>()
        val proj = arrayOf(
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE
        )
        context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            proj,
            null,
            null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                out += LocalDeviceMedia(
                    path = c.getString(0) ?: continue,
                    title = c.getString(1) ?: "فيديو",
                    artistOrFolder = c.getString(2) ?: "الكاميرا",
                    album = "",
                    durationSec = c.getLong(3) / 1000L,
                    sizeBytes = c.getLong(4),
                    kind = MediaKind.VIDEO
                )
            }
        }
        out
    }.getOrDefault(emptyList())
}

@Composable
fun FilesAndMusicLibraryScreen(
    onPlayMedia: (path: String, title: String) -> Unit,
    hazeState: HazeState,
    viewModel: FilesLibraryViewModel = hiltViewModel()
) {
    var tab by remember { mutableStateOf(0) } // 0=Music, 1=Albums, 2=Videos
    val songs by viewModel.songs.collectAsState()
    val videos by viewModel.videos.collectAsState()
    val colors = JoTheme.colors

    LaunchedEffect(Unit) { viewModel.scanDeviceLibrary() }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        JoText("موسيقتي وملفاتي", style = JoTheme.typography.hero, modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp))
        Row(modifier = Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassButton("أغاني (${songs.size})", primary = tab == 0, onClick = { tab = 0 })
            GlassButton("ألبومات", primary = tab == 1, onClick = { tab = 1 })
            GlassButton("فيديوهات (${videos.size})", primary = tab == 2, onClick = { tab = 2 })
        }
        Spacer(Modifier.height(10.dp))

        val list = if (tab == 2) videos else songs
        LazyColumn(
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 6.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(list, key = { it.path }) { media ->
                GlassCard(hazeState = hazeState, onClick = { onPlayMedia(media.path, media.title) }) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            JoText(media.title, style = JoTheme.typography.titleMedium, maxLines = 1)
                            JoText(
                                "${media.artistOrFolder} • ${Formatters.formatDuration(media.durationSec)} • ${FileSizeInfo(media.sizeBytes, true).formatHuman(true)}",
                                style = JoTheme.typography.caption,
                                color = colors.textSecondary
                            )
                        }
                        GlassButton("شغّل", onClick = { onPlayMedia(media.path, media.title) })
                    }
                }
            }
        }
    }
}
