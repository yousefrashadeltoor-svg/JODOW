package com.jodon.feature.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jodon.core.common.FileSizeInfo
import com.jodon.core.common.UrlNormalizer
import com.jodon.core.database.DownloadRecord
import com.jodon.core.database.LocalAppStore
import com.jodon.core.designsystem.GeminiGlowInput
import com.jodon.core.designsystem.GlassButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.JoText
import com.jodon.core.designsystem.JoTheme
import com.jodon.engine.downloader.SegmentedDownloadEngine
import com.jodon.engine.extractors.AnalysisSnapshot
import com.jodon.engine.extractors.LinkAnalyzerPipeline
import com.jodon.engine.extractors.MediaOptionItem
import com.jodon.feature.analyzer.AnalyzerResultSection
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val inputUrl: String = "",
    val clipboardUrl: String? = null,
    val isAnalyzing: Boolean = false,
    val snapshot: AnalysisSnapshot? = null,
    val customFileName: String = "",
    val batchCount: Int = 0,
    val feedbackAr: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val pipeline: LinkAnalyzerPipeline,
    private val downloadEngine: SegmentedDownloadEngine,
    private val store: LocalAppStore
) : ViewModel() {
    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()
    val recentDownloads: StateFlow<List<DownloadRecord>> = store.downloads

    private var activeJob: Job? = null

    fun onUrlChanged(raw: String) {
        val batch = UrlNormalizer.extractBatchUrls(raw)
        _state.update { it.copy(inputUrl = raw, batchCount = batch.size, feedbackAr = null) }
        activeJob?.cancel()
        val firstUrl = batch.firstOrNull().orEmpty()
        if (!firstUrl.startsWith("http") && !firstUrl.startsWith("magnet:")) {
            _state.update { it.copy(isAnalyzing = false, snapshot = null) }
            return
        }
        // 150ms input debounce + immediate cancellation of prior pipeline
        activeJob = viewModelScope.launch {
            delay(150)
            _state.update { it.copy(isAnalyzing = true) }
            pipeline.analyze(firstUrl).collect { snap ->
                _state.update {
                    it.copy(
                        snapshot = snap,
                        customFileName = snap.suggestedFileName,
                        isAnalyzing = !snap.isComplete
                    )
                }
            }
        }
    }

    fun inspectClipboard(text: String?) {
        if (!store.settings.value.clipboardMonitor) return
        val candidate = text?.trim()?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
        if (candidate != null && candidate != _state.value.inputUrl) {
            _state.update { it.copy(clipboardUrl = candidate) }
        }
    }

    fun onFileNameChange(name: String) {
        _state.update { it.copy(customFileName = name) }
    }

    fun startDownload(option: MediaOptionItem) {
        val snap = _state.value.snapshot ?: return
        val name = _state.value.customFileName.ifBlank { snap.suggestedFileName }
        viewModelScope.launch {
            downloadEngine.enqueueOption(snap.normalizedUrl, name, option)
            _state.update { it.copy(feedbackAr = "بدأ التحميل بأقصى سرعة في قائمة التحميلات") }
        }
    }
}

@Composable
fun HomeScreen(
    sharedIncomingUrl: String?,
    onOpenBrowser: (String) -> Unit,
    onOpenDownloads: () -> Unit,
    hazeState: HazeState,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val recents by viewModel.recentDownloads.collectAsState()
    val clipboard = LocalClipboardManager.current
    val colors = JoTheme.colors

    LaunchedEffect(sharedIncomingUrl) {
        if (!sharedIncomingUrl.isNullOrBlank()) viewModel.onUrlChanged(sharedIncomingUrl)
        else viewModel.inspectClipboard(clipboard.getText()?.text)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 16.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            JoText(text = "𝒥𝒪 DON", style = JoTheme.typography.hero, gradient = true)
            Spacer(Modifier.height(4.dp))
            JoText(text = "حط أي لينك وهنجيبلك كل الجودات في ثانية", style = JoTheme.typography.body, color = colors.textSecondary)
        }

        item {
            GeminiGlowInput(
                value = state.inputUrl,
                onValueChange = viewModel::onUrlChanged,
                placeholder = "حط لينك الفيديو أو الصوت أو الملف هنا...",
                isAnalyzing = state.isAnalyzing,
                trailing = {
                    GlassButton(
                        text = if (state.inputUrl.isBlank()) "الزق" else "امسح",
                        primary = state.inputUrl.isBlank(),
                        onClick = {
                            if (state.inputUrl.isBlank()) {
                                clipboard.getText()?.text?.let(viewModel::onUrlChanged)
                            } else viewModel.onUrlChanged("")
                        }
                    )
                }
            )
        }

        state.clipboardUrl?.takeIf { state.inputUrl.isBlank() }?.let { detected ->
            item {
                GlassCard(hazeState = hazeState, onClick = { viewModel.onUrlChanged(detected) }) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            JoText("لقينا لينك منسوخ عندك", style = JoTheme.typography.label, color = colors.accentPrimary)
                            JoText(detected, style = JoTheme.typography.caption, color = colors.textSecondary, maxLines = 1)
                        }
                        JoText("حلّله", style = JoTheme.typography.label, color = colors.accentPrimary)
                    }
                }
            }
        }

        state.feedbackAr?.let { msg ->
            item {
                GlassCard(hazeState = hazeState, onClick = onOpenDownloads) {
                    JoText(msg, style = JoTheme.typography.label, color = colors.success)
                }
            }
        }

        state.snapshot?.let { snap ->
            item {
                AnalyzerResultSection(
                    snapshot = snap,
                    customFileName = state.customFileName,
                    onFileNameChange = viewModel::onFileNameChange,
                    onDownloadOption = viewModel::startDownload,
                    onOpenInBrowserSniffer = onOpenBrowser,
                    hazeState = hazeState
                )
            }
        }

        if (recents.isNotEmpty()) {
            item {
                Spacer(Modifier.height(4.dp))
                JoText("آخر التحميلات", style = JoTheme.typography.titleMedium)
            }
            items(recents.take(5), key = { it.id }) { item ->
                GlassCard(hazeState = hazeState, onClick = onOpenDownloads) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            JoText(item.fileName, style = JoTheme.typography.label, maxLines = 1)
                            JoText(
                                FileSizeInfo(item.totalBytes, item.isExactSize).formatHuman(true),
                                style = JoTheme.typography.caption,
                                color = colors.textSecondary
                            )
                        }
                        val pct = if (item.totalBytes > 0) ((item.downloadedBytes * 100) / item.totalBytes).toInt() else 0
                        JoText("$pct%", style = JoTheme.typography.label, color = colors.accentPrimary)
                    }
                }
            }
        }
    }
}
