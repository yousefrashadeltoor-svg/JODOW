package com.jodon.feature.converter

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jodon.core.designsystem.GlassButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.JoText
import com.jodon.core.designsystem.JoTheme
import com.jodon.engine.media.MediaProcessingEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class ConverterViewModel @Inject constructor(
    private val mediaEngine: MediaProcessingEngine
) : ViewModel() {
    private val _status = MutableStateFlow<String?>(null)
    val status = _status.asStateFlow()

    fun convert(inputPath: String, targetExt: String, streamCopy: Boolean) {
        val file = File(inputPath)
        if (!file.exists()) {
            _status.value = "اختار ملف من جهازك الأول"
            return
        }
        viewModelScope.launch {
            _status.value = "بنحوّل لـ ${targetExt.uppercase()}..."
            val out = File(file.parentFile, "${file.nameWithoutExtension}_converted.$targetExt")
            mediaEngine.convertMedia(file, out, targetExt, streamCopyIfPossible = streamCopy)
                .onSuccess { _status.value = "اتحفظ بنجاح: ${it.name}" }
                .onFailure { _status.value = "فشل التحويل: ${it.message}" }
        }
    }
}

@Composable
fun ConverterCard(
    selectedFilePath: String,
    hazeState: HazeState,
    viewModel: ConverterViewModel = hiltViewModel()
) {
    var target by remember { mutableStateOf("mp3") }
    var streamCopy by remember { mutableStateOf(true) }
    val formats = listOf("mp3", "m4a", "flac", "opus", "wav", "mp4", "mkv", "gif")

    GlassCard(hazeState = hazeState) {
        JoText("تحويل واستخراج الصيغ", style = JoTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            formats.take(5).forEach { f ->
                GlassButton(f.uppercase(), primary = target == f, onClick = { target = f })
            }
        }
        Spacer(Modifier.height(8.dp))
        GlassButton(
            text = if (streamCopy) "نسخ مباشر من غير فقد جودة ✓" else "إعادة ترميز كاملة",
            primary = false,
            onClick = { streamCopy = !streamCopy }
        )
        Spacer(Modifier.height(10.dp))
        GlassButton("ابدأ التحويل", onClick = { viewModel.convert(selectedFilePath, target, streamCopy) })
    }
}
