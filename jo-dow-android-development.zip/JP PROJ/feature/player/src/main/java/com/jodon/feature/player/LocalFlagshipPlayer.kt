package com.jodon.feature.player

import android.content.Context
import android.content.Intent
import android.media.audiofx.BassBoost
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.ui.PlayerView
import com.jodon.core.common.Formatters
import com.jodon.core.designsystem.GlassButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.JoIcons
import com.jodon.core.designsystem.JoText
import com.jodon.core.designsystem.JoTheme
import com.jodon.core.designsystem.VisualWaveformTrimBar
import com.jodon.engine.media.MediaProcessingEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject
import kotlin.math.abs
import kotlin.math.sin

enum class JoRepeatMode(val labelAr: String) {
    OFF("بدون تكرار"),
    ALL("تكرار الكل"),
    ONE("تكرار الأغنية"),
    AB_LOOP("تكرار مقطع A-B")
}

/**
 * Background Media3 audio playback service enabling lock-screen controls & playing any video as a song.
 */
class JoDonPlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}

@HiltViewModel
class LocalPlayerViewModel @Inject constructor(
    private val mediaEngine: MediaProcessingEngine
) : ViewModel() {
    private val _messageAr = MutableStateFlow<String?>(null)
    val messageAr = _messageAr.asStateFlow()

    fun saveVisualTrim(filePath: String, startMs: Long, endMs: Long, asAudio: Boolean) {
        val input = File(filePath)
        if (!input.exists()) return
        viewModelScope.launch {
            val ext = if (asAudio) "m4a" else input.extension.ifBlank { "mp4" }
            val output = File(input.parentFile, "${input.nameWithoutExtension}_cut_${startMs / 1000}s.$ext")
            _messageAr.value = "بنقص المقطع اللي اخترته بدقة..."
            mediaEngine.trimMediaRange(input, output, startMs, endMs, audioOnly = asAudio, fadeInOut = asAudio)
                .onSuccess { _messageAr.value = "اتحفظ المقطع المقصوص: ${it.name}" }
                .onFailure { _messageAr.value = "مقدرناش نقص الملف: ${it.message}" }
        }
    }

    fun setTrimAsRingtone(context: Context, filePath: String, startMs: Long, endMs: Long) {
        if (!Settings.System.canWrite(context)) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
                    .setData(Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            _messageAr.value = "فعّل إذن تعديل النغمة وارجع دوس تاني وهتتظبط فوراً"
            return
        }
        val input = File(filePath)
        if (!input.exists()) return
        viewModelScope.launch {
            _messageAr.value = "بنجهّز نغمة الرنين بتلاشي ناعم..."
            val ringClip = File(context.cacheDir, "${input.nameWithoutExtension}_ringtone.m4a")
            mediaEngine.trimMediaRange(input, ringClip, startMs, endMs, audioOnly = true, fadeInOut = true)
                .onSuccess { clip ->
                    mediaEngine.setAsPhoneRingtone(clip, input.nameWithoutExtension)
                        .onSuccess { _messageAr.value = "اتظبطت نغمة رنين لموبايلك بنجاح!" }
                        .onFailure { _messageAr.value = "تعذر ضبط النغمة: ${it.message}" }
                }
        }
    }

    /**
     * Generates deterministic visual waveform amplitudes from real file bytes for instant offline scrubbing.
     */
    fun computeFileWaveform(path: String, bars: Int = 64): List<Float> {
        val f = File(path)
        if (!f.exists() || f.length() < bars) {
            return List(bars) { i -> (0.25f + 0.65f * abs(sin(i * 0.37f))) }
        }
        return runCatching {
            java.io.RandomAccessFile(f, "r").use { raf ->
                val step = (f.length() / bars).coerceAtLeast(1L)
                val sample = ByteArray(256)
                List(bars) { idx ->
                    raf.seek(idx * step)
                    val n = raf.read(sample).coerceAtLeast(1)
                    val avg = sample.take(n).map { abs(it.toInt()) }.average() / 128.0
                    avg.toFloat().coerceIn(0.14f, 0.98f)
                }
            }
        }.getOrElse { List(bars) { 0.5f } }
    }
}

@Composable
fun LocalFlagshipPlayerScreen(
    mediaUriOrPath: String,
    title: String,
    hazeState: HazeState,
    viewModel: LocalPlayerViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val colors = JoTheme.colors
    val message by viewModel.messageAr.collectAsState()

    var audioOnly by remember { mutableStateOf(mediaUriOrPath.endsWith(".mp3", true) || mediaUriOrPath.endsWith(".m4a", true) || mediaUriOrPath.endsWith(".flac", true)) }
    var repeatMode by remember { mutableStateOf(JoRepeatMode.OFF) }
    var speed by remember { mutableFloatStateOf(1.0f) }
    var bassEnabled by remember { mutableStateOf(false) }
    var sleepRemainingSec by remember { mutableLongStateOf(0L) }
    var showVisualTrimmer by remember { mutableStateOf(false) }
    var trimStart by remember { mutableFloatStateOf(0.12f) }
    var trimEnd by remember { mutableFloatStateOf(0.55f) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(1L) }

    val waveform = remember(mediaUriOrPath) { viewModel.computeFileWaveform(mediaUriOrPath) }

    val player = remember(mediaUriOrPath) {
        ExoPlayer.Builder(context).build().apply {
            val uri = if (mediaUriOrPath.startsWith("content://") || mediaUriOrPath.startsWith("http")) {
                Uri.parse(mediaUriOrPath)
            } else Uri.fromFile(File(mediaUriOrPath))
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = true
        }
    }

    // Optional hardware BassBoost audio effect
    DisposableEffect(player, bassEnabled) {
        val fx = runCatching {
            if (bassEnabled && player.audioSessionId != C.AUDIO_SESSION_ID_UNSET) {
                BassBoost(0, player.audioSessionId).apply { setStrength(650.toShort()); enabled = true }
            } else null
        }.getOrNull()
        onDispose { runCatching { fx?.release() } }
    }

    DisposableEffect(player) { onDispose { player.release() } }

    // Live timeline + A-B loop + manual trim preview + Sleep Timer with smooth volume fade-out
    LaunchedEffect(player, repeatMode, showVisualTrimmer, trimStart, trimEnd) {
        while (isActive) {
            positionMs = player.currentPosition.coerceAtLeast(0L)
            durationMs = player.duration.takeIf { it > 0 } ?: 1L
            if ((repeatMode == JoRepeatMode.AB_LOOP || showVisualTrimmer) && durationMs > 1000L) {
                val endMs = (trimEnd * durationMs).toLong()
                val startMs = (trimStart * durationMs).toLong()
                if (positionMs >= endMs) player.seekTo(startMs)
            }
            delay(200)
        }
    }

    LaunchedEffect(sleepRemainingSec > 0L) {
        while (sleepRemainingSec > 0L && isActive) {
            delay(1000)
            sleepRemainingSec--
            if (sleepRemainingSec in 1..10) {
                player.volume = sleepRemainingSec / 10f // Smooth sleep fade-out
            } else if (sleepRemainingSec == 0L) {
                player.pause()
                player.volume = 1f
            }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            if (!audioOnly) {
                AndroidView(
                    factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
                    update = { it.player = player },
                    modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(JoTheme.shapes.card)
                )
            } else {
                AuroraAudioVisualizer(isPlaying = player.isPlaying)
            }
        }

        item {
            JoText(title, style = JoTheme.typography.titleLarge, maxLines = 2)
            JoText(
                "${Formatters.formatDuration(positionMs / 1000)} / ${Formatters.formatDuration(durationMs / 1000)}",
                style = JoTheme.typography.caption,
                color = colors.textSecondary
            )
        }

        // Core music & video tools: Play as Song, Visual Manual Trim, Set as Ringtone, BassBoost
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton(
                    text = if (audioOnly) "وضع الفيديو" else "شغّل كأغنية",
                    primary = audioOnly,
                    onClick = { audioOnly = !audioOnly },
                    modifier = Modifier.weight(1f)
                )
                GlassButton(
                    text = "قص يدوي",
                    primary = showVisualTrimmer,
                    onClick = { showVisualTrimmer = !showVisualTrimmer },
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton(
                    text = "خلّيها نغمة رنين",
                    primary = false,
                    onClick = {
                        val s = (trimStart * durationMs).toLong()
                        val e = (trimEnd * durationMs).toLong().coerceAtMost(s + 30_000L)
                        viewModel.setTrimAsRingtone(context, mediaUriOrPath, s, e)
                    },
                    modifier = Modifier.weight(1f)
                )
                GlassButton(
                    text = if (bassEnabled) "بيز عميق ✓" else "بيز عميق",
                    primary = bassEnabled,
                    onClick = { bassEnabled = !bassEnabled },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Interactive manual visual waveform trimmer (drag handles directly — zero typing)
        if (showVisualTrimmer) {
            item {
                GlassCard(hazeState = hazeState, elevated = true) {
                    val startSec = ((trimStart * durationMs) / 1000).coerceAtLeast(0)
                    val endSec = ((trimEnd * durationMs) / 1000).coerceAtLeast(0)
                    JoText("اسحب البداية والنهاية بإيدك على الموجة", style = JoTheme.typography.titleMedium)
                    JoText(
                        "من ${Formatters.formatDuration(startSec)} لحد ${Formatters.formatDuration(endSec)} (المدة ${Formatters.formatDuration(endSec - startSec)})",
                        style = JoTheme.typography.caption,
                        color = colors.accentPrimary
                    )
                    Spacer(Modifier.height(10.dp))
                    VisualWaveformTrimBar(
                        amplitudes = waveform,
                        startFraction = trimStart,
                        endFraction = trimEnd,
                        playheadFraction = (positionMs.toFloat() / durationMs).coerceIn(0f, 1f),
                        onRangeChange = { ns, ne ->
                            trimStart = ns
                            trimEnd = ne
                            player.seekTo((ns * durationMs).toLong())
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassButton(
                            text = "احفظ المقطع",
                            onClick = { viewModel.saveVisualTrim(mediaUriOrPath, (trimStart * durationMs).toLong(), (trimEnd * durationMs).toLong(), audioOnly) },
                            modifier = Modifier.weight(1f)
                        )
                        GlassButton(
                            text = "نغمة من المقطع ده",
                            primary = false,
                            onClick = { viewModel.setTrimAsRingtone(context, mediaUriOrPath, (trimStart * durationMs).toLong(), (trimEnd * durationMs).toLong()) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Repeat modes (Off / All / One / A-B Loop), Playback Speed & Sleep Timer
        item {
            GlassCard(hazeState = hazeState) {
                JoText("التكرار والسرعة ومؤقت النوم", style = JoTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton(
                        text = repeatMode.labelAr,
                        primary = repeatMode != JoRepeatMode.OFF,
                        onClick = {
                            val next = JoRepeatMode.entries[(repeatMode.ordinal + 1) % JoRepeatMode.entries.size]
                            repeatMode = next
                            player.repeatMode = when (next) {
                                JoRepeatMode.ONE -> Player.REPEAT_MODE_ONE
                                JoRepeatMode.ALL -> Player.REPEAT_MODE_ALL
                                else -> Player.REPEAT_MODE_OFF
                            }
                        }
                    )
                    GlassButton(
                        text = "السرعة ${speed}x",
                        primary = false,
                        onClick = {
                            val speeds = listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
                            speed = speeds[(speeds.indexOf(speed) + 1) % speeds.size]
                            player.playbackParameters = PlaybackParameters(speed)
                        }
                    )
                }
                Spacer(Modifier.height(10.dp))
                JoText(
                    if (sleepRemainingSec > 0) "مؤقت النوم شغّال: فاضل ${Formatters.formatDuration(sleepRemainingSec)}"
                    else "مؤقت النوم (يقفل لوحده بهدوء)",
                    style = JoTheme.typography.caption,
                    color = colors.textSecondary
                )
                Spacer(Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf(0 to "إيقاف", 15 to "15 د", 30 to "30 د", 45 to "45 د", 60 to "ساعة")) { (mins, label) ->
                        GlassButton(
                            text = label,
                            primary = (mins > 0 && sleepRemainingSec in ((mins - 14) * 60L)..(mins * 60L)),
                            onClick = { sleepRemainingSec = mins * 60L }
                        )
                    }
                }
            }
        }

        message?.let { msg ->
            item {
                GlassCard(hazeState = hazeState) {
                    JoText(msg, style = JoTheme.typography.label, color = colors.success)
                }
            }
        }
    }
}

@Composable
private fun AuroraAudioVisualizer(isPlaying: Boolean) {
    val colors = JoTheme.colors
    val infinite = rememberInfiniteTransition(label = "viz")
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 6.283f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
        label = "vizP"
    )
    GlassCard(elevated = true) {
        Canvas(modifier = Modifier.fillMaxWidth().height(150.dp)) {
            val bars = 36
            val step = size.width / bars
            for (i in 0 until bars) {
                val wave = if (isPlaying) 0.22f + 0.72f * abs(sin(phase + i * 0.35f)) else 0.14f
                val h = size.height * wave
                val x = i * step + step / 2f
                drawLine(
                    brush = colors.signatureBrush,
                    start = Offset(x, (size.height - h) / 2f),
                    end = Offset(x, (size.height + h) / 2f),
                    strokeWidth = (step * 0.55f),
                    cap = StrokeCap.Round
                )
            }
        }
    }
}
