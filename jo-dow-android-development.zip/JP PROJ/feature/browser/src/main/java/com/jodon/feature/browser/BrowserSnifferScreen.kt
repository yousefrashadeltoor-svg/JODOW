package com.jodon.feature.browser

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jodon.core.common.MediaKind
import com.jodon.core.common.UrlNormalizer
import com.jodon.core.database.LocalAppStore
import com.jodon.core.designsystem.GeminiGlowInput
import com.jodon.core.designsystem.GlassBottomSheet
import com.jodon.core.designsystem.GlassButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.JoText
import com.jodon.core.designsystem.JoTheme
import com.jodon.core.network.EncryptedBridgeCookieJar
import com.jodon.core.network.ExactSizeResolver
import com.jodon.engine.downloader.SegmentedDownloadEngine
import com.jodon.engine.extractors.MediaOptionItem
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import javax.inject.Inject

/**
 * High-speed AdBlock & Anti-Popup filter engine with EasyList/EasyPrivacy rules + cosmetic CSS injection.
 * // VERIFY: Can also attach JNI libadblock_rust.so directly to shouldBlock() when NDK Rust toolchain is enabled.
 */
object AdBlockFilterEngine {
    private val blockedHosts = setOf(
        "doubleclick.net", "googlesyndication.com", "google-analytics.com", "adnxs.com",
        "popads.net", "popcash.net", "propellerads.com", "exoclick.com", "taboola.com",
        "outbrain.com", "criteo.com", "scorecardresearch.com", "adsterra.com", "clickadu.com"
    )

    const val COSMETIC_AND_SNIFFER_JS = """
        (function(){
            const st = document.createElement('style');
            st.textContent = '[id*="google_ads"],[class*="ad-banner"],[class*="popup-ad"],a[href*="popads"],[class*="fake-download"]{display:none!important;}';
            document.head && document.head.appendChild(st);
            const report = (u) => { if(u && typeof u==='string' && u.startsWith('http')) window.JoSniffer.onMedia(u); };
            document.querySelectorAll('video,audio,source').forEach(el => report(el.src || el.currentSrc));
            const origFetch = window.fetch;
            window.fetch = function(input, init){
                try { report(typeof input==='string' ? input : input.url); } catch(e){}
                return origFetch.apply(this, arguments);
            };
            const origOpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function(m, u){ try { report(u); } catch(e){} return origOpen.apply(this, arguments); };
        })();
    """

    fun shouldBlock(requestUrl: String, pageHost: String, whitelist: Set<String>): Boolean {
        if (pageHost in whitelist) return false
        val host = UrlNormalizer.extractDomain(requestUrl)
        return blockedHosts.any { host == it || host.endsWith(".$it") }
    }

    fun detectMediaKind(url: String): MediaKind? {
        val clean = url.substringBefore("?").lowercase()
        return when {
            clean.endsWith(".mp4") || clean.endsWith(".mkv") || clean.endsWith(".webm") ||
                clean.endsWith(".m3u8") || clean.endsWith(".mpd") || clean.endsWith(".mov") -> MediaKind.VIDEO
            clean.endsWith(".mp3") || clean.endsWith(".m4a") || clean.endsWith(".opus") ||
                clean.endsWith(".flac") || clean.endsWith(".wav") -> MediaKind.AUDIO
            clean.endsWith(".zip") || clean.endsWith(".apk") || clean.endsWith(".pdf") ||
                clean.endsWith(".7z") || clean.endsWith(".rar") || clean.endsWith(".iso") -> MediaKind.FILE
            else -> null
        }
    }
}

@HiltViewModel
class BrowserSnifferViewModel @Inject constructor(
    private val cookieJar: EncryptedBridgeCookieJar,
    private val sizeResolver: ExactSizeResolver,
    private val downloader: SegmentedDownloadEngine,
    private val store: LocalAppStore
) : ViewModel() {
    private val _sniffed = MutableStateFlow<List<MediaOptionItem>>(emptyList())
    val sniffed: StateFlow<List<MediaOptionItem>> = _sniffed.asStateFlow()

    private val _blockedCount = MutableStateFlow(0)
    val blockedCount: StateFlow<Int> = _blockedCount.asStateFlow()

    fun shouldBlock(reqUrl: String, pageUrl: String): Boolean {
        val settings = store.settings.value
        if (!settings.adBlockEnabled) return false
        val blocked = AdBlockFilterEngine.shouldBlock(reqUrl, UrlNormalizer.extractDomain(pageUrl), settings.adBlockWhitelistDomains)
        if (blocked) _blockedCount.update { it + 1 }
        return blocked
    }

    fun onPageFinishedSyncCookies(pageUrl: String, userAgent: String) {
        // Legitimate Cloudflare cf_clearance + session cookie bridge to OkHttp/Downloader
        cookieJar.importFromWebView(pageUrl, userAgent)
    }

    fun onCandidateUrl(mediaUrl: String, pageUrl: String, reqHeaders: Map<String, String>) {
        val kind = AdBlockFilterEngine.detectMediaKind(mediaUrl) ?: return
        if (_sniffed.value.any { it.directUrl == mediaUrl }) return
        viewModelScope.launch {
            val probe = sizeResolver.probeExact(mediaUrl, reqHeaders + ("Referer" to pageUrl))
            val name = probe.fileName ?: mediaUrl.substringAfterLast("/").substringBefore("?").take(60)
            val ext = name.substringAfterLast(".", if (kind == MediaKind.VIDEO) "mp4" else "bin")
            val item = MediaOptionItem(
                id = "sniff_${mediaUrl.hashCode()}",
                kind = kind,
                label = name,
                formatExt = ext,
                codec = if (mediaUrl.contains(".m3u8")) "HLS" else "مباشر",
                fpsOrBitrate = "ملقوط من الصفحة",
                directUrl = probe.finalUrl,
                size = probe.size,
                headers = reqHeaders + ("Referer" to pageUrl)
            )
            _sniffed.update { (listOf(item) + it).distinctBy { x -> x.directUrl } }
        }
    }

    fun downloadSniffed(item: MediaOptionItem, pageUrl: String) {
        viewModelScope.launch {
            downloader.enqueueOption(pageUrl, item.label, item, item.headers)
        }
    }

    fun clearSniffed() = _sniffed.update { emptyList() }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserSnifferScreen(
    initialUrl: String,
    hazeState: HazeState,
    viewModel: BrowserSnifferViewModel = hiltViewModel()
) {
    var address by remember { mutableStateOf(initialUrl.ifBlank { "https://archive.org" }) }
    var activeUrl by remember { mutableStateOf(address) }
    var desktopMode by remember { mutableStateOf(false) }
    var showSheet by remember { mutableStateOf(false) }
    val sniffed by viewModel.sniffed.collectAsState()
    val blocked by viewModel.blockedCount.collectAsState()

    Box(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        Column(modifier = Modifier.fillMaxSize().padding(bottom = 96.dp)) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                GeminiGlowInput(
                    value = address,
                    onValueChange = { address = it },
                    placeholder = "اكتب لينك الموقع...",
                    isAnalyzing = false,
                    trailing = {
                        GlassButton("افتح", onClick = {
                            viewModel.clearSniffed()
                            activeUrl = UrlNormalizer.normalize(address)
                        })
                    }
                )
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    JoText("اتحجب $blocked إعلان", style = JoTheme.typography.caption, color = JoTheme.colors.success)
                    GlassButton(
                        text = if (desktopMode) "وضع الموبايل" else "وضع الكمبيوتر",
                        primary = false,
                        onClick = { desktopMode = !desktopMode }
                    )
                }
            }

            AndroidView(
                modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 10.dp).clip(JoTheme.shapes.card),
                factory = { ctx ->
                    WebView(ctx).apply {
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.setSupportMultipleWindows(false) // Block popunders
                        addJavascriptInterface(object {
                            @JavascriptInterface
                            fun onMedia(u: String) {
                                viewModel.onCandidateUrl(u, activeUrl, emptyMap())
                            }
                        }, "JoSniffer")
                        setDownloadListener { url, userAgent, _, _, _ ->
                            viewModel.onCandidateUrl(url, activeUrl, mapOf("User-Agent" to userAgent))
                            showSheet = true
                        }
                        webViewClient = object : WebViewClient() {
                            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse? {
                                val reqUrl = request.url.toString()
                                if (viewModel.shouldBlock(reqUrl, activeUrl)) {
                                    return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
                                }
                                viewModel.onCandidateUrl(reqUrl, activeUrl, request.requestHeaders)
                                return super.shouldInterceptRequest(view, request)
                            }

                            override fun onPageFinished(view: WebView, url: String) {
                                address = url
                                viewModel.onPageFinishedSyncCookies(url, view.settings.userAgentString)
                                view.evaluateJavascript(AdBlockFilterEngine.COSMETIC_AND_SNIFFER_JS, null)
                            }
                        }
                        loadUrl(activeUrl)
                    }
                },
                update = { wv ->
                    wv.settings.useWideViewPort = desktopMode
                    if (wv.url != activeUrl && activeUrl.startsWith("http")) wv.loadUrl(activeUrl)
                }
            )
        }

        if (sniffed.isNotEmpty()) {
            GlassButton(
                text = "الملفات الملقوطة",
                badgeCount = sniffed.size,
                onClick = { showSheet = true },
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = 112.dp)
            )
        }

        GlassBottomSheet(visible = showSheet, onDismiss = { showSheet = false }, title = "الملفات الملقوطة (${sniffed.size})", hazeState = hazeState) {
            LazyColumn(modifier = Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sniffed, key = { it.id }) { item ->
                    GlassCard {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                JoText(item.label, style = JoTheme.typography.label, maxLines = 1)
                                JoText("${item.formatExt.uppercase()} • ${item.size.formatHuman(true)}", style = JoTheme.typography.caption, color = JoTheme.colors.textSecondary)
                            }
                            GlassButton("حمّل", onClick = {
                                viewModel.downloadSniffed(item, activeUrl)
                                showSheet = false
                            })
                        }
                    }
                }
            }
        }
    }
}
