package com.jodon.feature.downloads

import android.content.ClipData
import android.content.ClipboardManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import com.jodon.core.common.FileSizeInfo
import com.jodon.core.common.Formatters
import com.jodon.core.database.DownloadRecord
import com.jodon.core.database.DownloadStatus
import com.jodon.core.database.LocalAppStore
import com.jodon.core.designsystem.GlassButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.JoText
import com.jodon.core.designsystem.JoTheme
import com.jodon.core.designsystem.SpeedSparkline
import com.jodon.engine.downloader.SegmentedDownloadEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    store: LocalAppStore,
    private val engine: SegmentedDownloadEngine
) : ViewModel() {
    val downloads: StateFlow<List<DownloadRecord>> = store.downloads
    fun pause(id: String) = engine.pause(id)
    fun resume(id: String) = engine.resume(id)
    fun cancel(id: String) = engine.cancel(id)
}

@Composable
fun DownloadsScreen(
    onOpenInPlayer: (String) -> Unit,
    onOpenInCompressor: (String) -> Unit,
    hazeState: HazeState,
    viewModel: DownloadsViewModel = hiltViewModel()
) {
    val all by viewModel.downloads.collectAsState()
    var filter by remember { mutableStateOf<DownloadStatus?>(null) }
    val colors = JoTheme.colors
    val context = LocalContext.current

    val tabs = listOf(
        null to "الكل",
        DownloadStatus.RUNNING to "شغّال",
        DownloadStatus.QUEUED to "في الطابور",
        DownloadStatus.COMPLETED to "خلص",
        DownloadStatus.FAILED to "وقف"
    )
    val filtered = if (filter == null) all else all.filter { it.status == filter }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        JoText("التحميلات", style = JoTheme.typography.hero, modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tabs) { (st, label) ->
                GlassButton(text = label, primary = filter == st, onClick = { filter = st })
            }
        }
        Spacer(Modifier.height(10.dp))

        LazyColumn(
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 6.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (filtered.isEmpty()) {
                item {
                    GlassCard(hazeState = hazeState) {
                        JoText("مفيش تحميلات هنا دلوقتي", style = JoTheme.typography.titleMedium)
                        JoText("حط أي لينك في الرئيسية أو حمّل من يوتيوب وهتلاقيه طاير هنا", style = JoTheme.typography.bodySmall, color = colors.textSecondary)
                    }
                }
            }
            items(filtered, key = { it.id }) { item ->
                val progress = if (item.totalBytes > 0) (item.downloadedBytes.toFloat() / item.totalBytes).coerceIn(0f, 1f) else 0f
                GlassCard(hazeState = hazeState, elevated = item.status == DownloadStatus.RUNNING) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        JoText(item.fileName, style = JoTheme.typography.titleMedium, maxLines = 1, modifier = Modifier.weight(1f))
                        JoText("${(progress * 100).toInt()}%", style = JoTheme.typography.label, color = colors.accentPrimary)
                    }
                    Spacer(Modifier.height(8.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(7.dp).clip(JoTheme.shapes.pill).background(colors.glassElevated)) {
                        Box(modifier = Modifier.fillMaxWidth(progress).height(7.dp).clip(JoTheme.shapes.pill).background(colors.signatureBrush))
                    }
                    Spacer(Modifier.height(8.dp))
                    val doneText = FileSizeInfo(item.downloadedBytes, true).formatHuman(true)
                    val totalText = FileSizeInfo(item.totalBytes, item.isExactSize).formatHuman(true)
                    val meta = when (item.status) {
                        DownloadStatus.RUNNING ->
                            "$doneText من $totalText • ${Formatters.formatSpeed(item.speedBytesPerSec)} • ${item.activeConnections} اتصال • ${Formatters.formatEta(item.totalBytes - item.downloadedBytes, item.speedBytesPerSec)}"
                        DownloadStatus.MERGING -> "بندمج الصوت والفيديو بأعلى جودة..."
                        DownloadStatus.COMPLETED -> "خلص • $totalText"
                        DownloadStatus.PAUSED -> "متوقف مؤقتاً • $doneText من $totalText"
                        DownloadStatus.FAILED -> item.errorMessage ?: "فشل التحميل"
                        else -> "في الطابور • $totalText"
                    }
                    JoText(meta, style = JoTheme.typography.caption, color = colors.textSecondary)

                    if (item.speedHistory.size > 2 && item.status == DownloadStatus.RUNNING) {
                        Spacer(Modifier.height(6.dp))
                        SpeedSparkline(samples = item.speedHistory)
                    }

                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        when (item.status) {
                            DownloadStatus.RUNNING -> GlassButton("وقّف", primary = false, onClick = { viewModel.pause(item.id) })
                            DownloadStatus.PAUSED, DownloadStatus.FAILED -> GlassButton("كمّل", onClick = { viewModel.resume(item.id) })
                            DownloadStatus.COMPLETED -> {
                                GlassButton("شغّل", onClick = { onOpenInPlayer(item.destinationPath) })
                                GlassButton("صغّر الحجم", primary = false, onClick = { onOpenInCompressor(item.destinationPath) })
                            }
                            else -> Unit
                        }
                        GlassButton("نسخ اللينك", primary = false, onClick = {
                            context.getSystemService(ClipboardManager::class.java)
                                .setPrimaryClip(ClipData.newPlainText("url", item.sourcePageUrl))
                        })
                        GlassButton("مسح", primary = false, onClick = { viewModel.cancel(item.id) })
                    }
                }
            }
        }
    }
}
