package com.jodon.app

import android.app.Application
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.service.quicksettings.TileService
import android.widget.RemoteViews
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jodon.core.database.LocalAppStore
import com.jodon.core.designsystem.AuroraMeshBackground
import com.jodon.core.designsystem.DockItem
import com.jodon.core.designsystem.FloatingGlassDock
import com.jodon.core.designsystem.GlassButton
import com.jodon.core.designsystem.GlassCard
import com.jodon.core.designsystem.JoDonTheme
import com.jodon.core.designsystem.JoIcons
import com.jodon.core.designsystem.JoText
import com.jodon.core.designsystem.JoTheme
import com.jodon.core.designsystem.JoThemeId
import com.jodon.engine.extractors.LinkAnalyzerPipeline
import com.jodon.feature.browser.BrowserSnifferScreen
import com.jodon.feature.compressor.SmartCompressorCard
import com.jodon.feature.converter.ConverterCard
import com.jodon.feature.downloads.DownloadsScreen
import com.jodon.feature.files.FilesAndMusicLibraryScreen
import com.jodon.feature.home.HomeScreen
import com.jodon.feature.player.LocalFlagshipPlayerScreen
import com.jodon.feature.settings.SettingsScreen
import com.jodon.feature.youtube.YouTubeScreen
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.HiltAndroidApp
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@HiltAndroidApp
class JoDonApplication : Application() {
    @Inject lateinit var pipeline: LinkAnalyzerPipeline
    @Inject lateinit var store: LocalAppStore

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) Timber.plant(Timber.DebugTree())
        // Initialize open-source extractors silently on IO so cold start stays < 1s and UI renders offline
        appScope.launch {
            runCatching { pipeline.initAndOptionalUpdate(store.settings.value.autoUpdateExtractors) }
        }
    }
}

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    @Inject lateinit var store: LocalAppStore
    private val incomingUrl = mutableStateOf<String?>(null)
    private val startOnYouTube = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        consumeIntent(intent)

        setContent {
            val settings by store.settings.collectAsState()
            val scope = rememberCoroutineScope()
            val theme = remember(settings.themeName) {
                runCatching { JoThemeId.valueOf(settings.themeName) }.getOrDefault(JoThemeId.AURORA)
            }

            JoDonTheme(
                themeId = theme,
                darkTheme = settings.darkTheme,
                isArabic = settings.isArabic,
                blurScale = settings.blurScale
            ) {
                if (!settings.onboardingDone) {
                    JoDonOnboardingScreen(
                        onFinish = { scope.launch { store.updateSettings { it.copy(onboardingDone = true) } } }
                    )
                } else {
                    JoDonRootShell(
                        sharedUrl = incomingUrl.value,
                        initialRoute = if (startOnYouTube.value) "youtube" else "home"
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        consumeIntent(intent)
    }

    private fun consumeIntent(intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_SEND -> incomingUrl.value = intent.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> incomingUrl.value = intent.dataString
            "com.jodon.app.OPEN_YOUTUBE" -> startOnYouTube.value = true
        }
    }
}

@Composable
private fun JoDonRootShell(sharedUrl: String?, initialRoute: String) {
    val colors = JoTheme.colors
    val hazeState = rememberHazeState()
    var route by remember { mutableStateOf(initialRoute) }
    var browserUrl by remember { mutableStateOf("") }
    var activeToolFilePath by remember { mutableStateOf("") }
    var activePlayerMedia by remember { mutableStateOf<Pair<String, String>?>(null) }

    val dockItems = listOf(
        DockItem("home", "الرئيسية", JoIcons.Home),
        DockItem("youtube", "يوتيوب", JoIcons.YouTube, accentOverride = colors.youtubeRed),
        DockItem("downloads", "التحميلات", JoIcons.Download),
        DockItem("files", "ملفاتي", JoIcons.Audio),
        DockItem("tools", "الأدوات", JoIcons.Tools),
        DockItem("settings", "الإعدادات", JoIcons.Settings)
    )

    Box(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxSize().hazeSource(state = hazeState)) {
            AuroraMeshBackground()
            val playing = activePlayerMedia
            if (playing != null && route == "player") {
                LocalFlagshipPlayerScreen(mediaUriOrPath = playing.first, title = playing.second, hazeState = hazeState)
            } else when (route) {
                "home" -> HomeScreen(
                    sharedIncomingUrl = sharedUrl,
                    onOpenBrowser = { url -> browserUrl = url; route = "browser" },
                    onOpenDownloads = { route = "downloads" },
                    hazeState = hazeState
                )
                "youtube" -> YouTubeScreen(hazeState = hazeState)
                "downloads" -> DownloadsScreen(
                    onOpenInPlayer = { path -> activePlayerMedia = path to path.substringAfterLast("/"); route = "player" },
                    onOpenInCompressor = { path -> activeToolFilePath = path; route = "tools" },
                    hazeState = hazeState
                )
                "files" -> FilesAndMusicLibraryScreen(
                    onPlayMedia = { path, title -> activePlayerMedia = path to title; route = "player" },
                    hazeState = hazeState
                )
                "browser" -> BrowserSnifferScreen(initialUrl = browserUrl, hazeState = hazeState)
                "tools" -> LazyColumn(
                    modifier = Modifier.fillMaxSize().statusBarsPadding(),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 110.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        JoText("الأدوات والمتصفح", style = JoTheme.typography.hero)
                        Spacer(Modifier.height(8.dp))
                        GlassButton("افتح المتصفح الصيّاد بمانع الإعلانات", onClick = { route = "browser" }, modifier = Modifier.fillMaxWidth())
                    }
                    item { SmartCompressorCard(selectedFilePath = activeToolFilePath, hazeState = hazeState) }
                    item { ConverterCard(selectedFilePath = activeToolFilePath, hazeState = hazeState) }
                }
                "settings" -> SettingsScreen(hazeState = hazeState)
            }
        }

        FloatingGlassDock(
            items = dockItems,
            selectedRoute = if (route == "browser") "tools" else if (route == "player") "files" else route,
            onSelect = { route = it },
            hazeState = hazeState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun JoDonOnboardingScreen(onFinish: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize()) {
        AuroraMeshBackground()
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            JoText("أهلاً بيك في 𝒥𝒪 DON", style = JoTheme.typography.hero, gradient = true)
            Spacer(Modifier.height(10.dp))
            GlassCard(elevated = true) {
                JoText("• تحميل صاروخي حتى 32 اتصال من أكتر من 1800 موقع", style = JoTheme.typography.body)
                Spacer(Modifier.height(6.dp))
                JoText("• يوتيوب أصلي كامل وشورتس وحساب محلي من غير تسجيل دخول", style = JoTheme.typography.body)
                Spacer(Modifier.height(6.dp))
                JoText("• مشغل موسيقى وفيديو بقص يدوي ونغمة رنين ومؤقت نوم", style = JoTheme.typography.body)
                Spacer(Modifier.height(16.dp))
                GlassButton("يلا نبدأ", onClick = onFinish, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.N)
class QuickPasteTileService : TileService() {
    override fun onClick() {
        super.onClick()
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivityAndCollapse(intent)
    }
}

class QuickPasteWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { widgetId ->
            val pi = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val views = RemoteViews(context.packageName, R.layout.widget_quick_paste).apply {
                setOnClickPendingIntent(R.id.widget_root, pi)
            }
            manager.updateAppWidget(widgetId, views)
        }
    }
}
