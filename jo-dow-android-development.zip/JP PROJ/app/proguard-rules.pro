# Keep Kotlinx Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.jodon.**$$serializer { *; }

# Keep youtubedl-android, FFmpeg, Aria2c & Jackson models
-keep class com.yausername.** { *; }
-keep class com.fasterxml.jackson.** { *; }
-dontwarn com.fasterxml.jackson.**

# Keep NewPipeExtractor & Rhino JS decryption for native YouTube playback/download
-keep class org.schabi.newpipe.** { *; }
-keep class org.mozilla.javascript.** { *; }
-dontwarn org.mozilla.javascript.**

# Keep WebView JS Sniffer interface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep OkHttp / Cronet / Conscrypt
-dontwarn okhttp3.**
-dontwarn org.chromium.net.**
