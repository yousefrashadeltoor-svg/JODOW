# 𝒥𝒪 DON — مشروع الأندرويد الكامل (JP PROJ)

## 1) المعمارية ومخطط الـ Modules (Clean Architecture + MVI)

- **صفر Material Design**: مستبعد قسريًا في `build.gradle.kts` لكل الـ Modules (`exclude androidx.compose.material`, `material3`, `com.google.android.material`) ومبني 100% على `compose.foundation` + `compose.ui` + `Haze` + `AGSL RuntimeShader`.
- **صفر باكيند وصفر تتبع**: لا Firebase ولا Analytics ولا أي قاعدة بيانات سحابية؛ التخزين ذري محلي ومشفر على الجهاز (`LocalAppStore` + `EncryptedSharedPreferences` + `EncryptedFile`) والواجهة تفتح في أقل من ثانية بدون أي اتصال بالإنترنت.
- **يوتيوب أصلي 100% بدون WebView وبدون API رسمي**: مبني في `:engine:extractors` و `:feature:youtube` باستخدام مكتبة **`TeamNewPipe/NewPipeExtractor (v0.25.2)`** المفتوحة المصدر مع `Media3 ExoPlayer`، ويشمل الرئيسية بالاقتراحات اللانهائية حسب اشتراكاتك وتصفحك، البحث والاقتراحات الفورية، شورتس العمودي، زر تحميل ونسخ لينك تحت كل فيديو، وملف شخصي محلي قابل للتصدير والاستيراد بصيغة JSON.

### الوحدات (18 Module)
- `:app` — نقطة الدخول، الـ Floating Glass Dock، استقبال Share/VIEW Intents، الـ Onboarding، الـ Widget، والـ Quick Settings Tile.
- `:core:common` — تطبيع الروابط، تنسيق الأحجام الدقيقة مقابل التقريبية (`≈`)، فحص البصمة `MD5/SHA-1/SHA-256`.
- `:core:designsystem` — نظام **Aurora Glass** الكامل + 6 ثيمات كاملة بصورها الواقعية المدمجة محليًا في `res/drawable-nodpi/theme_*.jpg`.
- `:core:database` — التخزين المحلي الذري للأجزاء (Segments) والملف الشخصي المحلي ليوتيوب والإعدادات.
- `:core:network` — `OkHttp` (HTTP/2 + DoH) + `Cronet` (HTTP/3) + `EncryptedBridgeCookieJar` (نقل `cf_clearance` الشرعي) + `ExactSizeResolver` + `NewPipeOkHttpDownloader`.
- `:engine:downloader` — محرك التحميل المجزأ المتوازي (8–32 اتصال + Work-Stealing + `FileChannel` + ETag Resume + تجديد روابط 403/410 + `DownloadForegroundService`) + اختبارات الوحدة `SegmentPlannerTest`.
- `:engine:extractors` — `NewPipeYouTubeEngine` + `LinkAnalyzerPipeline` (`yt-dlp` + `ffmpeg` + `aria2c` + `Jsoup`).
- `:engine:media` — دمج DASH بدون فقد، تحويل الصيغ، القص اليدوي الدقيق، التصغير الذكي بفحص `SSIM`، وضبط نغمة الرنين عبر `RingtoneManager`.
- `:feature:analyzer`, `:feature:home`, `:feature:youtube`, `:feature:downloads`, `:feature:browser`, `:feature:converter`, `:feature:compressor`, `:feature:player`, `:feature:files`, `:feature:settings`.

---

## 2) خطوات بناء الـ APK والتشغيل

1. افتح مجلد `JP PROJ` مباشرة في **Android Studio Ladybug (2024.2.1+)** مع **JDK 17** و **Android SDK 35**.
2. نفّذ الفحص الصارم لعدم وجود أي مكتبة Material:
   ```bash
   ./gradlew :app:dependencies | grep -i "material"
   ```
3. شغّل اختبارات الوحدة لمحرك التجزئة والـ Work-Stealing وحساب الحجم الدقيق:
   ```bash
   ./gradlew :engine:downloader:testDebugUnitTest
   ```
4. ابنِ ملف الـ APK الجاهز للتثبيت مباشرة:
   ```bash
   ./gradlew :app:assembleDebug
   ```
   سيظهر الملف في: `app/build/outputs/apk/debug/app-debug.apk`.

---

## 3) ملاحظات التحقق الصادقة (VERIFY)

- `MediaProcessingEngine.runFfmpeg`: يستدعي `libffmpeg.so` المدمج من `io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1` (مع تفعيل `useLegacyPackaging = true` و `extractNativeLibs = true`).
- `AdBlockFilterEngine`: يعمل مباشرة بقوائم الحجب وCosmetic CSS وحجب النوافذ المنبثقة بدون إعدادات إضافية، ويمكن ربط `brave/adblock-rust` عبر JNI NDK عند تثبيت Rust toolchain محليًا.
- الخطوط المفتوحة (`IBM Plex Sans Arabic` + `Outfit`): يمكن وضع ملفات `.ttf` في `app/src/main/res/font/` لتضمينها داخل الـ APK بجانب الخط العربي النظيف الافتراضي.
