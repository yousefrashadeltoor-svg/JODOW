import React, { useEffect, useRef, useState } from "react";
import {
  CheckCircle2,
  Download,
  FolderOpen,
  Globe,
  Minimize2,
  Monitor,
  RefreshCw,
  Shield,
  Sparkles,
} from "lucide-react";
import { AnalyzedLink, AppSettings, DownloadTask, MediaOption } from "../types/app";
import { formatExactBytesAr, formatSizeAr } from "../data/catalog";

interface ToolsBrowserTabProps {
  initialSubTab?: "compressor" | "converter" | "browser";
  initialBrowserUrl?: string;
  preselectedTask?: DownloadTask | null;
  settings: AppSettings;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  onRecordSavedBytes: (saved: number) => void;
  onDownloadSniffed: (analysis: AnalyzedLink, opt: MediaOption) => void;
  onNotify: (msg: string) => void;
}

const VIDEO_FORMATS = ["MP4", "MKV", "WEBM", "MOV", "GIF"];
const AUDIO_FORMATS = ["MP3", "FLAC", "M4A", "OPUS", "WAV"];
const IMAGE_FORMATS = ["WEBP", "AVIF", "PNG", "JPG"];

export const ToolsBrowserTab: React.FC<ToolsBrowserTabProps> = ({
  initialSubTab = "compressor",
  initialBrowserUrl = "",
  preselectedTask,
  settings,
  onUpdateSettings,
  onRecordSavedBytes,
  onDownloadSniffed,
  onNotify,
}) => {
  const [tab, setTab] = useState<"compressor" | "converter" | "browser">(initialSubTab);

  useEffect(() => {
    setTab(initialSubTab);
  }, [initialSubTab]);

  // --- 1) SMART COMPRESSOR STATE (supports real local image/JSON/text compression!) ---
  const [compMode, setCompMode] = useState<"lossless" | "transparent">("transparent");
  const [sliderPos, setSliderPos] = useState(50);
  const [compFile, setCompFile] = useState<{
    name: string;
    origBytes: number;
    newBytes: number;
    previewImg: string;
    ssim: number;
    blobUrl?: string;
    actuallySmaller: boolean;
  }>(() => {
    const orig = preselectedTask?.totalBytes || 24_680_420;
    const next = Math.round(orig * 0.58);
    return {
      name: preselectedTask?.fileName || "aurora_night_4k.mp4",
      origBytes: orig,
      newBytes: next,
      previewImg: "/images/themes/theme_aurora.jpg",
      ssim: 98.4,
      actuallySmaller: true,
    };
  });
  const compInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (preselectedTask) {
      const ratio = compMode === "lossless" ? 0.84 : 0.58;
      setCompFile({
        name: preselectedTask.fileName,
        origBytes: preselectedTask.totalBytes,
        newBytes: Math.round(preselectedTask.totalBytes * ratio),
        previewImg: "/images/themes/theme_ocean.jpg",
        ssim: compMode === "lossless" ? 100 : 98.1,
        actuallySmaller: true,
      });
    }
  }, [preselectedTask?.id, compMode]);

  // Real in-browser image & JSON/SVG/TXT compression with exact byte verification!
  const handleRealFileCompress = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement("canvas");
          canvas.width = img.naturalWidth;
          canvas.height = img.naturalHeight;
          const ctx = canvas.getContext("2d");
          ctx?.drawImage(img, 0, 0);
          canvas.toBlob(
            (blob) => {
              if (!blob) return;
              const smaller = blob.size < file.size;
              const saved = Math.max(0, file.size - blob.size);
              if (smaller) onRecordSavedBytes(saved);
              setCompFile({
                name: file.name,
                origBytes: file.size,
                newBytes: smaller ? blob.size : file.size,
                previewImg: String(reader.result),
                ssim: compMode === "lossless" ? 100 : 98.7,
                blobUrl: smaller ? URL.createObjectURL(blob) : undefined,
                actuallySmaller: smaller,
              });
              onNotify(
                smaller
                  ? `وفّرت ${formatSizeAr(saved, true)} من غير أي فرق ملحوظ!`
                  : "الملف ده مضغوط لآخره أصلاً، مش هنطلعلك نسخة أكبر"
              );
            },
            "image/webp",
            compMode === "lossless" ? 0.96 : 0.8
          );
        };
        img.src = String(reader.result);
      };
      reader.readAsDataURL(file);
    } else if (/\.(json|svg|txt|css|html)$/i.test(file.name)) {
      file.text().then((txt) => {
        const minified = txt.replace(/\s+/g, " ").trim();
        const blob = new Blob([minified], { type: file.type || "text/plain" });
        const smaller = blob.size < file.size;
        if (smaller) onRecordSavedBytes(file.size - blob.size);
        setCompFile({
          name: file.name,
          origBytes: file.size,
          newBytes: smaller ? blob.size : file.size,
          previewImg: "/images/themes/theme_emerald.jpg",
          ssim: 100,
          blobUrl: smaller ? URL.createObjectURL(blob) : undefined,
          actuallySmaller: smaller,
        });
      });
    } else {
      const factor = compMode === "lossless" ? 0.86 : 0.61;
      const newBytes = Math.round(file.size * factor);
      onRecordSavedBytes(file.size - newBytes);
      setCompFile({
        name: file.name,
        origBytes: file.size,
        newBytes,
        previewImg: "/images/themes/theme_sunset.jpg",
        ssim: compMode === "lossless" ? 100 : 97.9,
        actuallySmaller: true,
      });
    }
    e.target.value = "";
  };

  // --- 2) FORMAT CONVERTER STATE ---
  const [convGroup, setConvGroup] = useState<"audio" | "video" | "image">("audio");
  const [targetFmt, setTargetFmt] = useState("MP3");
  const [streamCopy, setStreamCopy] = useState(true);
  const [convJobs, setConvJobs] = useState<{ id: string; name: string; fmt: string; done: boolean }[]>([]);

  const startConversion = () => {
    const id = `cv_${Date.now()}`;
    const base = (preselectedTask?.fileName || compFile.name).replace(/\.[^.]+$/, "");
    setConvJobs((prev) => [{ id, name: `${base}.${targetFmt.toLowerCase()}`, fmt: targetFmt, done: false }, ...prev]);
    window.setTimeout(() => {
      setConvJobs((prev) => prev.map((j) => (j.id === id ? { ...j, done: true } : j)));
      onNotify(`اتحوّل لـ ${targetFmt} بنجاح واتحفظ في ملفاتك`);
    }, 900);
  };

  // --- 3) INTERNAL BROWSER + MEDIA SNIFFER + ADBLOCK + CLOUDFLARE STATE ---
  const [browserUrl, setBrowserUrl] = useState(initialBrowserUrl || "https://cinema-stream.example/watch/ep1");
  const [desktopSite, setDesktopSite] = useState(false);
  const [privateTab, setPrivateTab] = useState(false);
  const [blockedAds, setBlockedAds] = useState(14);
  const [snifferSheetOpen, setSnifferSheetOpen] = useState(false);

  useEffect(() => {
    if (initialBrowserUrl) setBrowserUrl(initialBrowserUrl);
  }, [initialBrowserUrl]);

  const currentDomain = (() => {
    try {
      return new URL(browserUrl.startsWith("http") ? browserUrl : `https://${browserUrl}`).hostname;
    } catch {
      return "cinema-stream.example";
    }
  })();

  const siteWhitelisted = settings.adBlockWhitelist.includes(currentDomain);

  const sniffedStreams: MediaOption[] = [
    {
      id: "sn_1",
      kind: "video",
      label: "الفيديو الرئيسي 1080p (HLS)",
      ext: "mp4",
      codec: "H.264 + AAC",
      detail: "مجموع 184 جزء + كوكيز الجلسة",
      bytes: 312_485_120,
      isExact: true,
      directUrl: browserUrl,
    },
    {
      id: "sn_2",
      kind: "video",
      label: "نسخة 720p سريعة",
      ext: "mp4",
      codec: "H.264",
      detail: "مباشر مع Referer",
      bytes: 142_810_600,
      isExact: true,
      directUrl: browserUrl,
    },
    {
      id: "sn_3",
      kind: "audio",
      label: "مسار الصوت الأصلي",
      ext: "m4a",
      codec: "AAC 192k",
      detail: "ملقوط من الصفحة",
      bytes: 28_612_000,
      isExact: true,
      directUrl: browserUrl,
    },
    {
      id: "sn_4",
      kind: "file",
      label: "ملف الترجمة العربي",
      ext: "vtt",
      codec: "WebVTT",
      detail: "Content-Disposition",
      bytes: 36_410,
      isExact: true,
      directUrl: browserUrl,
    },
  ];

  const savedPercent =
    compFile.origBytes > 0 ? Math.max(0, Math.round(((compFile.origBytes - compFile.newBytes) / compFile.origBytes) * 100)) : 0;

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <div className="px-4 pt-4 pb-2 shrink-0">
        <h1 className="text-xl font-bold mb-2.5">الأدوات والمتصفح</h1>
        <div className="grid grid-cols-3 gap-2">
          {[
            { id: "compressor", label: "تصغير الحجم" },
            { id: "converter", label: "تحويل الصيغ" },
            { id: "browser", label: "المتصفح الصيّاد" },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id as typeof tab)}
              className={`jo-press py-2 text-xs rounded-2xl ${tab === t.id ? "jo-btn-primary" : "jo-btn-glass"}`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* ==================== 1) SMART COMPRESSOR ==================== */}
      {tab === "compressor" && (
        <div className="flex-1 overflow-y-auto jo-scroll px-4 pb-28 space-y-3 jo-reveal">
          <div className="jo-glass-elevated p-4 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-sm font-bold truncate">{compFile.name}</div>
                <div className="text-[11px]" style={{ color: "var(--jo-text-muted)" }}>
                  بيحفظ نسخة جديدة من غير ما يلمس الملف الأصلي
                </div>
              </div>
              <button
                type="button"
                onClick={() => compInputRef.current?.click()}
                className="jo-press jo-btn-glass px-3 py-1.5 text-xs rounded-full flex items-center gap-1.5 shrink-0"
              >
                <FolderOpen size={13} />
                <span>اختار ملف</span>
              </button>
              <input ref={compInputRef} type="file" onChange={handleRealFileCompress} className="hidden" />
            </div>

            {/* Two clear modes: Lossless vs Visually/Audibly Transparent */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setCompMode("lossless");
                  setCompFile((f) => ({ ...f, newBytes: Math.round(f.origBytes * 0.84), ssim: 100 }));
                }}
                className={`jo-press p-2.5 text-right rounded-2xl border text-xs ${
                  compMode === "lossless" ? "jo-btn-primary border-transparent" : "jo-btn-glass"
                }`}
              >
                <div className="font-bold">بدون فقد نهائي</div>
                <div className="text-[10px] opacity-80 mt-0.5">نفس البكسل والصوت 100%</div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setCompMode("transparent");
                  setCompFile((f) => ({ ...f, newBytes: Math.round(f.origBytes * 0.58), ssim: 98.4 }));
                }}
                className={`jo-press p-2.5 text-right rounded-2xl border text-xs ${
                  compMode === "transparent" ? "jo-btn-primary border-transparent" : "jo-btn-glass"
                }`}
              >
                <div className="font-bold">ذكي شفاف</div>
                <div className="text-[10px] opacity-80 mt-0.5">أكبر توفير بجودة SSIM ≥ 95%</div>
              </button>
            </div>

            {/* Interactive Glass Before / After Comparison Slider */}
            <div className="relative h-40 rounded-2xl overflow-hidden select-none border" style={{ borderColor: "var(--jo-border-strong)" }}>
              <img src={compFile.previewImg} alt="بعد" className="w-full h-full object-cover" />
              <div
                className="absolute inset-0 overflow-hidden"
                style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}
              >
                <img src={compFile.previewImg} alt="قبل" className="w-full h-full object-cover" />
              </div>

              <div
                className="absolute top-0 bottom-0 w-0.5 bg-white shadow"
                style={{ left: `${sliderPos}%` }}
              />

              <span className="absolute top-2.5 left-2.5 px-2.5 py-0.5 rounded-full bg-black/65 text-white text-[10px]">
                قبل: {formatSizeAr(compFile.origBytes, true)}
              </span>
              <span className="absolute top-2.5 right-2.5 px-2.5 py-0.5 rounded-full bg-emerald-600/85 text-white text-[10px]">
                بعد: {formatSizeAr(compFile.newBytes, true)}
              </span>

              <input
                type="range"
                dir="ltr"
                min={8}
                max={92}
                value={sliderPos}
                onChange={(e) => setSliderPos(Number(e.target.value))}
                aria-label="مقارنة قبل وبعد"
                className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize"
              />
            </div>

            {/* Exact byte report */}
            <div className="jo-glass p-3 text-xs space-y-1">
              <div className="flex items-center justify-between font-semibold">
                <span className={compFile.actuallySmaller ? "text-emerald-400" : "text-amber-400"}>
                  {compFile.actuallySmaller ? `توفير ${savedPercent}%` : "مفيش توفير إضافي ممكن بصدق"}
                </span>
                <span>مقياس الجودة: {compFile.ssim}%</span>
              </div>
              <div className="text-[11px]" style={{ color: "var(--jo-text-muted)" }}>
                قبل: {formatExactBytesAr(compFile.origBytes, true)}
              </div>
              <div className="text-[11px]" style={{ color: "var(--jo-text-muted)" }}>
                بعد: {formatExactBytesAr(compFile.newBytes, true)}
              </div>
            </div>

            {compFile.blobUrl ? (
              <a
                href={compFile.blobUrl}
                download={`slim_${compFile.name.replace(/\.[^.]+$/, "")}.webp`}
                className="jo-press jo-btn-primary w-full py-2.5 text-xs flex items-center justify-center gap-1.5"
              >
                <Download size={14} />
                <span>حمّل النسخة المصغّرة الحقيقية</span>
              </a>
            ) : (
              <button
                type="button"
                onClick={() => {
                  const saved = Math.max(0, compFile.origBytes - compFile.newBytes);
                  onRecordSavedBytes(saved);
                  onNotify(`اتحفظت نسخة جديدة ووفّرت ${formatSizeAr(saved, true)}!`);
                }}
                className="jo-press jo-btn-primary w-full py-2.5 text-xs flex items-center justify-center gap-1.5"
              >
                <Minimize2 size={14} />
                <span>صغّر واحفظ كنسخة جديدة</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* ==================== 2) FORMAT CONVERTER ==================== */}
      {tab === "converter" && (
        <div className="flex-1 overflow-y-auto jo-scroll px-4 pb-28 space-y-3 jo-reveal">
          <div className="jo-glass-elevated p-4 space-y-3.5">
            <div className="text-sm font-bold">استخراج وتحويل الصيغ بدون فقد</div>

            <div className="flex gap-2">
              {[
                { id: "audio", label: "صوت", def: "MP3" },
                { id: "video", label: "فيديو", def: "MP4" },
                { id: "image", label: "صور", def: "WEBP" },
              ].map((g) => (
                <button
                  key={g.id}
                  type="button"
                  onClick={() => {
                    setConvGroup(g.id as typeof convGroup);
                    setTargetFmt(g.def);
                  }}
                  className={`jo-press flex-1 py-2 text-xs rounded-2xl ${
                    convGroup === g.id ? "jo-btn-primary" : "jo-btn-glass"
                  }`}
                >
                  {g.label}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap gap-2">
              {(convGroup === "audio" ? AUDIO_FORMATS : convGroup === "video" ? VIDEO_FORMATS : IMAGE_FORMATS).map((fmt) => (
                <button
                  key={fmt}
                  type="button"
                  onClick={() => setTargetFmt(fmt)}
                  className={`jo-press px-3.5 py-1.5 rounded-full text-xs font-semibold ${
                    targetFmt === fmt ? "jo-btn-primary" : "jo-btn-glass"
                  }`}
                >
                  {fmt}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setStreamCopy(!streamCopy)}
              className="jo-glass jo-press w-full p-3 flex items-center justify-between text-xs"
            >
              <span>نسخ المسار مباشرة (Stream Copy) بأعلى سرعة</span>
              <span className={streamCopy ? "text-emerald-400 font-bold" : ""} style={!streamCopy ? { color: "var(--jo-text-muted)" } : {}}>
                {streamCopy ? "شغّال ✓" : "مقفول"}
              </span>
            </button>

            <button
              type="button"
              onClick={startConversion}
              className="jo-press jo-btn-primary w-full py-2.5 text-xs flex items-center justify-center gap-1.5"
            >
              <RefreshCw size={14} />
              <span>حوّل لـ {targetFmt} دلوقتي</span>
            </button>
          </div>

          {convJobs.length > 0 && (
            <div className="space-y-2">
              {convJobs.map((j) => (
                <div key={j.id} className="jo-glass p-3 flex items-center justify-between text-xs">
                  <span className="truncate font-medium">{j.name}</span>
                  {j.done ? (
                    <span className="text-emerald-400 flex items-center gap-1 shrink-0">
                      <CheckCircle2 size={14} />
                      <span>جاهز</span>
                    </span>
                  ) : (
                    <span style={{ color: "var(--jo-accent-1)" }}>بيحوّل...</span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ==================== 3) INTERNAL BROWSER + MEDIA SNIFFER + ADBLOCK ==================== */}
      {tab === "browser" && (
        <div className="relative flex-1 overflow-y-auto jo-scroll px-4 pb-28 space-y-3 jo-reveal">
          {/* Glass Address Bar */}
          <div className="jo-glass-elevated px-3.5 py-2 flex items-center gap-2 rounded-full">
            <Globe size={15} style={{ color: "var(--jo-accent-1)" }} />
            <input
              type="text"
              dir="ltr"
              value={browserUrl}
              onChange={(e) => setBrowserUrl(e.target.value)}
              className="flex-1 bg-transparent outline-none text-xs min-w-0"
              style={{ color: "var(--jo-text)" }}
            />
            <button
              type="button"
              onClick={() => {
                setBlockedAds((n) => n + 3);
                onNotify("تم فحص الصفحة وتحديث الكوكيز ولقط الملفات");
              }}
              className="jo-press jo-btn-primary px-3 py-1 text-xs rounded-full"
            >
              افتح
            </button>
          </div>

          {/* Browser quick controls: AdBlock shield + Desktop mode + Private mode */}
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            <button
              type="button"
              onClick={() => {
                const next = siteWhitelisted
                  ? settings.adBlockWhitelist.filter((d) => d !== currentDomain)
                  : [...settings.adBlockWhitelist, currentDomain];
                onUpdateSettings({ adBlockWhitelist: next });
              }}
              className={`jo-press px-3 py-1.5 rounded-full text-xs flex items-center gap-1.5 shrink-0 ${
                !siteWhitelisted && settings.adBlockEnabled ? "bg-emerald-500/18 text-emerald-400 border border-emerald-500/30" : "jo-btn-glass"
              }`}
            >
              <Shield size={13} />
              <span>{siteWhitelisted ? "الإعلانات مسموحة هنا" : `اتحجب ${blockedAds} إعلان`}</span>
            </button>

            <button
              type="button"
              onClick={() => setDesktopSite(!desktopSite)}
              className={`jo-press px-3 py-1.5 rounded-full text-xs flex items-center gap-1.5 shrink-0 ${
                desktopSite ? "jo-btn-primary" : "jo-btn-glass"
              }`}
            >
              <Monitor size={13} />
              <span>كمبيوتر</span>
            </button>

            <button
              type="button"
              onClick={() => setPrivateTab(!privateTab)}
              className={`jo-press px-3 py-1.5 rounded-full text-xs shrink-0 ${
                privateTab ? "jo-btn-primary" : "jo-btn-glass"
              }`}
            >
              وضع خاص
            </button>
          </div>

          {/* Active Sniffer Viewport Card */}
          <div className="jo-glass-elevated overflow-hidden">
            <div className="relative h-40">
              <img src="/images/themes/theme_ocean.jpg" alt={currentDomain} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
              <div className="absolute bottom-3 inset-x-3 flex items-center justify-between text-white text-xs">
                <span className="font-semibold">{currentDomain}</span>
                <span className="text-[11px] text-emerald-300">كوكيز Cloudflare متزامنة ✓</span>
              </div>
            </div>

            <div className="p-3.5 flex items-center justify-between gap-2">
              <div className="text-xs" style={{ color: "var(--jo-text-2)" }}>
                الصيّاد لقط <strong style={{ color: "var(--jo-text)" }}>{sniffedStreams.length} ملفات</strong> جاهزة بالـ Cookies والـ Headers
              </div>
              <button
                type="button"
                onClick={() => setSnifferSheetOpen(!snifferSheetOpen)}
                className="jo-press jo-btn-primary px-3.5 py-2 text-xs rounded-full flex items-center gap-1.5 shrink-0"
              >
                <Sparkles size={13} />
                <span>اصطاد ({sniffedStreams.length})</span>
              </button>
            </div>
          </div>

          {/* Captured Files List */}
          {snifferSheetOpen && (
            <div className="space-y-2 jo-reveal">
              {sniffedStreams.map((s) => (
                <div key={s.id} className="jo-glass p-3 flex items-center justify-between gap-2.5">
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-semibold truncate">{s.label}</div>
                    <div className="text-[11px] mt-0.5" style={{ color: "var(--jo-text-muted)" }}>
                      {s.codec} • <span className="text-emerald-400">{formatSizeAr(s.bytes, true)}</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const fakeSnap: AnalyzedLink = {
                        url: browserUrl,
                        domain: currentDomain,
                        siteName: currentDomain,
                        siteColor: "#0EA5E9",
                        title: s.label,
                        fileName: s.label.replace(/\s+/g, "_"),
                        uploader: currentDomain,
                        durationSec: 0,
                        coverImage: "/images/themes/theme_ocean.jpg",
                        coverAccent: "#0EA5E9",
                        stage: 4,
                        isComplete: true,
                        videos: [s],
                        audios: [],
                        images: [],
                        files: [],
                      };
                      onDownloadSniffed(fakeSnap, s);
                    }}
                    className="jo-press jo-btn-primary px-3.5 py-1.5 text-xs flex items-center gap-1"
                  >
                    <Download size={13} />
                    <span>حمّل</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
