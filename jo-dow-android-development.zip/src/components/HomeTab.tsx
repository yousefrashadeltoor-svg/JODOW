import React, { useEffect, useRef, useState } from "react";
import {
  CheckCircle2,
  Clipboard,
  Compass,
  Edit3,
  Layers,
  Pause,
  Play,
  ShieldAlert,
  Sparkles,
  X,
} from "lucide-react";
import { AnalyzedLink, DownloadTask, MediaKind } from "../types/app";
import { buildAnalysisForUrl, formatDuration, formatSizeAr } from "../data/catalog";
import { audioEngine } from "../utils/audioEngine";
import { FourSmartButtons } from "./SharedUI";

interface HomeTabProps {
  downloads: DownloadTask[];
  clipboardWatch: boolean;
  onOpenQualitySheet: (analysis: AnalyzedLink, kind: MediaKind, customName: string) => void;
  onOpenDownloads: () => void;
  onOpenSniffer: (url: string) => void;
  onQuickBatchQueue: (urls: string[]) => void;
  onCoverTint: (hex: string | null) => void;
  onNotify: (msg: string) => void;
}

const QUICK_TEST_LINKS = [
  { label: "يوتيوب 4K", url: "https://youtu.be/aurora_4k_hdr_eg" },
  { label: "تيك توك", url: "https://tiktok.com/@eg_creator/video/7419021" },
  { label: "ساوند كلاود", url: "https://soundcloud.com/mawgat/nesmet-elfagr" },
  { label: "ملف ZIP", url: "https://cdn.example.org/releases/jodon_pack_v2.zip" },
];

export const HomeTab: React.FC<HomeTabProps> = ({
  downloads,
  clipboardWatch,
  onOpenQualitySheet,
  onOpenDownloads,
  onOpenSniffer,
  onQuickBatchQueue,
  onCoverTint,
  onNotify,
}) => {
  const [urlInput, setUrlInput] = useState("");
  const [focused, setFocused] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [stageLabel, setStageLabel] = useState("");
  const [analysis, setAnalysis] = useState<AnalyzedLink | null>(null);
  const [customName, setCustomName] = useState("");
  const [editingName, setEditingName] = useState(false);
  const [previewPlaying, setPreviewPlaying] = useState(false);
  const [detectedClipboard, setDetectedClipboard] = useState<string | null>(null);
  const [batchOpen, setBatchOpen] = useState(false);
  const [batchText, setBatchText] = useState("");
  const timerRef = useRef<number[]>([]);

  const clearTimers = () => {
    timerRef.current.forEach((t) => clearTimeout(t));
    timerRef.current = [];
  };

  useEffect(() => {
    return () => {
      clearTimers();
      if (previewPlaying) audioEngine.stopSynth();
    };
  }, [previewPlaying]);

  // Progressive 150ms debounced pipeline matching Android LinkAnalyzerPipeline
  const triggerAnalyze = (raw: string) => {
    setUrlInput(raw);
    clearTimers();
    if (previewPlaying) {
      audioEngine.stopSynth();
      setPreviewPlaying(false);
    }

    const trimmed = raw.trim();
    if (!trimmed || trimmed.length < 5 || (!trimmed.includes(".") && !trimmed.startsWith("magnet:"))) {
      setIsAnalyzing(false);
      setAnalysis(null);
      onCoverTint(null);
      return;
    }

    setIsAnalyzing(true);
    setStageLabel("بنفحص اللينك...");

    const t1 = window.setTimeout(() => {
      const target = buildAnalysisForUrl(trimmed);
      // Stage 1 fast card (<220ms)
      setAnalysis({ ...target, stage: 1, isComplete: false, videos: [], audios: [], images: [], files: [] });
      setCustomName(target.fileName);
      onCoverTint(target.coverAccent);
      setStageLabel("بنحسب الجودات والحجم الحقيقي...");

      // Stage 2/3 full formats (<520ms)
      const t2 = window.setTimeout(() => {
        setAnalysis(target);
        setIsAnalyzing(false);
        setStageLabel("");
      }, 300);
      timerRef.current.push(t2);
    }, 160);
    timerRef.current.push(t1);
  };

  const handlePasteButton = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text && text.trim()) {
        const lines = text
          .split(/\s+/)
          .filter((x) => x.startsWith("http://") || x.startsWith("https://"));
        if (lines.length > 1) {
          onQuickBatchQueue(lines);
          return;
        }
        triggerAnalyze(text.trim());
        setDetectedClipboard(null);
        return;
      }
    } catch {
      // Clipboard API restricted fallback
    }
    triggerAnalyze(QUICK_TEST_LINKS[0].url);
    onNotify("حطينالك لينك جاهز للتجربة السريعة");
  };

  const checkClipboardSilently = async () => {
    if (!clipboardWatch || urlInput) return;
    try {
      const text = await navigator.clipboard.readText();
      if (text && /^https?:\/\//i.test(text.trim())) {
        setDetectedClipboard(text.trim());
      }
    } catch {
      // Silent — zero annoyance
    }
  };

  const toggleInlinePreview = () => {
    if (previewPlaying) {
      audioEngine.stopSynth();
      setPreviewPlaying(false);
    } else {
      audioEngine.startSynth(2, 1);
      setPreviewPlaying(true);
    }
  };

  const activeOrRecent = downloads.slice(0, 4);

  return (
    <div
      className="h-full overflow-y-auto jo-scroll px-4 pt-4 pb-28 space-y-4"
      onFocus={checkClipboardSilently}
    >
      {/* Clean Minimal Header */}
      <div className="flex items-center justify-between pt-1">
        <div>
          <h1 className="text-2xl font-bold tracking-tight jo-gradient-text">𝒥𝒪 DON</h1>
          <p className="text-xs mt-0.5" style={{ color: "var(--jo-text-2)" }}>
            حط أي لينك وحمّل بأقصى سرعة
          </p>
        </div>
        <button
          type="button"
          onClick={() => setBatchOpen(!batchOpen)}
          className="jo-press jo-btn-glass px-3 py-2 text-xs flex items-center gap-1.5"
        >
          <Layers size={14} />
          <span>كذا لينك</span>
        </button>
      </div>

      {/* Gemini Rotating Glow URL Input */}
      <div className={`jo-gemini-wrap ${isAnalyzing || focused ? "active" : ""}`}>
        <div className="jo-gemini-inner flex items-center gap-2 px-3.5 py-2.5">
          <input
            type="url"
            value={urlInput}
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            onChange={(e) => triggerAnalyze(e.target.value)}
            placeholder="حط اللينك هنا..."
            className="flex-1 bg-transparent border-none outline-none text-sm min-w-0 py-1.5"
            style={{ color: "var(--jo-text)" }}
          />
          {urlInput ? (
            <button
              type="button"
              onClick={() => triggerAnalyze("")}
              className="jo-press jo-btn-glass w-9 h-9 rounded-full flex items-center justify-center shrink-0"
              aria-label="امسح"
            >
              <X size={15} />
            </button>
          ) : (
            <button
              type="button"
              onClick={handlePasteButton}
              className="jo-press jo-btn-primary px-4 py-2 text-xs flex items-center gap-1.5 shrink-0"
            >
              <Clipboard size={14} />
              <span>الزق</span>
            </button>
          )}
        </div>
      </div>

      {/* Batch Multi-Link Sheet inline */}
      {batchOpen && (
        <div className="jo-glass-elevated jo-reveal p-3.5 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold">حط كل لينك في سطر وهنحمّلهم ورا بعض</span>
            <button type="button" onClick={() => setBatchOpen(false)} className="text-xs" style={{ color: "var(--jo-text-muted)" }}>
              قفل
            </button>
          </div>
          <textarea
            rows={3}
            value={batchText}
            onChange={(e) => setBatchText(e.target.value)}
            placeholder={"https://youtu.be/aurora_4k_hdr_eg\nhttps://soundcloud.com/mawgat/nesmet-elfagr"}
            dir="ltr"
            className="w-full rounded-2xl p-2.5 text-xs outline-none border"
            style={{ background: "var(--jo-surface)", borderColor: "var(--jo-border)", color: "var(--jo-text)" }}
          />
          <button
            type="button"
            onClick={() => {
              const list = batchText
                .split(/\s+/)
                .map((s) => s.trim())
                .filter((s) => s.length > 6);
              if (list.length) {
                onQuickBatchQueue(list);
                setBatchText("");
                setBatchOpen(false);
              }
            }}
            className="jo-press jo-btn-primary w-full py-2.5 text-xs"
          >
            ضيف الكل لطابور التحميل
          </button>
        </div>
      )}

      {/* Smart Non-Intrusive Clipboard Chip */}
      {detectedClipboard && !urlInput && (
        <button
          type="button"
          onClick={() => {
            triggerAnalyze(detectedClipboard);
            setDetectedClipboard(null);
          }}
          className="jo-glass jo-press jo-reveal w-full px-3.5 py-2.5 flex items-center justify-between gap-2 text-right"
        >
          <div className="min-w-0">
            <div className="text-xs font-semibold" style={{ color: "var(--jo-accent-1)" }}>
              لينك منسوخ جاهز
            </div>
            <div className="text-[11px] truncate" dir="ltr" style={{ color: "var(--jo-text-muted)" }}>
              {detectedClipboard}
            </div>
          </div>
          <span className="text-xs font-semibold shrink-0" style={{ color: "var(--jo-accent-1)" }}>
            افحصه
          </span>
        </button>
      )}

      {/* Clean Quick Link Pills when input is empty */}
      {!analysis && !isAnalyzing && (
        <div className="space-y-2">
          <div className="text-xs" style={{ color: "var(--jo-text-muted)" }}>
            جرّب بضغطة واحدة:
          </div>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {QUICK_TEST_LINKS.map((item) => (
              <button
                key={item.label}
                type="button"
                onClick={() => triggerAnalyze(item.url)}
                className="jo-press jo-btn-glass px-3.5 py-1.5 text-xs rounded-full shrink-0"
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Progressive Info Card */}
      {analysis && (
        <div className="space-y-3 jo-reveal">
          <div className="jo-glass-elevated p-3.5 space-y-3">
            {/* Site identity row */}
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 min-w-0">
                <span
                  className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white shrink-0"
                  style={{ background: analysis.siteColor }}
                >
                  {analysis.siteName[0]}
                </span>
                <span className="font-semibold">{analysis.siteName}</span>
                <span className="truncate" style={{ color: "var(--jo-text-muted)" }}>
                  • {analysis.domain}
                </span>
              </div>
              {stageLabel && (
                <span className="text-[11px]" style={{ color: "var(--jo-accent-1)" }}>
                  {stageLabel}
                </span>
              )}
            </div>

            {/* Thumbnail + Inline Media Preview */}
            {!analysis.drmBlocked && (
              <div className="relative h-40 rounded-2xl overflow-hidden">
                <img src={analysis.coverImage} alt={analysis.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/15 to-transparent" />
                {(analysis.videos.length > 0 || analysis.audios.length > 0) && (
                  <button
                    type="button"
                    onClick={toggleInlinePreview}
                    className="jo-press absolute inset-0 m-auto w-12 h-12 rounded-full bg-black/55 backdrop-blur-md border border-white/30 flex items-center justify-center text-white"
                    aria-label="معاينة"
                  >
                    {previewPlaying ? <Pause size={20} /> : <Play size={20} className="mr-[-2px]" />}
                  </button>
                )}
                {previewPlaying && (
                  <span className="absolute top-2.5 right-2.5 text-[11px] px-2.5 py-1 rounded-full bg-black/65 text-emerald-300 backdrop-blur-md">
                    معاينة شغّالة
                  </span>
                )}
                {analysis.durationSec > 0 && (
                  <span className="absolute bottom-2.5 left-2.5 text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-black/75 text-white">
                    {formatDuration(analysis.durationSec)}
                  </span>
                )}
              </div>
            )}

            {/* Title & Editable Filename */}
            <div>
              <h2 className="font-bold text-sm leading-relaxed">{analysis.title}</h2>
              <div className="flex items-center justify-between mt-1 text-xs" style={{ color: "var(--jo-text-2)" }}>
                <span>{analysis.uploader}</span>
                {!analysis.drmBlocked && !analysis.needsSniffer && (
                  <button
                    type="button"
                    onClick={() => setEditingName(!editingName)}
                    className="jo-press flex items-center gap-1 text-[11px]"
                    style={{ color: "var(--jo-accent-1)" }}
                  >
                    <Edit3 size={12} />
                    <span>غيّر الاسم</span>
                  </button>
                )}
              </div>

              {editingName && (
                <input
                  type="text"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="mt-2 w-full rounded-xl px-3 py-2 text-xs outline-none border"
                  style={{ background: "var(--jo-surface)", borderColor: "var(--jo-border-strong)", color: "var(--jo-text)" }}
                />
              )}
            </div>

            {/* DRM Notice */}
            {analysis.drmBlocked && (
              <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-rose-500/12 text-rose-300 text-xs">
                <ShieldAlert size={17} className="shrink-0 mt-0.5" />
                <span>المحتوى ده عليه حماية DRM والتطبيق بيحترم حقوق النشر ومش بيتجاوزها.</span>
              </div>
            )}

            {/* Browser Sniffer fallback */}
            {analysis.needsSniffer && (
              <button
                type="button"
                onClick={() => onOpenSniffer(analysis.url)}
                className="jo-press jo-btn-primary w-full py-2.5 text-xs flex items-center justify-center gap-2"
              >
                <Compass size={15} />
                <span>افتح في المتصفح الصيّاد والقط الملفات</span>
              </button>
            )}
          </div>

          {/* Skeleton shimmer while Stage 2/3 resolves */}
          {!analysis.isComplete ? (
            <div className="grid grid-cols-2 gap-2.5">
              <div className="h-16 rounded-3xl jo-shimmer" />
              <div className="h-16 rounded-3xl jo-shimmer" />
            </div>
          ) : (
            <FourSmartButtons
              analysis={analysis}
              onSelectKind={(kind) => onOpenQualitySheet(analysis, kind, customName)}
            />
          )}
        </div>
      )}

      {/* Calm Empty State Orb when nothing pasted and no downloads */}
      {!analysis && activeOrRecent.length === 0 && (
        <div className="py-10 flex flex-col items-center text-center gap-3">
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center"
            style={{
              background: "linear-gradient(135deg, color-mix(in srgb, var(--jo-accent-1) 24%, transparent), color-mix(in srgb, var(--jo-accent-2) 24%, transparent))",
              border: "1px solid var(--jo-border-strong)",
            }}
          >
            <Sparkles size={24} style={{ color: "var(--jo-accent-1)" }} />
          </div>
          <p className="text-sm font-medium" style={{ color: "var(--jo-text-2)" }}>
            بيدعم أكتر من 1800 موقع والروابط المباشرة
          </p>
        </div>
      )}

      {/* Clean Recent Downloads Preview */}
      {activeOrRecent.length > 0 && (
        <div className="space-y-2.5 pt-1">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold">آخر التحميلات</h3>
            <button
              type="button"
              onClick={onOpenDownloads}
              className="text-xs font-medium"
              style={{ color: "var(--jo-accent-1)" }}
            >
              عرض الكل ({downloads.length})
            </button>
          </div>

          <div className="space-y-2">
            {activeOrRecent.map((d) => {
              const pct = d.totalBytes > 0 ? Math.min(100, Math.round((d.downloadedBytes / d.totalBytes) * 100)) : 0;
              return (
                <button
                  key={d.id}
                  type="button"
                  onClick={onOpenDownloads}
                  className="jo-glass jo-press w-full p-3 text-right space-y-2"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold truncate">{d.fileName}</span>
                    {d.status === "completed" ? (
                      <CheckCircle2 size={15} className="text-emerald-400 shrink-0" />
                    ) : (
                      <span className="text-xs font-bold shrink-0" style={{ color: "var(--jo-accent-1)" }}>
                        {pct}%
                      </span>
                    )}
                  </div>
                  <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "var(--jo-surface-elevated)" }}>
                    <div className="h-full rounded-full jo-gradient-bar transition-all duration-300" style={{ width: `${pct}%` }} />
                  </div>
                  <div className="flex items-center justify-between text-[11px]" style={{ color: "var(--jo-text-muted)" }}>
                    <span>{formatSizeAr(d.totalBytes, d.isExact)}</span>
                    <span>
                      {d.status === "completed"
                        ? "خلص"
                        : d.status === "running"
                        ? `شغّال (${d.connections} اتصال)`
                        : d.status === "paused"
                        ? "متوقف"
                        : "في الطابور"}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
