import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight,
  Bookmark,
  ChevronDown,
  ChevronUp,
  Copy,
  Download,
  Edit3,
  Headphones,
  Heart,
  History,
  Pause,
  Play,
  Plus,
  Search,
  ThumbsUp,
  Upload,
  User,
  UserCheck,
  UserPlus,
  X,
} from "lucide-react";
import { AnalyzedLink, LocalProfile, MediaKind, YouTubeItem } from "../types/app";
import {
  BASE_SHORTS,
  BASE_YT_VIDEOS,
  buildAnalysisForUrl,
  formatDuration,
  formatViewsAr,
  generatePersonalizedBatch,
  YT_CATEGORIES,
  YT_CHANNELS,
  YT_SEARCH_SUGGESTIONS,
} from "../data/catalog";
import { audioEngine } from "../utils/audioEngine";
import { ShortsLogoIcon, YouTubeLogoIcon } from "./SharedUI";

interface YouTubeTabProps {
  profile: LocalProfile;
  onUpdateProfile: (updater: (prev: LocalProfile) => LocalProfile) => void;
  onReplaceProfile: (next: LocalProfile) => void;
  onOpenDownload: (analysis: AnalyzedLink, kind: MediaKind) => void;
  onPlayAsSong: (item: YouTubeItem) => void;
  onCopyLink: (url: string) => void;
  onNotify: (msg: string) => void;
}

type YtView = "feed" | "shorts" | "profile" | "watch";

const AVATAR_COLORS = ["#4285F4", "#9B72CB", "#0EA5E9", "#10B981", "#F59E0B", "#EC4899"];

export const YouTubeTab: React.FC<YouTubeTabProps> = ({
  profile,
  onUpdateProfile,
  onReplaceProfile,
  onOpenDownload,
  onPlayAsSong,
  onCopyLink,
  onNotify,
}) => {
  const [view, setView] = useState<YtView>("feed");
  const [category, setCategory] = useState("الكل");
  const [searchText, setSearchText] = useState("");
  const [appliedQuery, setAppliedQuery] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [extraBatches, setExtraBatches] = useState<YouTubeItem[]>([]);
  const [batchCounter, setBatchCounter] = useState(1);

  // Watch state
  const [watching, setWatching] = useState<YouTubeItem | null>(null);
  const [watchPlaying, setWatchPlaying] = useState(true);
  const [watchPos, setWatchPos] = useState(0);
  const [watchSpeed, setWatchSpeed] = useState(1);
  const [watchQuality, setWatchQuality] = useState("1080p60");
  const [watchAudioMode, setWatchAudioMode] = useState(false);

  // Shorts state + swipe handling
  const [shortIdx, setShortIdx] = useState(0);
  const swipeStartY = useRef<number | null>(null);

  // Sync live sound on Watch page
  useEffect(() => {
    if (view === "watch" && watching && watchPlaying) {
      audioEngine.startSynth(watching.toneSeed, watchSpeed);
      return () => audioEngine.stopSynth();
    }
    if (view !== "watch") audioEngine.stopSynth();
  }, [view, watching?.id, watchPlaying, watchSpeed]);

  // Local profile editor state
  const [editingProfile, setEditingProfile] = useState(false);
  const [profileSubTab, setProfileSubTab] = useState<"subs" | "history" | "likes" | "saved">("subs");
  const importInputRef = useRef<HTMLInputElement>(null);
  const sentinelRef = useRef<HTMLDivElement>(null);

  const allVideos = useMemo(() => [...BASE_YT_VIDEOS, ...extraBatches], [extraBatches]);

  // Personalized ranking + accurate search + category filtering
  const visibleFeed = useMemo(() => {
    const q = appliedQuery.trim().toLowerCase();
    let list = allVideos.filter((v) => {
      if (q) {
        const hay = `${v.title} ${v.channelName} ${v.category} ${v.tags.join(" ")}`.toLowerCase();
        return q.split(/\s+/).every((word) => hay.includes(word));
      }
      if (category === "الكل" || category === "مقترح ليك") return true;
      if (category === "اشتراكاتي") return profile.subscribedIds.includes(v.channelId);
      return v.category === category;
    });

    if (category === "مقترح ليك" || category === "الكل") {
      list = [...list].sort((a, b) => {
        const score = (it: YouTubeItem) =>
          (profile.subscribedIds.includes(it.channelId) ? 6 : 0) +
          (profile.categoryWeights[it.category] || 0);
        return score(b) - score(a);
      });
    }
    return list;
  }, [allVideos, appliedQuery, category, profile.subscribedIds, profile.categoryWeights]);

  // Real-time search autocomplete suggestions (local history + smart matches)
  const suggestions = useMemo(() => {
    const q = searchText.trim().toLowerCase();
    if (!q) return profile.searchHistory.slice(0, 6);
    const pool = Array.from(
      new Set([
        ...profile.searchHistory,
        ...YT_SEARCH_SUGGESTIONS,
        ...allVideos.map((v) => v.title),
        ...YT_CHANNELS.map((c) => c.name),
      ])
    );
    return pool.filter((s) => s.toLowerCase().includes(q)).slice(0, 7);
  }, [searchText, profile.searchHistory, allVideos]);

  // Infinite Scroll observer for endless personalized recommendations
  const appendMoreRecommendations = () => {
    if (appliedQuery || category === "اشتراكاتي") return;
    setExtraBatches((prev) => {
      if (prev.length >= 48) return prev;
      const next = generatePersonalizedBatch(batchCounter, profile.categoryWeights, profile.subscribedIds);
      return [...prev, ...next];
    });
    setBatchCounter((c) => c + 1);
  };

  useEffect(() => {
    if (view !== "feed") return;
    const node = sentinelRef.current;
    if (!node) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) appendMoreRecommendations();
      },
      { threshold: 0.1 }
    );
    obs.observe(node);
    return () => obs.disconnect();
  });

  // Live watch progress ticker
  useEffect(() => {
    if (view !== "watch" || !watching || !watchPlaying) return;
    const id = window.setInterval(() => {
      setWatchPos((p) => (p + watchSpeed >= watching.durationSec ? 0 : p + watchSpeed));
    }, 1000);
    return () => clearInterval(id);
  }, [view, watching, watchPlaying, watchSpeed]);

  const openWatch = (item: YouTubeItem) => {
    setWatching(item);
    setWatchPos(0);
    setWatchPlaying(true);
    setWatchAudioMode(false);
    setView("watch");
    onUpdateProfile((prev) => ({
      ...prev,
      watchHistoryIds: [item.id, ...prev.watchHistoryIds.filter((x) => x !== item.id)].slice(0, 60),
      categoryWeights: {
        ...prev.categoryWeights,
        [item.category]: (prev.categoryWeights[item.category] || 0) + 2,
      },
    }));
  };

  const runSearch = (query: string) => {
    const clean = query.trim();
    setSearchText(clean);
    setAppliedQuery(clean);
    setShowSuggestions(false);
    setView("feed");
    if (clean) {
      onUpdateProfile((prev) => ({
        ...prev,
        searchHistory: [clean, ...prev.searchHistory.filter((s) => s !== clean)].slice(0, 15),
      }));
    }
  };

  const toggleSubscribe = (channelId: string, channelName: string) => {
    const isSub = profile.subscribedIds.includes(channelId);
    const ch = YT_CHANNELS.find((c) => c.id === channelId);
    onUpdateProfile((prev) => ({
      ...prev,
      subscribedIds: isSub ? prev.subscribedIds.filter((id) => id !== channelId) : [channelId, ...prev.subscribedIds],
      categoryWeights: ch
        ? { ...prev.categoryWeights, [ch.category]: Math.max(0, (prev.categoryWeights[ch.category] || 0) + (isSub ? -2 : 4)) }
        : prev.categoryWeights,
    }));
    onNotify(isSub ? `لغيت الاشتراك في ${channelName}` : `اشتركت في ${channelName}`);
  };

  const toggleLike = (id: string) => {
    onUpdateProfile((prev) => ({
      ...prev,
      likedIds: prev.likedIds.includes(id) ? prev.likedIds.filter((x) => x !== id) : [id, ...prev.likedIds],
    }));
  };

  const toggleSave = (id: string) => {
    const saved = profile.savedIds.includes(id);
    onUpdateProfile((prev) => ({
      ...prev,
      savedIds: saved ? prev.savedIds.filter((x) => x !== id) : [id, ...prev.savedIds],
    }));
    onNotify(saved ? "اتشال من المحفوظات" : "اتحفظ في قائمتك المحلية");
  };

  const handleExportProfile = () => {
    const payload = JSON.stringify({ app: "JO_DON_LOCAL_PROFILE", version: 1, exportedAt: new Date().toISOString(), profile }, null, 2);
    const blob = new Blob([payload], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `jodon_profile_${profile.handle.replace("@", "")}.json`;
    a.click();
    URL.revokeObjectURL(url);
    onNotify("تم تصدير ملف حسابك المحلي بنجاح");
  };

  const handleImportProfile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        const candidate: LocalProfile = parsed.profile || parsed;
        if (candidate && typeof candidate.displayName === "string" && Array.isArray(candidate.subscribedIds)) {
          onReplaceProfile(candidate);
          onNotify("تم استيراد حسابك واشتراكاتك بنجاح!");
        } else {
          onNotify("ملف الحساب مش مظبوط");
        }
      } catch {
        onNotify("مقدرناش نقرا الملف، تأكد إنه ملف JSON سليم");
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  const findVideoById = (id: string) =>
    [...allVideos, ...BASE_SHORTS].find((v) => v.id === id);

  const currentShort = BASE_SHORTS[shortIdx % BASE_SHORTS.length];

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Native YouTube Top Bar: YouTube Logo + Shorts Button + My Local Account Button */}
      <div className="px-4 pt-4 pb-2 flex items-center justify-between gap-2 shrink-0">
        <button
          type="button"
          onClick={() => {
            setView("feed");
            setAppliedQuery("");
            setSearchText("");
          }}
          className="jo-press flex items-center gap-2"
        >
          <YouTubeLogoIcon size={26} />
          <span className="font-bold text-lg tracking-tight">يوتيوب</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setView(view === "shorts" ? "feed" : "shorts")}
            className={`jo-press px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 ${
              view === "shorts" ? "bg-[#FF0033] text-white" : "jo-btn-glass"
            }`}
          >
            <ShortsLogoIcon size={15} active={view === "shorts"} />
            <span>شورتس</span>
          </button>

          <button
            type="button"
            onClick={() => setView(view === "profile" ? "feed" : "profile")}
            className={`jo-press pl-3 pr-1.5 py-1 rounded-full text-xs font-semibold flex items-center gap-1.5 ${
              view === "profile" ? "jo-btn-primary" : "jo-btn-glass"
            }`}
          >
            <span
              className="w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-bold text-white"
              style={{ background: profile.avatarColor }}
            >
              {profile.displayName.trim()[0] || <User size={12} />}
            </span>
            <span>حسابي</span>
          </button>
        </div>
      </div>

      {/* ==================== 1) HOME FEED + SEARCH + INFINITE SUGGESTIONS ==================== */}
      {view === "feed" && (
        <div className="flex-1 overflow-y-auto jo-scroll px-4 pb-28 space-y-3">
          {/* Search bar with instant suggestions */}
          <div className="relative">
            <div className="jo-glass flex items-center gap-2 px-3.5 py-2 rounded-full">
              <Search size={16} style={{ color: "var(--jo-text-muted)" }} />
              <input
                type="text"
                value={searchText}
                onFocus={() => setShowSuggestions(true)}
                onChange={(e) => {
                  setSearchText(e.target.value);
                  setShowSuggestions(true);
                  if (!e.target.value.trim()) setAppliedQuery("");
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") runSearch(searchText);
                }}
                placeholder="دوّر في يوتيوب..."
                className="flex-1 bg-transparent outline-none text-xs py-0.5 min-w-0"
                style={{ color: "var(--jo-text)" }}
              />
              {searchText && (
                <button
                  type="button"
                  onClick={() => runSearch("")}
                  className="jo-press p-1"
                  style={{ color: "var(--jo-text-muted)" }}
                >
                  <X size={14} />
                </button>
              )}
              {searchText.trim() && (
                <button
                  type="button"
                  onClick={() => runSearch(searchText)}
                  className="jo-press jo-btn-primary px-3 py-1 text-xs rounded-full"
                >
                  بحث
                </button>
              )}
            </div>

            {showSuggestions && suggestions.length > 0 && (
              <div
                className="absolute inset-x-0 top-12 z-30 jo-glass-elevated p-2 space-y-0.5"
                style={{ background: "var(--jo-sheet-bg)" }}
              >
                <div className="flex items-center justify-between px-2.5 py-1 text-[11px]" style={{ color: "var(--jo-text-muted)" }}>
                  <span>{searchText.trim() ? "اقتراحات البحث" : "آخر حاجات دوّرت عليها"}</span>
                  <button type="button" onClick={() => setShowSuggestions(false)}>
                    قفل
                  </button>
                </div>
                {suggestions.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => runSearch(s)}
                    className="jo-press w-full px-3 py-2 rounded-xl text-right text-xs flex items-center gap-2.5 hover:bg-white/5"
                  >
                    {searchText.trim() ? (
                      <Search size={13} style={{ color: "var(--jo-text-muted)" }} />
                    ) : (
                      <History size={13} style={{ color: "var(--jo-text-muted)" }} />
                    )}
                    <span className="truncate flex-1">{s}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Category filter pills */}
          {!appliedQuery && (
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-0.5">
              {YT_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`jo-press px-3.5 py-1.5 rounded-full text-xs shrink-0 ${
                    category === cat ? "jo-btn-primary" : "jo-btn-glass"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          )}

          {appliedQuery && (
            <div className="flex items-center justify-between text-xs px-1" style={{ color: "var(--jo-text-2)" }}>
              <span>
                نتائج "{appliedQuery}" ({visibleFeed.length})
              </span>
              <button type="button" onClick={() => runSearch("")} style={{ color: "var(--jo-accent-1)" }}>
                رجوع للرئيسية
              </button>
            </div>
          )}

          {visibleFeed.length === 0 ? (
            <div className="jo-glass p-6 text-center space-y-2">
              <p className="text-sm font-semibold">
                {category === "اشتراكاتي" ? "لسه مشتركتش في قنوات" : "مفيش فيديو مطابق للكلمة دي"}
              </p>
              <p className="text-xs" style={{ color: "var(--jo-text-muted)" }}>
                {category === "اشتراكاتي"
                  ? "دوس اشترك تحت أي فيديو وهتظهر فيديوهات قنواتك هنا فوراً"
                  : "جرّب كلمة تانية زي: شفق، أندرويد، موسيقى، دهب"}
              </p>
            </div>
          ) : (
            <div className="space-y-3.5">
              {visibleFeed.map((video) => {
                const isSub = profile.subscribedIds.includes(video.channelId);
                return (
                  <article key={video.id} className="jo-glass overflow-hidden">
                    {/* Clickable 16:9 Thumbnail */}
                    <button
                      type="button"
                      onClick={() => openWatch(video)}
                      className="relative w-full aspect-video block overflow-hidden text-right"
                    >
                      <img src={video.coverImage} alt={video.title} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-transparent to-transparent" />
                      <span className="absolute bottom-2.5 left-2.5 text-[11px] font-medium px-2 py-0.5 rounded-lg bg-black/80 text-white">
                        {formatDuration(video.durationSec)}
                      </span>
                      <span className="absolute top-2.5 right-2.5 text-[10px] px-2.5 py-0.5 rounded-full bg-black/55 text-white/90 backdrop-blur-md">
                        {video.category}
                      </span>
                    </button>

                    {/* Metadata + Direct Action Bar under every video */}
                    <div className="p-3.5 space-y-3">
                      <div className="flex items-start gap-2.5">
                        <span
                          className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0 mt-0.5"
                          style={{ background: video.channelColor }}
                        >
                          {video.channelName[0]}
                        </span>
                        <button type="button" onClick={() => openWatch(video)} className="flex-1 min-w-0 text-right">
                          <h3 className="font-semibold text-sm leading-snug line-clamp-2">{video.title}</h3>
                          <p className="text-[11px] mt-1" style={{ color: "var(--jo-text-muted)" }}>
                            {video.channelName} • {formatViewsAr(video.views)} • {video.uploadedAr}
                          </p>
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onOpenDownload(buildAnalysisForUrl(video.url, video), "video")}
                          className="jo-press jo-btn-primary flex-1 py-2 px-3 text-xs flex items-center justify-center gap-1.5"
                        >
                          <Download size={14} />
                          <span>حمّل</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onPlayAsSong(video)}
                          title="شغّل كأغنية"
                          className="jo-press jo-btn-glass py-2 px-2.5 text-xs flex items-center gap-1"
                        >
                          <Headphones size={14} />
                          <span>كأغنية</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onCopyLink(video.url)}
                          title="نسخ اللينك"
                          className="jo-press jo-btn-glass py-2 px-2.5 text-xs flex items-center gap-1"
                        >
                          <Copy size={13} />
                          <span>نسخ</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => toggleSubscribe(video.channelId, video.channelName)}
                          className={`jo-press py-2 px-2.5 rounded-[20px] text-xs font-semibold flex items-center gap-1 ${
                            isSub ? "bg-emerald-500/18 text-emerald-400 border border-emerald-500/30" : "jo-btn-glass"
                          }`}
                        >
                          {isSub ? <UserCheck size={13} /> : <UserPlus size={13} />}
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })}

              {/* Infinite scroll trigger + manual button */}
              {!appliedQuery && category !== "اشتراكاتي" && (
                <div ref={sentinelRef} className="py-2 text-center">
                  <button
                    type="button"
                    onClick={appendMoreRecommendations}
                    className="jo-press jo-btn-glass px-4 py-2 text-xs rounded-full inline-flex items-center gap-1.5"
                  >
                    <Plus size={14} />
                    <span>اقتراحات أكتر على ذوقك</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ==================== 2) WATCH SCREEN ==================== */}
      {view === "watch" && watching && (
        <div className="flex-1 overflow-y-auto jo-scroll px-4 pb-28 space-y-3 jo-reveal">
          <button
            type="button"
            onClick={() => setView("feed")}
            className="jo-press flex items-center gap-1.5 text-xs font-medium"
            style={{ color: "var(--jo-text-2)" }}
          >
            <ArrowRight size={15} />
            <span>رجوع للفيديوهات</span>
          </button>

          {/* Native Video / Audio-Only Player */}
          <div className="relative aspect-video rounded-3xl overflow-hidden border" style={{ borderColor: "var(--jo-border-strong)" }}>
            <img
              src={watching.coverImage}
              alt={watching.title}
              className={`w-full h-full object-cover transition-transform duration-700 ${
                watchPlaying ? "scale-105" : "scale-100"
              } ${watchAudioMode ? "blur-md brightness-50" : ""}`}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-black/30" />

            {/* Top controls: Quality + Speed */}
            <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between text-[11px] text-white">
              <button
                type="button"
                onClick={() => {
                  const qs = ["4K HDR", "1080p60", "720p", "480p"];
                  setWatchQuality(qs[(qs.indexOf(watchQuality) + 1) % qs.length]);
                }}
                className="jo-press px-2.5 py-1 rounded-full bg-black/55 backdrop-blur-md"
              >
                {watchAudioMode ? "صوت نقي بالخلفية" : watchQuality}
              </button>
              <button
                type="button"
                onClick={() => {
                  const sp = [0.75, 1, 1.25, 1.5, 2];
                  setWatchSpeed(sp[(sp.indexOf(watchSpeed) + 1) % sp.length]);
                }}
                className="jo-press px-2.5 py-1 rounded-full bg-black/55 backdrop-blur-md"
              >
                {watchSpeed}x
              </button>
            </div>

            {/* Center Play/Pause */}
            <button
              type="button"
              onClick={() => setWatchPlaying(!watchPlaying)}
              className="jo-press absolute inset-0 m-auto w-14 h-14 rounded-full bg-black/55 backdrop-blur-md border border-white/30 flex items-center justify-center text-white"
            >
              {watchPlaying ? <Pause size={22} /> : <Play size={22} />}
            </button>

            {/* Scrub bar */}
            <div className="absolute bottom-2.5 inset-x-3 space-y-1">
              <input
                type="range"
                min={0}
                max={watching.durationSec}
                value={watchPos}
                onChange={(e) => setWatchPos(Number(e.target.value))}
                className="jo-range w-full"
              />
              <div className="flex justify-between text-[10px] text-white/85">
                <span>{formatDuration(watchPos)}</span>
                <span>{formatDuration(watching.durationSec)}</span>
              </div>
            </div>
          </div>

          <h2 className="font-bold text-base leading-snug">{watching.title}</h2>
          <p className="text-xs" style={{ color: "var(--jo-text-muted)" }}>
            {formatViewsAr(watching.views)} • {watching.uploadedAr}
          </p>

          {/* Channel + Local Subscribe */}
          <div className="jo-glass p-3 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5 min-w-0">
              <span
                className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0"
                style={{ background: watching.channelColor }}
              >
                {watching.channelName[0]}
              </span>
              <div className="min-w-0">
                <div className="font-semibold text-sm truncate">{watching.channelName}</div>
                <div className="text-[11px]" style={{ color: "var(--jo-text-muted)" }}>
                  {YT_CHANNELS.find((c) => c.id === watching.channelId)?.subsLabel || "قناة موثقة"}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => toggleSubscribe(watching.channelId, watching.channelName)}
              className={`jo-press px-4 py-2 text-xs rounded-full font-semibold ${
                profile.subscribedIds.includes(watching.channelId) ? "jo-btn-glass" : "bg-[#FF0033] text-white"
              }`}
            >
              {profile.subscribedIds.includes(watching.channelId) ? "مشترك ✓" : "اشترك"}
            </button>
          </div>

          {/* Rich Action Pills: Download, Play as Song, Copy Link, Like, Save */}
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            <button
              type="button"
              onClick={() => onOpenDownload(buildAnalysisForUrl(watching.url, watching), "video")}
              className="jo-press jo-btn-primary px-4 py-2 text-xs rounded-full flex items-center gap-1.5 shrink-0"
            >
              <Download size={14} />
              <span>حمّل الفيديو أو الصوت</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setWatchAudioMode(!watchAudioMode);
                onPlayAsSong(watching);
              }}
              className="jo-press jo-btn-glass px-3.5 py-2 text-xs rounded-full flex items-center gap-1.5 shrink-0"
            >
              <Headphones size={14} />
              <span>شغّل كأغنية</span>
            </button>

            <button
              type="button"
              onClick={() => onCopyLink(watching.url)}
              className="jo-press jo-btn-glass px-3.5 py-2 text-xs rounded-full flex items-center gap-1.5 shrink-0"
            >
              <Copy size={14} />
              <span>نسخ اللينك</span>
            </button>

            <button
              type="button"
              onClick={() => toggleLike(watching.id)}
              className={`jo-press px-3.5 py-2 text-xs rounded-full flex items-center gap-1.5 shrink-0 ${
                profile.likedIds.includes(watching.id) ? "jo-btn-primary" : "jo-btn-glass"
              }`}
            >
              <ThumbsUp size={14} />
              <span>{profile.likedIds.includes(watching.id) ? "عجبني" : "أعجبني"}</span>
            </button>

            <button
              type="button"
              onClick={() => toggleSave(watching.id)}
              className={`jo-press px-3.5 py-2 text-xs rounded-full flex items-center gap-1.5 shrink-0 ${
                profile.savedIds.includes(watching.id) ? "jo-btn-primary" : "jo-btn-glass"
              }`}
            >
              <Bookmark size={14} />
              <span>{profile.savedIds.includes(watching.id) ? "محفوظ" : "احفظ"}</span>
            </button>
          </div>

          <p className="jo-glass p-3 text-xs leading-relaxed" style={{ color: "var(--jo-text-2)" }}>
            {watching.description}
          </p>

          {/* Suggested Next Videos */}
          <div className="space-y-2 pt-1">
            <h3 className="text-sm font-bold">فيديوهات مقترحة ليك</h3>
            {allVideos
              .filter((v) => v.id !== watching.id)
              .slice(0, 5)
              .map((rel) => (
                <div key={rel.id} className="jo-glass p-2.5 flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => openWatch(rel)}
                    className="relative w-28 h-16 rounded-2xl overflow-hidden shrink-0"
                  >
                    <img src={rel.coverImage} alt={rel.title} className="w-full h-full object-cover" />
                    <span className="absolute bottom-1 left-1 text-[10px] px-1.5 rounded bg-black/75 text-white">
                      {formatDuration(rel.durationSec)}
                    </span>
                  </button>
                  <button type="button" onClick={() => openWatch(rel)} className="flex-1 min-w-0 text-right">
                    <div className="text-xs font-semibold line-clamp-2">{rel.title}</div>
                    <div className="text-[11px] mt-0.5" style={{ color: "var(--jo-text-muted)" }}>
                      {rel.channelName}
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenDownload(buildAnalysisForUrl(rel.url, rel), "video")}
                    className="jo-press jo-btn-glass w-9 h-9 rounded-2xl flex items-center justify-center shrink-0"
                    title="تحميل"
                  >
                    <Download size={14} />
                  </button>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* ==================== 3) VERTICAL SHORTS PLAYER ==================== */}
      {view === "shorts" && currentShort && (
        <div className="flex-1 px-4 pb-28 flex flex-col jo-reveal">
          <div
            onTouchStart={(e) => {
              swipeStartY.current = e.touches[0]?.clientY ?? null;
            }}
            onTouchEnd={(e) => {
              if (swipeStartY.current === null) return;
              const dy = swipeStartY.current - (e.changedTouches[0]?.clientY ?? swipeStartY.current);
              if (dy > 45) setShortIdx((i) => (i + 1) % BASE_SHORTS.length);
              else if (dy < -45) setShortIdx((i) => (i - 1 + BASE_SHORTS.length) % BASE_SHORTS.length);
              swipeStartY.current = null;
            }}
            className="relative flex-1 rounded-[28px] overflow-hidden border select-none"
            style={{ borderColor: "var(--jo-border-strong)" }}
          >
            <img src={currentShort.coverImage} alt={currentShort.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/15 to-black/25" />

            {/* Top counter + swipe arrows */}
            <div className="absolute top-3 left-3 flex flex-col gap-2">
              <button
                type="button"
                onClick={() => setShortIdx((i) => (i - 1 + BASE_SHORTS.length) % BASE_SHORTS.length)}
                className="jo-press w-9 h-9 rounded-full bg-black/50 backdrop-blur-md text-white flex items-center justify-center"
                aria-label="الشورت اللي قبله"
              >
                <ChevronUp size={18} />
              </button>
              <button
                type="button"
                onClick={() => setShortIdx((i) => (i + 1) % BASE_SHORTS.length)}
                className="jo-press w-9 h-9 rounded-full bg-black/50 backdrop-blur-md text-white flex items-center justify-center"
                aria-label="الشورت اللي بعده"
              >
                <ChevronDown size={18} />
              </button>
            </div>

            {/* Side vertical Shorts action rail */}
            <div className="absolute left-3 bottom-24 flex flex-col items-center gap-3 text-white">
              <button
                type="button"
                onClick={() => toggleLike(currentShort.id)}
                className={`jo-press w-11 h-11 rounded-full backdrop-blur-md flex items-center justify-center ${
                  profile.likedIds.includes(currentShort.id) ? "bg-rose-500" : "bg-black/50"
                }`}
              >
                <Heart size={19} />
              </button>
              <button
                type="button"
                onClick={() => onOpenDownload(buildAnalysisForUrl(currentShort.url, currentShort), "video")}
                className="jo-press w-11 h-11 rounded-full jo-btn-primary flex items-center justify-center"
                title="حمّل الشورت"
              >
                <Download size={19} />
              </button>
              <button
                type="button"
                onClick={() => onCopyLink(currentShort.url)}
                className="jo-press w-11 h-11 rounded-full bg-black/50 backdrop-blur-md flex items-center justify-center"
                title="نسخ اللينك"
              >
                <Copy size={18} />
              </button>
              <button
                type="button"
                onClick={() => onPlayAsSong(currentShort)}
                className="jo-press w-11 h-11 rounded-full bg-black/50 backdrop-blur-md flex items-center justify-center"
                title="شغّل الصوت"
              >
                <Headphones size={18} />
              </button>
            </div>

            {/* Bottom info + local subscribe */}
            <div className="absolute bottom-4 right-4 left-16 text-white space-y-2">
              <div className="flex items-center gap-2">
                <span
                  className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold"
                  style={{ background: currentShort.channelColor }}
                >
                  {currentShort.channelName[0]}
                </span>
                <span className="text-xs font-semibold">{currentShort.channelName}</span>
                <button
                  type="button"
                  onClick={() => toggleSubscribe(currentShort.channelId, currentShort.channelName)}
                  className="jo-press px-3 py-1 rounded-full text-[11px] font-semibold bg-white text-black"
                >
                  {profile.subscribedIds.includes(currentShort.channelId) ? "مشترك" : "اشترك"}
                </button>
              </div>
              <p className="text-sm font-bold leading-snug">{currentShort.title}</p>
              <p className="text-[11px] text-white/75">{formatViewsAr(currentShort.views)}</p>
            </div>
          </div>
        </div>
      )}

      {/* ==================== 4) LOCAL PROFILE (NO GOOGLE LOGIN + EXPORT/IMPORT JSON) ==================== */}
      {view === "profile" && (
        <div className="flex-1 overflow-y-auto jo-scroll px-4 pb-28 space-y-3.5 jo-reveal">
          <div className="jo-glass-elevated p-4 space-y-3.5">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className="w-13 h-13 rounded-full flex items-center justify-center text-lg font-bold text-white shrink-0"
                  style={{ background: profile.avatarColor }}
                >
                  {profile.displayName.trim()[0] || "ج"}
                </div>
                <div className="min-w-0">
                  <h2 className="font-bold text-base truncate">{profile.displayName}</h2>
                  <p className="text-xs" style={{ color: "var(--jo-text-muted)" }}>
                    {profile.handle} • حساب محلي بدون تسجيل دخول
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingProfile(!editingProfile)}
                className="jo-press jo-btn-glass w-9 h-9 rounded-2xl flex items-center justify-center shrink-0"
              >
                <Edit3 size={15} />
              </button>
            </div>

            {editingProfile && (
              <div className="space-y-2.5 pt-1 border-t" style={{ borderColor: "var(--jo-border)" }}>
                <input
                  type="text"
                  value={profile.displayName}
                  onChange={(e) => onUpdateProfile((p) => ({ ...p, displayName: e.target.value }))}
                  placeholder="اسمك"
                  className="w-full rounded-xl px-3 py-2 text-xs outline-none border"
                  style={{ background: "var(--jo-surface)", borderColor: "var(--jo-border)", color: "var(--jo-text)" }}
                />
                <input
                  type="text"
                  value={profile.bio}
                  onChange={(e) => onUpdateProfile((p) => ({ ...p, bio: e.target.value }))}
                  placeholder="نبذة قصيرة"
                  className="w-full rounded-xl px-3 py-2 text-xs outline-none border"
                  style={{ background: "var(--jo-surface)", borderColor: "var(--jo-border)", color: "var(--jo-text)" }}
                />
                <div className="flex items-center gap-2">
                  {AVATAR_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => onUpdateProfile((p) => ({ ...p, avatarColor: c }))}
                      className={`w-7 h-7 rounded-full ${profile.avatarColor === c ? "ring-2 ring-white" : ""}`}
                      style={{ background: c }}
                    />
                  ))}
                </div>
              </div>
            )}

            <p className="text-xs" style={{ color: "var(--jo-text-2)" }}>
              {profile.bio}
            </p>

            {/* Export & Import Local Profile JSON */}
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={handleExportProfile}
                className="jo-press jo-btn-primary py-2.5 text-xs flex items-center justify-center gap-1.5"
              >
                <Download size={14} />
                <span>تصدير حسابي</span>
              </button>
              <button
                type="button"
                onClick={() => importInputRef.current?.click()}
                className="jo-press jo-btn-glass py-2.5 text-xs flex items-center justify-center gap-1.5"
              >
                <Upload size={14} />
                <span>استيراد حسابي</span>
              </button>
              <input
                ref={importInputRef}
                type="file"
                accept=".json,application/json"
                onChange={handleImportProfile}
                className="hidden"
              />
            </div>
          </div>

          {/* Local profile sections */}
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {[
              { id: "subs", label: `اشتراكاتي (${profile.subscribedIds.length})` },
              { id: "history", label: `السجل (${profile.watchHistoryIds.length})` },
              { id: "likes", label: `عجبني (${profile.likedIds.length})` },
              { id: "saved", label: `المحفوظات (${profile.savedIds.length})` },
            ].map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setProfileSubTab(t.id as typeof profileSubTab)}
                className={`jo-press px-3.5 py-1.5 rounded-full text-xs shrink-0 ${
                  profileSubTab === t.id ? "jo-btn-primary" : "jo-btn-glass"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {profileSubTab === "subs" ? (
            <div className="space-y-2">
              {YT_CHANNELS.map((ch) => {
                const sub = profile.subscribedIds.includes(ch.id);
                return (
                  <div key={ch.id} className="jo-glass p-3 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span
                        className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0"
                        style={{ background: ch.color }}
                      >
                        {ch.name[0]}
                      </span>
                      <div className="min-w-0">
                        <div className="text-sm font-semibold truncate">{ch.name}</div>
                        <div className="text-[11px]" style={{ color: "var(--jo-text-muted)" }}>
                          {ch.category} • {ch.subsLabel}
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => toggleSubscribe(ch.id, ch.name)}
                      className={`jo-press px-3.5 py-1.5 text-xs rounded-full ${sub ? "jo-btn-glass" : "jo-btn-primary"}`}
                    >
                      {sub ? "إلغاء الاشتراك" : "اشترك"}
                    </button>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="space-y-2">
              {(profileSubTab === "history"
                ? profile.watchHistoryIds
                : profileSubTab === "likes"
                ? profile.likedIds
                : profile.savedIds
              )
                .map(findVideoById)
                .filter((x): x is YouTubeItem => Boolean(x))
                .map((v) => (
                  <div key={v.id} className="jo-glass p-3 flex items-center justify-between gap-2.5">
                    <button type="button" onClick={() => openWatch(v)} className="flex-1 min-w-0 text-right">
                      <div className="text-xs font-semibold truncate">{v.title}</div>
                      <div className="text-[11px] mt-0.5" style={{ color: "var(--jo-text-muted)" }}>
                        {v.channelName} • {formatDuration(v.durationSec)}
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenDownload(buildAnalysisForUrl(v.url, v), "video")}
                      className="jo-press jo-btn-glass w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                    >
                      <Download size={14} />
                    </button>
                  </div>
                ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
