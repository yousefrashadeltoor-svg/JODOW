import React, { useState } from "react";
import {
  Check,
  Code2,
  Download,
  FileText,
  Film,
  FolderGit2,
  Image as ImageIcon,
  Music2,
  RefreshCw,
  ShieldCheck,
  X,
} from "lucide-react";
import { AnalyzedLink, MediaKind, MediaOption } from "../types/app";
import { formatExactBytesAr, formatSizeAr } from "../data/catalog";

/** Official-style crisp YouTube Play Icon (non-Material custom SVG). */
export const YouTubeLogoIcon: React.FC<{ className?: string; size?: number }> = ({ className = "", size = 22 }) => (
  <svg width={size} height={size} viewBox="0 0 28 20" fill="none" className={className} aria-hidden="true">
    <rect x="0.5" y="0.5" width="27" height="19" rx="5.5" fill="#FF0033" />
    <path d="M11.2 5.8L18.8 10L11.2 14.2V5.8Z" fill="#FFFFFF" />
  </svg>
);

/** Crisp Shorts Bolt-Play SVG icon. */
export const ShortsLogoIcon: React.FC<{ size?: number; active?: boolean }> = ({ size = 17, active = false }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path
      d="M16.2 2.6L6.8 8.1C4.9 9.2 5.2 12 7.2 12.8L8.8 13.4L7.1 14.4C5.1 15.6 5.5 18.6 7.7 19.3L9.2 21.4L17.6 16.2C19.4 15.1 19.1 12.3 17.1 11.5L15.4 10.8L17.1 9.8C19 8.6 18.4 5.6 16.2 2.6Z"
      fill={active ? "#FFFFFF" : "#FF0033"}
    />
    <path d="M10.2 9.4L14.6 12L10.2 14.6V9.4Z" fill={active ? "#FF0033" : "#FFFFFF"} />
  </svg>
);

/** Smooth Speed Sparkline used in Download Manager cards. */
export const SpeedSparklineSvg: React.FC<{ points: number[] }> = ({ points }) => {
  if (points.length < 2) return null;
  const max = Math.max(...points, 1);
  const w = 220;
  const h = 28;
  const coords = points.map((v, i) => {
    const x = (i / (points.length - 1)) * w;
    const y = h - (v / max) * (h - 5) - 2;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-7 overflow-visible" preserveAspectRatio="none">
      <polyline
        fill="none"
        stroke="var(--jo-accent-1)"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
        points={coords.join(" ")}
      />
    </svg>
  );
};

/**
 * STRICT Section 4.4: The 4 Smart Category Buttons (صوت | صور | فيديو | ملفات).
 * A button NEVER appears if its media count is 0.
 */
export const FourSmartButtons: React.FC<{
  analysis: AnalyzedLink;
  onSelectKind: (kind: MediaKind) => void;
}> = ({ analysis, onSelectKind }) => {
  const buttons: { kind: MediaKind; label: string; list: MediaOption[]; color: string; icon: React.ReactNode }[] = [
    { kind: "video", label: "فيديو", list: analysis.videos, color: "var(--jo-accent-1)", icon: <Film size={18} /> },
    { kind: "audio", label: "صوت", list: analysis.audios, color: "var(--jo-accent-2)", icon: <Music2 size={18} /> },
    { kind: "image", label: "صور", list: analysis.images, color: "var(--jo-accent-3)", icon: <ImageIcon size={18} /> },
    { kind: "file", label: "ملفات", list: analysis.files, color: "#22C55E", icon: <FileText size={18} /> },
  ];

  const available = buttons.filter((b) => b.list.length > 0);
  if (available.length === 0) return null;

  return (
    <div
      className={`grid gap-2.5 ${
        available.length === 1 ? "grid-cols-1" : available.length === 3 ? "grid-cols-3" : "grid-cols-2"
      }`}
    >
      {available.map((b, idx) => (
        <button
          key={b.kind}
          type="button"
          onClick={() => onSelectKind(b.kind)}
          style={{ animationDelay: `${idx * 45}ms` }}
          className="jo-glass-elevated jo-press jo-reveal p-3.5 text-right flex items-center justify-between gap-2"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span
              className="w-9 h-9 rounded-2xl flex items-center justify-center shrink-0"
              style={{ background: `color-mix(in srgb, ${b.color} 18%, transparent)`, color: b.color }}
            >
              {b.icon}
            </span>
            <span className="font-semibold text-sm truncate" style={{ color: "var(--jo-text)" }}>
              {b.label}
            </span>
          </div>
          <span
            className="text-xs font-bold px-2.5 py-0.5 rounded-full shrink-0"
            style={{ background: `color-mix(in srgb, ${b.color} 20%, transparent)`, color: b.color }}
          >
            {b.list.length}
          </span>
        </button>
      ))}
    </div>
  );
};

/** Glass Bottom Sheet listing every resolution, codec, FPS, exact/approx byte size, DASH auto-merge, and convert trigger. */
export const QualityBottomSheet: React.FC<{
  analysis: AnalyzedLink | null;
  activeKind: MediaKind | null;
  customFileName?: string;
  onClose: () => void;
  onChangeKind: (kind: MediaKind) => void;
  onDownload: (analysis: AnalyzedLink, option: MediaOption, customName?: string) => void;
  onConvertOption?: (analysis: AnalyzedLink, option: MediaOption) => void;
}> = ({ analysis, activeKind, customFileName, onClose, onChangeKind, onDownload, onConvertOption }) => {
  const [exactOpenId, setExactOpenId] = useState<string | null>(null);
  if (!analysis || !activeKind) return null;

  const map: Record<MediaKind, { title: string; items: MediaOption[] }> = {
    video: { title: "فيديو", items: analysis.videos },
    audio: { title: "صوت", items: analysis.audios },
    image: { title: "صور", items: analysis.images },
    file: { title: "ملفات", items: analysis.files },
  };

  const availableKinds = (["video", "audio", "image", "file"] as MediaKind[]).filter((k) => map[k].items.length > 0);
  const current = map[activeKind].items.length > 0 ? activeKind : availableKinds[0];
  if (!current) return null;

  return (
    <div
      className="absolute inset-0 z-50 flex items-end justify-center bg-black/55 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="jo-sheet-in w-full max-h-[82%] flex flex-col rounded-t-[30px] border-t border-x p-4 pb-6"
        style={{
          background: "var(--jo-sheet-bg)",
          borderColor: "var(--jo-border-strong)",
          backdropFilter: "blur(32px)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-10 h-1 rounded-full bg-white/25 mx-auto mb-3" />

        <div className="flex items-center justify-between gap-3 mb-3">
          <div className="min-w-0">
            <h3 className="font-bold text-base truncate">{analysis.title}</h3>
            <p className="text-xs" style={{ color: "var(--jo-text-muted)" }}>
              دوس على الحجم عشان تشوفه بالبايت بالظبط
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="jo-press w-8 h-8 rounded-full flex items-center justify-center jo-btn-glass shrink-0"
            aria-label="قفل"
          >
            <X size={16} />
          </button>
        </div>

        {availableKinds.length > 1 && (
          <div className="flex gap-2 mb-3 overflow-x-auto no-scrollbar pb-0.5">
            {availableKinds.map((k) => (
              <button
                key={k}
                type="button"
                onClick={() => onChangeKind(k)}
                className={`jo-press px-3.5 py-1.5 text-xs rounded-full shrink-0 ${
                  k === current ? "jo-btn-primary" : "jo-btn-glass"
                }`}
              >
                {map[k].title} ({map[k].items.length})
              </button>
            ))}
          </div>
        )}

        <div className="overflow-y-auto jo-scroll space-y-2 pr-0.5">
          {map[current].items.map((opt) => {
            const showExact = exactOpenId === opt.id;
            return (
              <div
                key={opt.id}
                className="jo-glass p-3 flex items-center justify-between gap-3"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-sm">{opt.label}</span>
                    <span
                      className="text-[11px] px-2 py-0.5 rounded-full font-medium uppercase"
                      style={{ background: "var(--jo-surface-elevated)", color: "var(--jo-text-2)" }}
                    >
                      {opt.ext}
                    </span>
                    {opt.dashMerge && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-500/15 text-sky-400">
                        دمج صوت تلقائي
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-1 flex-wrap text-xs" style={{ color: "var(--jo-text-muted)" }}>
                    <span>{opt.codec}</span>
                    <span>•</span>
                    <span>{opt.detail}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setExactOpenId(showExact ? null : opt.id)}
                    className={`mt-1 text-xs font-medium text-right ${
                      opt.isExact ? "text-emerald-400" : "text-amber-400"
                    }`}
                  >
                    {showExact ? formatExactBytesAr(opt.bytes, opt.isExact) : formatSizeAr(opt.bytes, opt.isExact)}
                    {!opt.isExact && !showExact ? " (تقريبي)" : ""}
                  </button>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  {onConvertOption && (opt.kind === "video" || opt.kind === "audio") && (
                    <button
                      type="button"
                      onClick={() => {
                        onConvertOption(analysis, opt);
                        onClose();
                      }}
                      title="تحويل لصيغة تانية"
                      className="jo-press jo-btn-glass w-9 h-9 rounded-2xl flex items-center justify-center"
                    >
                      <RefreshCw size={15} />
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      onDownload(analysis, opt, customFileName);
                      onClose();
                    }}
                    className="jo-press jo-btn-primary px-3.5 py-2 text-xs flex items-center gap-1.5"
                  >
                    <Download size={14} />
                    <span>حمّل</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

/** Clean modal showing the complete real Android multi-module project built inside `JP PROJ/`. */
export const AndroidProjectModal: React.FC<{ open: boolean; onClose: () => void }> = ({ open, onClose }) => {
  if (!open) return null;
  const modules = [
    { path: ":app", info: "التشغيل، Floating Glass Dock، Share Intent، Widget، Quick Tile" },
    { path: ":core:designsystem", info: "Aurora Glass بدون Material + 6 ثيمات بصورها الواقعية + AGSL" },
    { path: ":core:network + :core:database", info: "OkHttp HTTP/2 + Cronet HTTP/3 + CookieJar مشفر + تخزين محلي ذري" },
    { path: ":engine:downloader", info: "تحميل مجزأ 8–32 اتصال + Work-Stealing + FileChannel + Resume + Tests" },
    { path: ":engine:extractors", info: "NewPipeExtractor ليوتيوب الأصلي (بدون API/WebView) + yt-dlp + aria2c" },
    { path: ":engine:media", info: "FFmpeg دمج وتحويل + قص يدوي + تصغير ذكي SSIM + RingtoneManager" },
    { path: ":feature:youtube", info: "يوتيوب أصلي كامل + شورتس + بحث واقتراحات + حساب محلي JSON" },
    { path: ":feature:player + :feature:files", info: "مشغل محلي بقص مرئي ونغمة رنين ومؤقت نوم + مكتبة موسيقى وخزنة بصمة" },
    { path: ":feature:home / downloads / browser / compressor / converter / settings", info: "جميع شاشات التطبيق كاملة بـ Clean Architecture + MVI" },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="jo-glass-elevated jo-sheet-in w-full max-w-lg max-h-[85vh] overflow-y-auto jo-scroll p-5 space-y-4"
        style={{ background: "var(--jo-sheet-bg)" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <FolderGit2 size={20} style={{ color: "var(--jo-accent-1)" }} />
            <h2 className="font-bold text-lg">مشروع الأندرويد الكامل (JP PROJ)</h2>
          </div>
          <button type="button" onClick={onClose} className="jo-press jo-btn-glass w-8 h-8 rounded-full flex items-center justify-center">
            <X size={16} />
          </button>
        </div>

        <div className="jo-glass p-3.5 text-xs space-y-1.5" style={{ color: "var(--jo-text-2)" }}>
          <div className="flex items-center gap-2 text-emerald-400 font-semibold">
            <ShieldCheck size={15} />
            <span>18 Module Kotlin 2.1 جاهزة لبناء APK مباشر (minSdk 24 / targetSdk 35)</span>
          </div>
          <p>صفر Material Design • صفر Firebase أو تتبع • صفر API رسمي ليوتيوب (NewPipeExtractor v0.25.2 + yt-dlp 0.18.1 + Media3 + Haze).</p>
        </div>

        <div className="space-y-2">
          {modules.map((m) => (
            <div key={m.path} className="jo-glass p-3 flex items-start gap-2.5">
              <Check size={15} className="text-emerald-400 mt-0.5 shrink-0" />
              <div className="min-w-0">
                <div className="font-mono text-xs font-semibold" dir="ltr" style={{ color: "var(--jo-accent-1)" }}>
                  {m.path}
                </div>
                <div className="text-xs mt-0.5" style={{ color: "var(--jo-text-2)" }}>
                  {m.info}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="jo-glass p-3.5 space-y-1.5">
          <div className="flex items-center gap-1.5 text-xs font-semibold">
            <Code2 size={14} />
            <span>أمر بناء ملف الـ APK مباشرة:</span>
          </div>
          <pre
            dir="ltr"
            className="text-[11px] p-2.5 rounded-xl bg-black/40 text-emerald-300 overflow-x-auto font-mono"
          >{`cd "JP PROJ"\n./gradlew testDebugUnitTest assembleDebug`}</pre>
        </div>
      </div>
    </div>
  );
};
