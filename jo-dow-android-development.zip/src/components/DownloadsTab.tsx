import React, { useState } from "react";
import {
  ArrowUp,
  Clock,
  Copy,
  Minimize2,
  Pause,
  Play,
  RotateCcw,
  SlidersHorizontal,
  Trash2,
  Wifi,
  Zap,
} from "lucide-react";
import { AppSettings, DownloadStatus, DownloadTask, MediaKind } from "../types/app";
import { formatEtaAr, formatExactBytesAr, formatSizeAr, formatSpeedAr } from "../data/catalog";
import { SpeedSparklineSvg } from "./SharedUI";

interface DownloadsTabProps {
  downloads: DownloadTask[];
  settings: AppSettings;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  onTogglePause: (id: string) => void;
  onPauseAll: () => void;
  onResumeAll: () => void;
  onRemove: (id: string) => void;
  onMoveTop: (id: string) => void;
  onCopyLink: (url: string) => void;
  onPlayDownloaded: (task: DownloadTask) => void;
  onSendToCompressor: (task: DownloadTask) => void;
}

const STATUS_TABS: { id: "all" | DownloadStatus; label: string }[] = [
  { id: "all", label: "الكل" },
  { id: "running", label: "شغّال" },
  { id: "queued", label: "في الطابور" },
  { id: "completed", label: "خلص" },
  { id: "failed", label: "وقف" },
];

const KIND_CHIPS: { id: "all" | MediaKind; label: string }[] = [
  { id: "all", label: "كل الأنواع" },
  { id: "video", label: "فيديو" },
  { id: "audio", label: "صوت" },
  { id: "image", label: "صور" },
  { id: "file", label: "ملفات" },
];

export const DownloadsTab: React.FC<DownloadsTabProps> = ({
  downloads,
  settings,
  onUpdateSettings,
  onTogglePause,
  onPauseAll,
  onResumeAll,
  onRemove,
  onMoveTop,
  onCopyLink,
  onPlayDownloaded,
  onSendToCompressor,
}) => {
  const [statusFilter, setStatusFilter] = useState<"all" | DownloadStatus>("all");
  const [kindFilter, setKindFilter] = useState<"all" | MediaKind>("all");
  const [showControls, setShowControls] = useState(false);
  const [exactId, setExactId] = useState<string | null>(null);
  const [scheduleTime, setScheduleTime] = useState("");

  const totalSpeed = downloads
    .filter((d) => d.status === "running")
    .reduce((sum, d) => sum + d.speedBps, 0);

  const visible = downloads.filter((d) => {
    const okStatus =
      statusFilter === "all" ||
      d.status === statusFilter ||
      (statusFilter === "running" && d.status === "merging") ||
      (statusFilter === "queued" && d.status === "paused");
    const okKind = kindFilter === "all" || d.kind === kindFilter;
    return okStatus && okKind;
  });

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-4 pt-4 pb-2 flex items-center justify-between shrink-0">
        <div>
          <h1 className="text-xl font-bold">التحميلات</h1>
          <p className="text-xs flex items-center gap-1.5 mt-0.5" style={{ color: "var(--jo-text-2)" }}>
            <Zap size={12} style={{ color: "var(--jo-accent-1)" }} />
            <span>
              {totalSpeed > 0
                ? `السرعة دلوقتي ${formatSpeedAr(totalSpeed)}`
                : `جاهز بـ ${settings.connections} اتصال متوازي`}
            </span>
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowControls(!showControls)}
          className={`jo-press w-9 h-9 rounded-2xl flex items-center justify-center ${
            showControls ? "jo-btn-primary" : "jo-btn-glass"
          }`}
          title="تظبيط الطابور"
        >
          <SlidersHorizontal size={16} />
        </button>
      </div>

      {/* Collapsible Queue, Speed Limiter & Scheduler panel */}
      {showControls && (
        <div className="mx-4 mb-2 jo-glass-elevated jo-reveal p-3.5 space-y-3 text-xs">
          <div className="flex items-center justify-between gap-2">
            <button type="button" onClick={onResumeAll} className="jo-press jo-btn-primary flex-1 py-2">
              كمّل الكل
            </button>
            <button type="button" onClick={onPauseAll} className="jo-press jo-btn-glass flex-1 py-2">
              وقّف الكل
            </button>
          </div>

          <div className="flex items-center justify-between">
            <span>حد السرعة: {settings.speedLimitMbps === 0 ? "مفتوحة للآخر" : `${settings.speedLimitMbps} ميجا/ث`}</span>
            <div className="flex gap-1.5">
              {[0, 5, 15, 30].map((v) => (
                <button
                  key={v}
                  type="button"
                  onClick={() => onUpdateSettings({ speedLimitMbps: v })}
                  className={`jo-press px-2.5 py-1 rounded-full ${
                    settings.speedLimitMbps === v ? "jo-btn-primary" : "jo-btn-glass"
                  }`}
                >
                  {v === 0 ? "أقصى" : v}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={() => onUpdateSettings({ wifiOnly: !settings.wifiOnly })}
              className={`jo-press px-3 py-1.5 rounded-full flex items-center gap-1.5 ${
                settings.wifiOnly ? "jo-btn-primary" : "jo-btn-glass"
              }`}
            >
              <Wifi size={13} />
              <span>واي فاي بس {settings.wifiOnly ? "✓" : ""}</span>
            </button>

            <label className="flex items-center gap-1.5 jo-btn-glass px-3 py-1.5 rounded-full">
              <Clock size={13} />
              <span>جدولة:</span>
              <input
                type="time"
                value={scheduleTime}
                onChange={(e) => setScheduleTime(e.target.value)}
                className="bg-transparent outline-none text-xs"
              />
            </label>
          </div>
        </div>
      )}

      {/* Status Tabs */}
      <div className="px-4 flex gap-2 overflow-x-auto no-scrollbar pb-2 shrink-0">
        {STATUS_TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setStatusFilter(t.id)}
            className={`jo-press px-3.5 py-1.5 rounded-full text-xs shrink-0 ${
              statusFilter === t.id ? "jo-btn-primary" : "jo-btn-glass"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Type Filter */}
      <div className="px-4 flex gap-1.5 overflow-x-auto no-scrollbar pb-2.5 shrink-0">
        {KIND_CHIPS.map((k) => (
          <button
            key={k.id}
            type="button"
            onClick={() => setKindFilter(k.id)}
            className="jo-press px-2.5 py-1 rounded-full text-[11px] shrink-0"
            style={{
              background: kindFilter === k.id ? "var(--jo-surface-elevated)" : "transparent",
              color: kindFilter === k.id ? "var(--jo-accent-1)" : "var(--jo-text-muted)",
            }}
          >
            {k.label}
          </button>
        ))}
      </div>

      {/* Downloads List */}
      <div className="flex-1 overflow-y-auto jo-scroll px-4 pb-28 space-y-3">
        {visible.length === 0 ? (
          <div className="jo-glass p-7 text-center space-y-1.5">
            <p className="text-sm font-semibold">القائمة فاضية</p>
            <p className="text-xs" style={{ color: "var(--jo-text-muted)" }}>
              أي ملف تحمّله من الرئيسية أو يوتيوب أو المتصفح هيظهر هنا بكل تفاصيله
            </p>
          </div>
        ) : (
          visible.map((item, idx) => {
            const pct = item.totalBytes > 0 ? Math.min(100, Math.round((item.downloadedBytes / item.totalBytes) * 100)) : 0;
            const remaining = Math.max(0, item.totalBytes - item.downloadedBytes);
            return (
              <div
                key={item.id}
                className={item.status === "running" ? "jo-glass-elevated p-3.5 space-y-2.5" : "jo-glass p-3.5 space-y-2.5"}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold text-sm truncate">{item.fileName}</div>
                    <button
                      type="button"
                      onClick={() => setExactId(exactId === item.id ? null : item.id)}
                      className="text-[11px] mt-0.5 text-right"
                      style={{ color: "var(--jo-text-2)" }}
                    >
                      {exactId === item.id
                        ? formatExactBytesAr(item.totalBytes, item.isExact)
                        : `${formatSizeAr(item.downloadedBytes, true)} من ${formatSizeAr(item.totalBytes, item.isExact)}`}
                    </button>
                  </div>
                  <span className="text-xs font-bold shrink-0" style={{ color: "var(--jo-accent-1)" }}>
                    {item.status === "merging" ? "دمج..." : `${pct}%`}
                  </span>
                </div>

                {/* Progress bar + parallel segments view */}
                <div className="space-y-1">
                  <div className="h-2 rounded-full overflow-hidden" style={{ background: "var(--jo-surface-elevated)" }}>
                    <div
                      className="h-full rounded-full jo-gradient-bar transition-all duration-300"
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  {item.status === "running" && item.segments.length > 0 && (
                    <div className="flex gap-0.5 h-1">
                      {item.segments.map((seg) => (
                        <div key={seg.id} className="flex-1 rounded-full bg-white/8 overflow-hidden">
                          <div
                            className="h-full rounded-full"
                            style={{
                              width: `${Math.round(seg.progress * 100)}%`,
                              background: seg.stolen ? "var(--jo-accent-3)" : "var(--jo-accent-1)",
                            }}
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Status line */}
                <div className="flex items-center justify-between text-[11px]" style={{ color: "var(--jo-text-muted)" }}>
                  <span>
                    {item.status === "running"
                      ? `${formatSpeedAr(item.speedBps)} • ${item.connections} اتصال`
                      : item.status === "merging"
                      ? "بندمج الصوت والفيديو بـ FFmpeg بدون فقد"
                      : item.status === "completed"
                      ? `خلص • ${item.ext.toUpperCase()} • ${item.codec}`
                      : item.status === "paused"
                      ? "متوقف مؤقتاً (محفوظ للاستكمال)"
                      : item.status === "failed"
                      ? "انقطع الاتصال — دوس كمّل"
                      : "مستني دوره في الطابور"}
                  </span>
                  {item.status === "running" && <span>{formatEtaAr(remaining, item.speedBps)}</span>}
                </div>

                {item.status === "running" && item.speedHistory.length > 2 && (
                  <SpeedSparklineSvg points={item.speedHistory} />
                )}

                {/* Smart compression saving tip when completed */}
                <div className="flex items-center justify-between gap-2 pt-0.5">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {item.status === "completed" ? (
                      <>
                        {(item.kind === "video" || item.kind === "audio") && (
                          <button
                            type="button"
                            onClick={() => onPlayDownloaded(item)}
                            className="jo-press jo-btn-primary px-3.5 py-1.5 text-xs flex items-center gap-1.5"
                          >
                            <Play size={13} />
                            <span>شغّل</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => onSendToCompressor(item)}
                          className="jo-press jo-btn-glass px-3 py-1.5 text-xs flex items-center gap-1 text-emerald-400"
                        >
                          <Minimize2 size={13} />
                          <span>وفّر {formatSizeAr(Math.round(item.totalBytes * 0.24), true)}</span>
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onTogglePause(item.id)}
                        className={`jo-press px-3.5 py-1.5 text-xs flex items-center gap-1.5 ${
                          item.status === "running" ? "jo-btn-glass" : "jo-btn-primary"
                        }`}
                      >
                        {item.status === "running" ? (
                          <>
                            <Pause size={13} />
                            <span>وقّف</span>
                          </>
                        ) : item.status === "failed" ? (
                          <>
                            <RotateCcw size={13} />
                            <span>إعادة</span>
                          </>
                        ) : (
                          <>
                            <Play size={13} />
                            <span>كمّل</span>
                          </>
                        )}
                      </button>
                    )}

                    {idx > 0 && item.status !== "completed" && (
                      <button
                        type="button"
                        onClick={() => onMoveTop(item.id)}
                        title="خلّيه الأول"
                        className="jo-press jo-btn-glass w-8 h-8 rounded-xl flex items-center justify-center"
                      >
                        <ArrowUp size={13} />
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => onCopyLink(item.sourceUrl)}
                      title="نسخ اللينك"
                      className="jo-press jo-btn-glass w-8 h-8 rounded-xl flex items-center justify-center"
                    >
                      <Copy size={13} />
                    </button>
                    <button
                      type="button"
                      onClick={() => onRemove(item.id)}
                      title="مسح"
                      className="jo-press jo-btn-glass w-8 h-8 rounded-xl flex items-center justify-center text-rose-400"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
