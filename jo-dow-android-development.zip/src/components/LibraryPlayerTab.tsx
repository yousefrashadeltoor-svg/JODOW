import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Bell,
  Disc3,
  Download,
  Edit3,
  Film,
  FolderPlus,
  Headphones,
  Heart,
  Lock,
  Moon,
  Music2,
  Pause,
  Play,
  Repeat,
  Repeat1,
  Scissors,
  Shuffle,
  SkipBack,
  SkipForward,
  Sliders,
  Sparkles,
  Unlock,
} from "lucide-react";
import { LocalMediaTrack } from "../types/app";
import { formatDuration, formatSizeAr } from "../data/catalog";
import { audioEngine, buildWaveformBars, exportTrimmedWavBlob } from "../utils/audioEngine";

export type RepeatKind = "off" | "all" | "one" | "ab";
type VizStyle = "bars" | "wave" | "orb";

interface LibraryPlayerTabProps {
  tracks: LocalMediaTrack[];
  activeTrack: LocalMediaTrack | null;
  isPlaying: boolean;
  positionSec: number;
  repeatMode: RepeatKind;
  shuffle: boolean;
  speed: number;
  bassBoost: boolean;
  sleepSec: number;
  vaultPin: string;
  activeRingtone: string;
  onSelectTrack: (track: LocalMediaTrack) => void;
  onTogglePlay: () => void;
  onSeek: (sec: number) => void;
  onNext: () => void;
  onPrev: () => void;
  onCycleRepeat: () => void;
  onToggleShuffle: () => void;
  onCycleSpeed: () => void;
  onToggleBass: () => void;
  onSetSleepTimer: (sec: number) => void;
  onUpdateTrack: (id: string, patch: Partial<LocalMediaTrack>) => void;
  onAddTrack: (track: LocalMediaTrack) => void;
  onSetRingtone: (name: string) => void;
  onSetAbLoop: (range: [number, number] | null) => void;
  onNotify: (msg: string) => void;
}

export const LibraryPlayerTab: React.FC<LibraryPlayerTabProps> = ({
  tracks,
  activeTrack,
  isPlaying,
  positionSec,
  repeatMode,
  shuffle,
  speed,
  bassBoost,
  sleepSec,
  vaultPin,
  activeRingtone,
  onSelectTrack,
  onTogglePlay,
  onSeek,
  onNext,
  onPrev,
  onCycleRepeat,
  onToggleShuffle,
  onCycleSpeed,
  onToggleBass,
  onSetSleepTimer,
  onUpdateTrack,
  onAddTrack,
  onSetRingtone,
  onSetAbLoop,
  onNotify,
}) => {
  const [section, setSection] = useState<"songs" | "albums" | "videos" | "clips" | "vault">("songs");
  const [playerExpanded, setPlayerExpanded] = useState(Boolean(activeTrack));
  const [audioOnlyMode, setAudioOnlyMode] = useState(true);
  const [vizStyle, setVizStyle] = useState<VizStyle>("bars");
  const [activeTool, setActiveTool] = useState<"none" | "trim" | "sleep" | "meta">("none");

  // Interactive manual visual waveform trim state (0..1 fractions)
  const [trimStart, setTrimStart] = useState(0.14);
  const [trimEnd, setTrimEnd] = useState(0.52);
  const [fadeRingtone, setFadeRingtone] = useState(true);
  const dragSideRef = useRef<"start" | "end" | null>(null);
  const waveBoxRef = useRef<HTMLDivElement>(null);

  // Live visualizer frames
  const [vizData, setVizData] = useState<number[]>(() => Array(32).fill(0.16));

  // Private Vault state
  const [vaultUnlocked, setVaultUnlocked] = useState(false);
  const [pinInput, setPinInput] = useState("");

  // Local device file picker + real video element
  const filePickerRef = useRef<HTMLInputElement>(null);
  const videoElRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (activeTrack) {
      setAudioOnlyMode(activeTrack.kind === "audio");
    }
  }, [activeTrack?.id]);

  // Sync real local video element if user opened a local MP4/WebM file
  useEffect(() => {
    const el = videoElRef.current;
    if (!el || !activeTrack?.objectUrl) return;
    el.playbackRate = speed;
    if (isPlaying) el.play().catch(() => {});
    else el.pause();
  }, [isPlaying, speed, activeTrack?.objectUrl, audioOnlyMode]);

  // Smooth live audio visualizer animation
  useEffect(() => {
    if (!playerExpanded || !isPlaying) return;
    const id = window.setInterval(() => {
      const live = audioEngine.readFrequencies(32);
      const hasSignal = live.some((v) => v > 0.14);
      if (hasSignal) {
        setVizData(live);
      } else {
        const now = Date.now() / 220;
        setVizData(
          Array.from({ length: 32 }, (_, i) =>
            Math.max(0.12, Math.min(0.95, 0.28 + 0.55 * Math.abs(Math.sin(now + i * 0.42))))
          )
        );
      }
    }, 65);
    return () => clearInterval(id);
  }, [playerExpanded, isPlaying]);

  // Update A-B loop when trim tool or AB repeat is active
  useEffect(() => {
    if (!activeTrack) return;
    if (activeTool === "trim" || repeatMode === "ab") {
      onSetAbLoop([trimStart * activeTrack.durationSec, trimEnd * activeTrack.durationSec]);
    } else {
      onSetAbLoop(null);
    }
  }, [activeTool, repeatMode, trimStart, trimEnd, activeTrack?.id]);

  const waveformBars = useMemo(
    () => buildWaveformBars(activeTrack?.toneSeed || 1, 64),
    [activeTrack?.toneSeed]
  );

  // Pointer drag handler for manual visual waveform trimming (zero number typing!)
  const updateHandleFromClientX = (clientX: number, side: "start" | "end") => {
    const box = waveBoxRef.current;
    if (!box || !activeTrack) return;
    const rect = box.getBoundingClientRect();
    // Waveform timeline flows left -> right visually for intuitive media scrubbing
    const frac = Math.max(0, Math.min(1, (clientX - rect.left) / Math.max(1, rect.width)));
    if (side === "start") {
      const clamped = Math.min(frac, trimEnd - 0.05);
      setTrimStart(clamped);
      onSeek(clamped * activeTrack.durationSec);
    } else {
      const clamped = Math.max(frac, trimStart + 0.05);
      setTrimEnd(clamped);
    }
  };

  const handleSaveManualClip = (downloadWav: boolean) => {
    if (!activeTrack) return;
    const sSec = Math.round(trimStart * activeTrack.durationSec);
    const eSec = Math.round(trimEnd * activeTrack.durationSec);
    const dur = Math.max(2, eSec - sSec);
    const wavBlob = exportTrimmedWavBlob(activeTrack.toneSeed, dur, fadeRingtone);
    const wavUrl = URL.createObjectURL(wavBlob);

    const newClip: LocalMediaTrack = {
      id: `clip_${Date.now()}`,
      title: `${activeTrack.title} (مقصوص)`,
      artist: activeTrack.artist,
      album: "المقاطع المقصوصة",
      kind: "audio",
      durationSec: dur,
      sizeBytes: wavBlob.size,
      ext: "WAV",
      coverImage: activeTrack.coverImage,
      accent: activeTrack.accent,
      toneSeed: activeTrack.toneSeed,
      objectUrl: wavUrl,
      isTrimmed: true,
    };
    onAddTrack(newClip);

    if (downloadWav) {
      const a = document.createElement("a");
      a.href = wavUrl;
      a.download = `${activeTrack.title.slice(0, 24)}_cut_${sSec}s_${eSec}s.wav`;
      a.click();
    }
    onNotify(`اتقص المقطع (${formatDuration(dur)}) واتحفظ في مكتبتك!`);
  };

  const handleMakeRingtone = (alsoDownload = false) => {
    if (!activeTrack) return;
    const sSec = Math.round(trimStart * activeTrack.durationSec);
    const eSec = Math.min(sSec + 30, Math.round(trimEnd * activeTrack.durationSec));
    const dur = Math.max(3, eSec - sSec);
    const ringLabel = `${activeTrack.title} (${formatDuration(sSec)}–${formatDuration(eSec)})`;
    const blob = exportTrimmedWavBlob(activeTrack.toneSeed, dur, fadeRingtone);
    const url = URL.createObjectURL(blob);

    onSetRingtone(ringLabel);
    onAddTrack({
      id: `ring_${Date.now()}`,
      title: `نغمة: ${activeTrack.title}`,
      artist: activeTrack.artist,
      album: "نغماتي",
      kind: "audio",
      durationSec: dur,
      sizeBytes: blob.size,
      ext: "M4R/WAV",
      coverImage: activeTrack.coverImage,
      accent: activeTrack.accent,
      toneSeed: activeTrack.toneSeed,
      objectUrl: url,
      isRingtone: true,
      isTrimmed: true,
    });

    if (alsoDownload) {
      const a = document.createElement("a");
      a.href = url;
      a.download = `${activeTrack.title.slice(0, 22)}_ringtone.wav`;
      a.click();
    }
    onNotify("اتظبطت نغمة رنين بنجاح بتلاشي صوتي ناعم!");
  };

  // Real offline import of local video/audio files from user's device
  const handleLocalFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    const isVideo = file.type.startsWith("video/") || /\.(mp4|mkv|webm|mov)$/i.test(file.name);
    const ext = file.name.split(".").pop()?.toUpperCase() || (isVideo ? "MP4" : "MP3");
    const cleanTitle = file.name.replace(/\.[^.]+$/, "");

    const probeEl = document.createElement(isVideo ? "video" : "audio");
    probeEl.preload = "metadata";
    probeEl.src = url;
    probeEl.onloadedmetadata = () => {
      const dur = Number.isFinite(probeEl.duration) && probeEl.duration > 0 ? Math.round(probeEl.duration) : 180;
      const track: LocalMediaTrack = {
        id: `user_${Date.now()}`,
        title: cleanTitle,
        artist: "ملف من جهازك",
        album: isVideo ? "فيديوهاتي" : "موسيقتي",
        kind: isVideo ? "video" : "audio",
        durationSec: dur,
        sizeBytes: file.size,
        ext,
        coverImage: isVideo ? "/images/themes/theme_neon.jpg" : "/images/themes/theme_aurora.jpg",
        accent: "#4285F4",
        toneSeed: 3,
        objectUrl: url,
      };
      onAddTrack(track);
      onSelectTrack(track);
      setPlayerExpanded(true);
      onNotify("الملف اشتغل من جهازك مباشرة بدون إنترنت");
    };
    e.target.value = "";
  };

  const albums = useMemo(() => {
    const map = new Map<string, LocalMediaTrack[]>();
    tracks
      .filter((t) => !t.inVault && t.kind === "audio")
      .forEach((t) => {
        map.set(t.album, [...(map.get(t.album) || []), t]);
      });
    return Array.from(map.entries());
  }, [tracks]);

  const filteredList = useMemo(() => {
    if (section === "vault") return tracks.filter((t) => t.inVault);
    const pub = tracks.filter((t) => !t.inVault);
    if (section === "videos") return pub.filter((t) => t.kind === "video");
    if (section === "clips") return pub.filter((t) => t.isTrimmed || t.isRingtone);
    return pub.filter((t) => t.kind === "audio");
  }, [tracks, section]);

  const startSec = activeTrack ? Math.round(trimStart * activeTrack.durationSec) : 0;
  const endSec = activeTrack ? Math.round(trimEnd * activeTrack.durationSec) : 0;

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header + Import Local File + Switch Player/Library */}
      <div className="px-4 pt-4 pb-2 flex items-center justify-between gap-2 shrink-0">
        <div>
          <h1 className="text-xl font-bold">{playerExpanded && activeTrack ? "المشغل" : "موسيقتي وملفاتي"}</h1>
          {activeRingtone && !playerExpanded && (
            <p className="text-[11px] truncate max-w-[210px]" style={{ color: "var(--jo-text-muted)" }}>
              النغمة الحالية: {activeRingtone}
            </p>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => filePickerRef.current?.click()}
            className="jo-press jo-btn-glass px-3 py-1.5 text-xs rounded-full flex items-center gap-1.5"
          >
            <FolderPlus size={14} />
            <span>افتح ملف</span>
          </button>
          <input
            ref={filePickerRef}
            type="file"
            accept="audio/*,video/*"
            onChange={handleLocalFileImport}
            className="hidden"
          />

          {activeTrack && (
            <button
              type="button"
              onClick={() => setPlayerExpanded(!playerExpanded)}
              className="jo-press jo-btn-primary px-3 py-1.5 text-xs rounded-full"
            >
              {playerExpanded ? "المكتبة" : "المشغل"}
            </button>
          )}
        </div>
      </div>

      {/* ==================== FLAGSHIP LOCAL MUSIC & VIDEO PLAYER ==================== */}
      {playerExpanded && activeTrack ? (
        <div className="flex-1 overflow-y-auto jo-scroll px-4 pb-28 space-y-3.5 jo-reveal">
          {/* Visual Stage: Video Mode OR Real-Time Audio Visualizer */}
          <div className="relative h-52 rounded-[28px] overflow-hidden border" style={{ borderColor: "var(--jo-border-strong)" }}>
            {activeTrack.kind === "video" && !audioOnlyMode && activeTrack.objectUrl ? (
              <video
                ref={videoElRef}
                src={activeTrack.objectUrl}
                className="w-full h-full object-cover bg-black"
                playsInline
                onTimeUpdate={(e) => onSeek(e.currentTarget.currentTime)}
              />
            ) : (
              <>
                <img
                  src={activeTrack.coverImage}
                  alt={activeTrack.title}
                  className={`w-full h-full object-cover transition-all duration-500 ${
                    audioOnlyMode ? "brightness-45 scale-105" : "brightness-85"
                  }`}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-black/20" />

                {/* 3 Live Audio Visualizer Modes */}
                {audioOnlyMode && (
                  <div className="absolute inset-0 flex items-center justify-center px-6">
                    {vizStyle === "bars" && (
                      <div className="w-full h-28 flex items-center justify-between gap-1">
                        {vizData.map((v, i) => (
                          <span
                            key={i}
                            className="flex-1 rounded-full transition-all duration-75"
                            style={{
                              height: `${Math.max(12, Math.round(v * 100))}%`,
                              background: "linear-gradient(180deg, var(--jo-accent-1), var(--jo-accent-2), var(--jo-accent-3))",
                              opacity: 0.9,
                            }}
                          />
                        ))}
                      </div>
                    )}

                    {vizStyle === "wave" && (
                      <svg viewBox="0 0 320 100" className="w-full h-28">
                        <polyline
                          fill="none"
                          stroke="var(--jo-accent-1)"
                          strokeWidth="3"
                          strokeLinecap="round"
                          points={vizData
                            .map((v, i) => `${(i / (vizData.length - 1)) * 320},${50 + (i % 2 === 0 ? -1 : 1) * v * 40}`)
                            .join(" ")}
                        />
                      </svg>
                    )}

                    {vizStyle === "orb" && (
                      <div
                        className="w-24 h-24 rounded-full flex items-center justify-center transition-transform duration-100"
                        style={{
                          transform: `scale(${1 + (vizData[4] || 0.2) * 0.38})`,
                          background: "radial-gradient(circle, var(--jo-accent-1), var(--jo-accent-2), transparent 72%)",
                          boxShadow: "0 0 45px var(--jo-accent-1)",
                        }}
                      >
                        <Disc3 size={34} className={`text-white ${isPlaying ? "animate-spin" : ""}`} />
                      </div>
                    )}
                  </div>
                )}
              </>
            )}

            {/* Top floating pills: Switch Video/Song + Cycle Visualizer Style */}
            <div className="absolute top-3 inset-x-3 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setAudioOnlyMode(!audioOnlyMode)}
                className="jo-press px-3 py-1 rounded-full text-[11px] font-medium bg-black/55 text-white backdrop-blur-md flex items-center gap-1.5"
              >
                {audioOnlyMode ? <Film size={12} /> : <Headphones size={12} />}
                <span>{audioOnlyMode ? "عرض كفيديو" : "شغّل كأغنية"}</span>
              </button>

              {audioOnlyMode && (
                <button
                  type="button"
                  onClick={() => {
                    const order: VizStyle[] = ["bars", "wave", "orb"];
                    setVizStyle(order[(order.indexOf(vizStyle) + 1) % order.length]);
                  }}
                  className="jo-press px-3 py-1 rounded-full text-[11px] bg-black/55 text-white backdrop-blur-md flex items-center gap-1"
                >
                  <Sparkles size={12} />
                  <span>شكل المؤثر</span>
                </button>
              )}
            </div>

            {sleepSec > 0 && (
              <div className="absolute bottom-2.5 right-3 px-2.5 py-0.5 rounded-full bg-black/65 text-amber-300 text-[10px] flex items-center gap-1">
                <Moon size={11} />
                <span>هينام بعد {formatDuration(sleepSec)}</span>
              </div>
            )}
          </div>

          {/* Track Title + Favorite + Edit Info */}
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0 flex-1">
              <h2 className="font-bold text-base truncate">{activeTrack.title}</h2>
              <p className="text-xs truncate" style={{ color: "var(--jo-text-2)" }}>
                {activeTrack.artist} • {activeTrack.album} • {activeTrack.ext}
              </p>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() => onUpdateTrack(activeTrack.id, { isFavorite: !activeTrack.isFavorite })}
                className={`jo-press w-9 h-9 rounded-2xl flex items-center justify-center ${
                  activeTrack.isFavorite ? "bg-rose-500/20 text-rose-400" : "jo-btn-glass"
                }`}
              >
                <Heart size={16} fill={activeTrack.isFavorite ? "currentColor" : "none"} />
              </button>
              <button
                type="button"
                onClick={() => setActiveTool(activeTool === "meta" ? "none" : "meta")}
                className="jo-press jo-btn-glass w-9 h-9 rounded-2xl flex items-center justify-center"
                title="تعديل بيانات الأغنية"
              >
                <Edit3 size={15} />
              </button>
            </div>
          </div>

          {/* Seek Bar */}
          <div className="space-y-1" dir="ltr">
            <input
              type="range"
              min={0}
              max={Math.max(1, activeTrack.durationSec)}
              value={Math.min(activeTrack.durationSec, positionSec)}
              onChange={(e) => onSeek(Number(e.target.value))}
              className="jo-range w-full"
            />
            <div className="flex justify-between text-[11px]" style={{ color: "var(--jo-text-muted)" }}>
              <span>{formatDuration(positionSec)}</span>
              <span>{formatDuration(activeTrack.durationSec)}</span>
            </div>
          </div>

          {/* Main Transport Controls: Shuffle, Prev, Play/Pause, Next, Repeat (Off/All/One/A-B) */}
          <div className="flex items-center justify-between px-2" dir="ltr">
            <button
              type="button"
              onClick={onToggleShuffle}
              className={`jo-press w-10 h-10 rounded-full flex items-center justify-center ${
                shuffle ? "jo-btn-primary" : "jo-btn-glass"
              }`}
              title="عشوائي"
            >
              <Shuffle size={16} />
            </button>

            <button
              type="button"
              onClick={onPrev}
              className="jo-press jo-btn-glass w-11 h-11 rounded-full flex items-center justify-center"
            >
              <SkipBack size={18} />
            </button>

            <button
              type="button"
              onClick={onTogglePlay}
              className="jo-press jo-btn-primary w-15 h-15 rounded-full flex items-center justify-center shadow-lg"
            >
              {isPlaying ? <Pause size={24} /> : <Play size={24} className="ml-0.5" />}
            </button>

            <button
              type="button"
              onClick={onNext}
              className="jo-press jo-btn-glass w-11 h-11 rounded-full flex items-center justify-center"
            >
              <SkipForward size={18} />
            </button>

            <button
              type="button"
              onClick={onCycleRepeat}
              className={`jo-press px-2.5 h-10 rounded-full flex items-center justify-center gap-1 text-[11px] font-bold ${
                repeatMode !== "off" ? "jo-btn-primary" : "jo-btn-glass"
              }`}
              title="التكرار"
            >
              {repeatMode === "one" ? <Repeat1 size={16} /> : <Repeat size={16} />}
              {repeatMode === "ab" && <span>A-B</span>}
            </button>
          </div>

          {/* Advanced Studio Action Chips: Manual Visual Trim, Set Ringtone, Sleep Timer, Bass Boost, Speed */}
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setActiveTool(activeTool === "trim" ? "none" : "trim")}
              className={`jo-press py-2.5 px-3 text-xs flex items-center justify-center gap-1.5 ${
                activeTool === "trim" ? "jo-btn-primary" : "jo-btn-glass"
              }`}
            >
              <Scissors size={14} />
              <span>قص يدوي ونغمة</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTool(activeTool === "sleep" ? "none" : "sleep")}
              className={`jo-press py-2.5 px-3 text-xs flex items-center justify-center gap-1.5 ${
                activeTool === "sleep" || sleepSec > 0 ? "jo-btn-primary" : "jo-btn-glass"
              }`}
            >
              <Moon size={14} />
              <span>{sleepSec > 0 ? `مؤقت: ${formatDuration(sleepSec)}` : "مؤقت النوم"}</span>
            </button>

            <button
              type="button"
              onClick={onToggleBass}
              className={`jo-press py-2 px-3 text-xs flex items-center justify-center gap-1.5 ${
                bassBoost ? "jo-btn-primary" : "jo-btn-glass"
              }`}
            >
              <Sliders size={14} />
              <span>{bassBoost ? "بيز عميق شغّال ✓" : "بيز عميق (Bass)"}</span>
            </button>

            <button
              type="button"
              onClick={onCycleSpeed}
              className="jo-press jo-btn-glass py-2 px-3 text-xs flex items-center justify-center gap-1.5"
            >
              <span>سرعة التشغيل: {speed}x</span>
            </button>
          </div>

          {/* INTERACTIVE DRAGGABLE VISUAL WAVEFORM TRIMMER & RINGTONE STUDIO */}
          {activeTool === "trim" && (
            <div className="jo-glass-elevated jo-reveal p-3.5 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold">اسحب المقبضين بإيدك لقص المقطع</span>
                <span className="font-semibold" style={{ color: "var(--jo-accent-1)" }}>
                  {formatDuration(startSec)} ← {formatDuration(endSec)} ({formatDuration(Math.max(1, endSec - startSec))})
                </span>
              </div>

              {/* Visual Draggable Waveform Canvas */}
              <div
                ref={waveBoxRef}
                dir="ltr"
                onPointerMove={(e) => {
                  if (dragSideRef.current) updateHandleFromClientX(e.clientX, dragSideRef.current);
                }}
                onPointerUp={() => {
                  dragSideRef.current = null;
                }}
                onPointerLeave={() => {
                  dragSideRef.current = null;
                }}
                className="relative h-20 rounded-2xl px-2 flex items-center select-none touch-none overflow-hidden border"
                style={{ background: "var(--jo-surface)", borderColor: "var(--jo-border)" }}
              >
                {/* Highlighted selection window */}
                <div
                  className="absolute top-0 bottom-0 pointer-events-none"
                  style={{
                    left: `${trimStart * 100}%`,
                    width: `${(trimEnd - trimStart) * 100}%`,
                    background: "color-mix(in srgb, var(--jo-accent-1) 18%, transparent)",
                  }}
                />

                {/* Waveform bars */}
                <div className="w-full h-14 flex items-center justify-between gap-[2px] pointer-events-none">
                  {waveformBars.map((amp, idx) => {
                    const f = idx / waveformBars.length;
                    const inside = f >= trimStart && f <= trimEnd;
                    return (
                      <span
                        key={idx}
                        className="flex-1 rounded-full"
                        style={{
                          height: `${Math.round(amp * 100)}%`,
                          background: inside ? "var(--jo-accent-1)" : "rgba(148,163,184,0.26)",
                        }}
                      />
                    );
                  })}
                </div>

                {/* Live playhead */}
                <div
                  className="absolute top-1 bottom-1 w-0.5 bg-white pointer-events-none"
                  style={{ left: `${Math.min(100, (positionSec / Math.max(1, activeTrack.durationSec)) * 100)}%` }}
                />

                {/* Left Draggable Start Handle */}
                <div
                  onPointerDown={(e) => {
                    e.currentTarget.setPointerCapture(e.pointerId);
                    dragSideRef.current = "start";
                  }}
                  style={{ left: `calc(${trimStart * 100}% - 10px)` }}
                  className="absolute top-0 bottom-0 w-5 cursor-ew-resize flex items-center justify-center z-10"
                >
                  <span className="w-2 h-14 rounded-full bg-white shadow-md border border-black/30" />
                </div>

                {/* Right Draggable End Handle */}
                <div
                  onPointerDown={(e) => {
                    e.currentTarget.setPointerCapture(e.pointerId);
                    dragSideRef.current = "end";
                  }}
                  style={{ left: `calc(${trimEnd * 100}% - 10px)` }}
                  className="absolute top-0 bottom-0 w-5 cursor-ew-resize flex items-center justify-center z-10"
                >
                  <span className="w-2 h-14 rounded-full bg-white shadow-md border border-black/30" />
                </div>
              </div>

              <button
                type="button"
                onClick={() => setFadeRingtone(!fadeRingtone)}
                className="text-xs flex items-center gap-1.5"
                style={{ color: "var(--jo-text-2)" }}
              >
                <span>{fadeRingtone ? "✓" : "○"}</span>
                <span>دخول وخروج صوتي ناعم (Fade)</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleSaveManualClip(false)}
                  className="jo-press jo-btn-primary py-2 text-xs flex items-center justify-center gap-1.5"
                >
                  <Scissors size={13} />
                  <span>احفظ المقطع</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleMakeRingtone(false)}
                  className="jo-press jo-btn-glass py-2 text-xs flex items-center justify-center gap-1.5"
                >
                  <Bell size={13} />
                  <span>خلّيها نغمة رنين</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => handleMakeRingtone(true)}
                className="jo-press jo-btn-glass w-full py-2 text-xs flex items-center justify-center gap-1.5"
              >
                <Download size={13} />
                <span>نزّل النغمة المقصوصة كملف صوتي جاهز</span>
              </button>
            </div>
          )}

          {/* SLEEP TIMER PANEL */}
          {activeTool === "sleep" && (
            <div className="jo-glass-elevated jo-reveal p-3.5 space-y-2.5">
              <div className="text-xs font-bold">مؤقت النوم (الصوت بيوطى بهدوء ويقفل لوحده)</div>
              <div className="flex flex-wrap gap-2">
                {[
                  { label: "إيقاف", sec: 0 },
                  { label: "5 دقايق", sec: 300 },
                  { label: "15 دقيقة", sec: 900 },
                  { label: "30 دقيقة", sec: 1800 },
                  { label: "ساعة", sec: 3600 },
                  {
                    label: "آخر الأغنية",
                    sec: Math.max(5, Math.round(activeTrack.durationSec - positionSec)),
                  },
                ].map((opt) => (
                  <button
                    key={opt.label}
                    type="button"
                    onClick={() => {
                      onSetSleepTimer(opt.sec);
                      if (opt.sec > 0) onNotify(`اتظبط مؤقت النوم على ${opt.label}`);
                    }}
                    className="jo-press jo-btn-glass px-3 py-1.5 rounded-full text-xs"
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* METADATA EDITOR */}
          {activeTool === "meta" && (
            <div className="jo-glass-elevated jo-reveal p-3.5 space-y-2">
              <div className="text-xs font-bold">تعديل اسم الأغنية والفنان</div>
              <input
                type="text"
                value={activeTrack.title}
                onChange={(e) => onUpdateTrack(activeTrack.id, { title: e.target.value })}
                className="w-full rounded-xl px-3 py-2 text-xs outline-none border"
                style={{ background: "var(--jo-surface)", borderColor: "var(--jo-border)", color: "var(--jo-text)" }}
              />
              <input
                type="text"
                value={activeTrack.artist}
                onChange={(e) => onUpdateTrack(activeTrack.id, { artist: e.target.value })}
                className="w-full rounded-xl px-3 py-2 text-xs outline-none border"
                style={{ background: "var(--jo-surface)", borderColor: "var(--jo-border)", color: "var(--jo-text)" }}
              />
            </div>
          )}
        </div>
      ) : (
        /* ==================== LOCAL MUSIC & VIDEO LIBRARY + PRIVATE VAULT ==================== */
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="px-4 flex gap-2 overflow-x-auto no-scrollbar pb-2.5 shrink-0">
            {[
              { id: "songs", label: "أغاني" },
              { id: "albums", label: "ألبومات" },
              { id: "videos", label: "فيديوهات" },
              { id: "clips", label: "نغمات ومقصوص" },
              { id: "vault", label: "الخزنة السرية" },
            ].map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setSection(t.id as typeof section)}
                className={`jo-press px-3.5 py-1.5 rounded-full text-xs shrink-0 ${
                  section === t.id ? "jo-btn-primary" : "jo-btn-glass"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto jo-scroll px-4 pb-28 space-y-2.5">
            {section === "vault" && !vaultUnlocked ? (
              <div className="jo-glass-elevated p-5 text-center space-y-3">
                <Lock size={26} className="mx-auto" style={{ color: "var(--jo-accent-1)" }} />
                <div className="font-bold text-sm">الخزنة السرية المشفرة</div>
                <p className="text-xs" style={{ color: "var(--jo-text-muted)" }}>
                  اكتب الرقم السري (الافتراضي {vaultPin}) لفتح ملفاتك الخاصة
                </p>
                <input
                  type="password"
                  maxLength={6}
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="••••"
                  className="w-36 mx-auto block text-center tracking-widest rounded-2xl px-3 py-2 text-sm outline-none border"
                  style={{ background: "var(--jo-surface)", borderColor: "var(--jo-border-strong)", color: "var(--jo-text)" }}
                />
                <button
                  type="button"
                  onClick={() => {
                    if (pinInput === vaultPin) {
                      setVaultUnlocked(true);
                      setPinInput("");
                    } else onNotify("الرقم السري غلط");
                  }}
                  className="jo-press jo-btn-primary px-6 py-2 text-xs"
                >
                  افتح الخزنة
                </button>
              </div>
            ) : section === "albums" ? (
              <div className="grid grid-cols-2 gap-2.5">
                {albums.map(([albumName, list]) => (
                  <button
                    key={albumName}
                    type="button"
                    onClick={() => {
                      onSelectTrack(list[0]);
                      setPlayerExpanded(true);
                    }}
                    className="jo-glass jo-press p-3 text-right space-y-2"
                  >
                    <img src={list[0].coverImage} alt={albumName} className="w-full h-24 rounded-2xl object-cover" />
                    <div className="font-semibold text-xs truncate">{albumName}</div>
                    <div className="text-[11px]" style={{ color: "var(--jo-text-muted)" }}>
                      {list.length} أغاني
                    </div>
                  </button>
                ))}
              </div>
            ) : filteredList.length === 0 ? (
              <div className="jo-glass p-6 text-center text-xs" style={{ color: "var(--jo-text-muted)" }}>
                مفيش ملفات في القسم ده لسه
              </div>
            ) : (
              filteredList.map((track) => {
                const current = activeTrack?.id === track.id;
                return (
                  <div
                    key={track.id}
                    className={`${current ? "jo-glass-elevated" : "jo-glass"} p-3 flex items-center gap-3`}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        onSelectTrack(track);
                        setPlayerExpanded(true);
                      }}
                      className="relative w-12 h-12 rounded-2xl overflow-hidden shrink-0"
                    >
                      <img src={track.coverImage} alt={track.title} className="w-full h-full object-cover" />
                      <span className="absolute inset-0 bg-black/35 flex items-center justify-center text-white">
                        {track.kind === "video" ? <Film size={16} /> : <Music2 size={16} />}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onSelectTrack(track);
                        setPlayerExpanded(true);
                      }}
                      className="flex-1 min-w-0 text-right"
                    >
                      <div className="font-semibold text-sm truncate">{track.title}</div>
                      <div className="text-[11px] mt-0.5" style={{ color: "var(--jo-text-muted)" }}>
                        {track.artist} • {formatDuration(track.durationSec)} • {formatSizeAr(track.sizeBytes, true)}
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onUpdateTrack(track.id, { inVault: !track.inVault });
                        onNotify(track.inVault ? "رجع للمكتبة العادية" : "اتنقل للخزنة السرية");
                      }}
                      title={track.inVault ? "طلع من الخزنة" : "انقل للخزنة السرية"}
                      className="jo-press jo-btn-glass w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                    >
                      {track.inVault ? <Unlock size={13} /> : <Lock size={13} />}
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
