/**
 * Offline Web Audio Engine for JO DON:
 * - Synthesizes warm, musical harmonic melodies offline so every built-in track/video actually plays crisp sound.
 * - Supports real Bass Boost (BiquadFilter lowshelf) and real-time AnalyserNode data for the 60fps visualizer.
 * - Exports real playable WAV files for the Visual Manual Trimmer and Ringtone Creator!
 */

const SCALES: number[][] = [
  [220.0, 246.94, 277.18, 329.63, 369.99, 440.0], // Warm A major pentatonic
  [196.0, 233.08, 261.63, 293.66, 349.23, 392.0], // G minor chill
  [220.0, 233.08, 277.18, 293.66, 329.63, 349.23, 440.0], // Hijaz Oriental (Cairo Night!)
  [174.61, 220.0, 261.63, 329.63, 392.0, 440.0], // Deep Ocean Fmaj7
  [261.63, 293.66, 329.63, 392.0, 440.0, 523.25], // Calm Emerald C
];

class JoOfflineAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private bassFilter: BiquadFilterNode | null = null;
  public analyser: AnalyserNode | null = null;
  private noteTimer: number | null = null;
  private step = 0;
  private speed = 1;
  private activeSeed = 1;
  private isSynthRunning = false;

  private ensureContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.bassFilter = this.ctx.createBiquadFilter();
      this.bassFilter.type = "lowshelf";
      this.bassFilter.frequency.value = 150;
      this.bassFilter.gain.value = 0;

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 0.22;

      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 128;
      this.analyser.smoothingTimeConstant = 0.82;

      this.bassFilter.connect(this.masterGain);
      this.masterGain.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  startSynth(seed: number, playbackSpeed = 1) {
    this.stopSynth();
    const ctx = this.ensureContext();
    this.activeSeed = seed;
    this.speed = playbackSpeed;
    this.isSynthRunning = true;

    const triggerNote = () => {
      if (!this.isSynthRunning || !this.ctx || !this.bassFilter) return;
      const scale = SCALES[Math.abs(this.activeSeed) % SCALES.length];
      const freq = scale[(this.step * 2 + (this.step % 3)) % scale.length];
      const now = ctx.currentTime;

      const osc = ctx.createOscillator();
      const sub = ctx.createOscillator();
      const env = ctx.createGain();

      osc.type = "triangle";
      osc.frequency.setValueAtTime(freq, now);
      sub.type = "sine";
      sub.frequency.setValueAtTime(freq * 0.5, now);

      env.gain.setValueAtTime(0.0001, now);
      env.gain.exponentialRampToValueAtTime(0.32, now + 0.06);
      env.gain.exponentialRampToValueAtTime(0.0008, now + 1.15 / Math.max(0.5, this.speed));

      osc.connect(env);
      sub.connect(env);
      env.connect(this.bassFilter);

      osc.start(now);
      sub.start(now);
      const stopAt = now + 1.2 / Math.max(0.5, this.speed);
      osc.stop(stopAt);
      sub.stop(stopAt);

      this.step++;
      this.noteTimer = window.setTimeout(triggerNote, Math.max(240, 620 / Math.max(0.5, this.speed)));
    };

    triggerNote();
  }

  stopSynth() {
    this.isSynthRunning = false;
    if (this.noteTimer !== null) {
      clearTimeout(this.noteTimer);
      this.noteTimer = null;
    }
  }

  setBassBoost(db: number) {
    if (this.bassFilter && this.ctx) {
      this.bassFilter.gain.setTargetAtTime(db, this.ctx.currentTime, 0.05);
    }
  }

  setVolume(vol: number) {
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(Math.max(0, Math.min(1, vol)) * 0.3, this.ctx.currentTime, 0.08);
    }
  }

  setSpeed(speed: number) {
    this.speed = speed;
  }

  readFrequencies(count = 36): number[] {
    if (!this.analyser) return Array(count).fill(0.1);
    const data = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(data);
    const out: number[] = [];
    for (let i = 0; i < count; i++) {
      const idx = Math.floor((i / count) * (data.length * 0.72));
      out.push(Math.max(0.08, data[idx] / 255));
    }
    return out;
  }
}

export const audioEngine = new JoOfflineAudioEngine();

/** Deterministic rich waveform bars for interactive manual scrubbing. */
export function buildWaveformBars(seed: number, count = 68): number[] {
  const out: number[] = [];
  for (let i = 0; i < count; i++) {
    const a = Math.abs(Math.sin(i * 0.31 + seed * 1.7));
    const b = Math.abs(Math.cos(i * 0.13 - seed * 0.9));
    const edge = i < 4 || i > count - 5 ? 0.45 : 1;
    out.push(Math.max(0.14, Math.min(0.98, (0.22 + a * 0.52 + b * 0.28) * edge)));
  }
  return out;
}

/** Exports a genuine playable 16-bit PCM WAV clip for any manually trimmed range or ringtone (with optional fade). */
export function exportTrimmedWavBlob(seed: number, durationSec: number, fadeInOut = true): Blob {
  const sampleRate = 22050;
  const clampedDur = Math.max(2, Math.min(30, Math.round(durationSec)));
  const totalSamples = sampleRate * clampedDur;
  const buffer = new ArrayBuffer(44 + totalSamples * 2);
  const view = new DataView(buffer);

  const writeStr = (offset: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(offset + i, s.charCodeAt(i));
  };

  writeStr(0, "RIFF");
  view.setUint32(4, 36 + totalSamples * 2, true);
  writeStr(8, "WAVE");
  writeStr(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(36, "data");
  view.setUint32(40, totalSamples * 2, true);

  const scale = SCALES[Math.abs(seed) % SCALES.length];
  for (let i = 0; i < totalSamples; i++) {
    const t = i / sampleRate;
    const noteIdx = Math.floor(t * 2) % scale.length;
    const notePos = (t * 2) % 1;
    const freq = scale[noteIdx];
    const env = Math.exp(-notePos * 3.2);
    let fade = 1;
    if (fadeInOut) {
      if (t < 0.8) fade = t / 0.8;
      else if (t > clampedDur - 1.2) fade = Math.max(0, (clampedDur - t) / 1.2);
    }
    const sample = (Math.sin(2 * Math.PI * freq * t) * 0.65 + Math.sin(Math.PI * freq * t) * 0.35) * env * fade * 0.45;
    view.setInt16(44 + i * 2, Math.max(-32767, Math.min(32767, sample * 32767)), true);
  }
  return new Blob([buffer], { type: "audio/wav" });
}
