import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Download,
  FolderGit2,
  Home,
  Maximize2,
  Music2,
  Pause,
  Play,
  Settings,
  Sliders,
  Smartphone,
  X,
} from "lucide-react";
import {
  AnalyzedLink,
  AppSettings,
  AppTab,
  DownloadTask,
  LocalMediaTrack,
  LocalProfile,
  MediaKind,
  MediaOption,
  YouTubeItem,
} from "./types/app";
import { buildAnalysisForUrl, INITIAL_LOCAL_TRACKS, JO_THEMES } from "./data/catalog";
import { audioEngine } from "./utils/audioEngine";
import { AndroidProjectModal, QualityBottomSheet, YouTubeLogoIcon } from "./components/SharedUI";
import { HomeTab } from "./components/HomeTab";
import { YouTubeTab } from "./components/YouTubeTab";
import { DownloadsTab } from "./components/DownloadsTab";
import { LibraryPlayerTab, RepeatKind } from "./components/LibraryPlayerTab";
import { ToolsBrowserTab } from "./components/ToolsBrowserTab";
import { SettingsTab } from "./components/SettingsTab";

const DEFAULT_SETTINGS: AppSettings = {
  themeId: "aurora",
  darkMode: true,
  blurScale: 1,
  motionPreset: "spring",
  connections: 16,
  maxConcurrent: 3,
  speedLimitMbps: 0,
  wifiOnly: false,
  enableDoh: true,
  clipboardWatch: true,
  adBlockEnabled: true,
  adBlockWhitelist: [],
  activeRingtoneName: "",
  vaultPin: "1234",
  savedByCompressorBytes: 38_420_100,
};

const DEFAULT_PROFILE: LocalProfile = {
  displayName: "يوسف المصري",
  handle: "@jodon_local",
  bio: "حسابي المحلي على موبايلي — اشتراكاتي واقتراحاتي من غير تسجيل دخول",
  avatarColor: "#4285F4",
  subscribedIds: ["ch_tech", "ch_mazika"],
  likedIds: ["yt_1", "yt_3"],
  savedIds: ["yt_2"],
  watchHistoryIds: ["yt_1", "yt_3"],
  searchHistory: ["موسيقى ليل القاهرة", "الشفق القطبي 4K"],
  categoryWeights: { تقنية: 4, موسيقى: 4, وثائقي: 3 },
};

const INITIAL_DOWNLOADS: DownloadTask[] = [
  {
    id: "dl_init_1",
    title: "رحلة الشفق القطبي 4K HDR",
    fileName: "رحلة_الشفق_القطبي_1080p60.mp4",
    sourceUrl: "https://youtu.be/aurora_4k_hdr_eg",
    kind: "video",
    ext: "mp4",
    codec: "AVC H.264",
    totalBytes: 148_372_910,
    isExact: true,
    downloadedBytes: 148_372_910,
    speedBps: 0,
    speedHistory: [],
    connections: 0,
    segments: [],
    dashMerge: true,
    status: "completed",
    wifiOnly: false,
    createdAt: Date.now() - 120_000,
  },
];

function readLocal<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? { ...fallback, ...JSON.parse(raw) } : fallback;
  } catch {
    return fallback;
  }
}

function readLocalArray<T>(key: string, fallback: T[]): T[] {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}

export function App() {
  const [tab, setTab] = useState<AppTab>("home");
  const [phoneFrame, setPhoneFrame] = useState(true);
  const [showAndroidModal, setShowAndroidModal] = useState(false);

  // Persisted offline state
  const [settings, setSettings] = useState<AppSettings>(() => readLocal("jodon_settings_v2", DEFAULT_SETTINGS));
  const [profile, setProfile] = useState<LocalProfile>(() => readLocal("jodon_profile_v2", DEFAULT_PROFILE));
  const [downloads, setDownloads] = useState<DownloadTask[]>(() => readLocalArray("jodon_downloads_v2", INITIAL_DOWNLOADS));
  const [tracks, setTracks] = useState<LocalMediaTrack[]>(() => INITIAL_LOCAL_TRACKS);

  // Dynamic cover tint & toast
  const [coverTint, setCoverTint] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  // Universal 4-Smart-Buttons Quality Sheet state
  const [sheetAnalysis, setSheetAnalysis] = useState<AnalyzedLink | null>(null);
  const [sheetKind, setSheetKind] = useState<MediaKind | null>(null);
  const [sheetCustomName, setSheetCustomName] = useState<string>("");

  // Tools routing context
  const [toolsSubTab, setToolsSubTab] = useState<"compressor" | "converter" | "browser">("compressor");
  const [browserTargetUrl, setBrowserTargetUrl] = useState("");
  const [toolTargetTask, setToolTargetTask] = useState<DownloadTask | null>(null);

  // Global Local Audio/Video Player state
  const [activeTrack, setActiveTrack] = useState<LocalMediaTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [positionSec, setPositionSec] = useState(0);
  const [repeatMode, setRepeatMode] = useState<RepeatKind>("off");
  const [shuffle, setShuffle] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [bassBoost, setBassBoost] = useState(false);
  const [sleepSec, setSleepSec] = useState(0);
  const [abLoop, setAbLoop] = useState<[number, number] | null>(null);
  const hiddenAudioRef = useRef<HTMLAudioElement>(null);

  const activeTheme = useMemo(
    () => JO_THEMES.find((t) => t.id === settings.themeId) || JO_THEMES[0],
    [settings.themeId]
  );

  // Persist locally
  useEffect(() => {
    try {
      localStorage.setItem("jodon_settings_v2", JSON.stringify(settings));
    } catch {}
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem("jodon_profile_v2", JSON.stringify(profile));
    } catch {}
  }, [profile]);

  useEffect(() => {
    try {
      localStorage.setItem("jodon_downloads_v2", JSON.stringify(downloads.slice(0, 40)));
    } catch {}
  }, [downloads]);

  // Apply Master Theme + Dark/Light + Blur + Motion Physics across ALL screens via CSS tokens
  useEffect(() => {
    const root = document.documentElement;
    const dark = settings.darkMode;
    const primary = tab === "home" && coverTint ? coverTint : activeTheme.accent1;

    root.style.setProperty("--jo-accent-1", primary);
    root.style.setProperty("--jo-accent-2", activeTheme.accent2);
    root.style.setProperty("--jo-accent-3", activeTheme.accent3);
    root.style.setProperty("--jo-blur", `${Math.round(activeTheme.blurPx * settings.blurScale)}px`);

    const motionMap = {
      spring: { curve: activeTheme.spring, speed: `${activeTheme.speedMs}ms` },
      snappy: { curve: "cubic-bezier(0.18, 1.05, 0.3, 1)", speed: "175ms" },
      calm: { curve: "cubic-bezier(0.25, 0.95, 0.35, 1)", speed: "380ms" },
    }[settings.motionPreset];

    root.style.setProperty("--jo-spring", motionMap.curve);
    root.style.setProperty("--jo-speed", motionMap.speed);
    root.style.setProperty("--jo-ambient-dur", `${activeTheme.ambientSec}s`);

    if (dark) {
      root.style.setProperty("--jo-bg", activeTheme.darkBg);
      root.style.setProperty("--jo-bg-2", activeTheme.darkBg2);
      root.style.setProperty("--jo-surface", "rgba(255, 255, 255, 0.062)");
      root.style.setProperty("--jo-surface-elevated", "rgba(255, 255, 255, 0.105)");
      root.style.setProperty("--jo-border", "rgba(255, 255, 255, 0.13)");
      root.style.setProperty("--jo-border-strong", "rgba(255, 255, 255, 0.24)");
      root.style.setProperty("--jo-text", "#F5F7FB");
      root.style.setProperty("--jo-text-2", "#AEB8CA");
      root.style.setProperty("--jo-text-muted", "#78849B");
      root.style.setProperty("--jo-sheet-bg", "rgba(13, 17, 26, 0.94)");
      root.style.setProperty("--jo-dock-bg", "rgba(12, 15, 24, 0.86)");
    } else {
      root.style.setProperty("--jo-bg", "#EEF2F9");
      root.style.setProperty("--jo-bg-2", "#FFFFFF");
      root.style.setProperty("--jo-surface", "rgba(255, 255, 255, 0.72)");
      root.style.setProperty("--jo-surface-elevated", "rgba(255, 255, 255, 0.92)");
      root.style.setProperty("--jo-border", "rgba(15, 23, 42, 0.09)");
      root.style.setProperty("--jo-border-strong", "rgba(15, 23, 42, 0.16)");
      root.style.setProperty("--jo-text", "#0F172A");
      root.style.setProperty("--jo-text-2", "#475569");
      root.style.setProperty("--jo-text-muted", "#64748B");
      root.style.setProperty("--jo-sheet-bg", "rgba(248, 250, 254, 0.96)");
      root.style.setProperty("--jo-dock-bg", "rgba(255, 255, 255, 0.88)");
    }
  }, [activeTheme, settings.darkMode, settings.blurScale, settings.motionPreset, coverTint, tab]);

  const notify = (msg: string) => {
    setToast(msg);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => setToast(null), 2600);
  };

  // Segmented Parallel Download + Work-Stealing live engine tick
  useEffect(() => {
    const hasActive = downloads.some((d) => d.status === "running" || d.status === "queued" || d.status === "merging");
    if (!hasActive) return;

    const timer = window.setInterval(() => {
      setDownloads((prev) => {
        let runningCount = prev.filter((d) => d.status === "running").length;
        return prev.map((task) => {
          if (task.status === "queued" && runningCount < settings.maxConcurrent) {
            runningCount++;
            return { ...task, status: "running", connections: settings.connections };
          }
          if (task.status === "merging") {
            return {
              ...task,
              status: "completed",
              downloadedBytes: task.totalBytes,
              speedBps: 0,
              connections: 0,
            };
          }
          if (task.status !== "running") return task;

          const baseSpeed = (14 + settings.connections * 0.95) * 1024 * 1024;
          const cap = settings.speedLimitMbps > 0 ? settings.speedLimitMbps * 1024 * 1024 : Infinity;
          const jitter = 0.86 + Math.random() * 0.28;
          const speedBps = Math.min(cap, Math.round(baseSpeed * jitter));
          const delta = Math.round(speedBps * 0.35);
          const nextBytes = Math.min(task.totalBytes, task.downloadedBytes + delta);
          const overallRatio = task.totalBytes > 0 ? nextBytes / task.totalBytes : 1;

          // Update segment bars + highlight Work-Stealing on slowest segment
          const nextSegs = task.segments.map((seg, i) => {
            const boost = i % 3 === 0 ? 1.15 : 0.92;
            const p = Math.min(1, Math.max(seg.progress, overallRatio * boost));
            return { ...seg, progress: p, stolen: seg.stolen || (overallRatio > 0.65 && i === task.segments.length - 1) };
          });

          if (nextBytes >= task.totalBytes) {
            // Auto-add finished video/audio downloads to Local Library
            if (task.kind === "video" || task.kind === "audio") {
              const mediaKind: "video" | "audio" = task.kind;
              setTracks((old) =>
                old.some((t) => t.id === `dl_${task.id}`)
                  ? old
                  : [
                      {
                        id: `dl_${task.id}`,
                        title: task.title,
                        artist: "تم تحميله بـ 𝒥𝒪 DON",
                        album: mediaKind === "video" ? "فيديوهاتي" : "التحميلات الصوتية",
                        kind: mediaKind,
                        durationSec: 210,
                        sizeBytes: task.totalBytes,
                        ext: task.ext.toUpperCase(),
                        coverImage: activeTheme.image,
                        accent: activeTheme.accent1,
                        toneSeed: 3,
                      },
                      ...old,
                    ]
              );
            }
            return {
              ...task,
              downloadedBytes: task.totalBytes,
              segments: nextSegs,
              speedBps: 0,
              status: task.dashMerge ? "merging" : "completed",
            };
          }

          return {
            ...task,
            downloadedBytes: nextBytes,
            speedBps,
            speedHistory: [...task.speedHistory, speedBps].slice(-22),
            connections: settings.connections,
            segments: nextSegs,
          };
        });
      });
    }, 350);
    return () => clearInterval(timer);
  }, [downloads, settings.connections, settings.maxConcurrent, settings.speedLimitMbps, activeTheme]);

  // Global Audio Engine synchronization (real local file OR offline harmonic synth)
  useEffect(() => {
    const audioEl = hiddenAudioRef.current;
    if (!activeTrack || !isPlaying) {
      audioEngine.stopSynth();
      audioEl?.pause();
      return;
    }

    if (activeTrack.objectUrl && activeTrack.kind === "audio") {
      audioEngine.stopSynth();
      if (audioEl) {
        if (audioEl.src !== activeTrack.objectUrl) audioEl.src = activeTrack.objectUrl;
        audioEl.playbackRate = speed;
        audioEl.play().catch(() => {});
      }
    } else if (!activeTrack.objectUrl) {
      audioEl?.pause();
      audioEngine.startSynth(activeTrack.toneSeed, speed);
    }
    return () => {
      audioEngine.stopSynth();
    };
  }, [activeTrack?.id, isPlaying]);

  useEffect(() => {
    audioEngine.setSpeed(speed);
    if (hiddenAudioRef.current) hiddenAudioRef.current.playbackRate = speed;
  }, [speed]);

  useEffect(() => {
    audioEngine.setBassBoost(bassBoost ? 9 : 0);
  }, [bassBoost]);

  // Playback progress + Repeat modes + A-B loop
  useEffect(() => {
    if (!activeTrack || !isPlaying) return;
    const id = window.setInterval(() => {
      setPositionSec((prev) => {
        const next = prev + speed * 0.5;
        if (abLoop && next >= abLoop[1]) return abLoop[0];
        if (next >= activeTrack.durationSec) {
          if (repeatMode === "one") return 0;
          if (repeatMode === "all") {
            handleNextTrack();
            return 0;
          }
          setIsPlaying(false);
          return 0;
        }
        return next;
      });
    }, 500);
    return () => clearInterval(id);
  }, [activeTrack, isPlaying, speed, repeatMode, abLoop]);

  // Sleep Timer countdown with gentle volume fade-out during final 10 seconds
  useEffect(() => {
    if (sleepSec <= 0) {
      audioEngine.setVolume(1);
      if (hiddenAudioRef.current) hiddenAudioRef.current.volume = 1;
      return;
    }
    const id = window.setInterval(() => {
      setSleepSec((s) => {
        const next = s - 1;
        if (next > 0 && next <= 10) {
          const v = next / 10;
          audioEngine.setVolume(v);
          if (hiddenAudioRef.current) hiddenAudioRef.current.volume = v;
        }
        if (next <= 0) {
          setIsPlaying(false);
          audioEngine.setVolume(1);
          if (hiddenAudioRef.current) hiddenAudioRef.current.volume = 1;
          notify("مؤقت النوم وقّف التشغيل بهدوء.. تصبح على خير");
          return 0;
        }
        return next;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [sleepSec > 0]);

  const enqueueDownload = (analysis: AnalyzedLink, option: MediaOption, customName?: string) => {
    const cleanBase = (customName || analysis.fileName || analysis.title).trim().replace(/\s+/g, "_").slice(0, 48);
    const fullName = `${cleanBase}_${option.label.split(" ")[0]}.${option.ext}`;
    const segCount = Math.min(16, settings.connections);
    const newTask: DownloadTask = {
      id: `dl_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title: analysis.title,
      fileName: fullName,
      sourceUrl: analysis.url,
      kind: option.kind,
      ext: option.ext,
      codec: option.codec,
      totalBytes: option.bytes,
      isExact: option.isExact,
      downloadedBytes: 0,
      speedBps: 0,
      speedHistory: [],
      connections: settings.connections,
      segments: Array.from({ length: segCount }, (_, i) => ({ id: i, progress: 0 })),
      dashMerge: Boolean(option.dashMerge),
      status: "running",
      wifiOnly: settings.wifiOnly,
      createdAt: Date.now(),
    };
    setDownloads((prev) => [newTask, ...prev]);
    notify(`بدأ تحميل ${option.label} بـ ${settings.connections} اتصال`);
  };

  const handleCopyLink = (url: string) => {
    navigator.clipboard?.writeText(url).catch(() => {});
    notify("اتنسخ اللينك!");
  };

  const selectAndPlayTrack = (track: LocalMediaTrack) => {
    setActiveTrack(track);
    setPositionSec(0);
    setIsPlaying(true);
  };

  const handleNextTrack = () => {
    const pub = tracks.filter((t) => !t.inVault);
    if (!pub.length) return;
    if (shuffle) {
      selectAndPlayTrack(pub[Math.floor(Math.random() * pub.length)]);
      return;
    }
    const idx = pub.findIndex((t) => t.id === activeTrack?.id);
    selectAndPlayTrack(pub[(idx + 1) % pub.length]);
  };

  const handlePrevTrack = () => {
    const pub = tracks.filter((t) => !t.inVault);
    if (!pub.length) return;
    const idx = pub.findIndex((t) => t.id === activeTrack?.id);
    selectAndPlayTrack(pub[(idx - 1 + pub.length) % pub.length]);
  };

  const playYouTubeAsSong = (item: YouTubeItem) => {
    const songTrack: LocalMediaTrack = {
      id: `ytsong_${item.id}`,
      title: item.title,
      artist: item.channelName,
      album: "يوتيوب صوتي",
      kind: "audio",
      durationSec: item.durationSec,
      sizeBytes: 12_400_000,
      ext: "OPUS",
      coverImage: item.coverImage,
      accent: item.accent,
      toneSeed: item.toneSeed,
    };
    selectAndPlayTrack(songTrack);
    notify("شغّال كأغنية في الخلفية");
  };

  const activeDownloadCount = downloads.filter((d) => d.status === "running" || d.status === "merging").length;
  const totalDownloadedBytes = useMemo(
    () => downloads.filter((d) => d.status === "completed").reduce((s, d) => s + d.totalBytes, 0),
    [downloads]
  );

  const dockItems: { id: AppTab; label: string; badge?: number; icon: React.ReactNode }[] = [
    { id: "home", label: "الرئيسية", icon: <Home size={19} /> },
    { id: "youtube", label: "يوتيوب", icon: <YouTubeLogoIcon size={21} /> },
    { id: "downloads", label: "التحميلات", badge: activeDownloadCount, icon: <Download size={19} /> },
    { id: "files", label: "ملفاتي", icon: <Music2 size={19} /> },
    { id: "tools", label: "الأدوات", icon: <Sliders size={19} /> },
    { id: "settings", label: "الإعدادات", icon: <Settings size={19} /> },
  ];

  return (
    <div
      className="relative w-full h-full flex items-center justify-center overflow-hidden transition-colors duration-300"
      style={{ background: "var(--jo-bg)" }}
    >
      {/* Hidden audio element for real user-imported local audio files */}
      <audio
        ref={hiddenAudioRef}
        onTimeUpdate={(e) => setPositionSec(e.currentTarget.currentTime)}
        onEnded={() => {
          if (repeatMode === "one" && hiddenAudioRef.current) {
            hiddenAudioRef.current.currentTime = 0;
            hiddenAudioRef.current.play().catch(() => {});
          } else if (repeatMode === "all") handleNextTrack();
          else setIsPlaying(false);
        }}
        className="hidden"
      />

      {/* Subtle Photorealistic Theme Backdrop on Desktop Phone Frame Mode */}
      {phoneFrame && (
        <div className="hidden md:block absolute inset-0 pointer-events-none overflow-hidden">
          <img
            src={activeTheme.image}
            alt=""
            className="w-full h-full object-cover opacity-22 blur-3xl scale-110 transition-all duration-700"
          />
        </div>
      )}

      {/* Quiet Minimal Desktop Corner Switcher (Phone Frame / Full Screen / JP PROJ Code) */}
      <div className="hidden md:flex fixed top-4 left-4 z-40 items-center gap-2">
        <button
          type="button"
          onClick={() => setPhoneFrame(!phoneFrame)}
          className="jo-press jo-btn-glass px-3 py-1.5 rounded-full text-xs flex items-center gap-1.5 backdrop-blur-xl"
        >
          {phoneFrame ? <Maximize2 size={13} /> : <Smartphone size={13} />}
          <span>{phoneFrame ? "ملء الشاشة" : "شكل الموبايل"}</span>
        </button>

        <button
          type="button"
          onClick={() => setShowAndroidModal(true)}
          className="jo-press jo-btn-glass px-3 py-1.5 rounded-full text-xs flex items-center gap-1.5 backdrop-blur-xl"
        >
          <FolderGit2 size={13} />
          <span>JP PROJ</span>
        </button>
      </div>

      {/* ==================== MAIN ANDROID APP SHELL (𝒥𝒪 DON) ==================== */}
      <main
        className={`relative w-full h-full overflow-hidden flex flex-col transition-all duration-300 ${
          phoneFrame
            ? "md:w-[412px] md:h-[min(868px,94vh)] md:rounded-[42px] md:border md:shadow-[0_28px_90px_rgba(0,0,0,0.65)]"
            : "max-w-3xl mx-auto"
        }`}
        style={{
          background: "var(--jo-bg)",
          borderColor: "var(--jo-border-strong)",
        }}
      >
        {/* Ambient Aurora Glass Mesh Background (AGSL equivalent) */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <img
            src={activeTheme.image}
            alt=""
            className="w-full h-full object-cover transition-opacity duration-700"
            style={{ opacity: settings.darkMode ? 0.12 : 0.08, filter: "blur(26px) saturate(130%)" }}
          />
          <div
            className="jo-blob-1 absolute -top-24 -right-20 w-72 h-72 rounded-full blur-3xl"
            style={{ background: "color-mix(in srgb, var(--jo-accent-1) 24%, transparent)" }}
          />
          <div
            className="jo-blob-2 absolute top-1/3 -left-24 w-72 h-72 rounded-full blur-3xl"
            style={{ background: "color-mix(in srgb, var(--jo-accent-2) 19%, transparent)" }}
          />
        </div>

        {/* Active Screen Content */}
        <div className="relative z-10 flex-1 overflow-hidden">
          {tab === "home" && (
            <HomeTab
              downloads={downloads}
              clipboardWatch={settings.clipboardWatch}
              onOpenQualitySheet={(analysis, kind, customName) => {
                setSheetAnalysis(analysis);
                setSheetKind(kind);
                setSheetCustomName(customName);
              }}
              onOpenDownloads={() => setTab("downloads")}
              onOpenSniffer={(url) => {
                setBrowserTargetUrl(url);
                setToolsSubTab("browser");
                setTab("tools");
              }}
              onQuickBatchQueue={(urls) => {
                urls.forEach((u) => {
                  const snap = buildAnalysisForUrl(u);
                  const first = snap.videos[1] || snap.videos[0] || snap.audios[0] || snap.files[0];
                  if (first) enqueueDownload(snap, first, snap.fileName);
                });
                setTab("downloads");
              }}
              onCoverTint={setCoverTint}
              onNotify={notify}
            />
          )}

          {tab === "youtube" && (
            <YouTubeTab
              profile={profile}
              onUpdateProfile={(fn) => setProfile((prev) => fn(prev))}
              onReplaceProfile={(next) => setProfile(next)}
              onOpenDownload={(analysis, kind) => {
                setSheetAnalysis(analysis);
                setSheetKind(kind);
                setSheetCustomName(analysis.fileName);
              }}
              onPlayAsSong={playYouTubeAsSong}
              onCopyLink={handleCopyLink}
              onNotify={notify}
            />
          )}

          {tab === "downloads" && (
            <DownloadsTab
              downloads={downloads}
              settings={settings}
              onUpdateSettings={(patch) => setSettings((s) => ({ ...s, ...patch }))}
              onTogglePause={(id) =>
                setDownloads((prev) =>
                  prev.map((d) =>
                    d.id === id
                      ? { ...d, status: d.status === "running" ? "paused" : "running", speedBps: 0 }
                      : d
                  )
                )
              }
              onPauseAll={() =>
                setDownloads((prev) =>
                  prev.map((d) => (d.status === "running" || d.status === "queued" ? { ...d, status: "paused", speedBps: 0 } : d))
                )
              }
              onResumeAll={() =>
                setDownloads((prev) =>
                  prev.map((d) => (d.status === "paused" || d.status === "failed" ? { ...d, status: "running" } : d))
                )
              }
              onRemove={(id) => setDownloads((prev) => prev.filter((d) => d.id !== id))}
              onMoveTop={(id) =>
                setDownloads((prev) => {
                  const target = prev.find((d) => d.id === id);
                  return target ? [target, ...prev.filter((d) => d.id !== id)] : prev;
                })
              }
              onCopyLink={handleCopyLink}
              onPlayDownloaded={(task) => {
                const existing = tracks.find((t) => t.id === `dl_${task.id}`) || {
                  id: `dl_${task.id}`,
                  title: task.title,
                  artist: "ملف محلي",
                  album: "التحميلات",
                  kind: task.kind === "video" ? ("video" as const) : ("audio" as const),
                  durationSec: 210,
                  sizeBytes: task.totalBytes,
                  ext: task.ext.toUpperCase(),
                  coverImage: activeTheme.image,
                  accent: activeTheme.accent1,
                  toneSeed: 2,
                };
                if (!tracks.some((t) => t.id === existing.id)) setTracks((p) => [existing, ...p]);
                selectAndPlayTrack(existing);
                setTab("files");
              }}
              onSendToCompressor={(task) => {
                setToolTargetTask(task);
                setToolsSubTab("compressor");
                setTab("tools");
              }}
            />
          )}

          {tab === "files" && (
            <LibraryPlayerTab
              tracks={tracks}
              activeTrack={activeTrack}
              isPlaying={isPlaying}
              positionSec={positionSec}
              repeatMode={repeatMode}
              shuffle={shuffle}
              speed={speed}
              bassBoost={bassBoost}
              sleepSec={sleepSec}
              vaultPin={settings.vaultPin}
              activeRingtone={settings.activeRingtoneName}
              onSelectTrack={selectAndPlayTrack}
              onTogglePlay={() => setIsPlaying((p) => !p)}
              onSeek={(sec) => {
                setPositionSec(sec);
                if (hiddenAudioRef.current && activeTrack?.objectUrl) {
                  hiddenAudioRef.current.currentTime = sec;
                }
              }}
              onNext={handleNextTrack}
              onPrev={handlePrevTrack}
              onCycleRepeat={() => {
                const order: RepeatKind[] = ["off", "all", "one", "ab"];
                const next = order[(order.indexOf(repeatMode) + 1) % order.length];
                setRepeatMode(next);
                const labels: Record<RepeatKind, string> = {
                  off: "بدون تكرار",
                  all: "تكرار القائمة كلها",
                  one: "تكرار الأغنية دي",
                  ab: "تكرار مقطع A-B",
                };
                notify(labels[next]);
              }}
              onToggleShuffle={() => setShuffle((s) => !s)}
              onCycleSpeed={() => {
                const list = [0.75, 1, 1.25, 1.5, 2];
                setSpeed(list[(list.indexOf(speed) + 1) % list.length]);
              }}
              onToggleBass={() => setBassBoost((b) => !b)}
              onSetSleepTimer={setSleepSec}
              onUpdateTrack={(id, patch) => {
                setTracks((prev) => prev.map((t) => (t.id === id ? { ...t, ...patch } : t)));
                setActiveTrack((cur) => (cur && cur.id === id ? { ...cur, ...patch } : cur));
              }}
              onAddTrack={(track) => setTracks((prev) => [track, ...prev])}
              onSetRingtone={(name) => setSettings((s) => ({ ...s, activeRingtoneName: name }))}
              onSetAbLoop={setAbLoop}
              onNotify={notify}
            />
          )}

          {tab === "tools" && (
            <ToolsBrowserTab
              initialSubTab={toolsSubTab}
              initialBrowserUrl={browserTargetUrl}
              preselectedTask={toolTargetTask}
              settings={settings}
              onUpdateSettings={(patch) => setSettings((s) => ({ ...s, ...patch }))}
              onRecordSavedBytes={(saved) =>
                setSettings((s) => ({ ...s, savedByCompressorBytes: s.savedByCompressorBytes + saved }))
              }
              onDownloadSniffed={(snap, opt) => enqueueDownload(snap, opt, snap.fileName)}
              onNotify={notify}
            />
          )}

          {tab === "settings" && (
            <SettingsTab
              settings={settings}
              totalDownloadedBytes={totalDownloadedBytes}
              onUpdateSettings={(patch) => setSettings((s) => ({ ...s, ...patch }))}
              onExportBackup={() => {
                const blob = new Blob([JSON.stringify({ settings, profile, downloads }, null, 2)], {
                  type: "application/json",
                });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = "jodon_full_backup.json";
                a.click();
                URL.revokeObjectURL(url);
                notify("اتحفظت النسخة الاحتياطية الكاملة");
              }}
              onImportBackup={(raw) => {
                try {
                  const data = JSON.parse(raw);
                  if (data.settings) setSettings((s) => ({ ...s, ...data.settings }));
                  if (data.profile) setProfile(data.profile);
                  if (Array.isArray(data.downloads)) setDownloads(data.downloads);
                  notify("تم استعادة إعداداتك وحسابك وسجلك بنجاح!");
                } catch {
                  notify("ملف النسخة الاحتياطية مش سليم");
                }
              }}
              onOpenAndroidCode={() => setShowAndroidModal(true)}
              onNotify={notify}
            />
          )}
        </div>

        {/* Floating Background Audio Mini-Player above the Dock */}
        {activeTrack && tab !== "files" && (
          <div
            className="absolute inset-x-3.5 bottom-[78px] z-30 jo-glass-elevated px-3 py-2 flex items-center gap-2.5 jo-reveal"
            style={{ background: "var(--jo-dock-bg)" }}
          >
            <button
              type="button"
              onClick={() => setTab("files")}
              className="flex items-center gap-2.5 flex-1 min-w-0 text-right"
            >
              <img src={activeTrack.coverImage} alt="" className="w-9 h-9 rounded-xl object-cover shrink-0" />
              <div className="min-w-0 flex-1">
                <div className="text-xs font-semibold truncate">{activeTrack.title}</div>
                <div className="text-[10px] truncate" style={{ color: "var(--jo-text-muted)" }}>
                  {activeTrack.artist}
                </div>
              </div>
            </button>
            <button
              type="button"
              onClick={() => setIsPlaying((p) => !p)}
              className="jo-press jo-btn-primary w-8 h-8 rounded-full flex items-center justify-center shrink-0"
            >
              {isPlaying ? <Pause size={14} /> : <Play size={14} />}
            </button>
            <button
              type="button"
              onClick={() => {
                setIsPlaying(false);
                setActiveTrack(null);
              }}
              className="jo-press p-1 shrink-0"
              style={{ color: "var(--jo-text-muted)" }}
            >
              <X size={14} />
            </button>
          </div>
        )}

        {/* Toast feedback pill */}
        {toast && (
          <div
            className="absolute top-3.5 inset-x-6 z-50 pointer-events-none flex justify-center jo-reveal"
          >
            <div
              className="px-4 py-2 rounded-full text-xs font-semibold shadow-xl border"
              style={{
                background: "var(--jo-sheet-bg)",
                borderColor: "var(--jo-border-strong)",
                color: "var(--jo-text)",
              }}
            >
              {toast}
            </div>
          </div>
        )}

        {/* Floating Glass Dock (Zero Material NavigationBar) */}
        <nav
          aria-label="التنقل الرئيسي"
          className="absolute inset-x-3 bottom-2.5 z-30 rounded-[28px] border px-1.5 py-1.5 flex items-center justify-between"
          style={{
            background: "var(--jo-dock-bg)",
            borderColor: "var(--jo-border-strong)",
            backdropFilter: "blur(28px) saturate(160%)",
            WebkitBackdropFilter: "blur(28px) saturate(160%)",
          }}
        >
          {dockItems.map((item) => {
            const selected = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className="jo-press relative flex-1 py-1.5 rounded-[20px] flex flex-col items-center justify-center gap-0.5 transition-all"
                style={{
                  background: selected
                    ? item.id === "youtube"
                      ? "rgba(255, 0, 51, 0.14)"
                      : "color-mix(in srgb, var(--jo-accent-1) 16%, transparent)"
                    : "transparent",
                  color: selected
                    ? item.id === "youtube"
                      ? "#FF2E55"
                      : "var(--jo-accent-1)"
                    : "var(--jo-text-muted)",
                }}
              >
                <span className="relative">
                  {item.icon}
                  {item.badge !== undefined && item.badge > 0 && (
                    <span className="absolute -top-1 -left-2 min-w-[15px] h-[15px] px-1 rounded-full bg-emerald-500 text-white text-[9px] font-bold flex items-center justify-center">
                      {item.badge}
                    </span>
                  )}
                </span>
                <span className="text-[10px] font-semibold leading-tight">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Universal 4 Smart Lists Quality Bottom Sheet */}
        <QualityBottomSheet
          analysis={sheetAnalysis}
          activeKind={sheetKind}
          customFileName={sheetCustomName}
          onClose={() => {
            setSheetAnalysis(null);
            setSheetKind(null);
          }}
          onChangeKind={(k) => setSheetKind(k)}
          onDownload={enqueueDownload}
          onConvertOption={(analysis, option) => {
            enqueueDownload(analysis, option, sheetCustomName);
            setToolsSubTab("converter");
            setTab("tools");
          }}
        />
      </main>

      {/* JP PROJ Complete Android Codebase Inspector Modal */}
      <AndroidProjectModal open={showAndroidModal} onClose={() => setShowAndroidModal(false)} />
    </div>
  );
}

export default App;
