import { AnalyzedLink, ChannelInfo, JoThemeSpec, LocalMediaTrack, MediaOption, YouTubeItem } from "../types/app";

export const JO_THEMES: JoThemeSpec[] = [
  {
    id: "aurora",
    name: "أورورا جيميناي",
    desc: "أزرق وبنفسجي ووردي ناعم بتوهج زجاجي راقي",
    image: "/images/themes/theme_aurora.jpg",
    darkBg: "#0B0D12",
    darkBg2: "#121622",
    accent1: "#4285F4",
    accent2: "#9B72CB",
    accent3: "#D96570",
    blurPx: 26,
    spring: "cubic-bezier(0.22, 1.18, 0.36, 1)",
    speedMs: 280,
    ambientSec: 18,
  },
  {
    id: "ocean",
    name: "محيط عميق",
    desc: "أزرق ياقوتي وفيروزي صافي مريح جداً للعين",
    image: "/images/themes/theme_ocean.jpg",
    darkBg: "#060D17",
    darkBg2: "#0C1829",
    accent1: "#0EA5E9",
    accent2: "#38BDF8",
    accent3: "#2DD4BF",
    blurPx: 30,
    spring: "cubic-bezier(0.2, 1.08, 0.32, 1)",
    speedMs: 320,
    ambientSec: 22,
  },
  {
    id: "sunset",
    name: "غروب الصحراء",
    desc: "دهبي دافي مع مرجاني شيك بلمسة هادية",
    image: "/images/themes/theme_sunset.jpg",
    darkBg: "#120B0A",
    darkBg2: "#1E1311",
    accent1: "#F59E0B",
    accent2: "#F97316",
    accent3: "#E11D48",
    blurPx: 24,
    spring: "cubic-bezier(0.22, 1.14, 0.36, 1)",
    speedMs: 290,
    ambientSec: 20,
  },
  {
    id: "emerald",
    name: "زمرد النيل",
    desc: "أخضر زمردي فخم مع زجاج داكن نقي",
    image: "/images/themes/theme_emerald.jpg",
    darkBg: "#06110E",
    darkBg2: "#0C1E19",
    accent1: "#10B981",
    accent2: "#14B8A6",
    accent3: "#34D399",
    blurPx: 26,
    spring: "cubic-bezier(0.22, 1.12, 0.34, 1)",
    speedMs: 300,
    ambientSec: 21,
  },
  {
    id: "mono",
    name: "أسود فحمي",
    desc: "أسود AMOLED صافي بيوفّر البطارية مع زجاج فضي",
    image: "/images/themes/theme_mono.jpg",
    darkBg: "#000000",
    darkBg2: "#0E1014",
    accent1: "#94A3B8",
    accent2: "#64748B",
    accent3: "#CBD5E1",
    blurPx: 22,
    spring: "cubic-bezier(0.2, 1.0, 0.3, 1)",
    speedMs: 220,
    ambientSec: 28,
  },
  {
    id: "neon",
    name: "نيون ليلي",
    desc: "سيان وماجنتا عصري بأنيميشن سريع وحيوي",
    image: "/images/themes/theme_neon.jpg",
    darkBg: "#090612",
    darkBg2: "#140D26",
    accent1: "#22D3EE",
    accent2: "#A855F7",
    accent3: "#EC4899",
    blurPx: 28,
    spring: "cubic-bezier(0.18, 1.28, 0.34, 1)",
    speedMs: 230,
    ambientSec: 13,
  },
];

/** Strictly distinguishes exact bytes from approximate sizes ("≈"). */
export function formatSizeAr(bytes: number, isExact = true): string {
  if (!bytes || bytes <= 0) return "غير معروف";
  const units = ["بايت", "ك.ب", "ميجا", "جيجا", "تيرا"];
  const idx = Math.min(4, Math.floor(Math.log(bytes) / Math.log(1024)));
  const val = bytes / Math.pow(1024, idx);
  const num = idx === 0 ? `${Math.round(bytes)}` : val.toFixed(val >= 100 ? 0 : 1);
  return `${isExact ? "" : "≈ "}${num} ${units[idx]}`;
}

export function formatExactBytesAr(bytes: number, isExact = true): string {
  const grouped = Math.round(bytes).toLocaleString("en-US");
  const human = formatSizeAr(bytes, isExact);
  return isExact ? `${grouped} بايت (${human})` : `≈ ${grouped} بايت (${human} • تقريبي)`;
}

export function formatDuration(sec: number): string {
  const s = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
  return `${m}:${String(r).padStart(2, "0")}`;
}

export function formatSpeedAr(bps: number): string {
  if (bps <= 0) return "0 ك.ب/ث";
  return `${formatSizeAr(bps, true)}/ث`;
}

export function formatEtaAr(remainingBytes: number, speedBps: number): string {
  if (remainingBytes <= 0) return "خلص";
  if (speedBps <= 0) return "مستني";
  const sec = Math.max(1, Math.ceil(remainingBytes / speedBps));
  if (sec < 60) return `فاضل ${sec} ث`;
  if (sec < 3600) return `فاضل ${Math.floor(sec / 60)} د ${sec % 60} ث`;
  return `فاضل ${Math.floor(sec / 3600)} س ${Math.floor((sec % 3600) / 60)} د`;
}

export function formatViewsAr(views: number): string {
  if (views >= 1_000_000) return `${(views / 1_000_000).toFixed(1)} مليون مشاهدة`;
  if (views >= 1_000) return `${Math.round(views / 1_000)} ألف مشاهدة`;
  return `${views} مشاهدة`;
}

export const YT_CATEGORIES = ["الكل", "مقترح ليك", "اشتراكاتي", "تقنية", "موسيقى", "وثائقي", "هدوء", "تعليم", "جيمنج"];

export const YT_CHANNELS: ChannelInfo[] = [
  { id: "ch_tech", name: "تكنو مصر", handle: "@technomasr", subsLabel: "1.8 مليون مشترك", color: "#4285F4", category: "تقنية" },
  { id: "ch_mazika", name: "موجة مزيكا", handle: "@mawgatmusic", subsLabel: "940 ألف مشترك", color: "#9B72CB", category: "موسيقى" },
  { id: "ch_doc", name: "حكاية الكوكب", handle: "@kawkabdoc", subsLabel: "2.4 مليون مشترك", color: "#0EA5E9", category: "وثائقي" },
  { id: "ch_calm", name: "سكينة وهدوء", handle: "@sakinah", subsLabel: "3.1 مليون مشترك", color: "#10B981", category: "هدوء" },
  { id: "ch_code", name: "كود بالعربي", handle: "@codearaby", subsLabel: "620 ألف مشترك", color: "#F59E0B", category: "تعليم" },
  { id: "ch_game", name: "أرينا جيمرز", handle: "@arenagamers", subsLabel: "1.2 مليون مشترك", color: "#EC4899", category: "جيمنج" },
];

export const BASE_YT_VIDEOS: YouTubeItem[] = [
  {
    id: "yt_1",
    url: "https://youtu.be/aurora_4k_hdr_eg",
    title: "رحلة الشفق القطبي بجودة 4K HDR — مشاهد طبيعية تخطف العين",
    channelId: "ch_doc",
    channelName: "حكاية الكوكب",
    channelColor: "#0EA5E9",
    category: "وثائقي",
    tags: ["شفق", "طبيعة", "4k", "hdr", "وثائقي", "تصوير"],
    durationSec: 864,
    views: 2_840_000,
    uploadedAr: "من يومين",
    coverImage: "/images/themes/theme_aurora.jpg",
    accent: "#4285F4",
    toneSeed: 1,
    description: "تصوير سينمائي حقيقي بدقة 4K 60fps لأجمل ليالي الشفق القطبي مع صوت محيطي نقي.",
  },
  {
    id: "yt_2",
    url: "https://youtu.be/android_flagship_review",
    title: "أقوى إعدادات تخلّي موبايلك الأندرويد طلقة وبطاريته تعيش يومين",
    channelId: "ch_tech",
    channelName: "تكنو مصر",
    channelColor: "#4285F4",
    category: "تقنية",
    tags: ["أندرويد", "موبايل", "سرعة", "بطارية", "تقنية", "مراجعة"],
    durationSec: 712,
    views: 980_000,
    uploadedAr: "من 5 ساعات",
    coverImage: "/images/themes/theme_mono.jpg",
    accent: "#38BDF8",
    toneSeed: 2,
    description: "خطوات عملية من غير برامج زيادة تفرّق معاك فوراً في سلاسة الشاشة واستهلاك البطارية.",
  },
  {
    id: "yt_3",
    url: "https://youtu.be/cairo_midnight_oud",
    title: "موسيقى ليل القاهرة — عود وبيانو هادي للشغل والتركيز العميق",
    channelId: "ch_mazika",
    channelName: "موجة مزيكا",
    channelColor: "#9B72CB",
    category: "موسيقى",
    tags: ["موسيقى", "عود", "بيانو", "تركيز", "مذاكرة", "ليل", "مزيكا"],
    durationSec: 2140,
    views: 4_350_000,
    uploadedAr: "من أسبوع",
    coverImage: "/images/themes/theme_sunset.jpg",
    accent: "#F59E0B",
    toneSeed: 3,
    description: "مقطوعة موسيقية أصلية صافية تقدر تشغّلها كأغنية في الخلفية أو تحمّلها بصيغة FLAC بدون فقد.",
  },
  {
    id: "yt_4",
    url: "https://youtu.be/red_sea_deep_4k",
    title: "أسرار أعماق البحر الأحمر في مرسى علم ودهب — تصوير تحت المية",
    channelId: "ch_doc",
    channelName: "حكاية الكوكب",
    channelColor: "#0EA5E9",
    category: "وثائقي",
    tags: ["البحر الأحمر", "دهب", "مصر", "محيط", "وثائقي", "غوص"],
    durationSec: 1125,
    views: 1_620_000,
    uploadedAr: "من 3 أيام",
    coverImage: "/images/themes/theme_ocean.jpg",
    accent: "#0EA5E9",
    toneSeed: 4,
    description: "جولة نادرة وسط الشعاب المرجانية والإضاءة الطبيعية تحت مياه البحر الأحمر الصافية.",
  },
  {
    id: "yt_5",
    url: "https://youtu.be/rain_forest_calm",
    title: "صوت المطر الهادي على الشباك مع طبيعة خضراء للاسترخاء والنوم",
    channelId: "ch_calm",
    channelName: "سكينة وهدوء",
    channelColor: "#10B981",
    category: "هدوء",
    tags: ["مطر", "نوم", "هدوء", "راحة", "طبيعة", "سكينة"],
    durationSec: 3600,
    views: 5_900_000,
    uploadedAr: "من شهر",
    coverImage: "/images/themes/theme_emerald.jpg",
    accent: "#10B981",
    toneSeed: 5,
    description: "مثالي مع مؤقت النوم المدمج في المشغل عشان يقفل لوحده بتلاشي صوتي ناعم.",
  },
  {
    id: "yt_6",
    url: "https://youtu.be/kotlin_compose_master",
    title: "إزاي تبني تطبيق أندرويد احترافي بـ Kotlin و Compose من الصفر",
    channelId: "ch_code",
    channelName: "كود بالعربي",
    channelColor: "#F59E0B",
    category: "تعليم",
    tags: ["برمجة", "كوتلن", "أندرويد", "تعليم", "كورس", "compose"],
    durationSec: 1940,
    views: 540_000,
    uploadedAr: "من 4 أيام",
    coverImage: "/images/themes/theme_aurora.jpg",
    accent: "#9B72CB",
    toneSeed: 6,
    description: "شرح منظم وسهل خطوة بخطوة لبناء معمارية Clean Architecture نظيفة وسريعة 120fps.",
  },
  {
    id: "yt_7",
    url: "https://youtu.be/cyber_night_120fps",
    title: "تجربة أقوى ألعاب الجرافيك على 120 فريم مع إضاءة Ray Tracing",
    channelId: "ch_game",
    channelName: "أرينا جيمرز",
    channelColor: "#EC4899",
    category: "جيمنج",
    tags: ["جيمنج", "ألعاب", "120fps", "جرافيك", "نيون"],
    durationSec: 938,
    views: 1_190_000,
    uploadedAr: "امبارح",
    coverImage: "/images/themes/theme_neon.jpg",
    accent: "#EC4899",
    toneSeed: 7,
    description: "اختبار أداء حقيقي بأعلى إعدادات جرافيك ومقارنة الفريمات في المشاهد الليلية.",
  },
  {
    id: "yt_8",
    url: "https://youtu.be/siwa_desert_stars",
    title: "ليلة كاملة في صحراء سيوة تحت ملايين النجوم — تجربة لا تُنسى",
    channelId: "ch_doc",
    channelName: "حكاية الكوكب",
    channelColor: "#0EA5E9",
    category: "وثائقي",
    tags: ["سيوة", "صحراء", "مصر", "سفر", "نجوم", "غروب"],
    durationSec: 1030,
    views: 2_110_000,
    uploadedAr: "من 6 أيام",
    coverImage: "/images/themes/theme_sunset.jpg",
    accent: "#F97316",
    toneSeed: 8,
    description: "توثيق بصري لغروب سيوة والنجوم بتقنية Timelapse 8K بدون أي فلاتر مصطنعة.",
  },
];

export const BASE_SHORTS: YouTubeItem[] = [
  {
    id: "sh_1",
    url: "https://youtube.com/shorts/fast_tip_1",
    title: "حركة سحرية في موبايلك هتوفرلك نص المساحة في دقيقة",
    channelId: "ch_tech",
    channelName: "تكنو مصر",
    channelColor: "#4285F4",
    category: "تقنية",
    tags: ["شورتس", "أندرويد", "مساحة", "تقنية"],
    durationSec: 48,
    views: 1_450_000,
    uploadedAr: "النهارده",
    coverImage: "/images/themes/theme_neon.jpg",
    accent: "#22D3EE",
    toneSeed: 11,
    isShort: true,
    description: "جربها دلوقتي وقولي وفّرت معاك كام جيجا.",
  },
  {
    id: "sh_2",
    url: "https://youtube.com/shorts/sunset_dahab",
    title: "لحظة الغروب في دهب مع صوت الموج الطبيعي",
    channelId: "ch_calm",
    channelName: "سكينة وهدوء",
    channelColor: "#10B981",
    category: "هدوء",
    tags: ["شورتس", "دهب", "غروب", "بحر"],
    durationSec: 36,
    views: 2_900_000,
    uploadedAr: "امبارح",
    coverImage: "/images/themes/theme_sunset.jpg",
    accent: "#F59E0B",
    toneSeed: 12,
    isShort: true,
    description: "تقدر تحمّله 1080p 60fps بضغطة واحدة من الزرار اللي تحت.",
  },
  {
    id: "sh_3",
    url: "https://youtube.com/shorts/guitar_solo_eg",
    title: "مقطوعة جيتار شرقي 30 ثانية تنفع أحلى نغمة رنين",
    channelId: "ch_mazika",
    channelName: "موجة مزيكا",
    channelColor: "#9B72CB",
    category: "موسيقى",
    tags: ["شورتس", "نغمة", "جيتار", "موسيقى"],
    durationSec: 31,
    views: 3_720_000,
    uploadedAr: "من يومين",
    coverImage: "/images/themes/theme_aurora.jpg",
    accent: "#9B72CB",
    toneSeed: 13,
    isShort: true,
    description: "حمّل الصوت بتاعها وخلّيها نغمة موبايلك من مشغل 𝒥𝒪 DON.",
  },
  {
    id: "sh_4",
    url: "https://youtube.com/shorts/ocean_glow",
    title: "إزاي المية بتنور أزرق بالليل؟ ظاهرة مدهشة سبحان الله",
    channelId: "ch_doc",
    channelName: "حكاية الكوكب",
    channelColor: "#0EA5E9",
    category: "وثائقي",
    tags: ["شورتس", "بحر", "محيط", "علوم"],
    durationSec: 54,
    views: 4_100_000,
    uploadedAr: "من 3 أيام",
    coverImage: "/images/themes/theme_ocean.jpg",
    accent: "#0EA5E9",
    toneSeed: 14,
    isShort: true,
    description: "لقطات نادرة للضياء الحيوي في المحيط بدقة عالية.",
  },
];

const EXTRA_TOPIC_TEMPLATES: Record<string, { titles: string[]; cover: string; accent: string; chIdx: number }> = {
  تقنية: {
    titles: [
      "مقارنة شاشات AMOLED 120Hz — أنهي الأفضل لعينك في الضلمة؟",
      "شرح بروتوكول HTTP/3 QUIC وإزاي بيضاعف سرعة التحميل",
      "أفضل 5 عادات تحافظ على صحة بطارية موبايلك 100% طول السنة",
    ],
    cover: "/images/themes/theme_mono.jpg",
    accent: "#4285F4",
    chIdx: 0,
  },
  موسيقى: {
    titles: [
      "موسيقى ناي وكمان شرقي صافي — جلسة مسائية هادية",
      "إيقاعات Lo-Fi عربية ناعمة للمذاكرة والشغل بالليل",
      "سيمفونية الفجر — بيانو نقي بجودة استوديو FLAC",
    ],
    cover: "/images/themes/theme_aurora.jpg",
    accent: "#9B72CB",
    chIdx: 1,
  },
  وثائقي: {
    titles: [
      "رحلة نهر النيل من المنبع للمصب بتصوير جوي 4K",
      "أجمل واحات مصر المخفية وسط الرمال الدهبية",
      "كيف تتكون السحب المضيئة في طبقات الجو العليا؟",
    ],
    cover: "/images/themes/theme_ocean.jpg",
    accent: "#0EA5E9",
    chIdx: 2,
  },
  هدوء: {
    titles: [
      "أصوات غابة الصنوبر والندى الصباحي لصفاء الذهن",
      "موج البحر الهادي بالليل بجودة صوت ثلاثي الأبعاد",
      "ساعة كاملة من السكون والطبيعة الخضراء بدون إعلانات",
    ],
    cover: "/images/themes/theme_emerald.jpg",
    accent: "#10B981",
    chIdx: 3,
  },
  تعليم: {
    titles: [
      "أسرار تصميم واجهات Glassmorphism الناعمة بدون تعقيد",
      "فهم الـ Coroutines والـ Flow في كوتلن بأبسط مثال عملي",
      "إزاي تظبط ضغط الفيديو بـ FFmpeg من غير ما تخسر جودة",
    ],
    cover: "/images/themes/theme_sunset.jpg",
    accent: "#F59E0B",
    chIdx: 4,
  },
  جيمنج: {
    titles: [
      "أجمل عوالم مفتوحة بتصميم ليلي خيالي في 2026",
      "تظبيط الحساسية والفريمات لأعلى سلاسة من غير تقطيع",
      "سباق ليلي تحت المطر بدقة 4K 60fps وصوت محركات واقعي",
    ],
    cover: "/images/themes/theme_neon.jpg",
    accent: "#EC4899",
    chIdx: 5,
  },
};

/** Generates infinite personalized recommendations tuned to local subscriptions & category weights. */
export function generatePersonalizedBatch(
  batchNumber: number,
  weights: Record<string, number>,
  subscribedIds: string[]
): YouTubeItem[] {
  const allCats = Object.keys(EXTRA_TOPIC_TEMPLATES);
  const rankedCats = [...allCats].sort((a, b) => {
    const subA = YT_CHANNELS.some((c) => c.category === a && subscribedIds.includes(c.id)) ? 5 : 0;
    const subB = YT_CHANNELS.some((c) => c.category === b && subscribedIds.includes(c.id)) ? 5 : 0;
    return (weights[b] || 0) + subB - ((weights[a] || 0) + subA);
  });

  return rankedCats.slice(0, 4).map((cat, idx) => {
    const tpl = EXTRA_TOPIC_TEMPLATES[cat];
    const ch = YT_CHANNELS[tpl.chIdx];
    const titleBase = tpl.titles[(batchNumber + idx) % tpl.titles.length];
    const partSuffix = batchNumber > 2 ? ` • حلقة ${batchNumber}` : "";
    return {
      id: `yt_inf_${batchNumber}_${idx}_${cat}`,
      url: `https://youtu.be/jodon_${batchNumber}_${idx}`,
      title: `${titleBase}${partSuffix}`,
      channelId: ch.id,
      channelName: ch.name,
      channelColor: ch.color,
      category: cat,
      tags: [cat, ch.name, ...titleBase.split(" ").slice(0, 4)],
      durationSec: 540 + ((batchNumber * 137 + idx * 95) % 1400),
      views: 180_000 + ((batchNumber * 310_000 + idx * 145_000) % 2_600_000),
      uploadedAr: subscribedIds.includes(ch.id) ? "جديد من اشتراكاتك" : "مقترح حسب تصفحك",
      coverImage: tpl.cover,
      accent: tpl.accent,
      toneSeed: (batchNumber + idx) % 9 + 1,
      description: `مقترح خصيصاً ليك بناءً على اهتمامك بـ "${cat}" وقناة ${ch.name} — محفوظ محلياً على جهازك.`,
    };
  });
}

export const YT_SEARCH_SUGGESTIONS = [
  "موسيقى ليل القاهرة عود وبيانو",
  "رحلة الشفق القطبي 4K HDR",
  "إعدادات تسريع الأندرويد والبطارية",
  "أعماق البحر الأحمر دهب",
  "صوت المطر الهادي للنوم",
  "كورس كوتلن وأندرويد بالعربي",
  "نغمة جيتار شرقي هادية",
  "صحراء سيوة بالليل 8K",
  "ألعاب 120 فريم جرافيك عالي",
];

/** Builds an accurate 4-smart-buttons AnalyzedLink for ANY pasted link or YouTube item. */
export function buildAnalysisForUrl(rawUrl: string, ytItem?: YouTubeItem): AnalyzedLink {
  const clean = rawUrl.trim();
  const normalized = clean.startsWith("http") || clean.startsWith("magnet:") ? clean : `https://${clean}`;
  let domain = "youtube.com";
  try {
    domain = new URL(normalized).hostname.replace(/^(www\.|m\.)/, "").toLowerCase();
  } catch {
    domain = "direct.file";
  }

  // Legal rule 11: Strict DRM refusal
  if (/netflix\.com|shahid\.mbc|disneyplus\.com|osnplus\.com/i.test(domain)) {
    return {
      url: normalized,
      domain,
      siteName: domain.split(".")[0].toUpperCase(),
      siteColor: "#F43F5E",
      title: "محتوى محمي بحقوق النشر الرقمية (DRM)",
      fileName: "protected",
      uploader: domain,
      durationSec: 0,
      coverImage: "/images/themes/theme_mono.jpg",
      coverAccent: "#F43F5E",
      stage: 3,
      isComplete: true,
      drmBlocked: true,
      videos: [],
      audios: [],
      images: [],
      files: [],
    };
  }

  // Direct single file URLs -> STRICT Rule 4.4: ONLY show the exact button for that file's type!
  if (/\.(apk|zip|pdf|iso|7z|rar)(\?|$)/i.test(normalized)) {
    const fileName = normalized.split("/").pop()?.split("?")[0] || "archive_package.zip";
    const ext = fileName.split(".").pop()?.toLowerCase() || "zip";
    const fileOpt: MediaOption = {
      id: "dir_f1",
      kind: "file",
      label: fileName,
      ext,
      codec: "متعدد الأجزاء (32 اتصال)",
      detail: "يدعم الإيقاف والاستكمال",
      bytes: 148_372_910,
      isExact: true,
      directUrl: normalized,
    };
    return {
      url: normalized,
      domain,
      siteName: domain,
      siteColor: "#22C55E",
      title: fileName,
      fileName: fileName.replace(/\.[^.]+$/, ""),
      uploader: "رابط مباشر سريع",
      durationSec: 0,
      coverImage: "/images/themes/theme_emerald.jpg",
      coverAccent: "#22C55E",
      stage: 1,
      isComplete: true,
      videos: [],
      audios: [],
      images: [],
      files: [fileOpt],
    };
  }

  // SoundCloud / Audio-only platforms -> ONLY Audio + Cover Image buttons appear (Video & Files stay hidden!)
  if (/soundcloud\.com|anghami\.|\.(mp3|flac|wav|m4a)(\?|$)/i.test(normalized)) {
    return {
      url: normalized,
      domain,
      siteName: domain.includes("soundcloud") ? "SoundCloud" : "ملف صوتي",
      siteColor: "#F97316",
      title: "مقطوعة نسمة الفجر — تسجيل استوديو نقي",
      fileName: "nesmet_elfagr_studio",
      uploader: "موجة مزيكا",
      durationSec: 268,
      coverImage: "/images/themes/theme_sunset.jpg",
      coverAccent: "#F97316",
      stage: 2,
      isComplete: true,
      videos: [],
      audios: [
        { id: "sc_flac", kind: "audio", label: "FLAC استوديو بدون فقد", ext: "flac", codec: "FLAC 24-bit", detail: "1,120 kbps", bytes: 37_521_408, isExact: true, directUrl: normalized },
        { id: "sc_mp3", kind: "audio", label: "MP3 جودة عالية", ext: "mp3", codec: "LAME MP3", detail: "320 kbps", bytes: 10_724_864, isExact: true, directUrl: normalized },
        { id: "sc_opus", kind: "audio", label: "Opus خفيف ونقي", ext: "opus", codec: "Opus", detail: "160 kbps", bytes: 5_362_432, isExact: true, directUrl: normalized },
      ],
      images: [
        { id: "sc_img", kind: "image", label: "غلاف الألبوم الأصلي 1500×1500", ext: "jpg", codec: "JPEG", detail: "أصلي", bytes: 842_110, isExact: true, directUrl: "/images/themes/theme_sunset.jpg" },
      ],
      files: [],
    };
  }

  // TikTok / Instagram / X -> Video (no watermark / HD), Original Audio, Cover/Slide Photos (no empty Files button!)
  if (/tiktok\.com|instagram\.com|x\.com|twitter\.com|facebook\.com|fb\.watch/i.test(normalized)) {
    const site = domain.includes("tiktok")
      ? "TikTok"
      : domain.includes("instagram")
      ? "Instagram"
      : domain.includes("facebook") || domain.includes("fb")
      ? "Facebook"
      : "X";
    return {
      url: normalized,
      domain,
      siteName: site,
      siteColor: "#EC4899",
      title: `فيديو ${site} بجودة أصلية كاملة`,
      fileName: `${site.toLowerCase()}_original_hd`,
      uploader: `@creator_${site.toLowerCase()}`,
      durationSec: 47,
      coverImage: "/images/themes/theme_neon.jpg",
      coverAccent: "#EC4899",
      stage: 2,
      isComplete: true,
      videos: [
        { id: "tk_1", kind: "video", label: "1080p الأصلية (بدون علامة)", ext: "mp4", codec: "HEVC", detail: "60fps", bytes: 18_642_190, isExact: true, directUrl: normalized },
        { id: "tk_2", kind: "video", label: "1080p متوافقة لكل الأجهزة", ext: "mp4", codec: "AVC H.264", detail: "30fps", bytes: 12_410_880, isExact: true, directUrl: normalized },
        { id: "tk_3", kind: "video", label: "720p سريعة وموفرة", ext: "mp4", codec: "AVC H.264", detail: "30fps", bytes: 6_192_300, isExact: true, directUrl: normalized },
      ],
      audios: [
        { id: "tk_a1", kind: "audio", label: "الصوت الأصلي الكامل", ext: "m4a", codec: "AAC", detail: "256 kbps", bytes: 1_512_440, isExact: true, directUrl: normalized },
        { id: "tk_a2", kind: "audio", label: "استخراج MP3 جاهز", ext: "mp3", codec: "MP3", detail: "320 kbps", bytes: 1_890_120, isExact: true, directUrl: normalized },
      ],
      images: [
        { id: "tk_i1", kind: "image", label: "غلاف الفيديو HD", ext: "webp", codec: "WebP", detail: "1080×1920", bytes: 412_600, isExact: true, directUrl: "/images/themes/theme_neon.jpg" },
        { id: "tk_i2", kind: "image", label: "شريحة الصورة 2", ext: "jpg", codec: "JPEG", detail: "1080×1920", bytes: 628_900, isExact: true, directUrl: "/images/themes/theme_aurora.jpg" },
      ],
      files: [],
    };
  }

  // Generic webpage needing Browser Sniffer
  if (/sniffer|blog|news|article|embed/i.test(normalized)) {
    return {
      url: normalized,
      domain,
      siteName: domain,
      siteColor: "#F59E0B",
      title: "صفحة ويب فيها ملفات مخفية جوّا المشغل",
      fileName: "web_media",
      uploader: domain,
      durationSec: 0,
      coverImage: "/images/themes/theme_ocean.jpg",
      coverAccent: "#F59E0B",
      stage: 4,
      isComplete: true,
      needsSniffer: true,
      videos: [],
      audios: [],
      images: [],
      files: [],
    };
  }

  // YouTube & Full 4-Category Rich Media (Videos 144p->4K/8K w/ DASH merge + Audios + Thumbnails + Subtitles)
  const title = ytItem?.title || "رحلة الشفق القطبي بجودة 4K HDR — مشاهد طبيعية تخطف العين";
  const dur = ytItem?.durationSec || 864;
  const scale = Math.max(0.15, dur / 600);
  return {
    url: normalized,
    domain: domain || "youtube.com",
    siteName: "YouTube",
    siteColor: "#FF0033",
    title,
    fileName: title.slice(0, 42).replace(/\s+/g, "_"),
    uploader: ytItem?.channelName || "حكاية الكوكب",
    durationSec: dur,
    coverImage: ytItem?.coverImage || "/images/themes/theme_aurora.jpg",
    coverAccent: ytItem?.accent || "#4285F4",
    stage: 3,
    isComplete: true,
    videos: [
      { id: "v_4k", kind: "video", label: "2160p 4K HDR", ext: "mkv", codec: "AV1", detail: "60fps • دمج صوت تلقائي", bytes: Math.round(418_624_512 * scale), isExact: true, dashMerge: true, directUrl: normalized },
      { id: "v_2k", kind: "video", label: "1440p 2K QHD", ext: "mp4", codec: "VP9", detail: "60fps • دمج صوت تلقائي", bytes: Math.round(212_341_760 * scale), isExact: true, dashMerge: true, directUrl: normalized },
      { id: "v_1080", kind: "video", label: "1080p Full HD", ext: "mp4", codec: "AVC H.264", detail: "60fps • دمج صوت تلقائي", bytes: Math.round(148_372_910 * scale), isExact: true, dashMerge: true, directUrl: normalized },
      { id: "v_720", kind: "video", label: "720p HD جاهز", ext: "mp4", codec: "AVC H.264", detail: "30fps • مدمج", bytes: Math.round(64_819_200 * scale), isExact: true, directUrl: normalized },
      { id: "v_480", kind: "video", label: "480p متوسطة", ext: "mp4", codec: "AVC", detail: "30fps", bytes: Math.round(34_120_400 * scale), isExact: true, directUrl: normalized },
      { id: "v_144", kind: "video", label: "144p توفير باقة", ext: "mp4", codec: "AV1", detail: "30fps", bytes: Math.round(8_910_000 * scale), isExact: false, directUrl: normalized },
    ],
    audios: [
      { id: "a_flac", kind: "audio", label: "FLAC نقي بدون فقد", ext: "flac", codec: "FLAC", detail: "استوديو", bytes: Math.round(48_210_944 * scale), isExact: false, directUrl: normalized },
      { id: "a_mp3", kind: "audio", label: "MP3 أعلى جودة", ext: "mp3", codec: "MP3", detail: "320 kbps", bytes: Math.round(23_910_400 * scale), isExact: true, directUrl: normalized },
      { id: "a_opus", kind: "audio", label: "Opus الأصلي", ext: "opus", codec: "Opus", detail: "160 kbps • نسخ مباشر", bytes: Math.round(12_184_320 * scale), isExact: true, directUrl: normalized },
      { id: "a_m4a", kind: "audio", label: "M4A للموبايل", ext: "m4a", codec: "AAC-LC", detail: "128 kbps", bytes: Math.round(9_830_400 * scale), isExact: true, directUrl: normalized },
    ],
    images: [
      { id: "i_max", kind: "image", label: "صورة الغلاف الكاملة 1920×1080", ext: "jpg", codec: "JPEG", detail: "MaxRes", bytes: 684_320, isExact: true, directUrl: ytItem?.coverImage || "/images/themes/theme_aurora.jpg" },
      { id: "i_webp", kind: "image", label: "صورة الغلاف WebP", ext: "webp", codec: "WebP", detail: "1280×720", bytes: 248_910, isExact: true, directUrl: ytItem?.coverImage || "/images/themes/theme_aurora.jpg" },
    ],
    files: [
      { id: "f_ar", kind: "file", label: "الترجمة العربية", ext: "srt", codec: "SRT", detail: "عربي كامل", bytes: 42_880, isExact: true, directUrl: normalized },
      { id: "f_en", kind: "file", label: "الترجمة الإنجليزية", ext: "vtt", codec: "WebVTT", detail: "English", bytes: 38_120, isExact: true, directUrl: normalized },
    ],
  };
}

export const INITIAL_LOCAL_TRACKS: LocalMediaTrack[] = [
  {
    id: "loc_1",
    title: "ليل القاهرة — عود وبيانو",
    artist: "موجة مزيكا",
    album: "جلسات النيل",
    kind: "audio",
    durationSec: 214,
    sizeBytes: 34_812_900,
    ext: "FLAC",
    coverImage: "/images/themes/theme_sunset.jpg",
    accent: "#F59E0B",
    toneSeed: 3,
    isFavorite: true,
  },
  {
    id: "loc_2",
    title: "نسيم البحر في دهب",
    artist: "سكينة وهدوء",
    album: "صفاء",
    kind: "audio",
    durationSec: 186,
    sizeBytes: 11_420_160,
    ext: "MP3",
    coverImage: "/images/themes/theme_ocean.jpg",
    accent: "#0EA5E9",
    toneSeed: 4,
    isFavorite: true,
  },
  {
    id: "loc_3",
    title: "شفق الشمال — معزوفة هادية",
    artist: "أورورا ستوديو",
    album: "جلسات النيل",
    kind: "audio",
    durationSec: 168,
    sizeBytes: 9_890_400,
    ext: "OPUS",
    coverImage: "/images/themes/theme_aurora.jpg",
    accent: "#4285F4",
    toneSeed: 1,
  },
  {
    id: "loc_4",
    title: "رحلة الشفق القطبي 4K HDR",
    artist: "حكاية الكوكب",
    album: "فيديوهاتي",
    kind: "video",
    durationSec: 245,
    sizeBytes: 148_372_910,
    ext: "MP4",
    coverImage: "/images/themes/theme_aurora.jpg",
    accent: "#9B72CB",
    toneSeed: 2,
  },
  {
    id: "loc_5",
    title: "غروب سيوة الساحر 60fps",
    artist: "حكاية الكوكب",
    album: "فيديوهاتي",
    kind: "video",
    durationSec: 192,
    sizeBytes: 96_512_000,
    ext: "MKV",
    coverImage: "/images/themes/theme_emerald.jpg",
    accent: "#10B981",
    toneSeed: 5,
  },
];
