export type ThemeId = "aurora" | "ocean" | "sunset" | "emerald" | "mono" | "neon";
export type MotionPreset = "spring" | "snappy" | "calm";
export type MediaKind = "video" | "audio" | "image" | "file";
export type AppTab = "home" | "youtube" | "downloads" | "files" | "tools" | "settings";

export interface JoThemeSpec {
  id: ThemeId;
  name: string;
  desc: string;
  image: string;
  darkBg: string;
  darkBg2: string;
  accent1: string;
  accent2: string;
  accent3: string;
  blurPx: number;
  spring: string;
  speedMs: number;
  ambientSec: number;
}

export interface MediaOption {
  id: string;
  kind: MediaKind;
  label: string;
  ext: string;
  codec: string;
  detail: string;
  bytes: number;
  isExact: boolean;
  dashMerge?: boolean;
  directUrl: string;
}

export interface AnalyzedLink {
  url: string;
  domain: string;
  siteName: string;
  siteColor: string;
  title: string;
  fileName: string;
  uploader: string;
  durationSec: number;
  coverImage: string;
  coverAccent: string;
  stage: number;
  isComplete: boolean;
  drmBlocked?: boolean;
  needsSniffer?: boolean;
  videos: MediaOption[];
  audios: MediaOption[];
  images: MediaOption[];
  files: MediaOption[];
}

export type DownloadStatus = "running" | "queued" | "paused" | "merging" | "completed" | "failed";

export interface SegmentSlice {
  id: number;
  progress: number; // 0..1
  stolen?: boolean;
}

export interface DownloadTask {
  id: string;
  title: string;
  fileName: string;
  sourceUrl: string;
  kind: MediaKind;
  ext: string;
  codec: string;
  totalBytes: number;
  isExact: boolean;
  downloadedBytes: number;
  speedBps: number;
  speedHistory: number[];
  connections: number;
  segments: SegmentSlice[];
  dashMerge: boolean;
  status: DownloadStatus;
  wifiOnly: boolean;
  scheduledTime?: string;
  sha256?: string;
  createdAt: number;
}

export interface ChannelInfo {
  id: string;
  name: string;
  handle: string;
  subsLabel: string;
  color: string;
  category: string;
}

export interface YouTubeItem {
  id: string;
  url: string;
  title: string;
  channelId: string;
  channelName: string;
  channelColor: string;
  category: string;
  tags: string[];
  durationSec: number;
  views: number;
  uploadedAr: string;
  coverImage: string;
  accent: string;
  toneSeed: number;
  isShort?: boolean;
  description: string;
}

export interface LocalProfile {
  displayName: string;
  handle: string;
  bio: string;
  avatarColor: string;
  subscribedIds: string[];
  likedIds: string[];
  savedIds: string[];
  watchHistoryIds: string[];
  searchHistory: string[];
  categoryWeights: Record<string, number>;
}

export interface LocalMediaTrack {
  id: string;
  title: string;
  artist: string;
  album: string;
  kind: "audio" | "video";
  durationSec: number;
  sizeBytes: number;
  ext: string;
  coverImage: string;
  accent: string;
  toneSeed: number;
  objectUrl?: string; // Real user-imported local file blob URL
  isFavorite?: boolean;
  isRingtone?: boolean;
  isTrimmed?: boolean;
  inVault?: boolean;
  trimRange?: [number, number]; // [startSec, endSec]
}

export interface AppSettings {
  themeId: ThemeId;
  darkMode: boolean;
  blurScale: number;
  motionPreset: MotionPreset;
  connections: number;
  maxConcurrent: number;
  speedLimitMbps: number; // 0 = unlimited
  wifiOnly: boolean;
  enableDoh: boolean;
  clipboardWatch: boolean;
  adBlockEnabled: boolean;
  adBlockWhitelist: string[];
  activeRingtoneName: string;
  vaultPin: string;
  savedByCompressorBytes: number;
}
