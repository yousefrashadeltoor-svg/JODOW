package com.auroraget.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.auroraget.app.ui.theme.AuroraShapes
import com.auroraget.app.ui.theme.AuroraType
import com.auroraget.app.ui.theme.LocalAuroraColors

/* ── Glass surfaces ─────────────────────────────────────────────────────── */

@Composable
fun AuroraGlass(
    modifier: Modifier = Modifier,
    radius: Dp = 26.dp,
    strong: Boolean = false,
    content: @Composable BoxScope.() -> Unit,
) {
    val c = LocalAuroraColors.current
    val shape = RoundedCornerShape(radius)
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(
                        if (strong) c.glassStrong else c.glass,
                        c.glass.copy(alpha = if (c.isLight) 0.55f else 0.03f),
                    )
                )
            )
            .border(1.dp, c.line, shape)
            .drawWithContent {
                drawContent()
                // specular inner top edge + subtle noise
                drawLine(
                    brush = Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.28f), Color.Transparent)),
                    start = Offset(12f, 1f),
                    end = Offset(size.width - 12f, 1f),
                    strokeWidth = 1.2f,
                )
                var y = 9f
                while (y < size.height) {
                    var x = 9f
                    while (x < size.width) {
                        drawCircle(
                            color = if (c.isLight) Color.Black.copy(alpha = 0.02f) else Color.White.copy(alpha = 0.035f),
                            radius = 0.8f,
                            center = Offset(x, y),
                        )
                        x += 17f
                    }
                    y += 17f
                }
            },
        content = content,
    )
}

@Composable
fun AuroraTag(
    text: String,
    color: Color = LocalAuroraColors.current.accent2,
    filled: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val c = LocalAuroraColors.current
    Box(
        modifier = modifier
            .clip(AuroraShapes.chip)
            .background(if (filled) color.copy(alpha = 0.16f) else Color.Transparent)
            .border(1.dp, if (filled) color.copy(alpha = 0.32f) else c.line, AuroraShapes.chip)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        BasicText(text, style = AuroraType.caption.copy(color = color, fontSize = 9.5.sp))
    }
}

@Composable
fun AuroraButton(
    text: String,
    modifier: Modifier = Modifier,
    primary: Boolean = true,
    enabled: Boolean = true,
    icon: (@Composable () -> Unit)? = null,
    onClick: () -> Unit,
) {
    val c = LocalAuroraColors.current
    val shape = AuroraShapes.button
    Row(
        modifier = modifier
            .height(44.dp)
            .clip(shape)
            .then(
                if (primary) Modifier.background(Brush.horizontalGradient(c.accents))
                else Modifier.background(c.glass).border(1.dp, c.line, shape)
            )
            .pointerInput(enabled) {
                if (enabled) detectTapGestures { onClick() }
            }
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) {
            icon()
            Spacer(Modifier.width(7.dp))
        }
        BasicText(
            text,
            style = AuroraType.label.copy(
                color = if (primary) Color.White else c.textPrimary,
                fontSize = 12.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun AuroraToggle(on: Boolean, onChange: (Boolean) -> Unit, label: String) {
    val c = LocalAuroraColors.current
    val transition = rememberInfiniteTransition(label = "toggle")
    val glow by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing)),
        label = "toggleGlow",
    )
    Box(
        Modifier
            .size(width = 44.dp, height = 26.dp)
            .clip(AuroraShapes.chip)
            .background(if (on) Brush.horizontalGradient(c.accents) else SolidColor(c.glassStrong))
            .border(1.dp, c.line, AuroraShapes.chip)
            .semantics { contentDescription = label }
            .toggleable(value = on, role = Role.Switch, onValueChange = onChange)
            .padding(3.dp),
        contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart,
    ) {
        Box(
            Modifier
                .size(20.dp)
                .clip(AuroraShapes.chip)
                .background(if (on) Color.White else c.textTertiary.copy(alpha = glow))
        )
    }
}

@Composable
fun AuroraProgress(value: Float, modifier: Modifier = Modifier, color: Color? = null) {
    val c = LocalAuroraColors.current
    val transition = rememberInfiniteTransition(label = "progress")
    val shift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "progressShift",
    )
    Canvas(modifier = modifier.fillMaxWidth().height(5.dp)) {
        drawRoundRect(color = c.line, cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2))
        val w = size.width * value.coerceIn(0f, 1f)
        if (w > 0f) {
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = color?.let { listOf(it, it) } ?: c.accents,
                    startX = shift * size.width - size.width,
                    endX = shift * size.width + size.width,
                ),
                size = Size(w, size.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2),
            )
        }
    }
}

@Composable
fun AuroraRing(progress: Float, size: Dp = 44.dp, label: String? = null) {
    val c = LocalAuroraColors.current
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 4.dp.toPx()
            drawArc(
                color = c.line,
                startAngle = -90f, sweepAngle = 360f, useCenter = false,
                topLeft = Offset(stroke / 2, stroke / 2),
                size = Size(this.size.width - stroke, this.size.height - stroke),
                style = Stroke(stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round),
            )
            drawArc(
                brush = Brush.sweepGradient(c.accents),
                startAngle = -90f, sweepAngle = 360f * progress.coerceIn(0f, 1f), useCenter = false,
                topLeft = Offset(stroke / 2, stroke / 2),
                size = Size(this.size.width - stroke, this.size.height - stroke),
                style = Stroke(stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round),
            )
        }
        BasicText(label ?: "${(progress * 100).toInt()}%", style = AuroraType.caption.copy(color = c.textPrimary, fontSize = 9.sp))
    }
}

@Composable
fun GradientTitle(text: String, modifier: Modifier = Modifier, style: TextStyle = AuroraType.display) {
    val c = LocalAuroraColors.current
    val brush = Brush.horizontalGradient(c.accents)
    androidx.compose.foundation.text.BasicText(
        text = text,
        modifier = modifier,
        style = style.copy(brush = brush, color = c.textPrimary),
        maxLines = 2,
    )
}

/* ── Gemini-style glow paste field ──────────────────────────────────────── */

@Composable
fun GlowPasteField(
    url: String,
    analyzing: Boolean,
    onUrlChange: (String) -> Unit,
    onAnalyze: () -> Unit,
    onPaste: () -> Unit,
    onQr: () -> Unit,
    onBrowser: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = LocalAuroraColors.current
    val rotate = rememberInfiniteTransition(label = "glow")
    val angle by rotate.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (analyzing) 2600 else 8000, easing = LinearEasing)),
        label = "glowAngle",
    )
    val shape = RoundedCornerShape(28.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .drawBehind {
                drawRoundRect(brush = Brush.sweepGradient(listOf(Color.Transparent, c.accent1, c.accent2, c.accent3, Color.Transparent)))
            }
            .drawBehind {
                rotate(angle) {
                    drawRoundRect(
                        brush = Brush.sweepGradient(c.accents + c.accent1),
                        style = Stroke(width = 2.2f)
                    )
                }
            }
            .padding(2.dp)
            .clip(shape)
            .background(if (c.isLight) c.glassStrong else Color(0xF20D1220))
            .border(1.dp, c.line, shape)
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                BasicText("رابط جديد", style = AuroraType.caption.copy(color = c.textSecondary))
                Spacer(Modifier.weight(1f))
                AuroraTag("خصوصية كاملة · محلي", color = c.success, filled = true)
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(AuroraShapes.field)
                    .background(c.field)
                    .border(1.dp, c.line, AuroraShapes.field)
                    .padding(horizontal = 10.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val focus = LocalFocusManager.current
                BasicTextField(
                    value = url,
                    onValueChange = onUrlChange,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = AuroraType.label.copy(color = c.textPrimary, fontSize = 11.sp),
                    cursorBrush = SolidColor(c.accent2),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { focus.clearFocus(); onAnalyze() }),
                    decorationBox = { inner ->
                        Box {
                            if (url.isEmpty()) {
                                BasicText("الصق رابط الفيديو أو الملف هنا…", style = AuroraType.caption.copy(color = c.textTertiary))
                            }
                            inner()
                        }
                    },
                )
                AuroraTag("URL", color = c.textSecondary)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    AuroraButton(
                        text = if (analyzing) "جاري التحليل…" else "تحليل الرابط",
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onAnalyze,
                    )
                }
                AuroraIconButton("لصق", onPaste)
                AuroraIconButton("QR", onQr)
                AuroraIconButton("متصفح", onBrowser)
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                BasicText(
                    if (analyzing) "تهيئة المحرك ثم قراءة الترويسات…" else "يدعم YouTube وTikTok و1800+ موقع",
                    style = AuroraType.caption.copy(color = c.textTertiary, fontSize = 8.5.sp),
                )
                Spacer(Modifier.weight(1f))
                AuroraTag(if (analyzing) "IO · Parallel" else "Ready", color = if (analyzing) c.accent2 else c.success)
            }
        }
    }
}

/** Dependency-free icon button: a glass square with a short glyph. */
@Composable
fun AuroraIconButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = LocalAuroraColors.current
    Box(
        modifier = modifier
            .size(42.dp)
            .clip(AuroraShapes.icon)
            .background(c.glassStrong)
            .border(1.dp, c.line, AuroraShapes.icon)
            .pointerInput(label) { detectTapGestures { onClick() } }
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        BasicText(
            text = when (label) {
                "لصق" -> "⧉"
                "QR" -> "▦"
                "متصفح" -> "◎"
                else -> label.take(1)
            },
            style = AuroraType.label.copy(color = c.textSecondary, fontSize = 15.sp),
        )
    }
}

/* ── Sheet & dock ───────────────────────────────────────────────────────── */

@Composable
fun AuroraSheet(
    title: String,
    subtitle: String? = null,
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    val c = LocalAuroraColors.current
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.6f))
                .pointerInput(Unit) { detectTapGestures { onDismiss() } }
        )
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .clip(AuroraShapes.sheet)
                .background(if (c.isLight) c.glassStrong else Color(0xFF0A0E18))
                .border(1.dp, c.line, AuroraShapes.sheet)
                .padding(horizontal = 18.dp, vertical = 12.dp),
        ) {
            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .size(width = 40.dp, height = 4.dp)
                    .clip(AuroraShapes.chip)
                    .background(c.lineStrong)
            )
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    BasicText(title, style = AuroraType.heading.copy(color = c.textPrimary))
                    if (subtitle != null) {
                        BasicText(subtitle, style = AuroraType.caption.copy(color = c.textSecondary), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                AuroraIconButton("إغلاق", onDismiss)
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun AuroraDock(
    items: List<Pair<String, String>>,
    selected: Int,
    onSelect: (Int) -> Unit,
    badge: Int = 0,
) {
    val c = LocalAuroraColors.current
    Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp), contentAlignment = Alignment.BottomCenter) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(AuroraShapes.dock)
                .background(if (c.isLight) c.glassStrong else Color(0xEE0A0E18))
                .border(1.dp, c.line, AuroraShapes.dock)
                .padding(horizontal = 6.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            items.forEachIndexed { i, item ->
                val active = selected == i
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(AuroraShapes.icon)
                        .then(if (active) Modifier.background(c.accentSoft) else Modifier)
                        .pointerInput(i) { detectTapGestures { onSelect(i) } }
                        .padding(vertical = 5.dp)
                        .semantics { contentDescription = item.first },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    BasicText(item.second, style = AuroraType.label.copy(color = if (active) c.accent2 else c.textTertiary, fontSize = 15.sp))
                    BasicText(item.first, style = AuroraType.caption.copy(color = if (active) c.textPrimary else c.textTertiary, fontSize = 8.5.sp))
                    if (i == 1 && badge > 0) {
                        AuroraTag("$badge", color = c.accent3, filled = true)
                    }
                }
            }
        }
    }
}

@Composable
fun StatTile(label: String, value: String, hint: String? = null, accent: Color = LocalAuroraColors.current.accent2) {
    val c = LocalAuroraColors.current
    AuroraGlass(Modifier.fillMaxWidth(), radius = 16.dp) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            BasicText(label, style = AuroraType.caption.copy(color = c.textTertiary, fontSize = 8.5.sp))
            BasicText(value, style = AuroraType.heading.copy(color = c.textPrimary, fontSize = 17.sp))
            if (hint != null) BasicText(hint, style = AuroraType.caption.copy(color = accent, fontSize = 8.sp))
        }
    }
}

@Composable
fun ScreenHeader(eyebrow: String, title: String, accent: Color = LocalAuroraColors.current.accent2) {
    val c = LocalAuroraColors.current
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        BasicText(eyebrow, style = AuroraType.caption.copy(color = accent, fontSize = 9.5.sp))
        BasicText(title, style = AuroraType.title.copy(color = c.textPrimary))
    }
}

