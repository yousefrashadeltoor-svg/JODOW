package com.auroraget.app.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.auroraget.app.data.ContentType
import com.auroraget.app.data.DownloadRequest
import com.auroraget.app.data.MediaFormat
import com.auroraget.app.data.formatBytes
import com.auroraget.app.engine.NetworkClient
import com.auroraget.app.ui.components.AuroraButton
import com.auroraget.app.ui.components.AuroraGlass
import com.auroraget.app.ui.components.AuroraIconButton
import com.auroraget.app.ui.components.AuroraSheet
import com.auroraget.app.ui.components.AuroraTag
import com.auroraget.app.ui.theme.AuroraShapes
import com.auroraget.app.ui.theme.AuroraType
import com.auroraget.app.ui.theme.LocalAuroraColors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.Cookie
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.json.JSONObject
import java.io.ByteArrayInputStream

private val BLOCKED_HOSTS = listOf(
    "doubleclick.net", "googlesyndication.com", "googleadservices.com",
    "adservice.google.com", "adnxs.com", "taboola.com", "outbrain.com",
    "scorecardresearch.com", "popads.net", "propellerads.com",
)

private val MEDIA_EXTENSIONS = listOf(
    ".mp4", ".mkv", ".webm", ".mov", ".m3u8", ".mpd", ".mp3", ".m4a",
    ".opus", ".flac", ".wav", ".jpg", ".jpeg", ".png", ".webp", ".zip",
    ".apk", ".pdf", ".srt", ".vtt", ".json",
)

data class SniffedMedia(val url: String, val type: ContentType, val bytes: Long?, val approx: Boolean, val format: String) {
    val filename: String get() = url.substringBefore('?').substringAfterLast('/').ifBlank { "aurora_media" }
}

/**
 * Real in-app browser + media sniffer.
 *
 * - WebView renders Cloudflare/Turnstile JS challenges; cookies are harvested
 *   back into OkHttp after each page (the legitimate, browser-cookie approach).
 * - `shouldInterceptRequest` captures media and blocks known ad/tracker hosts.
 * - Injected script hooks fetch/XHR to surface blob and manifest URLs.
 * - Downloads hand off to the segmented Aurora engine with UA/Referer/Cookie.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(
    startUrl: String,
    langArabic: Boolean,
    onDownload: (DownloadRequest) -> Unit,
) {
    val c = LocalAuroraColors.current
    var address by remember { mutableStateOf(startUrl.ifBlank { "https://www.youtube.com" }) }
    var current by remember { mutableStateOf(address) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var loading by remember { mutableStateOf(false) }
    var snifferOpen by remember { mutableStateOf(false) }
    var blocked by remember { mutableStateOf(0) }
    val caught = remember { mutableStateListOf<SniffedMedia>() }
    val cookies = remember { arrayListOf<String>() }

    fun syncCookies(target: String?) {
        target ?: return
        val manager = CookieManager.getInstance()
        val cookie = manager.getCookie(target) ?: return
        cookies.clear()
        cookie.split(";").map { it.trim() }.filter { it.contains("=") }.forEach { pair ->
            val name = pair.substringBefore("=")
            val value = pair.substringAfter("=")
            if (HttpUrlOrNullEquals(target)) {
                NetworkClient.cookies.saveFromResponse(
                    target.toHttpUrlOrNull() ?: return@forEach,
                    listOf(Cookie.Builder().domain(target.toHttpUrlOrNull()!!.host).name(name).value(value).path("/").build()),
                )
            }
        }
    }

    fun add(url: String?, mime: String? = null) {
        url ?: return
        if (url.startsWith("blob:") || url.startsWith("data:")) return
        val existing = caught.any { it.url == url }
        if (existing) return
        val extension = url.substringBefore('?').substringAfterLast('.', "").lowercase()
        val type = when {
            mime?.startsWith("video") == true -> ContentType.VIDEO
            mime?.startsWith("audio") == true -> ContentType.AUDIO
            mime?.startsWith("image") == true -> ContentType.IMAGE
            extension in listOf("m3u8", "mpd", "mp4", "mkv", "webm", "mov") -> ContentType.VIDEO
            extension in listOf("mp3", "m4a", "opus", "flac", "wav") -> ContentType.AUDIO
            extension in listOf("jpg", "jpeg", "png", "webp", "gif") -> ContentType.IMAGE
            else -> ContentType.FILE
        }
        val cookie = CookieManager.getInstance().getCookie(url)
        val request = NetworkClient.requestBuilder(url, buildMap {
            put("Referer", current)
            if (!cookie.isNullOrBlank()) put("Cookie", cookie)
        }).head().build()
        CoroutineScope(Dispatchers.IO).launch {
            val probe = runCatching {
                NetworkClient.client.newCall(request).execute().use {
                    val length = it.header("Content-Length")?.toLongOrNull()
                    Triple(length, it.header("ETag"), it.header("Accept-Ranges") == "bytes")
                }
            }.getOrNull()
            caught.add(
                SniffedMedia(
                    url = url,
                    type = type,
                    bytes = probe?.first,
                    approx = probe?.first == null,
                    format = extension.uppercase().ifBlank { mime?.substringBefore('/') ?: "FILE" },
                )
            )
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                ScreenHeader("متصفح داخلي + صيّاد ملفات", "اصطد ما تريد", c.accent2)
                Spacer(Modifier.weight(1f))
                AuroraTag("AdBlock $blocked", color = c.success, filled = true)
            }
            Spacer(Modifier.height(9.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(
                    value = address,
                    onValueChange = { address = it },
                    singleLine = true,
                    textStyle = AuroraType.label.copy(color = c.textPrimary, fontSize = 11.sp),
                    cursorBrush = SolidColor(c.accent2),
                    modifier = Modifier
                        .weight(1f)
                        .clip(AuroraShapes.field)
                        .background(c.field)
                        .border(1.dp, c.line, AuroraShapes.field)
                        .padding(horizontal = 10.dp, vertical = 9.dp),
                )
                Spacer(Modifier.size(5.dp))
                AuroraButton("اذهب", primary = true) {
                    val url = if (address.startsWith("http")) address else "https://$address"
                    current = url
                    webView?.loadUrl(url)
                }
            }
            Spacer(Modifier.height(8.dp))
            AuroraGlass(Modifier.weight(1f), radius = 20.dp) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        WebView(context).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.databaseEnabled = true
                            settings.mediaPlaybackRequiresUserGesture = false
                            settings.loadWithOverviewMode = true
                            settings.useWideViewPort = true
                            settings.cacheMode = WebSettings.LOAD_DEFAULT
                            settings.userAgentString = NetworkClient.DESKTOP_UA
                            CookieManager.getInstance().setAcceptCookie(true)
                            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                                    loading = true
                                    url?.let { address = it; current = it }
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    loading = false
                                    url?.let { address = it; current = it; syncCookies(it) }
                                    view?.evaluateJavascript(BRIDGE_SCRIPT, null)
                                }

                                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                                    val url = request?.url?.toString() ?: return null
                                    val host = runCatching { request.url.host.orEmpty() }.getOrDefault("")
                                    if (BLOCKED_HOSTS.any { host.endsWith(it) }) {
                                        blocked += 1
                                        return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                                    }
                                    if (MEDIA_EXTENSIONS.any { url.substringBefore('?').endsWith(it, true) }) {
                                        add(url, request.requestHeaders["Accept"])
                                    }
                                    return null
                                }
                            }
                            setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                                add(url, mimeType)
                                syncCookies(url)
                                val name = contentDisposition
                                    ?.substringAfter("filename=", "")
                                    ?.trim('"', ' ')
                                    ?.takeIf { it.isNotBlank() }
                                    ?: url.substringBefore('?').substringAfterLast('/')
                                onDownload(
                                    DownloadRequest(
                                        url = url,
                                        name = name.ifBlank { "aurora_file" },
                                        site = Uri.parse(url).host ?: "browser",
                                        type = if (mimeType.startsWith("video")) ContentType.VIDEO else ContentType.FILE,
                                        quality = "$mimeType · ${userAgent.take(18)}",
                                        totalBytes = 0,
                                        approx = true,
                                        headers = buildMap {
                                            put("User-Agent", userAgent)
                                            put("Referer", webView?.url ?: current)
                                            CookieManager.getInstance().getCookie(url)?.let { put("Cookie", it) }
                                        },
                                    )
                                )
                            }
                            loadUrl(current)
                        }
                    },
                    update = { view -> webView = view },
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                AuroraButton("صيّاد الملفات (${caught.size})") { snifferOpen = true }
                Spacer(Modifier.weight(1f))
                AuroraIconButton("↻") { webView?.reload() }
                Spacer(Modifier.size(5.dp))
                AuroraIconButton("⌂") { current = "https://www.youtube.com"; webView?.loadUrl(current) }
            }
            Spacer(Modifier.height(86.dp))
            Txt(
                if (langArabic) "الكوكيز وUA وReferer تنتقل تلقائيًا إلى محرك Aurora." else "Cookies, UA and Referer are transferred to the Aurora engine.",
                style = AuroraType.caption,
                color = c.textTertiary,
            )
            Spacer(Modifier.height(6.dp))
        }

        if (loading) {
            Box(Modifier.align(Alignment.TopCenter).padding(top = 96.dp)) {
                AuroraTag("جارٍ التحميل…", color = c.accent2, filled = true)
            }
        }

        if (snifferOpen) {
            AuroraSheet(
                title = "الملفات المكتشفة (${caught.size})",
                subtitle = "شبكة + JavaScript · Cloudflare داخل WebView",
                onDismiss = { snifferOpen = false },
            ) {
                if (caught.isEmpty()) {
                    Txt("لم يُلتقط أي ملف بعد — تصفّح الصفحة أو شغّل المعاينة.", style = AuroraType.caption, color = c.textSecondary)
                }
                caught.take(8).forEach { media ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AuroraTag(media.format, color = c.accent2)
                        Spacer(Modifier.size(7.dp))
                        Column(Modifier.weight(1f)) {
                            Txt(media.filename, style = AuroraType.label, maxLines = 1)
                            Txt(
                                if (media.approx) "≈ ${media.bytes?.let { formatBytes(it, true) } ?: "حجم غير مؤكد"}"
                                else formatBytes(media.bytes ?: 0),
                                style = AuroraType.caption,
                                color = if (media.approx) c.warning else c.success,
                            )
                        }
                        AuroraButton("تحميل") {
                            val cookie = CookieManager.getInstance().getCookie(media.url)
                            onDownload(
                                DownloadRequest(
                                    url = media.url,
                                    name = media.filename,
                                    site = Uri.parse(media.url).host ?: "browser",
                                    type = media.type,
                                    quality = media.format,
                                    totalBytes = media.bytes ?: 0,
                                    approx = media.approx,
                                    headers = buildMap {
                                        put("Referer", current)
                                        put("Origin", "https://${Uri.parse(current).host ?: ""}")
                                        if (!cookie.isNullOrBlank()) put("Cookie", cookie)
                                    },
                                )
                            )
                            snifferOpen = false
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Txt(
                    "لا يتجاوز التطبيق أي DRM أو Paywall. الكوكيز تُنقل بالطريقة المشروعة عبر متصفح فعلي.",
                    style = AuroraType.caption,
                    color = c.warning,
                )
            }
        }
    }
}

private fun HttpUrlOrNullEquals(target: String): Boolean = target.toHttpUrlOrNull() != null

private const val BRIDGE_SCRIPT = """
(function() {
  if (window.__auroraHooked) return;
  window.__auroraHooked = true;
  const send = (u) => { try { AuroraBridge?.onMedia(typeof u === 'string' ? u : ''); } catch (e) {} };
  const of = window.fetch;
  window.fetch = function(input, init) {
    try { send(typeof input === 'string' ? input : (input && input.url)); } catch (e) {}
    return of.apply(this, arguments);
  };
  const oo = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(method, url) {
    try { send(url); } catch (e) {}
    return oo.apply(this, arguments);
  };
  document.addEventListener('loadedmetadata', function(e) {
    const el = e.target;
    if (el && (el.tagName === 'VIDEO' || el.tagName === 'AUDIO')) send(el.currentSrc || el.src);
  }, true);
  document.querySelectorAll('video, audio, source').forEach(function(el) {
    send(el.currentSrc || el.src);
  });
})();
"""
