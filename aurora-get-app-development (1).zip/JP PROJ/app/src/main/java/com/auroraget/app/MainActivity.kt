package com.auroraget.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import com.auroraget.app.ui.AuroraApp
import com.auroraget.app.ui.theme.AuroraTheme
import com.auroraget.app.ui.theme.AuroraThemeId

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val sharedLink = extractSharedLink()
        val shortcut = intent?.getStringExtra("shortcut")
        setContent {
            var themeId by remember { mutableStateOf(AuroraThemeId.AURORA) }
            var light by remember { mutableStateOf(false) }
            AuroraTheme(theme = themeId, light = light) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AuroraApp(
                        sharedLink = sharedLink,
                        shortcut = shortcut,
                        onThemeChange = { themeId = it },
                        onAppearanceChange = { light = it },
                    )
                }
            }
        }
    }

    private fun extractSharedLink(): String? {
        val intent = intent ?: return null
        return when (intent.action) {
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> intent.dataString
            else -> null
        }
    }
}
