package com.auroraget.app.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.auroraget.app.MainActivity
import com.auroraget.app.engine.NetworkClient
import com.auroraget.app.engine.SizeProbe
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile

private const val TAG = "AuroraDownloader"
const val DOWNLOAD_CHANNEL_ID = "aurora_downloads"

data class DownloadRequest(
    val url: String,
    val name: String,
    val site: String,
    val type: ContentType,
    val quality: String,
    val totalBytes: Long,
    val approx: Boolean,
    val headers: Map<String, String> = emptyMap(),
    val needsMerge: Boolean = false,
)

data class DownloadProgress(
    val id: String,
    val progress: Float,
    val bytesPerSecond: Long,
    val activeConnections: Int,
    val status: DownloadStatus,
)

/**
 * Segmented, resumable download engine.
 *
 * - 8..32 parallel range workers; each worker owns a byte window and writes it
 *   straight into a pre-allocated file with RandomAccessFile.
 * - Every window is persisted in Room with ETag / Last-Modified so a resumed
 *   download can validate the remote object with If-Range before continuing.
 * - Servers without byte ranges gracefully fall back to one connection.
 * - 403/410 surfaces as FAILED so the analyzer can re-extract a fresh URL.
 */
class DownloadRepository(
    private val context: Context,
    private val dao: DownloadDao,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json = Json { ignoreUnknownKeys = true }
    private val progress = MutableStateFlow<Map<String, DownloadProgress>>(emptyMap())
    private val jobs = mutableMapOf<String, Job>()

    val allDownloads: Flow<List<DownloadEntity>> = dao.observeAll()
    val progressFlow = progress.asStateFlow()

    fun outputDir(type: ContentType): File {
        val root = File(context.getExternalFilesDir(null) ?: context.filesDir, "Aurora")
        val folder = when (type) {
            ContentType.VIDEO -> "Video"
            ContentType.AUDIO -> "Audio"
            ContentType.IMAGE -> "Images"
            ContentType.FILE -> "Files"
        }
        return File(root, folder).apply { mkdirs() }
    }

    suspend fun prepare(request: DownloadRequest, connectionTarget: Int = 16): String = withContext(Dispatchers.IO) {
        val id = "dl_" + System.currentTimeMillis().toString(36)
        val probe: SizeProbe = runCatching {
            NetworkClient.client.newCall(NetworkClient.requestBuilder(request.url, request.headers).head().build()).execute().use {
                SizeProbe(
                    bytes = it.header("Content-Length")?.toLongOrNull(),
                    approx = it.header("Content-Length") == null,
                    etag = it.header("ETag"),
                    lastModified = it.header("Last-Modified"),
                    acceptsRanges = it.header("Accept-Ranges") == "bytes",
                )
            }
        }.getOrDefault(SizeProbe(request.totalBytes, request.approx, null, null, false))

        val total = probe.bytes ?: request.totalBytes
        val supportsRanges = probe.acceptsRanges && total > 0
        val connections = if (supportsRanges) connectionTarget.coerceIn(8, 32) else 1
        val entity = DownloadEntity(
            id = id,
            url = request.url,
            name = request.name,
            site = request.site,
            type = request.type,
            quality = request.quality,
            totalBytes = total,
            approx = if (probe.bytes != null) probe.approx else request.approx,
            connections = connections,
            status = DownloadStatus.QUEUED,
            etag = probe.etag,
            lastModified = probe.lastModified,
            acceptsRanges = supportsRanges,
            headersJson = org.json.JSONObject(request.headers.toMap()).toString(),
            outputPath = File(outputDir(request.type), request.name).absolutePath,
        )
        val segments = if (total > 0) split(total, connections) else emptyList()
        dao.upsert(entity)
        dao.upsertSegments(segments.mapIndexed { index, pair ->
            SegmentEntity(downloadId = id, segmentIndex = index, start = pair.first, end = pair.second)
        })
        id
    }

    suspend fun enqueue(request: DownloadRequest, connectionTarget: Int = 16, autoStart: Boolean = true): String {
        val id = prepare(request, connectionTarget)
        if (autoStart) start(id)
        return id
    }

    fun start(id: String) {
        if (jobs[id]?.isActive == true) return
        jobs[id] = scope.launch {
            runCatching { execute(id) }
                .onFailure {
                    Log.e(TAG, "download $id failed", it)
                    dao.updateState(id, DownloadStatus.FAILED, 0, it.message)
                }
        }
    }

    fun pause(id: String) {
        jobs[id]?.cancel()
        jobs.remove(id)
        scope.launch { dao.updateStatus(id, DownloadStatus.PAUSED) }
    }

    fun cancel(id: String) {
        jobs[id]?.cancel()
        jobs.remove(id)
        scope.launch { dao.remove(id) }
    }

    fun retry(id: String) {
        scope.launch {
            dao.updateStatus(id, DownloadStatus.QUEUED)
            start(id)
        }
    }

    private suspend fun execute(id: String) = withContext(Dispatchers.IO) {
        val entity = dao.find(id) ?: return@withContext
        val segments = dao.segments(id)
        val file = File(entity.outputPath.ifBlank { File(outputDir(entity.type), entity.name).absolutePath })
        file.parentFile?.mkdirs()
        dao.updateStatus(id, DownloadStatus.DOWNLOADING)
        val total = if (entity.totalBytes > 0) entity.totalBytes else file.length()
        val perWorker = Semaphore(8)
        var lastTick = System.currentTimeMillis()
        var bytesAtTick = segments.sumOf { it.written }

        try {
            if (segments.isEmpty()) {
                streamSingle(entity, file) { written, speed ->
                    publish(entity, written, total, speed, 1, DownloadStatus.DOWNLOADING)
                    scope.launch { dao.updateState(id, DownloadStatus.DOWNLOADING, written) }
                }
            } else {
                RandomAccessFile(file, "rw").use { raf -> if (total > 0) raf.setLength(total) }
                coroutineScope {
                    segments.filterNot { it.completed }.map { segment ->
                        async(Dispatchers.IO) {
                            perWorker.withPermit {
                                try {
                                    downloadSegment(entity, segment, file) { writtenTotal, speed, connections ->
                                        publish(entity, writtenTotal, total, speed, connections, DownloadStatus.DOWNLOADING)
                                        val now = System.currentTimeMillis()
                                        if (now - lastTick > 1200) {
                                            lastTick = now
                                            scope.launch {
                                                dao.updateState(id, DownloadStatus.DOWNLOADING, writtenTotal)
                                            }
                                        }
                                    }
                                } catch (t: Throwable) {
                                    if (t is kotlinx.coroutines.CancellationException) throw t
                                    dao.updateState(id, DownloadStatus.FAILED, 0, t.message)
                                    throw t
                                }
                            }
                        }
                    }.awaitAll()
                }
                bytesAtTick = segments.sumOf { it.written }
            }
            val finalLength = file.length()
            dao.updateStatus(id, DownloadStatus.COMPLETED)
            dao.updateState(id, DownloadStatus.COMPLETED, finalLength)
            publish(entity, finalLength, finalLength, 0, 0, DownloadStatus.COMPLETED)
            notifyProgress(entity, 100, DownloadStatus.COMPLETED)
            Log.i(TAG, "completed $id ($finalLength bytes, resumed from $bytesAtTick)")
        } catch (t: Throwable) {
            if (t is kotlinx.coroutines.CancellationException) throw t
            publish(entity, entity.downloadedBytes, total, 0, 0, DownloadStatus.FAILED)
            notifyProgress(entity, 0, DownloadStatus.FAILED)
            throw t
        }
    }

    private suspend fun downloadSegment(
        entity: DownloadEntity,
        segment: SegmentEntity,
        file: File,
        onProgress: suspend (Long, Long, Int) -> Unit,
    ) = withContext(Dispatchers.IO) {
        val rangeStart = segment.start + segment.written
        if (rangeStart > segment.end) {
            dao.upsertSegment(segment.copy(written = segment.end - segment.start + 1, completed = true))
            return@withContext
        }
        val headers = runCatching {
            json.parseToJsonElement(entity.headersJson).let { element ->
                (element as? JsonObject)?.entries?.associate { (k, v) -> k to v.jsonPrimitive.content } ?: emptyMap()
            }
        }.getOrDefault(emptyMap()).toMutableMap()
        headers["Range"] = "bytes=$rangeStart-${segment.end}"
        if (entity.acceptsRanges && !entity.etag.isNullOrBlank()) headers["If-Range"] = entity.etag!!

        val request: Request = NetworkClient.requestBuilder(entity.url, headers).get().build()
        NetworkClient.client.newCall(request).execute().use { response ->
            if (response.code == 403 || response.code == 410) {
                throw IllegalStateException("انتهت صلاحية الرابط (HTTP ${response.code}) — أعد التحليل")
            }
            if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}")
            val body = response.body ?: throw IllegalStateException("empty body")
            RandomAccessFile(file, "rw").use { raf ->
                raf.seek(rangeStart)
                val buffer = ByteArray(512 * 1024)
                var written = segment.written
                var lastPersist = System.currentTimeMillis()
                var bytesWindow = 0L
                var windowStart = System.currentTimeMillis()
                body.byteStream().use { input ->
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        raf.write(buffer, 0, read)
                        written += read
                        bytesWindow += read
                        val now = System.currentTimeMillis()
                        if (now - lastPersist > 900) {
                            dao.upsertSegment(segment.copy(written = written, completed = false))
                            lastPersist = now
                        }
                        if (now - windowStart > 1000) {
                            val speed = bytesWindow * 1000 / (now - windowStart + 1)
                            val persisted = dao.segments(entity.id).sumOf { it.written }
                            onProgress(persisted, speed, entity.connections)
                            bytesWindow = 0
                            windowStart = now
                        }
                    }
                }
                dao.upsertSegment(segment.copy(written = written, completed = true))
            }
        }
    }

    private suspend fun streamSingle(
        entity: DownloadEntity,
        file: File,
        onProgress: suspend (Long, Long, Int) -> Unit,
    ) {
        val start = if (file.exists()) file.length() else 0L
        val headers = if (start > 0) mapOf("Range" to "bytes=$start-") else emptyMap()
        NetworkClient.client.newCall(NetworkClient.requestBuilder(entity.url, headers).get().build()).execute().use { response ->
            if (response.code == 403 || response.code == 410) throw IllegalStateException("انتهت صلاحية الرابط")
            if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}")
            val body = response.body ?: throw IllegalStateException("empty body")
            val channel = RandomAccessFile(file, "rw")
            channel.seek(start)
            var written = start
            var windowStart = System.currentTimeMillis()
            var bytesWindow = 0L
            body.byteStream().use { input ->
                val buffer = ByteArray(256 * 1024)
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    channel.write(buffer, 0, read)
                    written += read
                    bytesWindow += read
                    val now = System.currentTimeMillis()
                    if (now - windowStart > 1000) {
                        onProgress(written, bytesWindow * 1000 / (now - windowStart + 1), 1)
                        bytesWindow = 0
                        windowStart = now
                    }
                }
            }
            channel.close()
        }
    }

    private fun publish(entity: DownloadEntity, written: Long, total: Long, speed: Long, connections: Int, status: DownloadStatus) {
        val map = progress.value.toMutableMap()
        map[entity.id] = DownloadProgress(
            id = entity.id,
            progress = if (total > 0) (written.toFloat() / total).coerceIn(0f, 1f) else 0f,
            bytesPerSecond = speed,
            activeConnections = connections,
            status = status,
        )
        progress.value = map
    }

    private fun split(total: Long, connections: Int): List<Pair<Long, Long>> {
        val chunk = total / connections
        if (chunk <= 0) return listOf(0L to total - 1)
        return (0 until connections).map { index ->
            val start = index * chunk
            val end = if (index == connections - 1) total - 1 else (start + chunk - 1)
            start to end
        }
    }

    /* ── Notifications ─────────────────────────────────────────────────── */

    fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                DOWNLOAD_CHANNEL_ID,
                context.getString(com.auroraget.app.R.string.download_channel_name),
                NotificationManager.IMPORTANCE_LOW,
            )
            channel.setShowBadge(true)
            manager.createNotificationChannel(channel)
        }
    }

    private fun notifyProgress(entity: DownloadEntity, progress: Int, status: DownloadStatus) {
        ensureChannel()
        val open = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val builder = NotificationCompat.Builder(context, DOWNLOAD_CHANNEL_ID)
            .setSmallIcon(com.auroraget.app.R.drawable.ic_stat_aurora)
            .setContentTitle(entity.name)
            .setContentText(
                when (status) {
                    DownloadStatus.COMPLETED -> "اكتمل التحميل · $progress%"
                    DownloadStatus.FAILED -> "فشل التحميل — اضغط لإعادة المحاولة"
                    else -> "جارٍ التحميل · $progress%"
                }
            )
            .setProgress(100, progress, progress == 0)
            .setOngoing(status != DownloadStatus.COMPLETED)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, "إيقاف مؤقت", actionIntent(entity.id, "com.auroraget.app.PAUSE", 1))
            .addAction(0, "استئناف", actionIntent(entity.id, "com.auroraget.app.RESUME", 2))
            .addAction(0, "إلغاء", actionIntent(entity.id, "com.auroraget.app.CANCEL", 3))
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.notify(entity.id.hashCode(), builder.build())
    }

    private fun actionIntent(id: String, action: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, DownloadActionReceiver::class.java).setAction(action).putExtra("id", id)
        return PendingIntent.getBroadcast(
            context,
            requestCode + id.hashCode(),
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }
}

/* ── WorkManager worker ─────────────────────────────────────────────────── */

class DownloadWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getString("downloadId") ?: return Result.failure()
        val repository = org.koin.core.context.GlobalContext.getOrNull()
            ?.get<DownloadRepository>()
            ?: return Result.failure()
        repository.ensureChannel()
        runCatching {
            setForeground(createForegroundInfo(id))
        }
        repository.start(id)
        return Result.success()
    }

    private fun createForegroundInfo(id: String): ForegroundInfo {
        val open = PendingIntent.getActivity(
            applicationContext,
            0,
            Intent(applicationContext, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification = NotificationCompat.Builder(applicationContext, DOWNLOAD_CHANNEL_ID)
            .setSmallIcon(com.auroraget.app.R.drawable.ic_stat_aurora)
            .setContentTitle("Aurora Get")
            .setContentText("جارٍ تحميل $id")
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(id.hashCode(), notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else ForegroundInfo(id.hashCode(), notification)
    }
}

class DownloadForegroundService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
}

class DownloadActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        val repo = org.koin.core.context.GlobalContext.getOrNull()?.get<DownloadRepository>() ?: return
        when (intent.action) {
            "com.auroraget.app.PAUSE" -> repo.pause(id)
            "com.auroraget.app.RESUME" -> repo.retry(id)
            "com.auroraget.app.CANCEL" -> repo.cancel(id)
        }
    }
}
