package com.auroraget.app.data

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Relation
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.Serializable

/* ── Core value types ───────────────────────────────────────────────────── */

enum class ContentType(val ar: String, val en: String) {
    VIDEO("فيديو", "Video"),
    AUDIO("صوت", "Audio"),
    IMAGE("صور", "Images"),
    FILE("ملفات", "Files"),
}

enum class DownloadStatus { QUEUED, DOWNLOADING, PAUSED, COMPLETED, FAILED }

@Serializable
data class MediaFormat(
    val id: String,
    val type: ContentType,
    val quality: String,
    val container: String,
    val codec: String = "—",
    val detail: String = "",
    val bytes: Long? = null,
    val approx: Boolean = false,
    val best: Boolean = false,
    val needsMerge: Boolean = false,
) {
    /** Confirmed sizes are printed plain; approximate ones always keep the ≈ marker. */
    val displaySize: String get() = bytes?.let { formatBytes(it, approx) } ?: "—"
}

@Serializable
data class AnalyzedSource(
    val url: String,
    val site: String,
    val domain: String,
    val title: String,
    val filename: String,
    val thumbnail: String?,
    val channel: String?,
    val durationSeconds: Int?,
    val counts: Map<ContentType, Int>,
    val formats: Map<ContentType, List<MediaFormat>>,
    val exactSizeBytes: Long?,
    val approxSize: Boolean,
    val analyzedAtMillis: Long = System.currentTimeMillis(),
)

data class SizeProbe(val bytes: Long?, val approx: Boolean, val etag: String?, val lastModified: String?, val acceptsRanges: Boolean)

/* ── Room ───────────────────────────────────────────────────────────────── */

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String,
    val url: String,
    val name: String,
    val site: String,
    val type: ContentType,
    val quality: String,
    val totalBytes: Long,
    val approx: Boolean,
    val downloadedBytes: Long = 0,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val connections: Int = 16,
    val priority: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val etag: String? = null,
    val lastModified: String? = null,
    val acceptsRanges: Boolean = false,
    val headersJson: String = "{}",
    val error: String? = null,
    @ColumnInfo(defaultValue = "") val outputPath: String = "",
)

@Entity(tableName = "segments", primaryKeys = ["downloadId", "segmentIndex"])
data class SegmentEntity(
    val downloadId: String,
    val segmentIndex: Int,
    val start: Long,
    val end: Long,
    val written: Long = 0,
    val completed: Boolean = false,
)

data class DownloadWithSegments(
    @Embedded val download: DownloadEntity,
    @Relation(parentColumn = "id", entityColumn = "downloadId")
    val segments: List<SegmentEntity>,
) {
    val progress: Float
        get() = if (download.totalBytes <= 0) 0f
        else (download.downloadedBytes.toFloat() / download.totalBytes.toFloat()).coerceIn(0f, 1f)
}

@Entity(tableName = "analysis_cache")
data class AnalysisCacheEntity(
    @PrimaryKey val key: String,
    val payload: String,
    val cachedAt: Long = System.currentTimeMillis(),
    val ttlMillis: Long = 1000L * 60L * 60L * 12L,
) {
    val expired: Boolean get() = System.currentTimeMillis() - cachedAt > ttlMillis
}

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY priority DESC, createdAt DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun find(id: String): DownloadEntity?

    @Query("SELECT * FROM segments WHERE downloadId = :id ORDER BY segmentIndex")
    suspend fun segments(id: String): List<SegmentEntity>

    @Upsert
    suspend fun upsert(download: DownloadEntity)

    @Upsert
    suspend fun upsertSegments(segments: List<SegmentEntity>)

    @Upsert
    suspend fun upsertSegment(segment: SegmentEntity)

    @Query("UPDATE downloads SET status = :status, downloadedBytes = :downloaded, error = :error WHERE id = :id")
    suspend fun updateState(id: String, status: DownloadStatus, downloaded: Long, error: String? = null)

    @Query("UPDATE downloads SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: DownloadStatus)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM segments WHERE downloadId = :id")
    suspend fun deleteSegments(id: String)

    @Query("SELECT IFNULL(SUM(downloadedBytes),0) FROM downloads WHERE status = 'COMPLETED'")
    fun observeTotalDownloaded(): Flow<Long>

    @Transaction
    suspend fun remove(id: String) {
        deleteSegments(id)
        delete(id)
    }
}

@Dao
interface AnalysisDao {
    @Query("SELECT * FROM analysis_cache WHERE key = :key")
    suspend fun get(key: String): AnalysisCacheEntity?

    @Upsert
    suspend fun put(entity: AnalysisCacheEntity)

    @Query("DELETE FROM analysis_cache")
    suspend fun clear()
}

@Database(
    entities = [DownloadEntity::class, SegmentEntity::class, AnalysisCacheEntity::class],
    version = 1,
    exportSchema = true,
)
abstract class AuroraDatabase : RoomDatabase() {
    abstract fun downloads(): DownloadDao
    abstract fun analysis(): AnalysisDao
}

/* ── Formatting helpers (shared with the Compose UI) ────────────────────── */

fun formatBytes(bytes: Long, approx: Boolean = false): String {
    if (bytes <= 0L) return "0 B"
    val kib = bytes / 1024.0
    val mib = kib / 1024.0
    val gib = mib / 1024.0
    val prefix = if (approx) "≈ " else ""
    return when {
        gib >= 1.0 -> prefix + String.format("%.2f GiB", gib)
        mib >= 1.0 -> prefix + String.format("%.1f MiB", mib)
        else -> prefix + "${kib.toInt().coerceAtLeast(1)} KB"
    }
}

fun exactBytes(bytes: Long): String = String.format("%,d bytes", bytes)
