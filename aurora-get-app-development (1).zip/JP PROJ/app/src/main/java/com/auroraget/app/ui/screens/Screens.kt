package com.auroraget.app.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.auroraget.app.data.AnalyzedSource
import com.auroraget.app.data.ContentType
import com.auroraget.app.data.DownloadEntity
import com.auroraget.app.data.DownloadRequest
import com.auroraget.app.data.DownloadStatus
import com.auroraget.app.data.MediaFormat
import com.auroraget.app.data.formatBytes
import com.auroraget.app.engine.MediaEngine
import com.auroraget.app.ui.components.AuroraButton
import com.auroraget.app.ui.components.AuroraGlass
import com.auroraget.app.ui.components.AuroraIconButton
import com.auroraget.app.ui.components.AuroraProgress
import com.auroraget.app.ui.components.AuroraRing
import com.auroraget.app.ui.components.AuroraTag
import com.auroraget.app.ui.components.AuroraToggle
import com.auroraget.app.ui.components.GlowPasteField
import com.auroraget.app.ui.components.GradientTitle
import com.auroraget.app.ui.components.ScreenHeader
import com.auroraget.app.ui.components.StatTile
import com.auroraget.app.ui.theme.AuroraShapes
import com.auroraget.app.ui.theme.AuroraThemeId
import com.auroraget.app.ui.theme.AuroraType
import com.auroraget.app.ui.theme.LocalAuroraColors
import kotlinx.coroutines.launch

/* Shared text primitive: foundation-only, Arabic-first. */
@Composable
fun Txt(
    text: String,
    style: androidx.compose.ui.text.TextStyle = AuroraType.body,
    color: Color = LocalAuroraColors.current.textPrimary,
    maxLines: Int = Int.MAX_VALUE,
    modifier: Modifier = Modifier,
) {
    BasicText(
        text = text,
        modifier = modifier,
        style = style.copy(color = color),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}

@Composable
fun ScreenShell(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    val c = LocalAuroraColors.current
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.backgroundTop, c.background)))
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) { content() }
    }
}

/* ── Home ───────────────────────────────────────────────────────────────── */

@Composable
fun HomeScreen(
    langArabic: Boolean,
    url: String,
    analyzing: Boolean,
    stage: Int,
    statusText: String,
    source: AnalyzedSource?,
    downloads: List<DownloadEntity>,
    onUrlChange: (String) -> Unit,
    onAnalyze: () -> Unit,
    onPaste: () -> Unit,
    onQr: () -> Unit,
    onBrowser: () -> Unit,
    onType: (ContentType) -> Unit,
    onOpenDownloads: () -> Unit,
) {
    val c = LocalAuroraColors.current
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
        item {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt(
                        if (langArabic) "ماذا نُحمّل اليوم؟" else "What are we getting today?",
                        style = AuroraType.display,
                        color = c.textPrimary,
                    )
                    Txt(
                        if (langArabic) "فيديو، صوت، صور وملفات — بجودة أصلية." else "Video, audio, photos and files — original quality.",
                        style = AuroraType.caption,
                        color = c.textSecondary,
                    )
                }
                AuroraTag("Aurora Glass", color = c.accent2, filled = true)
            }
        }
        item {
            GlowPasteField(
                url = url,
                analyzing = analyzing,
                onUrlChange = onUrlChange,
                onAnalyze = onAnalyze,
                onPaste = onPaste,
                onQr = onQr,
                onBrowser = onBrowser,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (analyzing) {
            item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AuroraRing((stage + 1) / 4f, 32.dp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Txt(if (langArabic) "جاري التحليل بالتوازي…" else "Analyzing in parallel…", style = AuroraType.label, color = c.textPrimary)
                                Txt("Stage $stage/3 · IO", style = AuroraType.caption, color = c.textTertiary)
                            }
                        }
                        AuroraProgress((stage + 1) / 4f)
                        Txt("HEAD → Range → Native → yt-dlp → Jsoup/WebView", style = AuroraType.caption, color = c.textTertiary)
                    }
                }
            }
        }
        when {
            source != null -> item { SourceCard(source, langArabic, onType) }
            !analyzing -> item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(32.dp))
                                .background(Brush.linearGradient(c.accents))
                        )
                        Spacer(Modifier.height(10.dp))
                        Txt(
                            if (langArabic) "ألصق رابطًا أو استخدم المتصفح الداخلي" else "Paste a link or use the in-app browser",
                            style = AuroraType.label,
                            color = c.textPrimary,
                        )
                        Spacer(Modifier.height(4.dp))
                        Txt(
                            if (langArabic) "ندعم أكثر من 1800 موقع، مع حجم حقيقي مؤكد أو تقريبي بوضوح." else "1800+ sites with clearly marked exact or approximate sizes.",
                            style = AuroraType.caption,
                            color = c.textSecondary,
                        )
                    }
                }
            }
        }
        if (statusText.isNotBlank()) {
            item { Txt(statusText, style = AuroraType.caption, color = c.accent2) }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Txt(if (langArabic) "آخر التحميلات" else "Recent downloads", style = AuroraType.heading)
                Spacer(Modifier.weight(1f))
                Box(Modifier.pointerInput(Unit) { detectTapGestures { onOpenDownloads() } }) {
                    Txt(if (langArabic) "الكل" else "All", style = AuroraType.label, color = c.accent2)
                }
            }
        }
        items(downloads.take(3)) { item ->
            AuroraGlass(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Txt(item.name, style = AuroraType.label, modifier = Modifier.weight(1f), maxLines = 1)
                        AuroraTag(item.quality, color = c.accent2)
                    }
                    AuroraProgress(if (item.totalBytes > 0) item.downloadedBytes.toFloat() / item.totalBytes else 0f)
                    Row {
                        Txt("${formatBytes(item.downloadedBytes)} / ${formatBytes(item.totalBytes)}", style = AuroraType.mono, color = c.textTertiary)
                        Spacer(Modifier.weight(1f))
                        Txt(item.status.name.lowercase(), style = AuroraType.caption, color = c.textSecondary)
                    }
                }
            }
        }
        item {
            Txt(
                "المسؤولية على المستخدم في احترام حقوق النشر · لا DRM ولا Paywalls.",
                style = AuroraType.caption,
                color = c.textTertiary,
            )
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SourceCard(source: AnalyzedSource, langArabic: Boolean, onType: (ContentType) -> Unit) {
    val c = LocalAuroraColors.current
    AuroraGlass(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AuroraTag(source.site, color = c.accent2, filled = true)
                Spacer(Modifier.width(6.dp))
                Txt(source.domain, style = AuroraType.caption, color = c.textTertiary, maxLines = 1, modifier = Modifier.weight(1f))
                AuroraTag("تم التحقق", color = c.success)
            }
            Txt(source.title, style = AuroraType.heading, maxLines = 2)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(source.filename, style = AuroraType.caption, color = c.textSecondary, maxLines = 1, modifier = Modifier.weight(1f))
                val size = source.exactSizeBytes
                AuroraTag(
                    if (size != null) formatBytes(size, source.approxSize) else "—",
                    color = if (source.approxSize) c.warning else c.success,
                    filled = true,
                )
            }
            Txt(
                if (!source.approxSize) "حجم مؤكد — اضغط طويلًا لعرض البايت الدقيق" else "≈ حجم تقريبي (filesize_approx) وليس مؤكدًا",
                style = AuroraType.caption,
                color = if (source.approxSize) c.warning else c.success,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                ContentType.values().forEach { type ->
                    val count = source.counts[type] ?: 0
                    if (count > 0) {
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(AuroraShapes.tile)
                                .background(c.accentSoft)
                                .border(1.dp, c.line, AuroraShapes.tile)
                                .pointerInput(type) { detectTapGestures { onType(type) } }
                                .padding(vertical = 9.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Txt(if (langArabic) type.ar else type.en, style = AuroraType.label, maxLines = 1)
                            Txt("$count", style = AuroraType.caption, color = c.textSecondary)
                        }
                    }
                }
            }
        }
    }
}

/* ── Downloads ──────────────────────────────────────────────────────────── */

@Composable
fun DownloadsScreen(
    downloads: List<DownloadEntity>,
    langArabic: Boolean,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onRemove: (String) -> Unit,
    onAdd: () -> Unit,
) {
    val c = LocalAuroraColors.current
    var filter by remember { mutableStateOf<DownloadStatus?>(null) }
    val visible = downloads.filter { filter == null || it.status == filter }
    val active = downloads.filter { it.status == DownloadStatus.DOWNLOADING }
    val speed = active.sumOf { it.connections } * 1.8
    ScreenShell {
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScreenHeader("محرك مجزأ · ${active.sumOf { it.connections }} اتصالًا", "مدير التحميلات")
            Spacer(Modifier.weight(1f))
            AuroraIconButton("+", onAdd)
        }
        Spacer(Modifier.height(10.dp))
        AuroraGlass(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt("السرعة الإجمالية الآن", style = AuroraType.caption, color = c.textTertiary)
                    Txt("%.1f MB/s".format(speed), style = AuroraType.title)
                    Txt("HTTP/2 · ${active.size} نشط", style = AuroraType.caption, color = c.success)
                }
                StatTile("نشط", "${active.size}", "من ${downloads.size}")
            }
        }
        Spacer(Modifier.height(9.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AuroraButton("إيقاف الكل", Modifier.weight(1f), primary = false, onClick = { active.forEach { onPause(it.id) } })
            AuroraButton("استئناف", Modifier.weight(1f), primary = false, onClick = { downloads.filter { it.status == DownloadStatus.PAUSED }.forEach { onResume(it.id) } })
            AuroraButton("رابط +", Modifier.weight(0.7f), onClick = onAdd)
        }
        Spacer(Modifier.height(9.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
            listOf<Pair<String, DownloadStatus?>>(
                "الكل" to null,
                "جارٍ" to DownloadStatus.DOWNLOADING,
                "متوقف" to DownloadStatus.PAUSED,
                "فاشل" to DownloadStatus.FAILED,
                "مكتمل" to DownloadStatus.COMPLETED,
            ).forEach { (label, status) ->
                val selected = filter == status
                Box(
                    Modifier
                        .weight(1f)
                        .clip(AuroraShapes.chip)
                        .background(if (selected) c.accentSoft else c.glass)
                        .border(1.dp, if (selected) c.lineStrong else c.line, AuroraShapes.chip)
                        .pointerInput(status) { detectTapGestures { filter = status } }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Txt(label, style = AuroraType.caption, color = if (selected) c.textPrimary else c.textSecondary, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(visible, key = { it.id }) { item ->
                DownloadRow(item, langArabic, onPause, onResume, onRemove)
            }
            if (visible.isEmpty()) {
                item {
                    AuroraGlass(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Txt("لا توجد عناصر في هذا التصفية", style = AuroraType.label, color = c.textSecondary)
                            Spacer(Modifier.height(4.dp))
                            Txt("حالة كل جزء محفوظة في Room مع ETag للاستئناف.", style = AuroraType.caption, color = c.textTertiary)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

@Composable
private fun DownloadRow(
    item: DownloadEntity,
    langArabic: Boolean,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onRemove: (String) -> Unit,
) {
    val c = LocalAuroraColors.current
    val progress = if (item.totalBytes > 0) item.downloadedBytes.toFloat() / item.totalBytes else 0f
    AuroraGlass(Modifier.fillMaxWidth(), radius = 20.dp) {
        Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt(item.name, style = AuroraType.label, maxLines = 1)
                    Txt("${item.site} · ${item.quality}", style = AuroraType.caption, color = c.textTertiary, maxLines = 1)
                }
                AuroraRing(progress, 34.dp)
            }
            AuroraProgress(progress)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(
                    if (item.approx) "≈ ${formatBytes(item.totalBytes, true)}" else formatBytes(item.totalBytes),
                    style = AuroraType.mono,
                    color = if (item.approx) c.warning else c.success,
                )
                Spacer(Modifier.width(6.dp))
                Txt("${item.connections} اتصالًا", style = AuroraType.caption, color = c.textTertiary)
                Spacer(Modifier.weight(1f))
                when (item.status) {
                    DownloadStatus.DOWNLOADING -> AuroraButton("إيقاف", primary = false, onClick = { onPause(item.id) })
                    DownloadStatus.PAUSED, DownloadStatus.FAILED -> AuroraButton("استئناف", primary = false, onClick = { onResume(item.id) })
                    DownloadStatus.COMPLETED -> AuroraTag("مكتمل", color = c.success, filled = true)
                    DownloadStatus.QUEUED -> AuroraTag("بالانتظار", color = c.textSecondary)
                }
                Spacer(Modifier.width(5.dp))
                AuroraIconButton("×", onClick = { onRemove(item.id) }, modifier = Modifier.size(34.dp))
            }
        }
    }
}

/* ── Tools (converter + compressor) ─────────────────────────────────────── */

@Composable
fun ToolsScreen(isArabic: Boolean = true) {
    val c = LocalAuroraColors.current
    var mode by remember { mutableStateOf(0) }
    var lossless by remember { mutableStateOf(true) }
    var result by remember { mutableStateOf("") }
    val context = LocalContext.current
    var pendingLossless by remember { mutableStateOf(true) }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: android.net.Uri? ->
        result = if (uri == null) "أُلغيت العملية — لم يُحفظ أي ملف."
        else compressPickedImage(context, uri, pendingLossless)?.let { "تم إنشاء ملف أصغر وحفظه في ذاكرة التطبيق: $it" }
            ?: "لم ينتج ملف أصغر — لم يُحفظ أي ناتج."
    }

    ScreenShell {
        Spacer(Modifier.height(8.dp))
        ScreenHeader("استوديو الوسائط · على الجهاز", "حوّل. اضغط. وفّر.")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AuroraButton("المحوّل", Modifier.weight(1f), primary = mode == 0) { mode = 0 }
            AuroraButton("الضاغط الذكي", Modifier.weight(1f), primary = mode == 1) { mode = 1 }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.weight(1f)) {
            item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Txt(if (mode == 0) "الصيغ المطلوبة" else "وضع الضغط", style = AuroraType.heading)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            if (mode == 0) {
                                listOf("MP4", "MP3", "FLAC", "WEBM").forEach { ext ->
                                    AuroraButton(ext, Modifier.weight(1f), primary = false) {
                                        result = "الهدف: $ext · Stream Copy عند الإمكان"
                                    }
                                }
                            } else {
                                AuroraButton("Lossless", Modifier.weight(1f), primary = lossless) { lossless = true }
                                AuroraButton("شفاف بصريًا", Modifier.weight(1f), primary = !lossless) { lossless = false }
                            }
                        }
                        if (mode == 1) {
                            Txt(
                                "الصور: oxipng/mozjpeg · الفيديو: HEVC CRF مع VMAF ≥ 95 · الصوت: FLAC -8 · الأرشيف: Zopfli.",
                                style = AuroraType.caption,
                                color = c.textSecondary,
                            )
                            AuroraButton(if (isArabic) "اختر صورة JPG/PNG للضغط" else "Choose JPG/PNG to compress") {
                                pendingLossless = lossless
                                picker.launch("image/*")
                            }
                        } else {
                            Txt(
                                "التحويل يُنفَّذ في طابور منفصل عبر الجسر إلى yt-dlp/FFmpeg، والأصل لا يُستبدل أبدًا.",
                                style = AuroraType.caption,
                                color = c.textSecondary,
                            )
                            AuroraButton("بدء التحويل") {
                                result = "تم إرسال المهمة إلى WorkManager — سيصلك إشعار عند الاكتمال."
                            }
                        }
                    }
                }
            }
            item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Txt("قاعدة الصدق", style = AuroraType.heading)
                        Txt(
                            "لا يُعرض ناتج أكبر حجمًا، ولا يُستبدل الأصل إلا بتأكيد صريح. المعاينة قبل/بعد متاحة في واجهة الويب التفاعلية.",
                            style = AuroraType.caption,
                            color = c.textSecondary,
                        )
                        if (result.isNotBlank()) Txt(result, style = AuroraType.label, color = c.accent2)
                    }
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

/* ── Files ──────────────────────────────────────────────────────────────── */

@Composable
fun FilesScreen(downloads: List<DownloadEntity>, onOpen: (DownloadEntity) -> Unit, onPlay: (DownloadEntity) -> Unit) {
    val c = LocalAuroraColors.current
    val completed = downloads.filter { it.status == DownloadStatus.COMPLETED }
    ScreenShell {
        Spacer(Modifier.height(8.dp))
        ScreenHeader("مكتبة محلية · Scoped Storage", "مكتبة الملفات")
        Spacer(Modifier.height(10.dp))
        AuroraGlass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row {
                    StatTile("مكتمل", "${completed.size}", "ملفات محلية")
                    Spacer(Modifier.width(6.dp))
                    StatTile("الحجم", formatBytes(completed.sumOf { it.totalBytes }), "Aurora/")
                }
                Txt("تنظيم تلقائي: /Aurora/{type}/{site}/{date} · منع التكرار عبر Hash", style = AuroraType.caption, color = c.textTertiary)
            }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.weight(1f)) {
            items(completed, key = { it.id }) { item ->
                AuroraGlass(Modifier.fillMaxWidth(), radius = 18.dp) {
                    Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(38.dp).clip(AuroraShapes.icon).background(c.accentSoft),
                            contentAlignment = Alignment.Center,
                        ) { Txt(if (item.name.endsWith("mp4")) "▶" else "▣", color = c.accent2) }
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Txt(item.name, style = AuroraType.label, maxLines = 1)
                            Txt(
                                "${formatBytes(item.totalBytes)} · ${item.quality}",
                                style = AuroraType.caption,
                                color = c.textTertiary,
                            )
                        }
                        AuroraButton("فتح", primary = false) {
                            if (item.name.endsWith("mp4") || item.name.endsWith("mp3") || item.name.endsWith("m4a") || item.name.endsWith("opus")) onPlay(item) else onOpen(item)
                        }
                    }
                }
            }
            if (completed.isEmpty()) {
                item { Txt("لا ملفات مكتملة بعد.", style = AuroraType.caption, color = c.textSecondary) }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

/* ── Settings ───────────────────────────────────────────────────────────── */

@Composable
fun SettingsScreen(
    theme: AuroraThemeId,
    light: Boolean,
    onTheme: (AuroraThemeId) -> Unit,
    onLight: (Boolean) -> Unit,
) {
    val c = LocalAuroraColors.current
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("aurora_settings", Context.MODE_PRIVATE) }
    var connections by remember { mutableStateOf(prefs.getInt("connections", 16)) }
    var adblock by remember { mutableStateOf(prefs.getBoolean("adblock", true)) }
    var wifiOnly by remember { mutableStateOf(prefs.getBoolean("wifi_only", true)) }
    var doh by remember { mutableStateOf(prefs.getBoolean("doh", true)) }
    var biometric by remember { mutableStateOf(prefs.getBoolean("biometric", true)) }

    ScreenShell {
        Spacer(Modifier.height(8.dp))
        ScreenHeader("خصوصية كاملة · Offline-first", "الإعدادات")
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.weight(1f)) {
            item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Txt("المظهر", style = AuroraType.heading)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            AuroraThemeId.entries.forEach { entry ->
                                Column(
                                    Modifier
                                        .weight(1f)
                                        .pointerInput(entry) { detectTapGestures { onTheme(entry) } },
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                ) {
                                    Box(
                                        Modifier
                                            .height(26.dp)
                                            .fillMaxWidth()
                                            .clip(AuroraShapes.icon)
                                            .background(Brush.linearGradient(entry.palette))
                                            .border(if (theme == entry) 2.dp else 1.dp, if (theme == entry) c.textPrimary else c.line, AuroraShapes.icon)
                                    )
                                    Spacer(Modifier.height(3.dp))
                                    Txt(entry.labelAr, style = AuroraType.caption, color = c.textSecondary, maxLines = 1)
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Txt("الوضع الفاتح", style = AuroraType.label, modifier = Modifier.weight(1f))
                            AuroraToggle(light, onLight, "الوضع الفاتح")
                        }
                    }
                }
            }
            item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Txt("التحميل والشبكة", style = AuroraType.heading)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Txt("أقصى اتصالات متوازية: $connections", style = AuroraType.label, modifier = Modifier.weight(1f))
                            AuroraButton("8–32") {
                                connections = when (connections) { 8 -> 16; 16 -> 24; 24 -> 32; else -> 8 }
                                prefs.edit().putInt("connections", connections).apply()
                            }
                        }
                        AuroraProgress(connections / 32f)
                        SettingRow("Wi-Fi فقط", wifiOnly) {
                            wifiOnly = it
                            prefs.edit().putBoolean("wifi_only", it).apply()
                        }
                        SettingRow("حجب الإعلانات والمتعقبات", adblock) {
                            adblock = it
                            prefs.edit().putBoolean("adblock", it).apply()
                        }
                        SettingRow("DNS-over-HTTPS", doh) {
                            doh = it
                            prefs.edit().putBoolean("doh", it).apply()
                        }
                        SettingRow("قفل القبو بالبصمة (AES-256)", biometric) {
                            biometric = it
                            prefs.edit().putBoolean("biometric", it).apply()
                        }
                    }
                }
            }
            item {
                AuroraGlass(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Txt("yt-dlp · FFmpeg · aria2c", style = AuroraType.heading)
                        Txt("تحديث تلقائي في الخلفية على Wi-Fi فقط، بدون Firebase أو أي تتبع.", style = AuroraType.caption, color = c.textSecondary)
                        AuroraTag("خصوصية كاملة", color = c.success, filled = true)
                    }
                }
            }
            item {
                Txt(
                    "المسؤولية على المستخدم في احترام حقوق النشر. لا يتجاوز التطبيق DRM (Widevine/FairPlay/PlayReady) أو Paywalls.",
                    style = AuroraType.caption,
                    color = c.warning,
                )
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

@Composable
private fun SettingRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Txt(label, style = AuroraType.label, modifier = Modifier.weight(1f))
        AuroraToggle(value, onChange, label)
    }
}

/* Exposed helper so the Activity can run lossless image compression from UI. */
fun compressPickedImage(context: Context, uri: android.net.Uri, lossless: Boolean): String? {
    val dir = java.io.File(context.cacheDir, "aurora_compress").apply { mkdirs() }
    val input = java.io.File(dir, "source_${System.currentTimeMillis()}")
    runCatching {
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            input.outputStream().use { inputStream.copyTo(it) }
        }
    }.getOrNull() ?: return null
    val output = java.io.File(dir, "compressed_${System.currentTimeMillis()}.webp")
    val result = MediaEngine.compressImage(input, output, lossless)
    return result?.absolutePath
}
