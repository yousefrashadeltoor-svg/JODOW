package com.auroraget.app.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import com.auroraget.app.data.AnalysisCacheEntity
import com.auroraget.app.data.AnalysisDao
import com.auroraget.app.data.AnalyzedSource
import com.auroraget.app.data.ContentType
import com.auroraget.app.data.MediaFormat
import com.auroraget.app.data.SizeProbe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

private const val TAG = "AuroraEngine"

/* ── Network ────────────────────────────────────────────────────────────── */

/**
 * Shared network stack. OkHttp 4 with an encrypted-cookie bridge hook.
 * HTTP/3 is negotiated by Cronet when the optional Cronet provider is added;
 * see README VERIFY item #1. HTTP/2 multiplexing works out of the box here.
 */
object NetworkClient {
    private val cookieStore = LinkedHashMap<String, List<Cookie>>()

    val cookies: CookieJar = object : CookieJar {
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            cookieStore[url.host] = cookies
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> =
            cookieStore[url.host].orEmpty().filter { it.expiresAt > System.currentTimeMillis() }

        fun headerFor(url: HttpUrl): String =
            loadForRequest(url).joinToString("; ") { "${it.name}=${it.value}" }
    }

    val client: OkHttpClient = OkHttpClient.Builder()
        .cookieJar(cookies)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    const val DESKTOP_UA =
        "Mozilla/5.0 (Linux; Android 14; AuroraGet/1.0) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    fun requestBuilder(url: String, headers: Map<String, String> = emptyMap()): Request.Builder {
        val builder = Request.Builder().url(url).header("User-Agent", DESKTOP_UA)
        headers.forEach { (k, v) -> builder.header(k, v) }
        val cookie = cookies.headerFor(HttpUrl.get(url))
        if (cookie.isNotBlank()) builder.header("Cookie", cookie)
        return builder
    }
}

/* ── Extractors (yt-dlp bridge) ─────────────────────────────────────────── */

/**
 * yt-dlp / FFmpeg / aria2c bridge.
 *
 * The upstream Android wrappers are initialised through their public
 * `getInstance().init(context)` entry points and executed through reflection.
 * This keeps compilation independent from wrapper minor-version signature
 * changes (the execute() overloads changed across releases — VERIFY item #2 in
 * README.md). The bundled ffmpeg module supplies the binary used by
 * `--extract-audio`, format selection, merging and aria2c external downloads.
 */
class ExtractorEngine(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private var initialised = false

    fun init() {
        if (initialised) return
        runCatching {
            val clazz = Class.forName("com.yausername.youtubedl_android.YoutubeDL")
            val instance = clazz.getMethod("getInstance").invoke(null)
            clazz.getMethod("init", Context::class.java).invoke(instance, context)
            runCatching {
                val ffmpeg = Class.forName("com.yausername.ffmpeg.FFmpeg")
                val ff = ffmpeg.getMethod("getInstance").invoke(null)
                ffmpeg.getMethod("init", Context::class.java).invoke(ff, context)
            }
            runCatching {
                val aria = Class.forName("com.yausername.aria2c.Aria2c")
                val a = aria.getMethod("getInstance").invoke(null)
                aria.getMethod("init", Context::class.java).invoke(a, context)
            }
            initialised = true
        }.onFailure { Log.w(TAG, "yt-dlp wrapper unavailable: ${it.message}") }
    }

    fun installedVersion(): String = runCatching {
        val clazz = Class.forName("com.yausername.youtubedl_android.YoutubeDL")
        val instance = clazz.getMethod("getInstance").invoke(null)
        clazz.getMethod("version").invoke(instance)?.toString() ?: "unknown"
    }.getOrDefault("unavailable")

    /** Returns the raw JSON emitted by `yt-dlp --dump-single-json` or null. */
    fun dumpJson(url: String): String? {
        init()
        if (!initialised) return null
        return runCatching {
            val clazz = Class.forName("com.yausername.youtubedl_android.YoutubeDL")
            val instance = clazz.getMethod("getInstance").invoke(null)
            val requestClass = Class.forName("com.yausername.youtubedl_android.YoutubeDLRequest")
            val request = requestClass.getConstructor(String::class.java).newInstance(url)
            val addOption = requestClass.getMethod("addOption", String::class.java, String::class.java)
            addOption.invoke(request, "--dump-single-json")
            addOption.invoke(request, "--no-warnings")
            addOption.invoke(request, "--no-playlist")
            addOption.invoke(request, "--skip-download")
            val execute = clazz.methods.firstOrNull {
                it.name == "execute" && it.parameterTypes.firstOrNull() == requestClass
            } ?: return@runCatching null
            val response = execute.invoke(instance, request)
            val out = response?.javaClass?.getMethod("getOut")?.invoke(response) as? String
            out?.trim()
        }.onFailure { Log.w(TAG, "yt-dlp dump failed: ${it.message}") }.getOrNull()
    }

    /** Download through yt-dlp into [targetDir] with aria2c as the external downloader. */
    fun download(url: String, formatSelector: String, targetDir: File, targetName: String, aria2c: Boolean = true): File? {
        init()
        if (!initialised) return null
        return runCatching {
            val clazz = Class.forName("com.yausername.youtubedl_android.YoutubeDL")
            val instance = clazz.getMethod("getInstance").invoke(null)
            val requestClass = Class.forName("com.yausername.youtubedl_android.YoutubeDLRequest")
            val request = requestClass.getConstructor(String::class.java).newInstance(url)
            val addOption = requestClass.getMethod("addOption", String::class.java, String::class.java)
            addOption.invoke(request, "-f", formatSelector)
            addOption.invoke(request, "-o", File(targetDir, targetName).absolutePath)
            addOption.invoke(request, "--no-warnings")
            if (aria2c) {
                addOption.invoke(request, "--downloader", "aria2c")
                addOption.invoke(request, "--downloader-args", "aria2c:-x16 -s16 -k1M")
            }
            val execute = clazz.methods.firstOrNull {
                it.name == "execute" && it.parameterTypes.firstOrNull() == requestClass
            } ?: return@runCatching null
            execute.invoke(instance, request)
            File(targetDir, targetName).takeIf { it.exists() }
        }.onFailure { Log.w(TAG, "yt-dlp download failed: ${it.message}") }.getOrNull()
    }

    fun parseFormats(raw: String): Map<ContentType, List<MediaFormat>> {
        if (raw.isBlank()) return emptyMap()
        val root = runCatching { json.parseToJsonElement(raw).jsonObject }.getOrNull() ?: return emptyMap()
        val formats = root["formats"]?.jsonArray ?: return emptyMap()
        val videos = mutableListOf<MediaFormat>()
        val audios = mutableListOf<MediaFormat>()
        val files = mutableListOf<MediaFormat>()

        formats.forEach { element ->
            val f = element.jsonObject
            val vcodec = f.string("vcodec")
            val acodec = f.string("acodec")
            val ext = f.string("ext") ?: "bin"
            val size = f["filesize"]?.jsonPrimitive?.longOrNull
                ?: f["filesize_approx"]?.jsonPrimitive?.longOrNull
            val approx = f["filesize"]?.jsonPrimitive?.longOrNull == null && size != null
            val height = f["height"]?.jsonPrimitive?.longOrNull
            val fps = f["fps"]?.jsonPrimitive?.longOrNull
            val bitrate = f["abr"]?.jsonPrimitive?.doubleOrNull ?: f["tbr"]?.jsonPrimitive?.doubleOrNull
            val id = f.string("format_id") ?: return@forEach
            if (vcodec != null && vcodec != "none" && height != null) {
                videos += MediaFormat(
                    id = id,
                    type = ContentType.VIDEO,
                    quality = "${height}p" + if (fps != null) " · ${fps}fps" else "",
                    container = ext.uppercase(),
                    codec = vcodec,
                    detail = bitrate?.let { "%.1f Mbps".format(it / 1000.0) } ?: "",
                    bytes = size,
                    approx = approx,
                    needsMerge = acodec == "none" || acodec == null,
                )
            } else if (vcodec == "none" && acodec != null && acodec != "none") {
                audios += MediaFormat(
                    id = id,
                    type = ContentType.AUDIO,
                    quality = "Audio",
                    container = ext.uppercase(),
                    codec = acodec,
                    detail = bitrate?.let { "%.0f kbps".format(it) } ?: "",
                    bytes = size,
                    approx = approx,
                )
            } else {
                files += MediaFormat(
                    id = id, type = ContentType.FILE, quality = "Original", container = ext.uppercase(),
                    codec = "—", detail = f.string("format_note") ?: "", bytes = size, approx = approx,
                )
            }
        }

        val subtitles = root["subtitles"]?.jsonObject?.keys.orEmpty()
        if (subtitles.isNotEmpty()) {
            files += MediaFormat(
                id = "subtitles", type = ContentType.FILE, quality = "Subtitles",
                container = "SRT", codec = "UTF-8", detail = subtitles.joinToString(", "), approx = false,
            )
        }

        val thumbs = root["thumbnails"]?.jsonArray.orEmpty()
        val images = thumbs.mapIndexed { index, t ->
            val thumb = t.jsonObject
            MediaFormat(
                id = "thumb_$index",
                type = ContentType.IMAGE,
                quality = thumb["id"]?.jsonPrimitive?.content ?: "Thumbnail ${index + 1}",
                container = "JPG",
                detail = "${thumb["width"]?.jsonPrimitive?.content ?: "?"} × ${thumb["height"]?.jsonPrimitive?.content ?: "?"}",
                bytes = thumb["filesize"]?.jsonPrimitive?.longOrNull,
                approx = true,
            )
        }

        return buildMap {
            if (videos.isNotEmpty()) put(ContentType.VIDEO, videos.sortedByDescending { it.quality.substringBefore("p").toIntOrNull() ?: 0 })
            if (audios.isNotEmpty()) put(ContentType.AUDIO, audios)
            if (images.isNotEmpty()) put(ContentType.IMAGE, images)
            if (files.isNotEmpty()) put(ContentType.FILE, files)
        }
    }

    private fun JsonObject.string(key: String): String? = this[key]?.jsonPrimitive?.contentOrNullSafe()

    private fun kotlinx.serialization.json.JsonPrimitive.contentOrNullSafe(): String? =
        if (this is kotlinx.serialization.json.JsonNull) null else content
}

/* ── Link analyzer pipeline ─────────────────────────────────────────────── */

class LinkAnalyzer(
    private val dao: AnalysisDao,
    private val extractors: ExtractorEngine,
) {
    private val memory = object : LinkedHashMap<String, AnalyzedSource>(24, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, AnalyzedSource>?): Boolean = size > 24
    }

    /** Stage 0 is synchronous; later stages stream through [onStage]. */
    suspend fun analyze(rawUrl: String, onStage: (Int) -> Unit = {}): Result<AnalyzedSource> = withContext(Dispatchers.IO) {
        val url = normalize(rawUrl)
        if (url == null) return@withContext Result.failure(IllegalArgumentException("رابط غير صالح"))
        val key = cacheKey(url)
        val cached = memory[key] ?: dao.get(key)?.takeIf { !it.expired }?.let { decode(it.payload) }
        if (cached != null) {
            memory[key] = cached
            onStage(3)
            return@withContext Result.success(cached)
        }

        val domain = url.toHttpUrlOrNull()?.host ?: ""
        onStage(0)
        val head = probeSize(url)
        val siteName = domain.substringAfter("www.").substringBefore(".").replaceFirstChar { it.uppercase() }

        var title = url.substringAfterLast('/').substringBefore('?').ifBlank { "ملف مباشر" }
        var thumbnail: String? = null
        var ytFormats: Map<ContentType, List<MediaFormat>> = emptyMap()
        var channel: String? = null
        var duration: Int? = null

        try {
            NetworkClient.client.newCall(
                NetworkClient.requestBuilder(url).header("Accept", "text/html").build()
            ).execute().use { response ->
                val contentType = response.header("Content-Type").orEmpty()
                if (contentType.contains("html")) {
                    val doc = Jsoup.parse(response.body?.string().orEmpty(), url)
                    title = doc.selectFirst("meta[property=og:title]")?.attr("content")
                        ?: doc.selectFirst("meta[name=twitter:title]")?.attr("content")
                        ?: doc.title().ifBlank { title }
                    thumbnail = doc.selectFirst("meta[property=og:image]")?.attr("content")
                    channel = doc.selectFirst("meta[property=og:site_name]")?.attr("content") ?: siteName
                }
            }
            onStage(1)
            val raw = extractors.dumpJson(url)
            if (raw != null) {
                ytFormats = extractors.parseFormats(raw)
                runCatching {
                    val root = Json.parseToJsonElement(raw).jsonObject
                    title = root["title"]?.jsonPrimitive?.content ?: title
                    channel = root["uploader"]?.jsonPrimitive?.content ?: channel
                    duration = root["duration"]?.jsonPrimitive?.longOrNull?.toInt()
                    thumbnail = root["thumbnail"]?.jsonPrimitive?.content ?: thumbnail
                }
                onStage(3)
            } else {
                onStage(3)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "analysis fallback: ${t.message}")
        }

        val direct = if (ytFormats.isEmpty()) {
            buildMap {
                val extension = url.substringBefore('?').substringAfterLast('.', "bin").lowercase()
                val type = when (extension) {
                    "mp4", "mkv", "webm", "mov", "m3u8", "mpd" -> ContentType.VIDEO
                    "mp3", "m4a", "opus", "flac", "wav" -> ContentType.AUDIO
                    "jpg", "jpeg", "png", "webp", "avif", "gif" -> ContentType.IMAGE
                    else -> ContentType.FILE
                }
                put(
                    type, listOf(
                        MediaFormat(
                            id = "direct",
                            type = type,
                            quality = "المصدر الأصلي",
                            container = extension.uppercase(),
                            detail = "HTTP · Range",
                            bytes = head.bytes,
                            approx = head.approx,
                            best = true,
                        )
                    )
                )
            }
        } else ytFormats

        val counts = direct.mapValues { it.value.size }
        val best = direct[ContentType.VIDEO]?.firstOrNull { it.best } ?: direct.values.flatten().firstOrNull()
        val source = AnalyzedSource(
            url = url,
            site = channel ?: siteName,
            domain = domain,
            title = title,
            filename = safeFilename(title, best?.container ?: "bin"),
            thumbnail = thumbnail,
            channel = channel,
            durationSeconds = duration,
            counts = counts,
            formats = direct,
            exactSizeBytes = best?.bytes,
            approxSize = best?.approx ?: (head.bytes == null),
        )
        memory[key] = source
        dao.put(AnalysisCacheEntity(key = key, payload = encode(source)))
        Result.success(source)
    }

    suspend fun probeSize(url: String, headers: Map<String, String> = emptyMap()): SizeProbe = withContext(Dispatchers.IO) {
        runCatching {
            val head = NetworkClient.client.newCall(NetworkClient.requestBuilder(url, headers).head().build()).execute()
            head.use {
                val length = it.header("Content-Length")?.toLongOrNull()
                if (length != null && length > 0) {
                    return@withContext SizeProbe(
                        bytes = length,
                        approx = false,
                        etag = it.header("ETag"),
                        lastModified = it.header("Last-Modified"),
                        acceptsRanges = it.header("Accept-Ranges") == "bytes",
                    )
                }
            }
        }
        // HEAD failed / chunked: Range: bytes=0-0 gives Content-Range: bytes 0-0/TOTAL.
        runCatching {
            NetworkClient.client.newCall(
                NetworkClient.requestBuilder(url, headers).header("Range", "bytes=0-0").build()
            ).execute().use { response ->
                val range = response.header("Content-Range")
                val total = range?.substringAfter('/')?.toLongOrNull()
                SizeProbe(
                    bytes = total,
                    approx = total == null,
                    etag = response.header("ETag"),
                    lastModified = response.header("Last-Modified"),
                    acceptsRanges = response.code == 206,
                )
            }
        }.getOrElse { SizeProbe(null, true, null, null, false) }
    }

    private fun normalize(raw: String): String? {
        var value = raw.trim()
        if (value.isEmpty()) return null
        if (!value.startsWith("http://", true) && !value.startsWith("https://", true)) value = "https://$value"
        val parsed = value.toHttpUrlOrNull() ?: return null
        return parsed.toString()
    }

    private fun safeFilename(title: String, ext: String): String {
        val cleaned = title.replace(Regex("[\\\\/:*?\"<>|]"), "-").take(96).trim()
        val base = cleaned.ifBlank { "aurora_download" }
        return if (base.endsWith(".$ext", true)) base else "$base.${ext.lowercase()}"
    }

    private fun cacheKey(url: String): String = "v1:${url.hashCode()}:${url.length}"

    private fun encode(source: AnalyzedSource): String =
        Json.encodeToString(AnalyzedSource.serializer(), source)

    private fun decode(payload: String): AnalyzedSource? = runCatching {
        Json.decodeFromString(AnalyzedSource.serializer(), payload)
    }.getOrNull()
}

/* ── Media utilities ────────────────────────────────────────────────────── */

object MediaEngine {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    /**
     * Lossless/near-lossless image compression. webpLossless=true gives exact
     * pixels; otherwise quality 92 is the "visually transparent" tier.
     */
    fun compressImage(source: File, target: File, webpLossless: Boolean): File? = runCatching {
        val bitmap = BitmapFactory.decodeFile(source.absolutePath) ?: return null
        val format = if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSLESS
        else Bitmap.CompressFormat.WEBP
        FileOutputStream(target).use { out ->
            bitmap.compress(format, if (webpLossless) 100 else 92, out)
        }
        bitmap.recycle()
        // Refuse to return a larger artefact: the compressor never lies about savings.
        if (target.exists() && target.length() > 0 && target.length() < source.length()) target else {
            target.delete()
            null
        }
    }.getOrNull()

    fun parseSuggestedConnections(megabitsPerSecond: Double): Int = when {
        megabitsPerSecond >= 200 -> 32
        megabitsPerSecond >= 90 -> 24
        megabitsPerSecond >= 30 -> 16
        else -> 8
    }

    /** Runs the bundled FFmpeg through the yt-dlp post-processing bridge. */
    fun convert(source: File, outputDir: File, targetExtension: String, extractors: ExtractorEngine): File? {
        val generated = extractors.download(
            url = source.toURI().toString(),
            formatSelector = "best",
            targetDir = outputDir,
            targetName = "${source.nameWithoutExtension}.$targetExtension",
            aria2c = false,
        )
        return generated?.takeIf { it.length() > 0 && it.absolutePath != source.absolutePath }
    }

    fun prettyJson(raw: String): String = runCatching { json.parseToJsonElement(raw) }.map { it.toString() }.getOrDefault(raw)
}
