package com.auroraget.app.di

import android.content.Context
import androidx.room.Room
import com.auroraget.app.data.AuroraDatabase
import com.auroraget.app.data.DownloadDao
import com.auroraget.app.data.DownloadRepository
import com.auroraget.app.engine.ExtractorEngine
import com.auroraget.app.engine.LinkAnalyzer
import org.koin.dsl.module

val appModule = module {
    single { Room.databaseBuilder(get<Context>(), AuroraDatabase::class.java, "aurora.db").build() }
    single<DownloadDao> { get<AuroraDatabase>().downloads() }
    single { get<AuroraDatabase>().analysis() }
    single { DownloadRepository(get<Context>(), get<DownloadDao>()) }
    single { ExtractorEngine(get<Context>()) }
    single { LinkAnalyzer(get(), get()) }
}
