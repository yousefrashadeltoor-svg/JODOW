package com.auroraget.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.auroraget.app.data.AnalyzedSource
import com.auroraget.app.data.ContentType
import com.auroraget.app.data.DownloadEntity
import com.auroraget.app.data.DownloadRequest
import com.auroraget.app.data.MediaFormat
import com.auroraget.app.data.formatBytes
import com.auroraget.app.data.DownloadRepository
import com.auroraget.app.engine.LinkAnalyzer
import com.auroraget.app.ui.components.AuroraButton
import com.auroraget.app.ui.components.AuroraDock
import com.auroraget.app.ui.components.AuroraGlass
import com.auroraget.app.ui.components.AuroraSheet
import com.auroraget.app.ui.components.AuroraTag
import com.auroraget.app.ui.components.GradientTitle
import com.auroraget.app.ui.screens.BrowserScreen
import com.auroraget.app.ui.screens.DownloadsScreen
import com.auroraget.app.ui.screens.FilesScreen
import com.auroraget.app.ui.screens.HomeScreen
import com.auroraget.app.ui.screens.SettingsScreen
import com.auroraget.app.ui.screens.ToolsScreen
import com.auroraget.app.ui.screens.Txt
import com.auroraget.app.ui.theme.AuroraShapes
import com.auroraget.app.ui.theme.AuroraThemeId
import com.auroraget.app.ui.theme.AuroraType
import com.auroraget.app.ui.theme.LocalAuroraColors
import kotlinx.coroutines.launch
import org.koin.core.context.GlobalContext
import java.io.File

private val dockItems = listOf(
    "الرئيسية" to "⌂",
    "التحميلات" to "⇩",
    "المتصفح" to "◎",
    "المكتبة" to "▤",
    "الإعدادات" to "⚙",
)

@Composable
fun AuroraApp(
    sharedLink: String? = null,
    shortcut: String? = null,
    onThemeChange: (AuroraThemeId) -> Unit = {},
    onAppearanceChange: (Boolean) -> Unit = {},
) {
    val c = LocalAuroraColors.current
    val context = LocalContext.current
    val koin = remember { GlobalContext.getOrNull() }
    val repository = remember { koin?.get<DownloadRepository>() }
    val analyzer = remember { koin?.get<LinkAnalyzer>() }
    val downloads by (repository?.allDownloads ?: kotlinx.coroutines.flow.flowOf(emptyList()))
        .collectAsState(initial = emptyList())

    var tab by remember { mutableStateOf(if (shortcut == "downloads") 1 else 0) }
    var url by remember { mutableStateOf(sharedLink.orEmpty()) }
    var analyzing by remember { mutableStateOf(false) }
    var stage by remember { mutableStateOf(0) }
    var source by remember { mutableStateOf<AnalyzedSource?>(null) }
    var sheetType by remember { mutableStateOf<ContentType?>(null) }
    var statusText by remember { mutableStateOf("") }
    var theme by remember { mutableStateOf(AuroraThemeId.AURORA) }
    var light by remember { mutableStateOf(false) }
    var showOnboarding by remember { mutableStateOf(true) }
    var step by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(sharedLink) {
        if (!sharedLink.isNullOrBlank()) {
            url = sharedLink
            tab = 0
        }
    }

    fun analyzeLink() {
        if (url.isBlank() || analyzing) return
        val engine = analyzer ?: return
        analyzing = true
        source = null
        statusText = ""
        scope.launch {
            val result = engine.analyze(url) { stage = it }
            result.onSuccess { source = it }
                .onFailure { statusText = it.message ?: "فشل التحليل" }
            analyzing = false
        }
    }

    fun queue(format: MediaFormat) {
        val repo = repository ?: return
        val currentSource = source ?: return
        scope.launch {
            val id = repo.enqueue(
                DownloadRequest(
                    url = currentSource.url,
                    name = currentSource.filename,
                    site = currentSource.domain,
                    type = format.type,
                    quality = "${format.quality} · ${format.container}",
                    totalBytes = format.bytes ?: 0,
                    approx = format.approx,
                    headers = emptyMap(),
                    needsMerge = format.needsMerge,
                ),
                connectionTarget = 16,
            )
            statusText = "أُضيف إلى المحرك ($id) — ${format.displaySize}"
            sheetType = null
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.backgroundTop, c.background)))
    ) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars)) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeScreen(
                        langArabic = true,
                        url = url,
                        analyzing = analyzing,
                        stage = stage,
                        statusText = statusText,
                        source = source,
                        downloads = downloads,
                        onUrlChange = { url = it },
                        onAnalyze = { analyzeLink() },
                        onPaste = {
                            statusText = "الصق من الحافظة ثم اضغط تحليل"
                        },
                        onQr = { statusText = "ماسح QR على الجهاز (ML Kit) — يتطلب إضافة اختيارية" },
                        onBrowser = { tab = 2 },
                        onType = { sheetType = it },
                        onOpenDownloads = { tab = 1 },
                    )
                    1 -> DownloadsScreen(
                        downloads = downloads,
                        langArabic = true,
                        onPause = { repository?.pause(it) },
                        onResume = { repository?.retry(it) },
                        onRemove = { repository?.cancel(it) },
                        onAdd = { tab = 0 },
                    )
                    2 -> BrowserScreen(
                        startUrl = "https://www.youtube.com",
                        langArabic = true,
                        onDownload = { request ->
                            scope.launch {
                                repository?.enqueue(request, 16)
                                statusText = "أرسل الصيّاد ${request.name} إلى محرك Aurora"
                                tab = 1
                            }
                        },
                    )
                    3 -> FilesScreen(
                        downloads = downloads,
                        onOpen = { item -> openFile(context, item) },
                        onPlay = { item -> playFile(context, item) },
                    )
                    4 -> SettingsScreen(
                        theme = theme,
                        light = light,
                        onTheme = { theme = it; onThemeChange(it) },
                        onLight = { light = it; onAppearanceChange(it) },
                    )
                }
            }
            AuroraDock(
                items = dockItems,
                selected = tab,
                onSelect = { tab = it },
                badge = downloads.count { it.status.name == "DOWNLOADING" },
            )
            Spacer(Modifier.height(8.dp).navigationBarsPadding())
        }

        if (showOnboarding) {
            Onboarding(step = step, onNext = {
                if (step >= 2) {
                    showOnboarding = false
                    statusText = "أهلاً بك في Aurora Get"
                } else step += 1
            }, onSkip = { showOnboarding = false })
        }

        val activeType = sheetType
        if (activeType != null && source != null) {
            val formats = source?.formats?.get(activeType).orEmpty()
            AuroraSheet(
                title = "${activeType.ar} · ${formats.size}",
                subtitle = source?.title,
                onDismiss = { sheetType = null },
            ) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth().height(360.dp)) {
                    items(formats) { format ->
                        AuroraGlass(Modifier.fillMaxWidth(), radius = 16.dp) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Txt(format.quality, style = AuroraType.label, modifier = Modifier.weight(1f), maxLines = 1)
                                    if (format.best) AuroraTag("موصى به", color = c.accent2, filled = true)
                                }
                                Txt(
                                    "${format.container} · ${format.codec} · ${format.detail}",
                                    style = AuroraType.caption,
                                    color = c.textSecondary,
                                    maxLines = 1,
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Txt(
                                        format.displaySize,
                                        style = AuroraType.mono,
                                        color = if (format.approx) c.warning else c.success,
                                    )
                                    if (format.approx) {
                                        Spacer(Modifier.size(4.dp))
                                        AuroraTag("≈ تقديري", color = c.warning)
                                    }
                                    if (format.needsMerge) {
                                        Spacer(Modifier.size(4.dp))
                                        AuroraTag("دمج تلقائي", color = c.accent3)
                                    }
                                    Spacer(Modifier.weight(1f))
                                    AuroraButton("تحميل") { queue(format) }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                AuroraButton(
                    "تحميل الأفضل تلقائيًا",
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    val best = formats.firstOrNull { it.best } ?: formats.firstOrNull()
                    if (best != null) queue(best)
                }
            }
        }
    }
}

@Composable
private fun Onboarding(step: Int, onNext: () -> Unit, onSkip: () -> Unit) {
    val c = LocalAuroraColors.current
    val slides = listOf(
        Triple("Aurora Get", "كل ما تحبه، في مكان واحد.", "ألصق أي رابط ودع المحرك يتولى الباقي — فيديو، صوت، صور وملفات."),
        Triple("Four smart chips", "اختر نوعك، واحصل على الجودة.", "الأزرار تظهر فقط عند وجود محتوى فعلي، مع الحجم المؤكد أو التقريبي."),
        Triple("Privacy first", "لا سحابة. لا تتبع.", "محرك مجزأ حتى 32 اتصالًا، استئناف دائم، وقبو AES-256 بالبصمة."),
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.backgroundTop, c.background)))
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                AuroraTag("Aurora Glass", color = c.accent2, filled = true)
                Spacer(Modifier.weight(1f))
                Box(Modifier.pointerInput(Unit) { detectTapGestures { onSkip() } }) { Txt("تخطي ✕", style = AuroraType.caption, color = c.textSecondary) }
            }
            Spacer(Modifier.height(28.dp))
            Box(
                Modifier
                    .size(148.dp)
                    .clip(AuroraShapes.chip)
                    .background(Brush.linearGradient(c.accents))
            )
            Spacer(Modifier.height(22.dp))
            Txt(slides[step].second, style = AuroraType.display, color = c.textPrimary)
            Spacer(Modifier.height(8.dp))
            Txt(slides[step].third, style = AuroraType.body, color = c.textSecondary)
            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                repeat(3) { i ->
                    Box(
                        Modifier
                            .size(width = if (i == step) 22.dp else 7.dp, height = 3.dp)
                            .clip(AuroraShapes.chip)
                            .background(if (i == step) c.accent2 else c.lineStrong)
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            AuroraButton(if (step == 2) "ابدأ الآن" else "التالي", Modifier.fillMaxWidth(), onClick = onNext)
            Spacer(Modifier.height(8.dp))
            Txt("${step + 1} / 3 · واجهة عربية RTL كاملة", style = AuroraType.caption, color = c.textTertiary)
            Spacer(Modifier.height(10.dp))
        }
    }
}

private fun openFile(context: android.content.Context, item: DownloadEntity) {
    val file = File(item.outputPath.ifBlank { File(context.getExternalFilesDir(null), "Aurora/Files/${item.name}").absolutePath })
    if (!file.exists()) return
    val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, context.contentResolver.getType(uri) ?: "*/*")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    runCatching { context.startActivity(intent) }
}

private fun playFile(context: android.content.Context, item: DownloadEntity) = openFile(context, item)
