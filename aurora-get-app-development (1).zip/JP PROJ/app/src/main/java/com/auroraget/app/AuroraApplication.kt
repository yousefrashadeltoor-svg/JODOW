package com.auroraget.app

import android.app.Application
import com.auroraget.app.data.DownloadRepository
import com.auroraget.app.di.appModule
import com.auroraget.app.engine.ExtractorEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import org.koin.java.KoinJavaComponent.getKoin

class AuroraApplication : Application() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@AuroraApplication)
            modules(appModule)
        }
        // Background yt-dlp + notification-channel warm-up (privacy preserving).
        scope.launch {
            runCatching {
                getKoin().get<DownloadRepository>().ensureChannel()
                getKoin().get<ExtractorEngine>().init()
            }
        }
    }
}
