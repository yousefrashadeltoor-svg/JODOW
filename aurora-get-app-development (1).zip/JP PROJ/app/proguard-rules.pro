# Aurora Get — R8 rules.
# Custom design system only: no Material rules are required.

-keepattributes Signature, InnerClasses, EnclosingMethod, *Annotation*
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations

# Kotlinx Serialization models
-keepclassmembers class com.auroraget.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.auroraget.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.auroraget.app.**$$serializer { *; }

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }

# Room
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# yt-dlp wrapper (reflection bridge in Extractors.kt)
-keep class com.yausername.youtubedl_android.** { *; }
-keep class com.yausername.ffmpeg.** { *; }
-keep class com.yausername.aria2c.** { *; }
-dontwarn com.yausername.**

# Jsoup
-keeppackagenames org.jsoup.nodes

# Coil 3
-dontwarn coil3.**

# Media3
-dontwarn androidx.media3.**

# WorkManager workers
-keep class com.auroraget.app.data.**Worker { *; }

# JNI native bridges (adblock-rust / libtorrent4j optional)
-keepclasseswithmembernames class * {
    native <methods>;
}
