import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeftRight,
  Check,
  CircleCheck,
  Download,
  Fingerprint,
  FolderDown,
  Gauge,
  Image as ImageIcon,
  Layers3,
  Lock,
  Music2,
  Play,
  ShieldCheck,
  Sparkles,
  X,
  Zap,
  Merge,
  ArrowLeft,
} from "lucide-react";
import type { AnalyzedSource, Appearance, ContentType, DownloadItem, Lang, Screen, ThemeId } from "./data";
import {
  contentTypeMeta,
  formatBytes,
  formats as playFormatSheet,
  initialDownloads,
  initialFiles,
  sources,
} from "./data";
import { BrandMark, Chip, Dock, Sheet, StatusBar, Toast } from "./components/ui";
import { Home } from "./screens/Home";
import { Downloads } from "./screens/Downloads";
import { Browser } from "./screens/Browser";
import { Files, Player } from "./screens/Files";
import { Settings } from "./screens/Settings";
import { Tools } from "./screens/Tools";

const glow: Record<ThemeId, string> = {
  aurora: "#8b6cf0",
  ocean: "#27c7d8",
  sunset: "#ff8a6b",
  emerald: "#3fd9a0",
  mono: "#aab3ca",
  neon: "#8dff68",
};

function Onboarding({ lang, onClose }: { lang: Lang; onClose: () => void }) {
  const [step, setStep] = useState(0);
  const ar = lang === "ar";
  const slides = [
    {
      tag: ar ? "Aurora Get · مُحمِّل ذكي" : "Aurora Get · smart downloader",
      title: ar ? "كل ما تحبه، في مكان واحد." : "Everything you love, in one place.",
      body: ar ? "فيديو، صوت، صور وملفات من أكثر من 1800 موقع. ألصق الرابط ودع Aurora تتكفل بالباقي." : "Video, audio, photos & files from 1800+ sites. Paste a link and let Aurora do the rest.",
      render: (
        <div className="relative flex h-[210px] items-center justify-center">
          <div className="absolute h-40 w-40 rounded-full accent-soft blur-2xl" />
          <div className="orb relative h-32 w-32" />
          <span className="absolute end-8 top-5 flex h-9 w-9 items-center justify-center rounded-xl border border-white/15 bg-black/25 backdrop-blur-md"><Play size={14} color="white" fill="white" /></span>
          <span className="absolute bottom-6 start-7 flex h-10 w-10 items-center justify-center rounded-[13px] border border-white/15 bg-black/25 backdrop-blur-md"><Music2 size={16} color="white" /></span>
          <span className="absolute bottom-10 end-9 flex h-8 w-8 items-center justify-center rounded-lg border border-white/15 bg-black/25 backdrop-blur-md"><ImageIcon size={13} color="white" /></span>
        </div>
      ),
    },
    {
      tag: ar ? "أربعة أزرار ذكية" : "Four smart buttons",
      title: ar ? "اختر نوعك، واحصل على الجودة." : "Pick your type. Get exact quality.",
      body: ar ? "أزرار الصوت والصور والفيديو والملفات تظهر فقط عند وجود محتوى فعلي — مع الحجم المؤكد أو التقريبي بوضوح." : "Audio, images, video and file chips appear only when content exists — with exact vs approximate sizes.",
      render: (
        <div className="relative mx-auto grid h-[210px] w-[230px] grid-cols-2 content-center gap-2.5">
          {[
            { i: Play, label: ar ? "فيديو · 12" : "Video · 12" },
            { i: Music2, label: ar ? "صوت · 7" : "Audio · 7" },
            { i: ImageIcon, label: ar ? "صور · 6" : "Images · 6" },
            { i: FolderDown, label: ar ? "ملفات · 5" : "Files · 5" },
          ].map((x, i) => (
            <div key={i} className="flex items-center gap-2 rounded-[18px] border border-white/10 p-3 glass-soft stagger" style={{ animationDelay: `${i * 0.1}s` }}>
              <span className="flex h-8 w-8 items-center justify-center rounded-[10px] accent-soft"><x.i size={14} style={{ color: "var(--accent2)" }} /></span>
              <span className="text-[10.5px] font-semibold">{x.label}</span>
            </div>
          ))}
        </div>
      ),
    },
    {
      tag: ar ? "خصوصية أولًا" : "Privacy first",
      title: ar ? "لا سحابة. لا تتبع. لا تنازل." : "No cloud. No tracking. No compromise.",
      body: ar ? "محرك مجزأ بسرعة البرق، استئناف دائم، حجب إعلانات، وقبو مشفّر بالبصمة. كل شيء على جهازك." : "A blazing segmented engine, permanent resume, ad blocking and a biometric vault. All on your device.",
      render: (
        <div className="relative mx-auto flex h-[210px] w-[230px] flex-col justify-center gap-2">
          {[
            { i: Zap, t: ar ? "تنزيل متوازٍ حتى 32 اتصالًا" : "Parallel downloads up to 32 conns" },
            { i: ShieldCheck, t: ar ? "AdBlock + Cloudflare داخل WebView" : "AdBlock + Cloudflare in WebView" },
            { i: Fingerprint, t: ar ? "قبو AES-256 محمي بالبصمة" : "Biometric AES-256 vault" },
          ].map((x, i) => (
            <div key={i} className="flex items-center gap-2.5 rounded-[15px] border border-white/10 p-2.5 glass-soft">
              <span className="flex h-7 w-7 items-center justify-center rounded-[9px] accent-soft"><x.i size={12} style={{ color: "var(--accent2)" }} /></span>
              <span className="text-[10.2px] font-medium">{x.t}</span>
              <CircleCheck size={12} className="ms-auto" style={{ color: "var(--success)" }} />
            </div>
          ))}
        </div>
      ),
    },
  ];
  const s = slides[step];
  return (
    <div className="absolute inset-0 z-[90] flex flex-col overflow-hidden app-bg">
      <div className="absolute -end-16 -top-10 h-52 w-52 rounded-full accent-gradient opacity-20 blur-3xl" />
      <div className="relative flex items-center justify-between px-5 pt-4">
        <div className="flex items-center gap-1.5"><BrandMark size={26} /><span className="font-[Outfit] text-[12.5px] font-semibold">Aurora <span style={{ color: "var(--accent2)" }}>Get</span></span></div>
        <button onClick={onClose} className="press flex items-center gap-1 rounded-full border border-white/10 px-2.5 py-1 text-[9.2px] muted glass-soft">{ar ? "تخطي" : "Skip"} <X size={9} /></button>
      </div>
      <div key={step} className="screen-enter relative flex flex-1 flex-col px-6 pt-3">
        <div className="text-center">
          <span className="inline-flex items-center gap-1 rounded-full border border-white/12 bg-white/5 px-2.5 py-1 text-[9.2px] font-medium" style={{ color: "var(--accent2)" }}>
            <Sparkles size={9} /> {s.tag}
          </span>
          <h1 className="mt-3 text-[25px] font-bold leading-[1.35]">{s.title}</h1>
        </div>
        {s.render}
        <p className="mx-auto mt-1 max-w-[290px] text-center text-[10.5px] leading-5 muted">{s.body}</p>
        <div className="mt-auto pb-6">
          <div className="mb-4 flex justify-center gap-1.5">
            {slides.map((_, i) => <span key={i} className={`h-[3px] rounded-full transition-all ${i === step ? "w-6 accent-gradient" : "w-2 bg-white/15"}`} />)}
          </div>
          <button
            onClick={() => (step === slides.length - 1 ? onClose() : setStep(step + 1))}
            className="press btn-primary flex w-full items-center justify-center gap-1.5 rounded-[16px] py-3 text-[11px] font-bold"
          >
            {step === slides.length - 1 ? (ar ? "ابدأ الآن" : "Get started") : ar ? "التالي" : "Next"}
            <ArrowLeft size={13} className={ar ? "" : "rotate-180"} />
          </button>
          <div className="mt-2 text-center text-[8.7px] faint">{step + 1} / {slides.length} · {ar ? "واجهة عربية RTL كاملة" : "Full RTL Arabic"}</div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [lang, setLang] = useState<Lang>("ar");
  const [theme, setTheme] = useState<ThemeId>("aurora");
  const [appearance, setAppearance] = useState<Appearance>("dark");
  const [screen, setScreen] = useState<Screen>("home");
  const [url, setUrl] = useState("https://www.youtube.com/watch?v=aurora-8k");
  const [analyzed, setAnalyzed] = useState<AnalyzedSource | null>(sources[0]);
  const [status, setStatus] = useState<"idle" | "analyzing" | "done">("done");
  const [stage, setStage] = useState(3);
  const [sheetType, setSheetType] = useState<ContentType | null>(null);
  const [sheetSort, setSheetSort] = useState("best");
  const [downloads, setDownloads] = useState<DownloadItem[]>(initialDownloads);
  const [files, setFiles] = useState(initialFiles);
  const [toast, setToast] = useState<{ m: string; d?: string } | null>(null);
  const [onboarding, setOnboarding] = useState(false);
  const [player, setPlayer] = useState(initialFiles[0]);
  const [back, setBack] = useState<Screen>("files");
  const [toolsTab, setToolsTab] = useState<"convert" | "compress">("convert");
  const [concurrency, setConcurrency] = useState(32);
  const timers = useRef<number[]>([]);
  const ar = lang === "ar";

  const showToast = useCallback((m: string, d?: string) => setToast({ m, d }), []);

  const navigate = useCallback((next: Screen) => {
    setScreen((current) => {
      if (next !== "player") setBack(current);
      return next;
    });
  }, []);

  const analyze = useCallback((source: AnalyzedSource, nextUrl: string) => {
    timers.current.forEach((t) => window.clearTimeout(t));
    timers.current = [];
    setUrl(nextUrl);
    setStatus("analyzing");
    setStage(0);
    setAnalyzed(null);
    [260, 640, 1080].forEach((ms, i) => timers.current.push(window.setTimeout(() => setStage(i + 1), ms)));
    timers.current.push(window.setTimeout(() => {
      setAnalyzed(source);
      setStatus("done");
    }, 1650));
  }, []);

  useEffect(() => () => timers.current.forEach((t) => window.clearTimeout(t)), []);

  // live download engine simulation
  useEffect(() => {
    const t = window.setInterval(() => {
      setDownloads((prev) =>
        prev.map((d) => {
          if (d.status !== "downloading") return d;
          const inc = d.speed * 1024 * 1024 * 1.2;
          const downloaded = Math.min(d.bytes, d.downloaded + inc);
          const speed = Math.max(5.2, Math.min(38.4, d.speed + (Math.random() - 0.5) * 1.8));
          const connections = Math.max(12, Math.min(concurrency, d.connections + (Math.random() > 0.55 ? 1 : -1)));
          return {
            ...d,
            downloaded,
            speed,
            connections,
            status: downloaded >= d.bytes ? "done" : "downloading",
            spark: [...d.spark.slice(1), speed],
          };
        })
      );
    }, 1300);
    return () => window.clearInterval(t);
  }, [concurrency]);

  const addDownload = (item: { name: string; host: string; type: ContentType; bytes: number; approx?: boolean; quality: string; thumb?: string }) => {
    const activeCount = downloads.filter((d) => d.status === "downloading").length;
    const newItem: DownloadItem = {
      id: `n${Date.now()}`,
      name: item.name,
      host: item.host,
      type: item.type,
      bytes: item.bytes,
      downloaded: 0,
      speed: activeCount < 2 ? 18.6 : 0,
      connections: activeCount < 2 ? Math.min(32, concurrency) : 0,
      status: activeCount < 2 ? "downloading" : "queued",
      thumbnail: item.thumb,
      quality: item.quality,
      exact: !item.approx,
      spark: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 6, 9, 12],
    };
    setDownloads((prev) => [newItem, ...prev]);
    setFiles((prev) => [
      { id: `f${Date.now()}`, name: item.name, type: item.type, size: item.bytes, quality: item.quality, thumb: item.thumb, date: ar ? "الآن · جديد" : "Just now", host: item.host, vault: false },
      ...prev,
    ]);
    showToast(ar ? "أُضيف إلى محرّك Aurora" : "Added to Aurora engine", `${item.quality} · ${formatBytes(item.bytes, !!item.approx)}${item.approx ? " ≈" : ""}`);
  };

  const downloadFromSheet = (type: ContentType, quality: string, bytes: number, approx: boolean, merge?: boolean) => {
    const short = { video: "vid", audio: "aud", image: "img", file: "doc" }[type];
    const ext = type === "video" ? "mp4" : type === "audio" ? "opus" : type === "image" ? "webp" : "srt";
    addDownload({
      name: `aurora_${short}_${quality.split(" ")[0].replace(/[^\w\u0600-\u06FF]/g, "")}.${ext}`,
      host: analyzed?.domain ?? "auroraget.app",
      type,
      bytes,
      approx,
      quality,
      thumb: analyzed?.thumbnail,
    });
    if (merge) showToast(ar ? "سيُدمج تلقائيًا مع أفضل صوت" : "Auto-merging with best audio", ar ? "FFmpeg · -c copy · الحجم الإجمالي 148.4 MiB" : "FFmpeg · -c copy · total 148.4 MiB");
    setSheetType(null);
  };

  const downloadAction = (id: string, action: "pause" | "resume" | "cancel" | "retry" | "delete" | "open") => {
    const item = downloads.find((d) => d.id === id);
    setDownloads((prev) => {
      if (action === "delete") return prev.filter((d) => d.id !== id);
      return prev.map((d) => {
        if (d.id !== id) return d;
        if (action === "pause" || action === "cancel") return { ...d, status: "paused", speed: 0 };
        if (action === "resume" || action === "retry") return { ...d, status: "downloading", speed: 16.4, connections: 24 };
        return d;
      });
    });
    if (action === "open") navigate("files");
    showToast(
      ar
        ? action === "pause" ? "تم الإيقاف المؤقت — الحالة محفوظة" : action === "resume" ? "استُؤنف التحميل" : action === "retry" ? "إعادة المحاولة مع تجديد الرابط" : action === "delete" ? "تم حذف العنصر" : "تم فتح الملف"
        : action === "delete" ? "Item deleted" : action === "open" ? "File opened" : `Download ${action}`,
      item?.name
    );
  };

  const moveDownload = (id: string, dir: -1 | 1) => {
    setDownloads((prev) => {
      const idx = prev.findIndex((d) => d.id === id);
      if (idx < 0) return prev;
      const target = idx + dir;
      if (target < 0 || target >= prev.length) return prev;
      const copy = [...prev];
      [copy[idx], copy[target]] = [copy[target], copy[idx]];
      return copy;
    });
    showToast(ar ? "أُعيد ترتيب الطابور" : "Queue reordered");
  };

  const currentFormats = sheetType
    ? [...(playFormatSheet[sheetType] ?? [])].sort((a, b) => {
        if (sheetSort === "small") return (a.bytes ?? 0) - (b.bytes ?? 0);
        if (sheetSort === "fast") return a.container.localeCompare(b.container);
        return (b.best ? 1 : 0) - (a.best ? 1 : 0);
      })
    : [];

  const sheetMeta = sheetType ? contentTypeMeta[sheetType] : null;
  const activeCount = downloads.filter((d) => d.status === "downloading").length;

  return (
    <div className="showcase h-dvh overflow-hidden">
      <div className="aurora-field">
        <span className="aurora-blob b1" />
        <span className="aurora-blob b2" />
        <span className="aurora-blob b3" />
      </div>
      <span className="grain" />

      <div className="relative z-10 mx-auto flex h-full w-full max-w-[1260px] items-center justify-center gap-10 px-0 py-0 lg:justify-between lg:px-10 lg:py-6">
        {/* Desktop editorial panel */}
        <aside className="hidden max-w-[470px] flex-1 flex-col lg:flex">
          <div className="flex items-center gap-2.5">
            <BrandMark size={42} />
            <div>
              <div className="font-[Outfit] text-[20px] font-semibold tracking-tight">Aurora <span style={{ color: "#b18cf5" }}>Get</span></div>
              <div className="text-[10.2px] font-medium tracking-[0.16em] text-white/45">ANDROID · GLASS EDITION</div>
            </div>
            <span className="ms-1 flex items-center gap-1 rounded-full border border-white/15 bg-white/5 px-2 py-1 text-[9.2px] font-medium text-white/65">
              <span className="h-1.5 w-1.5 rounded-full bg-[#5ee1b0] pulse-dot" /> UI Preview · تفاعلي
            </span>
          </div>

          <h1 className="mt-7 text-[46px] font-bold leading-[1.22] tracking-tight text-white">
            حمّل كل شيء.
            <br />
            <span className="bg-gradient-to-l from-[#4a8cff] via-[#b18cf5] to-[#ff8a96] bg-clip-text text-transparent">بلمسة واحدة.</span>
          </h1>
          <p className="mt-3 max-w-[400px] text-[13px] leading-7 text-white/50">
            فيديو، صوت، صور، وملفات من أكثر من 1800 موقع. بتصميم Aurora Glass، محرك مجزأ حتى 32 اتصالًا، وخصوصية كاملة بدون تتبع.
          </p>

          <div className="mt-6 grid max-w-[420px] grid-cols-2 gap-2.5">
            {[
              { i: Layers3, t: "أربعة أزرار ذكية", s: "تظهر فقط عند وجود محتوى فعلي" },
              { i: Zap, t: "محرك مجزأ فائق", s: "8–32 اتصالًا مع استئناف دائم" },
              { i: Sparkles, t: "ضاغط ذكي", s: "Lossless + شفاف بصريًا VMAF" },
              { i: ShieldCheck, t: "خصوصية مطلقة", s: "بدون Firebase أو أي تتبع" },
            ].map((x) => (
              <div key={x.t} className="rounded-[18px] border border-white/10 bg-white/[0.045] p-3 backdrop-blur-xl">
                <span className="flex h-7 w-7 items-center justify-center rounded-[9px] border border-white/10 bg-white/[0.06]">
                  <x.i size={13} className="text-[#b9a4ff]" />
                </span>
                <div className="mt-2 text-[11.5px] font-semibold text-white/90">{x.t}</div>
                <div className="mt-0.5 text-[9.7px] leading-4 text-white/40">{x.s}</div>
              </div>
            ))}
          </div>

          <div className="mt-6 flex items-center gap-5">
            {[
              { n: "1800+", l: "موقع مدعوم" },
              { n: "32", l: "اتصال متوازٍ" },
              { n: "0", l: "تتبّع" },
              { n: "60fps", l: "أداء الواجهة" },
            ].map((s, i) => (
              <div key={s.l} className="flex items-center gap-5">
                {i > 0 && <span className="h-7 w-px bg-white/10" />}
                <div>
                  <div className="font-[Outfit] text-[17.5px] font-semibold text-white/90">{s.n}</div>
                  <div className="text-[9.2px] text-white/35">{s.l}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-5 flex flex-wrap items-center gap-1.5">
            {[
              { s: "home" as Screen, ar: "الرئيسية", en: "Home" },
              { s: "downloads" as Screen, ar: "التحميلات", en: "Downloads" },
              { s: "browser" as Screen, ar: "المتصفح", en: "Browser" },
              { s: "tools" as Screen, ar: "الأدوات", en: "Tools" },
              { s: "files" as Screen, ar: "المكتبة", en: "Library" },
              { s: "settings" as Screen, ar: "الإعدادات", en: "Settings" },
            ].map((x) => (
              <button
                key={x.s}
                onClick={() => { if (x.s === "tools") setToolsTab("convert"); navigate(x.s); }}
                className="press rounded-full border px-2.5 py-1 text-[9px] font-medium transition-colors"
                style={{
                  background: screen === x.s ? "rgba(155,114,203,.22)" : "rgba(255,255,255,.04)",
                  borderColor: screen === x.s ? "rgba(177,140,245,.5)" : "rgba(255,255,255,.1)",
                  color: screen === x.s ? "#efeaff" : "rgba(255,255,255,.55)",
                }}
              >
                {ar ? x.ar : x.en}
              </button>
            ))}
          </div>

          <div className="mt-6 flex items-center gap-2">
            <button onClick={() => setOnboarding(true)} className="press flex items-center gap-1.5 rounded-full bg-gradient-to-l from-[#4285f4] via-[#9b72cb] to-[#d96570] px-4 py-2.5 text-[11px] font-semibold text-white shadow-[0_14px_34px_-14px_#9b72cb]">
              <Play size={12} fill="white" /> شاهد الجولة السريعة
            </button>
            <button onClick={() => navigate("settings")} className="press flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-4 py-2.5 text-[11px] font-medium text-white/70 backdrop-blur-md">
              <Sparkles size={12} className="text-[#d4c4ff]" /> خصّص السمة
            </button>
          </div>

          <div className="mt-7 flex items-center gap-2 text-[9.2px] text-white/25">
            <Lock size={9} />
            واجهة عرض كاملة — تفاعلية بنفس تفاصيل التطبيق الأصلي. المسؤولية على المستخدم في احترام حقوق النشر.
            <span className="rounded border border-white/10 px-1.5 py-0.5 text-white/35">JP PROJ</span>
          </div>
        </aside>

        {/* Device */}
        <div className="device" style={{ ["--device-glow" as string]: glow[theme] }}>
          <div className="island" />
          <div
            className="device-screen app-root app-bg"
            data-theme={theme}
            data-appearance={appearance}
            dir={ar ? "rtl" : "ltr"}
          >
            <StatusBar appearance={appearance} />
            <main key={screen} className="screen-enter no-scrollbar relative flex-1 overflow-y-auto pb-[98px]">
              {screen === "home" && (
                <Home
                  lang={lang}
                  analyzed={analyzed}
                  status={status}
                  stage={stage}
                  url={url}
                  setUrl={setUrl}
                  downloads={downloads}
                  onAnalyze={analyze}
                  onReset={() => { setAnalyzed(null); setStatus("idle"); setUrl(""); }}
                  onOpenSheet={(t) => { setSheetType(t); setSheetSort("best"); }}
                  onPreview={() => { setBack("home"); setPlayer(initialFiles[0]); navigate("player"); }}
                  onNavigate={navigate}
                  onTools={(tab) => { setToolsTab(tab); navigate("tools"); }}
                  onToast={showToast}
                />
              )}
              {screen === "downloads" && (
                <Downloads lang={lang} downloads={downloads} onAction={downloadAction} onMove={moveDownload} onNavigate={navigate} onToast={showToast} />
              )}
              {screen === "browser" && <Browser lang={lang} onDownload={addDownload} onToast={showToast} />}
              {screen === "files" && (
                <Files
                  lang={lang}
                  files={files}
                  onNavigate={navigate}
                  onToast={showToast}
                  onPlay={(f) => { setPlayer(f); setBack("files"); navigate("player"); }}
                />
              )}
              {screen === "settings" && (
                <Settings
                  lang={lang}
                  setLang={setLang}
                  theme={theme}
                  setTheme={setTheme}
                  appearance={appearance}
                  setAppearance={setAppearance}
                  concurrency={concurrency}
                  setConcurrency={setConcurrency}
                  onToast={showToast}
                  onOnboarding={() => setOnboarding(true)}
                  onNavigate={navigate}
                />
              )}
              {screen === "tools" && <Tools lang={lang} tab={toolsTab} setTab={setToolsTab} onToast={showToast} onNavigate={navigate} />}
              {screen === "player" && (
                <Player
                  lang={lang}
                  file={player}
                  onBack={() => navigate(back)}
                  onNavigate={navigate}
                  onDownload={() => {
                    addDownload({ name: player.name, host: player.host, type: "video", bytes: player.size, quality: player.quality, thumb: player.thumb });
                    navigate("downloads");
                  }}
                  onToast={showToast}
                />
              )}
            </main>

            <Dock screen={screen} lang={lang} onNavigate={navigate} activeCount={activeCount} />

            {toast && <Toast message={toast.m} detail={toast.d} onClose={() => setToast(null)} icon={toastIcon(toast.m)} />}

            <Sheet
              open={!!sheetType}
              onClose={() => setSheetType(null)}
              lang={lang}
              title={sheetMeta ? <><span className="flex h-7 w-7 items-center justify-center rounded-[9px]" style={{ background: sheetMeta.glow }}><TypeIconLite type={sheetType!} /></span> {ar ? sheetMeta.ar : sheetMeta.en} <span className="rounded-full bg-white/8 px-1.5 py-0.5 text-[9.2px] font-bold">{analyzed?.counts[sheetType!] ?? 0}</span></> : ""}
              subtitle={analyzed ? `${analyzed.site} · ${analyzed.title}` : undefined}
            >
              {sheetType && (
                <div>
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1 rounded-full border p-[2px]" style={{ borderColor: "var(--line)" }}>
                      {[
                        { id: "best", ar: "الأفضل", en: "Best" },
                        { id: "small", ar: "الأصغر", en: "Smallest" },
                        { id: "fast", ar: "الأسرع", en: "Fastest" },
                      ].map((s) => (
                        <button key={s.id} onClick={() => setSheetSort(s.id)} className="press rounded-full px-2 py-[3px] text-[9.2px] font-medium" style={{ background: sheetSort === s.id ? "var(--accent-soft)" : "transparent", color: sheetSort === s.id ? "var(--accent2)" : "var(--text-3)" }}>{ar ? s.ar : s.en}</button>
                      ))}
                    </div>
                    <span className="flex items-center gap-1 text-[9.2px]" style={{ color: "var(--success)" }}><ShieldCheck size={9} /> {ar ? "حجم حقيقي" : "Exact size"}</span>
                  </div>
                  <div className="space-y-1.5">
                    {currentFormats.map((f) => (
                      <div key={f.id} className="rounded-[16px] border p-2 glass-soft" style={{ borderColor: f.best ? "color-mix(in srgb, var(--accent2) 40%, transparent)" : "var(--line)", background: f.best ? "linear-gradient(160deg, var(--accent-soft), var(--glass))" : undefined }}>
                        <div className="flex items-center gap-2">
                          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[10px] border border-white/10 bg-black/20">
                            {sheetType === "video" ? <Play size={13} style={{ color: "#7ea6ff" }} /> : sheetType === "audio" ? <Music2 size={14} style={{ color: "#c79bff" }} /> : sheetType === "image" ? <ImageIcon size={13} style={{ color: "#ff9d9d" }} /> : <FolderDown size={13} style={{ color: "#7ee3ca" }} />}
                          </span>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5">
                              <span className="text-[10.7px] font-semibold" style={{ color: "var(--text-1)" }}>{f.quality}</span>
                              {f.badge && <span className="rounded-full px-1.5 py-[1px] text-[7.7px] font-bold" style={{ background: f.best ? "var(--accent-soft)" : "rgba(255,255,255,.06)", color: f.best ? "var(--accent2)" : "var(--text-2)" }}>{f.badge}</span>}
                            </div>
                            <div className="mt-0.5 flex items-center gap-1 text-[8.7px] faint" dir="ltr">
                              <span className="rounded border border-white/10 bg-white/5 px-1 py-[1px] font-semibold" style={{ color: "var(--text-2)" }}>{f.container}</span>
                              <span>{f.codec}</span><span className="opacity-40">·</span><span>{f.detail}</span>
                            </div>
                          </div>
                          <button
                            onClick={() => showToast(ar ? "تم نسخ الرابط المباشر" : "Direct link copied", `${f.quality} · ${f.container}`)}
                            className="press-sm flex h-6 w-6 items-center justify-center rounded-md border glass-soft"
                            title={ar ? "تحويل إلى…" : "Convert to…"}
                          >
                            <ArrowLeftRight size={9} /> {ar ? "تحويل" : "Convert"}
                          </button>
                          <button onClick={() => downloadFromSheet(sheetType, f.quality, f.bytes ?? 0, f.approx, f.merge)} className="press flex h-8 w-8 shrink-0 items-center justify-center rounded-[10px] accent-gradient text-white" style={{ boxShadow: "0 6px 16px -8px var(--accent2)" }} aria-label="download">
                            <Download size={13} />
                          </button>
                        </div>
                        <div className="mt-1.5 flex items-center justify-between border-t pt-1.5" style={{ borderColor: "var(--line)" }}>
                          <button
                            onClick={() => f.bytes && showToast(ar ? "الحجم الحقيقي بالبايت" : "Exact size", f.bytes ? `${f.bytes.toLocaleString("en-US")} bytes${f.approx ? ` · ${ar ? "تقريبي" : "approx"}` : ` · ${ar ? "مؤكد" : "verified"}`}` : undefined)}
                            className="flex items-center gap-1 text-[9.2px] font-medium tabular-nums"
                            style={{ color: "var(--text-2)" }}
                          >
                            {f.bytes ? formatBytes(f.bytes, f.approx) : "—"}
                            {f.approx ? <span className="rounded-full bg-[#ffd284]/10 px-1.5 py-[1px] text-[7.7px] font-semibold" style={{ color: "var(--warning)" }}>≈ {ar ? "تقديري" : "approx"}</span> : <span className="rounded-full bg-[#5ee1b0]/10 px-1.5 py-[1px] text-[7.7px] font-semibold" style={{ color: "var(--success)" }}>{ar ? "مؤكد" : "exact"}</span>}
                          </button>
                          {f.merge && (
                            <span className="flex items-center gap-1 text-[8.2px]" style={{ color: "var(--accent3)" }}>
                              <Merge size={9} /> {ar ? "يُدمج مع أفضل صوت تلقائيًا" : "Auto-merge with best audio"}
                            </span>
                          )}
                          {f.id === "v4320" && <Chip tone="warning">{ar ? "HDR 10-bit" : "HDR 10-bit"}</Chip>}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-2.5 rounded-[13px] border p-2" style={{ borderColor: "var(--line)", background: "var(--glass)" }}>
                    <div className="flex items-start gap-1.5 text-[8.7px] leading-4 muted">
                      <Gauge size={10} className="mt-0.5 shrink-0" style={{ color: "var(--accent2)" }} />
                      {ar ? "الحجم المؤكد يُقرأ من HEAD / Content-Range. التقريبي من filesize_approx ويظهر دائمًا مع ≈. اضغط على الحجم لعرض البايت الدقيق." : "Exact sizes come from HEAD / Content-Range. Approximate uses filesize_approx and always shows ≈. Tap size for exact bytes."}
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      const best = currentFormats.find((f) => f.best) ?? currentFormats[0];
                      if (best?.bytes) downloadFromSheet(sheetType, best.quality, best.bytes, best.approx, best.merge);
                    }}
                    className="press btn-primary mt-2.5 flex w-full items-center justify-center gap-1.5 rounded-[14px] py-2.5 text-[10.7px] font-bold"
                  >
                    <Download size={12} /> {ar ? "تحميل الأفضل تلقائيًا" : "Auto-download best"} · {currentFormats.find((f) => f.best)?.quality ?? ""}
                  </button>
                </div>
              )}
            </Sheet>

            {onboarding && <Onboarding lang={lang} onClose={() => { setOnboarding(false); showToast(ar ? "أهلاً بك في Aurora Get" : "Welcome to Aurora Get", ar ? "ابدأ بلصق أي رابط — نحن جاهزون." : "Paste any link — we're ready."); }} />}
          </div>
        </div>
      </div>
    </div>
  );
}

function TypeIconLite({ type }: { type: ContentType }) {
  if (type === "video") return <Play size={12} style={{ color: contentTypeMeta.video.color }} />;
  if (type === "audio") return <Music2 size={12} style={{ color: contentTypeMeta.audio.color }} />;
  if (type === "image") return <ImageIcon size={12} style={{ color: contentTypeMeta.image.color }} />;
  return <FolderDown size={12} style={{ color: contentTypeMeta.file.color }} />;
}

function toastIcon(message: string) {
  if (/خطأ|فشل|failed|error/i.test(message)) return <X size={16} strokeWidth={2.6} />;
  if (/سرعة|speed/i.test(message)) return <Gauge size={16} />;
  if (/قبو|vault/i.test(message)) return <Fingerprint size={16} />;
  return <Check size={17} strokeWidth={2.8} />;
}
