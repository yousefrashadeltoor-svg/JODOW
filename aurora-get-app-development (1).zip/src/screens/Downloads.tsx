import { useMemo, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock3,
  Download,
  FolderOpen,
  Gauge,
  MoreHorizontal,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Settings2,
  Share2,
  ShieldCheck,
  SlidersHorizontal,
  Trash2,
  Wifi,
  X,
  Zap,
} from "lucide-react";
import type { DownloadItem, DownloadStatus, Lang, Screen } from "../data";
import { contentTypeMeta, formatBytes } from "../data";
import { Chip, Progress, SectionTitle, Sparkline, TypeIcon } from "../components/ui";

export type DownloadsProps = {
  lang: Lang;
  downloads: DownloadItem[];
  onAction: (id: string, action: "pause" | "resume" | "cancel" | "retry" | "delete" | "open") => void;
  onMove: (id: string, dir: -1 | 1) => void;
  onNavigate: (s: Screen) => void;
  onToast: (m: string, d?: string) => void;
};

const tabs: { id: "all" | DownloadStatus; ar: string; en: string }[] = [
  { id: "all", ar: "الكل", en: "All" },
  { id: "downloading", ar: "جارٍ", en: "Active" },
  { id: "queued", ar: "بالانتظار", en: "Queued" },
  { id: "done", ar: "مكتمل", en: "Done" },
  { id: "failed", ar: "فاشل", en: "Failed" },
];

function eta(d: DownloadItem) {
  if (!d.speed) return "—";
  const sec = Math.max(1, Math.round((d.bytes - d.downloaded) / (d.speed * 1024 * 1024)));
  return sec > 60 ? `${Math.floor(sec / 60)}m ${sec % 60}s` : `${sec}s`;
}

function DownloadCard({
  d,
  lang,
  onAction,
  onMove,
  onToast,
}: {
  d: DownloadItem;
  lang: Lang;
  onAction: DownloadsProps["onAction"];
  onMove: DownloadsProps["onMove"];
  onToast: DownloadsProps["onToast"];
}) {
  const ar = lang === "ar";
  const pct = Math.min(100, (d.downloaded / d.bytes) * 100);
  const meta = contentTypeMeta[d.type];
  const statusLabel: Record<DownloadStatus, { ar: string; en: string; color: string }> = {
    downloading: { ar: "جارٍ التحميل", en: "Downloading", color: "var(--accent2)" },
    paused: { ar: "متوقف مؤقتًا", en: "Paused", color: "var(--warning)" },
    queued: { ar: "في الانتظار", en: "Queued", color: "var(--text-2)" },
    done: { ar: "مكتمل", en: "Completed", color: "var(--success)" },
    failed: { ar: "فشل — بانتظار إعادة المحاولة", en: "Failed", color: "var(--danger)" },
  };
  const st = statusLabel[d.status];
  const iconBtn = "press-sm flex h-[26px] min-w-[26px] items-center justify-center rounded-[8px] border glass-soft px-1";

  return (
    <div
      className="relative overflow-hidden rounded-[20px] border p-2.5 glass-soft"
      style={{ borderColor: d.status === "failed" ? "rgba(255,107,129,.28)" : "var(--line)" }}
    >
      {d.status === "downloading" && <span className="absolute inset-x-0 top-0 h-[2px] accent-gradient opacity-80" />}
      <div className="flex items-center gap-2.5">
        <div className="relative h-[42px] w-[42px] shrink-0 overflow-hidden rounded-[12px] border border-white/10">
          {d.thumbnail ? (
            <img src={d.thumbnail} alt="" className="h-full w-full object-cover" />
          ) : (
            <span className="flex h-full w-full items-center justify-center" style={{ background: meta.glow }}>
              <TypeIcon type={d.type} size={16} />
            </span>
          )}
          <span className="absolute inset-x-0 bottom-0 h-[3px]" style={{ background: meta.color }} />
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate text-[11px] font-semibold leading-4" style={{ color: "var(--text-1)" }} dir="ltr">
            {d.name}
          </div>
          <div className="mt-0.5 flex items-center gap-1.5 truncate text-[8.5px] faint">
            <span dir="ltr">{d.host}</span>
            <span className="h-[3px] w-[3px] rounded-full bg-white/30" />
            <span className="truncate">{d.quality}</span>
          </div>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-0.5">
          {d.status === "done" ? (
            <CheckCircle2 size={16} style={{ color: "var(--success)" }} />
          ) : d.status === "failed" ? (
            <AlertTriangle size={15} style={{ color: "var(--danger)" }} />
          ) : d.status === "paused" ? (
            <Pause size={14} style={{ color: "var(--warning)" }} />
          ) : d.status === "queued" ? (
            <Clock3 size={14} className="faint" />
          ) : (
            <span className="text-[10px] font-bold tabular-nums" style={{ color: "var(--accent2)" }}>{Math.round(pct)}%</span>
          )}
          <span className="text-[7.5px] font-medium" style={{ color: st.color }}>{ar ? st.ar : st.en}</span>
        </div>
      </div>

      <div className="mt-2">
        <Progress value={pct} slim />
        <div className="mt-1 flex items-center justify-between text-[8px] faint" dir="ltr">
          <span className="tabular-nums font-medium" style={{ color: "var(--text-2)" }}>{formatBytes(d.downloaded)} / {formatBytes(d.bytes)}</span>
          <span className="tabular-nums">{((d.downloaded / d.bytes) * 100).toFixed(1)}%</span>
        </div>
      </div>

      <div className="mt-1.5 flex items-center justify-between gap-1 border-t pt-1.5" style={{ borderColor: "var(--line)" }}>
        <div className="flex min-w-0 items-center gap-1.5 text-[8px] faint">
          {d.status === "downloading" ? (
            <>
              <span className="flex items-center gap-0.5 font-semibold" style={{ color: "var(--accent2)" }}>
                <Zap size={9} /> {d.speed.toFixed(1)} MB/s
              </span>
              <span className="flex items-center gap-0.5"><Clock3 size={9} /> {eta(d)}</span>
              <span className="flex items-center gap-0.5"><Gauge size={9} /> {d.connections}</span>
            </>
          ) : d.status === "done" ? (
            <span className="truncate">{d.exact ? (ar ? "بايت مؤكد" : "exact bytes") : ar ? "تقريبي" : "approx"} · {formatBytes(d.bytes, !d.exact)}</span>
          ) : d.status === "failed" ? (
            <span className="truncate">{ar ? "403 · سيُجدَّد الرابط" : "403 · link refresh"}</span>
          ) : d.status === "paused" ? (
            <span>{ar ? "محفوظ من الجزء" : "Saved segment"} {Math.round(pct)}%</span>
          ) : (
            <span className="truncate">{ar ? "أولوية عالية" : "High priority"}</span>
          )}
        </div>
        <div className="flex shrink-0 items-center gap-1">
          {d.status === "queued" && (
            <>
              <button onClick={() => onMove(d.id, -1)} className={iconBtn} aria-label="move up"><ChevronUp size={11} /></button>
              <button onClick={() => onMove(d.id, 1)} className={iconBtn} aria-label="move down"><ChevronDown size={11} /></button>
            </>
          )}
          {(d.status === "downloading" || d.status === "queued") && (
            <button onClick={() => onAction(d.id, "pause")} className={iconBtn} aria-label={ar ? "إيقاف مؤقت" : "Pause"}><Pause size={11} /></button>
          )}
          {(d.status === "paused" || d.status === "failed") && (
            <button onClick={() => onAction(d.id, d.status === "failed" ? "retry" : "resume")} className="press-sm flex h-[26px] items-center gap-1 rounded-[8px] px-1.5 accent-gradient text-[7.5px] font-bold text-white" aria-label={ar ? "استئناف" : "Resume"}>
              {d.status === "failed" ? <RotateCcw size={10} /> : <Play size={10} fill="white" />}
              {d.status === "failed" ? (ar ? "إعادة" : "Retry") : null}
            </button>
          )}
          {d.status === "done" && (
            <button onClick={() => onAction(d.id, "open")} className="press flex h-[26px] items-center gap-1 rounded-[8px] border px-1.5 text-[7.5px] glass-soft"><FolderOpen size={10} /> {ar ? "فتح" : "Open"}</button>
          )}
          <button onClick={() => onToast(ar ? "خيارات إضافية" : "More options", ar ? "مشاركة، نسخ الرابط، تحويل، تصغير" : "Share, copy, convert, compress")} className={iconBtn} aria-label="more"><MoreHorizontal size={11} /></button>
          <button onClick={() => onAction(d.id, "delete")} className={iconBtn} aria-label="delete"><Trash2 size={10} style={{ color: "var(--danger)" }} /></button>
        </div>
      </div>
    </div>
  );
}

export function Downloads({ lang, downloads, onAction, onMove, onNavigate, onToast }: DownloadsProps) {
  const [filter, setFilter] = useState<"all" | DownloadStatus>("all");
  const counts = useMemo(() => {
    const base: Record<string, number> = { all: downloads.length };
    for (const d of downloads) base[d.status] = (base[d.status] ?? 0) + 1;
    return base;
  }, [downloads]);
  const visible = filter === "all" ? downloads : downloads.filter((d) => d.status === filter);
  const active = downloads.filter((d) => d.status === "downloading");
  const totalSpeed = active.reduce((a, b) => a + b.speed, 0);
  const totalConnections = active.reduce((a, b) => a + b.connections, 0);
  const downloadedTotal = downloads.reduce((a, b) => a + b.downloaded, 0);
  const overallTotal = downloads.reduce((a, b) => a + b.bytes, 0) || 1;
  const overall = (downloadedTotal / overallTotal) * 100;

  return (
    <div className="px-3.5 pt-1">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-[10.2px] font-medium" style={{ color: "var(--accent2)" }}>
            <span className="h-1.5 w-1.5 rounded-full accent-gradient" />
            {lang === "ar" ? "محرك مجزّأ · 32 اتصالًا" : "Segmented engine · 32 conns"}
          </div>
          <h1 className="mt-0.5 text-[23px] font-bold leading-tight">{lang === "ar" ? "مدير التحميلات" : "Download manager"}</h1>
          <p className="mt-0.5 text-[10.2px] muted">{lang === "ar" ? "طابور ذكي، استئناف دائم، وسرعة قصوى." : "Smart queue, permanent resume, max speed."}</p>
        </div>
        <button onClick={() => onNavigate("settings")} className="press flex h-8 w-8 items-center justify-center rounded-[11px] border glass-soft" aria-label="downloads settings">
          <SlidersHorizontal size={14} />
        </button>
      </div>

      {/* live summary */}
      <div className="relative mt-3 overflow-hidden rounded-[24px] border p-3 glass noise" style={{ borderColor: "var(--line)" }}>
        <div className="absolute -end-8 -top-8 h-28 w-28 rounded-full opacity-30 blur-2xl accent-gradient" />
        <div className="relative flex items-center justify-between">
          <div>
            <div className="text-[9.2px] faint">{lang === "ar" ? "السرعة الإجمالية الآن" : "Total speed now"}</div>
            <div className="mt-0.5 flex items-end gap-1">
              <span className="font-[Outfit] text-[27px] font-semibold leading-none tabular-nums">{totalSpeed.toFixed(1)}</span>
              <span className="mb-0.5 text-[10.5px] font-medium muted">MB/s</span>
            </div>
            <div className="mt-1.5 flex items-center gap-1.5">
              <Chip tone="accent"><Zap size={9} /> {active.length} {lang === "ar" ? "نشط" : "active"}</Chip>
              <Chip tone="neutral"><Gauge size={9} /> {totalConnections} {lang === "ar" ? "اتصال" : "conn"}</Chip>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <Sparkline data={[10, 16, 13, 22, 19, 28, 26, 34, 30, 38, 36, 44, 41, totalSpeed]} width={108} height={38} />
            <div className="flex items-center gap-1 text-[9.2px]" style={{ color: "var(--success)" }}>
              <Wifi size={9} /> {lang === "ar" ? "HTTP/3 · QUIC نشط" : "HTTP/3 · QUIC active"}
            </div>
          </div>
        </div>
        <div className="relative mt-2.5">
          <div className="mb-1 flex justify-between text-[9.2px] faint">
            <span>{lang === "ar" ? "تقدم الطابور الكلي" : "Overall queue"}</span>
            <span className="tabular-nums">{formatBytes(overall)} / {formatBytes(overallTotal)}</span>
          </div>
          <Progress value={(overall / overallTotal) * 100} slim />
        </div>
      </div>

      <div className="mt-2 flex gap-1.5">
        <button
          onClick={() => { downloads.filter((d) => d.status === "downloading").forEach((d) => onAction(d.id, "pause")); onToast(lang === "ar" ? "تم إيقاف جميع التحميلات" : "All downloads paused"); }}
          className="press flex flex-1 items-center justify-center gap-1 rounded-[13px] border py-2 text-[10.2px] font-medium glass-soft"
        >
          <Pause size={11} /> {lang === "ar" ? "إيقاف الكل" : "Pause all"}
        </button>
        <button
          onClick={() => { downloads.filter((d) => d.status === "paused").forEach((d) => onAction(d.id, "resume")); onToast(lang === "ar" ? "تم استئناف التحميلات" : "Downloads resumed"); }}
          className="press flex flex-1 items-center justify-center gap-1 rounded-[13px] border py-2 text-[10.2px] font-medium glass-soft"
        >
          <Play size={11} /> {lang === "ar" ? "استئناف الكل" : "Resume all"}
        </button>
        <button onClick={() => onNavigate("home")} className="press flex items-center justify-center gap-1 rounded-[13px] px-3 py-2 text-[10.2px] font-bold btn-primary">
          <Plus size={11} /> {lang === "ar" ? "رابط" : "Link"}
        </button>
      </div>

      {/* tabs */}
      <div className="no-scrollbar mt-3 flex gap-1 overflow-x-auto rounded-[15px] border p-1 glass-soft" style={{ borderColor: "var(--line)" }}>
        {tabs.map((t) => {
          const activeTab = filter === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setFilter(t.id)}
              className="press flex min-w-0 flex-1 shrink-0 items-center justify-center gap-1 rounded-[11px] px-2 py-1.5 text-[9.7px] font-medium transition-all"
              style={{
                background: activeTab ? "linear-gradient(120deg,var(--accent1),var(--accent2))" : "transparent",
                color: activeTab ? "#fff" : "var(--text-2)",
                boxShadow: activeTab ? "0 5px 14px -7px var(--accent2)" : "none",
              }}
            >
              {lang === "ar" ? t.ar : t.en}
              <span className={`rounded-full px-1 text-[8.7px] font-bold ${activeTab ? "bg-black/20" : "bg-white/8"}`}>{counts[t.id] ?? 0}</span>
            </button>
          );
        })}
      </div>

      <div className="mt-3 space-y-2">
        {visible.length === 0 && (
          <div className="rounded-[24px] border p-6 text-center glass-soft">
            <Download size={26} className="mx-auto faint" />
            <div className="mt-2 text-[11.5px] font-semibold">{lang === "ar" ? "لا توجد عناصر هنا" : "Nothing here yet"}</div>
            <div className="mt-1 text-[10.2px] faint">{lang === "ar" ? "أضف رابطًا للبدء" : "Add a link to get started"}</div>
          </div>
        )}
        {visible.map((d) => (
          <DownloadCard key={d.id} d={d} lang={lang} onAction={onAction} onMove={onMove} onToast={onToast} />
        ))}
      </div>

      <div className="mt-3 rounded-[18px] border p-2.5 glass-soft">
        <div className="flex items-start gap-2">
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-[9px] accent-soft">
            <ShieldCheck size={13} style={{ color: "var(--accent2)" }} />
          </span>
          <div className="min-w-0">
            <div className="text-[10.2px] font-semibold">{lang === "ar" ? "استئناف مضمون بعد إغلاق التطبيق" : "Guaranteed resume after app close"}</div>
            <div className="mt-0.5 text-[9.2px] leading-4 faint">
              {lang === "ar" ? "حالة كل جزء محفوظة في Room مع ETag وLast-Modified. يعمل عبر WorkManager والخدمة الأمامية." : "Every segment state is stored in Room with ETag & Last-Modified via WorkManager."}
            </div>
          </div>
        </div>
        <div className="mt-2 flex flex-wrap gap-1">
          <Chip tone="success"><Wifi size={9} /> Wi-Fi فقط</Chip>
          <Chip tone="neutral"><Settings2 size={9} /> 3 متزامنة</Chip>
          <Chip tone="neutral"><Clock3 size={9} /> 20:00</Chip>
          <Chip tone="accent"><Share2 size={9} /> إشعارات Pause/Resume</Chip>
        </div>
      </div>

      <div className="mt-3">
        <SectionTitle title={lang === "ar" ? "مقترح بعد التحميل" : "After download"} />
        <button
          onClick={() => onNavigate("tools")}
          className="press flex w-full items-center gap-2.5 rounded-[18px] border p-2.5 text-start glass-soft"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-[12px]" style={{ background: "rgba(255,210,132,.12)" }}>
            <Zap size={15} style={{ color: "var(--warning)" }} />
          </span>
          <div className="min-w-0 flex-1">
            <div className="text-[10.7px] font-semibold">{lang === "ar" ? "وفّر 148 MB من الفيديو بجودة بصرية مطابقة" : "Save 148 MB with visually identical video"}</div>
            <div className="text-[9.2px] faint">{lang === "ar" ? "الضاغط الذكي · HEVC وVMAF ≥ 95" : "Smart compressor · HEVC & VMAF ≥ 95"}</div>
          </div>
          <ChevronDown size={14} className="rotate-90 faint" />
        </button>
      </div>

      <div className="mt-3 flex items-center justify-center gap-1 pb-1 text-[8.7px] faint">
        <X size={8} /> {lang === "ar" ? "لا يتم تجاوز أي حماية DRM أو جدار دفع" : "No DRM or paywall bypass"}
      </div>
    </div>
  );
}
