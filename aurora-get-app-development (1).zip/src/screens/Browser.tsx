import { useMemo, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  CloudDownload,
  Cookie,
  Lock,
  Monitor,
  MoreHorizontal,
  Plus,
  Radar,
  RefreshCw,
  Shield,
  ShieldCheck,
  Play,
  Download,
  AlertTriangle,
  Layers3,
  Wifi,
} from "lucide-react";
import type { ContentType, Lang } from "../data";
import { browserItems, contentTypeMeta, exactBytes, formatBytes, images } from "../data";
import { Chip, Progress, Sheet, TypeIcon } from "../components/ui";

export type BrowserProps = {
  lang: Lang;
  onDownload: (item: { name: string; host: string; type: ContentType; bytes: number; approx: boolean; quality: string; thumb?: string }) => void;
  onToast: (m: string, d?: string) => void;
};

export function Browser({ lang, onDownload, onToast }: BrowserProps) {
  const [input, setInput] = useState("auroratravel.com/journal/northern-lights");
  const [loading, setLoading] = useState(false);
  const [sniffer, setSniffer] = useState(false);
  const [shieldOpen, setShieldOpen] = useState(false);
  const [adblock, setAdblock] = useState(true);
  const [desktop, setDesktop] = useState(false);
  const [detections, setDetections] = useState(browserItems);
  const [added, setAdded] = useState<string[]>([]);
  const blocked = 37;

  const go = (next?: string) => {
    const target = (next ?? input).replace(/^https?:\/\//, "");
    if (!target.trim()) return;
    setInput(target);
    setLoading(true);
    window.setTimeout(() => {
      setLoading(false);
      if (!detections.length) setDetections(browserItems);
      onToast(lang === "ar" ? "تم تحديث الصفحة" : "Page refreshed", target);
    }, 850);
  };

  const download = (item: (typeof browserItems)[number]) => {
    onDownload({ name: item.title, host: "auroratravel.com", type: item.type, bytes: item.bytes, approx: item.approx, quality: item.detail, thumb: item.type === "video" ? images.aurora : item.type === "image" ? images.auroraAlt : undefined });
    setAdded((a) => [...a, item.id]);
    onToast(lang === "ar" ? "أُضيف إلى محرك Aurora" : "Sent to Aurora engine", lang === "ar" ? "الكوكيز وUser-Agent وReferer نُقلت تلقائيًا" : "Cookies, User-Agent & Referer transferred");
  };

  const radarPulse = useMemo(() => detections.length, [detections.length]);

  return (
    <div className="flex flex-col pt-1">
      <div className="flex items-center justify-between px-3.5">
        <div>
          <div className="flex items-center gap-1.5 text-[10.2px] font-medium" style={{ color: "var(--accent2)" }}>
            <ShieldCheck size={10} />
            {lang === "ar" ? "متصفح داخلي + صيّاد ملفات" : "In-app browser + sniffer"}
          </div>
          <h1 className="mt-0.5 text-[22px] font-bold leading-tight">{lang === "ar" ? "اصطد ما تريد" : "Catch anything"}</h1>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => onToast(lang === "ar" ? "تبويب جديد" : "New tab", lang === "ar" ? "وضع خاص · لا حفظ للسجل" : "Private mode · no history saved")} className="press flex h-8 w-8 items-center justify-center rounded-[10px] border glass-soft">
            <Plus size={14} />
          </button>
          <button onClick={() => onToast(lang === "ar" ? "التبويبات" : "Tabs", lang === "ar" ? "تبويبان مفتوحان" : "2 tabs open")} className="press relative flex h-8 w-8 items-center justify-center rounded-[10px] border glass-soft">
            <Layers3 size={14} />
            <span className="absolute -end-1 -top-1 flex h-3.5 w-3.5 items-center justify-center rounded-full accent-gradient text-[8.2px] font-bold text-white">2</span>
          </button>
        </div>
      </div>

      {/* browser chrome */}
      <div className="mt-2.5 px-3.5">
        <div className="rounded-[20px] border p-1.5 glass-soft">
          <div className="flex items-center gap-1">
            <button onClick={() => onToast(lang === "ar" ? "رجوع" : "Back")} className="press-sm flex h-6 w-6 items-center justify-center rounded-md faint"><ArrowRight size={12} /></button>
            <button onClick={() => onToast(lang === "ar" ? "تقدم" : "Forward")} className="press-sm flex h-6 w-6 items-center justify-center rounded-md faint opacity-40"><ArrowLeft size={12} /></button>
            <div className="flex min-w-0 flex-1 items-center gap-1.5 rounded-[10px] border px-2 py-1.5" style={{ background: "var(--field)", borderColor: "var(--line)" }}>
              <Lock size={9} style={{ color: "var(--success)" }} />
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && go()}
                dir="ltr"
                className="min-w-0 flex-1 bg-transparent text-[10.2px] outline-none"
                style={{ color: "var(--text-1)" }}
                aria-label="address"
              />
              {loading ? <RefreshCw size={10} className="spin-slow" style={{ color: "var(--accent2)" }} /> : <button onClick={() => go()}><RefreshCw size={10} className="faint" /></button>}
            </div>
            <button onClick={() => setDesktop(!desktop)} className={`press-sm flex h-6 w-6 items-center justify-center rounded-md ${desktop ? "bg-white/10" : ""}`} style={{ color: desktop ? "var(--accent2)" : "var(--text-3)" }}><Monitor size={11} /></button>
            <button onClick={() => onToast(lang === "ar" ? "خيارات الصفحة" : "Page options", "JavaScript · Cookies · AdBlock")} className="press-sm flex h-6 w-6 items-center justify-center rounded-md faint"><MoreHorizontal size={12} /></button>
          </div>
          {loading && <div className="mt-1 px-1"><Progress value={64} slim /></div>}
        </div>

        <div className="mt-1.5 flex items-center gap-1.5">
          <button
            onClick={() => setShieldOpen(!shieldOpen)}
            className="press flex items-center gap-1 rounded-full border px-2 py-1 text-[9.7px] font-medium"
            style={{
              background: adblock ? "rgba(94,225,176,.1)" : "var(--glass)",
              borderColor: adblock ? "rgba(94,225,176,.25)" : "var(--line)",
              color: adblock ? "var(--success)" : "var(--text-2)",
            }}
          >
            <Shield size={10} />
            {adblock ? `${blocked} ${lang === "ar" ? "محجوب" : "blocked"}` : lang === "ar" ? "الحماية متوقفة" : "Protection off"}
          </button>
          <Chip tone="success"><Lock size={8} /> cf_clearance</Chip>
          <Chip tone="neutral"><Cookie size={8} /> {lang === "ar" ? "جلسة محفوظة" : "Session"}</Chip>
          <span className="ms-auto flex items-center gap-0.5 text-[9.2px] faint"><Wifi size={9} /> 12ms</span>
        </div>

        {shieldOpen && (
          <div className="fade-enter mt-1.5 rounded-[16px] border p-2.5 glass">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1 text-[10.7px] font-semibold"><ShieldCheck size={11} style={{ color: "var(--success)" }} /> {lang === "ar" ? "درع Aurora" : "Aurora Shield"}</span>
              <button onClick={() => setAdblock(!adblock)} className={`rounded-full px-2 py-0.5 text-[9.2px] font-bold text-white ${adblock ? "accent-gradient" : "bg-white/10"}`}>{adblock ? (lang === "ar" ? "مفعّل" : "On") : (lang === "ar" ? "متوقف" : "Off")}</button>
            </div>
            <div className="mt-1.5 grid grid-cols-3 gap-1">
              {[
                { ar: "إعلانات", en: "Ads", n: 21 },
                { ar: "متعقبات", en: "Trackers", n: 11 },
                { ar: "نوافذ مزعجة", en: "Popups", n: 5 },
              ].map((x) => (
                <div key={x.en} className="rounded-[10px] border px-1.5 py-1 text-center" style={{ borderColor: "var(--line)" }}>
                  <div className="text-[13.5px] font-semibold tabular-nums" style={{ color: "var(--text-1)" }}>{x.n}</div>
                  <div className="text-[8.2px] faint">{lang === "ar" ? x.ar : x.en}</div>
                </div>
              ))}
            </div>
            <div className="mt-1.5 flex items-center justify-between text-[8.7px] faint">
              <span>EasyList · EasyPrivacy · uBlock</span>
              <span className="flex items-center gap-0.5" style={{ color: "var(--success)" }}><CheckCircle2 size={8} /> {lang === "ar" ? "حدّثت اليوم" : "Updated today"}</span>
            </div>
          </div>
        )}
      </div>

      {/* page canvas */}
      <div className="mt-2.5 px-3.5">
        <div className="relative overflow-hidden rounded-[22px] border glass-soft" style={{ boxShadow: "0 24px 50px -32px #000" }}>
          <div className="flex items-center justify-between border-b px-2.5 py-1.5" style={{ borderColor: "var(--line)" }}>
            <div className="flex items-center gap-1.5">
              <span className="flex h-5 w-5 items-center justify-center rounded-md" style={{ background: "linear-gradient(140deg,#55d9c0,#2d9dbe)" }}><Radar size={10} color="white" /></span>
              <span className="text-[10.2px] font-bold tracking-wide">AURORA TRAVEL</span>
            </div>
            <div className="flex items-center gap-2 text-[7.7px] faint">
              <span>Journal</span><span>Trips</span><span>About</span>
              <span className="rounded-full accent-soft px-1.5 py-0.5 text-[7.7px]" style={{ color: "var(--accent2)" }}>Subscribe</span>
            </div>
          </div>
          <div className="relative h-[150px]">
            <img src={images.auroraLake} alt="Northern lights over a lake" className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-black/20" />
            <div className="absolute inset-x-3 bottom-3">
              <div className="flex items-center gap-1">
                <span className="rounded-full bg-[#d96570]/90 px-1.5 py-0.5 text-[7.7px] font-bold text-white">TRAVEL</span>
                <span className="text-[7.7px] text-white/70">8 MIN READ</span>
              </div>
              <h2 className="mt-1 max-w-[260px] text-[15.5px] font-bold leading-tight text-white">Chasing the Northern Lights across Iceland</h2>
              <p className="mt-0.5 text-[8.7px] text-white/65">A 7-day road trip under the aurora borealis — a complete field guide.</p>
            </div>
            <button onClick={() => setSniffer(true)} className="press absolute end-2.5 top-2.5 flex items-center gap-1 rounded-full border border-white/20 bg-black/40 px-2 py-1 text-[8.7px] font-semibold text-white backdrop-blur-md">
              <Radar size={9} /> {radarPulse} {lang === "ar" ? "ملفات" : "files"}
            </button>
          </div>
          <div className="relative p-2.5">
            <p className="line-clamp-2 text-[9.2px] leading-4 muted">
              The sky above Lake Mývatn turned into a river of green and violet light just after midnight. We set up our cameras near the frozen shore, waiting for the perfect exposure…
            </p>
            <div className="mt-2 grid grid-cols-3 gap-1.5">
              {[images.aurora, images.auroraAlt, images.auroraLake].map((src, i) => (
                <div key={i} className="relative h-[46px] overflow-hidden rounded-[8px]">
                  <img src={src} alt="" className="h-full w-full object-cover" />
                  <span className="absolute inset-0 bg-black/10" />
                </div>
              ))}
            </div>
            <div className="mt-2 flex items-center justify-between rounded-[10px] border px-2 py-1.5" style={{ borderColor: "var(--line)", background: "var(--field)" }}>
              <span className="flex items-center gap-1 text-[8.7px]"><Play size={9} style={{ color: "var(--accent3)" }} /> 2160p HDR · 12:48</span>
              <span className="rounded-full px-1.5 py-0.5 text-[7.7px] font-bold accent-gradient text-white">WATCH</span>
            </div>
            <div className="mt-2 flex items-center justify-center gap-1 rounded-[8px] border border-dashed py-1.5 text-[8.2px]" style={{ borderColor: adblock ? "rgba(94,225,176,.3)" : "var(--line)", color: adblock ? "var(--success)" : "var(--text-3)" }}>
              <ShieldCheck size={9} /> {adblock ? (lang === "ar" ? "3 عناصر إعلانية حُجبت هنا" : "3 ad elements blocked here") : lang === "ar" ? "المساحة الإعلانية" : "Ad space"}
            </div>
          </div>
        </div>

        <div className="mt-2 flex items-center gap-1.5 rounded-[14px] border px-2.5 py-2 glass-soft">
          <span className="relative flex h-6 w-6 items-center justify-center rounded-full" style={{ background: "rgba(94,225,176,.13)" }}>
            <Radar size={12} style={{ color: "var(--success)" }} />
            <span className="absolute inset-0 animate-ping rounded-full border border-[#5ee1b0]/30" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="text-[9.7px] font-semibold">{lang === "ar" ? "الصيّاد يعمل بالتوازي" : "Sniffer running in parallel"}</div>
            <div className="truncate text-[8.2px] faint" dir="ltr">video/* · audio/* · .m3u8 · .mpd · blob: · fetch/XHR</div>
          </div>
          <Chip tone="success">{detections.length} {lang === "ar" ? "التُقط" : "caught"}</Chip>
        </div>
      </div>

      <div className="pointer-events-none sticky bottom-[92px] mt-2 flex justify-end px-4">
        <button
          onClick={() => setSniffer(true)}
          className="pointer-events-auto press relative flex h-[52px] w-[52px] items-center justify-center rounded-[18px] accent-gradient text-white"
          style={{ boxShadow: "0 14px 34px -10px var(--accent2), inset 0 1px 0 rgba(255,255,255,.4)" }}
          aria-label="open sniffer"
        >
          <CloudDownload size={21} />
          <span className="absolute -end-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full border border-white/20 bg-[#0b0e18] text-[9.2px] font-bold text-white">{detections.length}</span>
        </button>
      </div>

      <div className="mt-1 px-3.5 text-center text-[8.2px] faint">
        {lang === "ar" ? "Cookies + UA + Referer تنتقل تلقائيًا لمحرك التحميل" : "Cookies + UA + Referer flow to the download engine"}
      </div>

      <Sheet open={sniffer} onClose={() => setSniffer(false)} lang={lang} title={<><Radar size={16} style={{ color: "var(--accent2)" }} /> {lang === "ar" ? "الملفات المكتشفة" : "Detected media"}</>} subtitle={lang === "ar" ? "auroratravel.com · صيد مباشر من الشبكة + JavaScript" : "auroratravel.com · network + JS sniffer"}>
        <div className="mb-2.5 flex items-center justify-between rounded-[14px] border px-2.5 py-2" style={{ borderColor: "rgba(94,225,176,.22)", background: "rgba(94,225,176,.06)" }}>
          <span className="flex items-center gap-1 text-[9.7px]" style={{ color: "var(--success)" }}><ShieldCheck size={11} /> {lang === "ar" ? "تحدي Cloudflare محلول داخل WebView" : "Cloudflare challenge solved in WebView"}</span>
          <span className="text-[8.7px] faint">cf_clearance ✓</span>
        </div>
        <div className="space-y-1.5">
          {detections.map((item) => {
            const meta = contentTypeMeta[item.type];
            const isAdded = added.includes(item.id);
            return (
              <div key={item.id} className="flex items-center gap-2.5 rounded-[16px] border p-2 glass-soft" style={{ borderColor: "var(--line)" }}>
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[11px]" style={{ background: `${meta.glow}`, border: "1px solid var(--line)" }}>
                  <TypeIcon type={item.type} size={15} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[10.7px] font-semibold" style={{ color: "var(--text-1)" }} dir="ltr">{item.title}</div>
                  <div className="mt-0.5 flex items-center gap-1.5 text-[9.2px] faint">
                    <span>{item.format}</span><span className="h-1 w-1 rounded-full bg-white/25" /><span>{item.detail}</span>
                  </div>
                  <button
                    onClick={() => onToast(lang === "ar" ? "الحجم الدقيق" : "Exact size", exactBytes(item.bytes))}
                    className="mt-0.5 flex items-center gap-1 text-[9.2px] font-medium tabular-nums"
                    style={{ color: "var(--text-2)" }}
                  >
                    {formatBytes(item.bytes, item.approx)}
                    {item.approx && <span className="rounded-full bg-[#ffd284]/10 px-1 text-[8.2px]" style={{ color: "var(--warning)" }}>≈ {lang === "ar" ? "تقديري" : "approx"}</span>}
                    {!item.approx && <span className="rounded-full bg-[#5ee1b0]/10 px-1 text-[8.2px]" style={{ color: "var(--success)" }}>{lang === "ar" ? "مؤكد" : "exact"}</span>}
                  </button>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <button onClick={() => download(item)} className={`press flex h-6 items-center gap-1 rounded-[8px] px-2 text-[9.2px] font-bold ${isAdded ? "border glass-soft" : "btn-primary"}`}>
                    {isAdded ? <CheckCircle2 size={9} style={{ color: "var(--success)" }} /> : <Download size={9} />}
                    {isAdded ? (lang === "ar" ? "أُضيف" : "Added") : lang === "ar" ? "تحميل" : "Get"}
                  </button>
                  <button onClick={() => onToast(lang === "ar" ? "خيارات" : "Options", lang === "ar" ? "تحويل، نسخ الرابط، معاينة" : "Convert, copy, preview")} className="press-sm"><MoreHorizontal size={11} className="faint" /></button>
                </div>
              </div>
            );
          })}
        </div>
        <div className="mt-2.5 flex items-start gap-1.5 rounded-[12px] border border-[#ffd284]/20 bg-[#ffd284]/5 p-2 text-[8.7px] leading-4" style={{ color: "var(--warning)" }}>
          <AlertTriangle size={10} className="mt-0.5 shrink-0" />
          {lang === "ar" ? "لا يتجاوز التطبيق أي DRM أو Paywall. احترم حقوق النشر والملكية." : "No DRM or paywall bypass. Respect copyright and ownership."}
        </div>
        <button onClick={() => { setSniffer(false); onToast(lang === "ar" ? "تم صيد كل الملفات" : "All media caught"); }} className="press mt-3 flex w-full items-center justify-center gap-1.5 rounded-[14px] py-2.5 text-[10.7px] font-bold btn-primary">
          <Download size={12} /> {lang === "ar" ? "تحميل الكل عبر Aurora" : "Download all with Aurora"} ({detections.length})
        </button>
      </Sheet>
    </div>
  );
}
