import { useState } from "react";
import {
  BatteryCharging,
  Bell,
  Check,
  ChevronLeft,
  CloudOff,
  Cpu,
  Database,
  Download,
  FileJson,
  FileText,
  Fingerprint,
  FolderTree,
  Gauge,
  Globe,
  Info,
  Languages,
  Leaf,
  Lock,
  Moon,
  Palette,
  RefreshCw,
  Server,
  Shield,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Sun,
  Trash2,
  Upload,
  Wifi,
  Zap,
  Music2,
  Radio,
  Merge,
  ArrowLeftRight,
  Sliders,
  CheckCircle2,
  CircleHelp,
  Car,
} from "lucide-react";
import type { Appearance, Lang, ThemeId } from "../data";
import { themes } from "../data";
import { BrandMark, Chip, Progress, Toggle } from "../components/ui";

export type SettingsProps = {
  lang: Lang;
  setLang: (l: Lang) => void;
  theme: ThemeId;
  setTheme: (t: ThemeId) => void;
  appearance: Appearance;
  setAppearance: (a: Appearance) => void;
  concurrency: number;
  setConcurrency: (n: number) => void;
  onToast: (m: string, d?: string) => void;
  onOnboarding: () => void;
  onNavigate: (s: "files" | "downloads" | "browser" | "tools") => void;
};

function Row({
  icon: Icon,
  label,
  sub,
  right,
  onClick,
  color = "var(--text-2)",
}: {
  icon: React.ElementType;
  label: string;
  sub?: string;
  right?: React.ReactNode;
  onClick?: () => void;
  color?: string;
}) {
  return (
    <div
      role={onClick ? "button" : undefined}
      onClick={onClick}
      className={`flex items-center gap-2.5 px-2.5 py-2 ${onClick ? "press cursor-pointer" : ""}`}
    >
      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-[9px]" style={{ background: "var(--glass-2)" }}>
        <Icon size={13} style={{ color }} />
      </span>
      <div className="min-w-0 flex-1">
        <div className="text-[10.7px] font-medium" style={{ color: "var(--text-1)" }}>{label}</div>
        {sub && <div className="mt-0.5 text-[8.7px] leading-3.5 faint">{sub}</div>}
      </div>
      {right ?? (onClick ? <ChevronLeft size={12} className="shrink-0 faint rtl:rotate-180" /> : null)}
    </div>
  );
}

function Group({ title, icon: Icon, children }: { title: string; icon: React.ElementType; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1.5 flex items-center gap-1.5 px-0.5 text-[10.2px] font-semibold" style={{ color: "var(--text-2)" }}>
        <Icon size={10} style={{ color: "var(--accent2)" }} />
        {title}
      </div>
      <div className="divide-y rounded-[18px] border glass-soft" style={{ borderColor: "var(--line)" }}>
        <div className="divide-y" style={{ borderColor: "var(--line)" }}>{children}</div>
      </div>
    </div>
  );
}

export function Settings({ lang, setLang, theme, setTheme, appearance, setAppearance, concurrency, setConcurrency, onToast, onOnboarding, onNavigate }: SettingsProps) {
  const ar = lang === "ar";
  const [wifiOnly, setWifiOnly] = useState(true);
  const [charging, setCharging] = useState(false);
  const [notify, setNotify] = useState(true);
  const [batterySaver, setBatterySaver] = useState(false);
  const [doh, setDoh] = useState(true);
  const [http3, setHttp3] = useState(true);
  const [adblock, setAdblock] = useState(true);
  const [tracker, setTracker] = useState(true);
  const [autoUpdate, setAutoUpdate] = useState(true);
  const [metadata, setMetadata] = useState(true);
  const [autoFolders, setAutoFolders] = useState(true);
  const [duplicates, setDuplicates] = useState(true);
  const [hardware, setHardware] = useState(true);
  const [testing, setTesting] = useState(false);
  const [speed, setSpeed] = useState<number | null>(null);

  const runSpeed = () => {
    setTesting(true);
    setSpeed(null);
    window.setTimeout(() => {
      setTesting(false);
      setSpeed(248.6);
      onToast(ar ? "نتيجة اختبار السرعة" : "Speed test result", ar ? "248.6 Mbps · يُقترح 32 اتصالًا" : "248.6 Mbps · 32 connections recommended");
    }, 1500);
  };

  return (
    <div className="px-3.5 pt-1">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-[10.2px] font-medium" style={{ color: "var(--accent2)" }}>
            <ShieldCheck size={10} /> {ar ? "خصوصية كاملة · Offline-first" : "Private · Offline-first"}
          </div>
          <h1 className="mt-0.5 text-[23px] font-bold leading-tight">{ar ? "الإعدادات" : "Settings"}</h1>
        </div>
        <Chip tone="success"><span className="h-1.5 w-1.5 rounded-full bg-[var(--success)]" /> {ar ? "متصل بأمان" : "Secure"}</Chip>
      </div>

      {/* profile */}
      <div className="relative mt-2.5 overflow-hidden rounded-[22px] border p-3 glass noise" style={{ borderColor: "var(--line)" }}>
        <div className="absolute -end-6 -top-8 h-24 w-24 rounded-full accent-gradient opacity-20 blur-2xl" />
        <div className="relative flex items-center gap-2.5">
          <span className="flex h-11 w-11 items-center justify-center rounded-[15px] font-[Outfit] text-[13.5px] font-bold text-white accent-gradient" style={{ boxShadow: "0 10px 24px -10px var(--accent2)" }}>AG</span>
          <div className="min-w-0 flex-1">
            <div className="text-[12px] font-semibold">Ahmed · {ar ? "مستخدم محلي" : "Local user"}</div>
            <div className="mt-0.5 text-[9.2px] faint">{ar ? "لا حساب، لا سحابة، لا تتبع." : "No account, no cloud, no tracking."}</div>
            <div className="mt-1 flex gap-1"><Chip tone="accent"><Sparkles size={8} /> Aurora Pro</Chip><Chip tone="neutral">{ar ? "إصدار 1.0.0" : "v1.0.0"}</Chip></div>
          </div>
          <div className="text-end">
            <div className="text-[15.5px] font-semibold tabular-nums">84.2</div>
            <div className="text-[8.2px] faint">GB {ar ? "محمّل" : "downloaded"}</div>
          </div>
        </div>
      </div>

      <div className="mt-3 space-y-3.5">
        {/* appearance */}
        <Group title={ar ? "المظهر والهوية" : "Appearance"} icon={Palette}>
          <div className="px-2.5 py-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-[10.2px]"><Palette size={11} style={{ color: "var(--accent2)" }} /> {ar ? "سمة Aurora Glass" : "Aurora Glass theme"}</div>
              <Chip tone="accent">{themes.find((t) => t.id === theme)?.ar}</Chip>
            </div>
            <div className="mt-2 grid grid-cols-6 gap-1.5">
              {themes.map((t) => (
                <button key={t.id} onClick={() => { setTheme(t.id); onToast(ar ? "تم تغيير السمة" : "Theme changed", ar ? t.ar : t.en); }} className="press flex flex-col items-center gap-1" aria-label={t.ar}>
                  <span className="relative h-8 w-8 rounded-[11px] border p-[2px]" style={{ borderColor: theme === t.id ? "white" : "var(--line)", boxShadow: theme === t.id ? "0 0 0 3px var(--accent-soft)" : "none" }}>
                    <span className="block h-full w-full rounded-[8px]" style={{ background: t.swatch }} />
                    {theme === t.id && <span className="absolute -end-1 -top-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-white text-[#111]"><Check size={8} strokeWidth={3.5} /></span>}
                  </span>
                  <span className="text-[7.7px] faint">{ar ? t.ar : t.en}</span>
                </button>
              ))}
            </div>
            <div className="mt-2.5 grid grid-cols-2 gap-1 rounded-[10px] border p-[3px]" style={{ borderColor: "var(--line)" }}>
              {[
                { id: "dark" as const, label: ar ? "داكن" : "Dark", icon: Moon },
                { id: "light" as const, label: ar ? "فاتح" : "Light", icon: Sun },
              ].map((x) => (
                <button key={x.id} onClick={() => setAppearance(x.id)} className="press flex items-center justify-center gap-1 rounded-[8px] py-1.5 text-[9.2px] font-medium" style={{ background: appearance === x.id ? "var(--accent-soft)" : "transparent", color: appearance === x.id ? "var(--text-1)" : "var(--text-2)" }}>
                  <x.icon size={10} /> {x.label}
                </button>
              ))}
            </div>
          </div>
          <Row icon={Languages} label={ar ? "لغة التطبيق" : "App language"} sub={ar ? "واجهة عربية RTL كاملة + English" : "Full Arabic RTL + English"} right={
            <div className="flex rounded-full border p-[2px]" style={{ borderColor: "var(--line)" }}>
              {(["ar", "en"] as Lang[]).map((l) => (
                <button key={l} onClick={() => setLang(l)} className="press rounded-full px-2 py-0.5 text-[8.7px] font-bold" style={{ background: lang === l ? "var(--accent-soft)" : "transparent", color: lang === l ? "var(--accent2)" : "var(--text-3)" }}>{l === "ar" ? "العربية" : "EN"}</button>
              ))}
            </div>
          } />
          <Row icon={Sparkles} label={ar ? "إعادة جولة الترحيب" : "Replay onboarding"} sub={ar ? "أنيميشن Orb والجولة القصيرة" : "Orb animation & quick tour"} onClick={onOnboarding} />
        </Group>

        {/* download */}
        <Group title={ar ? "التحميل والطابور" : "Downloads & queue"} icon={Download}>
          <div className="px-2.5 py-2.5">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[10.2px]"><Gauge size={11} style={{ color: "var(--accent2)" }} /> {ar ? "أقصى اتصالات متوازية" : "Max parallel connections"}</span>
              <Chip tone="accent">{concurrency}</Chip>
            </div>
            <input type="range" min={8} max={32} step={4} value={concurrency} onChange={(e) => setConcurrency(Number(e.target.value))} className="range-aurora mt-1.5 w-full" />
            <div className="flex justify-between text-[7.7px] faint"><span>8</span><span>16</span><span>24</span><span>32</span></div>
          </div>
          <Row icon={Wifi} label={ar ? "Wi-Fi فقط" : "Wi-Fi only"} sub={ar ? "تجنب بيانات الجوال" : "Avoid mobile data"} right={<Toggle on={wifiOnly} onChange={setWifiOnly} label="wifi" />} />
          <Row icon={BatteryCharging} label={ar ? "الشحن فقط" : "Charging only"} sub={ar ? "ابدأ عند توصيل الشاحن" : "Start when plugged in"} right={<Toggle on={charging} onChange={setCharging} label="charging" />} />
          <Row icon={Bell} label={ar ? "إشعارات غنية" : "Rich notifications"} sub={ar ? "Pause / Resume / Cancel مع التقدم" : "Pause / Resume / Cancel with progress"} right={<Toggle on={notify} onChange={setNotify} label="notify" />} />
          <Row icon={Leaf} label={ar ? "توفير البطارية والبيانات" : "Battery & data saver"} sub={ar ? "يخفض الاتصالات ويؤجل التحميلات" : "Fewer connections, defer downloads"} right={<Toggle on={batterySaver} onChange={setBatterySaver} label="saver" />} />
          <Row icon={FolderTree} label={ar ? "التنظيم التلقائي" : "Auto-organize"} sub="/Aurora/{type}/{site}/{date}" right={<Toggle on={autoFolders} onChange={setAutoFolders} label="folders" />} />
          <Row icon={Merge} label={ar ? "دمج DASH تلقائيًا" : "Auto merge DASH"} sub="FFmpeg -c copy · أفضل صوت" right={<Chip tone="success">{ar ? "مفعّل" : "On"}</Chip>} />
        </Group>

        {/* network */}
        <Group title={ar ? "الشبكة والأداء" : "Network & performance"} icon={Server}>
          <Row icon={Radio} label={ar ? "HTTP/3 عبر Cronet" : "HTTP/3 via Cronet"} sub="QUIC + HTTP/2 multiplexing" right={<Toggle on={http3} onChange={setHttp3} label="http3" />} />
          <Row icon={Lock} label={ar ? "DNS-over-HTTPS" : "DNS-over-HTTPS"} sub={ar ? "تشفير استعلامات DNS + كاش" : "Encrypted DNS + cache"} right={<Toggle on={doh} onChange={setDoh} label="doh" />} />
          <Row
            icon={Gauge}
            label={ar ? "اختبار سرعة الشبكة" : "Network speed test"}
            sub={testing ? (ar ? "جارٍ القياس…" : "Measuring…") : speed ? `${speed} Mbps · ${ar ? "اقتراح 32 اتصالًا" : "suggest 32 conns"}` : ar ? "اقتراح عدد الاتصالات الأمثل" : "Suggest optimal connections"}
            onClick={runSpeed}
            right={testing ? <RefreshCw size={12} className="spin-slow" style={{ color: "var(--accent2)" }} /> : <Chip tone={speed ? "success" : "neutral"}>{speed ? `${speed}` : ar ? "ابدأ" : "Run"}</Chip>}
          />
          <Row icon={Sliders} label={ar ? "حد السرعة" : "Speed limiter"} sub={ar ? "غير محدود حاليًا" : "Unlimited currently"} right={<Chip>{ar ? "غير محدود" : "Unlimited"}</Chip>} onClick={() => onToast(ar ? "حد السرعة" : "Speed limit", ar ? "إنشاء ملف تعريف للحدود" : "Create a bandwidth profile")} />
        </Group>

        {/* privacy */}
        <Group title={ar ? "الخصوصية والحماية" : "Privacy & protection"} icon={Shield}>
          <Row icon={ShieldCheck} label={ar ? "حجب الإعلانات والمتعقبات" : "Ad & tracker blocking"} sub="EasyList · EasyPrivacy · uBlock" right={<Toggle on={adblock} onChange={setAdblock} label="adblock" />} />
          <Row icon={CloudOff} label={ar ? "حظر النوافذ المزعجة" : "Block popups & redirects"} sub={ar ? "يمنع أزرار Download المضللة" : "Blocks deceptive download buttons"} right={<Toggle on={tracker} onChange={setTracker} label="tracker" />} />
          <Row icon={Fingerprint} label={ar ? "قفل القبو بالبصمة" : "Vault biometric lock"} sub="AES-256 · AndroidX Biometric" right={<Chip tone="success"><Lock size={8} /> {ar ? "مفعّل" : "On"}</Chip>} onClick={() => onNavigate("files")} />
          <Row icon={Database} label={ar ? "مسح ذاكرة التحليل المؤقتة" : "Clear analysis cache"} sub={ar ? "14.8 MB · تحليل 62 رابطًا" : "14.8 MB · 62 analyzed links"} onClick={() => onToast(ar ? "تم مسح الكاش" : "Cache cleared", ar ? "أُبقيت نتائجك المحفوظة وسجلّك" : "Saved results & history kept")} right={<Trash2 size={11} style={{ color: "var(--danger)" }} />} />
          <Row icon={Shield} label={ar ? "الكوكيز مشفرة" : "Encrypted cookies"} sub="EncryptedSharedPreferences" right={<Chip tone="success">{ar ? "آمن" : "Secure"}</Chip>} />
        </Group>

        {/* media */}
        <Group title={ar ? "المعالجة والوسائط" : "Media & processing"} icon={Cpu}>
          <Row icon={Music2} label={ar ? "تضمين البيانات الوصفية" : "Embed metadata"} sub={ar ? "العنوان والفنان والغلاف" : "Title, artist & cover"} right={<Toggle on={metadata} onChange={setMetadata} label="metadata" />} />
          <Row icon={FileText} label={ar ? "منع الملفات المكررة" : "Duplicate detection"} sub={ar ? "فحص Hash قبل الحفظ" : "Hash check before saving"} right={<Toggle on={duplicates} onChange={setDuplicates} label="dupes" />} />
          <Row icon={Zap} label={ar ? "ترميز عتادي" : "Hardware encoding"} sub="MediaCodec · HEVC / AV1" right={<Toggle on={hardware} onChange={setHardware} label="hardware" />} />
          <Row icon={ArrowLeftRight} label={ar ? "استوديو التحويل والضغط" : "Converter & compressor"} sub={ar ? "فيديو، صوت، صور، أرشيف، PDF" : "Video, audio, images, archive, PDF"} onClick={() => onNavigate("tools")} />
        </Group>

        {/* updates */}
        <Group title={ar ? "التحديثات والقوائم" : "Updates & lists"} icon={RefreshCw}>
          <Row icon={Sliders} label="yt-dlp" sub={ar ? "2026.02.14 · يُحدّث تلقائيًا" : "2026.02.14 · auto-updates"} right={<Chip tone="success">{ar ? "محدّث" : "Latest"}</Chip>} onClick={() => onToast(ar ? "فحص تحديث yt-dlp" : "Checking yt-dlp", ar ? "أنت على أحدث إصدار" : "You're up to date")} />
          <Row icon={Shield} label={ar ? "قوائم AdBlock" : "AdBlock lists"} sub={ar ? "EasyList + EasyPrivacy · اليوم" : "EasyList + EasyPrivacy · today"} right={<Chip tone="success">{ar ? "محدّثة" : "Updated"}</Chip>} onClick={() => onToast(ar ? "تحديث القوائم" : "Updating lists", "3 lists · 248,102 rules")} />
          <Row icon={RefreshCw} label={ar ? "تحديث تلقائي في الخلفية" : "Background auto-update"} sub={ar ? "عند بدء التطبيق · Wi-Fi فقط" : "On app start · Wi-Fi only"} right={<Toggle on={autoUpdate} onChange={setAutoUpdate} label="auto update" />} />
        </Group>

        {/* backup */}
        <Group title={ar ? "النسخ الاحتياطي والإحصاءات" : "Backup & stats"} icon={Database}>
          <Row icon={Upload} label={ar ? "تصدير السجل والإعدادات" : "Export history & settings"} sub={ar ? "ملف JSON محلي · بدون سحابة" : "Local JSON · no cloud"} onClick={() => onToast(ar ? "تم تصدير نسخة احتياطية" : "Backup exported", "aurora-backup-2026-02-14.json")} right={<FileJson size={12} style={{ color: "var(--accent2)" }} />} />
          <Row icon={FileText} label={ar ? "استعادة نسخة" : "Restore backup"} sub={ar ? "اختر ملف JSON" : "Choose a JSON file"} onClick={() => onToast(ar ? "تمت الاستعادة" : "Restored", ar ? "السجل والإعدادات جاهزة" : "History & settings ready")} />
          <div className="px-2.5 py-2.5">
            <div className="mb-1.5 flex items-center justify-between text-[9.2px]"><span className="muted">{ar ? "إجمالي ما وفّرته أداة الضغط" : "Total saved by compressor"}</span><span className="font-bold" style={{ color: "var(--success)" }}>3.42 GB</span></div>
            <Progress value={68} slim />
            <div className="mt-1.5 flex justify-between text-[7.7px] faint"><span>84.2 GB {ar ? "محمّل" : "downloaded"}</span><span>41.2 GB {ar ? "فيديو" : "video"}</span><span>12.8 GB {ar ? "صوت" : "audio"}</span></div>
          </div>
        </Group>

        {/* about */}
        <Group title={ar ? "عن التطبيق" : "About"} icon={Info}>
          <div className="flex items-center gap-2.5 px-2.5 py-2.5">
            <BrandMark size={34} />
            <div className="min-w-0 flex-1">
              <div className="font-[Outfit] text-[11.5px] font-semibold">Aurora Get <span className="text-[8.2px] faint">v1.0.0 (42)</span></div>
              <div className="text-[8.2px] faint">{ar ? "مُحمِّل ذكي بتصميم Aurora Glass · Custom Design System" : "Smart downloader · Custom Aurora Glass design"}</div>
            </div>
            <Chip tone="neutral">Kotlin</Chip>
          </div>
          <Row icon={ShieldCheck} label={ar ? "بدون Material · بدون Firebase" : "No Material · no Firebase"} sub={ar ? "Compose Foundation/UI فقط · صفر تتبع" : "Compose Foundation/UI only · zero tracking"} right={<CheckCircle2 size={12} style={{ color: "var(--success)" }} />} />
          <Row icon={Smartphone} label={ar ? "الحد الأدنى: Android 7.0" : "Minimum: Android 7.0"} sub="minSdk 24 · targetSdk 35" right={<Chip>API 24+</Chip>} />
          <Row icon={Car} label={ar ? "اختصارات وWidget" : "Shortcuts & widget"} sub={ar ? "لصق سريع من الشاشة الرئيسية" : "Quick paste from home screen"} right={<ChevronLeft size={12} className="rtl:rotate-180 faint" />} />
          <Row icon={CircleHelp} label={ar ? "المساعدة والترخيص" : "Help & licensing"} sub={ar ? "دليل الاستخدام · مكتبات مفتوحة" : "User guide · open-source licenses"} onClick={() => onToast(ar ? "المساعدة" : "Help", ar ? "yt-dlp, FFmpeg, Haze, Coil, Media3, OkHttp…" : "yt-dlp, FFmpeg, Haze, Coil, Media3, OkHttp…")} />
        </Group>

        <div className="rounded-[18px] border p-2.5" style={{ borderColor: "rgba(255,210,132,.18)", background: "rgba(255,210,132,.04)" }}>
          <div className="flex items-start gap-1.5 text-[8.7px] leading-4" style={{ color: "var(--warning)" }}>
            <Info size={11} className="mt-0.5 shrink-0" />
            {ar ? "المسؤولية على المستخدم في احترام حقوق النشر. لا يتجاوز التطبيق DRM (Widevine/FairPlay/PlayReady) ولا Paywalls، والتحميل مقصور على المحتوى المسموح به." : "Users are responsible for respecting copyright. Aurora Get does not bypass DRM (Widevine/FairPlay/PlayReady) or paywalls."}
          </div>
        </div>

        <div className="flex flex-col items-center gap-1 pb-2 text-center">
          <div className="flex items-center gap-1 text-[8.7px] faint"><Globe size={9} /> {ar ? "صُنع بعناية · Aurora Glass Design System" : "Crafted with Aurora Glass"}</div>
          <div className="text-[7.7px] faint opacity-70">© 2026 Aurora Get · No analytics · On-device first</div>
        </div>
      </div>
    </div>
  );
}
