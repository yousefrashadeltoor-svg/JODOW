import { useEffect, useState } from "react";
import {
  Bell,
  Clipboard,
  Copy,
  FileText,
  Film,
  Globe,
  Images,
  Link2,
  Lock,
  Music2,
  Pencil,
  Play,
  QrCode,
  Search,
  ShieldCheck,
  Sparkles,
  X,
  Zap,
  ScanLine,
  SlidersHorizontal,
  CircleCheck,
  Merge,
  MoreHorizontal,
  Clock3,
  Files,
} from "lucide-react";
import { BrandMark, SiteLogo, Chip, Progress, SectionTitle, TypeIcon } from "../components/ui";
import type { ContentType, DownloadItem, Lang, Screen, AnalyzedSource } from "../data";
import { contentTypeMeta, exactBytes, formatBytes, sources } from "../data";

const urlFor: Record<string, string> = {
  youtube: "https://www.youtube.com/watch?v=aurora-8k",
  tiktok: "https://www.tiktok.com/@aurora.moves/video/741203",
  instagram: "https://www.instagram.com/p/midnight-frequencies",
  direct: "https://cdn.auroraget.app/files/Design_Resources_v4.zip",
};

const typeIcons: Record<ContentType, typeof Film> = {
  video: Film,
  audio: Music2,
  image: Images,
  file: FileText,
};

export type HomeProps = {
  lang: Lang;
  analyzed: AnalyzedSource | null;
  status: "idle" | "analyzing" | "done";
  stage: number;
  url: string;
  setUrl: (v: string) => void;
  downloads: DownloadItem[];
  onAnalyze: (source: AnalyzedSource, url: string) => void;
  onReset: () => void;
  onOpenSheet: (type: ContentType) => void;
  onPreview: () => void;
  onNavigate: (s: Screen) => void;
  onTools: (tab: "convert" | "compress") => void;
  onToast: (msg: string, detail?: string) => void;
};

function ClipboardChip({ lang, onInsert, onClose }: { lang: Lang; onInsert: () => void; onClose: () => void }) {
  return (
    <div className="relative mb-2.5 flex items-center gap-2 rounded-[16px] border px-2.5 py-2 glass-soft fade-enter" style={{ borderColor: "color-mix(in srgb, var(--accent2) 35%, transparent)" }}>
      <span className="flex h-6 w-6 items-center justify-center rounded-[9px] accent-soft">
        <Sparkles size={12} style={{ color: "var(--accent2)" }} />
      </span>
      <div className="min-w-0 flex-1">
        <div className="text-[10.5px] font-semibold" style={{ color: "var(--text-1)" }}>
          {lang === "ar" ? "رابط مكتشف في الحافظة" : "Link detected in clipboard"}
        </div>
        <div className="truncate text-[10.2px] faint" dir="ltr">
          https://youtube.com/watch?v=aurora-8k
        </div>
      </div>
      <button onClick={onInsert} className="press rounded-full px-2 py-1 text-[10.7px] font-bold accent-gradient text-white">
        {lang === "ar" ? "إدراج" : "Insert"}
      </button>
      <button onClick={onClose} className="press flex h-5 w-5 items-center justify-center rounded-full bg-white/5">
        <X size={10} className="muted" />
      </button>
    </div>
  );
}

function AnalyzingSkeleton({ lang, stage }: { lang: Lang; stage: number }) {
  const stages =
    lang === "ar"
      ? ["تطبيع الرابط", "قراءة الترويسات", "المستخرِج السريع", "yt-dlp الكامل"]
      : ["Normalizing URL", "Reading headers", "Fast extractor", "Full yt-dlp"];
  return (
    <div className="relative overflow-hidden rounded-[26px] glass p-3.5">
      <div className="mb-3 flex items-center gap-2">
        <span className="flex h-6 w-6 items-center justify-center rounded-full accent-soft">
          <ScanLine size={13} className="spin-slow" style={{ color: "var(--accent2)" }} />
        </span>
        <span className="text-[11.5px] font-semibold" style={{ color: "var(--text-1)" }}>
          {lang === "ar" ? "جاري التحليل بالتوازي…" : "Analyzing in parallel…"}
        </span>
        <span className="ms-auto text-[10.2px] faint">Stage {Math.min(stage, 3)}/3</span>
      </div>
      <div className="flex gap-3">
        <div className="skeleton h-[86px] w-[96px] shrink-0 rounded-[16px]" />
        <div className="flex flex-1 flex-col gap-2 pt-1">
          <div className="skeleton h-2.5 w-3/4 rounded-full" />
          <div className="skeleton h-2.5 w-1/2 rounded-full" />
          <div className="skeleton mt-1 h-2 w-2/3 rounded-full" />
          <div className="skeleton h-2 w-1/3 rounded-full" />
        </div>
      </div>
      <div className="mt-3.5 flex gap-1.5">
        {stages.map((s, i) => (
          <div key={s} className="flex-1">
            <div className={`h-[3px] rounded-full transition-all ${i <= stage ? "accent-gradient" : "bg-white/10"}`} />
            <div className="mt-1.5 truncate text-[9.2px] faint">{s}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function InfoCard({
  lang,
  source,
  onOpen,
  onPreview,
  onToast,
}: {
  lang: Lang;
  source: AnalyzedSource;
  onOpen: (t: ContentType) => void;
  onPreview: () => void;
  onToast: (m: string, d?: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [filename, setFilename] = useState(source.filename);
  useEffect(() => setFilename(source.filename), [source.filename]);
  const types = (["video", "audio", "image", "file"] as ContentType[]).filter((t) => (source.counts[t] ?? 0) > 0);

  return (
    <div className="relative overflow-hidden rounded-[26px] border glass noise" style={{ borderColor: "var(--line)" }}>
      <div className="absolute inset-x-0 top-0 h-24 opacity-40" style={{ background: `radial-gradient(80% 100% at 70% 0%, ${source.tint}, transparent 72%)` }} />
      <div className="relative p-3.5">
        <div className="flex gap-3">
          <button onClick={onPreview} className="press group relative h-[104px] w-[98px] shrink-0 overflow-hidden rounded-[18px]">
            <img src={source.thumbnail} alt={source.title} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
            <span className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/5 to-black/15" />
            <span className="absolute inset-0 flex items-center justify-center">
              <span className="flex h-9 w-9 items-center justify-center rounded-full border border-white/30 bg-black/30 backdrop-blur-md">
                <Play size={14} color="white" fill="white" />
              </span>
            </span>
            <span className="absolute bottom-1.5 end-1.5 rounded-md bg-black/60 px-1.5 py-0.5 text-[9.7px] font-semibold text-white backdrop-blur-md">
              {source.duration}
            </span>
          </button>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <SiteLogo site={source.site} size={24} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1 text-[11px] font-semibold leading-tight" style={{ color: "var(--text-1)" }}>
                  {source.site}
                  <CircleCheck size={10} style={{ color: "var(--accent2)" }} />
                </div>
                <div className="truncate text-[9.7px] faint" dir="ltr">{source.domain}</div>
              </div>
              <Chip tone="success" className="shrink-0">
                <ShieldCheck size={9} /> {lang === "ar" ? "تحقق" : "Secure"}
              </Chip>
            </div>
            <h3 className="mt-2 line-clamp-2 text-[12.5px] font-semibold leading-[1.5]" style={{ color: "var(--text-1)" }}>
              {source.title}
            </h3>
            <div className="mt-1.5 flex flex-wrap items-center gap-1">
              <Chip tone="accent">{lang === "ar" ? "فيديو" : "Video"}</Chip>
              <span className="text-[9.7px] faint">{source.channel}</span>
              <span className="h-1 w-1 rounded-full bg-white/25" />
              <span className="text-[9.7px] faint">{source.date}</span>
            </div>
          </div>
        </div>

        <div className="mt-3 flex items-center gap-2 rounded-[14px] border px-2.5 py-2" style={{ background: "var(--glass)", borderColor: "var(--line)" }}>
          {editing ? (
            <>
              <Pencil size={12} className="shrink-0" style={{ color: "var(--accent2)" }} />
              <input
                autoFocus
                value={filename}
                onChange={(e) => setFilename(e.target.value)}
                onBlur={() => setEditing(false)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    setEditing(false);
                    onToast(lang === "ar" ? "تم تحديث اسم الملف" : "Filename updated", filename);
                  }
                }}
                className="min-w-0 flex-1 bg-transparent text-[10.7px] outline-none"
                style={{ color: "var(--text-1)" }}
                dir="ltr"
              />
            </>
          ) : (
            <>
              <Lock size={11} className="shrink-0 faint" />
              <span className="min-w-0 flex-1 truncate text-[10.2px] muted" dir="ltr">{filename}</span>
              <button onClick={() => setEditing(true)} className="press-sm rounded-full p-1" aria-label="edit">
                <Pencil size={10} style={{ color: "var(--accent2)" }} />
              </button>
            </>
          )}
        </div>

        <div className="mt-2.5 flex items-end justify-between gap-2">
          <button
            onClick={() => setEditing(true)}
            className="text-start"
            title={exactBytes(source.selectedSize.bytes)}
          >
            <div className="flex items-center gap-1.5">
              <span className="text-[13.5px] font-semibold tabular-nums" style={{ color: "var(--text-1)" }}>
                {formatBytes(source.selectedSize.bytes, source.selectedSize.approx)}
              </span>
              {source.selectedSize.approx ? (
                <Chip tone="warning">{lang === "ar" ? "≈ تقديري" : "≈ approx"}</Chip>
              ) : (
                <Chip tone="success">{lang === "ar" ? "حجم مؤكد" : "Exact"}</Chip>
              )}
            </div>
            <div className="mt-0.5 text-[9.2px] faint tabular-nums">{exactBytes(source.selectedSize.bytes)}</div>
          </button>
          <div className="flex gap-1">
            <button onClick={onPreview} className="press flex h-8 w-8 items-center justify-center rounded-[11px] border glass-soft" aria-label="preview">
              <Play size={13} />
            </button>
            <button onClick={() => onToast(lang === "ar" ? "تم نسخ الرابط المباشر" : "Direct link copied", source.domain)} className="press flex h-8 w-8 items-center justify-center rounded-[11px] border glass-soft" aria-label="copy">
              <Copy size={13} />
            </button>
            <button onClick={() => onToast(lang === "ar" ? "المزيد من الإجراءات" : "More actions", lang === "ar" ? "إعادة التحليل، المتصفح الداخلي، المشاركة" : "Re-analyze, browser, share")} className="press flex h-8 w-8 items-center justify-center rounded-[11px] border glass-soft" aria-label="more">
              <MoreHorizontal size={14} />
            </button>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-4 gap-1.5 stagger">
          {types.map((t) => {
            const Icon = typeIcons[t];
            const meta = contentTypeMeta[t];
            return (
              <button
                key={t}
                onClick={() => onOpen(t)}
                className="press group relative flex flex-col items-center gap-1.5 rounded-[18px] border py-2.5 transition-colors"
                style={{ background: `linear-gradient(160deg, ${meta.glow}, var(--glass))`, borderColor: "var(--line)", boxShadow: "inset 0 1px 0 rgba(255,255,255,.12)" }}
              >
                <span className="absolute end-1.5 top-1.5 flex h-[15px] min-w-[15px] items-center justify-center rounded-full border border-white/15 bg-black/25 px-1 text-[9.2px] font-bold text-white">
                  {source.counts[t]}
                </span>
                <span className="flex h-8 w-8 items-center justify-center rounded-[11px] border border-white/10 bg-black/20">
                  <Icon size={15} color={meta.color} strokeWidth={2.1} />
                </span>
                <span className="text-[10.7px] font-semibold" style={{ color: "var(--text-1)" }}>
                  {lang === "ar" ? meta.ar : meta.en}
                </span>
              </button>
            );
          })}
        </div>

        <div className="mt-2.5 flex items-center justify-between rounded-[13px] border px-2.5 py-1.5" style={{ background: "rgba(255,255,255,.03)", borderColor: "var(--line)" }}>
          <span className="flex items-center gap-1.5 text-[9.7px] muted">
            <Merge size={11} style={{ color: "var(--accent3)" }} />
            {lang === "ar" ? "دمج تلقائي: فيديو + أفضل صوت (FFmpeg · -c copy)" : "Auto-merge video + best audio (FFmpeg · -c copy)"}
          </span>
          <span className="text-[9.7px] font-semibold" style={{ color: "var(--accent2)" }}>{lang === "ar" ? "مشمول" : "Included"}</span>
        </div>
      </div>
    </div>
  );
}

export function Home(props: HomeProps) {
  const { lang, analyzed, status, stage, url, setUrl, onAnalyze, onReset, onOpenSheet, onPreview, onNavigate, onTools, onToast, downloads } = props;
  const [clipboard, setClipboard] = useState(true);
  const active = downloads.filter((d) => d.status === "downloading");
  const recent = downloads.filter((d) => d.status !== "queued").slice(0, 2);
  const stageText =
    status === "analyzing"
      ? lang === "ar"
        ? ["تهيئة المحرك…", "فتح اتصال آمن…", "استخراج الجودات…", "إضافة الترجمات…"][Math.min(stage, 3)]
        : ["Warming engine…", "Opening secure connection…", "Extracting qualities…", "Fetching subtitles…"][Math.min(stage, 3)]
      : lang === "ar"
        ? "يدعم YouTube وTikTok و1800+ موقع"
        : "YouTube, TikTok & 1800+ sites";

  const insert = () => {
    setClipboard(false);
    onAnalyze(sources[0], urlFor.youtube);
  };

  const detect = (raw: string) => {
    const low = raw.toLowerCase();
    if (low.includes("tiktok")) return sources[1];
    if (low.includes("instagram")) return sources[2];
    if (low.includes("youtube") || low.includes("youtu.be")) return sources[0];
    return sources[3];
  };

  const submit = () => {
    if (!url.trim()) {
      setClipboard(true);
      return;
    }
    onAnalyze(detect(url), url);
  };

  return (
    <div className="px-3.5 pb-2 pt-1">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BrandMark size={34} />
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-[Outfit] text-[16.5px] font-semibold leading-none tracking-tight" style={{ color: "var(--text-1)" }}>
                Aurora <span style={{ color: "var(--accent2)" }}>Get</span>
              </span>
              <span className="rounded-full border border-white/15 bg-white/5 px-1.5 py-[1px] text-[8.2px] font-bold tracking-wider muted">PRO</span>
            </div>
            <div className="mt-0.5 text-[9.2px] faint">{lang === "ar" ? "مُحمِّل ذكي · بدون تتبع" : "Smart downloader · No tracking"}</div>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onToast(lang === "ar" ? "لا إشعارات جديدة" : "No new notifications", lang === "ar" ? "كل تحميلاتك تحت السيطرة" : "Your downloads are under control")}
            className="press relative flex h-[32px] w-[32px] items-center justify-center rounded-full border glass-soft"
            aria-label="notifications"
          >
            <Bell size={14} />
            <span className="absolute end-1.5 top-1.5 h-[5px] w-[5px] rounded-full bg-[var(--accent3)]" />
          </button>
          <button
            onClick={() => onNavigate("settings")}
            className="press relative flex h-[32px] w-[32px] items-center justify-center overflow-hidden rounded-full text-[10.5px] font-bold text-white"
            style={{ background: "linear-gradient(140deg,var(--accent1),var(--accent3))", boxShadow: "0 6px 16px -6px var(--accent2)" }}
            aria-label="profile"
          >
            AG
          </button>
        </div>
      </div>

      {/* Greeting */}
      <div className="mt-4">
        <div className="flex items-center gap-1.5 text-[10.5px] font-medium" style={{ color: "var(--text-2)" }}>
          <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-[var(--success)]" />
          {lang === "ar" ? "مساء النور، أحمد" : "Good evening, Ahmed"}
          <Sparkles size={11} style={{ color: "var(--accent3)" }} />
        </div>
        <h1 className="mt-1 text-[24px] font-bold leading-[1.3] tracking-tight">
          <span className="text-gradient">{lang === "ar" ? "ماذا نُحمّل اليوم؟" : "What are we getting today?"}</span>
        </h1>
        <p className="mt-0.5 text-[10.5px] leading-5 muted">
          {lang === "ar" ? "فيديو، صوت، صور وملفات — بجودة أصلية وسرعة فائقة." : "Video, audio, photos & files — original quality, blazing speed."}
        </p>
      </div>

      {clipboard && status !== "analyzing" && <div className="mt-3"><ClipboardChip lang={lang} onInsert={insert} onClose={() => setClipboard(false)} /></div>}

      {/* Paste field */}
      <div className="relative mt-3">
        <div className={`glow-shell ${status === "analyzing" ? "" : "calm"}`}>
          <div className="glass-halo" />
          <div className="glow-halo" />
          <div className="relative rounded-[27px] p-3" style={{ background: "linear-gradient(155deg, rgba(15,19,32,.92), rgba(10,13,24,.94))" }}>
            <div className="mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[10.2px] font-semibold tracking-wide" style={{ color: "var(--text-2)" }}>
                <Link2 size={11} style={{ color: "var(--accent2)" }} />
                {lang === "ar" ? "رابط جديد" : "NEW LINK"}
              </span>
              <Chip tone="success">
                <ShieldCheck size={9} /> {lang === "ar" ? "خصوصية كاملة · محلي" : "Private · on-device"}
              </Chip>
            </div>
            <div className="flex items-center gap-2 rounded-[16px] border px-2.5 py-2" style={{ background: "rgba(255,255,255,.055)", borderColor: "rgba(255,255,255,.11)" }}>
              <Search size={14} className="shrink-0 faint" />
              <input
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && submit()}
                placeholder={lang === "ar" ? "الصق رابط الفيديو أو الملف هنا…" : "Paste a video or file link…"}
                dir="ltr"
                className="min-w-0 flex-1 bg-transparent text-[11px] outline-none placeholder:text-[var(--text-3)]"
                style={{ color: "var(--text-1)" }}
              />
              {url ? (
                <button onClick={onReset} className="press-sm flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-white/10" aria-label="clear">
                  <X size={10} />
                </button>
              ) : (
                <span className="flex items-center gap-0.5 text-[9.2px] faint">
                  <span className="rounded border border-white/10 px-1 py-0.5">URL</span>
                </span>
              )}
            </div>
            <div className="mt-2 flex items-center gap-1.5">
              <button onClick={submit} className="press btn-primary flex h-[34px] flex-1 items-center justify-center gap-1.5 rounded-[13px] text-[10.5px] font-bold">
                {status === "analyzing" ? <ScanLine size={13} className="spin-slow" /> : <Zap size={13} fill="white" />}
                {status === "analyzing" ? (lang === "ar" ? "جاري التحليل…" : "Analyzing…") : lang === "ar" ? "تحليل الرابط" : "Analyze link"}
              </button>
              <button onClick={insert} className="press flex h-[34px] w-[34px] items-center justify-center rounded-[13px] border glass-soft" aria-label="clipboard">
                <Clipboard size={13} style={{ color: "var(--text-2)" }} />
              </button>
              <button
                onClick={() => onToast(lang === "ar" ? "ماسح QR" : "QR Scanner", lang === "ar" ? "وجّه الكاميرا نحو الرمز — على الجهاز فقط" : "Point your camera at the code — on-device only")}
                className="press flex h-[34px] w-[34px] items-center justify-center rounded-[13px] border glass-soft"
                aria-label="qr"
              >
                <QrCode size={13} style={{ color: "var(--text-2)" }} />
              </button>
              <button onClick={() => onNavigate("browser")} className="press flex h-[34px] w-[34px] items-center justify-center rounded-[13px] border glass-soft" aria-label="browser">
                <Globe size={13} style={{ color: "var(--text-2)" }} />
              </button>
            </div>
            <div className="mt-1.5 flex items-center justify-between gap-2 px-0.5">
              <span className="truncate text-[9.2px] faint">{stageText}</span>
              <span className="flex shrink-0 items-center gap-1 text-[9.2px]" style={{ color: status === "analyzing" ? "var(--accent2)" : "var(--text-3)" }}>
                <span className={`h-1 w-1 rounded-full ${status === "analyzing" ? "pulse-dot accent-gradient" : "bg-[var(--success)]"}`} />
                {status === "analyzing" ? "IO · Parallel" : "Ready"}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* examples */}
      <div className="mt-2.5 flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
        <span className="shrink-0 text-[9.7px] faint">{lang === "ar" ? "جرّب:" : "Try:"}</span>
        {sources.map((s) => (
          <button
            key={s.id}
            onClick={() => onAnalyze(s, urlFor[s.id])}
            className="press flex shrink-0 items-center gap-1 rounded-full border px-2 py-1 text-[9.7px] font-medium glass-soft"
            style={{ color: "var(--text-2)", borderColor: "var(--line)" }}
          >
            <SiteLogo site={s.site} size={13} />
            {s.site}
          </button>
        ))}
      </div>

      {/* Result */}
      <div className="mt-2.5">
        {status === "analyzing" && <AnalyzingSkeleton lang={lang} stage={stage} />}
        {status === "done" && analyzed && (
          <InfoCard lang={lang} source={analyzed} onOpen={onOpenSheet} onPreview={onPreview} onToast={onToast} />
        )}
        {status === "idle" && (
          <div className="relative overflow-hidden rounded-[26px] glass p-5 text-center noise">
            <div className="orb mx-auto h-20 w-20 opacity-90" />
            <h3 className="mt-4 text-[13.5px] font-semibold">{lang === "ar" ? "جاهزون لاصطياد ما تريد" : "Ready to catch your media"}</h3>
            <p className="mx-auto mt-1 max-w-[230px] text-[10.7px] leading-5 muted">
              {lang === "ar" ? "ألصق رابطًا أو استخدم المتصفح الداخلي لاصطياد أي ملف، ثم اختر الجودة بدقة." : "Paste a link or use the in-app browser to sniff any file, then pick your exact quality."}
            </p>
            <button onClick={() => onAnalyze(sources[0], urlFor.youtube)} className="press btn-primary mx-auto mt-3 flex items-center gap-1.5 rounded-full px-4 py-2 text-[10.5px] font-semibold">
              <Sparkles size={12} /> {lang === "ar" ? "تحليل مثال" : "Try a demo"}
            </button>
          </div>
        )}
      </div>

      {/* Quick tools */}
      <div className="mt-4">
        <SectionTitle title={lang === "ar" ? "أدوات سريعة" : "Quick tools"} />
        <div className="grid grid-cols-4 gap-1.5">
          {[
            { icon: Globe, label: lang === "ar" ? "المتصفح" : "Browser", color: "var(--accent1)", action: () => onNavigate("browser") },
            { icon: SlidersHorizontal, label: lang === "ar" ? "المحوّل" : "Converter", color: "var(--accent2)", action: () => onTools("convert") },
            { icon: Zap, label: lang === "ar" ? "الضاغط" : "Compressor", color: "var(--accent3)", action: () => onTools("compress") },
            { icon: Files, label: lang === "ar" ? "المكتبة" : "Library", color: "var(--success)", action: () => onNavigate("files") },
          ].map(({ icon: Icon, label, color, action }) => (
            <button key={label} onClick={action} className="press flex flex-col items-center gap-1.5 rounded-[17px] border py-2.5 glass-soft">
              <span className="flex h-7 w-7 items-center justify-center rounded-[10px]" style={{ background: `color-mix(in srgb, ${color} 16%, transparent)` }}>
                <Icon size={13} style={{ color }} />
              </span>
              <span className="text-[9.7px] font-medium" style={{ color: "var(--text-2)" }}>{label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Recent */}
      <div className="mt-4">
        <SectionTitle
          title={lang === "ar" ? "آخر التحميلات" : "Recent downloads"}
          action={lang === "ar" ? "الكل" : "All"}
          onAction={() => onNavigate("downloads")}
          icon={<Clock3 size={12} style={{ color: "var(--text-2)" }} />}
        />
        <div className="space-y-1.5">
          {recent.map((d) => {
            const pct = (d.downloaded / d.bytes) * 100;
            return (
              <button key={d.id} onClick={() => onNavigate("downloads")} className="press flex w-full items-center gap-2.5 rounded-[18px] border p-2 text-start glass-soft">
                <div className="relative h-9 w-9 shrink-0 overflow-hidden rounded-[11px]">
                  {d.thumbnail ? <img src={d.thumbnail} alt="" className="h-full w-full object-cover" /> : <span className="flex h-full w-full items-center justify-center accent-soft"><TypeIcon type={d.type} size={14} /></span>}
                  <span className="absolute inset-0 bg-black/25" />
                  <span className="absolute inset-0 flex items-center justify-center text-[10.2px] font-bold text-white">{Math.round(pct)}%</span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[10.7px] font-semibold" style={{ color: "var(--text-1)" }} dir="ltr">{d.name}</div>
                  <div className="mt-0.5 flex items-center justify-between text-[9.2px] faint">
                    <span>{d.status === "done" ? (lang === "ar" ? "مكتمل" : "Completed") : `${d.speed.toFixed(1)} MB/s · ${d.connections} ${lang === "ar" ? "اتصال" : "conn"}`}</span>
                    <span className="tabular-nums">{formatBytes(d.downloaded)} / {formatBytes(d.bytes)}</span>
                  </div>
                  <div className="mt-1"><Progress value={pct} slim /></div>
                </div>
              </button>
            );
          })}
        </div>
        {active.length > 0 && (
          <div className="mt-2 flex items-center justify-between rounded-[14px] border px-2.5 py-1.5 glass-soft">
            <span className="flex items-center gap-1.5 text-[9.7px] muted">
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--success)] pulse-dot" />
              {active.length} {lang === "ar" ? "تحميلات نشطة" : "active downloads"}
            </span>
            <span className="flex items-center gap-1 text-[9.7px] font-semibold" style={{ color: "var(--accent2)" }}>
              {active.reduce((a, b) => a + b.speed, 0).toFixed(1)} MB/s
              <Zap size={10} />
            </span>
          </div>
        )}
      </div>

      <div className="mt-4 flex items-center justify-center gap-1 pb-1 text-center text-[8.7px] faint">
        <ShieldCheck size={9} />
        {lang === "ar" ? "المسؤولية على المستخدم في احترام حقوق النشر · بدون DRM" : "Respect copyright · No DRM bypass"}
      </div>
    </div>
  );
}
