import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeftRight,
  CheckCircle2,
  CircleDashed,
  Cpu,
  FileVideo,
  FileAudio,
  HardDrive,
  Images,
  Pause,
  Plus,
  ShieldCheck,
  Sparkles,
  Zap,
  Info,
  Leaf,
  Music2,
} from "lucide-react";
import type { Lang, Screen } from "../data";
import { compressionFiles, exactBytes, formatBytes, images } from "../data";
import { Chip, Progress, SectionTitle, Toggle } from "../components/ui";

export type ToolsProps = {
  lang: Lang;
  tab: "convert" | "compress";
  setTab: (t: "convert" | "compress") => void;
  onToast: (m: string, d?: string) => void;
  onNavigate: (s: Screen) => void;
};

const outputFormats = [
  { id: "mp4", label: "MP4", kind: "video", color: "#7ea6ff" },
  { id: "mkv", label: "MKV", kind: "video", color: "#7ea6ff" },
  { id: "webm", label: "WEBM", kind: "video", color: "#7ea6ff" },
  { id: "mp3", label: "MP3", kind: "audio", color: "#c79bff" },
  { id: "m4a", label: "M4A", kind: "audio", color: "#c79bff" },
  { id: "opus", label: "OPUS", kind: "audio", color: "#c79bff" },
  { id: "flac", label: "FLAC", kind: "audio", color: "#c79bff" },
  { id: "gif", label: "GIF", kind: "image", color: "#ff9d9d" },
];

function Comparison({ value, setValue, lang }: { value: number; setValue: (n: number) => void; lang: Lang }) {
  return (
    <div className="relative overflow-hidden rounded-[20px] border" style={{ borderColor: "var(--line)" }}>
      <div className="relative h-[154px] w-full select-none">
        <img src={images.auroraAlt} alt="after compression" className="absolute inset-0 h-full w-full object-cover" style={{ filter: "saturate(1.02) contrast(1.02)" }} />
        <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - value}% 0 0)` }}>
          <img src={images.auroraAlt} alt="before compression" className="h-full w-full object-cover" style={{ filter: "saturate(.72) brightness(.82) contrast(.92)" }} />
          <div className="absolute inset-0 bg-black/10" />
        </div>
        <span className="absolute start-2 top-2 rounded-full border border-white/15 bg-black/50 px-2 py-0.5 text-[8.7px] font-semibold text-white backdrop-blur-md">{lang === "ar" ? "قبل" : "Before"} · {formatBytes(4812990)}</span>
        <span className="absolute end-2 top-2 rounded-full border border-white/15 bg-black/50 px-2 py-0.5 text-[8.7px] font-semibold text-white backdrop-blur-md">{lang === "ar" ? "بعد" : "After"} · {formatBytes(1248110)}</span>
        <div className="absolute inset-y-0 w-[2px] bg-white/90 shadow-[0_0_14px_rgba(255,255,255,.8)]" style={{ insetInlineStart: `${value}%` }}>
          <span className="absolute left-1/2 top-1/2 flex h-7 w-7 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-white/60 bg-white/20 text-white backdrop-blur-md">
            <ArrowLeftRight size={12} />
          </span>
        </div>
        <span className="absolute bottom-2 start-1/2 -translate-x-1/2 rounded-full border border-white/10 bg-black/45 px-2 py-0.5 text-[8.2px] text-white/70 backdrop-blur-md">
          {lang === "ar" ? "اسحب للمقارنة" : "Drag to compare"}
        </span>
      </div>
      <input
        aria-label="comparison"
        type="range"
        min={0}
        max={100}
        value={value}
        onChange={(e) => setValue(Number(e.target.value))}
        className="absolute inset-x-3 bottom-2 h-4 w-[calc(100%-24px)] cursor-ew-resize opacity-0"
      />
    </div>
  );
}

export function Tools({ lang, tab, setTab, onToast, onNavigate }: ToolsProps) {
  const [outputs, setOutputs] = useState<string[]>(["mp4", "mp3"]);
  const [resolution, setResolution] = useState("original");
  const [streamCopy, setStreamCopy] = useState(true);
  const [subtitles, setSubtitles] = useState(true);
  const [crf, setCrf] = useState(23);
  const [convState, setConvState] = useState<"idle" | "processing" | "done">("idle");
  const [convProg, setConvProg] = useState(0);
  const [mode, setMode] = useState<"lossless" | "transparent">("transparent");
  const [compare, setCompare] = useState(58);
  const [compState, setCompState] = useState<"idle" | "processing" | "done">("done");
  const [compProg, setCompProg] = useState(100);
  const convTimer = useRef<number | null>(null);
  const compTimer = useRef<number | null>(null);

  useEffect(() => () => {
    if (convTimer.current) window.clearInterval(convTimer.current);
    if (compTimer.current) window.clearInterval(compTimer.current);
  }, []);

  const startConvert = () => {
    if (convState === "processing") return;
    setConvState("processing");
    setConvProg(4);
    onToast(lang === "ar" ? "بدأ التحويل في الخلفية" : "Conversion started", lang === "ar" ? "WorkManager · إشعار عند الاكتمال" : "WorkManager · notification on finish");
    convTimer.current = window.setInterval(() => {
      setConvProg((p) => {
        const next = p + 9 + Math.random() * 7;
        if (next >= 100) {
          if (convTimer.current) window.clearInterval(convTimer.current);
          setConvState("done");
          return 100;
        }
        return next;
      });
    }, 380);
  };

  const startCompress = () => {
    setCompState("processing");
    setCompProg(3);
    compTimer.current = window.setInterval(() => {
      setCompProg((p) => {
        const next = p + 8 + Math.random() * 9;
        if (next >= 100) {
          if (compTimer.current) window.clearInterval(compTimer.current);
          setCompState("done");
          onToast(lang === "ar" ? "اكتمل الضغط بجودة شفافة" : "Compression complete", lang === "ar" ? "تم حفظ نسخة جديدة — الأصل لم يُلمس" : "New copy saved — original untouched");
          return 100;
        }
        return next;
      });
    }, 420);
  };

  const selectedOutputs = useMemo(() => outputFormats.filter((o) => outputs.includes(o.id)), [outputs]);
  const selectedCompression = compressionFiles[0];
  const savingPct = Math.round(((4812990 - 1248110) / 4812990) * 100);

  return (
    <div className="px-3.5 pt-1">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-[10.2px] font-medium" style={{ color: "var(--accent2)" }}>
            <Sparkles size={10} /> {lang === "ar" ? "استوديو الوسائط · على الجهاز" : "Media studio · on-device"}
          </div>
          <h1 className="mt-0.5 text-[23px] font-bold leading-tight">{lang === "ar" ? "حوّل. اضغط. وفّر." : "Convert. Compress. Save."}</h1>
          <p className="mt-0.5 text-[10.2px] muted">{lang === "ar" ? "من دون فقد، ومن دون رفع أي ملف للسحابة." : "Lossless, local-only, no cloud uploads."}</p>
        </div>
        <Chip tone="success"><Cpu size={9} /> {lang === "ar" ? "تسريع عتادي" : "HW accel"}</Chip>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-1 rounded-[16px] border p-1 glass-soft">
        {[
          { id: "convert" as const, icon: ArrowLeftRight, ar: "المحوّل", en: "Converter" },
          { id: "compress" as const, icon: Zap, ar: "الضاغط الذكي", en: "Smart compressor" },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className="press flex items-center justify-center gap-1.5 rounded-[12px] py-2 text-[10.7px] font-semibold transition-all"
            style={{
              background: tab === t.id ? "linear-gradient(115deg,var(--accent1),var(--accent2))" : "transparent",
              color: tab === t.id ? "#fff" : "var(--text-2)",
              boxShadow: tab === t.id ? "0 6px 16px -8px var(--accent2)" : "none",
            }}
          >
            <t.icon size={12} /> {lang === "ar" ? t.ar : t.en}
          </button>
        ))}
      </div>

      {tab === "convert" ? (
        <div className="mt-3 space-y-2.5">
          <div className="rounded-[22px] border p-2.5 glass-soft">
            <div className="flex items-center gap-2.5">
              <div className="relative h-[52px] w-[62px] shrink-0 overflow-hidden rounded-[13px]">
                <img src={images.aurora} alt="" className="h-full w-full object-cover" />
                <span className="absolute inset-0 bg-black/25" />
                <span className="absolute bottom-1 start-1 rounded bg-black/55 px-1 text-[7.7px] text-white">MP4</span>
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-[10.5px] font-semibold" dir="ltr">aurora-northern-lights-8k.mp4</div>
                <div className="mt-0.5 flex items-center gap-1.5 text-[9.2px] faint">
                  <span>{formatBytes(892160400)}</span><span className="h-1 w-1 rounded-full bg-white/25" /><span>12:48</span><span className="h-1 w-1 rounded-full bg-white/25" /><span>2160p · VP9</span>
                </div>
                <div className="mt-1 flex items-center gap-1">
                  <Chip tone="success"><ShieldCheck size={8} /> {lang === "ar" ? "ملف محلي" : "Local file"}</Chip>
                  <Chip tone="neutral">HDR</Chip>
                  <Chip tone="neutral">60fps</Chip>
                </div>
              </div>
              <button onClick={() => onToast(lang === "ar" ? "اختيار ملف آخر" : "Choose another file", lang === "ar" ? "من المكتبة أو مدير الملفات" : "From library or file manager")} className="press flex h-7 w-7 shrink-0 items-center justify-center rounded-[9px] border glass-soft">
                <Plus size={12} />
              </button>
            </div>
          </div>

          <div>
            <SectionTitle title={lang === "ar" ? "الصيغ المطلوبة" : "Target formats"} action={lang === "ar" ? "استخراج متعدد" : "Batch"} onAction={() => onToast(lang === "ar" ? "وضع الدفعة" : "Batch mode", lang === "ar" ? "حوّل عدة صيغ في عملية واحدة" : "Convert multiple formats in one job")} />
            <div className="grid grid-cols-4 gap-1.5">
              {outputFormats.map((f) => {
                const on = outputs.includes(f.id);
                return (
                  <button
                    key={f.id}
                    onClick={() => setOutputs((prev) => (prev.includes(f.id) ? prev.filter((x) => x !== f.id) : [...prev, f.id]))}
                    className="press flex items-center justify-center gap-1 rounded-[11px] border py-2 text-[10.2px] font-semibold"
                    style={{
                      background: on ? `color-mix(in srgb, ${f.color} 16%, transparent)` : "var(--glass)",
                      borderColor: on ? `color-mix(in srgb, ${f.color} 45%, transparent)` : "var(--line)",
                      color: on ? f.color : "var(--text-2)",
                    }}
                  >
                    {on && <CheckCircle2 size={9} />} {f.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="rounded-[18px] border p-2.5 glass-soft">
            <div className="flex items-center justify-between">
              <span className="text-[10.2px] font-semibold">{lang === "ar" ? "الدقة" : "Resolution"}</span>
              <span className="text-[9.2px] faint">{lang === "ar" ? "حافظ على الأصل إن أمكن" : "Keep source when possible"}</span>
            </div>
            <div className="mt-1.5 grid grid-cols-4 gap-1">
              {[
                { id: "original", label: lang === "ar" ? "الأصل" : "Source" },
                { id: "1080", label: "1080p" },
                { id: "720", label: "720p" },
                { id: "480", label: "480p" },
              ].map((r) => (
                <button key={r.id} onClick={() => setResolution(r.id)} className="press rounded-[9px] border py-1.5 text-[9.2px] font-medium" style={{ borderColor: resolution === r.id ? "color-mix(in srgb, var(--accent2) 55%, transparent)" : "var(--line)", background: resolution === r.id ? "var(--accent-soft)" : "transparent", color: resolution === r.id ? "var(--text-1)" : "var(--text-2)" }}>{r.label}</button>
              ))}
            </div>
            <div className="mt-2 flex items-center gap-2">
              <div className="flex-1">
                <div className="mb-1 flex justify-between text-[9.2px] faint"><span>{lang === "ar" ? "جودة الترميز CRF" : "Encoding quality CRF"}</span><span className="tabular-nums" style={{ color: "var(--accent2)" }}>{crf}</span></div>
                <input type="range" className="range-aurora w-full" min={16} max={32} value={crf} onChange={(e) => setCrf(Number(e.target.value))} />
              </div>
            </div>
            <div className="mt-1.5 border-t pt-2" style={{ borderColor: "var(--line)" }}>
              {[
                { label: lang === "ar" ? "Stream Copy · بدون إعادة ترميز" : "Stream copy · no re-encode", on: streamCopy, set: setStreamCopy },
                { label: lang === "ar" ? "تضمين الترجمة العربية" : "Embed Arabic subtitles", on: subtitles, set: setSubtitles },
              ].map((row) => (
                <div key={row.label} className="flex items-center justify-between py-1">
                  <span className="text-[9.7px] muted">{row.label}</span>
                  <Toggle on={row.on} onChange={row.set} label={row.label} />
                </div>
              ))}
            </div>
          </div>

          {convState === "processing" && (
            <div className="rounded-[18px] border p-2.5 glass" style={{ borderColor: "color-mix(in srgb, var(--accent2) 30%, transparent)" }}>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-[10.2px] font-semibold"><Cpu size={12} className="spin-slow" style={{ color: "var(--accent2)" }} /> {lang === "ar" ? "FFmpeg يعمل…" : "FFmpeg running…"}</span>
                <span className="text-[10.2px] font-bold tabular-nums accent-gradient bg-clip-text text-transparent">{Math.round(convProg)}%</span>
              </div>
              <div className="mt-1.5"><Progress value={convProg} /></div>
              <div className="mt-1 text-[8.7px] faint">{lang === "ar" ? "libx265 · 8-bit · Hardware Where possible" : "libx265 · 8-bit · Hardware where possible"}</div>
            </div>
          )}

          {convState === "done" && (
            <div className="rounded-[20px] border p-2.5" style={{ borderColor: "rgba(94,225,176,.25)", background: "rgba(94,225,176,.05)" }}>
              <div className="flex items-center gap-1.5 text-[10.7px] font-semibold" style={{ color: "var(--success)" }}><CheckCircle2 size={13} /> {lang === "ar" ? "تم التحويل بنجاح" : "Conversion complete"}</div>
              <div className="mt-2 space-y-1.5">
                {selectedOutputs.slice(0, 3).map((f, i) => (
                  <div key={f.id} className="flex items-center gap-2 rounded-[11px] border px-2 py-1.5" style={{ borderColor: "var(--line)", background: "var(--glass)" }}>
                    <span className="flex h-6 w-6 items-center justify-center rounded-md" style={{ background: `color-mix(in srgb, ${f.color} 15%, transparent)` }}>
                      {f.kind === "video" ? <FileVideo size={11} style={{ color: f.color }} /> : f.kind === "audio" ? <FileAudio size={11} style={{ color: f.color }} /> : <Images size={11} style={{ color: f.color }} />}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-[9.7px]" dir="ltr">aurora-converted.{f.id}</span>
                    <span className="text-[8.7px] tabular-nums faint">{formatBytes([892160400, 30118440, 84910332][i] ?? 12000000)}</span>
                    <button onClick={() => onNavigate("files")} className="press-sm rounded-md px-1.5 py-0.5 text-[8.7px] font-bold accent-soft" style={{ color: "var(--accent2)" }}>{lang === "ar" ? "فتح" : "Open"}</button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <button onClick={startConvert} className="press btn-primary flex w-full items-center justify-center gap-1.5 rounded-[15px] py-3 text-[11px] font-bold">
            {convState === "processing" ? <Pause size={13} /> : <ArrowLeftRight size={13} />}
            {convState === "processing" ? (lang === "ar" ? "إيقاف مؤقت · ستُحفظ الحالة" : "Pause · state saved") : lang === "ar" ? `بدء التحويل (${selectedOutputs.length})` : `Start conversion (${selectedOutputs.length})`}
          </button>
          <p className="text-center text-[8.7px] leading-4 faint">{lang === "ar" ? "الأصل لا يُستبدل أبدًا. الناتج يُحفظ في مجلد Aurora / Converted." : "Originals are never replaced. Output goes to Aurora / Converted."}</p>
        </div>
      ) : (
        <div className="mt-3 space-y-2.5">
          <div className="grid grid-cols-2 gap-1.5">
            {[
              { id: "lossless" as const, ar: "بدون أي فقد", en: "Lossless", desc: lang === "ar" ? "نفس البكسلات والعينات" : "Bit-exact, same pixels", color: "var(--success)", icon: Leaf },
              { id: "transparent" as const, ar: "شفاف بصريًا", en: "Transparent", desc: lang === "ar" ? "فقد غير ملحوظ + VMAF" : "Invisible loss + VMAF", color: "var(--warning)", icon: Sparkles },
            ].map((m) => (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                className="press relative overflow-hidden rounded-[18px] border p-2.5 text-start"
                style={{ background: mode === m.id ? `color-mix(in srgb, ${m.color} 11%, var(--glass))` : "var(--glass)", borderColor: mode === m.id ? `color-mix(in srgb, ${m.color} 45%, transparent)` : "var(--line)" }}
              >
                <div className="flex items-center justify-between">
                  <span className="flex h-7 w-7 items-center justify-center rounded-[9px]" style={{ background: `color-mix(in srgb, ${m.color} 16%, transparent)` }}><m.icon size={13} style={{ color: m.color }} /></span>
                  {mode === m.id ? <CheckCircle2 size={13} style={{ color: m.color }} /> : <CircleDashed size={12} className="faint" />}
                </div>
                <div className="mt-1.5 text-[10.7px] font-bold">{lang === "ar" ? m.ar : m.en}</div>
                <div className="text-[8.7px] leading-4 muted">{m.desc}</div>
              </button>
            ))}
          </div>

          <div className="rounded-[22px] border p-2.5 glass-soft">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[10.2px] font-semibold">{lang === "ar" ? "معاينة قبل / بعد" : "Before / After"}</span>
              <Chip tone="success">{lang === "ar" ? `توفير ${savingPct}%` : `${savingPct}% smaller`}</Chip>
            </div>
            <Comparison value={compare} setValue={setCompare} lang={lang} />
            <div className="mt-2 flex items-center justify-between rounded-[12px] border px-2.5 py-1.5" style={{ borderColor: "var(--line)" }}>
              <div><div className="text-[8.2px] faint">{lang === "ar" ? "قبل" : "Before"}</div><div className="text-[10.7px] font-semibold tabular-nums">4,812,990 B</div></div>
              <div className="flex flex-col items-center">
                <span className="flex h-6 w-6 items-center justify-center rounded-full accent-soft"><Zap size={11} style={{ color: "var(--accent2)" }} /></span>
                <span className="text-[8.2px]" style={{ color: "var(--success)" }}>-{savingPct}%</span>
              </div>
              <div className="text-end"><div className="text-[8.2px] faint">{lang === "ar" ? "بعد" : "After"}</div><div className="text-[10.7px] font-semibold tabular-nums">1,248,110 B</div></div>
            </div>
            <div className="mt-1.5 flex items-center justify-between text-[8.7px] faint">
              <span className="flex items-center gap-1"><ShieldCheck size={9} /> {lang === "ar" ? "تم التحقق بالبكسل · ΔE = 0" : "Pixel verified · ΔE = 0"}</span>
              <span>{mode === "lossless" ? "oxipng · PNG" : "mozjpeg · near-lossless"}</span>
            </div>
          </div>

          <div className="rounded-[18px] border p-2.5 glass-soft">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 overflow-hidden rounded-[9px]"><img src={selectedCompression.thumb} alt="" className="h-full w-full object-cover" /></div>
                <div>
                  <div className="text-[9.7px] font-semibold" dir="ltr">{selectedCompression.name}</div>
                  <div className="text-[8.2px] faint">PNG · 3840 × 2160 · {exactBytes(selectedCompression.before)}</div>
                </div>
              </div>
              <button onClick={() => onToast(lang === "ar" ? "تغيير الملف" : "Change file", lang === "ar" ? "صور، فيديو، صوت، أرشيف، PDF" : "Image, video, audio, archive, PDF")} className="press rounded-[9px] border px-2 py-1 text-[8.7px] font-medium glass-soft">{lang === "ar" ? "تغيير" : "Change"}</button>
            </div>
            {compState === "processing" && (
              <div className="mt-2">
                <div className="mb-1 flex justify-between text-[9.2px]"><span className="muted">{lang === "ar" ? "يعمل في الخلفية عبر WorkManager" : "Running via WorkManager"}</span><span className="font-semibold tabular-nums" style={{ color: "var(--accent2)" }}>{Math.round(compProg)}%</span></div>
                <Progress value={compProg} />
              </div>
            )}
            {compState === "done" && (
              <div className="mt-2 flex items-center justify-between rounded-[10px] px-2 py-1.5" style={{ background: "rgba(94,225,176,.07)" }}>
                <span className="flex items-center gap-1 text-[9.2px]" style={{ color: "var(--success)" }}><CheckCircle2 size={10} /> {lang === "ar" ? `وفّرت ${formatBytes(3564880)} · الناتج أصغر فعلًا` : `Saved ${formatBytes(3564880)} · truly smaller`}</span>
                <button onClick={() => onNavigate("files")} className="press-sm text-[8.7px] font-bold" style={{ color: "var(--accent2)" }}>{lang === "ar" ? "عرض الناتج" : "View output"}</button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-3 gap-1.5">
            {[
              { icon: Images, label: lang === "ar" ? "صور" : "Images", detail: "oxipng" },
              { icon: FileVideo, label: lang === "ar" ? "فيديو" : "Video", detail: "HEVC" },
              { icon: Music2, label: lang === "ar" ? "صوت" : "Audio", detail: "FLAC -8" },
            ].map((x) => (
              <div key={x.label} className="rounded-[13px] border p-2 text-center glass-soft">
                <x.icon size={12} className="mx-auto" style={{ color: "var(--text-2)" }} />
                <div className="mt-1 text-[9.2px] font-semibold">{x.label}</div>
                <div className="text-[7.7px] faint">{x.detail}</div>
              </div>
            ))}
          </div>

          <div className="flex items-start gap-1.5 rounded-[13px] border px-2.5 py-2 text-[8.7px] leading-4" style={{ borderColor: "rgba(255,210,132,.2)", background: "rgba(255,210,132,.05)", color: "var(--warning)" }}>
            <Info size={11} className="mt-0.5 shrink-0" />
            {lang === "ar" ? "إن لم يصغر الناتج فعليًا، يُبلغ الضاغط بذلك بصدق ولا يعرض ملفًا أكبر. الأصل لا يُستبدل إلا بتأكيدك." : "If output isn't smaller, we say so honestly and never present a larger file. Originals require confirmation."}
          </div>

          <button onClick={startCompress} className="press btn-primary flex w-full items-center justify-center gap-1.5 rounded-[15px] py-3 text-[11px] font-bold">
            {compState === "processing" ? <Zap size={13} className="spin-slow" /> : <Zap size={13} />}
            {compState === "processing" ? (lang === "ar" ? "جاري الضغط…" : "Compressing…") : lang === "ar" ? `ضغط الآن · وضع ${mode === "lossless" ? "بدون فقد" : "شفاف"}` : `Compress now · ${mode} mode`}
          </button>

          <div>
            <SectionTitle title={lang === "ar" ? "نتائج حديثة" : "Recent results"} />
            <div className="space-y-1.5">
              {compressionFiles.map((f) => {
                const saved = Math.round(((f.before - f.after) / f.before) * 100);
                return (
                  <div key={f.id} className="flex items-center gap-2 rounded-[14px] border p-1.5 glass-soft">
                    <div className="h-7 w-7 shrink-0 overflow-hidden rounded-[8px]"><img src={f.thumb} alt="" className="h-full w-full object-cover" /></div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[9.2px]" dir="ltr">{f.name}</div>
                      <div className="text-[8.2px] faint tabular-nums">{formatBytes(f.before)} → {formatBytes(f.after)}</div>
                    </div>
                    <span className="text-[9.2px] font-bold" style={{ color: "var(--success)" }}>-{saved}%</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      <div className="mt-3 flex items-center justify-center gap-1 pb-1 text-[8.7px] faint">
        <HardDrive size={9} /> {lang === "ar" ? "المعالجة كلها على جهازك — لا تُرفع الملفات" : "All processing is on-device — no uploads"}
      </div>
    </div>
  );
}
