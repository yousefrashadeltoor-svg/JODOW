import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  Captions,
  CheckCircle2,
  ChevronRight,
  Download,
  FileText,
  Fingerprint,
  FolderOpen,
  FolderSearch,
  Grid2x2,
  HardDrive,
  List,
  Lock,
  Maximize2,
  MoreHorizontal,
  Pause,
  PictureInPicture2,
  Play,
  Search,
  Share2,
  Shield,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Unlock,
  Volume2,
  Wand2,
  X,
  Zap,
  Layers3,
  Gauge,
} from "lucide-react";
import type { ContentType, Lang, Screen } from "../data";
import { contentTypeMeta, exactBytes, formatBytes, images, initialFiles } from "../data";
import { Chip, Ring, SectionTitle, Sheet, TypeIcon } from "../components/ui";

type FileItem = (typeof initialFiles)[number];

export type FilesProps = {
  lang: Lang;
  files: FileItem[];
  onNavigate: (s: Screen) => void;
  onToast: (m: string, d?: string) => void;
  onPlay: (f: FileItem) => void;
};

const filters: { id: "all" | ContentType | "vault"; ar: string; en: string }[] = [
  { id: "all", ar: "الكل", en: "All" },
  { id: "video", ar: "فيديو", en: "Video" },
  { id: "audio", ar: "صوت", en: "Audio" },
  { id: "image", ar: "صور", en: "Images" },
  { id: "file", ar: "ملفات", en: "Files" },
  { id: "vault", ar: "القبو", en: "Vault" },
];

export function Files({ lang, files, onNavigate, onToast, onPlay }: FilesProps) {
  const [filter, setFilter] = useState<(typeof filters)[number]["id"]>("all");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [query, setQuery] = useState("");
  const [vaultOpen, setVaultOpen] = useState(false);
  const [unlocked, setUnlocked] = useState(false);
  const [scan, setScan] = useState(false);
  const [menu, setMenu] = useState<FileItem | null>(null);

  useEffect(() => {
    if (!scan) return;
    const t = setTimeout(() => {
      setScan(false);
      setUnlocked(true);
      setVaultOpen(false);
      onToast(lang === "ar" ? "فتح القبو المشفر" : "Encrypted vault unlocked", lang === "ar" ? "AES-256 · بقيت بياناتك على جهازك" : "AES-256 · everything stayed on-device");
    }, 1000);
    return () => clearTimeout(t);
  }, [scan]);

  const visible = useMemo(
    () =>
      files.filter((f) => {
        if (filter === "vault") return f.vault;
        if (filter !== "all" && f.type !== filter) return false;
        if (!unlocked && f.vault) return false;
        return f.name.toLowerCase().includes(query.toLowerCase());
      }),
    [files, filter, query, unlocked]
  );

  const totalDownloaded = files.reduce((a, b) => a + b.size, 0);
  const used = 64.2;
  const total = 128;

  return (
    <div className="px-3.5 pt-1">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-[10.2px] font-medium" style={{ color: "var(--accent2)" }}>
            <FolderOpen size={10} /> {lang === "ar" ? "مكتبة محلية · Scoped Storage" : "Local library · Scoped Storage"}
          </div>
          <h1 className="mt-0.5 text-[23px] font-bold leading-tight">{lang === "ar" ? "مكتبة الملفات" : "File library"}</h1>
          <p className="mt-0.5 text-[10.2px] muted">{lang === "ar" ? "كل ما حمّلته، منظمًا وجاهزًا." : "Everything you've downloaded, organized."}</p>
        </div>
        <button onClick={() => onToast(lang === "ar" ? "مجلد Downloads" : "Downloads folder", lang === "ar" ? "فتح عبر مدير الملفات" : "Open in file manager")} className="press flex h-8 w-8 items-center justify-center rounded-[11px] border glass-soft"><FolderSearch size={14} /></button>
      </div>

      {/* storage */}
      <div className="relative mt-3 overflow-hidden rounded-[24px] border p-3 glass noise" style={{ borderColor: "var(--line)" }}>
        <div className="absolute -start-6 -top-8 h-24 w-24 rounded-full accent-gradient opacity-20 blur-2xl" />
        <div className="relative flex items-center gap-3">
          <div className="relative">
            <Ring value={(used / total) * 100} size={54} />
            <HardDrive size={12} className="absolute inset-0 m-auto opacity-0" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-baseline justify-between">
              <span className="text-[10.2px] faint">{lang === "ar" ? "المساحة المستخدمة" : "Storage used"}</span>
              <span className="text-[9.2px] faint tabular-nums">{used} / {total} GB</span>
            </div>
            <div className="mt-0.5 text-[13.5px] font-semibold">{lang === "ar" ? "63.8 GB متاحة" : "63.8 GB free"}</div>
            <div className="mt-1.5 flex gap-2 text-[8.2px] faint">
              <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-[#7ea6ff]" /> {lang === "ar" ? "فيديو" : "Video"} 41.2</span>
              <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-[#c79bff]" /> {lang === "ar" ? "صوت" : "Audio"} 9.4</span>
              <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-[#ff9d9d]" /> {lang === "ar" ? "صور" : "Images"} 6.8</span>
              <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-[#7ee3ca]" /> {lang === "ar" ? "ملفات" : "Files"} 6.8</span>
            </div>
          </div>
        </div>
        <div className="relative mt-2 flex gap-[2px]">
          {[41.2, 9.4, 6.8, 6.8].map((n, i) => (
            <span key={i} className="h-[5px] rounded-full" style={{ width: `${(n / total) * 100}%`, background: ["#7ea6ff", "#c79bff", "#ff9d9d", "#7ee3ca"][i] }} />
          ))}
          <span className="h-[5px] flex-1 rounded-full bg-white/8" />
        </div>
        <div className="relative mt-2 flex gap-1.5">
          <Chip tone="success"><ShieldCheck size={8} /> {lang === "ar" ? "منع التكرار" : "Duplicates off"}</Chip>
          <Chip tone="neutral"><Layers3 size={8} /> {lang === "ar" ? "تنظيم تلقائي" : "Auto folder"}</Chip>
          <Chip tone="accent"><Sparkles size={8} /> {lang === "ar" ? "Metadata مضمّنة" : "Metadata embedded"}</Chip>
        </div>
      </div>

      {/* vault */}
      <button
        onClick={() => setVaultOpen(true)}
        className="press relative mt-2 flex w-full items-center gap-2.5 overflow-hidden rounded-[20px] border p-2.5 text-start glass-soft"
        style={{ borderColor: unlocked ? "rgba(94,225,176,.25)" : "color-mix(in srgb, var(--accent2) 28%, transparent)" }}
      >
        <span className="absolute -end-6 -top-6 h-20 w-20 rounded-full opacity-20 blur-2xl accent-gradient" />
        <span className="flex h-9 w-9 items-center justify-center rounded-[12px]" style={{ background: unlocked ? "rgba(94,225,176,.14)" : "var(--accent-soft)" }}>
          {unlocked ? <Unlock size={16} style={{ color: "var(--success)" }} /> : <Lock size={15} style={{ color: "var(--accent2)" }} />}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1 text-[10.7px] font-semibold">{lang === "ar" ? "القبو الخاص" : "Private vault"} <ShieldCheck size={10} style={{ color: "var(--accent2)" }} /></div>
          <div className="text-[8.7px] faint">{unlocked ? (lang === "ar" ? "مفتوح · AES-256 مفعّل" : "Unlocked · AES-256 active") : lang === "ar" ? "مشفر بالبصمة · ملفان مخفيان" : "Biometric lock · 2 hidden files"}</div>
        </div>
        <span className="flex items-center gap-1 rounded-full border px-2 py-1 text-[8.7px] font-semibold glass-soft" style={{ color: "var(--accent2)" }}>
          <Fingerprint size={10} /> {unlocked ? (lang === "ar" ? "إدارة" : "Manage") : lang === "ar" ? "فتح" : "Unlock"}
        </span>
      </button>

      {/* search + view */}
      <div className="mt-2.5 flex items-center gap-1.5">
        <div className="flex flex-1 items-center gap-1.5 rounded-[12px] border px-2 py-1.5" style={{ background: "var(--field)", borderColor: "var(--line)" }}>
          <Search size={11} className="faint" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={lang === "ar" ? "ابحث في ملفاتك…" : "Search your files…"} className="min-w-0 flex-1 bg-transparent text-[9.7px] outline-none placeholder:text-[var(--text-3)]" style={{ color: "var(--text-1)" }} />
          {query && <button onClick={() => setQuery("")}><X size={10} className="faint" /></button>}
        </div>
        <button onClick={() => setView(view === "grid" ? "list" : "grid")} className="press flex h-7 w-7 items-center justify-center rounded-[10px] border glass-soft">
          {view === "grid" ? <List size={12} /> : <Grid2x2 size={12} />}
        </button>
        <button onClick={() => onToast(lang === "ar" ? "ترتيب الملفات" : "Sort files", lang === "ar" ? "التاريخ · الحجم · الاسم" : "Date · size · name")} className="press flex h-7 w-7 items-center justify-center rounded-[10px] border glass-soft"><SlidersHorizontal size={11} /></button>
      </div>

      <div className="mt-2 flex gap-1 overflow-x-auto no-scrollbar">
        {filters.map((f) => (
          <button key={f.id} onClick={() => setFilter(f.id)} className="press shrink-0 rounded-full border px-2.5 py-1 text-[9.2px] font-medium" style={{ borderColor: filter === f.id ? "color-mix(in srgb, var(--accent2) 55%, transparent)" : "var(--line)", background: filter === f.id ? "var(--accent-soft)" : "var(--glass)", color: filter === f.id ? "var(--text-1)" : "var(--text-2)" }}>
            {lang === "ar" ? f.ar : f.en}
          </button>
        ))}
        <span className="ms-auto flex shrink-0 items-center gap-1 rounded-full border px-2 py-1 text-[8.7px] faint glass-soft">
          <CheckCircle2 size={8} /> {visible.length} {lang === "ar" ? "ملفات" : "files"}
        </span>
      </div>

      <div className={`mt-2.5 ${view === "grid" ? "grid grid-cols-2 gap-2" : "space-y-1.5"}`}>
        {visible.map((f) => {
          const meta = contentTypeMeta[f.type];
          if (view === "grid") {
            return (
              <div key={f.id} className="press group relative overflow-hidden rounded-[18px] border glass-soft" style={{ borderColor: "var(--line)" }} onClick={() => (f.type === "video" || f.type === "audio") ? onPlay(f) : onToast(f.name, `${formatBytes(f.size)} · ${exactBytes(f.size)}`)}>
                <div className="relative h-[88px] overflow-hidden">
                  {f.thumb ? <img src={f.thumb} alt="" className="h-full w-full object-cover transition duration-500 group-hover:scale-105" /> : (
                    <div className="flex h-full items-center justify-center" style={{ background: `linear-gradient(150deg, ${meta.glow}, rgba(255,255,255,.03))` }}><FileText size={24} style={{ color: meta.color }} /></div>
                  )}
                  <span className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
                  <span className="absolute start-1.5 top-1.5 flex items-center gap-0.5 rounded-full border border-white/15 bg-black/40 px-1.5 py-0.5 text-[7.7px] text-white backdrop-blur-md">
                    <TypeIcon type={f.type} size={7} /> {lang === "ar" ? meta.ar : meta.en}
                  </span>
                  {(f.type === "video" || f.type === "audio") && (
                    <span className="absolute inset-0 flex items-center justify-center">
                      <span className="flex h-7 w-7 items-center justify-center rounded-full border border-white/30 bg-black/30 backdrop-blur-md"><Play size={10} color="white" fill="white" /></span>
                    </span>
                  )}
                  {f.vault && <span className="absolute end-1.5 top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-black/50 backdrop-blur-md"><Lock size={8} color="white" /></span>}
                  <span className="absolute bottom-1.5 end-1.5 rounded bg-black/55 px-1 py-0.5 text-[7.7px] font-semibold text-white tabular-nums backdrop-blur-md">{formatBytes(f.size)}</span>
                </div>
                <div className="p-2">
                  <div className="truncate text-[9.7px] font-semibold" style={{ color: "var(--text-1)" }} dir="ltr">{f.name}</div>
                  <div className="mt-0.5 flex items-center justify-between">
                    <span className="text-[8.2px] faint">{f.quality}</span>
                    <button onClick={(e) => { e.stopPropagation(); setMenu(f); }} className="press-sm flex h-4 w-4 items-center justify-center rounded"><MoreHorizontal size={10} className="faint" /></button>
                  </div>
                </div>
              </div>
            );
          }
          return (
            <button key={f.id} onClick={() => (f.type === "video" || f.type === "audio") ? onPlay(f) : setMenu(f)} className="press flex w-full items-center gap-2 rounded-[14px] border p-2 text-start glass-soft">
              <div className="relative h-9 w-9 shrink-0 overflow-hidden rounded-[10px]">
                {f.thumb ? <img src={f.thumb} alt="" className="h-full w-full object-cover" /> : <span className="flex h-full w-full items-center justify-center" style={{ background: meta.glow }}><TypeIcon type={f.type} size={14} /></span>}
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-[9.7px] font-semibold" dir="ltr">{f.name}</div>
                <div className="mt-0.5 flex items-center gap-1.5 text-[8.2px] faint"><span>{f.date}</span><span className="h-1 w-1 rounded-full bg-white/25" /><span>{formatBytes(f.size)}</span><span className="h-1 w-1 rounded-full bg-white/25" /><span>{f.quality}</span></div>
              </div>
              {f.vault && <Lock size={10} style={{ color: "var(--accent2)" }} />}
              <ChevronRight size={12} className="faint" />
            </button>
          );
        })}
      </div>

      {visible.length === 0 && (
        <div className="mt-2.5 rounded-[22px] border p-6 text-center glass-soft">
          <FolderSearch size={26} className="mx-auto faint" />
          <div className="mt-2 text-[10.5px] font-semibold">{lang === "ar" ? "لا توجد ملفات مطابقة" : "No matching files"}</div>
          <button onClick={() => { setFilter("all"); setQuery(""); }} className="mt-2 text-[9.7px] font-medium" style={{ color: "var(--accent2)" }}>{lang === "ar" ? "مسح الفلاتر" : "Clear filters"}</button>
        </div>
      )}

      <div className="mt-3 flex items-center justify-between rounded-[13px] border px-2.5 py-2 glass-soft">
        <span className="flex items-center gap-1.5 text-[9.2px]" style={{ color: "var(--success)" }}><ShieldCheck size={10} /> {lang === "ar" ? "كل الملفات محفوظة محليًا" : "All files stored locally"}</span>
        <span className="text-[8.2px] faint tabular-nums">{formatBytes(totalDownloaded)} · {files.length}</span>
      </div>

      <Sheet open={!!menu} onClose={() => setMenu(null)} lang={lang} title={<><FileText size={15} style={{ color: "var(--accent2)" }} /> {lang === "ar" ? "خيارات الملف" : "File options"}</>} subtitle={menu?.name}>
        {menu && (
          <div>
            <div className="mb-2.5 flex items-center gap-2 rounded-[14px] border p-2 glass-soft">
              <div className="h-9 w-9 overflow-hidden rounded-[10px]">{menu.thumb ? <img src={menu.thumb} alt="" className="h-full w-full object-cover" /> : <span className="flex h-full w-full items-center justify-center accent-soft"><FileText size={15} /></span>}</div>
              <div className="min-w-0 flex-1"><div className="truncate text-[10.2px] font-semibold" dir="ltr">{menu.name}</div><div className="mt-0.5 text-[8.7px] faint">{formatBytes(menu.size)} · {exactBytes(menu.size)}</div></div>
            </div>
            <div className="space-y-1">
              {[
                { icon: Play, ar: "فتح ومعاينة", en: "Open & preview", action: () => { onPlay(menu); setMenu(null); } },
                { icon: Download, ar: "حفظ نسخة", en: "Save a copy", action: () => { onToast(lang === "ar" ? "تم حفظ نسخة" : "Copy saved", menu.name); setMenu(null); } },
                { icon: Share2, ar: "مشاركة الملف", en: "Share file", action: () => { onToast(lang === "ar" ? "ورقة المشاركة" : "Share sheet", menu.name); setMenu(null); } },
                { icon: Wand2, ar: "تحويل الصيغة", en: "Convert format", action: () => { onNavigate("tools"); setMenu(null); } },
                { icon: Zap, ar: "تصغير الحجم", en: "Compress", action: () => { onNavigate("tools"); setMenu(null); } },
                { icon: FolderOpen, ar: "إظهار في المجلد", en: "Show in folder", action: () => { onToast(lang === "ar" ? "Aurora/Downloads" : "Aurora/Downloads", menu.name); setMenu(null); } },
              ].map((x) => (
                <button key={x.en} onClick={x.action} className="press flex w-full items-center gap-2.5 rounded-[12px] border px-2.5 py-2 text-start glass-soft">
                  <x.icon size={13} style={{ color: "var(--text-2)" }} />
                  <span className="flex-1 text-[10.2px]">{lang === "ar" ? x.ar : x.en}</span>
                  <ChevronRight size={11} className="faint" />
                </button>
              ))}
            </div>
            <div className="mt-2 flex items-center justify-center gap-1 text-[8.7px] faint"><Shield size={9} /> {lang === "ar" ? "اختبار السلامة: SHA-256 متاح" : "Integrity: SHA-256 available"}</div>
          </div>
        )}
      </Sheet>

      {/* vault modal */}
      {vaultOpen && (
        <div className="absolute inset-0 z-[75] flex items-center justify-center px-6">
          <button className="fade-enter absolute inset-0 bg-black/65 backdrop-blur-md" onClick={() => setVaultOpen(false)} aria-label="close" />
          <div className="fade-enter relative w-full max-w-[300px] overflow-hidden rounded-[28px] glass-deep p-5 text-center noise">
            <button onClick={() => setVaultOpen(false)} className="press absolute end-3 top-3 flex h-7 w-7 items-center justify-center rounded-full bg-white/8"><X size={13} /></button>
            <div className="absolute inset-x-0 top-0 h-24 opacity-40" style={{ background: "radial-gradient(60% 100% at 50% 0%, var(--accent2), transparent 70%)" }} />
            <div className="relative mx-auto mt-2 flex h-16 w-16 items-center justify-center rounded-[22px] border" style={{ background: "var(--accent-soft)", borderColor: "color-mix(in srgb, var(--accent2) 40%, transparent)", boxShadow: "0 14px 32px -14px var(--accent2)" }}>
              <Fingerprint size={30} style={{ color: "var(--accent2)" }} className={scan ? "pulse-dot" : ""} />
            </div>
            <h3 className="mt-3 text-[14.5px] font-semibold">{lang === "ar" ? "القبو الخاص" : "Private vault"}</h3>
            <p className="mx-auto mt-1 max-w-[210px] text-[9.7px] leading-4 muted">{lang === "ar" ? "ملفاتك المشفرة بـ AES-256 ومحمية ببصمة جهازك. لا تُرفع للسحابة أبدًا." : "AES-256 encrypted files protected by your biometrics. Never uploaded."}</p>
            <div className="mt-2 flex justify-center gap-1"><Chip tone="success"><ShieldCheck size={8} /> AES-256</Chip><Chip tone="accent">{lang === "ar" ? "ملفان" : "2 files"}</Chip></div>
            <button onClick={() => setScan(true)} className="press btn-primary mt-4 flex w-full items-center justify-center gap-1.5 rounded-[14px] py-2.5 text-[10.5px] font-bold">
              {scan ? <Fingerprint size={14} className="spin-slow" /> : <Fingerprint size={14} />}
              {scan ? (lang === "ar" ? "جاري التحقق…" : "Verifying…") : unlocked ? (lang === "ar" ? "مفتوح بالفعل" : "Already unlocked") : lang === "ar" ? "فتح بالبصمة" : "Unlock with biometrics"}
            </button>
            <button onClick={() => onToast(lang === "ar" ? "الرمز السري" : "PIN code", lang === "ar" ? "أدخل رمزًا مكوّنًا من 6 أرقام" : "Enter your 6-digit PIN")} className="mt-1.5 w-full text-[9.2px] faint">{lang === "ar" ? "استخدام رمز الجهاز بدلًا من ذلك" : "Use device PIN instead"}</button>
          </div>
        </div>
      )}

      <div className="mt-3 flex items-center justify-center gap-1 pb-1 text-[8.7px] faint">
        <HardDrive size={9} /> {lang === "ar" ? "تنظيم تلقائي: /Aurora/النوع/الموقع/التاريخ" : "Auto-organized: /Aurora/type/site/date"}
      </div>
    </div>
  );
}

export type PlayerProps = {
  lang: Lang;
  file: FileItem;
  onBack: () => void;
  onNavigate: (s: Screen) => void;
  onDownload: () => void;
  onToast: (m: string, d?: string) => void;
};

export function Player({ lang, file, onBack, onNavigate, onDownload, onToast }: PlayerProps) {
  const [playing, setPlaying] = useState(true);
  const [progress, setProgress] = useState(23);
  const [speed, setSpeed] = useState(1);
  const [captions, setCaptions] = useState(true);
  const [tab, setTab] = useState<"chapters" | "subtitles" | "audio">("chapters");

  useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => setProgress((p) => (p >= 99.6 ? 0 : p + 0.35)), 700);
    return () => clearInterval(t);
  }, [playing]);

  const speeds = [1, 1.25, 1.5, 2];
  const durationSec = 768;
  const elapsed = Math.floor((progress / 100) * durationSec);
  const mmss = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

  return (
    <div className="pt-1">
      <div className="flex items-center justify-between px-3.5">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="press flex h-8 w-8 items-center justify-center rounded-[11px] border glass-soft"><ArrowLeft size={14} className={lang === "ar" ? "rotate-180" : ""} /></button>
          <div>
            <div className="text-[11.5px] font-semibold">{lang === "ar" ? "مشغل Aurora" : "Aurora Player"}</div>
            <div className="text-[8.7px] faint">{lang === "ar" ? "Media3 · HDR · بدون تسريب للذاكرة" : "Media3 · HDR · leak-free"}</div>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => onToast(lang === "ar" ? "تشغيل في نافذة عائمة PiP" : "Picture-in-picture", lang === "ar" ? "يستمر عند الخروج من التطبيق" : "Keeps playing outside the app")} className="press flex h-7 w-7 items-center justify-center rounded-[9px] border glass-soft"><PictureInPicture2 size={12} /></button>
          <button onClick={() => onToast(lang === "ar" ? "مشاركة" : "Share", file.name)} className="press flex h-7 w-7 items-center justify-center rounded-[9px] border glass-soft"><Share2 size={12} /></button>
          <button onClick={() => onToast(lang === "ar" ? "خيارات المشغل" : "Player options", lang === "ar" ? "ترجمة، مسارات صوت، سرعة" : "Captions, audio tracks, speed")} className="press flex h-7 w-7 items-center justify-center rounded-[9px] border glass-soft"><MoreHorizontal size={13} /></button>
        </div>
      </div>

      <div className="mt-2.5 px-3.5">
        <div className="relative overflow-hidden rounded-[22px] border" style={{ borderColor: "var(--line)", boxShadow: "0 24px 50px -26px #000" }}>
          <img src={file.thumb ?? images.aurora} alt={file.name} className="h-[196px] w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-black/25" />
          <div className="absolute start-2 top-2 flex items-center gap-1">
            <span className="rounded-full border border-white/20 bg-black/40 px-1.5 py-0.5 text-[7.7px] font-bold text-white backdrop-blur-md">4K HDR</span>
            <span className="rounded-full border border-white/20 bg-black/40 px-1.5 py-0.5 text-[7.7px] font-bold text-white backdrop-blur-md">VP9 · 60fps</span>
            {captions && <span className="rounded-full border border-white/20 bg-black/40 px-1.5 py-0.5 text-[7.7px] font-bold text-white backdrop-blur-md">CC</span>}
          </div>
          <button onClick={() => setPlaying(!playing)} className="press absolute inset-0 flex items-center justify-center" aria-label="play">
            <span className="flex h-12 w-12 items-center justify-center rounded-full border border-white/35 bg-black/30 backdrop-blur-md" style={{ boxShadow: "0 0 30px rgba(0,0,0,.4)" }}>
              {playing ? <Pause size={19} color="white" fill="white" /> : <Play size={19} color="white" fill="white" className="ms-0.5" />}
            </span>
          </button>
          {captions && playing && (
            <div className="absolute inset-x-0 bottom-[54px] flex justify-center px-4">
              <span className="rounded-md bg-black/60 px-2 py-1 text-center text-[9.2px] leading-4 text-white backdrop-blur-md">
                {lang === "ar" ? "وتحوّل السماء فوق البحيرة إلى نهرٍ من الضوء الأخضر." : "And the sky above the lake became a river of green light."}
              </span>
            </div>
          )}
          <div className="absolute inset-x-2.5 bottom-2">
            <div className="mb-1.5 flex items-center gap-2">
              <span className="text-[8.7px] font-medium tabular-nums text-white/85">{mmss(elapsed)}</span>
              <div className="relative h-[3px] flex-1 overflow-hidden rounded-full bg-white/25">
                <div className="h-full rounded-full accent-gradient" style={{ width: `${progress}%` }} />
                <span className="absolute top-1/2 h-2 w-2 -translate-y-1/2 rounded-full bg-white shadow" style={{ insetInlineStart: `calc(${progress}% - 4px)` }} />
              </div>
              <span className="text-[8.7px] tabular-nums text-white/70">{mmss(durationSec)}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5 text-white/85">
                <button onClick={() => onToast(lang === "ar" ? "الصوت" : "Volume", "100%")}><Volume2 size={12} /></button>
                <button onClick={() => setCaptions(!captions)} style={{ color: captions ? "var(--accent1)" : undefined }}><Captions size={12} /></button>
                <button
                  onClick={() => setSpeed(speeds[(speeds.indexOf(speed) + 1) % speeds.length])}
                  className="rounded-full border border-white/20 bg-black/25 px-1.5 py-0.5 text-[8.2px] font-bold tabular-nums backdrop-blur-md"
                >
                  {speed}×
                </button>
              </div>
              <div className="flex items-center gap-2.5 text-white/85">
                <button onClick={() => onToast(lang === "ar" ? "تكبير الشاشة" : "Zoom", lang === "ar" ? "حركة بإصبعين" : "Pinch to zoom")}><Maximize2 size={12} /></button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-3 px-3.5">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h1 className="line-clamp-2 text-[13.5px] font-semibold leading-5">{lang === "ar" ? "Aurora — Northern Lights in 8K HDR" : "Aurora — Northern Lights in 8K HDR"}</h1>
            <div className="mt-1 flex items-center gap-1.5 text-[9.2px] faint">
              <span>Aurora Studio</span><span className="h-1 w-1 rounded-full bg-white/25" /><span>1.8M {lang === "ar" ? "مشاهدة" : "views"}</span><span className="h-1 w-1 rounded-full bg-white/25" /><span>{lang === "ar" ? "قبل 3 أيام" : "3 days ago"}</span>
            </div>
          </div>
          <button onClick={onDownload} className="press btn-primary flex shrink-0 items-center gap-1 rounded-[10px] px-2.5 py-1.5 text-[9.2px] font-bold"><Download size={10} /> {lang === "ar" ? "تحميل" : "Download"}</button>
        </div>

        <div className="mt-2 grid grid-cols-4 gap-1.5">
          {[
            { icon: Download, ar: "حفظ", en: "Save", action: onDownload },
            { icon: Wand2, ar: "تحويل", en: "Convert", action: () => onNavigate("tools") },
            { icon: Zap, ar: "تصغير", en: "Compress", action: () => onNavigate("tools") },
            { icon: Share2, ar: "مشاركة", en: "Share", action: () => onToast(lang === "ar" ? "مشاركة الملف" : "Share file", file.name) },
          ].map((x) => (
            <button key={x.en} onClick={x.action} className="press flex flex-col items-center gap-1 rounded-[13px] border py-2 glass-soft">
              <x.icon size={13} style={{ color: "var(--text-2)" }} />
              <span className="text-[8.7px] muted">{lang === "ar" ? x.ar : x.en}</span>
            </button>
          ))}
        </div>

        <div className="mt-2.5 flex gap-1 rounded-[12px] border p-1 glass-soft">
          {[
            { id: "chapters" as const, ar: "الفصول", en: "Chapters" },
            { id: "subtitles" as const, ar: "الترجمة", en: "Subtitles" },
            { id: "audio" as const, ar: "الصوت", en: "Audio" },
          ].map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)} className="press flex-1 rounded-[8px] py-1.5 text-[9.2px] font-medium" style={{ background: tab === t.id ? "var(--accent-soft)" : "transparent", color: tab === t.id ? "var(--text-1)" : "var(--text-2)" }}>{lang === "ar" ? t.ar : t.en}</button>
          ))}
        </div>

        <div className="mt-1.5 space-y-1">
          {tab === "chapters" && [
            { t: "00:00", ar: "مقدمة — فوق الجليد", en: "Intro — Above the ice" },
            { t: "03:12", ar: "الشفق الأول", en: "First lights" },
            { t: "07:40", ar: "ذروة التوهج الأخضر", en: "Peak green glow" },
          ].map((c, i) => (
            <button key={c.t} onClick={() => { setProgress([2, 25, 60][i]); onToast(lang === "ar" ? "انتقل المشغل" : "Jumped", c.t); }} className="press flex w-full items-center gap-2 rounded-[10px] border px-2 py-1.5 text-start glass-soft">
              <span className="rounded bg-white/8 px-1 text-[8.2px] tabular-nums faint">{c.t}</span>
              <span className="flex-1 text-[9.2px]">{lang === "ar" ? c.ar : c.en}</span>
              <Play size={9} className="faint" />
            </button>
          ))}
          {tab === "subtitles" && (
            <div className="space-y-1">
              {["العربية · SRT", "English · VTT", "日本語 · ASS"].map((s, i) => (
                <div key={s} className="flex items-center justify-between rounded-[10px] border px-2 py-1.5 glass-soft">
                  <span className="text-[9.2px]">{s}</span>
                  <button onClick={() => onToast(lang === "ar" ? "تم اختيار الترجمة" : "Subtitle selected", s)} className={`rounded-full px-2 py-0.5 text-[8.2px] font-bold ${i === 0 ? "accent-gradient text-white" : "bg-white/8 muted"}`}>{i === 0 ? (lang === "ar" ? "مفعّل" : "On") : (lang === "ar" ? "اختيار" : "Use")}</button>
                </div>
              ))}
            </div>
          )}
          {tab === "audio" && (
            <div className="space-y-1">
              {["Arabic · Stereo · AAC 256", "English · 5.1 · Opus", "Original · Stereo"].map((s, i) => (
                <div key={s} className="flex items-center justify-between rounded-[10px] border px-2 py-1.5 glass-soft">
                  <span className="text-[9.2px]">{s}</span>
                  <span className="text-[8.2px]" style={{ color: i === 0 ? "var(--accent2)" : "var(--text-3)" }}>{i === 0 ? (lang === "ar" ? "نشط" : "Active") : "—"}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="mt-2.5 rounded-[15px] border p-2.5 glass-soft">
          <div className="grid grid-cols-2 gap-y-1.5 text-[8.7px]">
            {[
              { ar: "الحجم الدقيق", en: "Exact size", value: exactBytes(file.size) },
              { ar: "الترميز", en: "Codec", value: "VP9 · Opus" },
              { ar: "الدقة", en: "Resolution", value: "3840 × 2160" },
              { ar: "المسار", en: "Path", value: "/Aurora/Video/" },
            ].map((r) => (
              <div key={r.en}><div className="faint">{lang === "ar" ? r.ar : r.en}</div><div className="mt-0.5 font-medium" dir="ltr">{r.value}</div></div>
            ))}
          </div>
        </div>

        <div className="mt-2.5 flex items-center gap-1.5 rounded-[13px] border px-2.5 py-2 glass-soft">
          <Gauge size={12} style={{ color: "var(--accent2)" }} />
          <span className="flex-1 text-[8.7px] muted">{lang === "ar" ? "شغّل بإيماءات: اسحب للبحث، إصبعان للصوت والسطوع" : "Gestures: swipe to seek, two fingers for volume & brightness"}</span>
        </div>

        <div className="mt-3">
          <SectionTitle title={lang === "ar" ? "التالي في القائمة" : "Up next"} />
          <div className="space-y-1.5">
            {[
              { img: images.auroraAlt, title: "Iceland from Above — Drone Film", dur: "08:21" },
              { img: images.studio, title: "Midnight Frequencies — Visualizer", dur: "03:44" },
            ].map((v) => (
              <button key={v.title} onClick={() => onToast(lang === "ar" ? "التالي" : "Up next", v.title)} className="press flex w-full items-center gap-2 rounded-[12px] border p-1.5 text-start glass-soft">
                <div className="relative h-8 w-12 shrink-0 overflow-hidden rounded-[7px]"><img src={v.img} alt="" className="h-full w-full object-cover" /><span className="absolute inset-0 flex items-center justify-center"><Play size={8} color="white" fill="white" /></span><span className="absolute bottom-0.5 end-0.5 rounded bg-black/60 px-0.5 text-[7.2px] text-white">{v.dur}</span></div>
                <span className="flex-1 truncate text-[9.2px]">{v.title}</span>
                <ChevronRight size={11} className="faint" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
