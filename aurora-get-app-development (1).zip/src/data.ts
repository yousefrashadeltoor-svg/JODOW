export type Lang = "ar" | "en";
export type ThemeId = "aurora" | "ocean" | "sunset" | "emerald" | "mono" | "neon";
export type Appearance = "dark" | "light";
export type ContentType = "video" | "audio" | "image" | "file";
export type Screen = "home" | "downloads" | "browser" | "files" | "settings" | "tools" | "player";
export type DownloadStatus = "downloading" | "paused" | "queued" | "done" | "failed";

export const contentTypeMeta: Record<
  ContentType,
  { ar: string; en: string; color: string; glow: string }
> = {
  video: { ar: "فيديو", en: "Video", color: "#7ea6ff", glow: "rgba(74,140,255,.32)" },
  audio: { ar: "صوت", en: "Audio", color: "#c79bff", glow: "rgba(164,120,232,.32)" },
  image: { ar: "صور", en: "Images", color: "#ff9d9d", glow: "rgba(239,115,128,.3)" },
  file: { ar: "ملفات", en: "Files", color: "#7ee3ca", glow: "rgba(94,225,176,.28)" },
};

export const themes: { id: ThemeId; ar: string; en: string; swatch: string }[] = [
  { id: "aurora", ar: "أورورا", en: "Aurora", swatch: "linear-gradient(135deg,#4a8cff,#a478e8 55%,#ef7380)" },
  { id: "ocean", ar: "محيط", en: "Ocean", swatch: "linear-gradient(135deg,#2ee6d6,#3aa8ff 55%,#7b7dff)" },
  { id: "sunset", ar: "غروب", en: "Sunset", swatch: "linear-gradient(135deg,#ffb35c,#ff7a7a 55%,#e765c9)" },
  { id: "emerald", ar: "زمرد", en: "Emerald", swatch: "linear-gradient(135deg,#53e6a5,#2ec7c2 55%,#84d9ff)" },
  { id: "neon", ar: "نيون", en: "Neon", swatch: "linear-gradient(135deg,#a3ff4e,#39f5d2 55%,#ff5fd2)" },
  { id: "mono", ar: "رمادي", en: "Mono", swatch: "linear-gradient(135deg,#f0f2f8,#b9c0d4 55%,#818aa3)" },
];

export type FormatItem = {
  id: string;
  type: ContentType;
  quality: string;
  container: string;
  codec: string;
  detail: string;
  bytes: number | null;
  approx: boolean;
  best?: boolean;
  badge?: string;
  merge?: boolean;
};

export type AnalyzedSource = {
  id: string;
  site: string;
  domain: string;
  title: string;
  filename: string;
  thumbnail: string;
  duration: string;
  channel: string;
  date: string;
  counts: Partial<Record<ContentType, number>>;
  selectedSize: { bytes: number; approx: boolean };
  outputNote?: string;
  tint: string;
};

export const images = {
  aurora:
    "https://images.pexels.com/photos/15487406/pexels-photo-15487406.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  auroraAlt:
    "https://images.pexels.com/photos/11685290/pexels-photo-11685290.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  auroraLake:
    "https://images.pexels.com/photos/150240/pexels-photo-150240.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  neon:
    "https://images.pexels.com/photos/12641037/pexels-photo-12641037.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  studio:
    "https://images.pexels.com/photos/5749191/pexels-photo-5749191.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
};

export const sources: AnalyzedSource[] = [
  {
    id: "youtube",
    site: "YouTube",
    domain: "youtube.com",
    title: "Aurora — Northern Lights in 8K HDR | ساعة من الهدوء",
    filename: "aurora-northern-lights-8k.mp4",
    thumbnail: images.aurora,
    duration: "12:48",
    channel: "Aurora Studio",
    date: "قبل 3 أيام",
    counts: { video: 12, audio: 7, image: 6, file: 5 },
    selectedSize: { bytes: 892160400, approx: false },
    tint: "#7aa7ff",
  },
  {
    id: "tiktok",
    site: "TikTok",
    domain: "tiktok.com",
    title: "Golden hour transitions — شروق الشمس على البحر",
    filename: "golden-hour-transitions.mp4",
    thumbnail: images.neon,
    duration: "00:28",
    channel: "@aurora.moves",
    date: "قبل يومين",
    counts: { video: 4, audio: 3, image: 2 },
    selectedSize: { bytes: 28442112, approx: true },
    tint: "#c79bff",
  },
  {
    id: "instagram",
    site: "Instagram",
    domain: "instagram.com",
    title: "Midnight Frequencies — Photo Mode · 10 slides",
    filename: "midnight-frequencies-carousel.zip",
    thumbnail: images.studio,
    duration: "—",
    channel: "@midnight.freq",
    date: "قبل 5 ساعات",
    counts: { video: 3, audio: 1, image: 10 },
    selectedSize: { bytes: 46228840, approx: false },
    tint: "#ff9d9d",
  },
  {
    id: "direct",
    site: "Direct Link",
    domain: "cdn.auroraget.app",
    title: "Design_Resources_v4.zip — ملف مباشر",
    filename: "Design_Resources_v4.zip",
    thumbnail: images.auroraLake,
    duration: "—",
    channel: "cdn.auroraget.app",
    date: "الآن",
    counts: { file: 1 },
    selectedSize: { bytes: 432883712, approx: false },
    tint: "#7ee3ca",
  },
];

export const formats: Record<ContentType, FormatItem[]> = {
  video: [
    {
      id: "v4320",
      type: "video",
      quality: "4320p · 8K HDR",
      container: "MP4",
      codec: "AV1",
      detail: "60fps · 68.4 Mbps",
      bytes: 2789210112,
      approx: true,
      badge: "الأفضل",
    },
    {
      id: "v2160",
      type: "video",
      quality: "2160p · 4K HDR",
      container: "MP4",
      codec: "VP9",
      detail: "60fps · 22.8 Mbps",
      bytes: 892160400,
      approx: false,
      best: true,
      badge: "موصى به",
    },
    {
      id: "v1440",
      type: "video",
      quality: "1440p · QHD",
      container: "WEBM",
      codec: "VP9",
      detail: "60fps · 12.4 Mbps",
      bytes: 348221050,
      approx: false,
    },
    {
      id: "v1080",
      type: "video",
      quality: "1080p · FHD",
      container: "MP4",
      codec: "AVC",
      detail: "60fps · 6.2 Mbps",
      bytes: 148372910,
      approx: false,
      merge: true,
    },
    {
      id: "v720",
      type: "video",
      quality: "720p · HD",
      container: "MP4",
      codec: "AVC",
      detail: "30fps · 3.1 Mbps",
      bytes: 74518220,
      approx: false,
      merge: true,
    },
    {
      id: "v480",
      type: "video",
      quality: "480p · SD",
      container: "MP4",
      codec: "AVC",
      detail: "30fps · 1.4 Mbps",
      bytes: 33821400,
      approx: true,
    },
  ],
  audio: [
    {
      id: "aflac",
      type: "audio",
      quality: "Lossless · Studio",
      container: "FLAC",
      codec: "FLAC",
      detail: "1,411 kbps · 48 kHz",
      bytes: 84910332,
      approx: false,
      badge: "بدون فقد",
    },
    {
      id: "aopus",
      type: "audio",
      quality: "Original · High",
      container: "OPUS",
      codec: "Opus",
      detail: "160 kbps · 48 kHz",
      bytes: 15382144,
      approx: false,
      best: true,
      badge: "موصى به",
    },
    {
      id: "aaac",
      type: "audio",
      quality: "High · Stereo",
      container: "M4A",
      codec: "AAC",
      detail: "256 kbps · 44.1 kHz",
      bytes: 24412980,
      approx: false,
    },
    {
      id: "amp3",
      type: "audio",
      quality: "Compatible",
      container: "MP3",
      codec: "LAME",
      detail: "320 kbps · 44.1 kHz",
      bytes: 30118440,
      approx: true,
    },
    {
      id: "awav",
      type: "audio",
      quality: "Uncompressed",
      container: "WAV",
      codec: "PCM",
      detail: "1,536 kbps · 48 kHz",
      bytes: 92184000,
      approx: false,
    },
  ],
  image: [
    {
      id: "imax",
      type: "image",
      quality: "Max resolution",
      container: "WEBP",
      codec: "—",
      detail: "1280 × 720 · 248 KB",
      bytes: 248112,
      approx: false,
      best: true,
      badge: "موصى به",
    },
    {
      id: "i4k",
      type: "image",
      quality: "Cover · 4K",
      container: "PNG",
      codec: "—",
      detail: "3840 × 2160 · 4.8 MB",
      bytes: 4812990,
      approx: false,
    },
    {
      id: "ihq",
      type: "image",
      quality: "High quality",
      container: "JPG",
      codec: "—",
      detail: "1920 × 1080 · 1.2 MB",
      bytes: 1248110,
      approx: true,
    },
    {
      id: "iwebp",
      type: "image",
      quality: "Story · 1080",
      container: "WEBP",
      codec: "—",
      detail: "1080 × 1920 · 860 KB",
      bytes: 881214,
      approx: true,
    },
  ],
  file: [
    {
      id: "fsrt",
      type: "file",
      quality: "Arabic subtitles",
      container: "SRT",
      codec: "UTF-8",
      detail: "12:48 · 214 سطرًا",
      bytes: 48112,
      approx: false,
      best: true,
    },
    {
      id: "fvtt",
      type: "file",
      quality: "English captions",
      container: "VTT",
      codec: "UTF-8",
      detail: "12:48 · 208 سطرًا",
      bytes: 46280,
      approx: false,
    },
    {
      id: "fass",
      type: "file",
      quality: "Styled captions",
      container: "ASS",
      codec: "UTF-8",
      detail: "12:48 · منسّق",
      bytes: 71210,
      approx: true,
    },
    {
      id: "fjson",
      type: "file",
      quality: "Metadata & manifest",
      container: "JSON",
      codec: "UTF-8",
      detail: "بيانات وصفية كاملة",
      bytes: 18422,
      approx: false,
    },
  ],
};

export type DownloadItem = {
  id: string;
  name: string;
  host: string;
  type: ContentType;
  bytes: number;
  downloaded: number;
  speed: number;
  connections: number;
  status: DownloadStatus;
  thumbnail?: string;
  quality: string;
  exact: boolean;
  spark: number[];
};

export const initialDownloads: DownloadItem[] = [
  {
    id: "d1",
    name: "aurora-northern-lights-8k.mp4",
    host: "youtube.com",
    type: "video",
    bytes: 892160400,
    downloaded: 356864160,
    speed: 24.8,
    connections: 32,
    status: "downloading",
    thumbnail: images.aurora,
    quality: "2160p · VP9",
    exact: true,
    spark: [12, 18, 15, 27, 22, 31, 28, 36, 33, 41, 38, 45, 42, 49],
  },
  {
    id: "d2",
    name: "Midnight_Frequencies_FLAC.zip",
    host: "soundcloud.com",
    type: "audio",
    bytes: 184420880,
    downloaded: 132782760,
    speed: 9.4,
    connections: 16,
    status: "downloading",
    thumbnail: images.neon,
    quality: "FLAC · Lossless",
    exact: true,
    spark: [6, 8, 7, 12, 10, 14, 11, 16, 13, 18, 15, 19, 17, 21],
  },
  {
    id: "d3",
    name: "golden-hour-transitions.mp4",
    host: "tiktok.com",
    type: "video",
    bytes: 28442112,
    downloaded: 0,
    speed: 0,
    connections: 0,
    status: "queued",
    thumbnail: images.neon,
    quality: "1080p · بدون علامة",
    exact: false,
    spark: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  },
  {
    id: "d4",
    name: "Design_Resources_v4.zip",
    host: "cdn.auroraget.app",
    type: "file",
    bytes: 432883712,
    downloaded: 199238912,
    speed: 0,
    connections: 0,
    status: "paused",
    thumbnail: images.auroraLake,
    quality: "ZIP · مصدر مباشر",
    exact: true,
    spark: [8, 13, 19, 17, 24, 21, 27, 18, 15, 12, 9, 6, 3, 0],
  },
  {
    id: "d5",
    name: "Aurora_Still_Cover.png",
    host: "youtube.com",
    type: "image",
    bytes: 4812990,
    downloaded: 4812990,
    speed: 0,
    connections: 0,
    status: "done",
    thumbnail: images.auroraAlt,
    quality: "PNG · 4K",
    exact: true,
    spark: [4, 9, 16, 22, 29, 33, 38, 42, 47, 51, 56, 60, 64, 68],
  },
  {
    id: "d6",
    name: "reel_midnight_freq.mp4",
    host: "instagram.com",
    type: "video",
    bytes: 12642880,
    downloaded: 4210000,
    speed: 0,
    connections: 0,
    status: "failed",
    thumbnail: images.studio,
    quality: "1080p · AVC",
    exact: true,
    spark: [10, 12, 14, 11, 8, 6, 4, 2, 0, 0, 0, 0, 0, 0],
  },
];

export const initialFiles = [
  {
    id: "f1",
    name: "aurora-northern-lights-8k.mp4",
    type: "video" as ContentType,
    size: 892160400,
    quality: "2160p HDR",
    thumb: images.aurora,
    date: "اليوم · 18:24",
    host: "youtube.com",
    vault: false,
  },
  {
    id: "f2",
    name: "Aurora_Still_Cover.png",
    type: "image" as ContentType,
    size: 4812990,
    quality: "3840 × 2160",
    thumb: images.auroraAlt,
    date: "اليوم · 18:21",
    host: "youtube.com",
    vault: false,
  },
  {
    id: "f3",
    name: "Midnight_Frequencies.flac",
    type: "audio" as ContentType,
    size: 84910332,
    quality: "Lossless · 48kHz",
    thumb: images.neon,
    date: "أمس · 23:10",
    host: "soundcloud.com",
    vault: false,
  },
  {
    id: "f4",
    name: "golden-hour-transitions.mp4",
    type: "video" as ContentType,
    size: 28442112,
    quality: "1080p",
    thumb: images.studio,
    date: "أمس · 21:02",
    host: "tiktok.com",
    vault: false,
  },
  {
    id: "f5",
    name: "Design_Resources_v4.zip",
    type: "file" as ContentType,
    size: 432883712,
    quality: "ZIP · Zopfli",
    thumb: images.auroraLake,
    date: "الثلاثاء · 09:44",
    host: "cdn.auroraget.app",
    vault: false,
  },
  {
    id: "f6",
    name: "Arabic_Subtitles.srt",
    type: "file" as ContentType,
    size: 48112,
    quality: "SRT · UTF-8",
    date: "الثلاثاء · 09:44",
    host: "youtube.com",
    vault: false,
  },
  {
    id: "f7",
    name: "personal_notes.pdf",
    type: "file" as ContentType,
    size: 2481120,
    quality: "PDF · 32 صفحة",
    date: "قبل 4 أيام",
    host: "local",
    vault: true,
  },
  {
    id: "f8",
    name: "privé_photo_018.jpg",
    type: "image" as ContentType,
    size: 3829920,
    quality: "JPG · 3024 × 4032",
    date: "قبل 6 أيام",
    host: "local",
    vault: true,
  },
];

export const browserItems = [
  {
    id: "b1",
    title: "aurora_8k_master.mp4",
    type: "video" as ContentType,
    format: "MP4 · HLS",
    detail: "2160p · HDR",
    bytes: 892160400,
    approx: false,
  },
  {
    id: "b2",
    title: "ambient_theme.m4a",
    type: "audio" as ContentType,
    format: "M4A · AAC",
    detail: "256 kbps",
    bytes: 8442120,
    approx: true,
  },
  {
    id: "b3",
    title: "northern-lights-poster.png",
    type: "image" as ContentType,
    format: "PNG",
    detail: "3840 × 2160",
    bytes: 4812990,
    approx: false,
  },
  {
    id: "b4",
    title: "playlist_index.m3u8",
    type: "file" as ContentType,
    format: "M3U8",
    detail: "HLS · 84 مقطعًا",
    bytes: 18422,
    approx: false,
  },
  {
    id: "b5",
    title: "travel-guide.pdf",
    type: "file" as ContentType,
    format: "PDF",
    detail: "18 صفحة",
    bytes: 12484010,
    approx: true,
  },
];

export const compressionFiles = [
  {
    id: "c1",
    name: "Aurora_Still_Cover.png",
    type: "image",
    thumb: images.auroraAlt,
    before: 4812990,
    after: 1248110,
    mode: "lossless" as const,
    detail: "oxipng · lossless",
  },
  {
    id: "c2",
    name: "golden-hour-transitions.mp4",
    type: "video",
    thumb: images.studio,
    before: 28442112,
    after: 11484112,
    mode: "transparent" as const,
    detail: "HEVC CRF 23 · VMAF 96.4",
  },
  {
    id: "c3",
    name: "Midnight_Frequencies.flac",
    type: "audio",
    thumb: images.neon,
    before: 84910332,
    after: 61220210,
    mode: "lossless" as const,
    detail: "FLAC -8 · bit-exact",
  },
];

/* ── Helpers ─────────────────────────────────────────────── */
export function formatBytes(bytes: number, approx = false): string {
  if (bytes === 0) return "0 B";
  const miB = bytes / (1024 * 1024);
  if (miB >= 1024) return `${approx ? "≈ " : ""}${(miB / 1024).toFixed(2)} GiB`;
  if (miB >= 1) return `${approx ? "≈ " : ""}${miB.toFixed(1)} MiB`;
  return `${approx ? "≈ " : ""}${Math.max(1, Math.round(bytes / 1024))} KB`;
}

export function exactBytes(bytes: number): string {
  return `${bytes.toLocaleString("en-US")} bytes`;
}

export function formatDate(lang: Lang): string {
  return lang === "ar" ? "اليوم · 18:24" : "Today · 18:24";
}
