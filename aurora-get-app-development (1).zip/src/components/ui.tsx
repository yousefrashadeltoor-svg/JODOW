import { useEffect, useMemo, useState } from "react";
import {
  BatteryFull,
  Check,
  ChevronDown,
  Download,
  FolderDown,
  Home,
  Camera,
  Play,
  LayoutGrid,
  Music2,
  Settings,
  ShieldCheck,
  Wifi,
  X,
  Globe,
  Compass,
  Sparkles,
} from "lucide-react";
import type { ContentType, Lang, Screen } from "../data";
import { contentTypeMeta } from "../data";

/* ── Status bar ─────────────────────────────────────────── */
export function StatusBar({ appearance }: { appearance: string }) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(t);
  }, []);
  const dark = appearance === "light";
  return (
    <div
      dir="ltr"
      className="relative z-50 flex h-[42px] shrink-0 items-end justify-between px-7 pb-1 text-[12.5px] font-semibold tracking-wide"
      style={{ color: dark ? "#212638" : "#f2f4fb" }}
    >
      <span className="w-16">{now.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}</span>
      <div className="flex w-16 items-center justify-end gap-1.5">
        <span className="flex items-end gap-[2px]">
          {[4, 6, 8, 10].map((h, i) => (
            <span key={i} className="w-[3px] rounded-sm bg-current" style={{ height: h, opacity: i === 3 ? 0.55 : 0.95 }} />
          ))}
        </span>
        <Wifi size={13} strokeWidth={2.6} />
        <span className="flex items-center">
          <BatteryFull size={18} strokeWidth={2} />
        </span>
      </div>
    </div>
  );
}

/* ── Bottom dock ────────────────────────────────────────── */
const dockItems: { id: Screen; ar: string; en: string; icon: typeof Home }[] = [
  { id: "home", ar: "الرئيسية", en: "Home", icon: Home },
  { id: "downloads", ar: "التحميلات", en: "Downloads", icon: Download },
  { id: "browser", ar: "المتصفح", en: "Browser", icon: Compass },
  { id: "files", ar: "المكتبة", en: "Library", icon: FolderDown },
  { id: "settings", ar: "الإعدادات", en: "Settings", icon: Settings },
];

export function Dock({
  screen,
  lang,
  onNavigate,
  activeCount,
}: {
  screen: Screen;
  lang: Lang;
  onNavigate: (s: Screen) => void;
  activeCount: number;
}) {
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-40 px-3 pb-3">
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[96px]" style={{ background: "linear-gradient(to top, var(--bg-deep) 12%, transparent)" }} />
      <div className="pointer-events-auto relative mx-auto grid max-w-[380px] grid-cols-5 gap-1 rounded-[26px] glass-deep px-2 py-2">
        {dockItems.map(({ id, ar, en, icon: Icon }) => {
          const active = screen === id;
          return (
            <button
              key={id}
              onClick={() => onNavigate(id)}
              aria-label={lang === "ar" ? ar : en}
              className="press relative flex flex-col items-center gap-1 rounded-[18px] py-1.5"
            >
              {active && (
                <span
                  className="absolute inset-0 rounded-[18px] border accent-soft"
                  style={{ borderColor: "var(--line-strong)" }}
                />
              )}
              <span className="relative">
                <Icon
                  size={19}
                  strokeWidth={active ? 2.3 : 1.8}
                  style={{ color: active ? "var(--accent2)" : "var(--text-3)" }}
                />
                {id === "downloads" && activeCount > 0 && (
                  <span className="absolute -end-1.5 -top-1.5 flex h-[14px] min-w-[14px] items-center justify-center rounded-full px-1 text-[9.2px] font-bold text-white accent-gradient">
                    {activeCount}
                  </span>
                )}
              </span>
              <span
                className="relative text-[10.7px] font-medium leading-none"
                style={{ color: active ? "var(--text-1)" : "var(--text-3)" }}
              >
                {lang === "ar" ? ar : en}
              </span>
              {active && (
                <span className="absolute -bottom-[3px] h-[2px] w-4 rounded-full accent-gradient" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ── Site identity ──────────────────────────────────────── */
export function SiteLogo({ site, size = 38 }: { site: string; size?: number }) {
  const map: Record<string, { bg: string; icon: React.ReactNode; label: string }> = {
    YouTube: { bg: "linear-gradient(140deg,#ff5d6c,#e2263b)", icon: <Play size={size * 0.42} color="white" fill="white" />, label: "YT" },
    TikTok: { bg: "linear-gradient(140deg,#34e0d0,#7a5cff 70%)", icon: <Music2 size={size * 0.48} color="white" />, label: "TT" },
    Instagram: { bg: "linear-gradient(140deg,#ffc463,#f4557f 48%,#a25bff)", icon: <Camera size={size * 0.46} color="white" />, label: "IG" },
    "Direct Link": { bg: "linear-gradient(140deg,#3ee0b0,#1b9c9a)", icon: <Globe size={size * 0.48} color="white" />, label: "DL" },
    SoundCloud: { bg: "linear-gradient(140deg,#ff9a4d,#ff5b3b)", icon: <Music2 size={size * 0.48} color="white" />, label: "SC" },
    cdn: { bg: "linear-gradient(140deg,#3ee0b0,#1b9c9a)", icon: <Globe size={size * 0.48} color="white" />, label: "DL" },
  };
  const item = map[site] ?? {
    bg: "linear-gradient(140deg,var(--accent1),var(--accent3))",
    icon: <Globe size={size * 0.48} color="white" />,
    label: site.slice(0, 2).toUpperCase(),
  };
  return (
    <span
      className="relative flex shrink-0 items-center justify-center rounded-[13px] shadow-lg"
      style={{ width: size, height: size, background: item.bg, boxShadow: "0 8px 22px -10px rgba(0,0,0,.8), inset 0 1px 0 rgba(255,255,255,.4)" }}
    >
      {item.icon}
    </span>
  );
}

/* ── Small building blocks ─────────────────────────────── */
export function Chip({
  children,
  tone = "neutral",
  className = "",
  onClick,
}: {
  children: React.ReactNode;
  tone?: "neutral" | "success" | "warning" | "accent" | "danger";
  className?: string;
  onClick?: () => void;
}) {
  const tones: Record<string, string> = {
    neutral: "bg-white/[0.06] text-[var(--text-2)] border-white/10",
    success: "text-[#64e6b6] bg-[#3fe0aa]/10 border-[#3fe0aa]/25",
    warning: "text-[#ffd284] bg-[#ffd284]/10 border-[#ffd284]/25",
    accent: "text-[var(--accent2)] bg-[var(--accent-soft)] border-white/15",
    danger: "text-[#ff95a1] bg-[#ff6b81]/10 border-[#ff6b81]/25",
  };
  const Cmp = onClick ? "button" : "span";
  return (
    <Cmp
      onClick={onClick}
      className={`inline-flex items-center gap-1 rounded-full border px-2 py-[3px] text-[10.5px] font-medium leading-4 ${tones[tone]} ${className}`}
    >
      {children}
    </Cmp>
  );
}

export function Toggle({
  on,
  onChange,
  label,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
  label?: string;
}) {
  return (
    <button
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={() => onChange(!on)}
      className="relative h-[24px] w-[42px] shrink-0 rounded-full border transition-all duration-300"
      style={{
        background: on ? "linear-gradient(100deg,var(--accent1),var(--accent2))" : "rgba(255,255,255,.1)",
        borderColor: on ? "rgba(255,255,255,.24)" : "var(--line)",
        boxShadow: on ? "0 4px 14px -4px var(--accent2)" : "inset 0 1px 2px rgba(0,0,0,.2)",
      }}
    >
      <span
        className="absolute top-[3px] h-[16px] w-[16px] rounded-full bg-white shadow-md transition-all duration-300"
        style={{ insetInlineStart: on ? 23 : 3 }}
      />
    </button>
  );
}

export function Progress({ value, className = "", slim = false }: { value: number; className?: string; slim?: boolean }) {
  return (
    <div className={`progress-track w-full rounded-full ${slim ? "h-[3px]" : "h-[6px]"} ${className}`}>
      <div className="progress-fill h-full rounded-full" style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  );
}

export function Ring({ value, size = 44, color }: { value: number; size?: number; color?: string }) {
  const id = useMemo(() => `ring-${Math.random().toString(36).slice(2, 8)}`, []);
  const stroke = 4;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <span className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(255,255,255,.1)" strokeWidth={stroke} fill="none" />
        <defs>
          <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
            <stop stopColor={color ?? "var(--accent1)"} />
            <stop offset="1" stopColor="var(--accent3)" />
          </linearGradient>
        </defs>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={`url(#${id})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={c}
          strokeDashoffset={c - (c * Math.min(100, value)) / 100}
          style={{ transition: "stroke-dashoffset .7s cubic-bezier(.22,1,.36,1)" }}
        />
      </svg>
      <span className="absolute text-[10.5px] font-semibold">{Math.round(value)}%</span>
    </span>
  );
}

export function Sparkline({ data, color = "var(--accent2)", width = 86, height = 28 }: { data: number[]; color?: string; width?: number; height?: number }) {
  const max = Math.max(...data, 1);
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * width},${height - (v / max) * (height - 4) - 2}`);
  const id = useMemo(() => `spark-${Math.random().toString(36).slice(2, 8)}`, []);
  return (
    <svg width={width} height={height} className="overflow-visible">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.35" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={`0,${height} ${pts.join(" ")} ${width},${height}`} fill={`url(#${id})`} />
      <polyline points={pts.join(" ")} fill="none" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function SectionTitle({
  title,
  action,
  onAction,
  icon,
}: {
  title: string;
  action?: string;
  onAction?: () => void;
  icon?: React.ReactNode;
}) {
  return (
    <div className="mb-2.5 flex items-center justify-between px-0.5">
      <div className="flex items-center gap-1.5 text-[13.5px] font-semibold" style={{ color: "var(--text-1)" }}>
        {icon}
        {title}
      </div>
      {action && (
        <button onClick={onAction} className="press flex items-center gap-0.5 text-[11.5px] font-medium" style={{ color: "var(--accent2)" }}>
          {action}
          <ChevronDown size={12} className="rotate-90 rtl:rotate-90" />
        </button>
      )}
    </div>
  );
}

export function TypeIcon({ type, size = 16 }: { type: ContentType; size?: number }) {
  const color = contentTypeMeta[type].color;
  const common = { size, color, strokeWidth: 2 };
  if (type === "video") return <span style={{ color }}>▶</span>;
  if (type === "audio") return <Music2 {...common} />;
  if (type === "image") return <LayoutGrid {...common} />;
  return <FolderDown {...common} />;
}

/* ── Bottom sheet ───────────────────────────────────────── */
export function Sheet({
  open,
  onClose,
  title,
  subtitle,
  children,
  lang,
}: {
  open: boolean;
  onClose: () => void;
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  children: React.ReactNode;
  lang: Lang;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="absolute inset-0 z-[70] flex flex-col justify-end">
      <button aria-label="إغلاق الخلفية" onClick={onClose} className="fade-enter absolute inset-0 bg-black/55 backdrop-blur-[6px]" />
      <div className="sheet-enter relative flex max-h-[86%] flex-col overflow-hidden rounded-t-[32px] glass-deep noise">
        <div className="flex shrink-0 items-center justify-center pt-2.5">
          <span className="h-[4px] w-10 rounded-full bg-white/25" />
        </div>
        <div className="flex shrink-0 items-start justify-between gap-3 border-b px-5 pb-3 pt-2.5" style={{ borderColor: "var(--line)" }}>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 text-[15.5px] font-semibold" style={{ color: "var(--text-1)" }}>
              {title}
            </div>
            {subtitle && <div className="mt-1 line-clamp-1 text-[11px] muted">{subtitle}</div>}
          </div>
          <button
            onClick={onClose}
            aria-label="إغلاق"
            className="press flex h-8 w-8 shrink-0 items-center justify-center rounded-full border"
            style={{ background: "var(--glass-2)", borderColor: "var(--line)" }}
          >
            <X size={15} />
          </button>
        </div>
        <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 pb-7 pt-3">{children}</div>
        <span className="sr-only">{lang}</span>
      </div>
    </div>
  );
}

/* ── Toast ──────────────────────────────────────────────── */
export function Toast({
  message,
  detail,
  onClose,
  icon,
}: {
  message: string;
  detail?: string;
  onClose: () => void;
  icon?: React.ReactNode;
}) {
  useEffect(() => {
    const t = setTimeout(onClose, 3200);
    return () => clearTimeout(t);
  }, [message, onClose]);
  return (
    <div className="pointer-events-none absolute inset-x-4 bottom-[92px] z-[80] flex justify-center">
      <div className="toast-enter pointer-events-auto flex w-full max-w-[350px] items-center gap-3 rounded-[20px] glass-deep px-3.5 py-3">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[12px] accent-gradient text-white">
          {icon ?? <Check size={17} strokeWidth={2.6} />}
        </span>
        <div className="min-w-0 flex-1">
          <div className="truncate text-[12.5px] font-semibold" style={{ color: "var(--text-1)" }}>{message}</div>
          {detail && <div className="truncate text-[10.5px] muted">{detail}</div>}
        </div>
        <button onClick={onClose} className="press flex h-7 w-7 items-center justify-center rounded-full" style={{ background: "var(--glass-2)" }}>
          <X size={13} />
        </button>
      </div>
    </div>
  );
}

export function ShieldBadge({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-[#5ee1b0]/25 bg-[#5ee1b0]/10 px-2 py-[3px] text-[10.7px] font-medium text-[#69e7ba]">
      <ShieldCheck size={11} />
      {children}
    </span>
  );
}

export function BrandMark({ size = 38 }: { size?: number }) {
  return (
    <span
      className="relative flex shrink-0 items-center justify-center overflow-hidden rounded-[13px]"
      style={{
        width: size,
        height: size,
        background: "linear-gradient(145deg,var(--accent1),var(--accent2) 52%,var(--accent3))",
        boxShadow: "0 10px 26px -10px var(--accent2), inset 0 1px 0 rgba(255,255,255,.45)",
      }}
    >
      <Sparkles size={size * 0.45} color="white" strokeWidth={2.2} />
      <span className="absolute inset-0 rounded-[13px] ring-1 ring-inset ring-white/25" />
    </span>
  );
}

export { Wifi };
