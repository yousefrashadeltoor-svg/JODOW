pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
        maven(url = "https://jitpack.io")
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven(url = "https://jitpack.io")
    }
}

rootProject.name = "AuroraGet"

include(
    ":app",
    ":core:common",
    ":core:designsystem",
    ":core:network",
    ":core:database",
    ":engine:downloader",
    ":engine:extractors",
    ":engine:media",
    ":feature:analyzer",
    ":feature:home",
    ":feature:downloads",
    ":feature:browser",
    ":feature:converter",
    ":feature:compressor",
    ":feature:player",
    ":feature:files",
    ":feature:settings"
)
