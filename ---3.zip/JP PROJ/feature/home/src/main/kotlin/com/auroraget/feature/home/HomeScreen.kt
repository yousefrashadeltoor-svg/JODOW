package com.auroraget.feature.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import coil3.compose.AsyncImage
import com.auroraget.core.common.AnalysisResult
import com.auroraget.core.common.ByteFormatter
import com.auroraget.core.common.DownloadTask
import com.auroraget.core.common.MediaCategory
import com.auroraget.core.common.MediaFormatOption
import com.auroraget.core.common.SizePrecision
import com.auroraget.core.common.UrlNormalizer
import com.auroraget.core.designsystem.components.AuroraGlassBottomSheet
import com.auroraget.core.designsystem.components.AuroraGlassButton
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.AuroraGradientHeadline
import com.auroraget.core.designsystem.components.AuroraShimmerBox
import com.auroraget.core.designsystem.components.StreamingTextReveal
import com.auroraget.core.designsystem.icons.AuroraIcons
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.engine.downloader.SegmentedDownloadEngine
import com.auroraget.feature.analyzer.LinkAnalyzerPipeline
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID
import javax.inject.Inject

data class HomeUiState(
    val inputUrl: String = "",
    val detectedClipboardUrl: String? = null,
    val isAnalyzing: Boolean = false,
    val analysis: AnalysisResult? = null,
    val editableFileName: String = "",
    val activeSheetCategory: MediaCategory? = null,
    val exactByteTooltip: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val pipeline: LinkAnalyzerPipeline,
    private val downloadEngine: SegmentedDownloadEngine
) : ViewModel() {
    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    private var analyzeJob: Job? = null

    fun onUrlInputChanged(text: String) {
        _state.update { it.copy(inputUrl = text) }
        val extracted = UrlNormalizer.extractFirstUrl(text)
        analyzeJob?.cancel()
        if (extracted == null) {
            _state.update { it.copy(isAnalyzing = false, analysis = null) }
            return
        }
        // Strict 150ms Debounce + immediate cancellation of prior analysis
        analyzeJob = viewModelScope.launch {
            delay(150L)
            _state.update { it.copy(isAnalyzing = true) }
            pipeline.analyzeUrlStream(extracted).collect { result ->
                _state.update {
                    it.copy(
                        analysis = result,
                        editableFileName = result.suggestedFileName,
                        isAnalyzing = !result.isComplete
                    )
                }
            }
        }
    }

    fun onClipboardDetected(url: String) {
        if (url != _state.value.inputUrl) {
            _state.update { it.copy(detectedClipboardUrl = url) }
        }
    }

    fun acceptClipboardUrl() {
        val url = _state.value.detectedClipboardUrl ?: return
        _state.update { it.copy(detectedClipboardUrl = null) }
        onUrlInputChanged(url)
    }

    fun updateFileName(name: String) {
        _state.update { it.copy(editableFileName = name) }
    }

    fun openCategorySheet(category: MediaCategory) {
        _state.update { it.copy(activeSheetCategory = category) }
    }

    fun closeCategorySheet() {
        _state.update { it.copy(activeSheetCategory = null, exactByteTooltip = null) }
    }

    fun showExactBytes(option: MediaFormatOption) {
        _state.update { it.copy(exactByteTooltip = ByteFormatter.formatLongPressExact(option.size)) }
    }

    fun startFormatDownload(option: MediaFormatOption, outputDir: File) {
        val analysis = _state.value.analysis ?: return
        val fileName = UrlNormalizer.sanitizeFileName(
            _state.value.editableFileName.ifBlank { option.title },
            option.extension.lowercase()
        )
        val task = DownloadTask(
            id = UUID.randomUUID().toString(),
            url = option.downloadUrl,
            fileName = fileName,
            category = option.category,
            siteName = analysis.siteName,
            domain = analysis.domain,
            thumbnailUrl = analysis.thumbnailUrl,
            totalSize = option.size,
            requiresMerge = option.requiresAudioMerge,
            audioSourceUrl = option.audioTrackUrl,
            headers = option.headers
        )
        viewModelScope.launch {
            downloadEngine.enqueueAndStart(task, outputDir)
            closeCategorySheet()
        }
    }
}

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    hazeState: HazeState,
    outputDir: File,
    onOpenInBrowser: (String) -> Unit,
    onPreviewStream: (String, String) -> Unit,
    onOpenConverter: (MediaFormatOption) -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val palette = AuroraTheme.colors

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 24.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    AuroraGradientHeadline(text = "Aurora Get")
                    BasicText(
                        text = "Paste any media, audio, image, or direct link — lightning segmented analysis",
                        style = AuroraTheme.typography.bodyMedium.copy(color = palette.textSecondary)
                    )
                }
            }

            // Floating Clipboard Detection Chip (Non-intrusive)
            if (!state.detectedClipboardUrl.isNullOrBlank()) {
                item {
                    AuroraGlassSurface(
                        hazeState = hazeState,
                        shape = AuroraTheme.shapes.chip,
                        glowActive = true,
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.acceptClipboardUrl() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            BasicText(
                                text = "Link detected in clipboard — tap to analyze",
                                style = AuroraTheme.typography.labelLarge.copy(color = palette.accentStart)
                            )
                            BasicText(
                                text = "Paste",
                                style = AuroraTheme.typography.labelSmall.copy(color = palette.textPrimary)
                            )
                        }
                    }
                }
            }

            // Giant Gemini-Glowing Glass Link Input Box
            item {
                AuroraGlassSurface(
                    hazeState = hazeState,
                    shape = AuroraTheme.shapes.input,
                    glowActive = state.isAnalyzing || state.inputUrl.isNotBlank(),
                    elevated = true,
                    contentPadding = PaddingValues(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        BasicTextField(
                            value = state.inputUrl,
                            onValueChange = viewModel::onUrlInputChanged,
                            textStyle = AuroraTheme.typography.bodyLarge.copy(color = palette.textPrimary),
                            cursorBrush = SolidColor(palette.accentStart),
                            modifier = Modifier.fillMaxWidth(),
                            decorationBox = { innerTextField ->
                                if (state.inputUrl.isEmpty()) {
                                    BasicText(
                                        text = "https://youtube.com/... or paste multiple URLs",
                                        style = AuroraTheme.typography.bodyLarge.copy(color = palette.textMuted)
                                    )
                                }
                                innerTextField()
                            }
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            AuroraGlassButton(
                                text = "Analyze",
                                icon = AuroraIcons.Sparkles,
                                primaryGradient = true,
                                onClick = { viewModel.onUrlInputChanged(state.inputUrl) },
                                modifier = Modifier.weight(1f)
                            )
                            if (state.inputUrl.isNotBlank()) {
                                AuroraGlassButton(
                                    text = "Clear",
                                    onClick = { viewModel.onUrlInputChanged("") }
                                )
                            }
                        }
                    }
                }
            }

            // Progressive Info Card + Skeleton Shimmer
            val analysis = state.analysis
            if (analysis != null) {
                item {
                    AuroraGlassSurface(
                        hazeState = hazeState,
                        glowActive = !analysis.isComplete,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                AsyncImage(
                                    model = analysis.faviconUrl,
                                    contentDescription = analysis.siteName,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(palette.glassSurfaceStrong)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    BasicText(
                                        text = analysis.siteName,
                                        style = AuroraTheme.typography.labelLarge.copy(color = palette.textPrimary)
                                    )
                                    BasicText(
                                        text = analysis.domain,
                                        style = AuroraTheme.typography.labelSmall.copy(color = palette.textMuted)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(palette.accentStart.copy(alpha = 0.22f))
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    BasicText(
                                        text = analysis.primaryBadge,
                                        style = AuroraTheme.typography.labelSmall.copy(color = palette.textPrimary)
                                    )
                                }
                            }

                            if (!analysis.thumbnailUrl.isNullOrBlank()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp)
                                        .clip(RoundedCornerShape(22.dp))
                                        .clickable(enabled = !analysis.previewStreamUrl.isNullOrBlank()) {
                                            analysis.previewStreamUrl?.let { onPreviewStream(it, analysis.title) }
                                        }
                                ) {
                                    AsyncImage(
                                        model = analysis.thumbnailUrl,
                                        contentDescription = analysis.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            } else if (!analysis.isComplete) {
                                AuroraShimmerBox(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(140.dp)
                                )
                            }

                            StreamingTextReveal(
                                text = analysis.title,
                                style = AuroraTheme.typography.titleLarge.copy(color = palette.textPrimary)
                            )

                            // Editable File Name
                            BasicTextField(
                                value = state.editableFileName,
                                onValueChange = viewModel::updateFileName,
                                textStyle = AuroraTheme.typography.monoSmall.copy(color = palette.textSecondary),
                                cursorBrush = SolidColor(palette.accentStart),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(palette.glassSurfaceStrong)
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            )

                            // Exact Size & Duration Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                BasicText(
                                    text = ByteFormatter.formatDisplay(analysis.primarySize),
                                    style = AuroraTheme.typography.labelLarge.copy(
                                        color = if (analysis.primarySize.precision == SizePrecision.EXACT) palette.success else palette.warning
                                    )
                                )
                                if (analysis.durationSeconds != null) {
                                    BasicText(
                                        text = ByteFormatter.formatDuration(analysis.durationSeconds),
                                        style = AuroraTheme.typography.labelSmall.copy(color = palette.textSecondary)
                                    )
                                }
                            }

                            // DRM Warning (Zero Bypass)
                            if (analysis.drmBlockedReason != null) {
                                BasicText(
                                    text = analysis.drmBlockedReason,
                                    style = AuroraTheme.typography.bodyMedium.copy(color = palette.danger)
                                )
                            }

                            // Smart WebView Sniffer Fallback Suggestion
                            if (analysis.requiresWebViewSniffer && analysis.drmBlockedReason == null) {
                                AuroraGlassButton(
                                    text = "Open in Internal Browser to Sniff Media",
                                    icon = AuroraIcons.Globe,
                                    primaryGradient = true,
                                    onClick = { onOpenInBrowser(analysis.normalizedUrl) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                // THE 4 SMART BUTTONS (Section 4.4): ONLY shown when formats exist for that category!
                val categories = analysis.availableCategories
                if (categories.isNotEmpty()) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            categories.forEach { cat ->
                                val count = analysis.formatsFor(cat).size
                                val (label, icon) = when (cat) {
                                    MediaCategory.AUDIO -> "Audio" to AuroraIcons.AudioWave
                                    MediaCategory.IMAGE -> "Images" to AuroraIcons.PhotoFrame
                                    MediaCategory.VIDEO -> "Video" to AuroraIcons.VideoFilm
                                    MediaCategory.FILE -> "Files" to AuroraIcons.DocumentFile
                                }
                                AnimatedVisibility(
                                    visible = count > 0,
                                    enter = fadeIn() + scaleIn(spring(dampingRatio = Spring.DampingRatioMediumBouncy)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    AuroraGlassButton(
                                        text = label,
                                        icon = icon,
                                        badgeCount = count,
                                        onClick = { viewModel.openCategorySheet(cat) },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Glass Bottom Sheet Format Picker (Exact Size vs ≈ + Long-Press Exact Bytes + Auto-Merge)
        val sheetCategory = state.activeSheetCategory
        val sheetFormats = if (sheetCategory != null && state.analysis != null) {
            state.analysis!!.formatsFor(sheetCategory)
        } else emptyList()

        AuroraGlassBottomSheet(
            visible = sheetCategory != null,
            onDismiss = viewModel::closeCategorySheet,
            hazeState = hazeState,
            title = "${sheetCategory?.name ?: ""} Formats (${sheetFormats.size})"
        ) {
            if (state.exactByteTooltip != null) {
                BasicText(
                    text = state.exactByteTooltip!!,
                    style = AuroraTheme.typography.monoSmall.copy(color = palette.accentStart),
                    modifier = Modifier.padding(bottom = 10.dp)
                )
            }
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.height(340.dp)
            ) {
                items(sheetFormats, key = { it.id }) { option ->
                    AuroraGlassSurface(
                        shape = RoundedCornerShape(20.dp),
                        contentPadding = PaddingValues(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .pointerInput(option.id) {
                                detectTapGestures(
                                    onLongPress = { viewModel.showExactBytes(option) }
                                )
                            }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                BasicText(
                                    text = "${option.qualityLabel} • ${option.extension}" +
                                        (if (option.fps != null) " ${option.fps}fps" else "") +
                                        (if (option.isHdr) " HDR" else ""),
                                    style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary)
                                )
                                BasicText(
                                    text = buildString {
                                        append(option.codec.ifBlank { option.extension })
                                        if (option.bitrateKbps != null) append(" • ${option.bitrateKbps} kbps")
                                        if (option.requiresAudioMerge) append(" • Auto-Merge Audio (FFmpeg)")
                                    },
                                    style = AuroraTheme.typography.labelSmall.copy(color = palette.textSecondary)
                                )
                                BasicText(
                                    text = ByteFormatter.formatDisplay(option.size) +
                                        if (option.size.precision == SizePrecision.APPROXIMATE) " (Approx)" else " (Exact)",
                                    style = AuroraTheme.typography.monoSmall.copy(
                                        color = if (option.size.isExact) palette.success else palette.warning
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                AuroraGlassButton(
                                    text = "Download",
                                    primaryGradient = true,
                                    onClick = { viewModel.startFormatDownload(option, outputDir) }
                                )
                                AuroraGlassButton(
                                    text = "Convert",
                                    onClick = { onOpenConverter(option) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
