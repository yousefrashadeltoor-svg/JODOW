package com.auroraget.feature.converter

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.auroraget.core.designsystem.components.AuroraGlassButton
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.AuroraGradientHeadline
import com.auroraget.core.designsystem.components.AuroraProgressGlowBar
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.engine.media.ConversionSpec
import com.auroraget.engine.media.FFmpegMediaEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

data class ConverterUiState(
    val sourcePath: String = "",
    val selectedTarget: String = "MP3",
    val bitrateKbps: Int = 320,
    val streamCopyAudio: Boolean = true,
    val isConverting: Boolean = false,
    val statusMessage: String = "Select an output format to extract or transcode"
)

@HiltViewModel
class ConverterViewModel @Inject constructor(
    private val ffmpegMediaEngine: FFmpegMediaEngine
) : ViewModel() {
    private val _state = MutableStateFlow(ConverterUiState())
    val state: StateFlow<ConverterUiState> = _state.asStateFlow()

    val videoTargets = listOf("MP4", "MKV", "WEBM", "MOV", "AVI", "GIF")
    val audioTargets = listOf("MP3", "M4A", "OPUS", "OGG", "FLAC", "WAV")
    val imageTargets = listOf("JPG", "PNG", "WEBP", "AVIF")

    fun setSource(path: String) = _state.update { it.copy(sourcePath = path) }
    fun selectTarget(format: String) = _state.update { it.copy(selectedTarget = format) }
    fun selectBitrate(kbps: Int) = _state.update { it.copy(bitrateKbps = kbps) }

    fun runConversion() {
        val current = _state.value
        val src = File(current.sourcePath)
        if (!src.exists()) {
            _state.update { it.copy(statusMessage = "Choose a downloaded media file from Library first.") }
            return
        }
        val out = File(src.parentFile, "${src.nameWithoutExtension}_converted.${current.selectedTarget.lowercase()}")
        viewModelScope.launch {
            _state.update { it.copy(isConverting = true, statusMessage = "Converting to ${current.selectedTarget}...") }
            val result = ffmpegMediaEngine.convertMedia(
                ConversionSpec(
                    inputFile = src,
                    outputFile = out,
                    targetFormat = current.selectedTarget,
                    bitrateKbps = current.bitrateKbps,
                    streamCopyIfPossible = current.streamCopyAudio
                )
            )
            _state.update {
                it.copy(
                    isConverting = false,
                    statusMessage = result.fold(
                        onSuccess = { file -> "Converted successfully: ${file.name}" },
                        onFailure = { err -> "Conversion failed: ${err.message}" }
                    )
                )
            }
        }
    }
}

@Composable
fun ConverterScreen(
    viewModel: ConverterViewModel,
    hazeState: HazeState,
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val palette = AuroraTheme.colors

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 24.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { AuroraGradientHeadline(text = "Media Converter") }

        item {
            AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    BasicText(
                        text = "Audio Formats (Stream Copy when supported)",
                        style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary)
                    )
                    FormatChipRow(viewModel.audioTargets, state.selectedTarget, viewModel::selectTarget)

                    BasicText(
                        text = "Video Formats (Hardware MediaCodec + FFmpeg)",
                        style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary)
                    )
                    FormatChipRow(viewModel.videoTargets, state.selectedTarget, viewModel::selectTarget)

                    BasicText(
                        text = "Image Formats",
                        style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary)
                    )
                    FormatChipRow(viewModel.imageTargets, state.selectedTarget, viewModel::selectTarget)
                }
            }
        }

        item {
            AuroraGlassSurface(hazeState = hazeState, glowActive = state.isConverting, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    BasicText(
                        text = state.statusMessage,
                        style = AuroraTheme.typography.bodyMedium.copy(color = palette.textSecondary)
                    )
                    if (state.isConverting) {
                        AuroraProgressGlowBar(progress = 0.65f)
                    }
                    AuroraGlassButton(
                        text = "Convert to ${state.selectedTarget}",
                        primaryGradient = true,
                        enabled = !state.isConverting,
                        onClick = viewModel::runConversion,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun FormatChipRow(
    formats: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    val palette = AuroraTheme.colors
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        formats.forEach { fmt ->
            val isSelected = fmt == selected
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (isSelected) palette.accentStart.copy(alpha = 0.32f) else palette.glassSurfaceStrong)
                    .clickable { onSelect(fmt) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                BasicText(
                    text = fmt,
                    style = AuroraTheme.typography.labelLarge.copy(
                        color = if (isSelected) palette.textPrimary else palette.textSecondary
                    )
                )
            }
        }
    }
}
