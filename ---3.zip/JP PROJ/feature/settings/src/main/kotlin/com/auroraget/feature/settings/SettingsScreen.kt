package com.auroraget.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.auroraget.core.common.AppSettings
import com.auroraget.core.common.AuroraThemePreset
import com.auroraget.core.common.ByteFormatter
import com.auroraget.core.database.SettingsRepository
import com.auroraget.core.database.StatsDao
import com.auroraget.core.database.StatsEntity
import com.auroraget.core.designsystem.components.AuroraGlassButton
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.AuroraGradientHeadline
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.engine.extractors.YoutubeDlExtractor
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import javax.inject.Inject

data class SettingsUiState(
    val settings: AppSettings = AppSettings(),
    val stats: StatsEntity = StatsEntity(),
    val speedTestResult: String? = null,
    val ytDlpUpdateStatus: String? = null,
    val backupJsonPreview: String? = null
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    statsDao: StatsDao,
    private val youtubeDlExtractor: YoutubeDlExtractor,
    private val okHttpClient: OkHttpClient
) : ViewModel() {
    private val speedResult = MutableStateFlow<String?>(null)
    private val updateStatus = MutableStateFlow<String?>(null)
    private val backupPreview = MutableStateFlow<String?>(null)

    val state: StateFlow<SettingsUiState> = combine(
        settingsRepository.settingsFlow,
        statsDao.observeStats(),
        speedResult,
        updateStatus,
        backupPreview
    ) { settings, stats, speed, upd, backup ->
        SettingsUiState(settings, stats ?: StatsEntity(), speed, upd, backup)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState())

    fun setTheme(preset: AuroraThemePreset) {
        viewModelScope.launch { settingsRepository.update { it.copy(themePreset = preset) } }
    }

    fun toggleDarkMode() {
        viewModelScope.launch { settingsRepository.update { it.copy(darkMode = !it.darkMode) } }
    }

    fun toggleLanguage() {
        viewModelScope.launch {
            settingsRepository.update {
                it.copy(languageCode = if (it.languageCode == "ar") "en" else "ar")
            }
        }
    }

    fun setDefaultSegments(count: Int) {
        viewModelScope.launch { settingsRepository.update { it.copy(defaultSegments = count.coerceIn(8, 32)) } }
    }

    fun toggleDoh() {
        viewModelScope.launch { settingsRepository.update { it.copy(dohEnabled = !it.dohEnabled) } }
    }

    fun toggleAdBlock() {
        viewModelScope.launch { settingsRepository.update { it.copy(adBlockEnabled = !it.adBlockEnabled) } }
    }

    fun updateYtDlp() {
        viewModelScope.launch {
            updateStatus.value = "Updating yt-dlp..."
            val res = youtubeDlExtractor.updateYtDlpInBackground()
            updateStatus.value = res.fold(
                onSuccess = { "yt-dlp status: $it" },
                onFailure = { "Update failed: ${it.message}" }
            )
        }
    }

    fun runBuiltInSpeedTest() {
        viewModelScope.launch(Dispatchers.IO) {
            speedResult.value = "Measuring throughput..."
            val startNs = System.nanoTime()
            val bytes = runCatching {
                val req = Request.Builder().url("https://speed.cloudflare.com/__down?bytes=5000000").build()
                okHttpClient.newCall(req).execute().use { resp ->
                    resp.body?.bytes()?.size?.toLong() ?: 0L
                }
            }.getOrDefault(0L)
            val elapsedSec = ((System.nanoTime() - startNs) / 1_000_000_000.0).coerceAtLeast(0.05)
            val mbps = ((bytes * 8.0) / elapsedSec) / 1_000_000.0
            val recommended = when {
                mbps >= 150 -> 32
                mbps >= 50 -> 16
                else -> 8
            }
            speedResult.value = "${"%.1f".format(mbps)} Mbps • Recommended: $recommended segments"
            setDefaultSegments(recommended)
        }
    }

    fun exportBackup() {
        viewModelScope.launch {
            backupPreview.value = settingsRepository.exportJson(state.value.settings)
        }
    }
}

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    hazeState: HazeState,
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val palette = AuroraTheme.colors

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 24.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { AuroraGradientHeadline(text = "Settings & Privacy") }

        // Theme & Language Card
        item {
            AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    BasicText(
                        text = "Aurora Glass Themes",
                        style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary)
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AuroraThemePreset.entries.forEach { preset ->
                            val selected = preset == state.settings.themePreset
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(if (selected) palette.accentStart.copy(0.35f) else palette.glassSurfaceStrong)
                                    .clickable { viewModel.setTheme(preset) }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                BasicText(
                                    text = preset.name,
                                    style = AuroraTheme.typography.labelLarge.copy(color = palette.textPrimary)
                                )
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        AuroraGlassButton(
                            text = if (state.settings.darkMode) "AMOLED Dark" else "Light Glass",
                            onClick = viewModel::toggleDarkMode,
                            modifier = Modifier.weight(1f)
                        )
                        AuroraGlassButton(
                            text = if (state.settings.languageCode == "ar") "العربية (RTL)" else "English (LTR)",
                            primaryGradient = true,
                            onClick = viewModel::toggleLanguage,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Network, Speed Test & Engines
        item {
            AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    BasicText(
                        text = "Network & Download Engine (${state.settings.defaultSegments} Segments)",
                        style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AuroraGlassButton(
                            text = if (state.settings.dohEnabled) "DoH: ON" else "DoH: OFF",
                            onClick = viewModel::toggleDoh
                        )
                        AuroraGlassButton(
                            text = if (state.settings.adBlockEnabled) "AdBlock: ON" else "AdBlock: OFF",
                            onClick = viewModel::toggleAdBlock
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AuroraGlassButton(
                            text = "Run Speed Test",
                            primaryGradient = true,
                            onClick = viewModel::runBuiltInSpeedTest
                        )
                        AuroraGlassButton(
                            text = "Update yt-dlp",
                            onClick = viewModel::updateYtDlp
                        )
                    }
                    state.speedTestResult?.let {
                        BasicText(it, style = AuroraTheme.typography.monoSmall.copy(color = palette.success))
                    }
                    state.ytDlpUpdateStatus?.let {
                        BasicText(it, style = AuroraTheme.typography.monoSmall.copy(color = palette.info))
                    }
                }
            }
        }

        // Statistics & Backup
        item {
            AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    BasicText(
                        text = "Offline Statistics & Backup",
                        style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary)
                    )
                    BasicText(
                        text = "Downloaded: ${ByteFormatter.formatHumanBinary(state.stats.totalDownloadedBytes)} • Saved by Compressor: ${ByteFormatter.formatHumanBinary(state.stats.totalSavedByCompressionBytes)}",
                        style = AuroraTheme.typography.monoSmall.copy(color = palette.textSecondary)
                    )
                    AuroraGlassButton(text = "Export JSON Backup", onClick = viewModel::exportBackup)
                }
            }
        }

        // Legal & Privacy Notice (Section 1.11)
        item {
            AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    BasicText(
                        text = "Privacy & Copyright Responsibility",
                        style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary)
                    )
                    BasicText(
                        text = "Aurora Get is 100% offline-first with zero analytics or tracking. Users are solely responsible for respecting copyright laws and platform terms. DRM (Widevine/FairPlay/PlayReady) and paywalls are never bypassed.",
                        style = AuroraTheme.typography.bodyMedium.copy(color = palette.textSecondary)
                    )
                }
            }
        }
    }
}
