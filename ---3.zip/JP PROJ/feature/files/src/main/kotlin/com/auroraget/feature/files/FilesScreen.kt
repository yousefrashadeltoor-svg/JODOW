package com.auroraget.feature.files

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.auroraget.core.common.ByteFormatter
import com.auroraget.core.common.DownloadStatus
import com.auroraget.core.database.DownloadDao
import com.auroraget.core.database.DownloadEntity
import com.auroraget.core.database.VaultDao
import com.auroraget.core.database.VaultEntity
import com.auroraget.core.designsystem.components.AuroraGlassButton
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.AuroraGradientHeadline
import com.auroraget.core.designsystem.icons.AuroraIcons
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.engine.downloader.SegmentedDownloadEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Hardware-backed Android Keystore AES-256-GCM Vault encryptor protecting private downloads.
 */
@Singleton
class VaultEncryptionManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val keyAlias = "aurora_private_vault_aes256"

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(
                keyAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    suspend fun encryptToVault(sourceFile: File): File = withContext(Dispatchers.IO) {
        val vaultDir = File(context.filesDir, "private_vault").apply { mkdirs() }
        val outFile = File(vaultDir, "${UUID.randomUUID()}.agv")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        }
        val iv = cipher.iv
        val encryptedBytes = cipher.doFinal(sourceFile.readBytes())
        outFile.outputStream().use { fos ->
            fos.write(iv.size)
            fos.write(iv)
            fos.write(encryptedBytes)
        }
        outFile
    }

    suspend fun decryptFromVault(encryptedFile: File, targetFile: File): File = withContext(Dispatchers.IO) {
        val bytes = encryptedFile.readBytes()
        val ivLen = bytes[0].toInt()
        val iv = bytes.copyOfRange(1, 1 + ivLen)
        val payload = bytes.copyOfRange(1 + ivLen, bytes.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        }
        targetFile.writeBytes(cipher.doFinal(payload))
        targetFile
    }
}

data class FilesUiState(
    val completedFiles: List<DownloadEntity> = emptyList(),
    val vaultItems: List<VaultEntity> = emptyList(),
    val vaultUnlocked: Boolean = false,
    val lastVerifiedHash: String? = null
)

@HiltViewModel
class FilesViewModel @Inject constructor(
    downloadDao: DownloadDao,
    private val vaultDao: VaultDao,
    private val vaultEncryptor: VaultEncryptionManager,
    private val downloadEngine: SegmentedDownloadEngine
) : ViewModel() {
    private val vaultUnlocked = MutableStateFlow(false)
    private val verifiedHash = MutableStateFlow<String?>(null)

    val state: StateFlow<FilesUiState> = combine(
        downloadDao.observeAll(),
        vaultDao.observeAll(),
        vaultUnlocked,
        verifiedHash
    ) { all, vault, unlocked, hash ->
        FilesUiState(
            completedFiles = all.filter { it.status == DownloadStatus.COMPLETED.name },
            vaultItems = vault,
            vaultUnlocked = unlocked,
            lastVerifiedHash = hash
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), FilesUiState())

    fun unlockVault() { vaultUnlocked.value = true }
    fun lockVault() { vaultUnlocked.value = false }

    fun moveToVault(entity: DownloadEntity) {
        val file = File(entity.localFilePath ?: return)
        if (!file.exists()) return
        viewModelScope.launch {
            val sha = downloadEngine.computeFileHash(file, "SHA-256")
            val encFile = vaultEncryptor.encryptToVault(file)
            vaultDao.upsert(
                VaultEntity(
                    id = UUID.randomUUID().toString(),
                    displayName = entity.fileName,
                    encryptedPath = encFile.absolutePath,
                    mimeType = entity.category,
                    originalBytes = file.length(),
                    sha256 = sha,
                    addedAtMs = System.currentTimeMillis()
                )
            )
            file.delete()
        }
    }

    fun verifyHash(path: String) {
        viewModelScope.launch {
            val file = File(path)
            if (file.exists()) {
                val hash = downloadEngine.computeFileHash(file, "SHA-256")
                verifiedHash.value = "SHA-256: ${hash.take(24)}…"
            }
        }
    }
}

@Composable
fun FilesScreen(
    viewModel: FilesViewModel,
    hazeState: HazeState,
    onPlayFile: (String, String) -> Unit,
    onRequestBiometricUnlock: (() -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val palette = AuroraTheme.colors

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 24.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { AuroraGradientHeadline(text = "Library & Vault") }

        item {
            AuroraGlassSurface(hazeState = hazeState, glowActive = state.vaultUnlocked, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        BasicText(
                            text = "Private AES-256 Vault",
                            style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary)
                        )
                        BasicText(
                            text = "${state.vaultItems.size} encrypted items • Biometric protected",
                            style = AuroraTheme.typography.labelSmall.copy(color = palette.textSecondary)
                        )
                    }
                    AuroraGlassButton(
                        text = if (state.vaultUnlocked) "Lock" else "Unlock",
                        icon = AuroraIcons.LockVault,
                        primaryGradient = !state.vaultUnlocked,
                        onClick = {
                            if (state.vaultUnlocked) viewModel.lockVault()
                            else onRequestBiometricUnlock { viewModel.unlockVault() }
                        }
                    )
                }
            }
        }

        state.lastVerifiedHash?.let { hash ->
            item {
                BasicText(text = hash, style = AuroraTheme.typography.monoSmall.copy(color = palette.success))
            }
        }

        items(state.completedFiles, key = { it.id }) { file ->
            AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    BasicText(
                        text = file.fileName,
                        style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary)
                    )
                    BasicText(
                        text = "${file.category} • ${ByteFormatter.formatHumanBinary(file.totalBytes)}",
                        style = AuroraTheme.typography.monoSmall.copy(color = palette.textSecondary)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        file.localFilePath?.let { path ->
                            AuroraGlassButton(
                                text = "Play",
                                icon = AuroraIcons.PlayIcon,
                                primaryGradient = true,
                                onClick = { onPlayFile(path, file.fileName) }
                            )
                            AuroraGlassButton(
                                text = "SHA-256",
                                onClick = { viewModel.verifyHash(path) }
                            )
                        }
                        AuroraGlassButton(
                            text = "Vault",
                            icon = AuroraIcons.LockVault,
                            onClick = { viewModel.moveToVault(file) }
                        )
                    }
                }
            }
        }
    }
}
