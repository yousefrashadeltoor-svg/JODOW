package com.auroraget.feature.browser

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.auroraget.core.common.ByteFormatter
import com.auroraget.core.common.DownloadTask
import com.auroraget.core.common.FileSizeInfo
import com.auroraget.core.common.MediaCategory
import com.auroraget.core.common.MediaFormatOption
import com.auroraget.core.common.SizePrecision
import com.auroraget.core.common.UrlNormalizer
import com.auroraget.core.network.EncryptedCookieJar
import com.auroraget.core.network.ExactSizeResolver
import com.auroraget.core.designsystem.components.AuroraGlassBottomSheet
import com.auroraget.core.designsystem.components.AuroraGlassButton
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.icons.AuroraIcons
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.engine.downloader.SegmentedDownloadEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.io.File
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Native JNI bridge to brave/adblock-rust with automatic EasyList/EasyPrivacy fallback rules.
 * VERIFY: Compile brave/adblock-rust JNI wrapper to libaurora_adblock.so for native Rust speed.
 */
object NativeAdBlockBridge {
    val isLoaded: Boolean = runCatching {
        System.loadLibrary("aurora_adblock")
        true
    }.getOrDefault(false)

    external fun shouldBlockNative(url: String, sourceUrl: String, resourceType: String): Boolean
}

@Singleton
class AdBlockEngine @Inject constructor() {
    private val blockedHosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "taboola.com", "outbrain.com", "popads.net",
        "propellerads.com", "adnxs.com", "exoclick.com", "mgid.com",
        "scorecardresearch.com", "facebook.net", "hotjar.com", "analytics.tiktok.com"
    )
    private val allowlist = mutableSetOf<String>()

    fun isAllowedSite(host: String): Boolean = host in allowlist

    fun toggleAllowSite(host: String) {
        if (!allowlist.add(host)) allowlist.remove(host)
    }

    fun shouldBlock(requestUrl: String, pageHost: String, resourceType: String = "other"): Boolean {
        if (pageHost in allowlist) return false
        if (NativeAdBlockBridge.isLoaded) {
            return NativeAdBlockBridge.shouldBlockNative(requestUrl, "https://$pageHost", resourceType)
        }
        val reqHost = UrlNormalizer.extractDomain(requestUrl)
        return blockedHosts.any { reqHost == it || reqHost.endsWith(".$it") } ||
            requestUrl.contains("/popunder", true) ||
            requestUrl.contains("ad_banner", true) ||
            requestUrl.contains("fake-download-overlay", true)
    }

    /**
     * Cosmetic CSS filtering hiding ads, popups, and misleading fake Download button overlays.
     */
    val cosmeticFilterJs: String = """
        (function() {
            const style = document.createElement('style');
            style.textContent = `
                .ad-banner, .adsbox, [id*="google_ads"], [class*="popunder"],
                [class*="fake-download"], iframe[src*="doubleclick"], iframe[src*="adservice"] {
                    display: none !important; visibility: hidden !important; pointer-events: none !important;
                }
            `;
            document.documentElement.appendChild(style);
        })();
    """.trimIndent()
}

data class BrowserUiState(
    val currentUrl: String = "https://duckduckgo.com",
    val desktopMode: Boolean = false,
    val privateMode: Boolean = false,
    val adBlockEnabled: Boolean = true,
    val blockedCount: Int = 0,
    val cloudflareSessionSynced: Boolean = false,
    val sniffedMedia: List<MediaFormatOption> = emptyList(),
    val showSnifferSheet: Boolean = false
)

@HiltViewModel
class BrowserViewModel @Inject constructor(
    val adBlockEngine: AdBlockEngine,
    val cookieJar: EncryptedCookieJar,
    private val exactSizeResolver: ExactSizeResolver,
    private val downloadEngine: SegmentedDownloadEngine
) : ViewModel() {
    private val _state = MutableStateFlow(BrowserUiState())
    val state: StateFlow<BrowserUiState> = _state.asStateFlow()

    fun navigateTo(rawUrl: String) {
        _state.update { it.copy(currentUrl = UrlNormalizer.normalize(rawUrl)) }
    }

    fun toggleDesktopMode() = _state.update { it.copy(desktopMode = !it.desktopMode) }
    fun togglePrivateMode() = _state.update { it.copy(privateMode = !it.privateMode) }
    fun toggleSnifferSheet(show: Boolean) = _state.update { it.copy(showSnifferSheet = show) }
    fun incrementBlocked() = _state.update { it.copy(blockedCount = it.blockedCount + 1) }

    /**
     * Legitimate Cloudflare/Turnstile/JS Challenge session sync:
     * Reads cf_clearance and active session cookies solved inside the real WebView
     * and transfers them + User-Agent into Aurora's EncryptedCookieJar for OkHttp/Cronet.
     */
    fun syncWebViewCookies(url: String) {
        val rawCookies = CookieManager.getInstance().getCookie(url) ?: return
        cookieJar.importWebViewCookieString(url, rawCookies)
        if (rawCookies.contains("cf_clearance")) {
            _state.update { it.copy(cloudflareSessionSynced = true) }
        }
    }

    fun onMediaSniffed(
        url: String,
        mimeType: String?,
        referer: String,
        userAgent: String
    ) {
        if (url.startsWith("data:") || _state.value.sniffedMedia.any { it.downloadUrl == url }) return
        val lower = url.substringBefore("?").lowercase()
        val category = when {
            lower.endsWith(".m3u8") || lower.endsWith(".mpd") || lower.endsWith(".mp4") ||
                lower.endsWith(".webm") || mimeType?.startsWith("video/") == true -> MediaCategory.VIDEO
            lower.endsWith(".mp3") || lower.endsWith(".m4a") || lower.endsWith(".opus") ||
                lower.endsWith(".flac") || mimeType?.startsWith("audio/") == true -> MediaCategory.AUDIO
            lower.endsWith(".jpg") || lower.endsWith(".png") || lower.endsWith(".webp") ||
                mimeType?.startsWith("image/") == true -> MediaCategory.IMAGE
            lower.endsWith(".zip") || lower.endsWith(".apk") || lower.endsWith(".pdf") -> MediaCategory.FILE
            else -> return
        }

        val cookies = CookieManager.getInstance().getCookie(referer).orEmpty()
        val headers = buildMap {
            put("User-Agent", userAgent)
            put("Referer", referer)
            if (cookies.isNotBlank()) put("Cookie", cookies)
        }

        viewModelScope.launch(Dispatchers.IO) {
            val probe = if (!url.startsWith("blob:")) exactSizeResolver.probeExactMetadata(url, headers) else null
            val ext = lower.substringAfterLast(".", "bin").uppercase()
            val option = MediaFormatOption(
                id = "sniff_${url.hashCode()}",
                category = category,
                title = probe?.contentDispositionFileName ?: url.substringBefore("?").substringAfterLast("/").ifBlank { "Sniffed Media" },
                qualityLabel = if (lower.endsWith(".m3u8")) "HLS Stream" else if (lower.endsWith(".mpd")) "DASH Stream" else ext,
                extension = ext,
                codec = probe?.contentType ?: mimeType ?: ext,
                downloadUrl = url,
                size = probe?.sizeInfo ?: FileSizeInfo(0L, SizePrecision.UNKNOWN),
                headers = headers,
                isHlsOrDash = lower.endsWith(".m3u8") || lower.endsWith(".mpd")
            )
            _state.update { it.copy(sniffedMedia = (listOf(option) + it.sniffedMedia).distinctBy { m -> m.downloadUrl }) }
        }
    }

    fun downloadSniffed(option: MediaFormatOption, outputDir: File) {
        val task = DownloadTask(
            id = UUID.randomUUID().toString(),
            url = option.downloadUrl,
            fileName = UrlNormalizer.sanitizeFileName(option.title, option.extension.lowercase()),
            category = option.category,
            siteName = UrlNormalizer.extractDomain(_state.value.currentUrl),
            domain = UrlNormalizer.extractDomain(_state.value.currentUrl),
            totalSize = option.size,
            headers = option.headers
        )
        viewModelScope.launch {
            downloadEngine.enqueueAndStart(task, outputDir)
            toggleSnifferSheet(false)
        }
    }
}

private const val MEDIA_SNIFFER_INJECT_JS = """
(function() {
    if (window.__auroraSnifferInstalled) return;
    window.__auroraSnifferInstalled = true;
    const report = (u, m) => {
        if (u && typeof u === 'string' && window.AuroraSniffer) {
            window.AuroraSniffer.onResourceDetected(u, m || '');
        }
    };
    const origFetch = window.fetch;
    window.fetch = function(input, init) {
        const u = typeof input === 'string' ? input : (input && input.url);
        if (u && /\.(m3u8|mpd|mp4|webm|mp3|m4a|zip|apk|pdf)(\?|$)/i.test(u)) report(u, '');
        return origFetch.apply(this, arguments);
    };
    const origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
        if (url && /\.(m3u8|mpd|mp4|webm|mp3|m4a)(\?|$)/i.test(url)) report(url, '');
        return origOpen.apply(this, arguments);
    };
    const scanDom = () => {
        document.querySelectorAll('video, audio, source').forEach(el => {
            if (el.src) report(el.src, el.tagName === 'AUDIO' ? 'audio/mpeg' : 'video/mp4');
            if (el.currentSrc) report(el.currentSrc, 'video/mp4');
        });
    };
    setInterval(scanDom, 1500);
})();
"""

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(
    viewModel: BrowserViewModel,
    hazeState: HazeState,
    outputDir: File,
    initialUrl: String? = null,
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val palette = AuroraTheme.colors
    var addressInput by remember(state.currentUrl) { mutableStateOf(initialUrl ?: state.currentUrl) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Glass Browser Toolbar
            AuroraGlassSurface(
                hazeState = hazeState,
                shape = RoundedCornerShape(24.dp),
                contentPadding = PaddingValues(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BasicTextField(
                            value = addressInput,
                            onValueChange = { addressInput = it },
                            textStyle = AuroraTheme.typography.bodyMedium.copy(color = palette.textPrimary),
                            cursorBrush = SolidColor(palette.accentStart),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(palette.glassSurfaceStrong)
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                        AuroraGlassButton(
                            text = "Go",
                            primaryGradient = true,
                            onClick = {
                                viewModel.navigateTo(addressInput)
                                webViewRef?.loadUrl(UrlNormalizer.normalize(addressInput))
                            }
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            BasicText(
                                text = "◀",
                                style = AuroraTheme.typography.labelLarge.copy(color = palette.textPrimary),
                                modifier = Modifier.clickable { webViewRef?.goBack() }.padding(6.dp)
                            )
                            BasicText(
                                text = "▶",
                                style = AuroraTheme.typography.labelLarge.copy(color = palette.textPrimary),
                                modifier = Modifier.clickable { webViewRef?.goForward() }.padding(6.dp)
                            )
                            BasicText(
                                text = "↻",
                                style = AuroraTheme.typography.labelLarge.copy(color = palette.textPrimary),
                                modifier = Modifier.clickable { webViewRef?.reload() }.padding(6.dp)
                            )
                            BasicText(
                                text = if (state.desktopMode) "Desktop" else "Mobile",
                                style = AuroraTheme.typography.labelSmall.copy(color = palette.accentStart),
                                modifier = Modifier.clickable { viewModel.toggleDesktopMode() }.padding(6.dp)
                            )
                        }
                        BasicText(
                            text = "Blocked: ${state.blockedCount}" +
                                if (state.cloudflareSessionSynced) " • CF OK" else "",
                            style = AuroraTheme.typography.monoSmall.copy(color = palette.success)
                        )
                    }
                }
            }

            // Real WebView with Media Sniffer + AdBlock + Cloudflare Cookie Handoff
            AndroidView(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        addJavascriptInterface(
                            object {
                                @JavascriptInterface
                                fun onResourceDetected(url: String, mime: String) {
                                    viewModel.onMediaSniffed(
                                        url = url,
                                        mimeType = mime.ifBlank { null },
                                        referer = state.currentUrl,
                                        userAgent = settings.userAgentString
                                    )
                                }
                            },
                            "AuroraSniffer"
                        )
                        setDownloadListener(DownloadListener { url, userAgent, _, mimetype, _ ->
                            viewModel.onMediaSniffed(url, mimetype, state.currentUrl, userAgent)
                            viewModel.toggleSnifferSheet(true)
                        })
                        webChromeClient = WebChromeClient()
                        webViewClient = object : WebViewClient() {
                            override fun shouldInterceptRequest(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): WebResourceResponse? {
                                val reqUrl = request?.url?.toString() ?: return null
                                val pageHost = UrlNormalizer.extractDomain(state.currentUrl)
                                if (state.adBlockEnabled && viewModel.adBlockEngine.shouldBlock(reqUrl, pageHost)) {
                                    viewModel.incrementBlocked()
                                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                                }
                                viewModel.onMediaSniffed(
                                    url = reqUrl,
                                    mimeType = request.requestHeaders["Accept"],
                                    referer = state.currentUrl,
                                    userAgent = settings.userAgentString
                                )
                                return super.shouldInterceptRequest(view, request)
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                if (!url.isNullOrBlank()) {
                                    viewModel.syncWebViewCookies(url)
                                    view?.evaluateJavascript(MEDIA_SNIFFER_INJECT_JS, null)
                                    if (state.adBlockEnabled) {
                                        view?.evaluateJavascript(viewModel.adBlockEngine.cosmeticFilterJs, null)
                                    }
                                }
                            }
                        }
                        loadUrl(initialUrl ?: state.currentUrl)
                        webViewRef = this
                    }
                }
            )
        }

        // Floating Glass Sniffer FAB with Detected Media Badge
        AuroraGlassButton(
            text = "Sniffed Media",
            icon = AuroraIcons.DownloadArrow,
            badgeCount = state.sniffedMedia.size,
            primaryGradient = state.sniffedMedia.isNotEmpty(),
            onClick = { viewModel.toggleSnifferSheet(true) },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 104.dp)
        )

        AuroraGlassBottomSheet(
            visible = state.showSnifferSheet,
            onDismiss = { viewModel.toggleSnifferSheet(false) },
            hazeState = hazeState,
            title = "Sniffed Resources (${state.sniffedMedia.size})"
        ) {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.height(300.dp)
            ) {
                items(state.sniffedMedia, key = { it.id }) { item ->
                    AuroraGlassSurface(
                        shape = RoundedCornerShape(18.dp),
                        contentPadding = PaddingValues(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                BasicText(
                                    text = item.title,
                                    style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary)
                                )
                                BasicText(
                                    text = "${item.category.name} • ${item.extension} • ${ByteFormatter.formatDisplay(item.size)}",
                                    style = AuroraTheme.typography.monoSmall.copy(color = palette.textSecondary)
                                )
                            }
                            AuroraGlassButton(
                                text = "Get",
                                primaryGradient = true,
                                onClick = { viewModel.downloadSniffed(item, outputDir) }
                            )
                        }
                    }
                }
            }
        }
    }
}
