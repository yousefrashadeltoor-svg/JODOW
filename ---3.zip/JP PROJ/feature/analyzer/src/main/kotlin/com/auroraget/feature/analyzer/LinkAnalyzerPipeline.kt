package com.auroraget.feature.analyzer

import android.util.LruCache
import com.auroraget.core.common.AnalysisResult
import com.auroraget.core.common.DrmProtectionGuard
import com.auroraget.core.common.FileSizeInfo
import com.auroraget.core.common.SizePrecision
import com.auroraget.core.common.UrlNormalizer
import com.auroraget.core.database.AnalysisCacheDao
import com.auroraget.core.database.AnalysisCacheEntity
import com.auroraget.core.network.ExactSizeResolver
import com.auroraget.engine.extractors.FastPathNativeExtractor
import com.auroraget.engine.extractors.YoutubeDlExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Parallel Multi-Stage Link Analyzer Pipeline (Section 4.2):
 * Stage 0 (<50ms): URL cleanup, normalization, domain, cached logo, preconnect
 * Stage 1 (<300ms): HEAD / Range 0-0, exact size, High-Res Favicon, OpenGraph metadata
 * Stage 2 (<1.5s): Native Fast-Path extractors (direct files + popular sites)
 * Stage 3 (<=4s): Full yt-dlp extraction (all resolutions, codecs, audio, thumbnails, subtitles)
 * Stage 4 (fallback): Jsoup/Regex scrape or smart suggestion to open internal WebView Sniffer
 */
@Singleton
class LinkAnalyzerPipeline @Inject constructor(
    private val exactSizeResolver: ExactSizeResolver,
    private val fastPathExtractor: FastPathNativeExtractor,
    private val youtubeDlExtractor: YoutubeDlExtractor,
    private val analysisCacheDao: AnalysisCacheDao
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val memoryCache = LruCache<String, AnalysisResult>(64)
    private val cacheTtlMs = 20 * 60_000L

    fun analyzeUrlStream(rawUrl: String): Flow<AnalysisResult> = channelFlow {
        val normalized = UrlNormalizer.normalize(rawUrl)
        val domain = UrlNormalizer.extractDomain(normalized)
        val now = System.currentTimeMillis()

        // Check in-memory LRU and Room TTL cache first
        memoryCache.get(normalized)?.takeIf { now - it.analyzedAtEpochMs < cacheTtlMs }?.let { cached ->
            send(cached)
            return@channelFlow
        }
        analysisCacheDao.getValid(normalized, now)?.let { entity ->
            runCatching { json.decodeFromString<AnalysisResult>(entity.payloadJson) }.getOrNull()?.let { cached ->
                memoryCache.put(normalized, cached)
                send(cached)
                return@channelFlow
            }
        }

        // Stage 0: Instant (<50ms) normalization + preconnect
        var current = AnalysisResult(
            originalUrl = rawUrl,
            normalizedUrl = normalized,
            domain = domain,
            siteName = domain.substringBefore(".").replaceFirstChar { it.uppercase() },
            faviconUrl = "https://$domain/favicon.ico",
            title = domain,
            suggestedFileName = UrlNormalizer.sanitizeFileName(domain),
            thumbnailUrl = null,
            previewStreamUrl = null,
            primaryBadge = "Analyzing",
            stageCompleted = 0,
            isComplete = false,
            drmBlockedReason = DrmProtectionGuard.detectDrmReason(normalized)
        )
        send(current)

        if (current.drmBlockedReason != null) {
            send(current.copy(isComplete = true, primaryBadge = "DRM Protected"))
            return@channelFlow
        }

        coroutineScope {
            // Preconnect TCP/TLS + DNS cache warmup immediately
            launch { exactSizeResolver.preconnect(normalized) }

            val resolvedUrl = fastPathExtractor.resolveRedirects(normalized)

            // Stage 1 (<300ms): Parallel HEAD/Range probe + OpenGraph/Favicon fetch
            val directDeferred = async { runCatching { fastPathExtractor.tryDirectLinkFastPath(resolvedUrl) }.getOrNull() }
            val htmlDeferred = async { runCatching { fastPathExtractor.scrapeHtmlMetadataAndMedia(resolvedUrl) }.getOrNull() }

            val directBundle = directDeferred.await()
            if (directBundle != null && directBundle.formats.isNotEmpty()) {
                val primary = directBundle.formats.first()
                current = current.copy(
                    normalizedUrl = resolvedUrl,
                    title = directBundle.title,
                    suggestedFileName = UrlNormalizer.sanitizeFileName(directBundle.title),
                    thumbnailUrl = directBundle.thumbnailUrl,
                    previewStreamUrl = directBundle.previewStreamUrl,
                    primaryBadge = primary.category.name,
                    primarySize = primary.size,
                    formats = directBundle.formats,
                    stageCompleted = 2,
                    isComplete = true
                )
                cacheResult(current)
                send(current)
                return@coroutineScope
            }

            val htmlMeta = htmlDeferred.await()
            if (htmlMeta != null) {
                current = current.copy(
                    normalizedUrl = resolvedUrl,
                    siteName = htmlMeta.siteName,
                    faviconUrl = htmlMeta.faviconUrl ?: current.faviconUrl,
                    title = htmlMeta.title,
                    suggestedFileName = UrlNormalizer.sanitizeFileName(htmlMeta.title),
                    thumbnailUrl = htmlMeta.thumbnailUrl,
                    primaryBadge = if (htmlMeta.discoveredFormats.isNotEmpty()) {
                        htmlMeta.discoveredFormats.first().category.name
                    } else "Web Media",
                    formats = htmlMeta.discoveredFormats,
                    drmBlockedReason = htmlMeta.drmBlockedReason,
                    stageCompleted = 1
                )
                send(current)
                if (htmlMeta.drmBlockedReason != null) {
                    send(current.copy(isComplete = true))
                    return@coroutineScope
                }
            }

            // Stage 3: Full yt-dlp extraction for 1800+ supported platforms
            val ytdlpResult = runCatching { youtubeDlExtractor.extractAllFormats(resolvedUrl) }
                .onFailure { Timber.d(it, "yt-dlp skipped or unsupported for $resolvedUrl") }
                .getOrNull()

            if (ytdlpResult != null) {
                if (ytdlpResult.drmBlockedReason != null) {
                    current = current.copy(
                        drmBlockedReason = ytdlpResult.drmBlockedReason,
                        stageCompleted = 3,
                        isComplete = true
                    )
                    send(current)
                    return@coroutineScope
                }

                // Resolve exact sizes for thumbnails or formats missing exact byte size
                val mergedFormats = (ytdlpResult.formats + current.formats).distinctBy { it.id }
                val primarySize = mergedFormats.firstOrNull { it.size.isExact }?.size
                    ?: mergedFormats.firstOrNull { it.size.isKnown }?.size
                    ?: FileSizeInfo(0L, SizePrecision.UNKNOWN)

                current = current.copy(
                    title = ytdlpResult.title.ifBlank { current.title },
                    suggestedFileName = UrlNormalizer.sanitizeFileName(ytdlpResult.title.ifBlank { current.title }),
                    author = ytdlpResult.author,
                    publishedDate = ytdlpResult.publishedDate,
                    durationSeconds = ytdlpResult.durationSeconds,
                    thumbnailUrl = ytdlpResult.thumbnailUrl ?: current.thumbnailUrl,
                    previewStreamUrl = ytdlpResult.previewStreamUrl ?: current.previewStreamUrl,
                    primaryBadge = mergedFormats.firstOrNull()?.category?.name ?: "Media",
                    primarySize = primarySize,
                    formats = mergedFormats,
                    stageCompleted = 3,
                    isComplete = true,
                    requiresWebViewSniffer = mergedFormats.isEmpty()
                )
            } else {
                // Stage 4 Fallback: Suggest internal WebView Sniffer if no direct media was extracted
                current = current.copy(
                    stageCompleted = 4,
                    isComplete = true,
                    requiresWebViewSniffer = current.formats.isEmpty()
                )
            }

            cacheResult(current)
            send(current)
        }
    }.flowOn(Dispatchers.IO)

    private suspend fun cacheResult(result: AnalysisResult) {
        if (result.formats.isEmpty()) return
        memoryCache.put(result.normalizedUrl, result)
        val now = System.currentTimeMillis()
        analysisCacheDao.upsert(
            AnalysisCacheEntity(
                normalizedUrl = result.normalizedUrl,
                payloadJson = json.encodeToString(result),
                cachedAtMs = now,
                expiresAtMs = now + cacheTtlMs
            )
        )
    }
}
