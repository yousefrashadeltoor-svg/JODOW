package com.auroraget.feature.downloads

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.auroraget.core.common.ByteFormatter
import com.auroraget.core.common.DownloadStatus
import com.auroraget.core.common.FileSizeInfo
import com.auroraget.core.common.SizePrecision
import com.auroraget.core.database.DownloadDao
import com.auroraget.core.database.DownloadEntity
import com.auroraget.core.designsystem.components.AuroraGlassButton
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.AuroraGradientHeadline
import com.auroraget.core.designsystem.components.AuroraProgressGlowBar
import com.auroraget.core.designsystem.components.AuroraSpeedSparkline
import com.auroraget.core.designsystem.icons.AuroraIcons
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.engine.downloader.SegmentedDownloadEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class DownloadTabFilter { ALL, ACTIVE, QUEUED, COMPLETED, FAILED }

data class DownloadsUiState(
    val selectedTab: DownloadTabFilter = DownloadTabFilter.ALL,
    val items: List<DownloadEntity> = emptyList(),
    val metrics: Map<String, Pair<Long, List<Long>>> = emptyMap()
)

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    private val downloadDao: DownloadDao,
    private val engine: SegmentedDownloadEngine
) : ViewModel() {
    private val selectedTab = MutableStateFlow(DownloadTabFilter.ALL)

    val state: StateFlow<DownloadsUiState> = combine(
        selectedTab,
        downloadDao.observeAll(),
        engine.liveMetrics
    ) { tab, all, metrics ->
        val filtered = when (tab) {
            DownloadTabFilter.ALL -> all
            DownloadTabFilter.ACTIVE -> all.filter { it.status == DownloadStatus.DOWNLOADING.name || it.status == DownloadStatus.MERGING.name }
            DownloadTabFilter.QUEUED -> all.filter { it.status == DownloadStatus.QUEUED.name || it.status == DownloadStatus.PAUSED.name }
            DownloadTabFilter.COMPLETED -> all.filter { it.status == DownloadStatus.COMPLETED.name }
            DownloadTabFilter.FAILED -> all.filter { it.status == DownloadStatus.FAILED.name }
        }
        DownloadsUiState(tab, filtered, metrics)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DownloadsUiState())

    fun selectTab(tab: DownloadTabFilter) { selectedTab.value = tab }
    fun resume(id: String) = engine.startOrResume(id)
    fun pause(id: String) { viewModelScope.launch { engine.pause(id) } }
    fun cancel(id: String) { viewModelScope.launch { engine.cancelAndCleanup(id) } }
    fun delete(id: String) { viewModelScope.launch { downloadDao.deleteById(id) } }
    fun bumpPriority(id: String, newPriority: Int) {
        viewModelScope.launch { downloadDao.updatePriority(id, newPriority) }
    }
}

@Composable
fun DownloadsScreen(
    viewModel: DownloadsViewModel,
    hazeState: HazeState,
    onCompressFile: (String) -> Unit,
    onConvertFile: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val palette = AuroraTheme.colors

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 24.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { AuroraGradientHeadline(text = "Download Manager") }

        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DownloadTabFilter.entries.forEach { tab ->
                    val selected = tab == state.selectedTab
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (selected) palette.accentStart.copy(alpha = 0.3f) else palette.glassSurface)
                            .clickable { viewModel.selectTab(tab) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        BasicText(
                            text = tab.name,
                            style = AuroraTheme.typography.labelLarge.copy(
                                color = if (selected) palette.textPrimary else palette.textSecondary
                            )
                        )
                    }
                }
            }
        }

        items(state.items, key = { it.id }) { item ->
            val speedPair = state.metrics[item.id]
            val speed = speedPair?.first ?: 0L
            val history = speedPair?.second ?: emptyList()
            val progress = if (item.totalBytes > 0L) item.downloadedBytes.toFloat() / item.totalBytes.toFloat() else 0f

            AuroraGlassSurface(
                hazeState = hazeState,
                glowActive = item.status == DownloadStatus.DOWNLOADING.name,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            BasicText(
                                text = item.fileName,
                                style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary)
                            )
                            BasicText(
                                text = "${item.siteName} • ${item.maxConnections} Segments • ${item.status}",
                                style = AuroraTheme.typography.labelSmall.copy(color = palette.textSecondary)
                            )
                        }
                        BasicText(
                            text = ByteFormatter.formatSpeed(speed),
                            style = AuroraTheme.typography.monoSmall.copy(color = palette.accentStart)
                        )
                    }

                    AuroraProgressGlowBar(progress = progress)

                    if (history.size >= 2) {
                        AuroraSpeedSparkline(
                            samples = history,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(28.dp)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val sizeInfo = FileSizeInfo(
                            item.totalBytes,
                            runCatching { SizePrecision.valueOf(item.sizePrecision) }.getOrDefault(SizePrecision.EXACT)
                        )
                        BasicText(
                            text = "${ByteFormatter.formatHumanBinary(item.downloadedBytes)} / ${ByteFormatter.formatDisplay(sizeInfo)}",
                            style = AuroraTheme.typography.monoSmall.copy(color = palette.textSecondary)
                        )
                        BasicText(
                            text = "${(progress * 100).toInt()}%",
                            style = AuroraTheme.typography.labelLarge.copy(color = palette.textPrimary)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (item.status == DownloadStatus.DOWNLOADING.name) {
                            AuroraGlassButton(
                                text = "Pause",
                                icon = AuroraIcons.PauseIcon,
                                onClick = { viewModel.pause(item.id) }
                            )
                        } else if (item.status != DownloadStatus.COMPLETED.name) {
                            AuroraGlassButton(
                                text = "Resume",
                                icon = AuroraIcons.PlayIcon,
                                primaryGradient = true,
                                onClick = { viewModel.resume(item.id) }
                            )
                        } else if (item.localFilePath != null) {
                            AuroraGlassButton(
                                text = "Compress",
                                icon = AuroraIcons.CompressArrows,
                                onClick = { onCompressFile(item.localFilePath) }
                            )
                            AuroraGlassButton(
                                text = "Convert",
                                onClick = { onConvertFile(item.localFilePath) }
                            )
                        }
                        AuroraGlassButton(
                            text = "Delete",
                            onClick = { viewModel.delete(item.id) }
                        )
                    }
                }
            }
        }
    }
}
