package com.auroraget.feature.compressor

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.auroraget.core.common.ByteFormatter
import com.auroraget.core.common.CompressionMode
import com.auroraget.core.database.StatsDao
import com.auroraget.core.database.StatsEntity
import com.auroraget.core.designsystem.components.AuroraGlassButton
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.AuroraGradientHeadline
import com.auroraget.core.designsystem.icons.AuroraIcons
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.engine.media.CompressionReport
import com.auroraget.engine.media.SmartCompressorEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

data class CompressorUiState(
    val sourceFilePath: String = "",
    val mode: CompressionMode = CompressionMode.LOSSLESS,
    val isCompressing: Boolean = false,
    val report: CompressionReport? = null
)

@HiltViewModel
class CompressorViewModel @Inject constructor(
    private val compressorEngine: SmartCompressorEngine,
    private val statsDao: StatsDao
) : ViewModel() {
    private val _state = MutableStateFlow(CompressorUiState())
    val state: StateFlow<CompressorUiState> = _state.asStateFlow()

    fun setSourceFile(path: String) = _state.update { it.copy(sourceFilePath = path, report = null) }
    fun selectMode(mode: CompressionMode) = _state.update { it.copy(mode = mode) }

    fun compressNow() {
        val path = _state.value.sourceFilePath
        val file = File(path)
        if (!file.exists()) return
        viewModelScope.launch {
            _state.update { it.copy(isCompressing = true) }
            val report = compressorEngine.compress(file, _state.value.mode)
            if (report.effectivelyReduced) {
                val stats = statsDao.getOnce() ?: StatsEntity()
                statsDao.upsert(stats.copy(totalSavedByCompressionBytes = stats.totalSavedByCompressionBytes + report.savedBytes))
            }
            _state.update { it.copy(isCompressing = false, report = report) }
        }
    }
}

@Composable
fun CompressorScreen(
    viewModel: CompressorViewModel,
    hazeState: HazeState,
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val palette = AuroraTheme.colors
    var splitFraction by remember { mutableFloatStateOf(0.5f) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 24.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { AuroraGradientHeadline(text = "Smart Compressor") }

        item {
            AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    BasicText(
                        text = "Original file is never overwritten without your explicit confirmation.",
                        style = AuroraTheme.typography.bodyMedium.copy(color = palette.textSecondary)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        AuroraGlassButton(
                            text = "Lossless",
                            primaryGradient = state.mode == CompressionMode.LOSSLESS,
                            onClick = { viewModel.selectMode(CompressionMode.LOSSLESS) },
                            modifier = Modifier.weight(1f)
                        )
                        AuroraGlassButton(
                            text = "Transparent (SSIM ≥95%)",
                            primaryGradient = state.mode == CompressionMode.VISUALLY_TRANSPARENT,
                            onClick = { viewModel.selectMode(CompressionMode.VISUALLY_TRANSPARENT) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    AuroraGlassButton(
                        text = if (state.isCompressing) "Optimizing..." else "Compress File",
                        icon = AuroraIcons.CompressArrows,
                        primaryGradient = true,
                        enabled = !state.isCompressing,
                        onClick = viewModel::compressNow,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Interactive Glass Before / After Comparison Slider
        item {
            AuroraGlassSurface(hazeState = hazeState, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    BasicText(
                        text = "Before / After Visual Verification",
                        style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(170.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(Brush.linearGradient(listOf(palette.accentStart.copy(0.28f), palette.backgroundElevated)))
                            .pointerInput(Unit) {
                                detectHorizontalDragGestures { change, _ ->
                                    change.consume()
                                    splitFraction = (change.position.x / size.width.toFloat()).coerceIn(0.1f, 0.9f)
                                }
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(splitFraction)
                                .background(Brush.linearGradient(listOf(palette.accentMid.copy(0.35f), palette.accentEnd.copy(0.22f))))
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(2.dp)
                                .align(Alignment.CenterStart)
                                .padding(start = (splitFraction * 280).dp)
                                .background(Color.White)
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            BasicText("BEFORE", style = AuroraTheme.typography.labelSmall.copy(color = Color.White))
                            BasicText("AFTER", style = AuroraTheme.typography.labelSmall.copy(color = Color.White))
                        }
                    }

                    state.report?.let { rep ->
                        BasicText(
                            text = rep.message,
                            style = AuroraTheme.typography.bodyMedium.copy(
                                color = if (rep.effectivelyReduced) palette.success else palette.warning
                            )
                        )
                        BasicText(
                            text = "${ByteFormatter.formatHumanBinary(rep.originalBytes)} → ${ByteFormatter.formatHumanBinary(rep.compressedBytes)} • ${rep.qualityMetricName}: ${"%.1f".format(rep.qualityMetricScore)}%",
                            style = AuroraTheme.typography.monoSmall.copy(color = palette.textPrimary)
                        )
                    }
                }
            }
        }
    }
}
