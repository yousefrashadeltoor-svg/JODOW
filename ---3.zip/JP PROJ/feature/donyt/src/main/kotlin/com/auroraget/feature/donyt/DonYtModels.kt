package com.auroraget.feature.donyt

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.auroraget.core.common.MediaCategory
import com.auroraget.core.common.MediaFormatOption
import kotlinx.serialization.Serializable

@Entity(tableName = "donyt_channels")
data class DonChannel(
    @PrimaryKey val channelId: String,
    val handle: String,
    val displayName: String,
    val avatarUrl: String?,
    val subscriberCountFormatted: String,
    val verified: Boolean,
    val followedLocally: Boolean = false,
    val notificationsEnabled: Boolean = false
)

@Entity(tableName = "donyt_watch_history")
data class DonWatchHistoryEntry(
    @PrimaryKey val videoId: String,
    val title: String,
    val channelId: String,
    val channelName: String,
    val thumbnailUrl: String?,
    val durationSeconds: Long?,
    val watchedAtMs: Long = System.currentTimeMillis(),
    val watchProgressSeconds: Long = 0L,
    val isShort: Boolean = false,
    val category: String? = null
)

@Entity(tableName = "donyt_local_profile")
data class DonLocalProfile(
    @PrimaryKey val id: Int = 1,
    val displayName: String = "𝒥𝒪 DON Local User",
    val bio: String = "Completely offline profile. No Google account needed.",
    val avatarPath: String? = null,
    val darkMode: Boolean = true,
    val defaultAudioOnly: Boolean = false,
    val autoSleepTimerMinutes: Int? = null,
    val defaultRepeatMode: String = "OFF",
    val lastProfileExportJson: String? = null
)

@Serializable
data class DonVideoItem(
    val videoId: String,
    val title: String,
    val channelId: String,
    val channelName: String,
    val channelAvatarUrl: String?,
    val thumbnailUrl: String?,
    val durationSeconds: Long?,
    val viewCountFormatted: String,
    val publishedRelative: String,
    val verified: Boolean,
    val isShort: Boolean,
    val isLive: Boolean = false,
    val description: String? = null,
    val tags: List<String> = emptyList(),
    val recommendedFormat: MediaFormatOption? = null,
    val category: MediaCategory = MediaCategory.VIDEO
)

data class DonYouTubeSearchSuggestion(
    val text: String,
    val isHistory: Boolean = false
)

enum class DonYtTab {
    HOME, SHORTS, SUBSCRIPTIONS, LIBRARY
}

enum class DonPlayerRepeatMode {
    OFF, ONE, ALL, SHUFFLE
}
