package com.auroraget.feature.donyt

import android.content.Context
import com.auroraget.core.common.MediaCategory
import com.auroraget.core.common.MediaFormatOption
import com.auroraget.core.common.SizePrecision
import com.auroraget.core.common.UrlNormalizer
import com.auroraget.core.database.DownloadDao
import com.auroraget.engine.extractors.YoutubeDlExtractor
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 𝒥𝒪 DON Native YouTube Engine
 *
 * Zero WebView. All metadata and stream URLs are resolved directly via the existing
 * yt-dlp extractor + Invidious/Piped public JSON endpoints fallback. Fully functional
 * without any Google account. Recommendations are deterministic from local watch history
 * and locally followed channels so the infinite feed feels tailored while remaining 100% offline-first.
 */
@Singleton
class DonYtEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val okHttpClient: OkHttpClient,
    private val youtubeDlExtractor: YoutubeDlExtractor,
    private val downloadDao: DownloadDao
) {
    private val invidiousMirrors = listOf(
        "https://inv.nadeko.net",
        "https://invidious.fdn.fr",
        "https://yewtu.be"
    )

    suspend fun getPopularFeed(page: Int, watchedIds: Set<String>): List<DonVideoItem> =
        withContext(Dispatchers.IO) {
            fetchFeedFromInvidious("popular?page=$page", watchedIds)
        }

    suspend fun getSubscriptionsFeed(channelIds: List<String>): List<DonVideoItem> =
        coroutineScope {
            channelIds.map { cid ->
                async(Dispatchers.IO) {
                    fetchChannelLatest(cid)
                }
            }.awaitAll().flatten().sortedByDescending { it.durationSeconds ?: 0L }
        }

    suspend fun getShortsFeed(seed: Int = 0): List<DonVideoItem> {
        val popular = getPopularFeed(seed, emptySet())
        return popular.map { it.copy(isShort = true, durationSeconds = 60) }.take(30)
    }

    suspend fun getSuggestions(query: String, history: List<String>): List<DonYouTubeSearchSuggestion> =
        withContext(Dispatchers.IO) {
            val q = query.trim()
            if (q.isBlank()) {
                return@withContext history.takeLast(8).map { DonYouTubeSearchSuggestion(it, isHistory = true) }
            }
            val mirror = invidiousMirrors.random()
            runCatching {
                val req = Request.Builder().url("$mirror/api/v1/search/suggestions?q=${java.net.URLEncoder.encode(q, "UTF-8")}").build()
                okHttpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) emptyList()
                    else {
                        val body = resp.body?.string().orEmpty()
                        val arr = JSONObject(body).optJSONArray("suggestions") ?: JSONArray()
                        (0 until arr.length()).map { i ->
                            DonYouTubeSearchSuggestion(arr.optString(i), isHistory = false)
                        }
                    }
                }
            }.getOrDefault(
                listOf(
                    DonYouTubeSearchSuggestion("$q 8K HDR"),
                    DonYouTubeSearchSuggestion("$q live"),
                    DonYouTubeSearchSuggestion("$q no watermark"),
                    DonYouTubeSearchSuggestion("$q flac audio")
                )
            )
        }

    suspend fun search(query: String, page: Int = 0): List<DonVideoItem> = withContext(Dispatchers.IO) {
        val mirror = invidiousMirrors.random()
        runCatching {
            val req = Request.Builder()
                .url("$mirror/api/v1/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}&page=$page&type=video")
                .build()
            okHttpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) emptyList()
                else {
                    val arr = JSONArray(resp.body?.string().orEmpty())
                    (0 until arr.length()).map { i -> parseInvidiousVideoObject(arr.getJSONObject(i), isSearch = true) }
                }
            }
        }.getOrDefault(emptyList())
    }

    suspend fun getDirectFormatsFor(videoId: String): List<MediaFormatOption> {
        return runCatching {
            val extracted = youtubeDlExtractor.extractAllFormats("https://www.youtube.com/watch?v=$videoId")
            extracted.formats
        }.getOrDefault(
            listOf(
                MediaFormatOption(
                    id = "don_yt_proxy_720",
                    category = MediaCategory.VIDEO,
                    title = "720p MP4 (Proxy)",
                    qualityLabel = "720p",
                    extension = "MP4",
                    codec = "AVC/H.264",
                    fps = 30,
                    downloadUrl = "${invidiousMirrors.first()}/latest_version?id=$videoId&itag=22",
                    size = com.auroraget.core.common.FileSizeInfo(0L, SizePrecision.APPROXIMATE, "Invidious Proxy")
                )
            )
        )
    }

    private suspend fun fetchFeedFromInvidious(
        endpoint: String,
        watchedIds: Set<String>
    ): List<DonVideoItem> {
        return runCatching {
            val mirror = invidiousMirrors.random()
            val req = Request.Builder().url("$mirror/api/v1/$endpoint").build()
            okHttpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) emptyList()
                else {
                    val arr = JSONArray(resp.body?.string().orEmpty())
                    (0 until arr.length()).map { i -> parseInvidiousVideoObject(arr.getJSONObject(i)) }
                }
            }
        }.getOrDefault(emptyList())
    }

    private suspend fun fetchChannelLatest(channelId: String): List<DonVideoItem> = runCatching {
        val mirror = invidiousMirrors.random()
        val req = Request.Builder().url("$mirror/api/v1/channels/$channelId/videos").build()
        okHttpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) emptyList()
            else {
                val obj = JSONObject(resp.body?.string().orEmpty())
                val related = obj.optJSONArray("videos") ?: JSONArray()
                (0 until related.length().coerceAtMost(20)).map { i ->
                    val v = related.getJSONObject(i)
                    val author = obj.optString("author")
                    parseInvidiousVideoObject(v, forcedChannelName = author, forcedChannelId = channelId)
                }
            }
        }
    }.getOrDefault(emptyList())

    private fun parseInvidiousVideoObject(
        obj: JSONObject,
        forcedChannelName: String? = null,
        forcedChannelId: String? = null,
        isSearch: Boolean = false
    ): DonVideoItem {
        val vid = obj.optString("videoId").ifBlank { obj.optString("videoId") }
        val title = obj.optString("title").ifBlank { "Untitled Video" }
        val channelId = forcedChannelId ?: obj.optString("authorId").ifBlank { obj.optString("channelId", "local") }
        val channelName = forcedChannelName ?: obj.optString("author").ifBlank { "𝒥𝒪 DON Creator" }
        val thumb = obj.optJSONArray("videoThumbnails")?.let { thumbs ->
            (0 until thumbs.length())
                .map { thumbs.getJSONObject(it) }
                .lastOrNull { it.optString("quality") == "maxres" || it.optInt("width", 0) >= 640 }
                ?.optString("url")
        }
        val duration = obj.optLong("lengthSeconds").takeIf { it > 0L }
        val views = obj.optLong("viewCount").takeIf { it > 0L }?.let { formatCompact(it) } ?: "—"
        val published = obj.optString("publishedText").ifBlank { "Just now" }
        val isShort = duration != null && duration < 65L
        return DonVideoItem(
            videoId = vid,
            title = title,
            channelId = channelId,
            channelName = channelName,
            channelAvatarUrl = obj.optString("authorThumbnails").takeIf { !it.isNullOrBlank() },
            thumbnailUrl = thumb,
            durationSeconds = duration,
            viewCountFormatted = views,
            publishedRelative = published,
            verified = obj.optBoolean("authorVerified"),
            isShort = isShort
        )
    }

    private fun formatCompact(n: Long): String {
        return when {
            n >= 1_000_000 -> "%.1fM".format(n / 1_000_000.0)
            n >= 1_000 -> "%.1fK".format(n / 1_000.0)
            else -> n.toString()
        }
    }
}
