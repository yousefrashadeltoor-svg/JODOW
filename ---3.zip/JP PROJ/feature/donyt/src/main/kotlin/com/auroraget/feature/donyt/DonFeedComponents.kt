package com.auroraget.feature.donyt

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.auroraget.core.common.ByteFormatter
import com.auroraget.core.designsystem.components.AuroraGlassButton
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.AuroraShimmerBox
import com.auroraget.core.designsystem.icons.AuroraIcons
import com.auroraget.core.designsystem.theme.AuroraTheme
import dev.chrisbanes.haze.HazeState

@Composable
fun DonHomeFeed(
    items: List<DonVideoItem>,
    onOpen: (DonVideoItem) -> Unit,
    onDownload: (String, String) -> Unit,
    onLoadMore: () -> Unit,
    loading: Boolean
) {
    val listState = rememberLazyListState()
    LaunchedEffect(listState) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index }
            .collect { lastIdx ->
                if (lastIdx != null && lastIdx >= items.lastIndex - 6) onLoadMore()
            }
    }
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 16.dp)
    ) {
        items(items, key = { it.videoId }) { video ->
            DonVideoCard(video = video, onOpen = { onOpen(video) }, onDownload = onDownload)
        }
        if (loading) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AuroraShimmerBox(modifier = Modifier.fillMaxWidth().height(220.dp))
                    AuroraShimmerBox(modifier = Modifier.fillMaxWidth().height(60.dp))
                }
            }
        }
    }
}

@Composable
fun DonVideoCard(
    video: DonVideoItem,
    onOpen: () -> Unit,
    onDownload: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = AuroraTheme.colors
    AuroraGlassSurface(
        shape = RoundedCornerShape(22.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().clickable { onOpen() }) {
            Box(modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
                AsyncImage(
                    model = video.thumbnailUrl,
                    contentDescription = video.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.7f))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    BasicText(
                        text = video.durationSeconds?.let { ByteFormatter.formatDuration(it) } ?: "LIVE",
                        style = AuroraTheme.typography.monoSmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
                    )
                }
                if (video.isLive) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Red)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        BasicText(
                            text = "LIVE",
                            style = AuroraTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                    BasicText(
                        text = video.title,
                        style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary, fontWeight = FontWeight.Bold),
                        maxLines = 2
                    )
                    BasicText(
                        text = "${video.channelName} • ${video.viewCountFormatted} views • ${video.publishedRelative}",
                        style = AuroraTheme.typography.labelSmall.copy(color = palette.textSecondary)
                    )
                }
                AuroraGlassButton(
                    text = "Get",
                    icon = AuroraIcons.DownloadArrow,
                    primaryGradient = true,
                    onClick = { onDownload(video.videoId, video.title) }
                )
            }
        }
    }
}

@Composable
fun DonShortsFeed(items: List<DonVideoItem>, onOpen: (DonVideoItem) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(items, key = { it.videoId }) { video ->
            Box(
                modifier = Modifier
                    .aspectRatio(9f / 16f)
                    .clip(RoundedCornerShape(22.dp))
                    .clickable { onOpen(video) }
            ) {
                AsyncImage(
                    model = video.thumbnailUrl,
                    contentDescription = video.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))))
                        .padding(8.dp)
                ) {
                    BasicText(
                        text = video.title,
                        style = AuroraTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold),
                        maxLines = 2
                    )
                }
            }
        }
    }
}

@Composable
fun DonSubscriptionsFeed(
    channels: List<DonChannel>,
    items: List<DonVideoItem>,
    onOpen: (DonVideoItem) -> Unit,
    onToggleFollow: (String) -> Unit
) {
    val palette = AuroraTheme.colors
    Column(modifier = Modifier.fillMaxSize()) {
        LazyRow(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(channels.filter { it.followedLocally }) { ch ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { onToggleFollow(ch.channelId) }
                ) {
                    AsyncImage(
                        model = ch.avatarUrl,
                        contentDescription = ch.displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(palette.glassSurfaceStrong)
                    )
                    BasicText(
                        text = ch.displayName,
                        style = AuroraTheme.typography.labelSmall.copy(color = palette.textPrimary),
                        maxLines = 1
                    )
                }
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items, key = { it.videoId }) { video ->
                DonVideoCard(video = video, onOpen = { onOpen(video) }, onDownload = { _, _ -> onOpen(video) })
            }
        }
    }
}

@Composable
fun DonLocalProfileTab(
    profile: DonLocalProfile,
    history: List<DonWatchHistoryEntry>,
    onExport: () -> String,
    onImport: (String) -> Boolean
) {
    val palette = AuroraTheme.colors
    var exportJson by androidx.compose.runtime.remember { mutableStateOf<String?>(null) }
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AuroraGlassSurface(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(palette.auroraGradient))
                )
                Column(modifier = Modifier.weight(1f)) {
                    BasicText(
                        text = profile.displayName,
                        style = AuroraTheme.typography.titleLarge.copy(color = palette.textPrimary, fontWeight = FontWeight.Bold)
                    )
                    BasicText(
                        text = profile.bio,
                        style = AuroraTheme.typography.bodyMedium.copy(color = palette.textSecondary)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AuroraGlassButton(
                    text = "Export Profile",
                    onClick = { exportJson = onExport() },
                    modifier = Modifier.weight(1f)
                )
                AuroraGlassButton(
                    text = "Import Profile",
                    primaryGradient = true,
                    onClick = { /* file picker invocation wired in real APK */ },
                    modifier = Modifier.weight(1f)
                )
            }
            if (exportJson != null) {
                Spacer(modifier = Modifier.height(8.dp))
                BasicText(
                    text = exportJson!!.take(400) + if (exportJson!!.length > 400) "..." else "",
                    style = AuroraTheme.typography.monoSmall.copy(color = palette.textSecondary)
                )
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(horizontal = 12.dp)) {
            item {
                BasicText(
                    text = "Watch History",
                    style = AuroraTheme.typography.titleMedium.copy(color = palette.textPrimary, fontWeight = FontWeight.Bold)
                )
            }
            items(history.take(12)) { entry ->
                AuroraGlassSurface(
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AsyncImage(
                            model = entry.thumbnailUrl,
                            contentDescription = entry.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.width(88.dp).height(50.dp).clip(RoundedCornerShape(12.dp))
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            BasicText(
                                text = entry.title,
                                style = AuroraTheme.typography.labelLarge.copy(color = palette.textPrimary, fontWeight = FontWeight.Bold),
                                maxLines = 2
                            )
                            BasicText(
                                text = entry.channelName,
                                style = AuroraTheme.typography.labelSmall.copy(color = palette.textSecondary)
                            )
                        }
                    }
                }
            }
        }
    }
}
