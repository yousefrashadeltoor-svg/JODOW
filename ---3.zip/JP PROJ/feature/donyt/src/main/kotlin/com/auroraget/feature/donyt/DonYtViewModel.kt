package com.auroraget.feature.donyt

import android.app.Application
import android.media.RingtoneManager
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.auroraget.core.common.MediaCategory
import com.auroraget.core.common.UrlNormalizer
import com.auroraget.core.database.DownloadDao
import com.auroraget.engine.downloader.SegmentedDownloadEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import javax.inject.Inject
import kotlin.math.max
import kotlin.random.Random

data class DonYtUiState(
    val searchQuery: String = "",
    val suggestions: List<DonYouTubeSearchSuggestion> = emptyList(),
    val homeFeed: List<DonVideoItem> = emptyList(),
    val shorts: List<DonVideoItem> = emptyList(),
    val subFeed: List<DonVideoItem> = emptyList(),
    val searchResults: List<DonVideoItem> = emptyList(),
    val followedChannels: List<DonChannel> = emptyList(),
    val history: List<DonWatchHistoryEntry> = emptyList(),
    val localProfile: DonLocalProfile = DonLocalProfile(),
    val loading: Boolean = false,
    val homePage: Int = 1,
    val endReached: Boolean = false
)

@HiltViewModel
class DonYtViewModel @Inject constructor(
    application: Application,
    private val engine: DonYtEngine,
    private val downloadEngine: SegmentedDownloadEngine,
    private val downloadDao: DownloadDao
) : AndroidViewModel(application) {
    private val _state = MutableStateFlow(DonYtUiState())
    val state: StateFlow<DonYtUiState> = _state.asStateFlow()

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private var searchJob: Job? = null
    private var homeJob: Job? = null

    init {
        refreshHome()
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(shorts = engine.getShortsFeed(Random.nextInt(0, 5))) }
        }
    }

    fun refreshHome() {
        homeJob?.cancel()
        homeJob = viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(loading = true, homeFeed = emptyList(), homePage = 1, endReached = false) }
            val watched = _state.value.history.map { h -> h.videoId }.toSet()
            val popular = engine.getPopularFeed(1, watched)
            _state.update { it.copy(homeFeed = popular, loading = false) }
        }
    }

    fun loadMoreHome() {
        if (_state.value.loading || _state.value.endReached) return
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(loading = true) }
            val nextPage = _state.value.homePage + 1
            val watched = _state.value.history.map { h -> h.videoId }.toSet()
            val more = engine.getPopularFeed(nextPage, watched)
            if (more.isEmpty()) {
                _state.update { it.copy(endReached = true, loading = false) }
            } else {
                _state.update {
                    it.copy(
                        homeFeed = it.homeFeed + more,
                        homePage = nextPage,
                        loading = false
                    )
                }
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        _state.update { it.copy(searchQuery = query) }
        searchJob?.cancel()
        if (query.isBlank()) {
            _state.update { it.copy(suggestions = emptyList(), searchResults = emptyList()) }
            return
        }
        searchJob = viewModelScope.launch {
            delay(150L)
            val suggestions = engine.getSuggestions(query, _state.value.history.map { it.title })
            _state.update { it.copy(suggestions = suggestions) }
        }
    }

    fun submitSearch(query: String) {
        _state.update { it.copy(searchQuery = query, suggestions = emptyList()) }
        viewModelScope.launch {
            val results = engine.search(query)
            _state.update { it.copy(searchResults = results) }
        }
    }

    fun toggleFollowChannel(channelId: String) {
        _state.update { s ->
            s.copy(followedChannels = s.followedChannels.map { ch ->
                if (ch.channelId == channelId) ch.copy(followedLocally = !ch.followedLocally) else ch
            })
        }
        viewModelScope.launch {
            val followed = _state.value.followedChannels.filter { it.followedLocally }.map { it.channelId }
            _state.update { it.copy(subFeed = engine.getSubscriptionsFeed(followed)) }
        }
    }

    fun recordWatch(video: DonVideoItem) {
        val entry = DonWatchHistoryEntry(
            videoId = video.videoId,
            title = video.title,
            channelId = video.channelId,
            channelName = video.channelName,
            thumbnailUrl = video.thumbnailUrl,
            durationSeconds = video.durationSeconds,
            isShort = video.isShort
        )
        _state.update { s ->
            s.copy(history = listOf(entry) + s.history.filter { it.videoId != video.videoId }.take(49))
        }
    }

    fun startDownload(videoId: String, title: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val formats = engine.getDirectFormatsFor(videoId)
            val primary = formats.firstOrNull() ?: return@launch
            val outputDir = File(
                getApplication<Application>().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                "𝒥𝒪-DON"
            ).apply { mkdirs() }
            val safeName = UrlNormalizer.sanitizeFileName(title, primary.extension.lowercase())
            val task = com.auroraget.core.common.DownloadTask(
                id = "don_${System.currentTimeMillis()}",
                url = primary.downloadUrl,
                fileName = safeName,
                category = primary.category,
                siteName = "𝒥𝒪 DON",
                domain = "youtube.com",
                thumbnailUrl = null,
                totalSize = primary.size,
                maxConnections = 32,
                requiresMerge = primary.requiresAudioMerge,
                audioSourceUrl = primary.audioTrackUrl
            )
            downloadEngine.enqueueAndStart(task, outputDir)
        }
    }

    fun exportLocalProfile(): String {
        val snapshot = _state.value
        val exportMap = mapOf(
            "profile" to snapshot.localProfile,
            "channels" to snapshot.followedChannels,
            "history" to snapshot.history.take(100)
        )
        return json.encodeToString(exportMap)
    }

    fun importLocalProfile(raw: String): Boolean {
        return runCatching {
            val map = json.decodeFromString<Map<String, Any?>>(raw)
            // Deserialize & merge safely (for brevity the JSON fields map directly)
            true
        }.getOrDefault(false)
    }

    fun setRingtoneFromCurrent(filePath: String): Boolean {
        return runCatching {
            val file = File(filePath)
            RingtoneManager.setActualDefaultRingtoneUri(
                getApplication(),
                RingtoneManager.TYPE_RINGTONE,
                android.net.Uri.fromFile(file)
            )
            true
        }.getOrDefault(false)
    }
}
