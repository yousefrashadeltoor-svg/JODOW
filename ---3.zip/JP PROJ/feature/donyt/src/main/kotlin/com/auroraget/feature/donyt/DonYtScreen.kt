package com.auroraget.feature.donyt

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil3.compose.AsyncImage
import com.auroraget.core.designsystem.components.AuroraGlassButton
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.AuroraShimmerBox
import com.auroraget.core.designsystem.components.StreamingTextReveal
import com.auroraget.core.designsystem.icons.AuroraIcons
import com.auroraget.core.designsystem.theme.AuroraTheme
import dev.chrisbanes.haze.HazeState

@Composable
fun DonYtScreen(
    hazeState: HazeState,
    onOpenVideo: (DonVideoItem) -> Unit,
    onDownloadFormat: (String, String) -> Unit,
    onOpenLocalPlayer: () -> Unit
) {
    val vm: DonYtViewModel = hiltViewModel()
    val state by vm.state.collectAsState()
    val palette = AuroraTheme.colors

    var activeTab by rememberSaveable { mutableStateOf(DonYtTab.HOME) }

    Column(modifier = Modifier.fillMaxSize()) {
        // DON YouTube Custom Top Bar
        AuroraGlassSurface(
            hazeState = hazeState,
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            contentPadding = PaddingValues(10.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicText(
                        text = "𝒥𝒪 DON",
                        style = AuroraTheme.typography.titleLarge.copy(
                            brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                palette.auroraGradient
                            )
                        )
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AuroraGlassButton(
                            text = "Local Player",
                            icon = AuroraIcons.PlayIcon,
                            onClick = onOpenLocalPlayer,
                            primaryGradient = true
                        )
                    }
                }
                if (activeTab == DonYtTab.HOME || activeTab == DonYtTab.SEARCH) {
                    BasicTextField(
                        value = state.searchQuery,
                        onValueChange = vm::onSearchQueryChanged,
                        textStyle = AuroraTheme.typography.bodyLarge.copy(color = palette.textPrimary),
                        cursorBrush = SolidColor(palette.accentStart),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(palette.glassSurfaceStrong)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        decorationBox = { inner ->
                            if (state.searchQuery.isBlank()) {
                                BasicText(
                                    text = "Search 𝒥𝒪 DON (videos, channels, audio)",
                                    style = AuroraTheme.typography.bodyLarge.copy(color = palette.textMuted)
                                )
                            }
                            inner()
                        }
                    )
                    AnimatedVisibility(
                        visible = state.suggestions.isNotEmpty() && state.searchQuery.isNotBlank(),
                        enter = fadeIn(spring()),
                        exit = fadeOut()
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            state.suggestions.take(6).forEach { s ->
                                BasicText(
                                    text = s.text,
                                    style = AuroraTheme.typography.labelLarge.copy(color = palette.textSecondary),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { vm.submitSearch(s.text) }
                                        .padding(8.dp)
                                )
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(androidx.compose.foundation.rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DonYtTab.entries.forEach { t ->
                        val selected = activeTab == t
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (selected) androidx.compose.ui.graphics.Brush.horizontalGradient(palette.auroraGradient) else palette.glassSurfaceStrong)
                                .clickable {
                                    activeTab = t
                                    if (t == DonYtTab.HOME) vm.refreshHome()
                                }
                                .padding(horizontal = 14.dp, vertical = 7.dp)
                        ) {
                            BasicText(
                                text = t.name,
                                style = AuroraTheme.typography.labelLarge.copy(
                                    color = if (selected) Color.White else palette.textSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }
        }

        when (activeTab) {
            DonYtTab.HOME -> DonHomeFeed(
                items = state.homeFeed,
                onOpen = onOpenVideo,
                onDownload = { id, title -> onDownloadFormat(id, title) },
                onLoadMore = vm::loadMoreHome,
                loading = state.loading
            )
            DonYtTab.SHORTS -> DonShortsFeed(items = state.shorts, onOpen = onOpenVideo)
            DonYtTab.SUBSCRIPTIONS -> DonSubscriptionsFeed(
                channels = state.followedChannels,
                items = state.subFeed,
                onOpen = onOpenVideo,
                onToggleFollow = vm::toggleFollowChannel
            )
            DonYtTab.LIBRARY -> DonLocalProfileTab(
                profile = state.localProfile,
                history = state.history,
                onExport = vm::exportLocalProfile,
                onImport = vm::importLocalProfile
            )
        }
    }
}
