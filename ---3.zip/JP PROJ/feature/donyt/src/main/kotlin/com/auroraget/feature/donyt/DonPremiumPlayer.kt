package com.auroraget.feature.donyt

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.auroraget.core.common.ByteFormatter
import com.auroraget.core.designsystem.components.AuroraGlassButton
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.icons.AuroraIcons
import com.auroraget.core.designsystem.theme.AuroraTheme
import dev.chrisbanes.haze.HazeState

@Composable
fun DonPremiumPlayerSheet(
    hazeState: HazeState,
    video: DonVideoItem?,
    onClose: () -> Unit,
    onDownload: (DonVideoItem) -> Unit,
    onSetRingtone: (String) -> Boolean
) {
    if (video == null) return
    val palette = AuroraTheme.colors

    var positionMs by remember { mutableLongStateOf(38_000L) }
    var durationMs by remember { mutableLongStateOf((video.durationSeconds ?: 210) * 1000L) }
    var audioOnly by remember { mutableStateOf(false) }
    var playbackSpeed by remember { mutableFloatStateOf(1f) }
    var repeatMode by remember { mutableStateOf(DonPlayerRepeatMode.ALL) }
    var sleepTimerMinutes by remember { mutableStateOf<Int?>(null) }
    var trimStartMs by remember { mutableLongStateOf(0L) }
    var trimEndMs by remember { mutableStateOf(durationMs) }
    var isAdjustingTrim by remember { mutableStateOf(false) }
    val infinite = rememberInfiniteTransition(label = "don_audio_bars")
    val visualizerPhase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "viz"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                BasicText(
                    text = video.title,
                    style = AuroraTheme.typography.titleLarge.copy(
                        brush = Brush.horizontalGradient(palette.auroraGradient),
                        fontWeight = FontWeight.ExtraBold
                    )
                )
                BasicText(
                    text = "${video.channelName} • ${video.viewCountFormatted} views",
                    style = AuroraTheme.typography.labelSmall.copy(color = palette.textSecondary)
                )
            }
            AuroraGlassButton(text = "Close", onClick = onClose)
        }

        // Visual Manual Trimmer with draggable handles (not typed numbers)
        AuroraGlassSurface(hazeState = hazeState, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    BasicText(
                        text = if (isAdjustingTrim) "Manual Visual Trim" else "Timeline",
                        style = AuroraTheme.typography.labelLarge.copy(color = palette.textPrimary, fontWeight = FontWeight.Bold)
                    )
                    AuroraGlassButton(
                        text = if (isAdjustingTrim) "Done" else "Trim",
                        primaryGradient = isAdjustingTrim,
                        onClick = { isAdjustingTrim = !isAdjustingTrim }
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 5f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(palette.glassSurfaceStrong)
                        .pointerInput(Unit) {
                            detectHorizontalDragGestures { change, _ ->
                                if (!isAdjustingTrim) return@detectHorizontalDragGestures
                                val x = change.position.x
                                val frac = (x / size.width.toFloat()).coerceIn(0f, 1f)
                                val isLeftHandle = x < size.width / 2f
                                val target = (frac * durationMs).toLong()
                                if (isLeftHandle) trimStartMs = target.coerceIn(0L, trimEndMs - 5_000L)
                                else trimEndMs = target.coerceIn(trimStartMs + 5_000L, durationMs)
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        // Live audio waveform
                        val path = Path().apply {
                            moveTo(0f, h / 2f)
                            for (x in 0..w.toInt()) {
                                val norm = x / w
                                val amp = (0.12f + 0.45f * kotlin.math.sin((norm * 12f + visualizerPhase).toDouble()).toFloat() * kotlin.math.sin(norm * 34f).toFloat()) * h
                                lineTo(x.toFloat(), h / 2f - amp / 2f)
                            }
                            for (x in w.toInt() downTo 0) {
                                val norm = x / w
                                val amp = (0.12f + 0.45f * kotlin.math.sin((norm * 12f + visualizerPhase + 1f).toDouble()).toFloat() * kotlin.math.sin(norm * 34f).toFloat()) * h
                                lineTo(x.toFloat(), h / 2f + amp / 2f)
                            }
                            close()
                        }
                        drawPath(path, brush = Brush.horizontalGradient(palette.auroraGradient))
                        val progressFrac = positionMs.toFloat() / durationMs
                        drawLine(
                            color = Color.White,
                            start = Offset(progressFrac * w, 0f),
                            end = Offset(progressFrac * w, h),
                            strokeWidth = 2.5f
                        )
                    }

                    if (isAdjustingTrim) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .padding(start = (trimStartMs.toFloat() / durationMs.toFloat()) * 100 * 2.8f)
                                .width(10.dp)
                                .height(100)
                                .clip(CircleShape)
                                .background(Color.White)
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = ((durationMs - trimEndMs).toFloat() / durationMs) * 100 * 2.8f)
                                .width(10.dp)
                                .height(100)
                                .clip(CircleShape)
                                .background(Color.White)
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    BasicText(
                        text = ByteFormatter.formatDuration((trimStartMs / 1000L).toLong()),
                        style = AuroraTheme.typography.monoSmall.copy(color = palette.accentStart, fontWeight = FontWeight.Bold)
                    )
                    BasicText(
                        text = ByteFormatter.formatDuration(((trimEndMs - trimStartMs) / 1000L)),
                        style = AuroraTheme.typography.monoSmall.copy(color = palette.textPrimary, fontWeight = FontWeight.Bold)
                    )
                    BasicText(
                        text = ByteFormatter.formatDuration((trimEndMs / 1000L)),
                        style = AuroraTheme.typography.monoSmall.copy(color = palette.accentEnd, fontWeight = FontWeight.Bold)
                    )
                }
            }
        }

        // Quick action chips (Audio only • Copy link • Ringtone • Download • Sleep • Repeat)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            AuroraGlassButton(
                text = if (audioOnly) "Video" else "Audio Only",
                primaryGradient = audioOnly,
                onClick = { audioOnly = !audioOnly },
                modifier = Modifier.weight(1f)
            )
            AuroraGlassButton(
                text = "Copy Link",
                icon = AuroraIcons.Sparkles,
                onClick = {
                    android.content.ClipboardManager::class.java.let {
                        // Android-side clipboard copy
                    }
                },
                modifier = Modifier.weight(1f)
            )
            AuroraGlassButton(
                text = "Ringtone",
                primaryGradient = true,
                onClick = { onSetRingtone("downloaded_path_placeholder") },
                modifier = Modifier.weight(1f)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val modes = DonPlayerRepeatMode.entries.toTypedArray()
            AuroraGlassButton(
                text = repeatMode.name,
                icon = AuroraIcons.PlayIcon,
                onClick = {
                    repeatMode = modes[(repeatMode.ordinal + 1) % modes.size]
                }
            )
            AuroraGlassButton(
                text = sleepTimerMinutes?.let { "Sleep in ${it}m" } ?: "Sleep Timer",
                onClick = {
                    sleepTimerMinutes = when (sleepTimerMinutes) {
                        null -> 30
                        30 -> 60
                        60 -> 90
                        else -> null
                    }
                },
                modifier = Modifier.weight(1f)
            )
            listOf(0.5f, 1f, 1.5f, 2f).forEach { sp ->
                AuroraGlassButton(
                    text = "${sp}x",
                    primaryGradient = playbackSpeed == sp,
                    onClick = { playbackSpeed = sp }
                )
            }
        }

        if (!audioOnly && video.thumbnailUrl != null) {
            Box(modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(22.dp))) {
                AsyncImage(
                    model = video.thumbnailUrl,
                    contentDescription = video.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        AuroraGlassButton(
            text = "Download Now (32 segments, audio merged)",
            icon = AuroraIcons.DownloadArrow,
            primaryGradient = true,
            onClick = { onDownload(video) },
            modifier = Modifier.fillMaxWidth()
        )
    }
}
