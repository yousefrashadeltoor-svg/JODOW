package com.auroraget.engine.downloader

import com.auroraget.core.database.DownloadDao
import com.auroraget.core.database.StatsDao
import com.auroraget.core.network.ExactSizeResolver
import com.auroraget.engine.media.FFmpegMediaEngine
import io.mockk.mockk
import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SegmentedDownloadEngineTest {
    private val engine = SegmentedDownloadEngine(
        okHttpClient = mockk<OkHttpClient>(relaxed = true),
        sizeResolver = mockk<ExactSizeResolver>(relaxed = true),
        downloadDao = mockk<DownloadDao>(relaxed = true),
        statsDao = mockk<StatsDao>(relaxed = true),
        ffmpegMediaEngine = mockk<FFmpegMediaEngine>(relaxed = true)
    )

    @Test
    fun buildInitialSegments_coversEverySingleByteExactlyOnce() {
        val total = 148_372_910L
        val segments = engine.buildInitialSegments(total, 16)
        assertEquals(16, segments.size)
        assertEquals(0L, segments.first().startByte)
        assertEquals(total - 1L, segments.last().endByte)

        for (i in 0 until segments.lastIndex) {
            assertEquals(segments[i].endByte + 1L, segments[i + 1].startByte)
        }
        val summedBytes = segments.sumOf { it.endByte - it.startByte + 1L }
        assertEquals(total, summedBytes)
    }

    @Test
    fun workStealing_splitsSlowestRemainingSegmentCleanly() {
        val segments = mutableListOf(
            SegmentDescriptor(index = 0, startByte = 0L, endByte = 10_000_000L, downloadedBytes = 1_000_000L, completed = false),
            SegmentDescriptor(index = 1, startByte = 10_000_001L, endByte = 20_000_000L, downloadedBytes = 10_000_000L, completed = true)
        )
        val stolen = engine.stealWorkIfPossible(segments)
        assertNotNull(stolen)
        assertEquals(3, segments.size)
        assertEquals(segments[0].endByte + 1L, stolen!!.startByte)
        assertEquals(10_000_000L, stolen.endByte)
        assertTrue(stolen.remainingBytes > 1_000_000L)
    }

    @Test
    fun workStealing_returnsNullWhenRemainingBytesBelowThreshold() {
        val segments = mutableListOf(
            SegmentDescriptor(index = 0, startByte = 0L, endByte = 500_000L, downloadedBytes = 100_000L, completed = false)
        )
        assertNull(engine.stealWorkIfPossible(segments))
    }

    @Test
    fun adaptiveSegments_scalesBetween8And32BasedOnFileSize() {
        assertEquals(1, engine.calculateAdaptiveSegmentCount(512_000L, 16))
        assertEquals(8, engine.calculateAdaptiveSegmentCount(10L * 1024 * 1024, 32))
        assertEquals(16, engine.calculateAdaptiveSegmentCount(64L * 1024 * 1024, 32))
        assertEquals(32, engine.calculateAdaptiveSegmentCount(500L * 1024 * 1024, 32))
    }
}
