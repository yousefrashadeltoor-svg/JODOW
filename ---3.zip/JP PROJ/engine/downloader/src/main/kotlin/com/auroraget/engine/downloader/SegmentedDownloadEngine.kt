package com.auroraget.engine.downloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.auroraget.core.common.ByteFormatter
import com.auroraget.core.common.DownloadStatus
import com.auroraget.core.common.DownloadTask
import com.auroraget.core.common.FileSizeInfo
import com.auroraget.core.common.MediaCategory
import com.auroraget.core.common.SizePrecision
import com.auroraget.core.database.DownloadDao
import com.auroraget.core.database.DownloadEntity
import com.auroraget.core.database.SegmentEntity
import com.auroraget.core.database.StatsDao
import com.auroraget.core.database.StatsEntity
import com.auroraget.core.network.ExactSizeResolver
import com.auroraget.engine.media.FFmpegMediaEngine
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

data class SegmentDescriptor(
    val index: Int,
    var startByte: Long,
    var endByte: Long,
    var downloadedBytes: Long = 0L,
    var completed: Boolean = false
) {
    val remainingBytes: Long get() = ((endByte - startByte + 1) - downloadedBytes).coerceAtLeast(0L)
}

interface ExpiredLinkRefresher {
    suspend fun refreshDirectUrl(taskId: String, originalUrl: String): String?
}

@Singleton
class SegmentedDownloadEngine @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val sizeResolver: ExactSizeResolver,
    private val downloadDao: DownloadDao,
    private val statsDao: StatsDao,
    private val ffmpegMediaEngine: FFmpegMediaEngine
) {
    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val liveSpeeds = ConcurrentHashMap<String, MutableList<Long>>()
    private val json = Json { ignoreUnknownKeys = true }

    private val _liveMetrics = MutableStateFlow<Map<String, Pair<Long, List<Long>>>>(emptyMap())
    val liveMetrics: StateFlow<Map<String, Pair<Long, List<Long>>>> = _liveMetrics.asStateFlow()

    var speedLimitBytesPerSec: Long = 0L
    var linkRefresher: ExpiredLinkRefresher? = null

    fun calculateAdaptiveSegmentCount(totalBytes: Long, preferredMax: Int): Int {
        val clampedMax = preferredMax.coerceIn(8, 32)
        return when {
            totalBytes < 2L * 1024L * 1024L -> 1
            totalBytes < 16L * 1024L * 1024L -> min(8, clampedMax)
            totalBytes < 128L * 1024L * 1024L -> min(16, clampedMax)
            else -> clampedMax
        }
    }

    fun buildInitialSegments(totalBytes: Long, count: Int): List<SegmentDescriptor> {
        if (totalBytes <= 0L || count <= 1) {
            return listOf(SegmentDescriptor(0, 0L, (totalBytes - 1L).coerceAtLeast(0L)))
        }
        val chunkSize = totalBytes / count
        return (0 until count).map { i ->
            val start = i * chunkSize
            val end = if (i == count - 1) totalBytes - 1L else ((i + 1) * chunkSize) - 1L
            SegmentDescriptor(index = i, startByte = start, endByte = end)
        }
    }

    /**
     * Work-Stealing: when a worker finishes early, split the largest remaining active segment
     * in half so bandwidth stays saturated above 90% until the final byte.
     */
    fun stealWorkIfPossible(segments: MutableList<SegmentDescriptor>): SegmentDescriptor? {
        val minStealBytes = 1024L * 1024L // Only split segments with > 1 MiB remaining
        val candidate = segments
            .filter { !it.completed && it.remainingBytes >= minStealBytes * 2 }
            .maxByOrNull { it.remainingBytes } ?: return null

        val currentPos = candidate.startByte + candidate.downloadedBytes
        val mid = currentPos + (candidate.endByte - currentPos) / 2
        if (mid <= currentPos || mid >= candidate.endByte) return null

        val stolen = SegmentDescriptor(
            index = segments.size,
            startByte = mid + 1,
            endByte = candidate.endByte,
            downloadedBytes = 0L,
            completed = false
        )
        candidate.endByte = mid
        segments.add(stolen)
        return stolen
    }

    suspend fun enqueueAndStart(task: DownloadTask, outputDir: File) {
        val entity = DownloadEntity(
            id = task.id,
            url = task.url,
            mirrorUrlsJson = json.encodeToString(task.mirrorUrls),
            fileName = task.fileName,
            category = task.category.name,
            siteName = task.siteName,
            domain = task.domain,
            thumbnailUrl = task.thumbnailUrl,
            totalBytes = task.totalSize.bytes,
            sizePrecision = task.totalSize.precision.name,
            downloadedBytes = task.downloadedBytes,
            maxConnections = task.maxConnections.coerceIn(8, 32),
            status = DownloadStatus.QUEUED.name,
            priority = task.priority,
            localFilePath = File(outputDir, task.fileName).absolutePath,
            etag = task.etag,
            lastModified = task.lastModified,
            supportsRanges = task.supportsRanges,
            requiresMerge = task.requiresMerge,
            audioSourceUrl = task.audioSourceUrl,
            headersJson = json.encodeToString(task.headers),
            errorMessage = null,
            createdAtMs = task.createdAtMs,
            scheduledAtMs = task.scheduledAtMs,
            wifiOnly = task.wifiOnly,
            chargingOnly = task.chargingOnly
        )
        downloadDao.upsert(entity)
        startOrResume(task.id)
    }

    fun startOrResume(downloadId: String) {
        if (activeJobs[downloadId]?.isActive == true) return
        activeJobs[downloadId] = engineScope.launch {
            executeDownload(downloadId)
        }
    }

    suspend fun pause(downloadId: String) {
        activeJobs.remove(downloadId)?.cancel()
        downloadDao.updateStatus(downloadId, DownloadStatus.PAUSED.name)
    }

    suspend fun cancelAndCleanup(downloadId: String) {
        activeJobs.remove(downloadId)?.cancel()
        downloadDao.updateStatus(downloadId, DownloadStatus.CANCELLED.name)
        downloadDao.deleteSegments(downloadId)
    }

    private suspend fun executeDownload(downloadId: String) {
        val entity = downloadDao.getById(downloadId) ?: return
        val headers: Map<String, String> = runCatching {
            json.decodeFromString<Map<String, String>>(entity.headersJson)
        }.getOrDefault(emptyMap())
        val mirrors: List<String> = runCatching {
            json.decodeFromString<List<String>>(entity.mirrorUrlsJson)
        }.getOrDefault(emptyList())

        val targetFile = File(entity.localFilePath ?: return)
        targetFile.parentFile?.mkdirs()

        try {
            downloadDao.updateStatus(downloadId, DownloadStatus.DOWNLOADING.name)
            val probe = sizeResolver.probeExactMetadata(entity.url, headers, entity.totalBytes.takeIf { it > 0 })
            val totalBytes = probe.sizeInfo.bytes.takeIf { it > 0 } ?: entity.totalBytes
            val supportsRanges = probe.supportsRanges && totalBytes > 0L

            // Validate ETag / Last-Modified before resuming to prevent corrupted files
            val existingSegments = downloadDao.getSegments(downloadId)
            val remoteChanged = existingSegments.isNotEmpty() &&
                ((entity.etag != null && probe.etag != null && entity.etag != probe.etag) ||
                    (entity.lastModified != null && probe.lastModified != null && entity.lastModified != probe.lastModified))

            if (remoteChanged) {
                Timber.w("Remote ETag/Last-Modified changed for $downloadId; restarting segments cleanly.")
                downloadDao.deleteSegments(downloadId)
            }

            // Pre-allocate destination file for contiguous disk writes
            if (totalBytes > 0L) {
                RandomAccessFile(targetFile, "rw").use { raf ->
                    if (raf.length() != totalBytes) raf.setLength(totalBytes)
                }
            }

            val segments: MutableList<SegmentDescriptor> = if (supportsRanges) {
                val restored = if (!remoteChanged) existingSegments else emptyList()
                if (restored.isNotEmpty()) {
                    restored.map {
                        SegmentDescriptor(it.segmentIndex, it.startByte, it.endByte, it.downloadedBytes, it.completed)
                    }.toMutableList()
                } else {
                    val segCount = calculateAdaptiveSegmentCount(totalBytes, entity.maxConnections)
                    val fresh = buildInitialSegments(totalBytes, segCount)
                    downloadDao.upsertSegments(fresh.map {
                        SegmentEntity(downloadId, it.index, it.startByte, it.endByte, 0L, false)
                    })
                    fresh.toMutableList()
                }
            } else {
                mutableListOf(SegmentDescriptor(0, 0L, (totalBytes - 1L).coerceAtLeast(0L)))
            }

            val totalDownloaded = AtomicLong(segments.sumOf { it.downloadedBytes })
            val segmentMutex = Mutex()
            val candidateUrls = listOf(probe.finalUrl) + mirrors

            // Speed & progress telemetry ticker
            val telemetryJob = engineScope.launch {
                var prevBytes = totalDownloaded.get()
                while (isActive) {
                    delay(1000L)
                    val nowBytes = totalDownloaded.get()
                    val delta = (nowBytes - prevBytes).coerceAtLeast(0L)
                    prevBytes = nowBytes
                    val history = liveSpeeds.computeIfAbsent(downloadId) { mutableListOf() }
                    history.add(delta)
                    if (history.size > 30) history.removeAt(0)
                    _liveMetrics.update { it + (downloadId to (delta to history.toList())) }
                    downloadDao.updateProgress(downloadId, nowBytes, totalBytes)
                }
            }

            try {
                coroutineScope {
                    val workerCount = if (supportsRanges) segments.size.coerceIn(1, 32) else 1
                    val workers = (0 until workerCount).map { workerIdx ->
                        async(Dispatchers.IO) {
                            var currentSeg: SegmentDescriptor? = segments.getOrNull(workerIdx)
                            while (currentSeg != null && isActive) {
                                if (!currentSeg.completed) {
                                    downloadSegmentWithRetry(
                                        downloadId = downloadId,
                                        segment = currentSeg,
                                        candidateUrls = candidateUrls,
                                        targetFile = targetFile,
                                        headers = headers,
                                        supportsRanges = supportsRanges,
                                        etag = probe.etag,
                                        totalDownloaded = totalDownloaded
                                    )
                                }
                                currentSeg = segmentMutex.withLock {
                                    segments.firstOrNull { !it.completed && it.downloadedBytes == 0L }
                                        ?: stealWorkIfPossible(segments)
                                }
                            }
                        }
                    }
                    workers.awaitAll()
                }
            } finally {
                telemetryJob.cancel()
            }

            // Optional DASH Video + Audio merge via FFmpeg (-c copy)
            if (entity.requiresMerge && !entity.audioSourceUrl.isNullOrBlank()) {
                downloadDao.updateStatus(downloadId, DownloadStatus.MERGING.name)
                val tempAudio = File(targetFile.parentFile, "${targetFile.nameWithoutExtension}.aurora_audio.m4a")
                downloadSingleStream(entity.audioSourceUrl, tempAudio, headers)
                val mergedOut = File(targetFile.parentFile, "${targetFile.nameWithoutExtension}_merged.mp4")
                val muxResult = ffmpegMediaEngine.muxVideoAndAudioStreamCopy(
                    videoFile = targetFile,
                    audioFile = tempAudio,
                    outputFile = mergedOut
                )
                tempAudio.delete()
                if (muxResult.isSuccess) {
                    targetFile.delete()
                    mergedOut.renameTo(targetFile)
                }
            }

            downloadDao.updateProgress(downloadId, targetFile.length(), targetFile.length())
            downloadDao.updateStatus(downloadId, DownloadStatus.COMPLETED.name)
            downloadDao.deleteSegments(downloadId)
            recordCompletionStats(targetFile.length())
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            Timber.e(e, "Download failed for $downloadId")
            downloadDao.updateStatus(downloadId, DownloadStatus.FAILED.name, e.message ?: "Download error")
        } finally {
            activeJobs.remove(downloadId)
        }
    }

    private suspend fun downloadSegmentWithRetry(
        downloadId: String,
        segment: SegmentDescriptor,
        candidateUrls: List<String>,
        targetFile: File,
        headers: Map<String, String>,
        supportsRanges: Boolean,
        etag: String?,
        totalDownloaded: AtomicLong
    ) {
        var attempt = 0
        var activeUrlIndex = 0
        var activeUrl = candidateUrls.first()
        val maxAttempts = 6
        val bufferSize = 512 * 1024 // 512 KiB high-throughput zero-copy style buffer

        while (attempt < maxAttempts) {
            try {
                val rangeStart = segment.startByte + segment.downloadedBytes
                if (supportsRanges && rangeStart > segment.endByte) {
                    segment.completed = true
                    persistSegment(downloadId, segment)
                    return
                }

                val reqBuilder = Request.Builder().url(activeUrl)
                headers.forEach { (k, v) -> reqBuilder.header(k, v) }
                if (supportsRanges) {
                    reqBuilder.header("Range", "bytes=$rangeStart-${segment.endByte}")
                    if (!etag.isNullOrBlank()) reqBuilder.header("If-Range", etag)
                }

                okHttpClient.newCall(reqBuilder.build()).execute().use { response ->
                    if (response.code == 403 || response.code == 410) {
                        val refreshed = linkRefresher?.refreshDirectUrl(downloadId, activeUrl)
                        if (!refreshed.isNullOrBlank()) {
                            activeUrl = refreshed
                            throw IllegalStateException("Expired URL refreshed; retrying")
                        }
                    }
                    if (!response.isSuccessful && response.code != 206) {
                        throw IllegalStateException("HTTP ${response.code} for segment ${segment.index}")
                    }
                    val bodyStream = response.body?.byteStream()
                        ?: throw IllegalStateException("Empty response body")

                    RandomAccessFile(targetFile, "rw").use { raf ->
                        val channel = raf.channel
                        var writePos = rangeStart
                        val buffer = ByteArray(bufferSize)
                        var checkpointCounter = 0L

                        while (true) {
                            val read = bodyStream.read(buffer)
                            if (read == -1) break

                            // Respect Work-Stealing updated endByte boundary
                            val maxAllowed = if (supportsRanges) {
                                (segment.endByte - writePos + 1).coerceAtMost(read.toLong()).toInt()
                            } else read

                            if (maxAllowed <= 0) break

                            val bb = ByteBuffer.wrap(buffer, 0, maxAllowed)
                            while (bb.hasRemaining()) {
                                writePos += channel.write(bb, writePos)
                            }
                            segment.downloadedBytes += maxAllowed
                            totalDownloaded.addAndGet(maxAllowed.toLong())
                            checkpointCounter += maxAllowed

                            if (speedLimitBytesPerSec > 0L) {
                                val sleepMs = (maxAllowed * 1000L) / speedLimitBytesPerSec
                                if (sleepMs > 0L) delay(sleepMs)
                            }

                            if (checkpointCounter >= 1024L * 1024L) {
                                persistSegment(downloadId, segment)
                                checkpointCounter = 0L
                            }

                            if (supportsRanges && writePos > segment.endByte) break
                        }
                    }
                }
                segment.completed = true
                persistSegment(downloadId, segment)
                return
            } catch (ce: CancellationException) {
                persistSegment(downloadId, segment)
                throw ce
            } catch (e: Exception) {
                attempt++
                if (activeUrlIndex + 1 < candidateUrls.size) {
                    activeUrlIndex++
                    activeUrl = candidateUrls[activeUrlIndex]
                }
                if (attempt >= maxAttempts) throw e
                // Exponential Backoff + Jitter
                val baseDelay = (500.0 * 2.0.pow(attempt.toDouble())).toLong().coerceAtMost(15_000L)
                val jitter = Random.nextLong(100L, 650L)
                delay(baseDelay + jitter)
            }
        }
    }

    private suspend fun downloadSingleStream(url: String, outFile: File, headers: Map<String, String>) =
        withContext(Dispatchers.IO) {
            val req = Request.Builder().url(url).apply {
                headers.forEach { (k, v) -> header(k, v) }
            }.build()
            okHttpClient.newCall(req).execute().use { resp ->
                resp.body?.byteStream()?.use { input ->
                    outFile.outputStream().use { output -> input.copyTo(output, 256 * 1024) }
                }
            }
        }

    private suspend fun persistSegment(downloadId: String, seg: SegmentDescriptor) {
        downloadDao.upsertSegment(
            SegmentEntity(
                downloadId = downloadId,
                segmentIndex = seg.index,
                startByte = seg.startByte,
                endByte = seg.endByte,
                downloadedBytes = seg.downloadedBytes,
                completed = seg.completed
            )
        )
    }

    private suspend fun recordCompletionStats(bytes: Long) {
        val current = statsDao.getOnce() ?: StatsEntity()
        statsDao.upsert(
            current.copy(
                totalDownloadedBytes = current.totalDownloadedBytes + bytes,
                totalCompletedFiles = current.totalCompletedFiles + 1
            )
        )
    }

    suspend fun computeFileHash(file: File, algorithm: String = "SHA-256"): String =
        withContext(Dispatchers.IO) {
            val digest = MessageDigest.getInstance(algorithm)
            file.inputStream().use { input ->
                val buf = ByteArray(128 * 1024)
                while (true) {
                    val read = input.read(buf)
                    if (read == -1) break
                    digest.update(buf, 0, read)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        }
}

@AndroidEntryPoint
class AuroraDownloadService : Service() {
    @Inject lateinit var engine: SegmentedDownloadEngine

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureNotificationChannel()
        val notification = buildProgressNotification("Aurora Get", "Lightning segmented engine active", 0)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val action = intent?.action
        val taskId = intent?.getStringExtra(EXTRA_DOWNLOAD_ID)
        if (taskId != null) {
            when (action) {
                ACTION_START -> engine.startOrResume(taskId)
                ACTION_PAUSE -> CoroutineScope(Dispatchers.IO).launch { engine.pause(taskId) }
                ACTION_CANCEL -> CoroutineScope(Dispatchers.IO).launch { engine.cancelAndCleanup(taskId) }
            }
        }
        return START_STICKY
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Aurora Downloads",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun buildProgressNotification(title: String, subtitle: String, progress: Int): Notification {
        val pauseIntent = PendingIntent.getService(
            this, 1, Intent(this, AuroraDownloadService::class.java).setAction(ACTION_PAUSE),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(100, progress, progress == 0)
            .setOngoing(true)
            .addAction(0, "Pause", pauseIntent)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "aurora_downloads_channel"
        const val NOTIFICATION_ID = 7041
        const val ACTION_START = "com.auroraget.action.START_DOWNLOAD"
        const val ACTION_PAUSE = "com.auroraget.action.PAUSE_DOWNLOAD"
        const val ACTION_CANCEL = "com.auroraget.action.CANCEL_DOWNLOAD"
        const val EXTRA_DOWNLOAD_ID = "extra_download_id"

        fun scheduleWithWorkManager(
            context: Context,
            downloadId: String,
            wifiOnly: Boolean,
            chargingOnly: Boolean,
            initialDelayMs: Long
        ) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
                .setRequiresCharging(chargingOnly)
                .setRequiresBatteryNotLow(true)
                .build()

            val request = OneTimeWorkRequestBuilder<ScheduledDownloadWorker>()
                .setConstraints(constraints)
                .setInitialDelay(initialDelayMs.coerceAtLeast(0L), java.util.concurrent.TimeUnit.MILLISECONDS)
                .setInputData(Data.Builder().putString(EXTRA_DOWNLOAD_ID, downloadId).build())
                .build()

            WorkManager.getInstance(context).enqueue(request)
        }
    }
}

class ScheduledDownloadWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val downloadId = inputData.getString(AuroraDownloadService.EXTRA_DOWNLOAD_ID) ?: return Result.failure()
        val intent = Intent(applicationContext, AuroraDownloadService::class.java).apply {
            action = AuroraDownloadService.ACTION_START
            putExtra(AuroraDownloadService.EXTRA_DOWNLOAD_ID, downloadId)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            applicationContext.startForegroundService(intent)
        } else {
            applicationContext.startService(intent)
        }
        return Result.success()
    }
}
