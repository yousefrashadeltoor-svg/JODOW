package com.auroraget.engine.extractors

import android.content.Context
import com.auroraget.core.common.DrmProtectionGuard
import com.auroraget.core.common.FileSizeInfo
import com.auroraget.core.common.MediaCategory
import com.auroraget.core.common.MediaFormatOption
import com.auroraget.core.common.SizePrecision
import com.auroraget.core.common.UrlNormalizer
import com.auroraget.core.network.EncryptedCookieJar
import com.auroraget.core.network.ExactSizeResolver
import com.yausername.aria2c.Aria2c
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import timber.log.Timber
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

data class ExtractionBundle(
    val title: String,
    val author: String? = null,
    val publishedDate: String? = null,
    val durationSeconds: Long? = null,
    val thumbnailUrl: String? = null,
    val previewStreamUrl: String? = null,
    val formats: List<MediaFormatOption> = emptyList(),
    val drmBlockedReason: String? = null
)

/**
 * Wraps yt-dlp via youtubedl-android with aria2c (-x16 -s16 -k1M) external acceleration
 * and background auto-update support for 1800+ supported sites.
 */
@Singleton
class YoutubeDlExtractor @Inject constructor(
    @ApplicationContext private val context: Context,
    private val cookieJar: EncryptedCookieJar
) {
    @Volatile private var initialized = false

    fun initializeEngines() {
        if (initialized) return
        runCatching {
            YoutubeDL.getInstance().init(context)
            Aria2c.getInstance().init(context)
            initialized = true
        }.onFailure {
            Timber.e(it, "Failed to initialize YoutubeDL / Aria2c binaries")
        }
    }

    suspend fun updateYtDlpInBackground(): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            initializeEngines()
            val status = YoutubeDL.getInstance().updateYoutubeDL(context, YoutubeDL.UpdateChannel.STABLE)
            status?.name ?: "UP_TO_DATE"
        }
    }

    suspend fun extractAllFormats(url: String): ExtractionBundle = withContext(Dispatchers.IO) {
        initializeEngines()
        val request = YoutubeDLRequest(url).apply {
            addOption("--no-playlist")
            addOption("--skip-download")
            addOption("--write-subs")
            val cookieHeader = cookieJar.getCookieHeaderForUrl(url)
            if (cookieHeader.isNotBlank()) {
                addOption("--add-header", "Cookie:$cookieHeader")
            }
        }

        val info = YoutubeDL.getInstance().getInfo(request)
        val rawTitle = info.title ?: "Aurora Media"
        val drmCheck = DrmProtectionGuard.detectDrmReason(info.manifestUrl.orEmpty() + info.description.orEmpty())
        if (drmCheck != null) {
            return@withContext ExtractionBundle(title = rawTitle, drmBlockedReason = drmCheck)
        }

        val formats = mutableListOf<MediaFormatOption>()
        val bestAudio = info.formats
            ?.filter { it.acodec != "none" && (it.vcodec == "none" || it.vcodec.isNullOrBlank()) }
            ?.maxByOrNull { it.fileSize }

        info.formats?.forEach { fmt ->
            val directUrl = fmt.url ?: return@forEach
            val isVideo = !fmt.vcodec.isNullOrBlank() && fmt.vcodec != "none"
            val isAudioOnly = !isVideo && !fmt.acodec.isNullOrBlank() && fmt.acodec != "none"
            val category = when {
                isVideo -> MediaCategory.VIDEO
                isAudioOnly -> MediaCategory.AUDIO
                else -> MediaCategory.FILE
            }

            val exactBytes = fmt.fileSize.takeIf { it > 0L }
            val approxBytes = fmt.fileSizeApproximate.takeIf { it > 0L }
            val requiresMerge = isVideo && (fmt.acodec.isNullOrBlank() || fmt.acodec == "none")
            val audioExtraBytes = if (requiresMerge) (bestAudio?.fileSize?.takeIf { it > 0L } ?: bestAudio?.fileSizeApproximate ?: 0L) else 0L

            val sizeInfo = when {
                exactBytes != null -> FileSizeInfo(
                    bytes = exactBytes + audioExtraBytes,
                    precision = if (requiresMerge && bestAudio?.fileSize == 0L) SizePrecision.APPROXIMATE else SizePrecision.EXACT,
                    source = "yt-dlp filesize"
                )
                approxBytes != null -> FileSizeInfo(
                    bytes = approxBytes + audioExtraBytes,
                    precision = SizePrecision.APPROXIMATE,
                    source = "yt-dlp filesize_approx"
                )
                else -> FileSizeInfo(0L, SizePrecision.UNKNOWN)
            }

            val ext = fmt.ext ?: if (isVideo) "mp4" else "m4a"
            val quality = when {
                isVideo && fmt.height > 0 -> "${fmt.height}p"
                isAudioOnly && fmt.abr > 0 -> "${fmt.abr} kbps"
                else -> fmt.formatNote ?: ext.uppercase()
            }

            formats.add(
                MediaFormatOption(
                    id = fmt.formatId ?: "${category.name}_${formats.size}",
                    category = category,
                    title = rawTitle,
                    qualityLabel = quality,
                    extension = ext.uppercase(),
                    codec = if (isVideo) fmt.vcodec.orEmpty().substringBefore(".") else fmt.acodec.orEmpty(),
                    fps = fmt.fps.takeIf { it > 0 },
                    bitrateKbps = (fmt.tbr.takeIf { it > 0 } ?: fmt.abr.takeIf { it > 0 }),
                    isHdr = fmt.formatNote?.contains("HDR", ignoreCase = true) == true,
                    requiresAudioMerge = requiresMerge,
                    mergedAudioFormatId = if (requiresMerge) bestAudio?.formatId else null,
                    downloadUrl = directUrl,
                    audioTrackUrl = if (requiresMerge) bestAudio?.url else null,
                    size = sizeInfo,
                    isHlsOrDash = fmt.protocol?.contains("m3u8", true) == true || fmt.protocol?.contains("dash", true) == true
                )
            )
        }

        // Thumbnails -> Image category
        info.thumbnail?.takeIf { it.isNotBlank() }?.let { thumbUrl ->
            formats.add(
                MediaFormatOption(
                    id = "thumb_maxres",
                    category = MediaCategory.IMAGE,
                    title = "$rawTitle (Cover)",
                    qualityLabel = "Original Cover",
                    extension = "JPG",
                    codec = "JPEG",
                    downloadUrl = thumbUrl,
                    size = FileSizeInfo(0L, SizePrecision.UNKNOWN)
                )
            )
        }

        ExtractionBundle(
            title = rawTitle,
            author = info.uploader,
            publishedDate = info.uploadDate,
            durationSeconds = info.duration.toLong().takeIf { it > 0L },
            thumbnailUrl = info.thumbnail,
            previewStreamUrl = formats.firstOrNull { it.category == MediaCategory.VIDEO && !it.requiresAudioMerge }?.downloadUrl,
            formats = formats
        )
    }

    /**
     * Accelerated yt-dlp download delegating to aria2c with 16 concurrent connections (-x16 -s16 -k1M).
     */
    suspend fun downloadWithAria2c(
        url: String,
        formatSelector: String,
        outputTemplate: File,
        onProgress: (Float, Long) -> Unit
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            initializeEngines()
            val req = YoutubeDLRequest(url).apply {
                addOption("-f", formatSelector)
                addOption("--downloader", "libaria2c.so")
                addOption("--external-downloader-args", "aria2c:-x16 -s16 -k1M")
                addOption("-o", outputTemplate.absolutePath)
            }
            YoutubeDL.getInstance().execute(req) { progress, etaInSeconds, _ ->
                onProgress(progress, etaInSeconds)
            }
            Unit
        }
    }
}

/**
 * Fast-Path Native Extractors (< 1.5s) + Short URL Redirect Resolver + Direct File + Jsoup Fallback.
 */
@Singleton
class FastPathNativeExtractor @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val exactSizeResolver: ExactSizeResolver
) {
    private val directFileExtensions = setOf(
        "mp4", "mkv", "webm", "mov", "avi", "mp3", "m4a", "opus", "ogg", "flac", "wav",
        "jpg", "jpeg", "png", "webp", "avif", "gif", "zip", "rar", "7z", "apk", "pdf", "iso", "tar", "gz"
    )

    suspend fun resolveRedirects(url: String): String = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder().url(url).head().build()
            okHttpClient.newCall(req).execute().use { it.request.url.toString() }
        }.getOrDefault(url)
    }

    suspend fun tryDirectLinkFastPath(url: String): ExtractionBundle? = withContext(Dispatchers.IO) {
        val probe = exactSizeResolver.probeExactMetadata(url)
        val mime = probe.contentType?.lowercase().orEmpty()
        val extFromUrl = probe.finalUrl.substringBefore("?").substringAfterLast(".", "").lowercase()
        val isDirect = extFromUrl in directFileExtensions ||
            mime.startsWith("video/") || mime.startsWith("audio/") ||
            mime.startsWith("image/") || mime.contains("application/octet-stream") ||
            mime.contains("application/zip") || mime.contains("application/pdf") ||
            mime.contains("application/vnd.android.package-archive")

        if (!isDirect) return@withContext null

        val category = when {
            mime.startsWith("video/") || extFromUrl in setOf("mp4", "mkv", "webm", "mov", "avi") -> MediaCategory.VIDEO
            mime.startsWith("audio/") || extFromUrl in setOf("mp3", "m4a", "opus", "ogg", "flac", "wav") -> MediaCategory.AUDIO
            mime.startsWith("image/") || extFromUrl in setOf("jpg", "jpeg", "png", "webp", "avif", "gif") -> MediaCategory.IMAGE
            else -> MediaCategory.FILE
        }

        val name = probe.contentDispositionFileName
            ?: probe.finalUrl.substringBefore("?").substringAfterLast("/").ifBlank { "direct_file.$extFromUrl" }

        ExtractionBundle(
            title = name,
            previewStreamUrl = if (category == MediaCategory.VIDEO || category == MediaCategory.AUDIO) probe.finalUrl else null,
            thumbnailUrl = if (category == MediaCategory.IMAGE) probe.finalUrl else null,
            formats = listOf(
                MediaFormatOption(
                    id = "direct_primary",
                    category = category,
                    title = name,
                    qualityLabel = "Direct Original",
                    extension = extFromUrl.ifBlank { mime.substringAfter("/") }.uppercase(),
                    codec = mime.ifBlank { "Binary" },
                    downloadUrl = probe.finalUrl,
                    size = probe.sizeInfo
                )
            )
        )
    }

    /**
     * Stage 1 OpenGraph + High-Res Favicon + Stage 4 Jsoup/Regex media scraper fallback.
     */
    suspend fun scrapeHtmlMetadataAndMedia(url: String): HtmlScrapeResult = withContext(Dispatchers.IO) {
        val doc = Jsoup.connect(url)
            .userAgent("Mozilla/5.0 (Linux; Android 15; AuroraGet) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36")
            .timeout(8_000)
            .get()

        val title = doc.selectFirst("meta[property=og:title]")?.attr("content")
            ?.ifBlank { null } ?: doc.title().ifBlank { UrlNormalizer.extractDomain(url) }
        val ogImage = doc.selectFirst("meta[property=og:image]")?.attr("abs:content")?.ifBlank { null }
        val ogVideo = doc.selectFirst("meta[property=og:video:secure_url], meta[property=og:video]")?.attr("abs:content")?.ifBlank { null }
        val siteName = doc.selectFirst("meta[property=og:site_name]")?.attr("content")
            ?.ifBlank { null } ?: UrlNormalizer.extractDomain(url)

        // High-res Favicon resolution cascade: apple-touch-icon -> manifest/icon -> og:logo -> /favicon.ico
        val favicon = doc.selectFirst("link[rel*=apple-touch-icon]")?.attr("abs:href")?.ifBlank { null }
            ?: doc.selectFirst("link[rel*=icon][sizes*=192], link[rel*=icon][sizes*=180], link[rel*=icon]")?.attr("abs:href")?.ifBlank { null }
            ?: doc.selectFirst("meta[property=og:logo]")?.attr("abs:content")?.ifBlank { null }
            ?: "https://${UrlNormalizer.extractDomain(url)}/favicon.ico"

        val drmReason = DrmProtectionGuard.detectDrmReason(doc.html().take(60_000))
        val discovered = mutableListOf<MediaFormatOption>()

        if (!ogVideo.isNullOrBlank()) {
            val probed = exactSizeResolver.probeExactMetadata(ogVideo)
            discovered.add(
                MediaFormatOption(
                    id = "og_video",
                    category = MediaCategory.VIDEO,
                    title = title,
                    qualityLabel = "Stream Video",
                    extension = "MP4",
                    codec = "H.264",
                    downloadUrl = ogVideo,
                    size = probed.sizeInfo
                )
            )
        }
        doc.select("video source[src], video[src]").forEachIndexed { idx, el ->
            val src = el.absUrl("src")
            if (src.startsWith("http")) {
                val probed = exactSizeResolver.probeExactMetadata(src)
                discovered.add(
                    MediaFormatOption(
                        id = "html_vid_$idx",
                        category = MediaCategory.VIDEO,
                        title = title,
                        qualityLabel = "Embedded Video ${idx + 1}",
                        extension = src.substringBefore("?").substringAfterLast(".", "mp4").uppercase(),
                        codec = "HTML5",
                        downloadUrl = src,
                        size = probed.sizeInfo
                    )
                )
            }
        }
        doc.select("audio source[src], audio[src]").forEachIndexed { idx, el ->
            val src = el.absUrl("src")
            if (src.startsWith("http")) {
                val probed = exactSizeResolver.probeExactMetadata(src)
                discovered.add(
                    MediaFormatOption(
                        id = "html_aud_$idx",
                        category = MediaCategory.AUDIO,
                        title = title,
                        qualityLabel = "Audio Track ${idx + 1}",
                        extension = src.substringBefore("?").substringAfterLast(".", "mp3").uppercase(),
                        codec = "Audio",
                        downloadUrl = src,
                        size = probed.sizeInfo
                    )
                )
            }
        }
        if (!ogImage.isNullOrBlank()) {
            val probed = exactSizeResolver.probeExactMetadata(ogImage)
            discovered.add(
                MediaFormatOption(
                    id = "og_image",
                    category = MediaCategory.IMAGE,
                    title = "$title Cover",
                    qualityLabel = "HD Cover",
                    extension = ogImage.substringBefore("?").substringAfterLast(".", "jpg").uppercase(),
                    codec = "Image",
                    downloadUrl = ogImage,
                    size = probed.sizeInfo
                )
            )
        }

        HtmlScrapeResult(
            siteName = siteName,
            title = title,
            faviconUrl = favicon,
            thumbnailUrl = ogImage,
            discoveredFormats = discovered,
            drmBlockedReason = drmReason
        )
    }
}

data class HtmlScrapeResult(
    val siteName: String,
    val title: String,
    val faviconUrl: String?,
    val thumbnailUrl: String?,
    val discoveredFormats: List<MediaFormatOption>,
    val drmBlockedReason: String?
)
