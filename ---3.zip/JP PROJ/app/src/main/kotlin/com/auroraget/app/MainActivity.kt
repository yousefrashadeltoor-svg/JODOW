package com.auroraget.app

import android.app.PictureInPictureParams
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Rational
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.auroraget.core.common.AppSettings
import com.auroraget.core.common.UrlNormalizer
import com.auroraget.core.database.SettingsRepository
import com.auroraget.core.designsystem.components.AuroraGlassButton
import com.auroraget.core.designsystem.components.AuroraGlassSurface
import com.auroraget.core.designsystem.components.AuroraGradientHeadline
import com.auroraget.core.designsystem.components.DockDestination
import com.auroraget.core.designsystem.components.FloatingGlassDock
import com.auroraget.core.designsystem.icons.AuroraIcons
import com.auroraget.core.designsystem.shaders.AuroraMeshBackground
import com.auroraget.core.designsystem.theme.AuroraGlassTheme
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.auroraget.feature.browser.BrowserScreen
import com.auroraget.feature.browser.BrowserViewModel
import com.auroraget.feature.compressor.CompressorScreen
import com.auroraget.feature.compressor.CompressorViewModel
import com.auroraget.feature.converter.ConverterScreen
import com.auroraget.feature.converter.ConverterViewModel
import com.auroraget.feature.downloads.DownloadsScreen
import com.auroraget.feature.downloads.DownloadsViewModel
import com.auroraget.feature.files.FilesScreen
import com.auroraget.feature.files.FilesViewModel
import com.auroraget.feature.home.HomeScreen
import com.auroraget.feature.home.HomeViewModel
import com.auroraget.feature.player.AuroraMediaPlayerScreen
import com.auroraget.feature.settings.SettingsScreen
import com.auroraget.feature.settings.SettingsViewModel
import dagger.hilt.android.AndroidEntryPoint
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : FragmentActivity() {
    @Inject lateinit var settingsRepository: SettingsRepository

    private val incomingSharedUrl = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIncomingIntent(intent)

        val outputDir = File(
            getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir,
            "AuroraGet"
        ).apply { mkdirs() }

        setContent {
            val settings by settingsRepository.settingsFlow.collectAsStateWithLifecycle(initialValue = AppSettings())
            val layoutDirection = if (settings.languageCode == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                AuroraGlassTheme(
                    preset = settings.themePreset,
                    isDark = settings.darkMode,
                    amoledPureBlack = settings.amoledPureBlack
                ) {
                    if (!settings.copyrightAccepted) {
                        AuroraOnboardingScreen(
                            onAccept = {
                                CoroutineScope(Dispatchers.IO).launch {
                                    settingsRepository.update { it.copy(copyrightAccepted = true) }
                                }
                            }
                        )
                    } else {
                        AuroraMainShell(
                            sharedUrl = incomingSharedUrl.value,
                            clipboardReader = ::readClipboardUrl,
                            outputDir = outputDir,
                            onEnterPip = ::enterAuroraPip,
                            onBiometricAuth = ::authenticateBiometric
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        val text = when (intent?.action) {
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> intent.dataString
            "com.auroraget.QUICK_PASTE" -> readClipboardUrl()
            else -> null
        }
        val url = text?.let { UrlNormalizer.extractFirstUrl(it) }
        if (!url.isNullOrBlank()) {
            incomingSharedUrl.value = url
        }
    }

    private fun readClipboardUrl(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return null
        val clip = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: return null
        return UrlNormalizer.extractFirstUrl(clip)
    }

    private fun enterAuroraPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
            )
        }
    }

    private fun authenticateBiometric(onSuccess: () -> Unit) {
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(
            this,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Aurora Private Vault")
            .setSubtitle("Verify your identity to access AES-256 encrypted files")
            .setNegativeButtonText("Cancel")
            .build()
        prompt.authenticate(info)
    }
}

@Composable
private fun AuroraOnboardingScreen(onAccept: () -> Unit) {
    val palette = AuroraTheme.colors
    val hazeState = remember { HazeState() }
    Box(modifier = Modifier.fillMaxSize()) {
        AuroraMeshBackground(modifier = Modifier.hazeSource(hazeState))
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            AuroraGlassSurface(hazeState = hazeState, glowActive = true, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    AuroraGradientHeadline(text = "Aurora Get")
                    BasicText(
                        text = "Lightning segmented downloads (up to 32 parallel segments), 1800+ supported sites, AdBlock Sniffer Browser, Smart Lossless/SSIM Compressor, and Pure Aurora Glass UI.",
                        style = AuroraTheme.typography.bodyLarge.copy(color = palette.textPrimary)
                    )
                    BasicText(
                        text = "Legal & Privacy Commitment: 100% Offline-first with zero telemetry. Users are solely responsible for respecting copyright laws. DRM (Widevine/FairPlay/PlayReady) and paywalls are never bypassed.",
                        style = AuroraTheme.typography.bodyMedium.copy(color = palette.textSecondary)
                    )
                    AuroraGlassButton(
                        text = "Accept & Launch Aurora Get",
                        icon = AuroraIcons.Sparkles,
                        primaryGradient = true,
                        onClick = onAccept,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun AuroraMainShell(
    sharedUrl: String?,
    clipboardReader: () -> String?,
    outputDir: File,
    onEnterPip: () -> Unit,
    onBiometricAuth: (() -> Unit) -> Unit
) {
    val hazeState = remember { HazeState() }
    var activeRoute by remember { mutableStateOf("home") }
    var browserTargetUrl by remember { mutableStateOf<String?>(null) }
    var playerTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var toolsSubTab by remember { mutableStateOf("compressor") }

    val homeVm: HomeViewModel = hiltViewModel()
    val downloadsVm: DownloadsViewModel = hiltViewModel()
    val browserVm: BrowserViewModel = hiltViewModel()
    val converterVm: ConverterViewModel = hiltViewModel()
    val compressorVm: CompressorViewModel = hiltViewModel()
    val filesVm: FilesViewModel = hiltViewModel()
    val settingsVm: SettingsViewModel = hiltViewModel()

    LaunchedEffect(sharedUrl) {
        if (!sharedUrl.isNullOrBlank()) {
            activeRoute = "home"
            homeVm.onUrlInputChanged(sharedUrl)
        } else {
            clipboardReader()?.let { homeVm.onClipboardDetected(it) }
        }
    }

    val destinations = remember {
        listOf(
            DockDestination("home", "Home", AuroraIcons.Sparkles),
            DockDestination("downloads", "Downloads", AuroraIcons.DownloadArrow),
            DockDestination("browser", "Browser", AuroraIcons.Globe),
            DockDestination("tools", "Tools", AuroraIcons.CompressArrows),
            DockDestination("files", "Library", AuroraIcons.FolderLibrary),
            DockDestination("settings", "Settings", AuroraIcons.SlidersSettings)
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AuroraMeshBackground(modifier = Modifier.hazeSource(hazeState))

        Box(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
            val activePlayer = playerTarget
            if (activePlayer != null) {
                AuroraMediaPlayerScreen(
                    mediaUrl = activePlayer.first,
                    title = activePlayer.second,
                    hazeState = hazeState,
                    onEnterPip = onEnterPip,
                    onBack = { playerTarget = null }
                )
            } else {
                when (activeRoute) {
                    "home" -> HomeScreen(
                        viewModel = homeVm,
                        hazeState = hazeState,
                        outputDir = outputDir,
                        onOpenInBrowser = { url ->
                            browserTargetUrl = url
                            activeRoute = "browser"
                        },
                        onPreviewStream = { url, title -> playerTarget = url to title },
                        onOpenConverter = { option ->
                            converterVm.setSource(option.downloadUrl)
                            toolsSubTab = "converter"
                            activeRoute = "tools"
                        }
                    )
                    "downloads" -> DownloadsScreen(
                        viewModel = downloadsVm,
                        hazeState = hazeState,
                        onCompressFile = { path ->
                            compressorVm.setSourceFile(path)
                            toolsSubTab = "compressor"
                            activeRoute = "tools"
                        },
                        onConvertFile = { path ->
                            converterVm.setSource(path)
                            toolsSubTab = "converter"
                            activeRoute = "tools"
                        }
                    )
                    "browser" -> BrowserScreen(
                        viewModel = browserVm,
                        hazeState = hazeState,
                        outputDir = outputDir,
                        initialUrl = browserTargetUrl
                    )
                    "tools" -> Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 18.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            AuroraGlassButton(
                                text = "Compressor",
                                primaryGradient = toolsSubTab == "compressor",
                                onClick = { toolsSubTab = "compressor" },
                                modifier = Modifier.weight(1f)
                            )
                            AuroraGlassButton(
                                text = "Converter",
                                primaryGradient = toolsSubTab == "converter",
                                onClick = { toolsSubTab = "converter" },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (toolsSubTab == "compressor") {
                            CompressorScreen(viewModel = compressorVm, hazeState = hazeState)
                        } else {
                            ConverterScreen(viewModel = converterVm, hazeState = hazeState)
                        }
                    }
                    "files" -> FilesScreen(
                        viewModel = filesVm,
                        hazeState = hazeState,
                        onPlayFile = { path, title -> playerTarget = path to title },
                        onRequestBiometricUnlock = onBiometricAuth
                    )
                    "settings" -> SettingsScreen(
                        viewModel = settingsVm,
                        hazeState = hazeState
                    )
                }
            }
        }

        if (playerTarget == null) {
            FloatingGlassDock(
                destinations = destinations,
                selectedRoute = activeRoute,
                onSelect = { activeRoute = it },
                hazeState = hazeState,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}
