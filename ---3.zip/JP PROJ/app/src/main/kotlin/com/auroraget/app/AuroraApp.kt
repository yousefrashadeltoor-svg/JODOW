package com.auroraget.app

import android.app.Application
import com.auroraget.engine.extractors.YoutubeDlExtractor
import com.auroraget.engine.media.FFmpegMediaEngine
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@HiltAndroidApp
class AuroraApp : Application() {
    @Inject lateinit var youtubeDlExtractor: YoutubeDlExtractor
    @Inject lateinit var ffmpegMediaEngine: FFmpegMediaEngine

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        // Background engine warmup + silent yt-dlp auto-update (zero analytics, 100% offline-first)
        appScope.launch {
            youtubeDlExtractor.initializeEngines()
            ffmpegMediaEngine.initialize()
        }
    }
}
