# 𝒥𝒪 DOW — Aurora Get (Android Architecture & Build Guide)

## 1. المخطط المعماري (Clean Architecture + MVI Multi-Module)

```text
                       ┌──────────────────────────┐
                       │           :app           │
                       │ NavHost • Onboarding     │
                       │ Widget • Tile • Shortcuts│
                       └─────────────┬────────────┘
         ┌───────────────────────────┼────────────────────────────┐
         ▼                           ▼                            ▼
┌──────────────────┐      ┌─────────────────────┐      ┌─────────────────────┐
│  :feature:home   │      │ :feature:downloads  │      │  :feature:browser   │
│ :feature:analyzer│      │ :feature:converter  │      │  :feature:compressor│
│ :feature:player  │      │   :feature:files    │      │  :feature:settings  │
└────────┬─────────┘      └──────────┬──────────┘      └──────────┬──────────┘
         │                           │                            │
         ▼                           ▼                            ▼
┌──────────────────┐      ┌─────────────────────┐      ┌─────────────────────┐
│:engine:extractors│      │ :engine:downloader  │      │    :engine:media    │
│ yt-dlp + aria2c  │      │ 8-32 Seg + Stealing │      │ FFmpeg + MediaCodec │
│ Native Fast-Path │      │ Room Resume + Queue │      │ VMAF/SSIM + Lossless│
└────────┬─────────┘      └──────────┬──────────┘      └──────────┬──────────┘
         └───────────────────────────┼────────────────────────────┘
                                     ▼
   ┌───────────────────────────────────────────────────────────────────────┐
   │  :core:designsystem (Zero Material • Foundation/UI • Haze • AGSL)     │
   │  :core:network (OkHttp HTTP/2 + Cronet HTTP/3 + EncryptedCookieJar)   │
   │  :core:database (Room + DataStore) • :core:common (Models + Format)   │
   └───────────────────────────────────────────────────────────────────────┘
```

## 2. تدفق البيانات (Data Flow)
1. **إدخال الرابط (Home / Clipboard / Share Intent / Batch)** ← `LinkAnalyzerPipeline` بـ Debounce 150ms وإلغاء التحليل السابق.
2. **المراحل المتوازية (Stage 0 → 4 عبر `Flow`)**:
   - Stage 0 (<50ms): تطبيع الرابط + استخراج الدومين + فحص DRM.
   - Stage 1 (<300ms): `Preconnect` + `HEAD / Range: bytes=0-0` + Favicon عالي الدقة + OpenGraph.
   - Stage 2 (<1.5s): Native Fast-Path Extractors لأشهر المواقع.
   - Stage 3 (≤4s): `yt-dlp` الكامل (`youtubedl-android`) لجلب جميع الصيغ والأكواد والترجمات.
   - Stage 4: Fallback عبر `Jsoup + Regex` أو توجيه ذكي إلى المتصفح الداخلي (`:feature:browser`) لاصطياد الوسائط وتجاوز تحديات Cloudflare بشكل مشروع داخل WebView.
3. **حساب الحجم الدقيق (`ExactSizeResolver`)**: يتبع التسلسل الإلزامي (HEAD → Range 0-0 → Multi-Range → HLS/DASH Parallel HEAD Pool → yt-dlp filesize) مع التمييز الصارم بين المؤكد والتقريبي (`≈`).
4. **الأزرار الأربعة الذكية (`🎵 صوت | 🖼️ صور | 🎬 فيديو | 📄 ملفات`)**: تُفلتر ديناميكيًا بحيث لا يُعرض أي زر فارغ مطلقًا.
5. **محرك التحميل (`SegmentedDownloadEngine`)**: 8–32 اتصالًا متوازيًا مع Work-Stealing، Pre-allocation عبر `RandomAccessFile`، حفظ حالة الأجزاء في Room، واستكمال موثوق مع التحقق من `ETag` و `If-Range`.

## 3. خطوات البناء والتشغيل
1. افتح مجلد `JP PROJ` في **Android Studio Ladybug (2024.2+)** مع **JDK 21**.
2. تأكد من تنزيل Android SDK 35 (`compileSdk = 35`, `targetSdk = 35`, `minSdk = 24`).
3. نفّذ الفحص الصارم لعدم وجود Material Design:
   ```bash
   ./gradlew :app:dependencies | grep -iE "material|firebase"
   ```
   (يجب ألا يعيد أي نتيجة).
4. شغّل الاختبارات:
   ```bash
   ./gradlew testDebugUnitTest
   ```
5. ابنِ النسخة:
   ```bash
   ./gradlew assembleDebug
   ```

## 4. قائمة العناصر المؤشر عليها بـ `// VERIFY:`
- `io.github.junkfood02.youtubedl-android`: الفرع المُصان نشطًا من `yausername/youtubedl-android` (يتضمن `library` و`ffmpeg` و`aria2c`). تحقق من أحدث رقم إصدار على JitPack عند البناء.
- `org.chromium.net:cronet-embedded`: لمكدس HTTP/3 + QUIC بدون الاعتماد على Google Play Services. يمكن استبداله بـ `com.google.android.gms:play-services-cronet` إن رُغِب في تقليل حجم الـ APK.
- `NativeAdBlockBridge` (`brave/adblock-rust` JNI): يتطلب بناء مكتبة Rust (`libaurora_adblock.so`) عبر `cargo-ndk` لأهداف `arm64-v8a` و`armeabi-v7a`، ويتضمن المشروع محرك قواعد Kotlin مضمّنًا كبديل فوري يعمل تلقائيًا عند غياب ملف `.so`.
- `NativeCompressionBridge` (`mozjpeg` / `oxipng` / `libwebp` / `libavif` / `zopfli` NDK): يتضمن المشروع تنفيذًا احتياطيًا فوريًا عبر `Bitmap` + `MediaCodec` + `FFmpeg` + `java.util.zip` عند عدم توفر ملفات `.so` المترجمة بـ NDK.
- `libtorrent4j` / `PdfBox-Android` / `ML Kit Barcode`: وحدات اختيارية موثقة بعقود واجهة جاهزة للربط في `:engine:extractors` و`:engine:media`.

## 5. قائمة القبول النهائية
- [x] صفر استيرادات أو تبعيات Material Design (مع حظر صريح في `build.gradle.kts` وCI).
- [x] صفر Firebase أو Analytics أو Tracking.
- [x] الأزرار الأربعة الذكية تظهر فقط عند توفر عناصر فعلية من نوعها.
- [x] حساب الحجم الحقيقي مع التمييز الصارم بين المؤكد والتقريبي (`≈`) وعرض البايت الدقيق بالضغط المطوّل.
- [x] محرك تحميل مجزأ (8–32 اتصالًا) مع Work-Stealing واستكمال حقيقي عبر Room.
- [x] متصفح داخلي بـ Sniffer + حجب إعلانات + استخراج `cf_clearance` المشروع لـ Cloudflare.
- [x] أداة تصغير ذكية بوضعي Lossless وVisually Transparent مع فحص VMAF/SSIM ≥ 95 ومقارنة Before/After.
- [x] نظام Aurora Glass مخصص بالكامل مع AGSL Shaders وتوهج Gemini ودعم RTL عربي كامل.
- [x] تنبيه حقوق النشر وحظر تجاوز DRM/Paywall.
