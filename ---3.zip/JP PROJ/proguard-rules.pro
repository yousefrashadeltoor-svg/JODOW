# Aurora Get - R8 / ProGuard Configuration
-keepattributes SourceFile,LineNumberTable,*Annotation*,Signature,InnerClasses,EnclosingMethod

# Kotlinx Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.auroraget.**$$serializer { *; }
-keepclassmembers class com.auroraget.** {
    *** Companion;
}
-keepclasseswithmembers class com.auroraget.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# youtubedl-android (yt-dlp + FFmpeg + aria2c)
-keep class com.yausername.youtubedl_android.** { *; }
-keep class com.yausername.ffmpeg.** { *; }
-keep class com.yausername.aria2c.** { *; }
-keep class com.fasterxml.jackson.** { *; }

# Native JNI Bridges (adblock-rust, mozjpeg, oxipng, libwebp, libavif, zopfli)
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}
-keep class com.auroraget.feature.browser.adblock.NativeAdBlockBridge { *; }
-keep class com.auroraget.engine.media.NativeCompressionBridge { *; }

# Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# OkHttp & Cronet
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class org.chromium.net.** { *; }
-dontwarn org.chromium.net.**

# Media3
-keep class androidx.media3.** { *; }
