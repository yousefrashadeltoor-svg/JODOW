package com.auroraget.core.database

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.auroraget.core.common.AppSettings
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String,
    val url: String,
    val mirrorUrlsJson: String,
    val fileName: String,
    val category: String,
    val siteName: String,
    val domain: String,
    val thumbnailUrl: String?,
    val totalBytes: Long,
    val sizePrecision: String,
    val downloadedBytes: Long,
    val maxConnections: Int,
    val status: String,
    val priority: Int,
    val localFilePath: String?,
    val etag: String?,
    val lastModified: String?,
    val supportsRanges: Boolean,
    val requiresMerge: Boolean,
    val audioSourceUrl: String?,
    val headersJson: String,
    val errorMessage: String?,
    val createdAtMs: Long,
    val scheduledAtMs: Long?,
    val wifiOnly: Boolean,
    val chargingOnly: Boolean
)

@Entity(tableName = "download_segments", primaryKeys = ["downloadId", "segmentIndex"])
data class SegmentEntity(
    val downloadId: String,
    val segmentIndex: Int,
    val startByte: Long,
    val endByte: Long,
    val downloadedBytes: Long,
    val completed: Boolean
)

@Entity(tableName = "analysis_cache")
data class AnalysisCacheEntity(
    @PrimaryKey val normalizedUrl: String,
    val payloadJson: String,
    val cachedAtMs: Long,
    val expiresAtMs: Long
)

@Entity(tableName = "vault_items")
data class VaultEntity(
    @PrimaryKey val id: String,
    val displayName: String,
    val encryptedPath: String,
    val mimeType: String,
    val originalBytes: Long,
    val sha256: String,
    val addedAtMs: Long
)

@Entity(tableName = "adblock_exceptions")
data class AdBlockExceptionEntity(
    @PrimaryKey val domain: String,
    val addedAtMs: Long
)

@Entity(tableName = "usage_stats")
data class StatsEntity(
    @PrimaryKey val id: Int = 1,
    val totalDownloadedBytes: Long = 0L,
    val totalSavedByCompressionBytes: Long = 0L,
    val totalCompletedFiles: Int = 0,
    val totalAdsBlocked: Long = 0L
)

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY priority DESC, createdAtMs DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE status IN ('DOWNLOADING', 'QUEUED')")
    suspend fun getActiveOrQueued(): List<DownloadEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DownloadEntity)

    @Query("UPDATE downloads SET status = :status, errorMessage = :error WHERE id = :id")
    suspend fun updateStatus(id: String, status: String, error: String? = null)

    @Query("UPDATE downloads SET downloadedBytes = :downloaded, totalBytes = :total WHERE id = :id")
    suspend fun updateProgress(id: String, downloaded: Long, total: Long)

    @Query("UPDATE downloads SET priority = :priority WHERE id = :id")
    suspend fun updatePriority(id: String, priority: Int)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT * FROM download_segments WHERE downloadId = :downloadId ORDER BY segmentIndex ASC")
    suspend fun getSegments(downloadId: String): List<SegmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSegments(segments: List<SegmentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSegment(segment: SegmentEntity)

    @Query("DELETE FROM download_segments WHERE downloadId = :downloadId")
    suspend fun deleteSegments(downloadId: String)
}

@Dao
interface AnalysisCacheDao {
    @Query("SELECT * FROM analysis_cache WHERE normalizedUrl = :url AND expiresAtMs > :nowMs LIMIT 1")
    suspend fun getValid(url: String, nowMs: Long): AnalysisCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: AnalysisCacheEntity)

    @Query("DELETE FROM analysis_cache WHERE expiresAtMs <= :nowMs")
    suspend fun pruneExpired(nowMs: Long)
}

@Dao
interface VaultDao {
    @Query("SELECT * FROM vault_items ORDER BY addedAtMs DESC")
    fun observeAll(): Flow<List<VaultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: VaultEntity)

    @Query("DELETE FROM vault_items WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface AdBlockExceptionDao {
    @Query("SELECT domain FROM adblock_exceptions")
    fun observeExceptions(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun allowDomain(entity: AdBlockExceptionEntity)

    @Query("DELETE FROM adblock_exceptions WHERE domain = :domain")
    suspend fun removeDomain(domain: String)
}

@Dao
interface StatsDao {
    @Query("SELECT * FROM usage_stats WHERE id = 1")
    fun observeStats(): Flow<StatsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(stats: StatsEntity)

    @Query("SELECT * FROM usage_stats WHERE id = 1")
    suspend fun getOnce(): StatsEntity?
}

@Database(
    entities = [
        DownloadEntity::class,
        SegmentEntity::class,
        AnalysisCacheEntity::class,
        VaultEntity::class,
        AdBlockExceptionEntity::class,
        StatsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AuroraDatabase : RoomDatabase() {
    abstract fun downloadDao(): DownloadDao
    abstract fun analysisCacheDao(): AnalysisCacheDao
    abstract fun vaultDao(): VaultDao
    abstract fun adBlockExceptionDao(): AdBlockExceptionDao
    abstract fun statsDao(): StatsDao
}

private val Context.auroraDataStore: DataStore<Preferences> by preferencesDataStore(name = "aurora_settings")

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val settingsKey = stringPreferencesKey("app_settings_v1")

    val settingsFlow: Flow<AppSettings> = context.auroraDataStore.data.map { prefs ->
        val raw = prefs[settingsKey]
        if (raw.isNullOrBlank()) AppSettings()
        else runCatching { json.decodeFromString<AppSettings>(raw) }.getOrDefault(AppSettings())
    }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.auroraDataStore.edit { prefs ->
            val current = prefs[settingsKey]?.let {
                runCatching { json.decodeFromString<AppSettings>(it) }.getOrNull()
            } ?: AppSettings()
            prefs[settingsKey] = json.encodeToString(transform(current))
        }
    }

    suspend fun exportJson(current: AppSettings): String = json.encodeToString(current)

    suspend fun importJson(raw: String): Result<AppSettings> = runCatching {
        val parsed = json.decodeFromString<AppSettings>(raw)
        update { parsed }
        parsed
    }
}

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides
    @Singleton
    fun provideAuroraDatabase(@ApplicationContext context: Context): AuroraDatabase {
        return Room.databaseBuilder(
            context,
            AuroraDatabase::class.java,
            "aurora_get.db"
        ).fallbackToDestructiveMigration().build()
    }

    @Provides fun provideDownloadDao(db: AuroraDatabase): DownloadDao = db.downloadDao()
    @Provides fun provideAnalysisCacheDao(db: AuroraDatabase): AnalysisCacheDao = db.analysisCacheDao()
    @Provides fun provideVaultDao(db: AuroraDatabase): VaultDao = db.vaultDao()
    @Provides fun provideAdBlockExceptionDao(db: AuroraDatabase): AdBlockExceptionDao = db.adBlockExceptionDao()
    @Provides fun provideStatsDao(db: AuroraDatabase): StatsDao = db.statsDao()
}
