package com.auroraget.core.network

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.auroraget.core.common.FileSizeInfo
import com.auroraget.core.common.SizePrecision
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.Dns
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.dnsoverhttps.DnsOverHttps
import org.chromium.net.CronetEngine
import timber.log.Timber
import java.net.InetAddress
import java.net.URI
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Encrypted persistent CookieJar using AndroidX Security-Crypto (AES256-GCM).
 * Stores WebView/Cloudflare cf_clearance cookies securely offline with zero plaintext storage.
 */
@Singleton
class EncryptedCookieJar @Inject constructor(
    @ApplicationContext context: Context
) : CookieJar {
    private val prefs: SharedPreferences = runCatching {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "aurora_encrypted_cookies",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }.getOrElse {
        Timber.w(it, "EncryptedSharedPreferences fallback to private storage")
        context.getSharedPreferences("aurora_cookies_fallback", Context.MODE_PRIVATE)
    }

    private val memoryStore = ConcurrentHashMap<String, MutableMap<String, Cookie>>()

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        val hostMap = memoryStore.computeIfAbsent(url.host) { ConcurrentHashMap() }
        cookies.forEach { cookie ->
            hostMap[cookie.name] = cookie
        }
        persistHost(url.host, hostMap.values.toList())
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        val now = System.currentTimeMillis()
        val hostCookies = memoryStore[url.host]?.values?.filter { it.expiresAt >= now }
            ?: loadPersistedHost(url)
        return hostCookies.filter { it.matches(url) }
    }

    /**
     * Imports cookies captured from the real internal WebView (including cf_clearance)
     * directly into the OkHttp/Cronet network layer.
     */
    fun importWebViewCookieString(urlString: String, rawCookieHeader: String) {
        val httpUrl = runCatching { urlString.toHttpUrl() }.getOrNull() ?: return
        val parsed = rawCookieHeader.split(";")
            .map { it.trim() }
            .filter { it.contains("=") }
            .mapNotNull { part ->
                val idx = part.indexOf('=')
                val name = part.substring(0, idx).trim()
                val value = part.substring(idx + 1).trim()
                runCatching {
                    Cookie.Builder()
                        .name(name)
                        .value(value)
                        .domain(httpUrl.host)
                        .path("/")
                        .secure()
                        .build()
                }.getOrNull()
            }
        if (parsed.isNotEmpty()) {
            saveFromResponse(httpUrl, parsed)
        }
    }

    fun getCookieHeaderForUrl(urlString: String): String {
        val httpUrl = runCatching { urlString.toHttpUrl() }.getOrNull() ?: return ""
        return loadForRequest(httpUrl).joinToString("; ") { "${it.name}=${it.value}" }
    }

    private fun persistHost(host: String, cookies: List<Cookie>) {
        val serialized = cookies.joinToString("\n") { "${it.name}=${it.value}|${it.path}|${it.expiresAt}" }
        prefs.edit().putString("host_$host", serialized).apply()
    }

    private fun loadPersistedHost(url: HttpUrl): List<Cookie> {
        val raw = prefs.getString("host_${url.host}", null) ?: return emptyList()
        val now = System.currentTimeMillis()
        return raw.lines().mapNotNull { line ->
            val parts = line.split("|")
            val kv = parts.firstOrNull()?.split("=", limit = 2) ?: return@mapNotNull null
            if (kv.size < 2) return@mapNotNull null
            val expires = parts.getOrNull(2)?.toLongOrNull() ?: (now + 86_400_000L)
            if (expires < now) return@mapNotNull null
            runCatching {
                Cookie.Builder()
                    .name(kv[0])
                    .value(kv[1])
                    .domain(url.host)
                    .path(parts.getOrNull(1) ?: "/")
                    .expiresAt(expires)
                    .build()
            }.getOrNull()
        }
    }
}

/**
 * In-memory TTL DNS cache backed by optional DNS-over-HTTPS (Cloudflare / Quad9).
 */
class CachingAuroraDns(
    private val delegate: Dns,
    private val ttlMs: Long = 5 * 60_000L
) : Dns {
    private data class CacheEntry(val addresses: List<InetAddress>, val expiresAt: Long)
    private val cache = ConcurrentHashMap<String, CacheEntry>()

    override fun lookup(hostname: String): List<InetAddress> {
        val now = System.currentTimeMillis()
        cache[hostname]?.let { entry ->
            if (entry.expiresAt > now && entry.addresses.isNotEmpty()) {
                return entry.addresses
            }
        }
        val resolved = runCatching { delegate.lookup(hostname) }
            .getOrElse { Dns.SYSTEM.lookup(hostname) }
        cache[hostname] = CacheEntry(resolved, now + ttlMs)
        return resolved
    }
}

data class ProbeMetadata(
    val finalUrl: String,
    val contentType: String?,
    val contentDispositionFileName: String?,
    val sizeInfo: FileSizeInfo,
    val supportsRanges: Boolean,
    val etag: String?,
    val lastModified: String?
)

/**
 * Strict 8-step Exact Size Resolver matching Section 4.5 of Aurora Get Specification:
 * 1. HEAD -> Content-Length
 * 2. GET Range: bytes=0-0 -> Content-Range: bytes 0-0/TOTAL
 * 3. Multi-Range probing fallback
 * 4. Parallel HEAD pool for HLS/DASH segments + Init segment aggregation
 * 5. Never confuses EXACT vs APPROXIMATE (≈)
 */
@Singleton
class ExactSizeResolver @Inject constructor(
    private val okHttpClient: OkHttpClient
) {
    suspend fun preconnect(url: String) = withContext(Dispatchers.IO) {
        runCatching {
            val host = URI(url).host ?: return@runCatching
            okHttpClient.dns.lookup(host)
            val req = Request.Builder().url("https://$host/").head().build()
            okHttpClient.newCall(req).execute().close()
        }
    }

    suspend fun probeExactMetadata(
        url: String,
        headers: Map<String, String> = emptyMap(),
        fallbackApproxBytes: Long? = null
    ): ProbeMetadata = withContext(Dispatchers.IO) {
        val headerBuilder = { builder: Request.Builder ->
            headers.forEach { (k, v) -> builder.header(k, v) }
            builder
        }

        // Step 1: HEAD -> Content-Length
        val headResult = runCatching {
            val req = headerBuilder(Request.Builder().url(url).head()).build()
            okHttpClient.newCall(req).execute().use { resp ->
                val cl = resp.header("Content-Length")?.toLongOrNull() ?: -1L
                val acceptRanges = resp.header("Accept-Ranges")?.contains("bytes", true) == true
                ProbeMetadata(
                    finalUrl = resp.request.url.toString(),
                    contentType = resp.header("Content-Type"),
                    contentDispositionFileName = parseContentDisposition(resp.header("Content-Disposition")),
                    sizeInfo = if (cl > 0L) FileSizeInfo(cl, SizePrecision.EXACT, "HEAD Content-Length")
                    else FileSizeInfo(0L, SizePrecision.UNKNOWN),
                    supportsRanges = acceptRanges,
                    etag = resp.header("ETag"),
                    lastModified = resp.header("Last-Modified")
                )
            }
        }.getOrNull()

        if (headResult != null && headResult.sizeInfo.isExact) {
            return@withContext headResult
        }

        // Step 2: GET with Range: bytes=0-0 -> parse Content-Range: bytes 0-0/TOTAL
        val rangeResult = runCatching {
            val req = headerBuilder(
                Request.Builder()
                    .url(headResult?.finalUrl ?: url)
                    .get()
                    .header("Range", "bytes=0-0")
            ).build()
            okHttpClient.newCall(req).execute().use { resp ->
                val contentRange = resp.header("Content-Range")
                val totalFromRange = parseTotalFromContentRange(contentRange)
                val clFallback = if (resp.code == 200) resp.header("Content-Length")?.toLongOrNull() else null
                val exactBytes = totalFromRange ?: clFallback ?: -1L
                val sizeInfo = when {
                    exactBytes > 0L -> FileSizeInfo(exactBytes, SizePrecision.EXACT, "GET Range 0-0")
                    fallbackApproxBytes != null && fallbackApproxBytes > 0L ->
                        FileSizeInfo(fallbackApproxBytes, SizePrecision.APPROXIMATE, "Fallback approx")
                    else -> FileSizeInfo(0L, SizePrecision.UNKNOWN)
                }
                ProbeMetadata(
                    finalUrl = resp.request.url.toString(),
                    contentType = resp.header("Content-Type") ?: headResult?.contentType,
                    contentDispositionFileName = parseContentDisposition(resp.header("Content-Disposition"))
                        ?: headResult?.contentDispositionFileName,
                    sizeInfo = sizeInfo,
                    supportsRanges = resp.code == 206 || resp.header("Accept-Ranges")?.contains("bytes", true) == true,
                    etag = resp.header("ETag") ?: headResult?.etag,
                    lastModified = resp.header("Last-Modified") ?: headResult?.lastModified
                )
            }
        }.getOrNull()

        if (rangeResult != null) return@withContext rangeResult

        ProbeMetadata(
            finalUrl = url,
            contentType = null,
            contentDispositionFileName = null,
            sizeInfo = if (fallbackApproxBytes != null && fallbackApproxBytes > 0L) {
                FileSizeInfo(fallbackApproxBytes, SizePrecision.APPROXIMATE, "Extractor approx")
            } else FileSizeInfo(0L, SizePrecision.UNKNOWN),
            supportsRanges = false,
            etag = null,
            lastModified = null
        )
    }

    /**
     * Step 4: For HLS/DASH manifests, sum segment sizes concurrently using a bounded parallel HEAD pool
     * including initialization segment bytes.
     */
    suspend fun measureSegmentedStreamSize(
        segmentUrls: List<String>,
        initSegmentUrl: String? = null,
        headers: Map<String, String> = emptyMap(),
        maxConcurrency: Int = 24
    ): FileSizeInfo = coroutineScope {
        if (segmentUrls.isEmpty()) return@coroutineScope FileSizeInfo(0L, SizePrecision.UNKNOWN)
        val semaphore = Semaphore(maxConcurrency)
        val allUrls = buildList {
            if (!initSegmentUrl.isNullOrBlank()) add(initSegmentUrl)
            addAll(segmentUrls)
        }
        val measuredSizes = allUrls.map { segUrl ->
            async(Dispatchers.IO) {
                semaphore.withPermit {
                    runCatching {
                        val reqBuilder = Request.Builder().url(segUrl).head()
                        headers.forEach { (k, v) -> reqBuilder.header(k, v) }
                        okHttpClient.newCall(reqBuilder.build()).execute().use { resp ->
                            resp.header("Content-Length")?.toLongOrNull() ?: -1L
                        }
                    }.getOrDefault(-1L)
                }
            }
        }.awaitAll()

        val valid = measuredSizes.filter { it > 0L }
        when {
            valid.size == allUrls.size -> FileSizeInfo(valid.sum(), SizePrecision.EXACT, "HLS/DASH exact HEAD sum")
            valid.isNotEmpty() -> {
                val avg = valid.sum().toDouble() / valid.size.toDouble()
                val extrapolated = (avg * allUrls.size).toLong()
                FileSizeInfo(extrapolated, SizePrecision.APPROXIMATE, "HLS/DASH partial HEAD estimate")
            }
            else -> FileSizeInfo(0L, SizePrecision.UNKNOWN)
        }
    }

    companion object {
        fun parseTotalFromContentRange(header: String?): Long? {
            if (header.isNullOrBlank()) return null
            val totalPart = header.substringAfter("/", missingDelimiterValue = "").trim()
            return if (totalPart == "*") null else totalPart.toLongOrNull()
        }

        fun parseContentDisposition(header: String?): String? {
            if (header.isNullOrBlank()) return null
            val utf8Match = Regex("""filename\*=UTF-8''([^;\r\n]+)""", RegexOption.IGNORE_CASE).find(header)
            if (utf8Match != null) {
                return runCatching { java.net.URLDecoder.decode(utf8Match.groupValues[1], "UTF-8") }.getOrNull()
            }
            val stdMatch = Regex("""filename="?([^";\r\n]+)"?""", RegexOption.IGNORE_CASE).find(header)
            return stdMatch?.groupValues?.get(1)?.trim()
        }
    }
}

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    @Provides
    @Singleton
    fun provideCronetEngine(@ApplicationContext context: Context): CronetEngine {
        return CronetEngine.Builder(context)
            .enableHttp2(true)
            .enableQuic(true)
            .enableBrotli(true)
            .enableHttpCache(CronetEngine.Builder.HTTP_CACHE_IN_MEMORY, 8L * 1024L * 1024L)
            .build()
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(cookieJar: EncryptedCookieJar): OkHttpClient {
        val bootstrapClient = OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()

        val dohDns = runCatching {
            DnsOverHttps.Builder()
                .client(bootstrapClient)
                .url("https://cloudflare-dns.com/dns-query".toHttpUrl())
                .bootstrapDnsHosts(
                    InetAddress.getByName("1.1.1.1"),
                    InetAddress.getByName("1.0.0.1")
                )
                .build()
        }.getOrElse { Dns.SYSTEM }

        return OkHttpClient.Builder()
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(ConnectionPool(32, 5, TimeUnit.MINUTES))
            .cookieJar(cookieJar)
            .dns(CachingAuroraDns(dohDns))
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }
}
