package com.auroraget.core.network

import com.auroraget.core.common.ByteFormatter
import com.auroraget.core.common.FileSizeInfo
import com.auroraget.core.common.SizePrecision
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExactSizeResolverTest {
    @Test
    fun parseContentRange_extractsTotalBytesAccurately() {
        assertEquals(148_372_910L, ExactSizeResolver.parseTotalFromContentRange("bytes 0-0/148372910"))
        assertNull(ExactSizeResolver.parseTotalFromContentRange("bytes 0-0/*"))
        assertNull(ExactSizeResolver.parseTotalFromContentRange(null))
    }

    @Test
    fun parseContentDisposition_handlesUtf8AndStandardFilenames() {
        assertEquals(
            "aurora_video.mp4",
            ExactSizeResolver.parseContentDisposition("attachment; filename=\"aurora_video.mp4\"")
        )
        assertEquals(
            "ملف_أورورا.mp4",
            ExactSizeResolver.parseContentDisposition("attachment; filename*=UTF-8''%D9%85%D9%84%D9%81_%D8%A3%D9%88%D8%B1%D9%88%D8%B1%D8%A7.mp4")
        )
    }

    @Test
    fun byteFormatter_strictlySeparatesExactAndApproximateSizes() {
        val exact = FileSizeInfo(148_372_910L, SizePrecision.EXACT)
        val approx = FileSizeInfo(148_372_910L, SizePrecision.APPROXIMATE)

        val exactDisplay = ByteFormatter.formatDisplay(exact)
        val approxDisplay = ByteFormatter.formatDisplay(approx)

        assertFalse(exactDisplay.contains("≈"))
        assertTrue(approxDisplay.startsWith("≈ "))
        assertEquals("148,372,910 bytes (141.5 MiB)", ByteFormatter.formatLongPressExact(exact))
    }
}
