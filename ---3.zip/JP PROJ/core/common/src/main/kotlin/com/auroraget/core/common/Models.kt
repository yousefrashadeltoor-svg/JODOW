package com.auroraget.core.common

import kotlinx.serialization.Serializable

@Serializable
enum class MediaCategory {
    AUDIO,
    IMAGE,
    VIDEO,
    FILE
}

@Serializable
enum class SizePrecision {
    EXACT,
    APPROXIMATE,
    UNKNOWN
}

@Serializable
data class FileSizeInfo(
    val bytes: Long,
    val precision: SizePrecision,
    val source: String = ""
) {
    val isKnown: Boolean get() = bytes > 0L && precision != SizePrecision.UNKNOWN
    val isExact: Boolean get() = precision == SizePrecision.EXACT && bytes > 0L
}

@Serializable
data class MediaFormatOption(
    val id: String,
    val category: MediaCategory,
    val title: String,
    val qualityLabel: String,
    val extension: String,
    val codec: String,
    val fps: Int? = null,
    val bitrateKbps: Int? = null,
    val isHdr: Boolean = false,
    val requiresAudioMerge: Boolean = false,
    val mergedAudioFormatId: String? = null,
    val hasWatermark: Boolean? = null,
    val downloadUrl: String,
    val audioTrackUrl: String? = null,
    val size: FileSizeInfo,
    val headers: Map<String, String> = emptyMap(),
    val isHlsOrDash: Boolean = false
)

@Serializable
data class AnalysisResult(
    val originalUrl: String,
    val normalizedUrl: String,
    val domain: String,
    val siteName: String,
    val faviconUrl: String?,
    val title: String,
    val suggestedFileName: String,
    val thumbnailUrl: String?,
    val previewStreamUrl: String?,
    val primaryBadge: String,
    val durationSeconds: Long? = null,
    val author: String? = null,
    val publishedDate: String? = null,
    val dominantColorHex: Long? = null,
    val primarySize: FileSizeInfo = FileSizeInfo(0L, SizePrecision.UNKNOWN),
    val formats: List<MediaFormatOption> = emptyList(),
    val stageCompleted: Int = 0,
    val isComplete: Boolean = false,
    val requiresWebViewSniffer: Boolean = false,
    val drmBlockedReason: String? = null,
    val analyzedAtEpochMs: Long = System.currentTimeMillis()
) {
    fun formatsFor(category: MediaCategory): List<MediaFormatOption> =
        formats.filter { it.category == category }

    val availableCategories: List<MediaCategory>
        get() = listOf(
            MediaCategory.AUDIO,
            MediaCategory.IMAGE,
            MediaCategory.VIDEO,
            MediaCategory.FILE
        ).filter { category -> formats.any { it.category == category } }
}

@Serializable
enum class DownloadStatus {
    QUEUED,
    ANALYZING,
    DOWNLOADING,
    MERGING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

@Serializable
data class DownloadSegmentState(
    val index: Int,
    val startByte: Long,
    val endByte: Long,
    val downloadedBytes: Long,
    val completed: Boolean
)

@Serializable
data class DownloadTask(
    val id: String,
    val url: String,
    val mirrorUrls: List<String> = emptyList(),
    val fileName: String,
    val category: MediaCategory,
    val siteName: String,
    val domain: String,
    val thumbnailUrl: String? = null,
    val totalSize: FileSizeInfo,
    val downloadedBytes: Long = 0L,
    val speedBytesPerSec: Long = 0L,
    val speedHistory: List<Long> = emptyList(),
    val activeConnections: Int = 0,
    val maxConnections: Int = 16,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val priority: Int = 0,
    val localFilePath: String? = null,
    val etag: String? = null,
    val lastModified: String? = null,
    val supportsRanges: Boolean = true,
    val requiresMerge: Boolean = false,
    val audioSourceUrl: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val errorMessage: String? = null,
    val createdAtMs: Long = System.currentTimeMillis(),
    val scheduledAtMs: Long? = null,
    val wifiOnly: Boolean = false,
    val chargingOnly: Boolean = false
) {
    val progress: Float
        get() = if (totalSize.bytes > 0L) {
            (downloadedBytes.toFloat() / totalSize.bytes.toFloat()).coerceIn(0f, 1f)
        } else 0f

    val etaSeconds: Long?
        get() = if (speedBytesPerSec > 0L && totalSize.bytes > downloadedBytes) {
            (totalSize.bytes - downloadedBytes) / speedBytesPerSec
        } else null
}

@Serializable
enum class CompressionMode {
    LOSSLESS,
    VISUALLY_TRANSPARENT
}

@Serializable
enum class AuroraThemePreset {
    AURORA,
    OCEAN,
    SUNSET,
    EMERALD,
    MONO,
    NEON
}

@Serializable
data class AppSettings(
    val themePreset: AuroraThemePreset = AuroraThemePreset.AURORA,
    val darkMode: Boolean = true,
    val amoledPureBlack: Boolean = true,
    val dynamicCoverColor: Boolean = true,
    val languageCode: String = "ar",
    val maxConcurrentDownloads: Int = 3,
    val defaultSegments: Int = 16,
    val speedLimitKbps: Int = 0,
    val wifiOnly: Boolean = false,
    val pauseOnLowBattery: Boolean = true,
    val clipboardAutoDetect: Boolean = true,
    val dohEnabled: Boolean = true,
    val dohProviderUrl: String = "https://cloudflare-dns.com/dns-query",
    val adBlockEnabled: Boolean = true,
    val blockCookieBanners: Boolean = false,
    val autoUpdateYtDlp: Boolean = true,
    val autoUpdateAdBlockLists: Boolean = true,
    val dataSaverMode: Boolean = false,
    val gyroscopeParallax: Boolean = false,
    val hapticFeedback: Boolean = true,
    val copyrightAccepted: Boolean = false
)
