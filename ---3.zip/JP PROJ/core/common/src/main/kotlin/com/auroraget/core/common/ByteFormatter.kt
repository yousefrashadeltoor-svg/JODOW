package com.auroraget.core.common

import java.net.URI
import java.text.DecimalFormat
import java.text.NumberFormat
import java.util.Locale

object ByteFormatter {
    private val decimalFormat = DecimalFormat("0.##")

    /**
     * Formats a FileSizeInfo with strict visual separation between exact sizes (no prefix)
     * and approximate sizes (always prefixed with ≈). Never conflates the two.
     */
    fun formatDisplay(info: FileSizeInfo, unknownLabel: String = "—"): String {
        if (!info.isKnown) return unknownLabel
        val formatted = formatHumanBinary(info.bytes)
        return when (info.precision) {
            SizePrecision.EXACT -> formatted
            SizePrecision.APPROXIMATE -> "≈ $formatted"
            SizePrecision.UNKNOWN -> unknownLabel
        }
    }

    /**
     * Returns exact byte-accurate string for long-press inspection:
     * Example: "148,372,910 bytes (141.5 MiB)"
     */
    fun formatLongPressExact(info: FileSizeInfo): String {
        if (!info.isKnown) return "Size unavailable"
        val exactNumber = NumberFormat.getNumberInstance(Locale.US).format(info.bytes)
        val human = formatHumanBinary(info.bytes)
        val prefix = if (info.precision == SizePrecision.APPROXIMATE) "≈ " else ""
        return "$prefix$exactNumber bytes ($human)"
    }

    fun formatHumanBinary(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val units = arrayOf("B", "KiB", "MiB", "GiB", "TiB")
        var value = bytes.toDouble()
        var unitIdx = 0
        while (value >= 1024.0 && unitIdx < units.lastIndex) {
            value /= 1024.0
            unitIdx++
        }
        return "${decimalFormat.format(value)} ${units[unitIdx]}"
    }

    fun formatSpeed(bytesPerSec: Long): String {
        if (bytesPerSec <= 0L) return "0 B/s"
        return "${formatHumanBinary(bytesPerSec)}/s"
    }

    fun formatDuration(seconds: Long?): String {
        if (seconds == null || seconds <= 0L) return ""
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }
}

object UrlNormalizer {
    private val trackingParams = setOf(
        "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
        "fbclid", "gclid", "si", "igshid", "feature", "ref_src", "ref_url"
    )

    fun extractFirstUrl(rawText: String): String? {
        val regex = Regex("""https?://[^\s<>"'\)]+""", RegexOption.IGNORE_CASE)
        return regex.find(rawText.trim())?.value
    }

    fun extractAllUrls(rawText: String): List<String> {
        val regex = Regex("""https?://[^\s<>"'\)]+""", RegexOption.IGNORE_CASE)
        return regex.findAll(rawText).map { normalize(it.value) }.distinct().toList()
    }

    fun normalize(rawUrl: String): String {
        val trimmed = rawUrl.trim()
        val withScheme = if (!trimmed.startsWith("http://", true) && !trimmed.startsWith("https://", true)) {
            "https://$trimmed"
        } else trimmed
        return try {
            val uri = URI(withScheme)
            val cleanQuery = uri.rawQuery?.split("&")
                ?.filter { pair ->
                    val key = pair.substringBefore("=").lowercase(Locale.US)
                    key.isNotBlank() && key !in trackingParams
                }
                ?.joinToString("&")
                ?.takeIf { it.isNotEmpty() }
            URI(
                uri.scheme?.lowercase(Locale.US) ?: "https",
                uri.userInfo,
                uri.host?.lowercase(Locale.US),
                uri.port,
                uri.path,
                cleanQuery,
                null
            ).toString()
        } catch (_: Exception) {
            withScheme
        }
    }

    fun extractDomain(url: String): String {
        return try {
            val host = URI(normalize(url)).host ?: return "unknown"
            host.removePrefix("www.").removePrefix("m.")
        } catch (_: Exception) {
            "unknown"
        }
    }

    fun sanitizeFileName(raw: String, fallbackExt: String? = null): String {
        val cleaned = raw
            .replace(Regex("""[\\/:*?"<>|\r\n\t]+"""), "_")
            .trim()
            .take(140)
            .ifBlank { "aurora_download_${System.currentTimeMillis()}" }
        return if (fallbackExt != null && !cleaned.endsWith(".$fallbackExt", ignoreCase = true)) {
            "$cleaned.$fallbackExt"
        } else cleaned
    }
}

/**
 * Strictly enforces legal boundaries: refuses DRM-protected (Widevine/FairPlay/PlayReady)
 * streams and paywalled endpoints without attempting circumvention.
 */
object DrmProtectionGuard {
    private val drmIndicators = listOf(
        "widevine", "fairplay", "playready", "clearkey",
        "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed",
        "urn:uuid:9a04f079-9840-4286-ab92-e65be0885f95",
        "com.apple.fps", "skd://", "SAMPLE-AES-CTR", "CONTENTPROTECTION"
    )

    fun detectDrmReason(manifestOrMetadata: String): String? {
        val upper = manifestOrMetadata.uppercase(Locale.US)
        val matched = drmIndicators.firstOrNull { upper.contains(it.uppercase(Locale.US)) }
        return if (matched != null) {
            "DRM-protected content detected ($matched). Aurora Get does not bypass DRM or paywalls."
        } else null
    }
}
