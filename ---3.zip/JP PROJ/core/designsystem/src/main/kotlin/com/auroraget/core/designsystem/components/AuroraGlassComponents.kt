package com.auroraget.core.designsystem.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.auroraget.core.designsystem.theme.AuroraTheme
import com.valentinilk.shimmer.shimmer
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.hazeEffect
import kotlinx.coroutines.delay

/**
 * Real Glassmorphism Surface built purely on Compose Foundation/UI + chrisbanes/haze.
 * Features: Real-time backdrop blur, 1dp specular gradient border, optional Gemini rotating sweep glow.
 */
@Composable
fun AuroraGlassSurface(
    modifier: Modifier = Modifier,
    hazeState: HazeState? = null,
    shape: Shape = AuroraTheme.shapes.card,
    glowActive: Boolean = false,
    elevated: Boolean = false,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val palette = AuroraTheme.colors
    val infinite = rememberInfiniteTransition(label = "gemini_sweep")
    val sweepAngle by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep_angle"
    )

    val glassBase = if (elevated) palette.glassSurfaceStrong else palette.glassSurface
    val borderBrush = Brush.verticalGradient(
        colors = listOf(palette.glassBorderTop, palette.glassBorderBottom)
    )

    val hazeModifier = if (hazeState != null) {
        Modifier.hazeEffect(
            state = hazeState,
            style = HazeStyle(
                backgroundColor = palette.background.copy(alpha = 0.55f),
                blurRadius = 24.dp,
                noiseFactor = 0.04f
            )
        )
    } else Modifier

    Box(
        modifier = modifier
            .shadow(
                elevation = if (glowActive) 18.dp else 8.dp,
                shape = shape,
                ambientColor = palette.accentStart.copy(alpha = if (glowActive) 0.45f else 0.14f),
                spotColor = palette.accentMid.copy(alpha = if (glowActive) 0.50f else 0.18f)
            )
            .clip(shape)
            .then(hazeModifier)
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        glassBase,
                        glassBase.copy(alpha = glassBase.alpha * 0.65f)
                    )
                )
            )
            .drawWithCache {
                val sweepBrush = Brush.sweepGradient(
                    colors = listOf(
                        palette.accentStart,
                        palette.accentMid,
                        palette.accentEnd,
                        palette.accentStart
                    )
                )
                onDrawWithContent {
                    drawContent()
                    if (glowActive) {
                        rotate(degrees = sweepAngle) {
                            drawRoundRect(
                                brush = sweepBrush,
                                cornerRadius = CornerRadius(28.dp.toPx(), 28.dp.toPx()),
                                style = Stroke(width = 2.dp.toPx())
                            )
                        }
                    }
                }
            }
            .border(width = 1.dp, brush = borderBrush, shape = shape)
            .padding(contentPadding),
        content = content
    )
}

/**
 * Aurora Glass Button with Spring press scale + Haptic feedback + Custom non-Material feedback.
 */
@Composable
fun AuroraGlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    badgeCount: Int? = null,
    primaryGradient: Boolean = false,
    enabled: Boolean = true,
    onLongClick: (() -> Unit)? = null
) {
    val palette = AuroraTheme.colors
    val haptic = LocalHapticFeedback.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) 0.95f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "btn_scale"
    )

    val shape = AuroraTheme.shapes.button
    val backgroundBrush = if (primaryGradient) {
        Brush.horizontalGradient(palette.auroraGradient)
    } else {
        Brush.linearGradient(
            listOf(palette.glassSurfaceStrong, palette.glassSurface)
        )
    }

    Row(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = if (enabled) 1f else 0.45f
            }
            .clip(shape)
            .background(backgroundBrush)
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(listOf(palette.glassBorderTop, palette.glassBorderBottom)),
                shape = shape
            )
            .pointerInput(enabled, onClick, onLongClick) {
                if (!enabled) return@pointerInput
                detectTapGestures(
                    onTap = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onClick()
                    },
                    onLongPress = {
                        if (onLongClick != null) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onLongClick()
                        }
                    }
                )
            }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Image(
                imageVector = icon,
                contentDescription = text,
                colorFilter = ColorFilter.tint(if (primaryGradient) Color.White else palette.textPrimary),
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
        }
        BasicText(
            text = text,
            style = AuroraTheme.typography.labelLarge.copy(
                color = if (primaryGradient) Color.White else palette.textPrimary
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (badgeCount != null && badgeCount > 0) {
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(
                        if (primaryGradient) Color.White.copy(alpha = 0.25f)
                        else palette.accentStart.copy(alpha = 0.28f)
                    )
                    .padding(horizontal = 7.dp, vertical = 2.dp),
                contentAlignment = Alignment.Center
            ) {
                BasicText(
                    text = badgeCount.toString(),
                    style = AuroraTheme.typography.labelSmall.copy(
                        color = if (primaryGradient) Color.White else palette.textPrimary
                    )
                )
            }
        }
    }
}

/**
 * Gemini-style Streaming Text Reveal with progressive Blur-to-Sharp entrance.
 */
@Composable
fun StreamingTextReveal(
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier,
    maxLines: Int = 2
) {
    var visibleChars by remember(text) { mutableIntStateOf(0) }
    val blurAmount by animateFloatAsState(
        targetValue = if (visibleChars >= text.length) 0f else 4f,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "stream_blur"
    )

    LaunchedEffect(text) {
        visibleChars = 0
        val step = (text.length / 18).coerceAtLeast(1)
        while (visibleChars < text.length) {
            visibleChars = (visibleChars + step).coerceAtMost(text.length)
            delay(16L)
        }
    }

    BasicText(
        text = text.take(visibleChars),
        style = style,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier.blur(blurAmount.dp)
    )
}

@Composable
fun AuroraGradientHeadline(
    text: String,
    modifier: Modifier = Modifier
) {
    val palette = AuroraTheme.colors
    BasicText(
        text = text,
        style = AuroraTheme.typography.displayLarge.copy(
            brush = Brush.horizontalGradient(palette.auroraGradient)
        ),
        modifier = modifier
    )
}

@Composable
fun AuroraShimmerBox(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 18.dp
) {
    val palette = AuroraTheme.colors
    Box(
        modifier = modifier
            .shimmer()
            .clip(RoundedCornerShape(cornerRadius))
            .background(palette.glassSurfaceStrong)
    )
}

@Composable
fun AuroraProgressGlowBar(
    progress: Float,
    modifier: Modifier = Modifier,
    height: Dp = 8.dp
) {
    val palette = AuroraTheme.colors
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "progress_bar"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(CircleShape)
            .background(palette.glassSurfaceStrong)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(animatedProgress)
                .height(height)
                .clip(CircleShape)
                .background(Brush.horizontalGradient(palette.auroraGradient))
        )
    }
}

@Composable
fun AuroraSpeedSparkline(
    samples: List<Long>,
    modifier: Modifier = Modifier
) {
    val palette = AuroraTheme.colors
    Canvas(modifier = modifier) {
        if (samples.size < 2) return@Canvas
        val maxVal = (samples.maxOrNull() ?: 1L).coerceAtLeast(1L).toFloat()
        val path = Path()
        val stepX = size.width / (samples.size - 1).coerceAtLeast(1)
        samples.forEachIndexed { idx, value ->
            val x = idx * stepX
            val y = size.height - ((value.toFloat() / maxVal) * size.height * 0.85f) - (size.height * 0.08f)
            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
            path = path,
            brush = Brush.horizontalGradient(palette.auroraGradient),
            style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}

data class DockDestination(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val badgeCount: Int = 0
)

/**
 * Floating Glass Dock (Zero Material NavigationBar) with Spring Morphing Pill indicator.
 */
@Composable
fun FloatingGlassDock(
    destinations: List<DockDestination>,
    selectedRoute: String,
    onSelect: (String) -> Unit,
    hazeState: HazeState,
    modifier: Modifier = Modifier
) {
    val palette = AuroraTheme.colors
    val haptic = LocalHapticFeedback.current

    AuroraGlassSurface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        hazeState = hazeState,
        shape = AuroraTheme.shapes.dock,
        elevated = true,
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            destinations.forEach { dest ->
                val selected = dest.route == selectedRoute
                val scale by animateFloatAsState(
                    targetValue = if (selected) 1.04f else 0.96f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessMedium
                    ),
                    label = "dock_scale"
                )
                Row(
                    modifier = Modifier
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                        }
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            if (selected) Brush.horizontalGradient(
                                palette.auroraGradient.map { it.copy(alpha = 0.28f) }
                            ) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onSelect(dest.route)
                        }
                        .padding(horizontal = if (selected) 14.dp else 10.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        imageVector = dest.icon,
                        contentDescription = dest.label,
                        colorFilter = ColorFilter.tint(
                            if (selected) palette.textPrimary else palette.textMuted
                        ),
                        modifier = Modifier.size(20.dp)
                    )
                    if (selected) {
                        Spacer(modifier = Modifier.width(6.dp))
                        BasicText(
                            text = dest.label,
                            style = AuroraTheme.typography.labelSmall.copy(color = palette.textPrimary),
                            maxLines = 1
                        )
                    }
                    if (dest.badgeCount > 0) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(palette.accentEnd),
                            contentAlignment = Alignment.Center
                        ) {
                            BasicText(
                                text = dest.badgeCount.coerceAtMost(99).toString(),
                                style = AuroraTheme.typography.labelSmall.copy(color = Color.White)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Custom Physics Glass Bottom Sheet (Zero Material ModalBottomSheet).
 */
@Composable
fun AuroraGlassBottomSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    hazeState: HazeState,
    title: String,
    content: @Composable () -> Unit
) {
    val palette = AuroraTheme.colors
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(spring(stiffness = Spring.StiffnessMediumLow)),
        exit = fadeOut(spring(stiffness = Spring.StiffnessMedium))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.56f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                ),
            contentAlignment = Alignment.BottomCenter
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = slideInVertically(
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioLowBouncy,
                        stiffness = Spring.StiffnessMediumLow
                    )
                ) { it },
                exit = slideOutVertically { it }
            ) {
                AuroraGlassSurface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {}
                        ),
                    hazeState = hazeState,
                    shape = AuroraTheme.shapes.sheet,
                    elevated = true,
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .width(44.dp)
                                .height(4.dp)
                                .clip(CircleShape)
                                .background(palette.textMuted.copy(alpha = 0.5f))
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        BasicText(
                            text = title,
                            style = AuroraTheme.typography.titleLarge.copy(color = palette.textPrimary)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        content()
                    }
                }
            }
        }
    }
}
