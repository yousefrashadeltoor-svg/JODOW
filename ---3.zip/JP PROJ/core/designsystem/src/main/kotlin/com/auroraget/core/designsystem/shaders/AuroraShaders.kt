package com.auroraget.core.designsystem.shaders

import android.graphics.RuntimeShader
import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import com.auroraget.core.designsystem.theme.AuroraTheme
import kotlin.math.cos
import kotlin.math.sin

private const val AURORA_MESH_AGSL = """
uniform float2 iResolution;
uniform float iTime;
uniform half4 colorBg;
uniform half4 colorA;
uniform half4 colorB;
uniform half4 colorC;

half4 main(float2 fragCoord) {
    float2 uv = fragCoord / iResolution;
    float t = iTime * 0.35;

    float2 p1 = float2(0.22 + 0.16 * sin(t), 0.18 + 0.14 * cos(t * 0.9));
    float2 p2 = float2(0.78 + 0.14 * cos(t * 0.8), 0.32 + 0.16 * sin(t * 1.1));
    float2 p3 = float2(0.50 + 0.18 * sin(t * 0.7 + 1.4), 0.82 + 0.12 * cos(t * 0.6));

    float d1 = exp(-4.8 * dot(uv - p1, uv - p1));
    float d2 = exp(-4.5 * dot(uv - p2, uv - p2));
    float d3 = exp(-5.0 * dot(uv - p3, uv - p3));

    half4 col = colorBg;
    col = mix(col, colorA, clamp(d1 * 0.42, 0.0, 0.42));
    col = mix(col, colorB, clamp(d2 * 0.38, 0.0, 0.38));
    col = mix(col, colorC, clamp(d3 * 0.32, 0.0, 0.32));
    return col;
}
"""

/**
 * Animated Mesh Gradient Background using AGSL RuntimeShader on Android 13+ (API 33+)
 * with an ultra-smooth multi-radial Brush fallback on Android 7.0–12 (API 24–32).
 */
@Composable
fun AuroraMeshBackground(
    modifier: Modifier = Modifier,
    parallaxOffsetX: Float = 0f,
    parallaxOffsetY: Float = 0f
) {
    val palette = AuroraTheme.colors
    val infinite = rememberInfiniteTransition(label = "aurora_mesh")
    val time by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 62.83185f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 36_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "mesh_time"
    )

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        val shader = remember { RuntimeShader(AURORA_MESH_AGSL) }
        Canvas(modifier = modifier.fillMaxSize()) {
            shader.setFloatUniform("iResolution", size.width, size.height)
            shader.setFloatUniform("iTime", time)
            shader.setColorUniform("colorBg", android.graphics.Color.argb(
                (palette.background.alpha * 255).toInt(),
                (palette.background.red * 255).toInt(),
                (palette.background.green * 255).toInt(),
                (palette.background.blue * 255).toInt()
            ))
            shader.setColorUniform("colorA", android.graphics.Color.argb(
                255,
                (palette.accentStart.red * 255).toInt(),
                (palette.accentStart.green * 255).toInt(),
                (palette.accentStart.blue * 255).toInt()
            ))
            shader.setColorUniform("colorB", android.graphics.Color.argb(
                255,
                (palette.accentMid.red * 255).toInt(),
                (palette.accentMid.green * 255).toInt(),
                (palette.accentMid.blue * 255).toInt()
            ))
            shader.setColorUniform("colorC", android.graphics.Color.argb(
                255,
                (palette.accentEnd.red * 255).toInt(),
                (palette.accentEnd.green * 255).toInt(),
                (palette.accentEnd.blue * 255).toInt()
            ))
            drawRect(brush = ShaderBrush(shader))
        }
    } else {
        Canvas(modifier = modifier.fillMaxSize()) {
            drawRect(color = palette.background)
            val t = time * 0.35f
            val c1 = Offset(
                x = size.width * (0.24f + 0.14f * sin(t)) + parallaxOffsetX,
                y = size.height * (0.20f + 0.10f * cos(t)) + parallaxOffsetY
            )
            val c2 = Offset(
                x = size.width * (0.78f + 0.12f * cos(t * 0.8f)) - parallaxOffsetX,
                y = size.height * (0.34f + 0.12f * sin(t * 1.1f)) + parallaxOffsetY
            )
            val c3 = Offset(
                x = size.width * (0.50f + 0.15f * sin(t * 0.7f)),
                y = size.height * (0.82f + 0.08f * cos(t * 0.6f))
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(palette.accentStart.copy(alpha = 0.28f), Color.Transparent),
                    center = c1,
                    radius = size.maxDimension * 0.55f
                ),
                center = c1,
                radius = size.maxDimension * 0.55f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(palette.accentMid.copy(alpha = 0.26f), Color.Transparent),
                    center = c2,
                    radius = size.maxDimension * 0.52f
                ),
                center = c2,
                radius = size.maxDimension * 0.52f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(palette.accentEnd.copy(alpha = 0.22f), Color.Transparent),
                    center = c3,
                    radius = size.maxDimension * 0.50f
                ),
                center = c3,
                radius = size.maxDimension * 0.50f
            )
        }
    }
}
