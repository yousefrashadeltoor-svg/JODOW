package com.auroraget.core.designsystem.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.auroraget.core.common.AuroraThemePreset

@Immutable
data class AuroraPalette(
    val preset: AuroraThemePreset,
    val isDark: Boolean,
    val background: Color,
    val backgroundElevated: Color,
    val glassSurface: Color,
    val glassSurfaceStrong: Color,
    val glassBorderTop: Color,
    val glassBorderBottom: Color,
    val accentStart: Color,
    val accentMid: Color,
    val accentEnd: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val success: Color,
    val warning: Color,
    val danger: Color,
    val info: Color
) {
    val auroraGradient: List<Color> get() = listOf(accentStart, accentMid, accentEnd)
}

@Immutable
data class AuroraTypography(
    val displayLarge: TextStyle,
    val headlineMedium: TextStyle,
    val titleLarge: TextStyle,
    val titleMedium: TextStyle,
    val bodyLarge: TextStyle,
    val bodyMedium: TextStyle,
    val labelLarge: TextStyle,
    val labelSmall: TextStyle,
    val monoSmall: TextStyle
)

@Immutable
data class AuroraShapes(
    val card: Shape = RoundedCornerShape(28.dp),
    val sheet: Shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    val button: Shape = RoundedCornerShape(22.dp),
    val chip: Shape = RoundedCornerShape(20.dp),
    val dock: Shape = RoundedCornerShape(30.dp),
    val input: Shape = RoundedCornerShape(26.dp),
    val cornerCardDp: Dp = 28.dp
)

fun buildAuroraPalette(
    preset: AuroraThemePreset,
    isDark: Boolean,
    amoledPureBlack: Boolean,
    dynamicSeedColor: Color? = null
): AuroraPalette {
    val (start, mid, end) = when (preset) {
        AuroraThemePreset.AURORA -> Triple(Color(0xFF4285F4), Color(0xFF9B72CB), Color(0xFFD96570))
        AuroraThemePreset.OCEAN -> Triple(Color(0xFF00D2FF), Color(0xFF3A7BD5), Color(0xFF6366F1))
        AuroraThemePreset.SUNSET -> Triple(Color(0xFFFF6B6B), Color(0xFFF59E0B), Color(0xFFEC4899))
        AuroraThemePreset.EMERALD -> Triple(Color(0xFF10B981), Color(0xFF06B6D4), Color(0xFF34D399))
        AuroraThemePreset.MONO -> Triple(Color(0xFFE2E8F0), Color(0xFF94A3B8), Color(0xFFCBD5E1))
        AuroraThemePreset.NEON -> Triple(Color(0xFF00F5D4), Color(0xFF9B5DE5), Color(0xFFF15BB5))
    }

    val effectiveStart = dynamicSeedColor ?: start

    return if (isDark) {
        AuroraPalette(
            preset = preset,
            isDark = true,
            background = if (amoledPureBlack) Color(0xFF07080C) else Color(0xFF0B0D12),
            backgroundElevated = Color(0xFF121622),
            glassSurface = Color(0x26FFFFFF).copy(alpha = 0.08f),
            glassSurfaceStrong = Color(0x38FFFFFF).copy(alpha = 0.14f),
            glassBorderTop = Color.White.copy(alpha = 0.24f),
            glassBorderBottom = Color.White.copy(alpha = 0.05f),
            accentStart = effectiveStart,
            accentMid = mid,
            accentEnd = end,
            textPrimary = Color(0xFFF8FAFC),
            textSecondary = Color(0xFFB7C2D6),
            textMuted = Color(0xFF7B879E),
            success = Color(0xFF34D399),
            warning = Color(0xFFFBBF24),
            danger = Color(0xFFFB7185),
            info = Color(0xFF60A5FA)
        )
    } else {
        AuroraPalette(
            preset = preset,
            isDark = false,
            background = Color(0xFFF2F5FC),
            backgroundElevated = Color(0xFFFFFFFF),
            glassSurface = Color.White.copy(alpha = 0.68f),
            glassSurfaceStrong = Color.White.copy(alpha = 0.86f),
            glassBorderTop = Color.White.copy(alpha = 0.92f),
            glassBorderBottom = Color(0xFFCBD5E1).copy(alpha = 0.45f),
            accentStart = effectiveStart,
            accentMid = mid,
            accentEnd = end,
            textPrimary = Color(0xFF0F172A),
            textSecondary = Color(0xFF475569),
            textMuted = Color(0xFF64748B),
            success = Color(0xFF059669),
            warning = Color(0xFFD97706),
            danger = Color(0xFFE11D48),
            info = Color(0xFF2563EB)
        )
    }
}

/**
 * Open-licensed font stacks: Plus Jakarta Sans (Latin) + IBM Plex Sans Arabic (Arabic).
 * Drop .ttf font files into res/font/ and replace FontFamily.SansSerif via Font(R.font.*).
 */
fun buildAuroraTypography(primaryFamily: FontFamily = FontFamily.SansSerif): AuroraTypography {
    return AuroraTypography(
        displayLarge = TextStyle(
            fontFamily = primaryFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 30.sp,
            lineHeight = 38.sp,
            letterSpacing = (-0.5).sp
        ),
        headlineMedium = TextStyle(
            fontFamily = primaryFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 22.sp,
            lineHeight = 30.sp
        ),
        titleLarge = TextStyle(
            fontFamily = primaryFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 18.sp,
            lineHeight = 24.sp
        ),
        titleMedium = TextStyle(
            fontFamily = primaryFamily,
            fontWeight = FontWeight.Medium,
            fontSize = 15.sp,
            lineHeight = 22.sp
        ),
        bodyLarge = TextStyle(
            fontFamily = primaryFamily,
            fontWeight = FontWeight.Normal,
            fontSize = 15.sp,
            lineHeight = 22.sp
        ),
        bodyMedium = TextStyle(
            fontFamily = primaryFamily,
            fontWeight = FontWeight.Normal,
            fontSize = 13.sp,
            lineHeight = 19.sp
        ),
        labelLarge = TextStyle(
            fontFamily = primaryFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp,
            lineHeight = 18.sp
        ),
        labelSmall = TextStyle(
            fontFamily = primaryFamily,
            fontWeight = FontWeight.Medium,
            fontSize = 11.sp,
            lineHeight = 15.sp
        ),
        monoSmall = TextStyle(
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium,
            fontSize = 11.sp,
            lineHeight = 15.sp
        )
    )
}

val LocalAuroraPalette = staticCompositionLocalOf {
    buildAuroraPalette(AuroraThemePreset.AURORA, isDark = true, amoledPureBlack = true)
}
val LocalAuroraTypography = staticCompositionLocalOf { buildAuroraTypography() }
val LocalAuroraShapes = staticCompositionLocalOf { AuroraShapes() }

object AuroraTheme {
    val colors: AuroraPalette @Composable get() = LocalAuroraPalette.current
    val typography: AuroraTypography @Composable get() = LocalAuroraTypography.current
    val shapes: AuroraShapes @Composable get() = LocalAuroraShapes.current
}

@Composable
fun AuroraGlassTheme(
    preset: AuroraThemePreset = AuroraThemePreset.AURORA,
    isDark: Boolean = true,
    amoledPureBlack: Boolean = true,
    dynamicSeedColor: Color? = null,
    content: @Composable () -> Unit
) {
    val palette = buildAuroraPalette(preset, isDark, amoledPureBlack, dynamicSeedColor)
    val typography = buildAuroraTypography()
    val shapes = AuroraShapes()

    CompositionLocalProvider(
        LocalAuroraPalette provides palette,
        LocalAuroraTypography provides typography,
        LocalAuroraShapes provides shapes,
        content = content
    )
}
