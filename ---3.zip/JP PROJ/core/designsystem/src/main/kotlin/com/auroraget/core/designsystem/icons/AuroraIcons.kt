package com.auroraget.core.designsystem.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Custom Duotone-inspired Lucide/Phosphor-style vector icons built purely on
 * androidx.compose.ui.graphics.vector.ImageVector. ZERO Material Icons used anywhere.
 */
object AuroraIcons {
    private fun icon(name: String, block: ImageVector.Builder.() -> Unit): ImageVector {
        return ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply(block).build()
    }

    val Sparkles: ImageVector by lazy {
        icon("AuroraSparkles") {
            path(
                fill = SolidColor(Color.White.copy(alpha = 0.22f)),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(12f, 3f)
                lineTo(14.4f, 9.6f)
                lineTo(21f, 12f)
                lineTo(14.4f, 14.4f)
                lineTo(12f, 21f)
                lineTo(9.6f, 14.4f)
                lineTo(3f, 12f)
                lineTo(9.6f, 9.6f)
                close()
            }
        }
    }

    val DownloadArrow: ImageVector by lazy {
        icon("AuroraDownload") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(12f, 3f); lineTo(12f, 15f)
                moveTo(7f, 10f); lineTo(12f, 15f); lineTo(17f, 10f)
                moveTo(4f, 18f); lineTo(4f, 19.5f); lineTo(20f, 19.5f); lineTo(20f, 18f)
            }
        }
    }

    val Globe: ImageVector by lazy {
        icon("AuroraGlobe") {
            path(
                fill = SolidColor(Color.White.copy(alpha = 0.14f)),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(12f, 2f)
                arcTo(10f, 10f, 0f, true, true, 11.99f, 2f)
                moveTo(2f, 12f); lineTo(22f, 12f)
                moveTo(12f, 2f); quadTo(16f, 12f, 12f, 22f)
                moveTo(12f, 2f); quadTo(8f, 12f, 12f, 22f)
            }
        }
    }

    val AudioWave: ImageVector by lazy {
        icon("AuroraAudio") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.0f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(4f, 10f); lineTo(4f, 14f)
                moveTo(8f, 6f); lineTo(8f, 18f)
                moveTo(12f, 3f); lineTo(12f, 21f)
                moveTo(16f, 7f); lineTo(16f, 17f)
                moveTo(20f, 10f); lineTo(20f, 14f)
            }
        }
    }

    val VideoFilm: ImageVector by lazy {
        icon("AuroraVideo") {
            path(
                fill = SolidColor(Color.White.copy(alpha = 0.16f)),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.8f,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(4f, 6f); lineTo(16f, 6f); lineTo(16f, 18f); lineTo(4f, 18f); close()
                moveTo(16f, 10f); lineTo(21f, 7f); lineTo(21f, 17f); lineTo(16f, 14f); close()
            }
        }
    }

    val PhotoFrame: ImageVector by lazy {
        icon("AuroraImage") {
            path(
                fill = SolidColor(Color.White.copy(alpha = 0.14f)),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.8f,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(4f, 5f); lineTo(20f, 5f); lineTo(20f, 19f); lineTo(4f, 19f); close()
                moveTo(4f, 16f); lineTo(9f, 11f); lineTo(14f, 16f); lineTo(17f, 13f); lineTo(20f, 16f)
            }
        }
    }

    val DocumentFile: ImageVector by lazy {
        icon("AuroraFile") {
            path(
                fill = SolidColor(Color.White.copy(alpha = 0.14f)),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.8f,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(6f, 3f); lineTo(14f, 3f); lineTo(19f, 8f); lineTo(19f, 21f); lineTo(6f, 21f); close()
                moveTo(14f, 3f); lineTo(14f, 8f); lineTo(19f, 8f)
            }
        }
    }

    val ShieldCheck: ImageVector by lazy {
        icon("AuroraShield") {
            path(
                fill = SolidColor(Color.White.copy(alpha = 0.16f)),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(12f, 2.5f); lineTo(20f, 6f); lineTo(20f, 12f)
                quadTo(20f, 18.5f, 12f, 21.5f)
                quadTo(4f, 18.5f, 4f, 12f); lineTo(4f, 6f); close()
                moveTo(9f, 12f); lineTo(11.2f, 14.2f); lineTo(15.5f, 9.8f)
            }
        }
    }

    val CompressArrows: ImageVector by lazy {
        icon("AuroraCompress") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(4f, 14f); lineTo(10f, 14f); lineTo(10f, 20f)
                moveTo(20f, 10f); lineTo(14f, 10f); lineTo(14f, 4f)
                moveTo(14f, 10f); lineTo(21f, 3f)
                moveTo(3f, 21f); lineTo(10f, 14f)
            }
        }
    }

    val FolderLibrary: ImageVector by lazy {
        icon("AuroraLibrary") {
            path(
                fill = SolidColor(Color.White.copy(alpha = 0.15f)),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.8f,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(3f, 6f); lineTo(9.5f, 6f); lineTo(11.5f, 8.5f); lineTo(21f, 8.5f)
                lineTo(21f, 19f); lineTo(3f, 19f); close()
            }
        }
    }

    val SlidersSettings: ImageVector by lazy {
        icon("AuroraSettings") {
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(4f, 7f); lineTo(20f, 7f)
                moveTo(4f, 12f); lineTo(20f, 12f)
                moveTo(4f, 17f); lineTo(20f, 17f)
                moveTo(9f, 5f); lineTo(9f, 9f)
                moveTo(15f, 10f); lineTo(15f, 14f)
                moveTo(11f, 15f); lineTo(11f, 19f)
            }
        }
    }

    val PauseIcon: ImageVector by lazy {
        icon("AuroraPause") {
            path(stroke = SolidColor(Color.White), strokeLineWidth = 2.2f, strokeLineCap = StrokeCap.Round) {
                moveTo(9f, 5f); lineTo(9f, 19f)
                moveTo(15f, 5f); lineTo(15f, 19f)
            }
        }
    }

    val PlayIcon: ImageVector by lazy {
        icon("AuroraPlay") {
            path(
                fill = SolidColor(Color.White.copy(alpha = 0.25f)),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.9f,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(7f, 5f); lineTo(19f, 12f); lineTo(7f, 19f); close()
            }
        }
    }

    val LockVault: ImageVector by lazy {
        icon("AuroraVault") {
            path(
                fill = SolidColor(Color.White.copy(alpha = 0.16f)),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.8f,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(5f, 11f); lineTo(19f, 11f); lineTo(19f, 20f); lineTo(5f, 20f); close()
                moveTo(8f, 11f); lineTo(8f, 7.5f); arcTo(4f, 4f, 0f, true, true, 16f, 7.5f); lineTo(16f, 11f)
            }
        }
    }
}
