import { AuroraAppShowcase } from "@/components/aurora/AuroraAppShowcase";

export default function HomePage() {
  return <AuroraAppShowcase />;
}
