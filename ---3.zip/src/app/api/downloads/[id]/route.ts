import { db } from "@/db";
import { auroraDownloads } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const body = await request.json();
    const updates: Partial<typeof auroraDownloads.$inferInsert> = {};

    if (typeof body.status === "string") updates.status = body.status;
    if (typeof body.downloadedBytes === "number") updates.downloadedBytes = body.downloadedBytes;
    if (typeof body.priority === "number") updates.priority = body.priority;
    if (typeof body.savedByCompressionBytes === "number") {
      updates.savedByCompressionBytes = body.savedByCompressionBytes;
    }

    const [updated] = await db
      .update(auroraDownloads)
      .set(updates)
      .where(eq(auroraDownloads.id, id))
      .returning();

    if (!updated) {
      return Response.json({ error: "Download not found" }, { status: 404 });
    }
    return Response.json(updated);
  } catch (error) {
    console.error("PATCH /api/downloads/[id] error:", error);
    return Response.json({ error: "Failed to update download" }, { status: 500 });
  }
}

export async function DELETE(
  _request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    await db.delete(auroraDownloads).where(eq(auroraDownloads.id, id));
    return Response.json({ deleted: true, id });
  } catch (error) {
    console.error("DELETE /api/downloads/[id] error:", error);
    return Response.json({ error: "Failed to delete download" }, { status: 500 });
  }
}
