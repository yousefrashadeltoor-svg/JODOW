import { db } from "@/db";
import { auroraDownloads } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

const INITIAL_SEED_DOWNLOADS = [
  {
    id: "dl-aurora-8k-active",
    url: "https://youtube.com/watch?v=aurora_iceland_8k_hdr",
    fileName: "Iceland_Aurora_Borealis_1080p60_HDR.mp4",
    category: "VIDEO",
    siteName: "YouTube",
    domain: "youtube.com",
    thumbnailUrl: "/images/aurora-thumb-yt.png",
    totalBytes: 148372910,
    sizePrecision: "EXACT",
    downloadedBytes: 98421000,
    maxConnections: 16,
    status: "DOWNLOADING",
    priority: 10,
    requiresMerge: true,
    savedByCompressionBytes: 0,
  },
  {
    id: "dl-tiktok-complete",
    url: "https://tiktok.com/@cybertokyo/video/7481920441",
    fileName: "Neon_Rain_Shibuya_NoWM_1080p60.mp4",
    category: "VIDEO",
    siteName: "TikTok",
    domain: "tiktok.com",
    thumbnailUrl: "/images/aurora-thumb-tiktok.png",
    totalBytes: 34812940,
    sizePrecision: "EXACT",
    downloadedBytes: 34812940,
    maxConnections: 16,
    status: "COMPLETED",
    priority: 5,
    requiresMerge: false,
    savedByCompressionBytes: 14621430,
  },
  {
    id: "dl-flac-complete",
    url: "https://soundcloud.com/aurora-labs/crystalline-waves",
    fileName: "Crystalline_Waves_24bit_Master.flac",
    category: "AUDIO",
    siteName: "SoundCloud",
    domain: "soundcloud.com",
    thumbnailUrl: "/images/aurora-thumb-audio.png",
    totalBytes: 41943040,
    sizePrecision: "EXACT",
    downloadedBytes: 41943040,
    maxConnections: 8,
    status: "COMPLETED",
    priority: 4,
    requiresMerge: false,
    savedByCompressionBytes: 6180200,
  },
  {
    id: "dl-apk-queued",
    url: "https://releases.auroraget.app/builds/AuroraGet-v1.0.0-arm64.apk",
    fileName: "AuroraGet-v1.0.0-arm64.apk",
    category: "FILE",
    siteName: "Aurora Releases",
    domain: "releases.auroraget.app",
    thumbnailUrl: null,
    totalBytes: 48912384,
    sizePrecision: "EXACT",
    downloadedBytes: 14210048,
    maxConnections: 16,
    status: "PAUSED",
    priority: 3,
    requiresMerge: false,
    savedByCompressionBytes: 0,
  },
];

export async function GET() {
  try {
    const existing = await db
      .select()
      .from(auroraDownloads)
      .orderBy(desc(auroraDownloads.priority), desc(auroraDownloads.createdAt));

    if (existing.length === 0) {
      await db.insert(auroraDownloads).values(INITIAL_SEED_DOWNLOADS).onConflictDoNothing();
      const seeded = await db
        .select()
        .from(auroraDownloads)
        .orderBy(desc(auroraDownloads.priority), desc(auroraDownloads.createdAt));
      return Response.json(seeded);
    }

    return Response.json(existing);
  } catch (error) {
    console.error("GET /api/downloads error:", error);
    return Response.json(INITIAL_SEED_DOWNLOADS);
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const id = String(body.id || `dl-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`);
    const record = {
      id,
      url: String(body.url || ""),
      fileName: String(body.fileName || "aurora_download.bin"),
      category: String(body.category || "FILE"),
      siteName: String(body.siteName || "Web"),
      domain: String(body.domain || "web"),
      thumbnailUrl: body.thumbnailUrl ? String(body.thumbnailUrl) : null,
      totalBytes: Number(body.totalBytes || 0),
      sizePrecision: String(body.sizePrecision || "EXACT"),
      downloadedBytes: Number(body.downloadedBytes || 0),
      maxConnections: Math.min(32, Math.max(8, Number(body.maxConnections || 16))),
      status: String(body.status || "DOWNLOADING"),
      priority: Number(body.priority || 10),
      requiresMerge: Boolean(body.requiresMerge || false),
      savedByCompressionBytes: Number(body.savedByCompressionBytes || 0),
    };

    const [inserted] = await db.insert(auroraDownloads).values(record).returning();
    return Response.json(inserted ?? record, { status: 201 });
  } catch (error) {
    console.error("POST /api/downloads error:", error);
    return Response.json({ error: "Failed to create download task" }, { status: 500 });
  }
}
