import { db } from "@/db";
import { auroraSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const DEFAULT_SETTINGS = {
  id: 1,
  themePreset: "AURORA",
  darkMode: true,
  amoledPureBlack: true,
  dynamicCoverColor: true,
  languageCode: "ar",
  defaultSegments: 16,
  dohEnabled: true,
  adBlockEnabled: true,
  clipboardAutoDetect: true,
  copyrightAccepted: true,
};

export async function GET() {
  try {
    const existing = await db
      .select()
      .from(auroraSettings)
      .where(eq(auroraSettings.id, 1))
      .limit(1);

    if (existing.length > 0) {
      return Response.json(existing[0]);
    }

    const [created] = await db
      .insert(auroraSettings)
      .values(DEFAULT_SETTINGS)
      .onConflictDoNothing()
      .returning();

    return Response.json(created ?? DEFAULT_SETTINGS);
  } catch (error) {
    console.error("GET /api/settings error:", error);
    return Response.json(DEFAULT_SETTINGS);
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const nextValues = {
      id: 1,
      themePreset: String(body.themePreset ?? DEFAULT_SETTINGS.themePreset),
      darkMode: Boolean(body.darkMode ?? DEFAULT_SETTINGS.darkMode),
      amoledPureBlack: Boolean(body.amoledPureBlack ?? DEFAULT_SETTINGS.amoledPureBlack),
      dynamicCoverColor: Boolean(body.dynamicCoverColor ?? DEFAULT_SETTINGS.dynamicCoverColor),
      languageCode: body.languageCode === "en" ? "en" : "ar",
      defaultSegments: Math.min(32, Math.max(8, Number(body.defaultSegments ?? 16))),
      dohEnabled: Boolean(body.dohEnabled ?? true),
      adBlockEnabled: Boolean(body.adBlockEnabled ?? true),
      clipboardAutoDetect: Boolean(body.clipboardAutoDetect ?? true),
      copyrightAccepted: Boolean(body.copyrightAccepted ?? true),
      updatedAt: new Date(),
    };

    const [saved] = await db
      .insert(auroraSettings)
      .values(nextValues)
      .onConflictDoUpdate({
        target: auroraSettings.id,
        set: {
          themePreset: nextValues.themePreset,
          darkMode: nextValues.darkMode,
          amoledPureBlack: nextValues.amoledPureBlack,
          dynamicCoverColor: nextValues.dynamicCoverColor,
          languageCode: nextValues.languageCode,
          defaultSegments: nextValues.defaultSegments,
          dohEnabled: nextValues.dohEnabled,
          adBlockEnabled: nextValues.adBlockEnabled,
          clipboardAutoDetect: nextValues.clipboardAutoDetect,
          copyrightAccepted: nextValues.copyrightAccepted,
          updatedAt: nextValues.updatedAt,
        },
      })
      .returning();

    return Response.json(saved ?? nextValues);
  } catch (error) {
    console.error("PUT /api/settings error:", error);
    return Response.json({ error: "Failed to persist settings" }, { status: 500 });
  }
}
