import { db } from "@/db";
import { auroraAnalysisHistory } from "@/db/schema";
import { analyzeUrlDeterministic } from "@/lib/aurora-types";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const history = await db
      .select()
      .from(auroraAnalysisHistory)
      .orderBy(desc(auroraAnalysisHistory.analyzedAt))
      .limit(12);
    return Response.json(history);
  } catch {
    return Response.json([]);
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const rawUrl = String(body.url || "").trim();
    if (!rawUrl) {
      return Response.json({ error: "URL is required" }, { status: 400 });
    }

    const analysis = analyzeUrlDeterministic(rawUrl);

    await db
      .insert(auroraAnalysisHistory)
      .values({
        url: analysis.normalizedUrl,
        domain: analysis.domain,
        siteName: analysis.siteName,
        title: analysis.title,
        primaryBadge: analysis.primaryBadgeEn,
        totalFormats: analysis.formats.length,
      })
      .catch(() => null);

    return Response.json(analysis);
  } catch (error) {
    console.error("POST /api/analyze error:", error);
    return Response.json({ error: "Analysis failed" }, { status: 500 });
  }
}
