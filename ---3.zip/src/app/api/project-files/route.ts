import { promises as fs } from "fs";
import path from "path";

export const dynamic = "force-dynamic";

const ANDROID_ROOT = path.resolve(process.cwd(), "JP PROJ");

async function walkDirectory(dir: string, baseDir: string): Promise<string[]> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files: string[] = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...(await walkDirectory(full, baseDir)));
    } else if (entry.isFile()) {
      files.push(path.relative(baseDir, full).replace(/\\/g, "/"));
    }
  }
  return files.sort();
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const requestedFile = searchParams.get("file");

    if (requestedFile) {
      const normalized = path.normalize(requestedFile).replace(/^(\.\.(\/|\\|$))+/, "");
      const targetPath = path.resolve(ANDROID_ROOT, normalized);
      if (!targetPath.startsWith(ANDROID_ROOT)) {
        return Response.json({ error: "Invalid file path" }, { status: 400 });
      }
      const content = await fs.readFile(targetPath, "utf-8");
      return Response.json({
        file: normalized,
        lines: content.split("\n").length,
        content,
      });
    }

    const files = await walkDirectory(ANDROID_ROOT, ANDROID_ROOT);
    return Response.json({
      projectFolder: "JP PROJ",
      totalFiles: files.length,
      files,
    });
  } catch (error) {
    console.error("GET /api/project-files error:", error);
    return Response.json({ error: "Unable to read JP PROJ directory" }, { status: 500 });
  }
}
