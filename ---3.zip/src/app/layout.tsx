import type { Metadata } from "next";
import type { ReactNode } from "react";
import {
  IBM_Plex_Sans_Arabic,
  JetBrains_Mono,
  Plus_Jakarta_Sans,
} from "next/font/google";
import "./globals.css";

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-latin",
  display: "swap",
});

const ibmArabic = IBM_Plex_Sans_Arabic({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-arabic",
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Aurora Get — 𝒥𝒪 DOW | Aurora Glass Android App & Interactive Preview",
  description:
    "Aurora Get (𝒥𝒪 DOW): Lightning segmented media downloader, 1800+ sites, WebView Sniffer + AdBlock, Smart Lossless/SSIM Compressor, and pure Aurora Glass UI (Zero Material Design).",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="ar"
      dir="rtl"
      className={`${plusJakarta.variable} ${ibmArabic.variable} ${jetbrainsMono.variable}`}
    >
      <body className="min-h-screen overflow-x-hidden bg-[#07080C] text-slate-50 antialiased selection:bg-[#4285F4]/40 selection:text-white">
        {children}
      </body>
    </html>
  );
}
