export type MediaCategory = "AUDIO" | "IMAGE" | "VIDEO" | "FILE";
export type SizePrecision = "EXACT" | "APPROXIMATE" | "UNKNOWN";
export type AuroraThemePreset = "AURORA" | "OCEAN" | "SUNSET" | "EMERALD" | "MONO" | "NEON";
export type DownloadStatus = "QUEUED" | "DOWNLOADING" | "MERGING" | "PAUSED" | "COMPLETED" | "FAILED";
export type CompressionMode = "LOSSLESS" | "VISUALLY_TRANSPARENT";
export type LangCode = "ar" | "en";

export interface FileSizeInfo {
  bytes: number;
  precision: SizePrecision;
  source: string;
}

export interface MediaFormatOption {
  id: string;
  category: MediaCategory;
  title: string;
  qualityLabel: string;
  extension: string;
  codec: string;
  fps?: number;
  bitrateKbps?: number;
  isHdr?: boolean;
  requiresAudioMerge?: boolean;
  hasWatermark?: boolean;
  size: FileSizeInfo;
  downloadUrl: string;
}

export interface AnalysisResult {
  originalUrl: string;
  normalizedUrl: string;
  domain: string;
  siteName: string;
  faviconBg: string;
  faviconText: string;
  title: string;
  suggestedFileName: string;
  thumbnailUrl?: string;
  primaryBadgeAr: string;
  primaryBadgeEn: string;
  durationSeconds?: number;
  author?: string;
  publishedDate?: string;
  dominantAccent: string;
  primarySize: FileSizeInfo;
  formats: MediaFormatOption[];
  stageLatencyMs: number;
  requiresWebViewSniffer?: boolean;
  drmBlockedReasonAr?: string;
  drmBlockedReasonEn?: string;
}

export interface DownloadItem {
  id: string;
  url: string;
  fileName: string;
  category: MediaCategory;
  siteName: string;
  domain: string;
  thumbnailUrl: string | null;
  totalBytes: number;
  sizePrecision: SizePrecision;
  downloadedBytes: number;
  maxConnections: number;
  status: DownloadStatus;
  priority: number;
  requiresMerge: boolean;
  savedByCompressionBytes: number;
  createdAt?: string;
}

export interface AuroraAppSettings {
  themePreset: AuroraThemePreset;
  darkMode: boolean;
  amoledPureBlack: boolean;
  dynamicCoverColor: boolean;
  languageCode: LangCode;
  defaultSegments: number;
  dohEnabled: boolean;
  adBlockEnabled: boolean;
  clipboardAutoDetect: boolean;
  copyrightAccepted: boolean;
}

export const THEME_PALETTES: Record<
  AuroraThemePreset,
  { nameAr: string; nameEn: string; start: string; mid: string; end: string }
> = {
  AURORA: { nameAr: "أورورا (Gemini)", nameEn: "Aurora (Gemini)", start: "#4285F4", mid: "#9B72CB", end: "#D96570" },
  OCEAN: { nameAr: "المحيط", nameEn: "Ocean", start: "#00D2FF", mid: "#3A7BD5", end: "#6366F1" },
  SUNSET: { nameAr: "الغروب", nameEn: "Sunset", start: "#FF6B6B", mid: "#F59E0B", end: "#EC4899" },
  EMERALD: { nameAr: "الزمرد", nameEn: "Emerald", start: "#10B981", mid: "#06B6D4", end: "#34D399" },
  MONO: { nameAr: "أحادي", nameEn: "Mono", start: "#E2E8F0", mid: "#94A3B8", end: "#CBD5E1" },
  NEON: { nameAr: "نيون", nameEn: "Neon", start: "#00F5D4", mid: "#9B5DE5", end: "#F15BB5" },
};

export function formatHumanBinary(bytes: number): string {
  if (!bytes || bytes <= 0) return "0 B";
  const units = ["B", "KiB", "MiB", "GiB", "TiB"];
  let value = bytes;
  let idx = 0;
  while (value >= 1024 && idx < units.length - 1) {
    value /= 1024;
    idx++;
  }
  return `${value.toFixed(value >= 100 ? 1 : 2).replace(/\.00$/, "")} ${units[idx]}`;
}

export function formatFileSize(info: FileSizeInfo): string {
  if (!info || info.bytes <= 0 || info.precision === "UNKNOWN") return "—";
  const human = formatHumanBinary(info.bytes);
  return info.precision === "APPROXIMATE" ? `≈ ${human}` : human;
}

export function formatExactBytesLongPress(info: FileSizeInfo): string {
  if (!info || info.bytes <= 0) return "Size unavailable";
  const exact = new Intl.NumberFormat("en-US").format(info.bytes);
  const human = formatHumanBinary(info.bytes);
  const prefix = info.precision === "APPROXIMATE" ? "≈ " : "";
  return `${prefix}${exact} bytes (${human})`;
}

export function formatDuration(seconds?: number): string {
  if (!seconds || seconds <= 0) return "";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export const DEMO_SCENARIOS: Array<{
  key: string;
  labelAr: string;
  labelEn: string;
  sampleUrl: string;
}> = [
  {
    key: "youtube",
    labelAr: "YouTube 8K HDR",
    labelEn: "YouTube 8K HDR",
    sampleUrl: "https://youtube.com/watch?v=aurora_iceland_8k_hdr",
  },
  {
    key: "tiktok",
    labelAr: "TikTok (بدون علامة)",
    labelEn: "TikTok (No WM)",
    sampleUrl: "https://tiktok.com/@cybertokyo/video/7481920441",
  },
  {
    key: "audio",
    labelAr: "SoundCloud FLAC",
    labelEn: "SoundCloud FLAC",
    sampleUrl: "https://soundcloud.com/aurora-labs/crystalline-waves",
  },
  {
    key: "apk",
    labelAr: "ملف APK مباشر",
    labelEn: "Direct APK",
    sampleUrl: "https://releases.auroraget.app/builds/AuroraGet-v1.0.0-arm64.apk",
  },
  {
    key: "cloudflare",
    labelAr: "رابط غير مباشر (CF)",
    labelEn: "Indirect (Cloudflare)",
    sampleUrl: "https://streamhub.example.org/watch/live-aurora-hls",
  },
  {
    key: "drm",
    labelAr: "محتوى DRM محمي",
    labelEn: "DRM Protected",
    sampleUrl: "https://widevine-cinema.example.com/license/encrypted-manifest.mpd",
  },
];

export function analyzeUrlDeterministic(rawUrl: string): AnalysisResult {
  const cleanUrl = rawUrl.trim() || DEMO_SCENARIOS[0].sampleUrl;
  const lower = cleanUrl.toLowerCase();

  if (lower.includes("widevine") || lower.includes("drm") || lower.includes("fairplay")) {
    return {
      originalUrl: cleanUrl,
      normalizedUrl: cleanUrl,
      domain: "widevine-cinema.example.com",
      siteName: "Protected Cinema",
      faviconBg: "#E11D48",
      faviconText: "DR",
      title: "Widevine L1 Encrypted Stream",
      suggestedFileName: "drm_protected_stream.mpd",
      primaryBadgeAr: "محمي بـ DRM",
      primaryBadgeEn: "DRM Protected",
      dominantAccent: "#FB7185",
      primarySize: { bytes: 0, precision: "UNKNOWN", source: "Blocked" },
      formats: [],
      stageLatencyMs: 42,
      drmBlockedReasonAr:
        "تم اكتشاف حماية DRM (Widevine/PlayReady). يلتزم Aurora Get بالقوانين ولا يقوم بتجاوز DRM أو الحوائط المدفوعة.",
      drmBlockedReasonEn:
        "DRM protection detected (Widevine/PlayReady). Aurora Get strictly refuses DRM or paywall circumvention.",
    };
  }

  if (lower.includes("streamhub") || lower.includes("cloudflare") || lower.includes("indirect")) {
    return {
      originalUrl: cleanUrl,
      normalizedUrl: cleanUrl,
      domain: "streamhub.example.org",
      siteName: "StreamHub Web",
      faviconBg: "#F59E0B",
      faviconText: "SH",
      title: "Protected Web Media Page (Cloudflare Turnstile)",
      suggestedFileName: "streamhub_capture.mp4",
      primaryBadgeAr: "صفحة ويب",
      primaryBadgeEn: "Web Page",
      dominantAccent: "#F59E0B",
      primarySize: { bytes: 0, precision: "UNKNOWN", source: "Requires WebView" },
      formats: [],
      stageLatencyMs: 285,
      requiresWebViewSniffer: true,
    };
  }

  if (lower.endsWith(".apk") || lower.endsWith(".zip") || lower.endsWith(".pdf") || lower.includes("releases.")) {
    return {
      originalUrl: cleanUrl,
      normalizedUrl: cleanUrl,
      domain: "releases.auroraget.app",
      siteName: "Aurora Releases",
      faviconBg: "#10B981",
      faviconText: "AG",
      title: "AuroraGet-v1.0.0-arm64.apk",
      suggestedFileName: "AuroraGet-v1.0.0-arm64.apk",
      primaryBadgeAr: "حزمة APK",
      primaryBadgeEn: "APK Package",
      dominantAccent: "#10B981",
      primarySize: { bytes: 48_912_384, precision: "EXACT", source: "HEAD Content-Length" },
      stageLatencyMs: 118,
      formats: [
        {
          id: "apk-direct-1",
          category: "FILE",
          title: "AuroraGet-v1.0.0-arm64.apk",
          qualityLabel: "ARM64-v8a Signed",
          extension: "APK",
          codec: "Android Package",
          size: { bytes: 48_912_384, precision: "EXACT", source: "HEAD Content-Length" },
          downloadUrl: cleanUrl,
        },
        {
          id: "apk-sha-2",
          category: "FILE",
          title: "SHA256SUMS.txt",
          qualityLabel: "Checksum",
          extension: "TXT",
          codec: "UTF-8",
          size: { bytes: 1_420, precision: "EXACT", source: "HEAD Content-Length" },
          downloadUrl: `${cleanUrl}.sha256`,
        },
      ],
    };
  }

  if (lower.includes("soundcloud") || lower.includes("audio") || lower.includes("music")) {
    return {
      originalUrl: cleanUrl,
      normalizedUrl: cleanUrl,
      domain: "soundcloud.com",
      siteName: "SoundCloud",
      faviconBg: "#FF5500",
      faviconText: "SC",
      title: "Crystalline Waves — Spatial Ambient Master (24-bit)",
      suggestedFileName: "Crystalline_Waves_24bit_Master",
      thumbnailUrl: "/images/aurora-thumb-audio.png",
      primaryBadgeAr: "صوت عالي الدقة",
      primaryBadgeEn: "Hi-Res Audio",
      durationSeconds: 314,
      author: "Aurora Labs Audio",
      publishedDate: "2026-02-14",
      dominantAccent: "#9B72CB",
      primarySize: { bytes: 41_943_040, precision: "EXACT", source: "GET Range 0-0" },
      stageLatencyMs: 240,
      formats: [
        {
          id: "sc-flac",
          category: "AUDIO",
          title: "Lossless Master",
          qualityLabel: "FLAC 24-bit",
          extension: "FLAC",
          codec: "FLAC",
          bitrateKbps: 1411,
          size: { bytes: 41_943_040, precision: "EXACT", source: "GET Range 0-0" },
          downloadUrl: "https://cdn.soundcloud.example/crystalline.flac",
        },
        {
          id: "sc-opus",
          category: "AUDIO",
          title: "Transparent Opus",
          qualityLabel: "256 kbps",
          extension: "OPUS",
          codec: "Opus",
          bitrateKbps: 256,
          size: { bytes: 10_048_112, precision: "EXACT", source: "HEAD Content-Length" },
          downloadUrl: "https://cdn.soundcloud.example/crystalline.opus",
        },
        {
          id: "sc-mp3",
          category: "AUDIO",
          title: "Studio MP3",
          qualityLabel: "320 kbps",
          extension: "MP3",
          codec: "LAME MP3",
          bitrateKbps: 320,
          size: { bytes: 12_560_140, precision: "EXACT", source: "HEAD Content-Length" },
          downloadUrl: "https://cdn.soundcloud.example/crystalline.mp3",
        },
        {
          id: "sc-cover",
          category: "IMAGE",
          title: "Album Artwork 3000×3000",
          qualityLabel: "3000px Original",
          extension: "PNG",
          codec: "PNG",
          size: { bytes: 3_421_890, precision: "EXACT", source: "HEAD Content-Length" },
          downloadUrl: "/images/aurora-thumb-audio.png",
        },
      ],
    };
  }

  if (lower.includes("tiktok")) {
    return {
      originalUrl: cleanUrl,
      normalizedUrl: cleanUrl,
      domain: "tiktok.com",
      siteName: "TikTok",
      faviconBg: "#111827",
      faviconText: "TT",
      title: "Neon Rain in Shibuya — 4K60 Glass Reflections #cyberpunk",
      suggestedFileName: "Neon_Rain_Shibuya_NoWM",
      thumbnailUrl: "/images/aurora-thumb-tiktok.png",
      primaryBadgeAr: "فيديو قصير",
      primaryBadgeEn: "Short Video",
      durationSeconds: 47,
      author: "@cybertokyo",
      publishedDate: "2026-03-01",
      dominantAccent: "#00D2FF",
      primarySize: { bytes: 34_812_940, precision: "EXACT", source: "HEAD Content-Length" },
      stageLatencyMs: 680,
      formats: [
        {
          id: "tt-nowm-hd",
          category: "VIDEO",
          title: "HD 1080p • بدون علامة مائية",
          qualityLabel: "1080p HD (No Watermark)",
          extension: "MP4",
          codec: "HEVC (H.265)",
          fps: 60,
          bitrateKbps: 5800,
          hasWatermark: false,
          size: { bytes: 34_812_940, precision: "EXACT", source: "HEAD Content-Length" },
          downloadUrl: "https://cdn.tiktok.example/shibuya_nowm.mp4",
        },
        {
          id: "tt-wm-720",
          category: "VIDEO",
          title: "720p • مع علامة مائية",
          qualityLabel: "720p (Watermark)",
          extension: "MP4",
          codec: "AVC (H.264)",
          fps: 30,
          bitrateKbps: 2400,
          hasWatermark: true,
          size: { bytes: 14_204_812, precision: "EXACT", source: "HEAD Content-Length" },
          downloadUrl: "https://cdn.tiktok.example/shibuya_wm.mp4",
        },
        {
          id: "tt-audio-orig",
          category: "AUDIO",
          title: "Original Sound — Midnight Synth",
          qualityLabel: "192 kbps M4A",
          extension: "M4A",
          codec: "AAC-LC",
          bitrateKbps: 192,
          size: { bytes: 1_142_880, precision: "EXACT", source: "HEAD Content-Length" },
          downloadUrl: "https://cdn.tiktok.example/sound.m4a",
        },
        {
          id: "tt-cover",
          category: "IMAGE",
          title: "Dynamic Cover + Photo Slides (2)",
          qualityLabel: "2160×3840 Cover",
          extension: "WEBP",
          codec: "WebP",
          size: { bytes: 1_892_410, precision: "EXACT", source: "HEAD Content-Length" },
          downloadUrl: "/images/aurora-thumb-tiktok.png",
        },
      ],
    };
  }

  // Default rich YouTube 8K HDR showcase demonstrating ALL 4 Smart Buttons + Exact vs ≈ + DASH Auto-Merge
  return {
    originalUrl: cleanUrl,
    normalizedUrl: cleanUrl,
    domain: "youtube.com",
    siteName: "YouTube",
    faviconBg: "#EF4444",
    faviconText: "YT",
    title: "Iceland Aurora Borealis Over Glacial Lagoon — 8K 60fps HDR10 Master",
    suggestedFileName: "Iceland_Aurora_Borealis_8K_HDR10",
    thumbnailUrl: "/images/aurora-thumb-yt.png",
    primaryBadgeAr: "فيديو 8K HDR",
    primaryBadgeEn: "8K HDR Video",
    durationSeconds: 512,
    author: "Nordic Cinema 8K",
    publishedDate: "2026-01-22",
    dominantAccent: "#4285F4",
    primarySize: { bytes: 148_372_910, precision: "EXACT", source: "HEAD Content-Length + Audio Sum" },
    stageLatencyMs: 890,
    formats: [
      {
        id: "yt-8k-av1",
        category: "VIDEO",
        title: "4320p 8K HDR • AV1",
        qualityLabel: "8K 4320p",
        extension: "MP4",
        codec: "AV1",
        fps: 60,
        bitrateKbps: 42000,
        isHdr: true,
        requiresAudioMerge: true,
        size: { bytes: 1_482_910_420, precision: "EXACT", source: "DASH Video + Best Audio Exact Sum" },
        downloadUrl: "https://rr1.googlevideo.example/8k_av1.mp4",
      },
      {
        id: "yt-4k-vp9",
        category: "VIDEO",
        title: "2160p 4K HDR • VP9",
        qualityLabel: "4K 2160p",
        extension: "MKV",
        codec: "VP9.2",
        fps: 60,
        bitrateKbps: 18500,
        isHdr: true,
        requiresAudioMerge: true,
        size: { bytes: 542_811_204, precision: "EXACT", source: "DASH Video + Best Audio Exact Sum" },
        downloadUrl: "https://rr1.googlevideo.example/4k_vp9.webm",
      },
      {
        id: "yt-1080-avc",
        category: "VIDEO",
        title: "1080p Full HD • H.264",
        qualityLabel: "1080p FHD",
        extension: "MP4",
        codec: "AVC (H.264)",
        fps: 60,
        bitrateKbps: 5400,
        requiresAudioMerge: true,
        size: { bytes: 148_372_910, precision: "EXACT", source: "HEAD Content-Length" },
        downloadUrl: "https://rr1.googlevideo.example/1080p_avc.mp4",
      },
      {
        id: "yt-720-hls",
        category: "VIDEO",
        title: "720p Stream • HLS Live Mirror",
        qualityLabel: "720p HD",
        extension: "MP4",
        codec: "AVC",
        fps: 30,
        bitrateKbps: 2200,
        requiresAudioMerge: false,
        size: { bytes: 74_190_000, precision: "APPROXIMATE", source: "yt-dlp filesize_approx" },
        downloadUrl: "https://rr1.googlevideo.example/720p.m3u8",
      },
      {
        id: "yt-aud-opus",
        category: "AUDIO",
        title: "Opus Original WebM Audio",
        qualityLabel: "160 kbps Opus",
        extension: "OPUS",
        codec: "Opus",
        bitrateKbps: 160,
        size: { bytes: 10_341_120, precision: "EXACT", source: "HEAD Content-Length" },
        downloadUrl: "https://rr1.googlevideo.example/audio.opus",
      },
      {
        id: "yt-aud-m4a",
        category: "AUDIO",
        title: "AAC-LC Native M4A",
        qualityLabel: "256 kbps M4A",
        extension: "M4A",
        codec: "AAC",
        bitrateKbps: 256,
        size: { bytes: 16_422_910, precision: "EXACT", source: "HEAD Content-Length" },
        downloadUrl: "https://rr1.googlevideo.example/audio.m4a",
      },
      {
        id: "yt-aud-flac",
        category: "AUDIO",
        title: "FLAC Lossless Post-Process",
        qualityLabel: "FLAC Extract",
        extension: "FLAC",
        codec: "FLAC",
        bitrateKbps: 980,
        size: { bytes: 61_900_000, precision: "APPROXIMATE", source: "Estimated Transcode" },
        downloadUrl: "https://rr1.googlevideo.example/audio.flac",
      },
      {
        id: "yt-img-max",
        category: "IMAGE",
        title: "MaxRes Thumbnail (3840×2160)",
        qualityLabel: "4K Cover",
        extension: "JPG",
        codec: "JPEG",
        size: { bytes: 2_481_920, precision: "EXACT", source: "HEAD Content-Length" },
        downloadUrl: "/images/aurora-thumb-yt.png",
      },
      {
        id: "yt-img-webp",
        category: "IMAGE",
        title: "WebP Poster Thumbnail",
        qualityLabel: "1920×1080",
        extension: "WEBP",
        codec: "WebP",
        size: { bytes: 482_110, precision: "EXACT", source: "HEAD Content-Length" },
        downloadUrl: "/images/aurora-thumb-yt.png",
      },
      {
        id: "yt-sub-ar",
        category: "FILE",
        title: "Arabic Subtitles (العربية)",
        qualityLabel: "SRT Subtitles",
        extension: "SRT",
        codec: "UTF-8",
        size: { bytes: 42_180, precision: "EXACT", source: "HEAD Content-Length" },
        downloadUrl: "https://youtube.example/subs/ar.srt",
      },
      {
        id: "yt-sub-en",
        category: "FILE",
        title: "English CC Subtitles",
        qualityLabel: "VTT / ASS",
        extension: "VTT",
        codec: "WebVTT",
        size: { bytes: 39_640, precision: "EXACT", source: "HEAD Content-Length" },
        downloadUrl: "https://youtube.example/subs/en.vtt",
      },
      {
        id: "yt-meta-json",
        category: "FILE",
        title: "Full Info Metadata + Description",
        qualityLabel: "JSON Info",
        extension: "JSON",
        codec: "JSON",
        size: { bytes: 18_920, precision: "EXACT", source: "Generated" },
        downloadUrl: "https://youtube.example/info.json",
      },
    ],
  };
}
