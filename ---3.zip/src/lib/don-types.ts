// 𝒥𝒪 DON — Offline-first native Android app data models (client-side showcase only, zero backend)

export type MediaCategory = "AUDIO" | "IMAGE" | "VIDEO" | "FILE";
export type SizePrecision = "EXACT" | "APPROXIMATE" | "UNKNOWN";
export type LangCode = "ar" | "en";
export type DonTheme = "AURORA" | "OCEAN" | "SUNSET" | "EMERALD" | "MONO" | "NEON";
export type DonYtTab = "HOME" | "SHORTS" | "SUBS" | "LIBRARY" | "PLAYER";
export type DonRepeatMode = "OFF" | "ONE" | "ALL" | "SHUFFLE";

export interface FileSizeInfo {
  bytes: number;
  precision: SizePrecision;
  source: string;
}

export interface MediaFormat {
  id: string;
  category: MediaCategory;
  title: string;
  qualityLabel: string;
  extension: string;
  codec: string;
  fps?: number;
  bitrateKbps?: number;
  isHdr?: boolean;
  requiresAudioMerge?: boolean;
  hasWatermark?: boolean;
  size: FileSizeInfo;
  audioOnly?: boolean;
}

export interface AnalysisResult {
  normalizedUrl: string;
  domain: string;
  siteName: string;
  faviconBg: string;
  faviconText: string;
  title: string;
  suggestedFileName: string;
  thumbnailUrl?: string;
  primaryBadgeAr: string;
  primaryBadgeEn: string;
  durationSeconds?: number;
  author?: string;
  primarySize: FileSizeInfo;
  formats: MediaFormat[];
  drmBlockedReasonAr?: string;
  drmBlockedReasonEn?: string;
  requiresWebViewSniffer?: boolean;
  stageLatencyMs: number;
}

export interface DonVideo {
  id: string;
  title: string;
  channelName: string;
  channelHandle: string;
  channelAvatarGradient: string;
  thumbnailUrl: string;
  durationSeconds: number;
  viewsFormatted: string;
  publishedRelative: string;
  verified: boolean;
  isShort: boolean;
  isLive?: boolean;
  category?: string;
  description?: string;
  subsCount?: string;
}

export interface DonChannel {
  id: string;
  name: string;
  handle: string;
  avatarGradient: string;
  subsCount: string;
  followed: boolean;
  notificationsOn: boolean;
}

export interface DonLocalProfile {
  displayName: string;
  handle: string;
  bio: string;
  totalWatched: number;
  totalDownloads: number;
  followingCount: number;
}

export interface DonDownload {
  id: string;
  title: string;
  fileName: string;
  category: MediaCategory;
  siteName: string;
  totalBytes: number;
  sizePrecision: SizePrecision;
  downloadedBytes: number;
  maxConnections: number;
  status: "DOWNLOADING" | "COMPLETED" | "PAUSED" | "MERGING" | "QUEUED" | "FAILED";
  priority: number;
  speedBps: number;
  speedHistory: number[];
  workStealing: boolean;
  requiresMerge: boolean;
  thumbnailUrl?: string;
  savedByCompressionBytes: number;
}

export interface DonThemePreview {
  key: DonTheme;
  nameAr: string;
  nameEn: string;
  start: string;
  mid: string;
  end: string;
  bgDark: string;
  bgLight: string;
  previewImage: string;
  descriptionAr: string;
  descriptionEn: string;
}
