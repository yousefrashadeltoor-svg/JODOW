import {
  bigint,
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const auroraSettings = pgTable("aurora_settings", {
  id: integer("id").primaryKey().default(1),
  themePreset: text("theme_preset").notNull().default("AURORA"),
  darkMode: boolean("dark_mode").notNull().default(true),
  amoledPureBlack: boolean("amoled_pure_black").notNull().default(true),
  dynamicCoverColor: boolean("dynamic_cover_color").notNull().default(true),
  languageCode: text("language_code").notNull().default("ar"),
  defaultSegments: integer("default_segments").notNull().default(16),
  dohEnabled: boolean("doh_enabled").notNull().default(true),
  adBlockEnabled: boolean("ad_block_enabled").notNull().default(true),
  clipboardAutoDetect: boolean("clipboard_auto_detect").notNull().default(true),
  copyrightAccepted: boolean("copyright_accepted").notNull().default(true),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const auroraDownloads = pgTable("aurora_downloads", {
  id: text("id").primaryKey(),
  url: text("url").notNull(),
  fileName: text("file_name").notNull(),
  category: text("category").notNull(),
  siteName: text("site_name").notNull(),
  domain: text("domain").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  totalBytes: bigint("total_bytes", { mode: "number" }).notNull().default(0),
  sizePrecision: text("size_precision").notNull().default("EXACT"),
  downloadedBytes: bigint("downloaded_bytes", { mode: "number" }).notNull().default(0),
  maxConnections: integer("max_connections").notNull().default(16),
  status: text("status").notNull().default("QUEUED"),
  priority: integer("priority").notNull().default(0),
  requiresMerge: boolean("requires_merge").notNull().default(false),
  savedByCompressionBytes: bigint("saved_by_compression_bytes", { mode: "number" }).notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const auroraAnalysisHistory = pgTable("aurora_analysis_history", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  domain: text("domain").notNull(),
  siteName: text("site_name").notNull(),
  title: text("title").notNull(),
  primaryBadge: text("primary_badge").notNull(),
  totalFormats: integer("total_formats").notNull().default(0),
  analyzedAt: timestamp("analyzed_at").defaultNow().notNull(),
});
