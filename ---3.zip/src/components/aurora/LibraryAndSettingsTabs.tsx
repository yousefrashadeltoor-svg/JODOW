"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Check,
  Download,
  Fingerprint,
  Gauge,
  Globe,
  HardDrive,
  Hash,
  Lock,
  Moon,
  Play,
  RefreshCw,
  ShieldCheck,
  Sun,
  Unlock,
} from "lucide-react";
import {
  formatHumanBinary,
  THEME_PALETTES,
  type AuroraAppSettings,
  type AuroraThemePreset,
  type DownloadItem,
  type LangCode,
} from "@/lib/aurora-types";

export function LibraryTab({
  lang,
  darkMode,
  completedDownloads,
  onPlayMedia,
}: {
  lang: LangCode;
  darkMode: boolean;
  completedDownloads: DownloadItem[];
  onPlayMedia: (media: { title: string; thumb: string }) => void;
}) {
  const [vaultUnlocked, setVaultUnlocked] = useState(false);
  const [verifyingBio, setVerifyingBio] = useState(false);
  const [verifiedHashId, setVerifiedHashId] = useState<string | null>(null);

  const handleToggleVault = () => {
    if (vaultUnlocked) {
      setVaultUnlocked(false);
      return;
    }
    setVerifyingBio(true);
    setTimeout(() => {
      setVerifyingBio(false);
      setVaultUnlocked(true);
    }, 650);
  };

  return (
    <div className="space-y-4 px-4 pb-28 pt-4">
      <div>
        <h1 className="aurora-gradient-text text-xl font-extrabold">
          {lang === "ar" ? "المكتبة والقبو الخاص" : "Library & Private Vault"}
        </h1>
        <p className="text-[11px] opacity-65">
          {lang === "ar"
            ? "تنظيم تلقائي عبر Scoped Storage + تشفير AES-256-GCM بالبصمة"
            : "MediaStore Scoped Storage + Biometric AES-256-GCM Vault"}
        </p>
      </div>

      {/* Private Biometric AES-256 Vault Card */}
      <div
        className={`aurora-glass-card space-y-3 rounded-[26px] p-4 ${
          vaultUnlocked ? "aurora-gemini-glow" : ""
        }`}
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="aurora-gradient-bg flex h-10 w-10 items-center justify-center rounded-2xl text-white">
              {verifyingBio ? (
                <Fingerprint className="h-5 w-5 animate-pulse" />
              ) : vaultUnlocked ? (
                <Unlock className="h-5 w-5" />
              ) : (
                <Lock className="h-5 w-5" />
              )}
            </div>
            <div>
              <p className="text-xs font-extrabold">
                {lang === "ar" ? "القبو المشفّر (AES-256)" : "Encrypted Private Vault"}
              </p>
              <p className="text-[10px] opacity-70">
                {vaultUnlocked
                  ? lang === "ar"
                    ? "مفتوح بالبصمة • 2 ملفات محمية"
                    : "Unlocked via Biometric • 2 encrypted files"
                  : lang === "ar"
                  ? "مقفل ببصمة AndroidX Biometric"
                  : "Locked with AndroidX Biometric"}
              </p>
            </div>
          </div>
          <motion.button
            type="button"
            whileTap={{ scale: 0.94 }}
            onClick={handleToggleVault}
            className="aurora-gradient-bg rounded-[16px] px-3.5 py-2 text-xs font-bold text-white"
          >
            {verifyingBio
              ? "..."
              : vaultUnlocked
              ? lang === "ar"
                ? "قفل"
                : "Lock"
              : lang === "ar"
              ? "فتح بالبصمة"
              : "Unlock"}
          </motion.button>
        </div>

        {vaultUnlocked && (
          <div className="space-y-1.5 rounded-[18px] bg-black/25 p-2.5 text-[11px]">
            <div className="flex items-center justify-between">
              <span className="font-mono-aurora">private_clip_hdr.agv</span>
              <span className="text-emerald-400">AES-256-GCM</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-mono-aurora">confidential_docs.agv</span>
              <span className="text-emerald-400">AES-256-GCM</span>
            </div>
          </div>
        )}
      </div>

      {/* Downloaded Files Grid */}
      <div className="space-y-2.5">
        {completedDownloads.map((item) => (
          <div key={item.id} className="aurora-glass-card space-y-2.5 rounded-[24px] p-3.5">
            <div className="flex items-center gap-3">
              {item.thumbnailUrl ? (
                <img
                  src={item.thumbnailUrl}
                  alt={item.fileName}
                  className="h-14 w-14 rounded-[16px] object-cover"
                />
              ) : (
                <div className="flex h-14 w-14 items-center justify-center rounded-[16px] bg-white/10">
                  <HardDrive className="h-6 w-6 opacity-60" />
                </div>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-bold">{item.fileName}</p>
                <p className="font-mono-aurora mt-0.5 text-[10px] opacity-65">
                  {item.category} • {formatHumanBinary(item.totalBytes)}
                </p>
                {item.savedByCompressionBytes > 0 && (
                  <p className="mt-0.5 text-[10px] text-emerald-400">
                    {lang === "ar"
                      ? `تم توفير ${formatHumanBinary(item.savedByCompressionBytes)} بالتصغير`
                      : `Saved ${formatHumanBinary(item.savedByCompressionBytes)} via Compressor`}
                  </p>
                )}
              </div>
            </div>

            {verifiedHashId === item.id && (
              <div className="rounded-xl bg-emerald-500/15 px-2.5 py-1.5 font-mono-aurora text-[9.5px] text-emerald-300">
                SHA-256 OK: 9f84b2c1d7e0412a8c5f01b7...e2a9
              </div>
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  onPlayMedia({
                    title: item.fileName,
                    thumb: item.thumbnailUrl || "/images/aurora-thumb-audio.png",
                  })
                }
                className="aurora-gradient-bg flex flex-1 items-center justify-center gap-1.5 rounded-[14px] py-2 text-[11px] font-bold text-white"
              >
                <Play className="h-3.5 w-3.5 fill-white" />
                <span>{lang === "ar" ? "تشغيل بـ Media3" : "Play Media3"}</span>
              </button>
              <button
                type="button"
                onClick={() => setVerifiedHashId(item.id)}
                className={`flex items-center gap-1 rounded-[14px] px-3 py-2 text-[11px] font-semibold ${
                  darkMode ? "bg-white/10" : "bg-slate-200/80"
                }`}
              >
                <Hash className="h-3.5 w-3.5 text-[#4285F4]" />
                <span>SHA-256</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function SettingsTab({
  settings,
  totalDownloadedBytes,
  totalSavedBytes,
  onUpdateSettings,
  onReplayOnboarding,
}: {
  settings: AuroraAppSettings;
  totalDownloadedBytes: number;
  totalSavedBytes: number;
  onUpdateSettings: (patch: Partial<AuroraAppSettings>) => void;
  onReplayOnboarding: () => void;
}) {
  const lang = settings.languageCode;
  const [speedTesting, setSpeedTesting] = useState(false);
  const [speedResult, setSpeedResult] = useState<string | null>(null);
  const [ytStatus, setYtStatus] = useState<string | null>(null);
  const [backupCopied, setBackupCopied] = useState(false);

  const runSpeedTest = () => {
    setSpeedTesting(true);
    setSpeedResult(null);
    setTimeout(() => {
      setSpeedTesting(false);
      setSpeedResult(
        lang === "ar"
          ? "248.4 Mbps • الاتصالات المثلى المقترحة: 24 اتصالًا"
          : "248.4 Mbps • Recommended optimal segments: 24"
      );
      onUpdateSettings({ defaultSegments: 24 });
    }, 950);
  };

  const handleBackup = () => {
    const payload = JSON.stringify({ app: "Aurora Get", version: "1.0.0", settings }, null, 2);
    navigator.clipboard?.writeText(payload);
    setBackupCopied(true);
    setTimeout(() => setBackupCopied(false), 2000);
  };

  return (
    <div className="space-y-4 px-4 pb-28 pt-4">
      <div>
        <h1 className="aurora-gradient-text text-xl font-extrabold">
          {lang === "ar" ? "الإعدادات والخصوصية" : "Settings & Privacy"}
        </h1>
        <p className="text-[11px] opacity-65">
          {lang === "ar"
            ? "نظام Aurora Glass بالكامل • بدون Material • بدون تتبع"
            : "Pure Aurora Glass • Zero Material • Zero Telemetry"}
        </p>
      </div>

      {/* 6 Aurora Glass Themes */}
      <div className="aurora-glass-card space-y-3 rounded-[26px] p-4">
        <p className="text-xs font-extrabold">
          {lang === "ar" ? "سمات Aurora Glass (6 ثيمات)" : "Aurora Glass Themes (6 Presets)"}
        </p>
        <div className="grid grid-cols-3 gap-2">
          {(Object.keys(THEME_PALETTES) as AuroraThemePreset[]).map((preset) => {
            const pal = THEME_PALETTES[preset];
            const active = settings.themePreset === preset;
            return (
              <button
                key={preset}
                type="button"
                onClick={() => onUpdateSettings({ themePreset: preset })}
                className={`flex flex-col items-center gap-1.5 rounded-[18px] border p-2.5 transition ${
                  active ? "border-white/50 bg-white/15" : "border-white/10 bg-white/5 opacity-80"
                }`}
              >
                <span
                  className="h-5 w-12 rounded-full"
                  style={{
                    background: `linear-gradient(120deg, ${pal.start}, ${pal.mid}, ${pal.end})`,
                  }}
                />
                <span className="text-[10px] font-bold">
                  {lang === "ar" ? pal.nameAr : pal.nameEn}
                </span>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            type="button"
            onClick={() => onUpdateSettings({ darkMode: !settings.darkMode })}
            className="aurora-glass-card flex items-center justify-center gap-1.5 rounded-[18px] py-2.5 text-xs font-bold"
          >
            {settings.darkMode ? <Moon className="h-3.5 w-3.5 text-sky-400" /> : <Sun className="h-3.5 w-3.5 text-amber-400" />}
            <span>
              {settings.darkMode
                ? lang === "ar"
                  ? "داكن AMOLED"
                  : "AMOLED Dark"
                : lang === "ar"
                ? "نهاري زجاجي"
                : "Light Glass"}
            </span>
          </button>
          <button
            type="button"
            onClick={() => onUpdateSettings({ languageCode: lang === "ar" ? "en" : "ar" })}
            className="aurora-gradient-bg flex items-center justify-center gap-1.5 rounded-[18px] py-2.5 text-xs font-bold text-white"
          >
            <Globe className="h-3.5 w-3.5" />
            <span>{lang === "ar" ? "العربية (RTL)" : "English (LTR)"}</span>
          </button>
        </div>
      </div>

      {/* Engine, Segments & Speed Test */}
      <div className="aurora-glass-card space-y-3 rounded-[26px] p-4">
        <div className="flex items-center justify-between">
          <p className="text-xs font-extrabold">
            {lang === "ar" ? "عدد الاتصالات المجزأة" : "Parallel Download Segments"}
          </p>
          <span className="font-mono-aurora rounded-full bg-[#4285F4]/25 px-2.5 py-0.5 text-xs font-bold text-sky-300">
            {settings.defaultSegments}
          </span>
        </div>
        <input
          type="range"
          min={8}
          max={32}
          step={4}
          value={settings.defaultSegments}
          onChange={(e) => onUpdateSettings({ defaultSegments: Number(e.target.value) })}
          className="w-full accent-[#4285F4]"
        />

        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => onUpdateSettings({ dohEnabled: !settings.dohEnabled })}
            className={`rounded-[16px] py-2 text-[11px] font-bold ${
              settings.dohEnabled ? "bg-emerald-500/20 text-emerald-300" : "bg-white/8 opacity-70"
            }`}
          >
            DNS-over-HTTPS: {settings.dohEnabled ? "ON" : "OFF"}
          </button>
          <button
            type="button"
            onClick={() => onUpdateSettings({ dynamicCoverColor: !settings.dynamicCoverColor })}
            className={`rounded-[16px] py-2 text-[11px] font-bold ${
              settings.dynamicCoverColor ? "bg-violet-500/20 text-violet-300" : "bg-white/8 opacity-70"
            }`}
          >
            {lang === "ar" ? "ألوان الغلاف" : "Cover Tint"}: {settings.dynamicCoverColor ? "ON" : "OFF"}
          </button>
        </div>

        <div className="flex gap-2">
          <button
            type="button"
            onClick={runSpeedTest}
            className="aurora-gradient-bg flex flex-1 items-center justify-center gap-1.5 rounded-[18px] py-2.5 text-xs font-bold text-white"
          >
            <Gauge className="h-3.5 w-3.5" />
            <span>
              {speedTesting
                ? lang === "ar"
                  ? "جارٍ القياس..."
                  : "Testing..."
                : lang === "ar"
                ? "اختبار السرعة"
                : "Speed Test"}
            </span>
          </button>
          <button
            type="button"
            onClick={() =>
              setYtStatus(
                lang === "ar"
                  ? "yt-dlp 2026.03 + EasyList محدّثان"
                  : "yt-dlp 2026.03 + EasyList up to date"
              )
            }
            className="aurora-glass-card flex items-center gap-1.5 rounded-[18px] px-3 py-2.5 text-xs font-bold"
          >
            <RefreshCw className="h-3.5 w-3.5 text-[#9B72CB]" />
            <span>yt-dlp</span>
          </button>
        </div>

        {speedResult && <p className="font-mono-aurora text-[11px] text-emerald-400">{speedResult}</p>}
        {ytStatus && <p className="font-mono-aurora text-[11px] text-sky-400">{ytStatus}</p>}
      </div>

      {/* Offline Statistics & JSON Backup */}
      <div className="aurora-glass-card space-y-2.5 rounded-[26px] p-4">
        <p className="text-xs font-extrabold">
          {lang === "ar" ? "إحصائيات محلية + نسخ احتياطي JSON" : "Offline Stats & JSON Backup"}
        </p>
        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-[18px] bg-white/5 p-3">
            <p className="text-[10px] opacity-65">{lang === "ar" ? "إجمالي المحمّل" : "Total Downloaded"}</p>
            <p className="font-mono-aurora mt-1 text-sm font-extrabold text-sky-400">
              {formatHumanBinary(totalDownloadedBytes)}
            </p>
          </div>
          <div className="rounded-[18px] bg-white/5 p-3">
            <p className="text-[10px] opacity-65">{lang === "ar" ? "التوفير بالتصغير" : "Compressor Saved"}</p>
            <p className="font-mono-aurora mt-1 text-sm font-extrabold text-emerald-400">
              {formatHumanBinary(totalSavedBytes)}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={handleBackup}
            className="aurora-glass-card flex flex-1 items-center justify-center gap-1.5 rounded-[16px] py-2 text-xs font-bold"
          >
            {backupCopied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Download className="h-3.5 w-3.5" />}
            <span>
              {backupCopied
                ? lang === "ar"
                  ? "تم نسخ JSON"
                  : "JSON Copied"
                : lang === "ar"
                ? "تصدير إعدادات JSON"
                : "Export JSON"}
            </span>
          </button>
          <button
            type="button"
            onClick={onReplayOnboarding}
            className="aurora-glass-card rounded-[16px] px-3 py-2 text-xs font-semibold"
          >
            {lang === "ar" ? "الترحيب" : "Intro"}
          </button>
        </div>
      </div>

      {/* Legal Copyright & Zero DRM Notice */}
      <div className="aurora-glass-card flex items-start gap-2.5 rounded-[24px] p-4 text-[11px] opacity-85">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
        <p className="leading-relaxed">
          {lang === "ar"
            ? "المسؤولية كاملة على المستخدم في احترام حقوق النشر. يعمل التطبيق Offline-first بدون Firebase أو تتبع، ولا يتجاوز DRM (Widevine/FairPlay/PlayReady) أو Paywalls."
            : "Users are solely responsible for respecting copyright laws. Offline-first with zero Firebase/tracking. DRM (Widevine/FairPlay/PlayReady) and paywalls are never bypassed."}
        </p>
      </div>
    </div>
  );
}
