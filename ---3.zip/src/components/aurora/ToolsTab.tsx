"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  CheckCircle2,
  FileCheck,
  Minimize2,
  ShieldCheck,
  Sliders,
  Sparkles,
  Wand2,
} from "lucide-react";
import {
  formatHumanBinary,
  type CompressionMode,
  type LangCode,
} from "@/lib/aurora-types";

export function ToolsTab({
  lang,
  darkMode,
  initialSubTab,
  selectedFileLabel,
}: {
  lang: LangCode;
  darkMode: boolean;
  initialSubTab: "compressor" | "converter";
  selectedFileLabel: string;
}) {
  const [subTab, setSubTab] = useState<"compressor" | "converter">(initialSubTab);
  const [mode, setMode] = useState<CompressionMode>("VISUALLY_TRANSPARENT");
  const [sliderPos, setSliderPos] = useState(52);
  const [compressing, setCompressing] = useState(false);
  const [compressedDone, setCompressedDone] = useState(true);
  const [alreadyOptimalDemo, setAlreadyOptimalDemo] = useState(false);

  // Converter state
  const [targetFormat, setTargetFormat] = useState("OPUS");
  const [bitrate, setBitrate] = useState(256);
  const [streamCopy, setStreamCopy] = useState(true);
  const [converting, setConverting] = useState(false);
  const [convertedMsg, setConvertedMsg] = useState<string | null>(null);

  const origBytes = 148_372_910;
  const outBytes =
    mode === "LOSSLESS" ? 124_633_244 : 84_572_558; // 16% lossless vs 43% HEVC/AV1 SSIM>=95%
  const savedBytes = origBytes - outBytes;
  const savedPct = ((savedBytes / origBytes) * 100).toFixed(1);

  const runCompression = () => {
    setCompressing(true);
    setCompressedDone(false);
    setTimeout(() => {
      setCompressing(false);
      setCompressedDone(true);
    }, 900);
  };

  const runConvert = () => {
    setConverting(true);
    setConvertedMsg(null);
    setTimeout(() => {
      setConverting(false);
      setConvertedMsg(
        lang === "ar"
          ? `تم الاستخراج والتحويل بنجاح إلى ${targetFormat} (${bitrate} kbps)`
          : `Converted successfully to ${targetFormat} (${bitrate} kbps)`
      );
    }, 850);
  };

  return (
    <div className="space-y-4 px-4 pb-28 pt-4">
      {/* Sub-tab Pill Switcher */}
      <div className="aurora-glass-card grid grid-cols-2 gap-1.5 rounded-[24px] p-1.5">
        <button
          type="button"
          onClick={() => setSubTab("compressor")}
          className={`flex items-center justify-center gap-1.5 rounded-[18px] py-2.5 text-xs font-bold transition ${
            subTab === "compressor" ? "aurora-gradient-bg text-white" : "opacity-70"
          }`}
        >
          <Minimize2 className="h-3.5 w-3.5" />
          <span>{lang === "ar" ? "التصغير الذكي" : "Smart Compressor"}</span>
        </button>
        <button
          type="button"
          onClick={() => setSubTab("converter")}
          className={`flex items-center justify-center gap-1.5 rounded-[18px] py-2.5 text-xs font-bold transition ${
            subTab === "converter" ? "aurora-gradient-bg text-white" : "opacity-70"
          }`}
        >
          <Wand2 className="h-3.5 w-3.5" />
          <span>{lang === "ar" ? "محول الصيغ" : "Converter"}</span>
        </button>
      </div>

      {subTab === "compressor" ? (
        <div className="space-y-3.5">
          <div className="aurora-glass-card space-y-3 rounded-[26px] p-4">
            <div className="flex items-center justify-between">
              <div className="min-w-0">
                <p className="truncate text-xs font-bold">{selectedFileLabel}</p>
                <p className="text-[10px] opacity-65">
                  {lang === "ar"
                    ? "لا يُستبدل الملف الأصلي أبدًا — يُحفظ ناتج جديد آمن"
                    : "Original file is never overwritten — new safe output created"}
                </p>
              </div>
              <span className="rounded-full bg-emerald-500/20 px-2.5 py-1 font-mono-aurora text-[10px] font-bold text-emerald-300">
                {mode === "LOSSLESS" ? "100% Bit-Exact" : "SSIM 98.4%"}
              </span>
            </div>

            {/* Two Clear Modes: Lossless vs Visually Transparent */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setMode("LOSSLESS");
                  setAlreadyOptimalDemo(false);
                }}
                className={`rounded-[20px] border p-3 text-start transition ${
                  mode === "LOSSLESS"
                    ? "border-emerald-400/60 bg-emerald-500/20"
                    : "border-white/10 bg-white/5 opacity-75"
                }`}
              >
                <p className="text-xs font-extrabold">
                  🟢 {lang === "ar" ? "Lossless بدون فقد" : "Lossless"}
                </p>
                <p className="mt-0.5 text-[10px] opacity-75">
                  {lang === "ar"
                    ? "mozjpeg / oxipng / zopfli / FLAC"
                    : "Zero pixel or sample loss"}
                </p>
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode("VISUALLY_TRANSPARENT");
                  setAlreadyOptimalDemo(false);
                }}
                className={`rounded-[20px] border p-3 text-start transition ${
                  mode === "VISUALLY_TRANSPARENT"
                    ? "border-amber-400/60 bg-amber-500/20"
                    : "border-white/10 bg-white/5 opacity-75"
                }`}
              >
                <p className="text-xs font-extrabold">
                  🟡 {lang === "ar" ? "شفاف بصريًا" : "Transparent"}
                </p>
                <p className="mt-0.5 text-[10px] opacity-75">
                  {lang === "ar"
                    ? "HEVC/AV1 مع تحقق VMAF/SSIM ≥ 95%"
                    : "HEVC/AV1 verified SSIM ≥ 95%"}
                </p>
              </button>
            </div>

            {/* Interactive Glass Before / After Comparison Slider */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[10px] opacity-75">
                <span>{lang === "ar" ? "سلايدر مقارنة Before / After" : "Before / After Comparison Slider"}</span>
                <span className="font-mono-aurora">{sliderPos}%</span>
              </div>
              <div className="relative h-44 w-full overflow-hidden rounded-[22px] border border-white/15 select-none">
                <img
                  src="/images/aurora-thumb-yt.png"
                  alt="After compression"
                  className="absolute inset-0 h-full w-full object-cover"
                />
                <div
                  className="absolute inset-y-0 left-0 overflow-hidden"
                  style={{ width: `${sliderPos}%` }}
                >
                  <img
                    src="/images/aurora-thumb-yt.png"
                    alt="Before compression"
                    className="h-full w-full max-w-none object-cover brightness-105 contrast-105"
                    style={{ width: "360px" }}
                  />
                </div>
                <div
                  className="pointer-events-none absolute inset-y-0 w-0.5 bg-white shadow-[0_0_12px_#fff]"
                  style={{ left: `${sliderPos}%` }}
                >
                  <div className="aurora-gradient-bg absolute top-1/2 -left-3.5 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-full border border-white/80 text-white shadow-lg">
                    <Sliders className="h-3.5 w-3.5" />
                  </div>
                </div>
                <span className="absolute start-2.5 top-2.5 rounded-full bg-black/65 px-2.5 py-0.5 font-mono-aurora text-[10px] font-bold text-white backdrop-blur-md">
                  {lang === "ar" ? "قبل" : "BEFORE"} • {formatHumanBinary(origBytes)}
                </span>
                <span className="absolute end-2.5 top-2.5 rounded-full bg-emerald-600/80 px-2.5 py-0.5 font-mono-aurora text-[10px] font-bold text-white backdrop-blur-md">
                  {lang === "ar" ? "بعد" : "AFTER"} • {formatHumanBinary(outBytes)}
                </span>
                <input
                  type="range"
                  min={8}
                  max={92}
                  value={sliderPos}
                  onChange={(e) => setSliderPos(Number(e.target.value))}
                  aria-label="Before and after comparison"
                  className="absolute inset-0 h-full w-full cursor-ew-resize opacity-0"
                />
              </div>
            </div>

            {/* Savings Metrics */}
            {alreadyOptimalDemo ? (
              <div className="flex items-center gap-2 rounded-[18px] border border-amber-400/35 bg-amber-500/15 p-3 text-xs text-amber-200">
                <ShieldCheck className="h-4 w-4 shrink-0 text-amber-400" />
                <span>
                  {lang === "ar"
                    ? "بصدق: الملف مضغوط بأقصى درجة بالفعل؛ لم يتم إنشاء نسخة أكبر."
                    : "Honest check: File is already optimally compressed; no larger output created."}
                </span>
              </div>
            ) : (
              compressedDone && (
                <div className="rounded-[20px] border border-emerald-400/30 bg-emerald-500/12 p-3">
                  <div className="flex items-center justify-between text-xs font-extrabold text-emerald-300">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="h-4 w-4" />
                      {lang === "ar" ? `توفير ${savedPct}%` : `Saved ${savedPct}%`}
                    </span>
                    <span className="font-mono-aurora">-{formatHumanBinary(savedBytes)}</span>
                  </div>
                  <p className="font-mono-aurora mt-1 text-[10px] opacity-80">
                    {new Intl.NumberFormat("en-US").format(origBytes)} B →{" "}
                    {new Intl.NumberFormat("en-US").format(outBytes)} B
                  </p>
                </div>
              )
            )}

            <div className="flex gap-2">
              <motion.button
                type="button"
                whileTap={{ scale: 0.96 }}
                onClick={runCompression}
                className="aurora-gradient-bg flex flex-1 items-center justify-center gap-1.5 rounded-[20px] py-3 text-xs font-bold text-white"
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>
                  {compressing
                    ? lang === "ar"
                      ? "جارٍ التحقق من SSIM..."
                      : "Verifying SSIM..."
                    : lang === "ar"
                    ? "ضغط وحفظ كملف جديد"
                    : "Compress to New File"}
                </span>
              </motion.button>
              <button
                type="button"
                onClick={() => setAlreadyOptimalDemo((v) => !v)}
                className="aurora-glass-card rounded-[20px] px-3 text-[10px] font-semibold"
              >
                {lang === "ar" ? "فحص الصدق" : "Honest Check"}
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="aurora-glass-card space-y-4 rounded-[26px] p-4">
          <div>
            <p className="text-xs font-extrabold">
              {lang === "ar" ? "استخراج وتحويل الصيغ (FFmpeg + MediaCodec)" : "Multi-Format Converter (FFmpeg + MediaCodec)"}
            </p>
            <p className="mt-0.5 truncate font-mono-aurora text-[10px] opacity-65">
              {selectedFileLabel}
            </p>
          </div>

          {[
            {
              labelAr: "صوت (استخراج مباشر بدون إعادة ترميز عند الإمكان)",
              labelEn: "Audio (Stream Copy when supported)",
              items: ["MP3", "M4A", "OPUS", "OGG", "FLAC", "WAV"],
            },
            {
              labelAr: "فيديو + GIF",
              labelEn: "Video + GIF",
              items: ["MP4", "MKV", "WEBM", "MOV", "AVI", "GIF"],
            },
            {
              labelAr: "صور",
              labelEn: "Images",
              items: ["JPG", "PNG", "WEBP", "AVIF"],
            },
          ].map((group) => (
            <div key={group.labelEn} className="space-y-2">
              <p className="text-[11px] font-bold opacity-80">
                {lang === "ar" ? group.labelAr : group.labelEn}
              </p>
              <div className="flex flex-wrap gap-1.5">
                {group.items.map((fmt) => (
                  <button
                    key={fmt}
                    type="button"
                    onClick={() => setTargetFormat(fmt)}
                    className={`rounded-full px-3 py-1.5 font-mono-aurora text-[11px] font-bold transition ${
                      targetFormat === fmt
                        ? "aurora-gradient-bg text-white"
                        : darkMode
                        ? "bg-white/10 text-slate-300 hover:bg-white/15"
                        : "bg-slate-200 text-slate-700"
                    }`}
                  >
                    {fmt}
                  </button>
                ))}
              </div>
            </div>
          ))}

          <div className="flex items-center justify-between rounded-[18px] bg-white/5 px-3 py-2.5 text-xs">
            <span>{lang === "ar" ? "Stream Copy (بدون إعادة ترميز)" : "Stream Copy (Zero Re-encode)"}</span>
            <button
              type="button"
              onClick={() => setStreamCopy((s) => !s)}
              className={`rounded-full px-3 py-1 text-[10px] font-bold ${
                streamCopy ? "bg-emerald-500/25 text-emerald-300" : "bg-white/10 opacity-70"
              }`}
            >
              {streamCopy ? "ON" : "OFF"}
            </button>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between font-mono-aurora text-[10px] opacity-75">
              <span>Bitrate</span>
              <span>{bitrate} kbps</span>
            </div>
            <input
              type="range"
              min={96}
              max={512}
              step={32}
              value={bitrate}
              onChange={(e) => setBitrate(Number(e.target.value))}
              className="w-full accent-[#9B72CB]"
            />
          </div>

          {convertedMsg && (
            <div className="flex items-center gap-2 rounded-[16px] bg-emerald-500/15 px-3 py-2 text-xs text-emerald-300">
              <FileCheck className="h-4 w-4 shrink-0" />
              <span>{convertedMsg}</span>
            </div>
          )}

          <motion.button
            type="button"
            whileTap={{ scale: 0.96 }}
            onClick={runConvert}
            className="aurora-gradient-bg w-full rounded-[20px] py-3 text-xs font-bold text-white"
          >
            {converting
              ? lang === "ar"
                ? "جارٍ المعالجة..."
                : "Processing..."
              : lang === "ar"
              ? `تحويل الآن إلى ${targetFormat}`
              : `Convert Now to ${targetFormat}`}
          </motion.button>
        </div>
      )}
    </div>
  );
}
