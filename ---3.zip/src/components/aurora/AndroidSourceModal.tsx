"use client";

import React, { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Code2, Copy, FileCode2, FolderTree, Search, ShieldCheck, X } from "lucide-react";
import type { LangCode } from "@/lib/aurora-types";

export function AndroidSourceModal({
  open,
  onClose,
  lang,
}: {
  open: boolean;
  onClose: () => void;
  lang: LangCode;
}) {
  const [files, setFiles] = useState<string[]>([]);
  const [search, setSearch] = useState("");
  const [selectedFile, setSelectedFile] = useState<string>("ARCHITECTURE.md");
  const [fileContent, setFileContent] = useState<string>("");
  const [lineCount, setLineCount] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!open) return;
    fetch("/api/project-files")
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data.files)) {
          setFiles(data.files);
          if (!selectedFile && data.files.length > 0) {
            setSelectedFile(data.files[0]);
          }
        }
      })
      .catch(() => null);
  }, [open, selectedFile]);

  useEffect(() => {
    if (!open || !selectedFile) return;
    setLoading(true);
    fetch(`/api/project-files?file=${encodeURIComponent(selectedFile)}`)
      .then((r) => r.json())
      .then((data) => {
        setFileContent(data.content || "");
        setLineCount(data.lines || 0);
      })
      .catch(() => setFileContent("Unable to load file."))
      .finally(() => setLoading(false));
  }, [open, selectedFile]);

  const filtered = files.filter((f) => f.toLowerCase().includes(search.toLowerCase()));

  const handleCopy = () => {
    navigator.clipboard?.writeText(fileContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-lg"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.94, opacity: 0, y: 18 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
            dir="ltr"
            className="aurora-glass-card flex h-[86vh] w-full max-w-6xl flex-col overflow-hidden rounded-[30px] bg-[#0A0D16]/95 text-slate-100"
          >
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-5 py-4">
              <div className="flex items-center gap-3">
                <div className="aurora-gradient-bg flex h-10 w-10 items-center justify-center rounded-2xl">
                  <Code2 className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white">
                    JP PROJ — Complete Android Multi-Module Source ({files.length} files)
                  </h2>
                  <p className="flex items-center gap-1.5 text-xs text-emerald-400">
                    <ShieldCheck className="h-3.5 w-3.5" />
                    {lang === "ar"
                      ? "17 Module كاملة • صفر Material Design • صفر Firebase • جاهز للبناء بـ Android Studio"
                      : "17 Gradle Modules • Zero Material Design • Zero Firebase • Build-Ready Kotlin 2.x"}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 hover:bg-white/20"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="grid min-h-0 flex-1 grid-cols-1 md:grid-cols-[310px_1fr]">
              <div className="flex min-h-0 flex-col border-b border-white/10 bg-black/25 p-3 md:border-b-0 md:border-r">
                <div className="mb-2.5 flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-3 py-2">
                  <Search className="h-4 w-4 text-slate-400" />
                  <input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Filter JP PROJ files..."
                    className="w-full bg-transparent text-xs text-white outline-none placeholder:text-slate-500"
                  />
                </div>
                <div className="no-scrollbar flex-1 space-y-1 overflow-y-auto">
                  {filtered.map((f) => {
                    const active = f === selectedFile;
                    return (
                      <button
                        key={f}
                        type="button"
                        onClick={() => setSelectedFile(f)}
                        className={`flex w-full items-center gap-2 rounded-xl px-2.5 py-2 text-left font-mono-aurora text-[11px] transition ${
                          active
                            ? "aurora-gradient-bg text-white font-semibold"
                            : "text-slate-300 hover:bg-white/10"
                        }`}
                      >
                        {f.endsWith(".kt") || f.endsWith(".kts") ? (
                          <FileCode2 className="h-3.5 w-3.5 shrink-0" />
                        ) : (
                          <FolderTree className="h-3.5 w-3.5 shrink-0" />
                        )}
                        <span className="truncate">{f}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex min-h-0 flex-col bg-[#06080F]">
                <div className="flex items-center justify-between border-b border-white/10 px-4 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate font-mono-aurora text-xs font-semibold text-sky-300">
                      JP PROJ/{selectedFile}
                    </p>
                    <p className="text-[11px] text-slate-500">{lineCount} lines</p>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="flex items-center gap-1.5 rounded-xl bg-white/10 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-white/20"
                  >
                    {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                    {copied ? "Copied" : "Copy File"}
                  </button>
                </div>
                <div className="flex-1 overflow-auto p-4">
                  {loading ? (
                    <div className="space-y-2">
                      <div className="aurora-shimmer h-4 w-2/3 rounded bg-white/10" />
                      <div className="aurora-shimmer h-4 w-1/2 rounded bg-white/10" />
                      <div className="aurora-shimmer h-4 w-3/4 rounded bg-white/10" />
                    </div>
                  ) : (
                    <pre className="font-mono-aurora whitespace-pre text-[11.5px] leading-relaxed text-slate-200">
                      {fileContent}
                    </pre>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
