"use client";

import React, { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Download,
  FolderLock,
  Globe,
  Pause,
  PictureInPicture2,
  Play,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Subtitles,
  Wand2,
  X,
} from "lucide-react";
import type { LangCode } from "@/lib/aurora-types";

export function AuroraMeshBackdrop({
  start,
  mid,
  end,
  darkMode,
  amoled,
  dynamicAccent,
}: {
  start: string;
  mid: string;
  end: string;
  darkMode: boolean;
  amoled: boolean;
  dynamicAccent?: string;
}) {
  const effectiveStart = dynamicAccent || start;
  return (
    <div
      className="pointer-events-none absolute inset-0 overflow-hidden transition-colors duration-700"
      style={{
        backgroundColor: darkMode ? (amoled ? "#06070B" : "#0B0D12") : "#F2F5FC",
      }}
    >
      <div
        className="aurora-blob-a absolute -top-24 -start-20 h-72 w-72 rounded-full blur-[90px] transition-colors duration-700"
        style={{ backgroundColor: effectiveStart, opacity: darkMode ? 0.32 : 0.24 }}
      />
      <div
        className="aurora-blob-b absolute top-1/3 -end-20 h-72 w-72 rounded-full blur-[95px] transition-colors duration-700"
        style={{ backgroundColor: mid, opacity: darkMode ? 0.28 : 0.22 }}
      />
      <div
        className="aurora-blob-c absolute -bottom-24 start-1/4 h-72 w-72 rounded-full blur-[100px] transition-colors duration-700"
        style={{ backgroundColor: end, opacity: darkMode ? 0.24 : 0.18 }}
      />
      <div className="aurora-noise absolute inset-0 opacity-40" />
    </div>
  );
}

export function StreamingText({
  text,
  className = "",
}: {
  text: string;
  className?: string;
}) {
  const [visibleLen, setVisibleLen] = useState(0);

  useEffect(() => {
    setVisibleLen(0);
    if (!text) return;
    const step = Math.max(1, Math.ceil(text.length / 22));
    const interval = setInterval(() => {
      setVisibleLen((prev) => {
        if (prev + step >= text.length) {
          clearInterval(interval);
          return text.length;
        }
        return prev + step;
      });
    }, 18);
    return () => clearInterval(interval);
  }, [text]);

  const done = visibleLen >= text.length;

  return (
    <span
      className={`transition-[filter] duration-300 ${done ? "blur-0" : "blur-[1.5px]"} ${className}`}
    >
      {text.slice(0, visibleLen)}
    </span>
  );
}

export function SparklineSvg({
  samples,
  startColor,
  endColor,
}: {
  samples: number[];
  startColor: string;
  endColor: string;
}) {
  if (samples.length < 2) return null;
  const max = Math.max(...samples, 1);
  const w = 220;
  const h = 34;
  const points = samples
    .map((v, i) => {
      const x = (i / (samples.length - 1)) * w;
      const y = h - (v / max) * (h - 6) - 3;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-8 w-full overflow-visible">
      <defs>
        <linearGradient id="sparkGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor={startColor} />
          <stop offset="100%" stopColor={endColor} />
        </linearGradient>
      </defs>
      <polyline
        fill="none"
        stroke="url(#sparkGrad)"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
        points={points}
      />
    </svg>
  );
}

export type AuroraTabKey = "home" | "downloads" | "don" | "browser" | "tools" | "library" | "settings";

export function FloatingGlassDock({
  activeTab,
  onSelect,
  activeDownloadsCount,
  lang,
  darkMode,
}: {
  activeTab: AuroraTabKey;
  onSelect: (tab: AuroraTabKey) => void;
  activeDownloadsCount: number;
  lang: LangCode;
  darkMode: boolean;
}) {
  const items: Array<{
    key: AuroraTabKey;
    labelAr: string;
    labelEn: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
  }> = [
    { key: "home", labelAr: "الرئيسية", labelEn: "Home", icon: Sparkles },
    {
      key: "downloads",
      labelAr: "التحميلات",
      labelEn: "Queue",
      icon: Download,
      badge: activeDownloadsCount,
    },
    { key: "browser", labelAr: "المتصفح", labelEn: "Browser", icon: Globe },
    { key: "tools", labelAr: "الأدوات", labelEn: "Tools", icon: Wand2 },
    { key: "library", labelAr: "المكتبة", labelEn: "Library", icon: FolderLock },
    { key: "settings", labelAr: "الإعدادات", labelEn: "Settings", icon: SlidersHorizontal },
  ];

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-3 z-30 flex justify-center px-3">
      <nav
        aria-label="Aurora Floating Glass Dock"
        className={`pointer-events-auto aurora-glass-card flex w-full max-w-[396px] items-center justify-between rounded-[28px] p-1.5 ${
          darkMode ? "bg-black/45" : "bg-white/75"
        }`}
      >
        {items.map((item) => {
          const Icon = item.icon;
          const active = item.key === activeTab;
          return (
            <motion.button
              key={item.key}
              type="button"
              whileTap={{ scale: 0.92 }}
              onClick={() => onSelect(item.key)}
              className={`relative flex items-center justify-center gap-1.5 rounded-[22px] px-2.5 py-2.5 text-xs font-semibold transition-colors ${
                active
                  ? darkMode
                    ? "text-white"
                    : "text-slate-950"
                  : darkMode
                  ? "text-slate-400 hover:text-slate-200"
                  : "text-slate-500 hover:text-slate-900"
              }`}
            >
              {active && (
                <motion.span
                  layoutId="auroraDockActivePill"
                  transition={{ type: "spring", stiffness: 380, damping: 28 }}
                  className="aurora-gradient-bg absolute inset-0 rounded-[22px] opacity-25"
                />
              )}
              <Icon className="relative z-10 h-[18px] w-[18px] shrink-0" />
              {active && (
                <motion.span
                  initial={{ opacity: 0, width: 0 }}
                  animate={{ opacity: 1, width: "auto" }}
                  exit={{ opacity: 0, width: 0 }}
                  className="relative z-10 overflow-hidden whitespace-nowrap text-[11px]"
                >
                  {lang === "ar" ? item.labelAr : item.labelEn}
                </motion.span>
              )}
              {item.badge !== undefined && item.badge > 0 && (
                <span className="aurora-gradient-bg relative z-10 flex h-4 min-w-[16px] items-center justify-center rounded-full px-1 text-[10px] font-bold text-white">
                  {item.badge}
                </span>
              )}
            </motion.button>
          );
        })}
      </nav>
    </div>
  );
}

export function AuroraBottomSheet({
  open,
  onClose,
  title,
  subtitle,
  darkMode,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  darkMode: boolean;
  children: React.ReactNode;
}) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 z-40 flex items-end bg-black/60 backdrop-blur-sm"
        >
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 320, damping: 30 }}
            onClick={(e) => e.stopPropagation()}
            className={`aurora-glass-card flex max-h-[78%] w-full flex-col rounded-t-[32px] p-5 ${
              darkMode ? "bg-[#0F131E]/90 text-slate-50" : "bg-white/92 text-slate-900"
            }`}
          >
            <div className="mx-auto mb-3 h-1 w-11 rounded-full bg-slate-400/40" />
            <div className="mb-3 flex items-start justify-between gap-3">
              <div>
                <h3 className="text-base font-bold">{title}</h3>
                {subtitle && <p className="mt-0.5 text-xs opacity-70">{subtitle}</p>}
              </div>
              <button
                type="button"
                onClick={onClose}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-white/10 transition hover:bg-white/20"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="no-scrollbar flex-1 overflow-y-auto pb-2">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function EmbeddedMediaPlayerModal({
  media,
  onClose,
  lang,
}: {
  media: { title: string; thumb: string; duration?: string } | null;
  onClose: () => void;
  lang: LangCode;
}) {
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [progress, setProgress] = useState(28);
  const [subsOn, setSubsOn] = useState(true);
  const [pipActive, setPipActive] = useState(false);

  useEffect(() => {
    if (!media || !playing) return;
    const timer = setInterval(() => {
      setProgress((p) => (p >= 100 ? 0 : p + 0.8 * speed));
    }, 500);
    return () => clearInterval(timer);
  }, [media, playing, speed]);

  return (
    <AnimatePresence>
      {media && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 z-50 flex flex-col justify-between bg-black/92 p-4 text-white backdrop-blur-xl"
        >
          <div className="flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 hover:bg-white/20"
            >
              <X className="h-4 w-4" />
            </button>
            <div className="min-w-0 flex-1 text-center">
              <p className="truncate text-xs font-bold">{media.title}</p>
              <p className="font-mono-aurora text-[10px] text-sky-400">
                Media3 ExoPlayer • HLS/DASH Hardware Decode
              </p>
            </div>
            <button
              type="button"
              onClick={() => setPipActive((v) => !v)}
              className={`flex items-center gap-1 rounded-full px-2.5 py-1.5 text-[11px] font-semibold ${
                pipActive ? "aurora-gradient-bg text-white" : "bg-white/10 text-slate-200"
              }`}
            >
              <PictureInPicture2 className="h-3.5 w-3.5" />
              PiP
            </button>
          </div>

          <div className="relative my-auto overflow-hidden rounded-[26px] border border-white/15 bg-black">
            <img
              src={media.thumb}
              alt={media.title}
              className={`w-full object-cover transition-transform duration-500 ${
                pipActive ? "h-40 scale-95" : "h-56 scale-100"
              }`}
            />
            {subsOn && (
              <div className="absolute inset-x-4 bottom-3 rounded-xl bg-black/70 px-3 py-1.5 text-center text-[11px] backdrop-blur-md">
                {lang === "ar"
                  ? "الشفق القطبي الساطع فوق بحيرة الجليد — معاينة فورية بدقة HDR"
                  : "Vivid northern lights over glacial lagoon — Live HDR Preview"}
              </div>
            )}
          </div>

          <div className="aurora-glass-card space-y-3 rounded-[24px] p-4">
            <input
              type="range"
              min={0}
              max={100}
              value={progress}
              onChange={(e) => setProgress(Number(e.target.value))}
              className="h-1.5 w-full cursor-pointer accent-[#4285F4]"
            />
            <div className="flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setPlaying((p) => !p)}
                className="aurora-gradient-bg flex h-10 w-10 items-center justify-center rounded-full text-white"
              >
                {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              </button>
              <div className="flex items-center gap-1">
                {[0.5, 1, 1.5, 2].map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setSpeed(r)}
                    className={`font-mono-aurora rounded-full px-2 py-1 text-[10px] font-semibold ${
                      speed === r ? "bg-white/25 text-white" : "bg-white/5 text-slate-300"
                    }`}
                  >
                    {r}x
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={() => setSubsOn((s) => !s)}
                className={`flex items-center gap-1 rounded-full px-2.5 py-1.5 text-[11px] ${
                  subsOn ? "bg-emerald-500/25 text-emerald-300" : "bg-white/10 text-slate-400"
                }`}
              >
                <Subtitles className="h-3.5 w-3.5" />
                CC
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function OnboardingOverlay({
  open,
  lang,
  onAccept,
}: {
  open: boolean;
  lang: LangCode;
  onAccept: () => void;
}) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 z-50 flex items-center justify-center bg-black/75 p-5 backdrop-blur-xl"
        >
          <motion.div
            initial={{ scale: 0.9, y: 24, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ type: "spring", stiffness: 280, damping: 24 }}
            className="aurora-glass-card aurora-gemini-glow w-full rounded-[32px] bg-[#0C101B]/95 p-6 text-white"
          >
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-[22px] aurora-gradient-bg shadow-lg shadow-[#4285F4]/40">
              <Sparkles className="h-8 w-8 text-white" />
            </div>
            <h2 className="aurora-gradient-text text-center text-2xl font-extrabold">
              Aurora Get • 𝒥𝒪 DOW
            </h2>
            <p className="mt-2 text-center text-xs leading-relaxed text-slate-300">
              {lang === "ar"
                ? "محرك تحميل مجزأ حتى 32 اتصالًا مع Work-Stealing، تحليل فوري متوازٍ لآلاف المواقع، متصفح صيد وسائط مع حجب إعلانات، وتصغير ذكي Lossless & SSIM ≥ 95% — بتصميم زجاجي Aurora Glass بالكامل بدون Material."
                : "Up to 32-segment parallel downloads with work-stealing, instant multi-stage extraction for 1800+ sites, Sniffer Browser + AdBlock, and Smart Lossless/SSIM ≥ 95% Compressor in pure Aurora Glass UI."}
            </p>
            <div className="mt-4 flex items-start gap-2.5 rounded-[20px] border border-emerald-400/25 bg-emerald-500/10 p-3 text-[11px] text-emerald-200">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
              <span>
                {lang === "ar"
                  ? "خصوصية 100% Offline-first بدون Firebase أو تتبع. المسؤولية كاملة على المستخدم في احترام حقوق النشر. لا يتجاوز التطبيق DRM أو الحوائط المدفوعة."
                  : "100% Offline-first with zero Firebase or tracking. Users are solely responsible for respecting copyright. DRM and paywalls are never bypassed."}
              </span>
            </div>
            <motion.button
              type="button"
              whileTap={{ scale: 0.96 }}
              onClick={onAccept}
              className="aurora-gradient-bg mt-5 w-full rounded-[22px] py-3.5 text-sm font-bold text-white shadow-lg shadow-[#4285F4]/35"
            >
              {lang === "ar" ? "موافق — ابدأ استخدام Aurora Get" : "Accept & Launch Aurora Get"}
            </motion.button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
