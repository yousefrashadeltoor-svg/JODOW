"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  BatteryCharging,
  Code2,
  Globe,
  Maximize2,
  Minimize2,
  Moon,
  ShieldCheck,
  Signal,
  Smartphone,
  Sparkles,
  Sun,
  Wifi,
} from "lucide-react";
import {
  analyzeUrlDeterministic,
  DEMO_SCENARIOS,
  THEME_PALETTES,
  type AnalysisResult,
  type AuroraAppSettings,
  type AuroraThemePreset,
  type DownloadItem,
  type MediaFormatOption,
} from "@/lib/aurora-types";
import {
  AuroraMeshBackdrop,
  EmbeddedMediaPlayerModal,
  FloatingGlassDock,
  OnboardingOverlay,
  type AuroraTabKey,
} from "./AuroraGlassUi";
import { HomeTab } from "./HomeTab";
import { DownloadsTab } from "./DownloadsTab";
import { BrowserTab } from "./BrowserTab";
import { ToolsTab } from "./ToolsTab";
import { LibraryTab, SettingsTab } from "./LibraryAndSettingsTabs";
import { AndroidSourceModal } from "./AndroidSourceModal";

const DEFAULT_SETTINGS: AuroraAppSettings = {
  themePreset: "AURORA",
  darkMode: true,
  amoledPureBlack: true,
  dynamicCoverColor: true,
  languageCode: "ar",
  defaultSegments: 16,
  dohEnabled: true,
  adBlockEnabled: true,
  clipboardAutoDetect: true,
  copyrightAccepted: true,
};

export function AuroraAppShowcase() {
  const [settings, setSettings] = useState<AuroraAppSettings>(DEFAULT_SETTINGS);
  const [activeTab, setActiveTab] = useState<AuroraTabKey>("home");
  const [phoneFrameMode, setPhoneFrameMode] = useState(true);
  const [sourceModalOpen, setSourceModalOpen] = useState(false);
  const [onboardingOpen, setOnboardingOpen] = useState(false);

  // Home Analyzer state
  const [urlInput, setUrlInput] = useState(DEMO_SCENARIOS[0].sampleUrl);
  const [analyzingStage, setAnalyzingStage] = useState(0);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(() =>
    analyzeUrlDeterministic(DEMO_SCENARIOS[0].sampleUrl)
  );
  const [clipboardUrl, setClipboardUrl] = useState<string | null>(DEMO_SCENARIOS[1].sampleUrl);

  // Browser & Tools handoff state
  const [browserUrl, setBrowserUrl] = useState("https://streamhub.example.org/watch/live-aurora-hls");
  const [toolsSubTab, setToolsSubTab] = useState<"compressor" | "converter">("compressor");
  const [toolsFileLabel, setToolsFileLabel] = useState("Iceland_Aurora_Borealis_1080p60_HDR.mp4");

  // Media Player modal state
  const [previewMedia, setPreviewMedia] = useState<{
    title: string;
    thumb: string;
    duration?: string;
  } | null>(null);

  // Persisted Downloads state
  const [downloads, setDownloads] = useState<DownloadItem[]>([]);
  const [speedMap, setSpeedMap] = useState<
    Record<string, { speedBps: number; history: number[]; workStealing: boolean }>
  >({});

  // Toast banner inside app
  const [toast, setToast] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => {
      setToast((curr) => (curr === msg ? null : curr));
    }, 2800);
  }, []);

  // Load persisted settings & downloads from PostgreSQL on mount
  useEffect(() => {
    fetch("/api/settings")
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data && data.themePreset) {
          setSettings({
            themePreset: (data.themePreset as AuroraThemePreset) || "AURORA",
            darkMode: Boolean(data.darkMode),
            amoledPureBlack: Boolean(data.amoledPureBlack),
            dynamicCoverColor: Boolean(data.dynamicCoverColor),
            languageCode: data.languageCode === "en" ? "en" : "ar",
            defaultSegments: Number(data.defaultSegments) || 16,
            dohEnabled: Boolean(data.dohEnabled),
            adBlockEnabled: Boolean(data.adBlockEnabled),
            clipboardAutoDetect: Boolean(data.clipboardAutoDetect),
            copyrightAccepted: Boolean(data.copyrightAccepted),
          });
        }
      })
      .catch(() => null);

    fetch("/api/downloads")
      .then((r) => (r.ok ? r.json() : null))
      .then((rows) => {
        if (Array.isArray(rows)) {
          setDownloads(rows as DownloadItem[]);
        }
      })
      .catch(() => null);
  }, []);

  // Sync HTML dir/lang attribute cleanly
  useEffect(() => {
    document.documentElement.dir = settings.languageCode === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = settings.languageCode;
  }, [settings.languageCode]);

  // Live segmented download simulator for DOWNLOADING items
  useEffect(() => {
    const interval = setInterval(() => {
      setDownloads((prev) =>
        prev.map((item) => {
          if (item.status !== "DOWNLOADING") return item;
          const baseSpeed = 14_500_000 + Math.floor(Math.random() * 11_000_000);
          const nextDownloaded = Math.min(item.totalBytes, item.downloadedBytes + Math.floor(baseSpeed * 0.45));
          const completed = item.totalBytes > 0 && nextDownloaded >= item.totalBytes;

          setSpeedMap((prevMap) => {
            const existing = prevMap[item.id]?.history ?? [15_200_000, 18_400_000, 21_100_000];
            const nextHist = [...existing, baseSpeed].slice(-18);
            return {
              ...prevMap,
              [item.id]: {
                speedBps: baseSpeed,
                history: nextHist,
                workStealing: nextDownloaded / Math.max(1, item.totalBytes) > 0.72,
              },
            };
          });

          if (completed) {
            fetch(`/api/downloads/${encodeURIComponent(item.id)}`, {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ status: "COMPLETED", downloadedBytes: item.totalBytes }),
            }).catch(() => null);
          }

          return {
            ...item,
            downloadedBytes: nextDownloaded,
            status: completed ? "COMPLETED" : "DOWNLOADING",
          };
        })
      );
    }, 900);
    return () => clearInterval(interval);
  }, []);

  const handleUpdateSettings = useCallback((patch: Partial<AuroraAppSettings>) => {
    setSettings((prev) => {
      const merged = { ...prev, ...patch };
      fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(merged),
      }).catch(() => null);
      return merged;
    });
  }, []);

  const handleAnalyze = useCallback(async (targetUrl: string) => {
    const trimmed = targetUrl.trim();
    if (!trimmed) return;
    setAnalyzingStage(1);
    setTimeout(() => setAnalyzingStage(2), 180);
    setTimeout(() => setAnalyzingStage(3), 380);

    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: trimmed }),
      });
      const result: AnalysisResult = res.ok
        ? await res.json()
        : analyzeUrlDeterministic(trimmed);
      setTimeout(() => {
        setAnalysis(result);
        setAnalyzingStage(0);
      }, 540);
    } catch {
      setTimeout(() => {
        setAnalysis(analyzeUrlDeterministic(trimmed));
        setAnalyzingStage(0);
      }, 540);
    }
  }, []);

  const handleDownloadOption = useCallback(
    async (opt: MediaFormatOption, customBaseName?: string) => {
      const ext = opt.extension.toLowerCase();
      const base = (customBaseName || opt.title).replace(/\.[a-z0-9]{2,5}$/i, "");
      const fileName = `${base}.${ext}`;
      const newTask: DownloadItem = {
        id: `dl-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        url: opt.downloadUrl,
        fileName,
        category: opt.category,
        siteName: analysis?.siteName || "Web",
        domain: analysis?.domain || "web",
        thumbnailUrl: analysis?.thumbnailUrl || null,
        totalBytes: opt.size.bytes > 0 ? opt.size.bytes : 24_800_000,
        sizePrecision: opt.size.precision,
        downloadedBytes: 0,
        maxConnections: settings.defaultSegments,
        status: "DOWNLOADING",
        priority: 20,
        requiresMerge: Boolean(opt.requiresAudioMerge),
        savedByCompressionBytes: 0,
      };

      setDownloads((prev) => [newTask, ...prev]);
      showToast(
        settings.languageCode === "ar"
          ? `بدأ التحميل بـ ${settings.defaultSegments} اتصالًا: ${fileName}`
          : `Started ${settings.defaultSegments}-segment download: ${fileName}`
      );
      setActiveTab("downloads");

      fetch("/api/downloads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newTask),
      }).catch(() => null);
    },
    [analysis, settings.defaultSegments, settings.languageCode, showToast]
  );

  const handleTogglePause = useCallback((item: DownloadItem) => {
    const nextStatus = item.status === "DOWNLOADING" ? "PAUSED" : "DOWNLOADING";
    setDownloads((prev) =>
      prev.map((d) => (d.id === item.id ? { ...d, status: nextStatus } : d))
    );
    fetch(`/api/downloads/${encodeURIComponent(item.id)}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: nextStatus, downloadedBytes: item.downloadedBytes }),
    }).catch(() => null);
  }, []);

  const handleDeleteDownload = useCallback((id: string) => {
    setDownloads((prev) => prev.filter((d) => d.id !== id));
    fetch(`/api/downloads/${encodeURIComponent(id)}`, { method: "DELETE" }).catch(() => null);
  }, []);

  const handleReorder = useCallback((id: string, delta: number) => {
    setDownloads((prev) => {
      const idx = prev.findIndex((d) => d.id === id);
      if (idx === -1) return prev;
      const targetIdx = idx - delta;
      if (targetIdx < 0 || targetIdx >= prev.length) return prev;
      const copy = [...prev];
      const [moved] = copy.splice(idx, 1);
      copy.splice(targetIdx, 0, moved);
      return copy;
    });
  }, []);

  const palette = THEME_PALETTES[settings.themePreset];
  const dynamicAccent =
    settings.dynamicCoverColor && analysis?.dominantAccent ? analysis.dominantAccent : undefined;

  const activeDownloadsCount = useMemo(
    () => downloads.filter((d) => d.status === "DOWNLOADING" || d.status === "MERGING").length,
    [downloads]
  );
  const completedDownloads = useMemo(
    () => downloads.filter((d) => d.status === "COMPLETED"),
    [downloads]
  );
  const totalDownloadedBytes = useMemo(
    () => downloads.reduce((acc, d) => acc + d.downloadedBytes, 0),
    [downloads]
  );
  const totalSavedBytes = useMemo(
    () => downloads.reduce((acc, d) => acc + (d.savedByCompressionBytes || 0), 0),
    [downloads]
  );

  const lang = settings.languageCode;
  const cssVars = {
    "--aurora-start": dynamicAccent || palette.start,
    "--aurora-mid": palette.mid,
    "--aurora-end": palette.end,
    "--aurora-surface": settings.darkMode ? "rgba(255,255,255,0.065)" : "rgba(255,255,255,0.70)",
    "--aurora-surface-strong": settings.darkMode ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.88)",
    "--aurora-border-top": settings.darkMode ? "rgba(255,255,255,0.24)" : "rgba(255,255,255,0.95)",
    "--aurora-border-bottom": settings.darkMode ? "rgba(255,255,255,0.06)" : "rgba(148,163,184,0.35)",
  } as React.CSSProperties;

  return (
    <div
      style={cssVars}
      dir={lang === "ar" ? "rtl" : "ltr"}
      className={`relative min-h-screen w-full transition-colors duration-500 ${
        settings.darkMode ? "bg-[#050609] text-slate-50" : "bg-[#E9EFFB] text-slate-900"
      }`}
    >
      {/* Ambient Studio Outer Glow */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden opacity-55">
        <div
          className="aurora-blob-a absolute -top-32 start-1/4 h-96 w-96 rounded-full blur-[130px]"
          style={{ backgroundColor: dynamicAccent || palette.start, opacity: 0.25 }}
        />
        <div
          className="aurora-blob-b absolute bottom-0 end-1/4 h-96 w-96 rounded-full blur-[140px]"
          style={{ backgroundColor: palette.mid, opacity: 0.22 }}
        />
      </div>

      {/* Top Studio Bar (Clean Controls + Direct JP PROJ Android Code Explorer) */}
      <header className="relative z-20 mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3.5">
        <div className="flex items-center gap-2.5">
          <div className="aurora-gradient-bg flex h-9 w-9 items-center justify-center rounded-[14px] text-white shadow-lg shadow-[#4285F4]/30">
            <Sparkles className="h-4 w-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="aurora-gradient-text text-sm font-extrabold">
                Aurora Get • 𝒥𝒪 DOW
              </span>
              <span className="rounded-full border border-emerald-400/30 bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold text-emerald-400">
                Zero Material
              </span>
            </div>
            <p className="text-[11px] opacity-65">
              {lang === "ar"
                ? "معاينة تفاعلية مطابقة تمامًا للتطبيق الأصلي + مشروع Android كامل في مجلد JP PROJ"
                : "1:1 Interactive Android UI Preview + Complete Android Project in JP PROJ/"}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setSourceModalOpen(true)}
            className="aurora-gradient-bg flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-extrabold text-white shadow-md shadow-[#4285F4]/30 transition active:scale-95"
          >
            <Code2 className="h-3.5 w-3.5" />
            <span>
              {lang === "ar" ? "استعراض كود Android (JP PROJ)" : "Explore Android Source (JP PROJ)"}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setPhoneFrameMode((v) => !v)}
            className="aurora-glass-card hidden items-center gap-1.5 rounded-full px-3 py-2 text-xs font-semibold md:flex"
          >
            {phoneFrameMode ? <Maximize2 className="h-3.5 w-3.5" /> : <Minimize2 className="h-3.5 w-3.5" />}
            <span>
              {phoneFrameMode
                ? lang === "ar"
                  ? "توسيع العرض"
                  : "Expand"
                : lang === "ar"
                ? "إطار الهاتف"
                : "Phone Frame"}
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleUpdateSettings({ darkMode: !settings.darkMode })}
            className="aurora-glass-card flex h-9 w-9 items-center justify-center rounded-full"
            title="Toggle Dark / Light"
          >
            {settings.darkMode ? <Sun className="h-4 w-4 text-amber-300" /> : <Moon className="h-4 w-4 text-indigo-600" />}
          </button>

          <button
            type="button"
            onClick={() =>
              handleUpdateSettings({ languageCode: lang === "ar" ? "en" : "ar" })
            }
            className="aurora-glass-card flex items-center gap-1 rounded-full px-3 py-2 text-xs font-bold"
          >
            <Globe className="h-3.5 w-3.5 text-[#4285F4]" />
            <span>{lang === "ar" ? "EN" : "عربي"}</span>
          </button>
        </div>
      </header>

      {/* Main Stage: Flagship Android 15 Device Viewport */}
      <main className="relative z-10 mx-auto flex max-w-6xl flex-col items-center justify-center px-3 pb-10 pt-1">
        <div
          className={`relative flex flex-col overflow-hidden transition-all duration-500 ${
            phoneFrameMode
              ? "h-[812px] w-full max-w-[420px] rounded-[46px] border-[6px] border-white/15 shadow-[0_32px_90px_-20px_rgba(0,0,0,0.85)]"
              : "h-[82vh] min-h-[720px] w-full max-w-4xl rounded-[34px] border border-white/15 shadow-2xl"
          }`}
        >
          {/* Animated AGSL-Equivalent Mesh Gradient Background inside App */}
          <AuroraMeshBackdrop
            start={palette.start}
            mid={palette.mid}
            end={palette.end}
            darkMode={settings.darkMode}
            amoled={settings.amoledPureBlack}
            dynamicAccent={dynamicAccent}
          />

          {/* Native Android 15 Transparent Status Bar */}
          <div
            dir="ltr"
            className={`relative z-20 flex shrink-0 items-center justify-between px-6 pb-1.5 pt-3 text-[11px] font-semibold ${
              settings.darkMode ? "text-white/90" : "text-slate-900/90"
            }`}
          >
            <span className="font-mono-aurora">09:41</span>
            {phoneFrameMode && (
              <div className="h-4 w-24 rounded-full bg-black/85 ring-1 ring-white/10" />
            )}
            <div className="flex items-center gap-1.5">
              <Signal className="h-3.5 w-3.5" />
              <Wifi className="h-3.5 w-3.5" />
              <BatteryCharging className="h-3.5 w-3.5 text-emerald-400" />
            </div>
          </div>

          {/* In-App Floating Toast */}
          <AnimatePresence>
            {toast && (
              <motion.div
                initial={{ opacity: 0, y: -14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -14 }}
                className="aurora-glass-card absolute inset-x-4 top-12 z-40 flex items-center gap-2 rounded-[20px] bg-black/70 px-3.5 py-2.5 text-xs font-bold text-white"
              >
                <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-400" />
                <span className="truncate">{toast}</span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Active Android Screen Content with Fade-Through + Scale Transition */}
          <div className="no-scrollbar relative z-10 flex-1 overflow-y-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, scale: 0.985, filter: "blur(4px)" }}
                animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                exit={{ opacity: 0, scale: 0.985, filter: "blur(4px)" }}
                transition={{ duration: 0.2 }}
                className="min-h-full"
              >
                {activeTab === "home" && (
                  <HomeTab
                    lang={lang}
                    darkMode={settings.darkMode}
                    urlInput={urlInput}
                    onUrlChange={setUrlInput}
                    onAnalyze={handleAnalyze}
                    analyzingStage={analyzingStage}
                    analysis={analysis}
                    recentDownloads={downloads}
                    clipboardUrl={settings.clipboardAutoDetect ? clipboardUrl : null}
                    onAcceptClipboard={() => {
                      if (!clipboardUrl) return;
                      setUrlInput(clipboardUrl);
                      setClipboardUrl(null);
                      handleAnalyze(clipboardUrl);
                    }}
                    onDismissClipboard={() => setClipboardUrl(null)}
                    onDownloadOption={handleDownloadOption}
                    onOpenBrowser={(u) => {
                      setBrowserUrl(u);
                      setActiveTab("browser");
                    }}
                    onPreviewMedia={(m) => setPreviewMedia(m)}
                    onOpenConverter={(opt) => {
                      setToolsFileLabel(`${opt.title}.${opt.extension.toLowerCase()}`);
                      setToolsSubTab("converter");
                      setActiveTab("tools");
                    }}
                  />
                )}

                {activeTab === "downloads" && (
                  <DownloadsTab
                    lang={lang}
                    darkMode={settings.darkMode}
                    downloads={downloads}
                    speedMap={speedMap}
                    accentStart={dynamicAccent || palette.start}
                    accentEnd={palette.end}
                    onTogglePause={handleTogglePause}
                    onDelete={handleDeleteDownload}
                    onReorder={handleReorder}
                    onSendToCompressor={(item) => {
                      setToolsFileLabel(item.fileName);
                      setToolsSubTab("compressor");
                      setActiveTab("tools");
                    }}
                  />
                )}

                {activeTab === "browser" && (
                  <BrowserTab
                    lang={lang}
                    darkMode={settings.darkMode}
                    initialUrl={browserUrl}
                    onDownloadSniffed={(opt) => handleDownloadOption(opt)}
                  />
                )}

                {activeTab === "tools" && (
                  <ToolsTab
                    lang={lang}
                    darkMode={settings.darkMode}
                    initialSubTab={toolsSubTab}
                    selectedFileLabel={toolsFileLabel}
                  />
                )}

                {activeTab === "library" && (
                  <LibraryTab
                    lang={lang}
                    darkMode={settings.darkMode}
                    completedDownloads={completedDownloads}
                    onPlayMedia={(m) => setPreviewMedia(m)}
                  />
                )}

                {activeTab === "settings" && (
                  <SettingsTab
                    settings={settings}
                    totalDownloadedBytes={totalDownloadedBytes}
                    totalSavedBytes={totalSavedBytes}
                    onUpdateSettings={handleUpdateSettings}
                    onReplayOnboarding={() => setOnboardingOpen(true)}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Pure Custom Floating Glass Dock (Zero Material NavigationBar) */}
          <FloatingGlassDock
            activeTab={activeTab}
            onSelect={setActiveTab}
            activeDownloadsCount={activeDownloadsCount}
            lang={lang}
            darkMode={settings.darkMode}
          />

          {/* Embedded Media3 Preview Player Overlay */}
          <EmbeddedMediaPlayerModal
            media={previewMedia}
            onClose={() => setPreviewMedia(null)}
            lang={lang}
          />

          {/* Animated Onboarding & Copyright Commitment Overlay */}
          <OnboardingOverlay
            open={onboardingOpen}
            lang={lang}
            onAccept={() => {
              setOnboardingOpen(false);
              handleUpdateSettings({ copyrightAccepted: true });
            }}
          />
        </div>

        {/* Minimal Footer Spec Strip */}
        <div className="mt-5 flex flex-wrap items-center justify-center gap-3 text-[11px] opacity-70">
          <span className="flex items-center gap-1">
            <Smartphone className="h-3.5 w-3.5 text-[#4285F4]" />
            Kotlin 2.1 • Compose Foundation/UI • Haze • AGSL
          </span>
          <span>•</span>
          <span>17 Modules inside JP PROJ/</span>
          <span>•</span>
          <span>yt-dlp + aria2c + FFmpeg + Cronet QUIC + adblock-rust</span>
        </div>
      </main>

      {/* Complete Android Source Explorer Modal reading live files from JP PROJ/ */}
      <AndroidSourceModal
        open={sourceModalOpen}
        onClose={() => setSourceModalOpen(false)}
        lang={lang}
      />
    </div>
  );
}
