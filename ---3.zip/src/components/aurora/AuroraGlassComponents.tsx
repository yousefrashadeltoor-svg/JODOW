"use client";

import React, { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";

export function StreamingText({ text, className = "" }: { text: string; className?: string }) {
  const [visible, setVisible] = useState(0);
  useEffect(() => {
    setVisible(0);
    if (!text) return;
    const step = Math.max(1, Math.ceil(text.length / 22));
    const id = setInterval(() => {
      setVisible((v) => {
        if (v + step >= text.length) {
          clearInterval(id);
          return text.length;
        }
        return v + step;
      });
    }, 16);
    return () => clearInterval(id);
  }, [text]);
  const done = visible >= text.length;
  return (
    <span className={`transition-[filter] duration-300 ${done ? "blur-0" : "blur-[1.5px]"} ${className}`}>
      {text.slice(0, visible)}
    </span>
  );
}

export function AuroraGlassSurface({
  children,
  className = "",
  padding = "16px",
  shape = "rounded-[28px]",
  glowActive = false,
  style,
}: {
  children: React.ReactNode;
  className?: string;
  padding?: string;
  shape?: string;
  glowActive?: boolean;
  style?: React.CSSProperties;
}) {
  return (
    <div
      className={`relative ${shape} aurora-glass-card ${glowActive ? "aurora-gemini-glow" : ""} ${className}`}
      style={{ padding, ...style, animationDuration: "var(--aurora-spin-speed)" }}
    >
      {children}
    </div>
  );
}

export function AuroraGlassButton({
  children,
  onClick,
  primaryGradient = false,
  className = "",
  padding,
  icon,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  primaryGradient?: boolean;
  className?: string;
  padding?: string;
  icon?: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`relative inline-flex items-center justify-center gap-1.5 rounded-[20px] px-3 py-2 text-[11px] font-bold transition active:scale-95 ${
        primaryGradient
          ? "aurora-gradient-bg text-white shadow-md shadow-sky-500/30"
          : "bg-white/10 hover:bg-white/15"
      } ${className}`}
      style={padding ? { padding } : undefined}
    >
      {icon}
      {children}
    </button>
  );
}

export function AuroraShimmerBox({
  height = 60,
  className = "",
}: {
  height?: number;
  className?: string;
}) {
  return (
    <div
      className={`aurora-shimmer rounded-[18px] bg-white/10 ${className}`}
      style={{ height }}
    />
  );
}

export function AuroraProgressGlowBar({ progress }: { progress: number }) {
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
      <motion.div
        initial={false}
        animate={{ width: `${Math.round(progress * 100)}%` }}
        transition={{ type: "spring", stiffness: 300, damping: 24 }}
        className="aurora-gradient-bg h-full rounded-full"
      />
    </div>
  );
}

export function AuroraSpeedSparkline({
  samples,
  startColor,
  endColor,
  height = 32,
}: {
  samples: number[];
  startColor: string;
  endColor: string;
  height?: number;
}) {
  if (samples.length < 2) return null;
  const w = 220;
  const h = height;
  const max = Math.max(...samples, 1);
  const points = samples
    .map((v, i) => {
      const x = (i / (samples.length - 1)) * w;
      const y = h - (v / max) * (h - 6) - 3;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className={`w-full`} style={{ height }}>
      <defs>
        <linearGradient id={`spark-${startColor.replace("#", "")}-${endColor.replace("#", "")}`} x1="0" x2="1">
          <stop offset="0%" stopColor={startColor} />
          <stop offset="100%" stopColor={endColor} />
        </linearGradient>
      </defs>
      <polyline
        fill="none"
        stroke={`url(#spark-${startColor.replace("#", "")}-${endColor.replace("#", "")})`}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        points={points}
      />
    </svg>
  );
}

export function AuroraBottomSheet({
  open,
  onClose,
  title,
  subtitle,
  darkMode,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  darkMode: boolean;
  children: React.ReactNode;
}) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 z-40 flex items-end bg-black/60 backdrop-blur-sm"
        >
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 320, damping: 30 }}
            onClick={(e) => e.stopPropagation()}
            className={`aurora-glass-card flex max-h-[78%] w-full flex-col rounded-t-[32px] p-4 ${
              darkMode ? "bg-[#0F131E]/90 text-white" : "bg-white/92 text-slate-900"
            }`}
          >
            <div className="mx-auto mb-3 h-1 w-11 rounded-full bg-slate-400/40" />
            <div className="mb-3 flex items-start justify-between gap-3">
              <div>
                <h3 className="text-sm font-extrabold">{title}</h3>
                {subtitle && <p className="mt-0.5 text-[10px] opacity-70">{subtitle}</p>}
              </div>
              <button
                type="button"
                onClick={onClose}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-white/10"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="no-scrollbar flex-1 overflow-y-auto pb-2">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
