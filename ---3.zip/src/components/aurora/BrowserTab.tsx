"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Cookie,
  Download,
  EyeOff,
  Monitor,
  Radar,
  RefreshCw,
  Shield,
  ShieldCheck,
  Smartphone,
} from "lucide-react";
import {
  formatFileSize,
  type LangCode,
  type MediaFormatOption,
} from "@/lib/aurora-types";
import { AuroraBottomSheet } from "./AuroraGlassUi";

const SNIFFED_RESOURCES: MediaFormatOption[] = [
  {
    id: "sniff-hls-1",
    category: "VIDEO",
    title: "master_1080p60_aurora_stream.m3u8",
    qualityLabel: "HLS 1080p • 32 Seg",
    extension: "MP4",
    codec: "HLS -> FFmpeg -c copy",
    fps: 60,
    size: { bytes: 218_420_110, precision: "EXACT", source: "Parallel HLS HEAD Sum" },
    downloadUrl: "https://edge-cf.streamhub.example/hls/master.m3u8",
  },
  {
    id: "sniff-audio-2",
    category: "AUDIO",
    title: "stream_audio_aac_256k.m4a",
    qualityLabel: "256 kbps AAC",
    extension: "M4A",
    codec: "AAC-LC",
    bitrateKbps: 256,
    size: { bytes: 14_820_480, precision: "EXACT", source: "Content-Range 0-0" },
    downloadUrl: "https://edge-cf.streamhub.example/audio/track.m4a",
  },
  {
    id: "sniff-poster-3",
    category: "IMAGE",
    title: "stream_poster_uhd.webp",
    qualityLabel: "4K Poster",
    extension: "WEBP",
    codec: "WebP",
    size: { bytes: 924_112, precision: "EXACT", source: "HEAD Content-Length" },
    downloadUrl: "/images/aurora-thumb-yt.png",
  },
];

export function BrowserTab({
  lang,
  darkMode,
  initialUrl,
  onDownloadSniffed,
}: {
  lang: LangCode;
  darkMode: boolean;
  initialUrl: string;
  onDownloadSniffed: (opt: MediaFormatOption) => void;
}) {
  const [address, setAddress] = useState(initialUrl || "https://streamhub.example.org/watch/live-aurora-hls");
  const [desktopMode, setDesktopMode] = useState(false);
  const [privateMode, setPrivateMode] = useState(true);
  const [adBlockOn, setAdBlockOn] = useState(true);
  const [blockedCount, setBlockedCount] = useState(27);
  const [cfSolved, setCfSolved] = useState(true);
  const [snifferOpen, setSnifferOpen] = useState(false);

  return (
    <div className="relative flex h-full flex-col gap-3 px-4 pb-28 pt-4">
      {/* Glass Browser Address Bar */}
      <div className="aurora-glass-card space-y-2.5 rounded-[24px] p-3">
        <div className="flex items-center gap-2">
          <input
            dir="ltr"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className={`font-mono-aurora flex-1 rounded-[14px] px-3 py-2 text-[11px] outline-none ${
              darkMode ? "bg-black/35 text-slate-100" : "bg-white/80 text-slate-900"
            }`}
          />
          <button
            type="button"
            onClick={() => setBlockedCount((c) => c + 4)}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-white/10"
          >
            <RefreshCw className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-1.5 text-[10px]">
          <div className="flex items-center gap-1">
            <button type="button" className="rounded-full bg-white/8 p-1.5">
              <ArrowRight className="h-3 w-3" />
            </button>
            <button type="button" className="rounded-full bg-white/8 p-1.5">
              <ArrowLeft className="h-3 w-3" />
            </button>
            <button
              type="button"
              onClick={() => setDesktopMode((v) => !v)}
              className={`flex items-center gap-1 rounded-full px-2 py-1 font-semibold ${
                desktopMode ? "bg-sky-500/25 text-sky-300" : "bg-white/8 opacity-75"
              }`}
            >
              {desktopMode ? <Monitor className="h-3 w-3" /> : <Smartphone className="h-3 w-3" />}
              <span>{desktopMode ? "Desktop" : "Mobile"}</span>
            </button>
            <button
              type="button"
              onClick={() => setPrivateMode((v) => !v)}
              className={`flex items-center gap-1 rounded-full px-2 py-1 font-semibold ${
                privateMode ? "bg-violet-500/25 text-violet-300" : "bg-white/8 opacity-75"
              }`}
            >
              <EyeOff className="h-3 w-3" />
              <span>{lang === "ar" ? "خاص" : "Private"}</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => setAdBlockOn((v) => !v)}
            className={`flex items-center gap-1 rounded-full px-2.5 py-1 font-bold ${
              adBlockOn ? "bg-emerald-500/20 text-emerald-300" : "bg-rose-500/20 text-rose-300"
            }`}
          >
            <Shield className="h-3 w-3" />
            <span>
              {adBlockOn
                ? lang === "ar"
                  ? `حجب ${blockedCount}`
                  : `Blocked ${blockedCount}`
                : "AdBlock OFF"}
            </span>
          </button>
        </div>
      </div>

      {/* Cloudflare Legitimate Session Sync Banner */}
      <div className="aurora-glass-card flex items-center justify-between gap-2 rounded-[20px] px-3.5 py-2.5 text-[11px]">
        <div className="flex items-center gap-2">
          <Cookie className="h-4 w-4 text-amber-400" />
          <div>
            <p className="font-bold">
              {cfSolved
                ? lang === "ar"
                  ? "Cloudflare cf_clearance متزامن مع CookieJar"
                  : "Cloudflare cf_clearance synced to CookieJar"
                : lang === "ar"
                ? "بانتظار حل تحدي WebView..."
                : "Solving WebView challenge..."}
            </p>
            <p className="font-mono-aurora text-[9.5px] opacity-65">
              UA + Referer + Encrypted AES-256 Cookie Handoff
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setCfSolved((v) => !v)}
          className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] font-bold text-emerald-300"
        >
          {cfSolved ? "OK" : "Retry"}
        </button>
      </div>

      {/* Simulated Real WebView Canvas showing Cosmetic AdBlock + Active Sniffer */}
      <div className="aurora-glass-card relative flex-1 space-y-3 overflow-hidden rounded-[26px] p-4">
        <div className="relative overflow-hidden rounded-[20px]">
          <img
            src="/images/aurora-thumb-yt.png"
            alt="WebView Sniffed Stream"
            className="h-40 w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
          <div className="absolute bottom-2.5 inset-x-3 flex items-center justify-between text-white">
            <span className="flex items-center gap-1 rounded-full bg-emerald-500/30 px-2.5 py-0.5 font-mono-aurora text-[10px] font-bold backdrop-blur-md">
              <Radar className="h-3 w-3 animate-pulse" />
              HLS .m3u8 Intercepted
            </span>
            <span className="font-mono-aurora text-[10px] opacity-80">fetch / XHR Hook</span>
          </div>
        </div>

        {/* Cosmetic AdBlock Evidence */}
        <div className="space-y-2">
          <div className="flex items-center gap-2 rounded-[16px] border border-dashed border-emerald-400/30 bg-emerald-500/10 px-3 py-2 text-[11px] text-emerald-300">
            <ShieldCheck className="h-4 w-4 shrink-0" />
            <span>
              {adBlockOn
                ? lang === "ar"
                  ? "adblock-rust + EasyList: تم إخفاء زر تحميل وهمي (Fake Download Overlay) و4 نوافذ منبثقة."
                  : "adblock-rust + EasyList: Stripped fake Download overlay & 4 popunders."
                : lang === "ar"
                ? "تم تعطيل حجب الإعلانات لهذا الموقع مؤقتًا."
                : "AdBlock temporarily disabled for this site."}
            </span>
          </div>
          <p className="text-[11px] leading-relaxed opacity-70">
            {lang === "ar"
              ? "يتم تمرير Cookies وUser-Agent وReferer تلقائيًا مع كل ملف يُصطاد ليقوم محرك Aurora المجزأ بالتحميل بدل مدير WebView."
              : "Every sniffed resource automatically carries WebView Cookies, User-Agent, and Referer directly into Aurora's segmented engine."}
          </p>
        </div>

        {/* Floating Glass Sniffer FAB */}
        <motion.button
          type="button"
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.94 }}
          onClick={() => setSnifferOpen(true)}
          className="aurora-gradient-bg aurora-gemini-glow absolute bottom-4 end-4 flex items-center gap-2 rounded-full px-4 py-3 text-xs font-extrabold text-white shadow-xl"
        >
          <Download className="h-4 w-4" />
          <span>{lang === "ar" ? "ملفات مصطادة" : "Sniffed"}</span>
          <span className="font-mono-aurora flex h-5 min-w-[20px] items-center justify-center rounded-full bg-white/25 px-1 text-[11px]">
            {SNIFFED_RESOURCES.length}
          </span>
        </motion.button>
      </div>

      {/* Sniffer Resources Glass Bottom Sheet */}
      <AuroraBottomSheet
        open={snifferOpen}
        onClose={() => setSnifferOpen(false)}
        darkMode={darkMode}
        title={
          lang === "ar"
            ? `الملفات المصطادة (${SNIFFED_RESOURCES.length})`
            : `Sniffed Resources (${SNIFFED_RESOURCES.length})`
        }
        subtitle={
          lang === "ar"
            ? "يُحمَّل عبر محرك Aurora مع نقل الكوكيز والهيدرز بالكامل"
            : "Downloaded via Aurora Engine with full Cookies + Headers"
        }
      >
        <div className="space-y-2.5">
          {SNIFFED_RESOURCES.map((res) => (
            <div
              key={res.id}
              className="aurora-glass-card flex items-center justify-between gap-2 rounded-[20px] p-3"
            >
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-bold">{res.title}</p>
                <p className="font-mono-aurora mt-0.5 text-[10px] opacity-70">
                  {res.qualityLabel} • {formatFileSize(res.size)}
                </p>
                <p className="mt-0.5 flex items-center gap-1 text-[9.5px] text-emerald-400">
                  <CheckCircle2 className="h-3 w-3" />
                  Cookie + Referer + UA attached
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  onDownloadSniffed(res);
                  setSnifferOpen(false);
                }}
                className="aurora-gradient-bg shrink-0 rounded-[14px] px-3.5 py-2 text-xs font-bold text-white"
              >
                {lang === "ar" ? "تحميل" : "Get"}
              </button>
            </div>
          ))}
        </div>
      </AuroraBottomSheet>
    </div>
  );
}
