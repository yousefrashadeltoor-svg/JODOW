"use client";

import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowDown,
  ArrowUp,
  CheckCircle2,
  Clock,
  Minimize2,
  Pause,
  Play,
  Sparkles,
  Trash2,
  Wifi,
  Zap,
} from "lucide-react";
import {
  formatHumanBinary,
  type DownloadItem,
  type LangCode,
} from "@/lib/aurora-types";
import { SparklineSvg } from "./AuroraGlassUi";

type FilterTab = "ALL" | "DOWNLOADING" | "QUEUED" | "COMPLETED" | "FAILED";

export function DownloadsTab({
  lang,
  darkMode,
  downloads,
  speedMap,
  accentStart,
  accentEnd,
  onTogglePause,
  onDelete,
  onReorder,
  onSendToCompressor,
}: {
  lang: LangCode;
  darkMode: boolean;
  downloads: DownloadItem[];
  speedMap: Record<string, { speedBps: number; history: number[]; workStealing: boolean }>;
  accentStart: string;
  accentEnd: string;
  onTogglePause: (item: DownloadItem) => void;
  onDelete: (id: string) => void;
  onReorder: (id: string, delta: number) => void;
  onSendToCompressor: (item: DownloadItem) => void;
}) {
  const [tab, setTab] = useState<FilterTab>("ALL");
  const [wifiOnly, setWifiOnly] = useState(false);

  const filtered = useMemo(() => {
    return downloads.filter((d) => {
      if (tab === "ALL") return true;
      if (tab === "DOWNLOADING") return d.status === "DOWNLOADING" || d.status === "MERGING";
      if (tab === "QUEUED") return d.status === "QUEUED" || d.status === "PAUSED";
      return d.status === tab;
    });
  }, [downloads, tab]);

  const tabDefs: Array<{ key: FilterTab; ar: string; en: string }> = [
    { key: "ALL", ar: "الكل", en: "All" },
    { key: "DOWNLOADING", ar: "جارٍ", en: "Active" },
    { key: "QUEUED", ar: "الانتظار", en: "Queued" },
    { key: "COMPLETED", ar: "مكتمل", en: "Done" },
    { key: "FAILED", ar: "فاشل", en: "Failed" },
  ];

  return (
    <div className="space-y-4 px-4 pb-28 pt-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="aurora-gradient-text text-xl font-extrabold">
            {lang === "ar" ? "مدير التحميلات الفائق" : "Lightning Downloads"}
          </h1>
          <p className="text-[11px] opacity-65">
            {lang === "ar"
              ? "تجزئة ديناميكية 8–32 اتصالًا • Work-Stealing • HTTP/3 QUIC"
              : "8–32 Dynamic Segments • Work-Stealing • HTTP/3 QUIC"}
          </p>
        </div>
        <button
          type="button"
          onClick={() => setWifiOnly((w) => !w)}
          className={`flex items-center gap-1 rounded-full px-3 py-1.5 text-[10px] font-bold transition ${
            wifiOnly
              ? "bg-emerald-500/25 text-emerald-300"
              : darkMode
              ? "bg-white/10 text-slate-300"
              : "bg-slate-200/80 text-slate-700"
          }`}
        >
          <Wifi className="h-3.5 w-3.5" />
          <span>{lang === "ar" ? "Wi-Fi فقط" : "Wi-Fi Only"}</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="no-scrollbar flex gap-1.5 overflow-x-auto">
        {tabDefs.map((t) => {
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              type="button"
              onClick={() => setTab(t.key)}
              className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-bold transition ${
                active
                  ? "aurora-gradient-bg text-white shadow-sm"
                  : darkMode
                  ? "bg-white/8 text-slate-300 hover:bg-white/12"
                  : "bg-white/70 text-slate-600"
              }`}
            >
              {lang === "ar" ? t.ar : t.en}
            </button>
          );
        })}
      </div>

      {/* Download Cards */}
      <div className="space-y-3">
        {filtered.length === 0 && (
          <div className="aurora-glass-card rounded-[26px] p-8 text-center">
            <Sparkles className="mx-auto mb-2 h-8 w-8 text-[#9B72CB] opacity-75" />
            <p className="text-xs font-semibold opacity-75">
              {lang === "ar"
                ? "لا توجد عناصر في هذا التبويب حاليًا"
                : "No downloads in this tab yet"}
            </p>
          </div>
        )}

        {filtered.map((item) => {
          const progress =
            item.totalBytes > 0
              ? Math.min(100, Math.round((item.downloadedBytes / item.totalBytes) * 100))
              : 0;
          const live = speedMap[item.id];
          const speedBps = item.status === "DOWNLOADING" ? live?.speedBps ?? 18_400_000 : 0;
          const etaSec =
            speedBps > 0 && item.totalBytes > item.downloadedBytes
              ? Math.ceil((item.totalBytes - item.downloadedBytes) / speedBps)
              : null;

          return (
            <motion.div
              key={item.id}
              layout
              transition={{ type: "spring", stiffness: 300, damping: 28 }}
              className={`aurora-glass-card space-y-2.5 rounded-[26px] p-4 ${
                item.status === "DOWNLOADING" ? "aurora-gemini-glow" : ""
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-extrabold">{item.fileName}</p>
                  <p className="mt-0.5 flex flex-wrap items-center gap-1.5 font-mono-aurora text-[10px] opacity-70">
                    <span>{item.siteName}</span>
                    <span>•</span>
                    <span className="text-sky-400">
                      {item.maxConnections} {lang === "ar" ? "اتصالات" : "conns"}
                    </span>
                    {item.requiresMerge && (
                      <>
                        <span>•</span>
                        <span className="text-violet-300">FFmpeg -c copy</span>
                      </>
                    )}
                  </p>
                </div>

                {item.status === "DOWNLOADING" ? (
                  <div className="text-end">
                    <p className="font-mono-aurora text-xs font-bold text-[#60A5FA]">
                      {formatHumanBinary(speedBps)}/s
                    </p>
                    {etaSec !== null && (
                      <p className="flex items-center justify-end gap-1 font-mono-aurora text-[10px] opacity-65">
                        <Clock className="h-2.5 w-2.5" />
                        {etaSec}s
                      </p>
                    )}
                  </div>
                ) : item.status === "COMPLETED" ? (
                  <span className="flex items-center gap-1 rounded-full bg-emerald-500/20 px-2.5 py-1 text-[10px] font-bold text-emerald-300">
                    <CheckCircle2 className="h-3 w-3" />
                    {lang === "ar" ? "مكتمل" : "Done"}
                  </span>
                ) : (
                  <span className="rounded-full bg-amber-500/20 px-2.5 py-1 text-[10px] font-bold text-amber-300">
                    {lang === "ar" ? "متوقف مؤقتًا" : "Paused"}
                  </span>
                )}
              </div>

              {/* Animated Glow Progress Bar */}
              <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
                <motion.div
                  className="aurora-gradient-bg h-full rounded-full"
                  initial={false}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.45 }}
                />
              </div>

              {/* Individual Parallel Segments Matrix (Visualizing Segmented Engine + Work-Stealing) */}
              {item.status === "DOWNLOADING" && (
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[9px] opacity-75">
                    <span className="flex items-center gap-1 font-mono-aurora text-emerald-300">
                      <Zap className="h-3 w-3" />
                      {live?.workStealing
                        ? lang === "ar"
                          ? "Work-Stealing نشط (موازنة الأجزاء)"
                          : "Work-Stealing Active"
                        : lang === "ar"
                        ? "كتابة مباشرة FileChannel • ETag محفوظ"
                        : "FileChannel Direct Write • ETag Verified"}
                    </span>
                    <span className="font-mono-aurora">{progress}%</span>
                  </div>
                  <div className="grid grid-cols-16 gap-0.5">
                    {Array.from({ length: 16 }).map((_, idx) => {
                      const filled = idx / 16 < progress / 100;
                      return (
                        <div
                          key={idx}
                          className={`h-1.5 rounded-full transition-colors ${
                            filled ? "aurora-gradient-bg" : "bg-white/12"
                          }`}
                        />
                      );
                    })}
                  </div>
                  {live && live.history.length >= 2 && (
                    <SparklineSvg
                      samples={live.history}
                      startColor={accentStart}
                      endColor={accentEnd}
                    />
                  )}
                </div>
              )}

              {/* Downloaded / Total Exact Bytes */}
              <div className="flex items-center justify-between font-mono-aurora text-[10px] opacity-75">
                <span>
                  {formatHumanBinary(item.downloadedBytes)} /{" "}
                  {item.sizePrecision === "APPROXIMATE" ? "≈ " : ""}
                  {formatHumanBinary(item.totalBytes)}
                </span>
                <span>{progress}%</span>
              </div>

              {/* Action Controls */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5">
                <div className="flex items-center gap-1.5">
                  {item.status !== "COMPLETED" ? (
                    <motion.button
                      type="button"
                      whileTap={{ scale: 0.94 }}
                      onClick={() => onTogglePause(item)}
                      className={`flex items-center gap-1 rounded-[14px] px-3 py-1.5 text-[11px] font-bold ${
                        item.status === "DOWNLOADING"
                          ? "bg-white/12 text-white"
                          : "aurora-gradient-bg text-white"
                      }`}
                    >
                      {item.status === "DOWNLOADING" ? (
                        <>
                          <Pause className="h-3.5 w-3.5" />
                          <span>{lang === "ar" ? "إيقاف" : "Pause"}</span>
                        </>
                      ) : (
                        <>
                          <Play className="h-3.5 w-3.5" />
                          <span>{lang === "ar" ? "استكمال" : "Resume"}</span>
                        </>
                      )}
                    </motion.button>
                  ) : (
                    <motion.button
                      type="button"
                      whileTap={{ scale: 0.95 }}
                      onClick={() => onSendToCompressor(item)}
                      className="flex items-center gap-1 rounded-[14px] bg-emerald-500/20 px-3 py-1.5 text-[11px] font-bold text-emerald-300"
                    >
                      <Minimize2 className="h-3.5 w-3.5" />
                      <span>
                        {lang === "ar"
                          ? `وفّر ~${Math.max(4, Math.round(item.totalBytes / 1_048_576 * 0.38))} MB بالتصغير`
                          : `Save ~${Math.max(4, Math.round(item.totalBytes / 1_048_576 * 0.38))} MB`}
                      </span>
                    </motion.button>
                  )}
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => onReorder(item.id, 1)}
                    title={lang === "ar" ? "رفع الأولوية" : "Priority Up"}
                    className="flex h-7 w-7 items-center justify-center rounded-full bg-white/8 hover:bg-white/15"
                  >
                    <ArrowUp className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onReorder(item.id, -1)}
                    title={lang === "ar" ? "خفض الأولوية" : "Priority Down"}
                    className="flex h-7 w-7 items-center justify-center rounded-full bg-white/8 hover:bg-white/15"
                  >
                    <ArrowDown className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onDelete(item.id)}
                    title={lang === "ar" ? "حذف" : "Delete"}
                    className="flex h-7 w-7 items-center justify-center rounded-full bg-rose-500/15 text-rose-300 hover:bg-rose-500/25"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
