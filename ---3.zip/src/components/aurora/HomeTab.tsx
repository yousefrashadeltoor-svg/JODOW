"use client";

import React, { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  AlertTriangle,
  CheckCircle2,
  ClipboardPaste,
  Download,
  FileText,
  Film,
  Globe,
  Image as ImageIcon,
  Info,
  Layers,
  Music2,
  Play,
  QrCode,
  RefreshCw,
  ShieldAlert,
  Sparkles,
  Wand2,
  X,
} from "lucide-react";
import {
  DEMO_SCENARIOS,
  formatDuration,
  formatExactBytesLongPress,
  formatFileSize,
  type AnalysisResult,
  type DownloadItem,
  type LangCode,
  type MediaCategory,
  type MediaFormatOption,
} from "@/lib/aurora-types";
import { AuroraBottomSheet, StreamingText } from "./AuroraGlassUi";

export function HomeTab({
  lang,
  darkMode,
  urlInput,
  onUrlChange,
  onAnalyze,
  analyzingStage,
  analysis,
  recentDownloads,
  clipboardUrl,
  onAcceptClipboard,
  onDismissClipboard,
  onDownloadOption,
  onOpenBrowser,
  onPreviewMedia,
  onOpenConverter,
}: {
  lang: LangCode;
  darkMode: boolean;
  urlInput: string;
  onUrlChange: (val: string) => void;
  onAnalyze: (url: string) => void;
  analyzingStage: number; // 0 = idle, 1..3 = active stages
  analysis: AnalysisResult | null;
  recentDownloads: DownloadItem[];
  clipboardUrl: string | null;
  onAcceptClipboard: () => void;
  onDismissClipboard: () => void;
  onDownloadOption: (opt: MediaFormatOption, customName: string) => void;
  onOpenBrowser: (url: string) => void;
  onPreviewMedia: (media: { title: string; thumb: string; duration?: string }) => void;
  onOpenConverter: (opt: MediaFormatOption) => void;
}) {
  const [editableName, setEditableName] = useState<string>("");
  const [sheetCategory, setSheetCategory] = useState<MediaCategory | null>(null);
  const [exactInspectOpt, setExactInspectOpt] = useState<MediaFormatOption | null>(null);
  const [batchOpen, setBatchOpen] = useState(false);
  const [batchText, setBatchText] = useState("");
  const [qrNotice, setQrNotice] = useState(false);

  const displayFileName = editableName || analysis?.suggestedFileName || "";

  // Strictly compute ONLY categories that contain actual formats (> 0 items)
  const availableCategories = useMemo(() => {
    if (!analysis) return [];
    const order: MediaCategory[] = ["AUDIO", "IMAGE", "VIDEO", "FILE"];
    return order
      .map((cat) => ({
        cat,
        items: analysis.formats.filter((f) => f.category === cat),
      }))
      .filter((entry) => entry.items.length > 0);
  }, [analysis]);

  const activeSheetItems = useMemo(() => {
    if (!analysis || !sheetCategory) return [];
    return analysis.formats.filter((f) => f.category === sheetCategory);
  }, [analysis, sheetCategory]);

  const categoryMeta: Record<
    MediaCategory,
    { labelAr: string; labelEn: string; icon: React.ComponentType<{ className?: string }>; tint: string }
  > = {
    AUDIO: { labelAr: "صوت", labelEn: "Audio", icon: Music2, tint: "from-violet-500/35 to-fuchsia-500/20" },
    IMAGE: { labelAr: "صور", labelEn: "Images", icon: ImageIcon, tint: "from-emerald-500/35 to-teal-500/20" },
    VIDEO: { labelAr: "فيديو", labelEn: "Video", icon: Film, tint: "from-sky-500/35 to-indigo-500/20" },
    FILE: { labelAr: "ملفات", labelEn: "Files", icon: FileText, tint: "from-amber-500/35 to-rose-500/20" },
  };

  const handlePasteClipboard = async () => {
    try {
      const txt = await navigator.clipboard.readText();
      if (txt) {
        setEditableName("");
        onUrlChange(txt);
        onAnalyze(txt);
        return;
      }
    } catch {
      // Fallback to demo link in sandbox iframe where clipboard API is restricted
    }
    const fallback = DEMO_SCENARIOS[1].sampleUrl;
    setEditableName("");
    onUrlChange(fallback);
    onAnalyze(fallback);
  };

  const handleTriggerAnalyze = (target: string) => {
    setEditableName("");
    onUrlChange(target);
    onAnalyze(target);
  };

  return (
    <div className="space-y-4 px-4 pb-28 pt-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="aurora-gradient-text text-2xl font-extrabold tracking-tight">
            Aurora Get
          </h1>
          <p className={`text-[11px] ${darkMode ? "text-slate-400" : "text-slate-600"}`}>
            {lang === "ar"
              ? "𝒥𝒪 DOW • محرك تحليل وتحميل فائق السرعة"
              : "𝒥𝒪 DOW • Lightning Glass Media Engine"}
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setBatchOpen(true)}
            title={lang === "ar" ? "لصق روابط متعددة" : "Batch Paste"}
            className="aurora-glass-card flex h-9 items-center gap-1.5 rounded-full px-3 text-[11px] font-semibold transition active:scale-95"
          >
            <Layers className="h-3.5 w-3.5 text-[#4285F4]" />
            <span>{lang === "ar" ? "دفعة" : "Batch"}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setQrNotice(true);
              setTimeout(() => setQrNotice(false), 2600);
            }}
            title={lang === "ar" ? "مسح QR محلي" : "On-device QR"}
            className="aurora-glass-card flex h-9 w-9 items-center justify-center rounded-full transition active:scale-95"
          >
            <QrCode className="h-4 w-4 text-[#9B72CB]" />
          </button>
        </div>
      </div>

      {/* On-Device QR Toast */}
      <AnimatePresence>
        {qrNotice && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="aurora-glass-card flex items-center justify-between rounded-[20px] px-3.5 py-2.5 text-xs"
          >
            <span>
              {lang === "ar"
                ? "ماسح QR المحلي (ML Kit On-Device) جاهز في نسخة Android دون اتصال."
                : "On-device ML Kit QR scanner is active in the Android build (offline)."}
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Non-intrusive Floating Clipboard Detection Chip */}
      <AnimatePresence>
        {clipboardUrl && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.96 }}
            transition={{ type: "spring", stiffness: 320, damping: 26 }}
            className="aurora-glass-card aurora-gemini-glow flex items-center justify-between gap-2 rounded-[22px] px-3.5 py-2.5"
          >
            <button
              type="button"
              onClick={() => {
                setEditableName("");
                onAcceptClipboard();
              }}
              className="flex min-w-0 flex-1 items-center gap-2 text-start"
            >
              <span className="aurora-gradient-bg flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-white">
                <ClipboardPaste className="h-3.5 w-3.5" />
              </span>
              <div className="min-w-0">
                <p className="text-[11px] font-bold text-[#60A5FA]">
                  {lang === "ar" ? "رابط مكتشف في الحافظة" : "Link detected in clipboard"}
                </p>
                <p className="font-mono-aurora truncate text-[10px] opacity-70">{clipboardUrl}</p>
              </div>
            </button>
            <button
              type="button"
              onClick={onDismissClipboard}
              className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-white/10"
            >
              <X className="h-3 w-3" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Giant Gemini-Style Glowing Glass URL Input */}
      <div
        className={`aurora-glass-card rounded-[28px] p-4 transition-all ${
          analyzingStage > 0 || urlInput.trim().length > 0 ? "aurora-gemini-glow" : ""
        }`}
      >
        <div className="flex items-center gap-2">
          <input
            dir="ltr"
            value={urlInput}
            onChange={(e) => onUrlChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && urlInput.trim()) handleTriggerAnalyze(urlInput);
            }}
            placeholder={
              lang === "ar"
                ? "الصق رابط فيديو، صوت، صورة، أو ملف مباشر..."
                : "Paste video, audio, image, or direct file URL..."
            }
            className={`w-full bg-transparent text-left text-xs font-medium outline-none placeholder:text-right ${
              darkMode
                ? "text-white placeholder:text-slate-400"
                : "text-slate-900 placeholder:text-slate-500"
            }`}
          />
          {urlInput && (
            <button
              type="button"
              onClick={() => onUrlChange("")}
              className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white/10"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>

        <div className="mt-3 flex items-center gap-2">
          <motion.button
            type="button"
            whileTap={{ scale: 0.96 }}
            onClick={() => handleTriggerAnalyze(urlInput || DEMO_SCENARIOS[0].sampleUrl)}
            className="aurora-gradient-bg flex flex-1 items-center justify-center gap-1.5 rounded-[20px] py-2.5 text-xs font-bold text-white shadow-md shadow-[#4285F4]/30"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>
              {analyzingStage > 0
                ? lang === "ar"
                  ? `جارٍ التحليل (مرحلة ${analyzingStage}/3)...`
                  : `Analyzing (Stage ${analyzingStage}/3)...`
                : lang === "ar"
                ? "تحليل فوري"
                : "Analyze Now"}
            </span>
          </motion.button>
          <motion.button
            type="button"
            whileTap={{ scale: 0.95 }}
            onClick={handlePasteClipboard}
            className="aurora-glass-card flex items-center gap-1.5 rounded-[20px] px-3.5 py-2.5 text-xs font-semibold"
          >
            <ClipboardPaste className="h-3.5 w-3.5 text-[#9B72CB]" />
            <span>{lang === "ar" ? "لصق" : "Paste"}</span>
          </motion.button>
        </div>

        {/* Quick Live Scenarios Bar */}
        <div className="no-scrollbar mt-3 flex gap-1.5 overflow-x-auto pb-0.5">
          {DEMO_SCENARIOS.map((sc) => (
            <button
              key={sc.key}
              type="button"
              onClick={() => handleTriggerAnalyze(sc.sampleUrl)}
              className={`shrink-0 rounded-full border px-2.5 py-1 text-[10px] font-semibold transition ${
                analysis?.originalUrl === sc.sampleUrl
                  ? "border-[#4285F4]/60 bg-[#4285F4]/25 text-sky-300"
                  : darkMode
                  ? "border-white/10 bg-white/5 text-slate-300 hover:bg-white/10"
                  : "border-slate-300/60 bg-white/60 text-slate-700 hover:bg-white"
              }`}
            >
              {lang === "ar" ? sc.labelAr : sc.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* Parallel Pipeline Skeleton Shimmer while loading */}
      {analyzingStage > 0 && (
        <div className="aurora-glass-card aurora-gemini-glow space-y-3 rounded-[28px] p-4">
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-semibold text-[#60A5FA]">
              {analyzingStage === 1
                ? lang === "ar"
                  ? "Stage 0–1: Preconnect + HEAD / Range 0-0 + Favicon"
                  : "Stage 0–1: Preconnect + HEAD / Range 0-0 + Favicon"
                : analyzingStage === 2
                ? lang === "ar"
                  ? "Stage 2: Native Fast-Path Extractor (<1.5s)"
                  : "Stage 2: Native Fast-Path Extractor (<1.5s)"
                : lang === "ar"
                ? "Stage 3: yt-dlp الكامل + حساب الأحجام الدقيقة"
                : "Stage 3: Full yt-dlp + Exact Byte Size Probe"}
            </span>
            <RefreshCw className="h-3.5 w-3.5 animate-spin text-[#9B72CB]" />
          </div>
          <div className="aurora-shimmer h-36 w-full rounded-[20px] bg-white/10" />
          <div className="aurora-shimmer h-4 w-4/5 rounded-full bg-white/10" />
          <div className="flex gap-2">
            <div className="aurora-shimmer h-9 flex-1 rounded-[18px] bg-white/10" />
            <div className="aurora-shimmer h-9 flex-1 rounded-[18px] bg-white/10" />
          </div>
        </div>
      )}

      {/* Progressive Info Card */}
      {analysis && analyzingStage === 0 && (
        <motion.div
          key={analysis.normalizedUrl}
          initial={{ opacity: 0, y: 14, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ type: "spring", stiffness: 280, damping: 24 }}
          className="space-y-3"
        >
          <div
            className="aurora-glass-card space-y-3 rounded-[28px] p-4"
            style={{
              boxShadow: `0 16px 40px -16px ${analysis.dominantAccent}55`,
            }}
          >
            {/* Site Logo + Domain + Type Badge */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex min-w-0 items-center gap-2.5">
                <div
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl text-xs font-extrabold text-white shadow-inner"
                  style={{ backgroundColor: analysis.faviconBg }}
                >
                  {analysis.faviconText}
                </div>
                <div className="min-w-0">
                  <p className="truncate text-xs font-bold">{analysis.siteName}</p>
                  <p className="font-mono-aurora truncate text-[10px] opacity-65">
                    {analysis.domain} • {analysis.stageLatencyMs}ms
                  </p>
                </div>
              </div>
              <span className="shrink-0 rounded-full bg-[#4285F4]/20 px-2.5 py-1 text-[10px] font-bold text-[#60A5FA]">
                {lang === "ar" ? analysis.primaryBadgeAr : analysis.primaryBadgeEn}
              </span>
            </div>

            {/* Thumbnail with Embedded Media3 Preview Button */}
            {analysis.thumbnailUrl && (
              <button
                type="button"
                onClick={() =>
                  onPreviewMedia({
                    title: analysis.title,
                    thumb: analysis.thumbnailUrl!,
                    duration: formatDuration(analysis.durationSeconds),
                  })
                }
                className="group relative block w-full overflow-hidden rounded-[22px] border border-white/15"
              >
                <img
                  src={analysis.thumbnailUrl}
                  alt={analysis.title}
                  className="h-44 w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black/25 transition group-hover:bg-black/40">
                  <span className="aurora-glass-card flex h-12 w-12 items-center justify-center rounded-full text-white">
                    <Play className="h-5 w-5 fill-white" />
                  </span>
                </div>
                {analysis.durationSeconds && (
                  <span className="font-mono-aurora absolute bottom-2.5 end-2.5 rounded-full bg-black/70 px-2.5 py-0.5 text-[10px] font-semibold text-white backdrop-blur-md">
                    {formatDuration(analysis.durationSeconds)}
                  </span>
                )}
              </button>
            )}

            {/* Streaming Text Reveal Title */}
            <div className="space-y-1">
              <h2 className="text-sm font-bold leading-snug">
                <StreamingText text={analysis.title} />
              </h2>
              {(analysis.author || analysis.publishedDate) && (
                <p className="text-[11px] opacity-65">
                  {[analysis.author, analysis.publishedDate].filter(Boolean).join(" • ")}
                </p>
              )}
            </div>

            {/* Editable File Name */}
            <div className="space-y-1">
              <label className="text-[10px] font-semibold opacity-65">
                {lang === "ar" ? "اسم الملف قبل التحميل (قابل للتعديل):" : "Filename (editable):"}
              </label>
              <input
                dir="ltr"
                value={displayFileName}
                onChange={(e) => setEditableName(e.target.value)}
                className={`font-mono-aurora w-full rounded-[16px] border px-3 py-2 text-[11px] outline-none ${
                  darkMode
                    ? "border-white/10 bg-black/30 text-slate-200 focus:border-[#4285F4]/60"
                    : "border-slate-300/70 bg-white/70 text-slate-800 focus:border-[#4285F4]"
                }`}
              />
            </div>

            {/* Exact vs Approx Primary Size Row */}
            {analysis.primarySize.bytes > 0 && (
              <div className="flex items-center justify-between rounded-[16px] bg-white/5 px-3 py-2 text-[11px]">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="font-mono-aurora font-bold text-emerald-400">
                    {formatFileSize(analysis.primarySize)}
                  </span>
                  <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[9px] font-semibold text-emerald-300">
                    {analysis.primarySize.precision === "EXACT"
                      ? lang === "ar"
                        ? "حجم مؤكد"
                        : "Exact"
                      : lang === "ar"
                      ? "تقريبي ≈"
                      : "Approx ≈"}
                  </span>
                </div>
                <span className="font-mono-aurora text-[10px] opacity-60">
                  {analysis.primarySize.source}
                </span>
              </div>
            )}

            {/* DRM Refusal Alert (Strict Legal Rule) */}
            {analysis.drmBlockedReasonAr && (
              <div className="flex items-start gap-2.5 rounded-[20px] border border-rose-500/35 bg-rose-500/15 p-3 text-xs text-rose-200">
                <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" />
                <span>
                  {lang === "ar" ? analysis.drmBlockedReasonAr : analysis.drmBlockedReasonEn}
                </span>
              </div>
            )}

            {/* Smart Indirect WebView Sniffer Fallback */}
            {analysis.requiresWebViewSniffer && (
              <motion.button
                type="button"
                whileTap={{ scale: 0.97 }}
                onClick={() => onOpenBrowser(analysis.normalizedUrl)}
                className="aurora-gradient-bg flex w-full items-center justify-center gap-2 rounded-[20px] py-3 text-xs font-bold text-white shadow-lg"
              >
                <Globe className="h-4 w-4" />
                <span>
                  {lang === "ar"
                    ? "افتح في المتصفح الداخلي لاصطياد الملفات (Cloudflare + Sniffer)"
                    : "Open in Internal Browser to Sniff Media (Cloudflare + Sniffer)"}
                </span>
              </motion.button>
            )}
          </div>

          {/* THE 4 SMART CONDITIONAL BUTTONS (Strictly ONLY rendered when items > 0!) */}
          {availableCategories.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between px-1">
                <span className="text-[11px] font-bold opacity-80">
                  {lang === "ar"
                    ? "الأزرار الذكية (تظهر فقط للأنواع المتوفرة)"
                    : "Smart Media Buttons (Only Available Types)"}
                </span>
                <span className="font-mono-aurora text-[10px] opacity-55">
                  {availableCategories.length}/4
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {availableCategories.map(({ cat, items }, index) => {
                  const meta = categoryMeta[cat];
                  const Icon = meta.icon;
                  return (
                    <motion.button
                      key={`${analysis.normalizedUrl}-${cat}`}
                      type="button"
                      initial={{ opacity: 0, scale: 0.85, filter: "blur(6px)", y: 8 }}
                      animate={{ opacity: 1, scale: 1, filter: "blur(0px)", y: 0 }}
                      transition={{
                        type: "spring",
                        stiffness: 340,
                        damping: 22,
                        delay: index * 0.06,
                      }}
                      whileTap={{ scale: 0.94 }}
                      onClick={() => setSheetCategory(cat)}
                      className={`aurora-glass-card flex items-center justify-between rounded-[22px] bg-gradient-to-br ${meta.tint} px-3.5 py-3 text-start`}
                    >
                      <div className="flex items-center gap-2">
                        <Icon className="h-4 w-4" />
                        <span className="text-xs font-bold">
                          {lang === "ar" ? meta.labelAr : meta.labelEn}
                        </span>
                      </div>
                      <span className="font-mono-aurora flex h-6 min-w-[24px] items-center justify-center rounded-full bg-white/20 px-1.5 text-[11px] font-extrabold">
                        {items.length}
                      </span>
                    </motion.button>
                  );
                })}
              </div>
            </div>
          )}
        </motion.div>
      )}

      {/* Recent Downloads Strip */}
      {recentDownloads.length > 0 && (
        <div className="space-y-2 pt-1">
          <p className="px-1 text-xs font-bold opacity-80">
            {lang === "ar" ? "أحدث التحميلات" : "Recent Downloads"}
          </p>
          <div className="space-y-2">
            {recentDownloads.slice(0, 2).map((dl) => {
              const pct = dl.totalBytes > 0 ? Math.round((dl.downloadedBytes / dl.totalBytes) * 100) : 0;
              return (
                <div
                  key={dl.id}
                  className="aurora-glass-card flex items-center justify-between gap-3 rounded-[22px] p-3"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-bold">{dl.fileName}</p>
                    <p className="font-mono-aurora text-[10px] opacity-65">
                      {dl.siteName} • {dl.maxConnections} {lang === "ar" ? "اتصال" : "seg"} • {pct}%
                    </p>
                  </div>
                  <span
                    className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${
                      dl.status === "COMPLETED"
                        ? "bg-emerald-500/20 text-emerald-300"
                        : "bg-sky-500/20 text-sky-300"
                    }`}
                  >
                    {dl.status === "COMPLETED"
                      ? lang === "ar"
                        ? "مكتمل"
                        : "Done"
                      : `${pct}%`}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Glass Bottom Sheet for Selected Smart Category */}
      <AuroraBottomSheet
        open={sheetCategory !== null}
        onClose={() => {
          setSheetCategory(null);
          setExactInspectOpt(null);
        }}
        darkMode={darkMode}
        title={
          sheetCategory
            ? `${lang === "ar" ? categoryMeta[sheetCategory].labelAr : categoryMeta[sheetCategory].labelEn} (${activeSheetItems.length})`
            : ""
        }
        subtitle={
          lang === "ar"
            ? "اضغط على أيقونة الحجم (i) لعرض البايت الدقيق • التمييز الصارم بين المؤكد والتقريبي (≈)"
            : "Tap size info (i) for exact byte count • Strict Exact vs Approximate (≈) distinction"
        }
      >
        <AnimatePresence>
          {exactInspectOpt && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              className="mb-3 flex items-center justify-between rounded-[18px] border border-[#4285F4]/40 bg-[#4285F4]/15 px-3 py-2 text-[11px]"
            >
              <div>
                <p className="font-mono-aurora font-bold text-sky-300">
                  {formatExactBytesLongPress(exactInspectOpt.size)}
                </p>
                <p className="text-[10px] opacity-75">{exactInspectOpt.size.source}</p>
              </div>
              <button
                type="button"
                onClick={() => setExactInspectOpt(null)}
                className="rounded-full bg-white/10 p-1"
              >
                <X className="h-3 w-3" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="space-y-2.5">
          {activeSheetItems.map((opt) => (
            <div
              key={opt.id}
              className="aurora-glass-card space-y-2 rounded-[22px] p-3.5"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-xs font-extrabold">{opt.qualityLabel}</span>
                    <span className="rounded-full bg-white/15 px-2 py-0.5 font-mono-aurora text-[10px] font-bold">
                      {opt.extension}
                    </span>
                    {opt.fps && (
                      <span className="rounded-full bg-sky-500/20 px-1.5 py-0.5 font-mono-aurora text-[9px] text-sky-300">
                        {opt.fps}fps
                      </span>
                    )}
                    {opt.isHdr && (
                      <span className="rounded-full bg-amber-500/25 px-1.5 py-0.5 font-mono-aurora text-[9px] font-bold text-amber-300">
                        HDR10
                      </span>
                    )}
                  </div>
                  <p className="mt-1 font-mono-aurora text-[10px] opacity-70">
                    {opt.codec}
                    {opt.bitrateKbps ? ` • ${opt.bitrateKbps} kbps` : ""}
                  </p>
                  {opt.requiresAudioMerge && (
                    <p className="mt-1 flex items-center gap-1 text-[10px] font-semibold text-violet-300">
                      <Sparkles className="h-3 w-3" />
                      {lang === "ar"
                        ? "دمج تلقائي مع أفضل صوت عبر FFmpeg (-c copy) • الحجم إجمالي"
                        : "Auto-merge with best audio via FFmpeg (-c copy) • Total combined size"}
                    </p>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => setExactInspectOpt(opt)}
                  title="Inspect exact byte count"
                  className={`flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 font-mono-aurora text-[11px] font-bold ${
                    opt.size.precision === "EXACT"
                      ? "bg-emerald-500/20 text-emerald-300"
                      : "bg-amber-500/20 text-amber-300"
                  }`}
                >
                  <span>{formatFileSize(opt.size)}</span>
                  <Info className="h-3 w-3" />
                </button>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.96 }}
                  onClick={() => {
                    onDownloadOption(opt, displayFileName);
                    setSheetCategory(null);
                  }}
                  className="aurora-gradient-bg flex flex-1 items-center justify-center gap-1.5 rounded-[16px] py-2 text-xs font-bold text-white"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>{lang === "ar" ? "تحميل فوري" : "Download"}</span>
                </motion.button>
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.96 }}
                  onClick={() => {
                    setSheetCategory(null);
                    onOpenConverter(opt);
                  }}
                  className="aurora-glass-card flex items-center gap-1 rounded-[16px] px-3 py-2 text-xs font-semibold"
                >
                  <Wand2 className="h-3.5 w-3.5 text-[#9B72CB]" />
                  <span>{lang === "ar" ? "تحويل إلى…" : "Convert…"}</span>
                </motion.button>
              </div>
            </div>
          ))}
        </div>
      </AuroraBottomSheet>

      {/* Batch URLs Glass Bottom Sheet */}
      <AuroraBottomSheet
        open={batchOpen}
        onClose={() => setBatchOpen(false)}
        darkMode={darkMode}
        title={lang === "ar" ? "تحليل دفعة روابط (Batch)" : "Batch Link Analyzer"}
        subtitle={
          lang === "ar"
            ? "الصق عدة روابط (رابط في كل سطر) للتحليل المتوازي"
            : "Paste multiple URLs (one per line) for parallel extraction"
        }
      >
        <div className="space-y-3">
          <textarea
            dir="ltr"
            rows={4}
            value={batchText}
            onChange={(e) => setBatchText(e.target.value)}
            placeholder={"https://youtube.com/watch?v=...\nhttps://tiktok.com/@...\nhttps://soundcloud.com/..."}
            className="font-mono-aurora w-full rounded-[20px] border border-white/15 bg-black/30 p-3 text-xs text-white outline-none"
          />
          <button
            type="button"
            onClick={() => {
              const first = batchText
                .split("\n")
                .map((l) => l.trim())
                .find((l) => l.startsWith("http"));
              setBatchOpen(false);
              if (first) handleTriggerAnalyze(first);
              else handleTriggerAnalyze(DEMO_SCENARIOS[0].sampleUrl);
            }}
            className="aurora-gradient-bg w-full rounded-[20px] py-3 text-xs font-bold text-white"
          >
            {lang === "ar" ? "بدء تحليل الدفعة بالتوازي" : "Analyze Batch in Parallel"}
          </button>
        </div>
      </AuroraBottomSheet>
    </div>
  );
}
