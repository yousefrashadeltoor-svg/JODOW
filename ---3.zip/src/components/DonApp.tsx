"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion, Reorder } from "framer-motion";
import {
  ArrowDown,
  ArrowUp,
  BatteryCharging,
  Check,
  CheckCircle2,
  ClipboardPaste,
  Code2,
  Copy,
  Smartphone,
  Download,
  FileText,
  Film,
  Fingerprint,
  Globe,
  Home,
  Image as ImageIcon,
  Info,
  Library,
  Lock,
  Maximize2,
  Minimize2,
  Moon,
  Music2,
  Pause,
  PictureInPicture2,
  Play,
  Plus,
  Radar,
  RefreshCw,
  Repeat,
  Repeat1,
  Search,
  Settings as SettingsIcon,
  ShieldCheck,
  ShieldAlert,
  Shuffle,
  Signal,
  Sliders,
  Sparkles,
  Subtitles,
  Sun,
  Trash2,
  User,
  Video,
  Wifi,
  Wand2,
  X,
  Zap,
  Bell,
  BedDouble,
  Volume2,
} from "lucide-react";
import {
  analyzeUrl,
  createInitialDownloads,
  DON_CHANNELS,
  DON_LOCAL_PROFILE,
  DON_THEMES,
  DON_VIDEOS,
  donSearchSuggestions,
  getThemePalette,
} from "@/lib/don-data";
import type {
  AnalysisResult,
  DonChannel,
  DonDownload,
  DonLocalProfile,
  DonRepeatMode,
  DonTheme,
  DonVideo,
  DonYtTab,
  LangCode,
  MediaCategory,
  MediaFormat,
} from "@/lib/don-types";
import {
  AuroraMeshBackdrop,
  FloatingGlassDock,
  type AuroraTabKey,
} from "./aurora/AuroraGlassUi";
import { AndroidSourceModal } from "./aurora/AndroidSourceModal";
import {
  AuroraBottomSheet,
  AuroraGlassButton,
  AuroraGlassSurface,
  AuroraProgressGlowBar,
  AuroraShimmerBox,
  AuroraSpeedSparkline,
  StreamingText,
} from "./aurora/AuroraGlassComponents";

// ────────────────────────────────────────────────────────────────────────────
// Utility helpers
// ────────────────────────────────────────────────────────────────────────────
function formatHumanBinary(bytes: number): string {
  if (!bytes || bytes <= 0) return "0 B";
  const units = ["B", "KiB", "MiB", "GiB", "TiB"];
  let v = bytes;
  let idx = 0;
  while (v >= 1024 && idx < units.length - 1) {
    v /= 1024;
    idx++;
  }
  return `${v.toFixed(v >= 100 ? 1 : 2).replace(/\.00$/, "")} ${units[idx]}`;
}
function formatFileSize(size: { bytes: number; precision: string; source?: string }) {
  if (!size || size.bytes <= 0 || size.precision === "UNKNOWN") return "—";
  const human = formatHumanBinary(size.bytes);
  return size.precision === "APPROXIMATE" ? `≈ ${human}` : human;
}
function formatExactLongPress(size: { bytes: number; precision: string; source?: string }) {
  if (!size || size.bytes <= 0) return "Size unavailable";
  const exact = new Intl.NumberFormat("en-US").format(size.bytes);
  const human = formatHumanBinary(size.bytes);
  const prefix = size.precision === "APPROXIMATE" ? "≈ " : "";
  return `${prefix}${exact} bytes (${human}) • ${size.source}`;
}
function formatDuration(seconds?: number) {
  if (!seconds || seconds <= 0) return "";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

// ────────────────────────────────────────────────────────────────────────────
// Main 𝒥𝒪 DON App
// ────────────────────────────────────────────────────────────────────────────
export function DonApp() {
  // Global Settings (zero backend)
  const [theme, setTheme] = useState<DonTheme>("AURORA");
  const [darkMode, setDarkMode] = useState(true);
  const [amoled, setAmoled] = useState(true);
  const [lang, setLang] = useState<LangCode>("ar");
  const [dynamicTint, setDynamicTint] = useState(true);
  const [defaultSegments, setDefaultSegments] = useState(16);
  const [dohEnabled, setDohEnabled] = useState(true);
  const [adBlockEnabled, setAdBlockEnabled] = useState(true);
  const [clipboardDetect, setClipboardDetect] = useState(true);
  const [audioOnlyDefault, setAudioOnlyDefault] = useState(false);
  const [sleepTimerDefault, setSleepTimerDefault] = useState<number | null>(null);
  const [phoneFrame, setPhoneFrame] = useState(true);
  const [sourceOpen, setSourceOpen] = useState(false);
  const [onboardingOpen, setOnboardingOpen] = useState(true);
  const [settingsScreen, setSettingsScreen] = useState<"main" | "themes">("main");

  // Navigation
  const [activeTab, setActiveTab] = useState<AuroraTabKey>("home");
  const [donTab, setDonTab] = useState<DonYtTab>("HOME");
  const [toolsSubTab, setToolsSubTab] = useState<"compressor" | "converter">("compressor");

  // Analyzer (Home) state
  const [urlInput, setUrlInput] = useState("https://youtube.com/watch?v=aurora_iceland_8k_hdr");
  const [analyzingStage, setAnalyzingStage] = useState(0);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [editableName, setEditableName] = useState("");
  const [sheetCategory, setSheetCategory] = useState<MediaCategory | null>(null);
  const [exactInspect, setExactInspect] = useState<MediaFormat | null>(null);
  const [clipboardUrl, setClipboardUrl] = useState<string | null>(
    "https://tiktok.com/@cybertokyo/video/7481920441"
  );

  // Downloads
  const [downloads, setDownloads] = useState<DonDownload[]>(() => createInitialDownloads());

  // Browser
  const [browserUrl, setBrowserUrl] = useState("https://streamhub.example.org/watch/live-aurora-hls");
  const [desktopMode, setDesktopMode] = useState(false);
  const [privateMode, setPrivateMode] = useState(true);
  const [blockedCount, setBlockedCount] = useState(27);
  const [cfSynced, setCfSynced] = useState(true);
  const [sniffedOpen, setSniffedOpen] = useState(false);
  const sniffedResources = useMemo<MediaFormat[]>(
    () => [
      {
        id: "sniff-hls",
        category: "VIDEO",
        title: "master_1080p60_aurora_stream.m3u8",
        qualityLabel: "HLS 1080p • 32 Segments",
        extension: "MP4",
        codec: "HLS -> FFmpeg -c copy",
        fps: 60,
        size: { bytes: 218_420_110, precision: "EXACT", source: "Parallel HLS HEAD Sum" },
      },
      {
        id: "sniff-aud",
        category: "AUDIO",
        title: "stream_audio_aac_256k.m4a",
        qualityLabel: "AAC 256",
        extension: "M4A",
        codec: "AAC-LC",
        bitrateKbps: 256,
        size: { bytes: 14_820_480, precision: "EXACT", source: "Range 0-0" },
      },
      {
        id: "sniff-poster",
        category: "IMAGE",
        title: "stream_poster_uhd.webp",
        qualityLabel: "4K Poster",
        extension: "WEBP",
        codec: "WebP",
        size: { bytes: 924_112, precision: "EXACT", source: "HEAD" },
      },
    ],
    []
  );

  // 𝒥𝒪 YouTube native state
  const [donHome, setDonHome] = useState<DonVideo[]>(() => [...DON_VIDEOS]);
  const [donShorts] = useState<DonVideo[]>(() => DON_VIDEOS.filter((v) => v.isShort || Math.random() > 0.4));
  const [donQuery, setDonQuery] = useState("");
  const [donSuggestions, setDonSuggestions] = useState<string[]>([]);
  const [donSearchResults, setDonSearchResults] = useState<DonVideo[] | null>(null);
  const [donChannels, setDonChannels] = useState<DonChannel[]>(DON_CHANNELS);
  const [donSubFeed, setDonSubFeed] = useState<DonVideo[]>(() =>
    DON_VIDEOS.filter((v) => ["@nordic-cinema", "@cybertokyo", "@aurora-lofi"].includes(v.channelHandle))
  );
  const [donProfile, setDonProfile] = useState<DonLocalProfile>(DON_LOCAL_PROFILE);
  const [donHistory, setDonHistory] = useState<string[]>([
    "aurora borealis iceland",
    "cyberpunk night drive",
    "lofi 1 hour",
  ]);
  const [activeVideo, setActiveVideo] = useState<DonVideo | null>(null);
  // Premium player state
  const [audioOnly, setAudioOnly] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [repeatMode, setRepeatMode] = useState<DonRepeatMode>("OFF");
  const [sleepMinutes, setSleepMinutes] = useState<number | null>(null);
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(1);
  const [trimEditing, setTrimEditing] = useState(false);
  const [volume, setVolume] = useState(75);
  const [subtitlesOn, setSubtitlesOn] = useState(true);
  const [pip, setPip] = useState(false);
  const [ringtoneSet, setRingtoneSet] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast((c) => (c === msg ? null : c)), 2800);
  }, []);

  const palette = useMemo(() => getThemePalette(theme), [theme]);
  const dynamicAccent = dynamicTint && analysis?.faviconBg ? analysis.faviconBg : undefined;

  const cssVars = useMemo(
    (): React.CSSProperties & Record<string, string | number> => ({
      "--aurora-start": dynamicAccent || palette.start,
      "--aurora-mid": palette.mid,
      "--aurora-end": palette.end,
      "--aurora-surface": darkMode ? "rgba(255,255,255,0.065)" : "rgba(255,255,255,0.70)",
      "--aurora-surface-strong": darkMode ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.88)",
      "--aurora-border-top": darkMode ? "rgba(255,255,255,0.24)" : "rgba(255,255,255,0.95)",
      "--aurora-border-bottom": darkMode ? "rgba(255,255,255,0.06)" : "rgba(148,163,184,0.35)",
      // Theme-controlled animation speeds & shape radius
      "--aurora-spin-speed":
        theme === "NEON" ? "2.2s" : theme === "MONO" ? "8s" : "3.4s",
      "--aurora-blob-speed-a":
        theme === "SUNSET" ? "14s" : theme === "OCEAN" ? "18s" : "16s",
      "--aurora-blob-speed-b":
        theme === "EMERALD" ? "18s" : theme === "NEON" ? "14s" : "20s",
      "--aurora-radius-large":
        theme === "MONO" ? "18px" : theme === "NEON" ? "30px" : "28px",
    }),
    [palette, darkMode, dynamicAccent, theme]
  );

  // Live download simulator
  useEffect(() => {
    const t = setInterval(() => {
      setDownloads((prev) =>
        prev.map((d) => {
          if (d.status !== "DOWNLOADING") return d;
          const speed = 14_500_000 + Math.floor(Math.random() * 11_000_000);
          const next = Math.min(d.totalBytes, d.downloadedBytes + Math.floor(speed * 0.45));
          const done = d.totalBytes > 0 && next >= d.totalBytes;
          return {
            ...d,
            downloadedBytes: next,
            speedBps: speed,
            speedHistory: [...d.speedHistory.slice(-17), speed],
            workStealing: next / d.totalBytes > 0.72,
            status: done ? "COMPLETED" : d.status,
          };
        })
      );
    }, 900);
    return () => clearInterval(t);
  }, []);

  // Analyzer trigger
  const runAnalyze = useCallback((rawUrl: string) => {
    const url = rawUrl.trim();
    if (!url) return;
    setAnalyzingStage(1);
    setAnalysis(null);
    setEditableName("");
    setTimeout(() => setAnalyzingStage(2), 180);
    setTimeout(() => setAnalyzingStage(3), 380);
    setTimeout(() => {
      const result = analyzeUrl(url);
      setAnalysis(result);
      setAnalyzingStage(0);
      setEditableName(result.suggestedFileName);
    }, 540);
  }, []);

  // Auto-analyze initial URL
  useEffect(() => {
    runAnalyze(urlInput);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Search suggestions for DON YouTube
  useEffect(() => {
    if (!donQuery.trim()) {
      setDonSuggestions(donHistory);
      setDonSearchResults(null);
      return;
    }
    setDonSuggestions(donSearchSuggestions(donQuery, donHistory));
    const lower = donQuery.toLowerCase();
    const results = DON_VIDEOS.filter(
      (v) =>
        v.title.toLowerCase().includes(lower) ||
        v.channelName.toLowerCase().includes(lower)
    );
    setDonSearchResults(results);
  }, [donQuery]);

  const startDownload = useCallback(
    (format: MediaFormat, customBase?: string) => {
      const ext = format.extension.toLowerCase();
      const base = (customBase || format.title).replace(/\.[a-z0-9]{2,5}$/i, "");
      const name = `${base}.${ext}`;
      const id = `dl-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const newDl: DonDownload = {
        id,
        title: base,
        fileName: name,
        category: format.category,
        siteName: format.audioOnly ? "𝒥𝒪 DON Audio" : "𝒥𝒪 DON",
        totalBytes: format.size.bytes || 24_800_000,
        sizePrecision: format.size.precision as "EXACT" | "APPROXIMATE" | "UNKNOWN",
        downloadedBytes: 0,
        maxConnections: defaultSegments,
        status: "DOWNLOADING",
        priority: 20,
        speedBps: 0,
        speedHistory: [],
        workStealing: false,
        requiresMerge: Boolean(format.requiresAudioMerge),
        savedByCompressionBytes: 0,
        thumbnailUrl: format.category === "AUDIO" ? "/images/aurora-thumb-audio.png" : analysis?.thumbnailUrl,
      };
      setDownloads((d) => [newDl, ...d]);
      setActiveTab("downloads");
      showToast(
        lang === "ar"
          ? `بدأ التحميل بـ ${defaultSegments} اتصال: ${name}`
          : `Started ${defaultSegments}-segment download: ${name}`
      );
    },
    [defaultSegments, analysis?.thumbnailUrl, lang, showToast]
  );

  const toggleDlPause = useCallback((id: string) => {
    setDownloads((prev) =>
      prev.map((d) =>
        d.id === id
          ? { ...d, status: d.status === "DOWNLOADING" ? "PAUSED" : "DOWNLOADING" }
          : d
      )
    );
  }, []);
  const deleteDl = useCallback((id: string) => {
    setDownloads((prev) => prev.filter((d) => d.id !== id));
  }, []);
  const reorderDl = useCallback((id: string, delta: number) => {
    setDownloads((prev) => {
      const idx = prev.findIndex((d) => d.id === id);
      if (idx === -1) return prev;
      const tgt = idx - delta;
      if (tgt < 0 || tgt >= prev.length) return prev;
      const copy = [...prev];
      const [it] = copy.splice(idx, 1);
      copy.splice(tgt, 0, it);
      return copy;
    });
  }, []);
  const sendToCompressor = useCallback(() => {
    setToolsSubTab("compressor");
    setActiveTab("tools");
  }, []);

  const toggleFollowChannel = useCallback((id: string) => {
    setDonChannels((ch) =>
      ch.map((c) => (c.id === id ? { ...c, followed: !c.followed } : c))
    );
    setDonChannels((channels) => {
      const followed = channels.filter((c) => c.followed).map((c) => c.handle);
      setDonSubFeed(DON_VIDEOS.filter((v) => followed.includes(v.channelHandle)));
      setDonProfile((p) => ({
        ...p,
        followingCount: channels.filter((c) => c.followed).length,
      }));
      return channels;
    });
  }, []);

  // Toggle follow action with ripple update
  useEffect(() => {
    const followed = donChannels.filter((c) => c.followed).map((c) => c.handle);
    setDonSubFeed(DON_VIDEOS.filter((v) => followed.includes(v.channelHandle)));
    setDonProfile((p) => ({ ...p, followingCount: followed.length }));
  }, [donChannels]);

  const categories = useMemo<Array<{ cat: MediaCategory; items: MediaFormat[] }>>(() => {
    if (!analysis) return [];
    const order: MediaCategory[] = ["AUDIO", "IMAGE", "VIDEO", "FILE"];
    return order
      .map((cat) => ({ cat, items: analysis.formats.filter((f) => f.category === cat) }))
      .filter((entry) => entry.items.length > 0);
  }, [analysis]);

  const dockTabs: Array<{ key: AuroraTabKey; ar: string; en: string; icon: React.ComponentType<{ className?: string }>; badge?: number }> = [
    { key: "home", ar: "الرئيسية", en: "Home", icon: Home },
    {
      key: "downloads",
      ar: "التحميلات",
      en: "Queue",
      icon: Download,
      badge: downloads.filter((d) => d.status === "DOWNLOADING").length,
    },
    { key: "don", ar: "𝒥𝒪 YT", en: "𝒥𝒪 YT", icon: Video },
    { key: "browser", ar: "المتصفح", en: "Sniffer", icon: Globe },
    { key: "tools", ar: "الأدوات", en: "Tools", icon: Wand2 },
    { key: "library", ar: "المكتبة", en: "Library", icon: Library },
    { key: "settings", ar: "الإعدادات", en: "Settings", icon: SettingsIcon },
  ];

  const dir = lang === "ar" ? "rtl" : "ltr";
  const htmlDir = lang === "ar" ? "rtl" : "ltr";
  useEffect(() => {
    if (typeof document !== "undefined") {
      document.documentElement.dir = htmlDir;
      document.documentElement.lang = lang;
    }
  }, [htmlDir, lang]);

  return (
    <div
      dir={dir}
      style={cssVars}
      className={`relative min-h-screen w-full overflow-x-hidden transition-colors duration-500 ${
        darkMode ? "text-slate-50" : "text-slate-900"
      }`}
    >
      {/* Outer ambient blobs */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden opacity-70">
        <div
          className="aurora-blob-a absolute -top-32 start-1/4 h-96 w-96 rounded-full blur-[130px]"
          style={{
            backgroundColor: dynamicAccent || palette.start,
            opacity: 0.28,
            animationDuration: "var(--aurora-blob-speed-a)",
          }}
        />
        <div
          className="aurora-blob-b absolute bottom-0 end-1/4 h-96 w-96 rounded-full blur-[140px]"
          style={{
            backgroundColor: palette.mid,
            opacity: 0.24,
            animationDuration: "var(--aurora-blob-speed-b)",
          }}
        />
      </div>

      {/* Top Studio Header */}
      <header className="relative z-20 mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4">
        <div className="flex items-center gap-2.5">
          <div className="aurora-gradient-bg flex h-10 w-10 items-center justify-center rounded-2xl text-white shadow-lg shadow-sky-500/30">
            <Sparkles className="h-4 w-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="aurora-gradient-text text-base font-extrabold tracking-tight">
                𝒥𝒪 DON
              </h1>
              <span className="rounded-full border border-emerald-400/40 bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold text-emerald-400">
                Zero Material • 100% Offline-Ready
              </span>
            </div>
            <p className="text-[11px] opacity-70">
              {lang === "ar"
                ? "محمل فائق السرعة + 𝒥𝒪 YouTube أصلي + مشغل متميز + ثيمات كاملة التحكم"
                : "Lightning Segmented Downloader + Native 𝒥𝒪 YouTube + Premium Player + Full Theme Control"}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setSourceOpen(true)}
            className="aurora-gradient-bg flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[11px] font-extrabold text-white shadow-md shadow-sky-500/30 active:scale-95"
          >
            <Code2 className="h-3.5 w-3.5" />
            {lang === "ar" ? "كود Android (JP PROJ)" : "Android Source (JP PROJ)"}
          </button>
          <button
            type="button"
            onClick={() => setPhoneFrame((v) => !v)}
            className="aurora-glass-card hidden items-center gap-1.5 rounded-full px-3 py-2 text-[11px] font-semibold md:flex"
          >
            {phoneFrame ? <Maximize2 className="h-3.5 w-3.5" /> : <Minimize2 className="h-3.5 w-3.5" />}
            {phoneFrame ? (lang === "ar" ? "توسيع" : "Expand") : lang === "ar" ? "إطار الهاتف" : "Phone Frame"}
          </button>
          <button
            type="button"
            onClick={() => setDarkMode((v) => !v)}
            className="aurora-glass-card flex h-9 w-9 items-center justify-center rounded-full"
          >
            {darkMode ? <Sun className="h-4 w-4 text-amber-300" /> : <Moon className="h-4 w-4 text-indigo-600" />}
          </button>
          <button
            type="button"
            onClick={() => setLang((l) => (l === "ar" ? "en" : "ar"))}
            className="aurora-glass-card flex items-center gap-1 rounded-full px-3 py-2 text-[11px] font-bold"
          >
            <Globe className="h-3.5 w-3.5 text-sky-400" />
            <span>{lang === "ar" ? "EN" : "عربي"}</span>
          </button>
        </div>
      </header>

      {/* Phone Stage */}
      <main className="relative z-10 mx-auto flex max-w-6xl flex-col items-center justify-center px-3 pb-10 pt-1">
        <div
          className={`relative flex flex-col overflow-hidden transition-all duration-500 ${
            phoneFrame
              ? "h-[820px] w-full max-w-[420px] rounded-[46px] border-[6px] border-white/20 shadow-[0_32px_90px_-20px_rgba(0,0,0,0.85)]"
              : "min-h-[720px] h-[82vh] w-full max-w-4xl rounded-[34px] border border-white/20 shadow-2xl"
          }`}
        >
          <AuroraMeshBackdrop
            start={palette.start}
            mid={palette.mid}
            end={palette.end}
            darkMode={darkMode}
            amoled={amoled}
            dynamicAccent={dynamicAccent}
          />

          {/* Status bar */}
          <div
            dir="ltr"
            className={`relative z-20 flex shrink-0 items-center justify-between px-6 pb-1.5 pt-3 text-[11px] font-semibold ${
              darkMode ? "text-white/90" : "text-slate-900/90"
            }`}
          >
            <span className="font-mono-aurora">09:41</span>
            {phoneFrame && <div className="h-4 w-24 rounded-full bg-black/85 ring-1 ring-white/10" />}
            <div className="flex items-center gap-1.5">
              <Signal className="h-3.5 w-3.5" />
              <Wifi className="h-3.5 w-3.5" />
              <BatteryCharging className="h-3.5 w-3.5 text-emerald-400" />
            </div>
          </div>

          {/* In-app toast */}
          <AnimatePresence>
            {toast && (
              <motion.div
                initial={{ opacity: 0, y: -14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -14 }}
                className="aurora-glass-card absolute inset-x-4 top-12 z-40 flex items-center gap-2 rounded-[20px] bg-black/70 px-3.5 py-2.5 text-[11px] font-bold text-white"
              >
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                <span className="truncate">{toast}</span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Content */}
          <div className="no-scrollbar relative z-10 flex-1 overflow-y-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab + (activeTab === "don" ? donTab : "")}
                initial={{ opacity: 0, scale: 0.99, filter: "blur(5px)" }}
                animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                exit={{ opacity: 0, scale: 0.99, filter: "blur(5px)" }}
                transition={{ duration: 0.22 }}
                className="min-h-full pb-28"
              >
                {activeTab === "home" && <HomePanel />}
                {activeTab === "downloads" && <DownloadsPanel />}
                {activeTab === "don" && <DonYtPanel />}
                {activeTab === "browser" && <BrowserPanel />}
                {activeTab === "tools" && <ToolsPanel />}
                {activeTab === "library" && <LibraryPanel />}
                {activeTab === "settings" && <SettingsPanel />}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Custom Floating Glass Dock (Zero Material) */}
          <div className="absolute inset-x-0 bottom-3 z-30 flex justify-center px-3">
            <nav
              className={`aurora-glass-card flex w-full max-w-[400px] items-center justify-between rounded-[28px] p-1.5 ${
                darkMode ? "bg-black/50" : "bg-white/80"
              }`}
            >
              {dockTabs.map((t) => {
                const Icon = t.icon;
                const active = activeTab === t.key;
                return (
                  <button
                    key={t.key}
                    type="button"
                    onClick={() => setActiveTab(t.key)}
                    className={`relative flex items-center justify-center gap-1.5 rounded-[22px] px-2 py-2 text-[11px] font-bold transition ${
                      active ? "" : darkMode ? "text-slate-400" : "text-slate-500"
                    }`}
                  >
                    {active && (
                      <motion.span
                        layoutId="dock-pill-don"
                        transition={{ type: "spring", stiffness: 380, damping: 28 }}
                        className="aurora-gradient-bg absolute inset-0 rounded-[22px] opacity-25"
                      />
                    )}
                    <Icon className={`relative z-10 h-4 w-4 ${active ? "" : "opacity-90"}`} />
                    {active && (
                      <motion.span
                        initial={{ opacity: 0, width: 0 }}
                        animate={{ opacity: 1, width: "auto" }}
                        exit={{ opacity: 0, width: 0 }}
                        className="relative z-10 whitespace-nowrap text-[11px]"
                      >
                        {lang === "ar" ? t.ar : t.en}
                      </motion.span>
                    )}
                    {t.badge !== undefined && t.badge > 0 && (
                      <span className="aurora-gradient-bg relative z-10 flex h-4 min-w-[16px] items-center justify-center rounded-full px-1 text-[9px] font-extrabold text-white">
                        {t.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        <div className="mt-5 flex flex-wrap items-center justify-center gap-3 text-[11px] opacity-75">
          <span className="flex items-center gap-1">
            <Smartphone className="h-3.5 w-3.5 text-sky-400" />
            Kotlin 2.1 + Compose Foundation/UI + Haze + AGSL
          </span>
          <span>•</span>
          <span>yt-dlp + aria2c + FFmpeg + Cronet QUIC + adblock-rust</span>
          <span>•</span>
          <span>17 Gradle modules inside JP PROJ/</span>
        </div>
      </main>

      {/* Format bottom sheet */}
      <AuroraBottomSheet
        open={sheetCategory !== null}
        onClose={() => {
          setSheetCategory(null);
          setExactInspect(null);
        }}
        darkMode={darkMode}
        title={
          sheetCategory
            ? `${sheetCategory} (${(analysis?.formats.filter((f) => f.category === sheetCategory) || []).length})`
            : ""
        }
        subtitle={
          lang === "ar"
            ? "اضغط (i) لعرض البايت الدقيق • تمييز صارم بين المؤكد والتقريبي (≈)"
            : "Tap info for exact bytes • Strict Exact vs Approximate (≈) distinction"
        }
      >
        {exactInspect && (
          <div className="mb-3 flex items-center justify-between rounded-[18px] border border-sky-400/40 bg-sky-500/15 px-3 py-2 text-[11px]">
            <div>
              <p className="font-mono-aurora font-bold text-sky-300">
                {formatExactLongPress(exactInspect.size)}
              </p>
              <p className="text-[10px] opacity-75">{exactInspect.size.source}</p>
            </div>
            <button
              type="button"
              onClick={() => setExactInspect(null)}
              className="rounded-full bg-white/10 p-1"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        )}
        <div className="space-y-2.5">
          {(analysis?.formats.filter((f) => f.category === sheetCategory) || []).map((opt) => (
            <div key={opt.id} className="aurora-glass-card space-y-2 rounded-[20px] p-3.5">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-xs font-extrabold">{opt.qualityLabel}</span>
                    <span className="rounded-full bg-white/15 px-2 py-0.5 font-mono-aurora text-[10px] font-bold">
                      {opt.extension}
                    </span>
                    {opt.fps && (
                      <span className="rounded-full bg-sky-500/20 px-1.5 py-0.5 font-mono-aurora text-[9px] text-sky-300">
                        {opt.fps}fps
                      </span>
                    )}
                    {opt.isHdr && (
                      <span className="rounded-full bg-amber-500/25 px-1.5 py-0.5 font-mono-aurora text-[9px] font-bold text-amber-300">
                        HDR
                      </span>
                    )}
                  </div>
                  <p className="mt-1 font-mono-aurora text-[10px] opacity-70">
                    {opt.codec}
                    {opt.bitrateKbps ? ` • ${opt.bitrateKbps} kbps` : ""}
                  </p>
                  {opt.requiresAudioMerge && (
                    <p className="mt-1 flex items-center gap-1 text-[10px] font-semibold text-violet-300">
                      <Sparkles className="h-3 w-3" />
                      {lang === "ar"
                        ? "دمج تلقائي مع أفضل صوت عبر FFmpeg (-c copy) • الحجم إجمالي"
                        : "Auto-merge with best audio via FFmpeg (-c copy) • Combined size"}
                    </p>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => setExactInspect(opt)}
                  className={`flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 font-mono-aurora text-[11px] font-bold ${
                    opt.size.precision === "EXACT"
                      ? "bg-emerald-500/20 text-emerald-300"
                      : "bg-amber-500/20 text-amber-300"
                  }`}
                >
                  <span>{formatFileSize(opt.size)}</span>
                  <Info className="h-3 w-3" />
                </button>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => startDownload(opt, editableName)}
                  className="aurora-gradient-bg flex flex-1 items-center justify-center gap-1.5 rounded-[16px] py-2 text-xs font-bold text-white"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>{lang === "ar" ? "تحميل فوري" : "Download"}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setToolsSubTab("converter");
                    setActiveTab("tools");
                    setSheetCategory(null);
                  }}
                  className="aurora-glass-card flex items-center gap-1 rounded-[16px] px-3 py-2 text-xs font-semibold"
                >
                  <Wand2 className="h-3.5 w-3.5 text-violet-400" />
                  <span>{lang === "ar" ? "تحويل" : "Convert"}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </AuroraBottomSheet>

      {/* Sniffer resources sheet */}
      <AuroraBottomSheet
        open={sniffedOpen}
        onClose={() => setSniffedOpen(false)}
        darkMode={darkMode}
        title={lang === "ar" ? `الملفات المصطادة (${sniffedResources.length})` : `Sniffed Resources (${sniffedResources.length})`}
        subtitle={
          lang === "ar"
            ? "يُنقل Cookie + Referer + User-Agent إلى محرك 𝒥𝒪 DON"
            : "Cookies + Referer + UA handed directly to the segmented engine"
        }
      >
        <div className="space-y-2.5">
          {sniffedResources.map((res) => (
            <div key={res.id} className="aurora-glass-card flex items-center justify-between gap-2 rounded-[20px] p-3">
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-bold">{res.title}</p>
                <p className="font-mono-aurora text-[10px] opacity-70">
                  {res.qualityLabel} • {formatFileSize(res.size)}
                </p>
                <p className="text-[10px] text-emerald-400">Cookie + Referer + UA attached</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  startDownload(res, res.title);
                  setSniffedOpen(false);
                }}
                className="aurora-gradient-bg shrink-0 rounded-[14px] px-3.5 py-2 text-xs font-bold text-white"
              >
                {lang === "ar" ? "تحميل" : "Get"}
              </button>
            </div>
          ))}
        </div>
      </AuroraBottomSheet>

      {/* Premium Player Modal for 𝒥𝒪 YouTube videos */}
      <PremiumPlayerModal />

      {/* Source Modal */}
      <AndroidSourceModal open={sourceOpen} onClose={() => setSourceOpen(false)} lang={lang} />

      {/* Onboarding */}
      <div
        className={`fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-5 backdrop-blur-xl ${
          onboardingOpen ? "" : "pointer-events-none opacity-0"
        }`}
      >
        <motion.div
          initial={{ scale: 0.9, y: 24, opacity: 0 }}
          animate={{ scale: onboardingOpen ? 1 : 0.9, y: onboardingOpen ? 0 : 24, opacity: onboardingOpen ? 1 : 0 }}
          transition={{ type: "spring", stiffness: 280, damping: 24 }}
          className="aurora-glass-card aurora-gemini-glow w-full max-w-md rounded-[32px] p-6 text-white"
        >
          <div className="aurora-gradient-bg mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-[22px]">
            <Sparkles className="h-8 w-8 text-white" />
          </div>
          <h2 className="aurora-gradient-text text-center text-2xl font-extrabold">
            𝒥𝒪 DON
          </h2>
          <p className="mt-2 text-center text-[12px] leading-relaxed text-slate-300">
            {lang === "ar"
              ? "محرك تحميل مجزأ حتى 32 اتصالًا مع Work-Stealing، تطبيق 𝒥𝒪 YouTube أصلي (بدون WebView)، متصفح صيد وسائط + AdBlock، مشغل محلي فاخر، وتصغير ذكي Lossless/SSIM ≥ 95% — كل ذلك بتصميم Aurora Glass نقي بدون Material."
              : "32-segment parallel downloads with work-stealing, a fully native 𝒥𝒪 YouTube client (no WebView), Sniffer Browser + AdBlock, a premium offline media player, and a Smart Lossless/SSIM ≥ 95% Compressor — all in pure Aurora Glass UI with zero Material."}
          </p>
          <div className="mt-4 flex items-start gap-2.5 rounded-[20px] border border-emerald-400/30 bg-emerald-500/10 p-3 text-[11px] text-emerald-200">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
            <span>
              {lang === "ar"
                ? "100% Offline-first بدون أي Firebase أو Tracking. المسؤولية على المستخدم في احترام حقوق النشر. لا يتجاوز DRM أو الحوائط المدفوعة."
                : "100% Offline-first with zero Firebase or tracking. Users are responsible for respecting copyright. DRM and paywalls are never bypassed."}
            </span>
          </div>
          <button
            type="button"
            onClick={() => setOnboardingOpen(false)}
            className="aurora-gradient-bg mt-5 w-full rounded-[22px] py-3.5 text-sm font-bold text-white shadow-lg shadow-sky-500/30"
          >
            {lang === "ar" ? "تشغيل 𝒥𝒪 DON" : "Launch 𝒥𝒪 DON"}
          </button>
        </motion.div>
      </div>
    </div>
  );

  // ──────────────────────────────────────────────────────────────────────────
  // Panels
  // ──────────────────────────────────────────────────────────────────────────
  function HomePanel() {
    return (
      <div className="space-y-4 px-4 pt-4">
        <div>
          <h1 className="aurora-gradient-text text-2xl font-extrabold tracking-tight">
            𝒥𝒪 DON
          </h1>
          <p className="text-[11px] opacity-70">
            {lang === "ar"
              ? "𝒥𝒪 DOW • محرك تحليل وتحميل فائق السرعة ومشغل متميّز"
              : "𝒥𝒪 DOW • Lightning download engine + premium media player"}
          </p>
        </div>

        <AnimatePresence>
          {clipboardUrl && clipboardDetect && (
            <motion.div
              initial={{ opacity: 0, y: -10, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.96 }}
              transition={{ type: "spring", stiffness: 320, damping: 26 }}
              className="aurora-glass-card aurora-gemini-glow flex items-center justify-between gap-2 rounded-[22px] px-3.5 py-2.5"
            >
              <button
                type="button"
                onClick={() => {
                  setUrlInput(clipboardUrl);
                  setClipboardUrl(null);
                  runAnalyze(clipboardUrl);
                }}
                className="flex min-w-0 flex-1 items-center gap-2 text-start"
              >
                <span className="aurora-gradient-bg flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-white">
                  <ClipboardPaste className="h-3.5 w-3.5" />
                </span>
                <div className="min-w-0">
                  <p className="text-[11px] font-bold text-sky-300">
                    {lang === "ar" ? "رابط مكتشف في الحافظة" : "Clipboard link detected"}
                  </p>
                  <p className="font-mono-aurora truncate text-[10px] opacity-70">
                    {clipboardUrl}
                  </p>
                </div>
              </button>
              <button
                type="button"
                onClick={() => setClipboardUrl(null)}
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-white/10"
              >
                <X className="h-3 w-3" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <div
          className={`aurora-glass-card rounded-[28px] p-4 transition-all ${
            analyzingStage > 0 || urlInput.trim() ? "aurora-gemini-glow" : ""
          }`}
          style={{ animationDuration: "var(--aurora-spin-speed)" }}
        >
          <div className="flex items-center gap-2">
            <input
              dir="ltr"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && runAnalyze(urlInput)}
              placeholder={
                lang === "ar"
                  ? "ألصق رابط فيديو، صوت، صورة، ملف، أو M3U8..."
                  : "Paste video, audio, image, file, or M3U8 URL..."
              }
              className={`w-full bg-transparent text-[11px] font-medium outline-none placeholder:opacity-60 ${
                darkMode ? "text-white placeholder:text-slate-400" : "text-slate-900"
              }`}
            />
            {urlInput && (
              <button
                type="button"
                onClick={() => {
                  setUrlInput("");
                  setAnalysis(null);
                }}
                className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white/10"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
          <div className="mt-3 flex items-center gap-2">
            <button
              type="button"
              onClick={() => runAnalyze(urlInput)}
              className="aurora-gradient-bg flex flex-1 items-center justify-center gap-1.5 rounded-[20px] py-2.5 text-xs font-bold text-white shadow-md shadow-sky-500/30"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>
                {analyzingStage > 0
                  ? lang === "ar"
                    ? `جارٍ التحليل (${analyzingStage}/3)...`
                    : `Analyzing (Stage ${analyzingStage}/3)...`
                  : lang === "ar"
                  ? "تحليل فوري"
                  : "Analyze Now"}
              </span>
            </button>
            <button
              type="button"
              onClick={async () => {
                try {
                  const txt = await navigator.clipboard.readText();
                  if (txt) {
                    setUrlInput(txt);
                    runAnalyze(txt);
                    return;
                  }
                } catch {}
                runAnalyze(clipboardUrl || "https://tiktok.com/@cybertokyo/video/7481920441");
              }}
              className="aurora-glass-card flex items-center gap-1.5 rounded-[20px] px-3.5 py-2.5 text-xs font-semibold"
            >
              <ClipboardPaste className="h-3.5 w-3.5 text-violet-400" />
              <span>{lang === "ar" ? "لصق" : "Paste"}</span>
            </button>
          </div>
        </div>

        {analyzingStage > 0 && (
          <div className="aurora-glass-card aurora-gemini-glow space-y-3 rounded-[28px] p-4">
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-semibold text-sky-300">
                {analyzingStage === 1
                  ? "Stage 0–1: Preconnect + HEAD / Range + Favicon"
                  : analyzingStage === 2
                  ? "Stage 2: Native Fast-Path"
                  : "Stage 3: yt-dlp + Exact Byte Probe"}
              </span>
              <RefreshCw className="h-3.5 w-3.5 animate-spin text-violet-400" />
            </div>
            <AuroraShimmerBox height={140} />
            <AuroraShimmerBox height={14} />
            <div className="flex gap-2">
              <AuroraShimmerBox height={34} className="flex-1" />
              <AuroraShimmerBox height={34} className="flex-1" />
            </div>
          </div>
        )}

        {analysis && analyzingStage === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 14, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ type: "spring", stiffness: 280, damping: 24 }}
            className="space-y-3"
          >
            <AuroraGlassSurface
              glowActive
              padding="16px"
              className="space-y-3"
              style={{
                boxShadow: `0 16px 40px -16px ${analysis.faviconBg}88`,
              }}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex min-w-0 items-center gap-2.5">
                  <div
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl text-[11px] font-extrabold text-white shadow-inner"
                    style={{ backgroundColor: analysis.faviconBg }}
                  >
                    {analysis.faviconText}
                  </div>
                  <div className="min-w-0">
                    <p className="truncate text-[11px] font-bold">{analysis.siteName}</p>
                    <p className="font-mono-aurora truncate text-[10px] opacity-65">
                      {analysis.domain} • {analysis.stageLatencyMs}ms
                    </p>
                  </div>
                </div>
                <span className="shrink-0 rounded-full bg-sky-500/20 px-2.5 py-1 text-[10px] font-bold text-sky-300">
                  {lang === "ar" ? analysis.primaryBadgeAr : analysis.primaryBadgeEn}
                </span>
              </div>

              {analysis.thumbnailUrl && (
                <button
                  type="button"
                  onClick={() =>
                    setActiveVideo({
                      id: "analyzed",
                      title: analysis.title,
                      channelName: analysis.author || analysis.siteName,
                      channelHandle: "@aurora",
                      channelAvatarGradient: `linear-gradient(135deg, ${analysis.faviconBg}, ${palette.mid})`,
                      thumbnailUrl: analysis.thumbnailUrl!,
                      durationSeconds: analysis.durationSeconds ?? 0,
                      viewsFormatted: "—",
                      publishedRelative: "",
                      verified: true,
                      isShort: false,
                      description: "",
                    })
                  }
                  className="group relative block w-full overflow-hidden rounded-[22px] border border-white/15"
                >
                  <img
                    src={analysis.thumbnailUrl}
                    alt={analysis.title}
                    className="h-44 w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/25 transition group-hover:bg-black/40">
                    <span className="aurora-glass-card flex h-12 w-12 items-center justify-center rounded-full text-white">
                      <Play className="h-5 w-5 fill-white" />
                    </span>
                  </div>
                </button>
              )}

              <h2 className="text-sm font-extrabold leading-snug">
                <StreamingText text={analysis.title} className="" />
              </h2>

              <input
                dir="ltr"
                value={editableName}
                onChange={(e) => setEditableName(e.target.value)}
                className={`font-mono-aurora w-full rounded-[16px] border px-3 py-2 text-[11px] outline-none ${
                  darkMode
                    ? "border-white/10 bg-black/30 text-slate-200 focus:border-sky-400/60"
                    : "border-slate-300/70 bg-white/70 text-slate-800"
                }`}
              />

              <div className="flex items-center justify-between rounded-[16px] bg-white/5 px-3 py-2 text-[11px]">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="font-mono-aurora font-bold text-emerald-400">
                    {formatFileSize(analysis.primarySize)}
                  </span>
                </div>
                <span className="font-mono-aurora text-[10px] opacity-60">
                  {analysis.primarySize.source}
                </span>
              </div>

              {analysis.drmBlockedReasonAr && (
                <div className="flex items-start gap-2.5 rounded-[20px] border border-rose-500/35 bg-rose-500/15 p-3 text-[11px] text-rose-200">
                  <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" />
                  <span>{lang === "ar" ? analysis.drmBlockedReasonAr : analysis.drmBlockedReasonEn}</span>
                </div>
              )}

              {analysis.requiresWebViewSniffer && (
                <button
                  type="button"
                  onClick={() => {
                    setBrowserUrl(analysis.normalizedUrl);
                    setActiveTab("browser");
                  }}
                  className="aurora-gradient-bg flex w-full items-center justify-center gap-2 rounded-[20px] py-3 text-xs font-bold text-white shadow-lg"
                >
                  <Globe className="h-4 w-4" />
                  <span>
                    {lang === "ar"
                      ? "افتح في المتصفح الداخلي لاصطياد الملفات (Cloudflare + Sniffer)"
                      : "Open Internal Sniffer Browser (Cloudflare + Media Sniffer)"}
                  </span>
                </button>
              )}
            </AuroraGlassSurface>

            {categories.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <span className="text-[11px] font-bold opacity-80">
                    {lang === "ar" ? "الأزرار الذكية (تظهر فقط للأنواع المتوفرة)" : "Smart Media Buttons (Available Types Only)"}
                  </span>
                  <span className="font-mono-aurora text-[10px] opacity-55">{categories.length}/4</span>
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  {categories.map(({ cat, items }, idx) => {
                    const icon =
                      cat === "AUDIO" ? Music2 : cat === "IMAGE" ? ImageIcon : cat === "VIDEO" ? Film : FileText;
                    const label =
                      cat === "AUDIO"
                        ? lang === "ar"
                          ? "صوت"
                          : "Audio"
                        : cat === "IMAGE"
                        ? lang === "ar"
                          ? "صور"
                          : "Images"
                        : cat === "VIDEO"
                        ? lang === "ar"
                          ? "فيديو"
                          : "Video"
                        : lang === "ar"
                        ? "ملفات"
                        : "Files";
                    const Icon = icon;
                    return (
                      <motion.button
                        key={`${analysis.normalizedUrl}-${cat}`}
                        type="button"
                        initial={{ opacity: 0, scale: 0.85, y: 8, filter: "blur(6px)" }}
                        animate={{ opacity: 1, scale: 1, y: 0, filter: "blur(0px)" }}
                        transition={{
                          type: "spring",
                          stiffness: 340,
                          damping: 22,
                          delay: idx * 0.06,
                        }}
                        whileTap={{ scale: 0.94 }}
                        onClick={() => setSheetCategory(cat)}
                        className="aurora-glass-card flex items-center justify-between rounded-[22px] bg-white/5 px-3.5 py-3 text-start"
                      >
                        <div className="flex items-center gap-2">
                          <Icon className="h-4 w-4" />
                          <span className="text-xs font-bold">{label}</span>
                        </div>
                        <span className="font-mono-aurora flex h-6 min-w-[24px] items-center justify-center rounded-full bg-white/20 px-1.5 text-[11px] font-extrabold">
                          {items.length}
                        </span>
                      </motion.button>
                    );
                  })}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </div>
    );
  }

  function DownloadsPanel() {
    const [tab, setTab] = useState<"ALL" | "ACTIVE" | "QUEUED" | "COMPLETED" | "FAILED">("ALL");
    const [wifiOnly, setWifiOnly] = useState(false);
    const filtered = useMemo(() => {
      return downloads.filter((d) => {
        if (tab === "ALL") return true;
        if (tab === "ACTIVE") return d.status === "DOWNLOADING";
        if (tab === "QUEUED") return d.status === "PAUSED" || d.status === "QUEUED";
        if (tab === "COMPLETED") return d.status === "COMPLETED";
        return d.status === "FAILED";
      });
    }, [downloads, tab]);
    const tabs: Array<{ k: typeof tab; ar: string; en: string }> = [
      { k: "ALL", ar: "الكل", en: "All" },
      { k: "ACTIVE", ar: "جارٍ", en: "Active" },
      { k: "QUEUED", ar: "الانتظار", en: "Queued" },
      { k: "COMPLETED", ar: "مكتمل", en: "Done" },
      { k: "FAILED", ar: "فاشل", en: "Failed" },
    ];
    return (
      <div className="space-y-4 px-4 pt-4">
        <div>
          <h1 className="aurora-gradient-text text-xl font-extrabold">
            {lang === "ar" ? "مدير التحميلات" : "Download Manager"}
          </h1>
          <p className="text-[11px] opacity-70">
            {lang === "ar"
              ? "8–32 جزء • Work-Stealing • HTTP/3 QUIC • ETag Resume"
              : "8–32 segments • Work-Stealing • HTTP/3 QUIC • ETag Resume"}
          </p>
        </div>
        <div className="no-scrollbar flex gap-1.5 overflow-x-auto">
          {tabs.map((t) => {
            const active = tab === t.k;
            return (
              <button
                key={t.k}
                type="button"
                onClick={() => setTab(t.k)}
                className={`shrink-0 rounded-full px-3.5 py-1.5 text-[11px] font-bold transition ${
                  active ? "aurora-gradient-bg text-white" : darkMode ? "bg-white/8 text-slate-300" : "bg-white/70 text-slate-600"
                }`}
              >
                {lang === "ar" ? t.ar : t.en}
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => setWifiOnly((w) => !w)}
            className={`shrink-0 rounded-full px-3 py-1.5 text-[11px] font-bold ${
              wifiOnly ? "bg-emerald-500/25 text-emerald-300" : darkMode ? "bg-white/8 text-slate-300" : "bg-slate-200/80 text-slate-700"
            }`}
          >
            Wi-Fi Only
          </button>
        </div>
        <div className="space-y-3">
          {filtered.length === 0 && (
            <div className="aurora-glass-card rounded-[26px] p-8 text-center">
              <Sparkles className="mx-auto mb-2 h-8 w-8 text-violet-400 opacity-75" />
              <p className="text-[11px] font-semibold opacity-75">
                {lang === "ar" ? "لا توجد تحميلات في هذا التبويب" : "No items in this tab yet"}
              </p>
            </div>
          )}
          {filtered.map((item) => {
            const pct = item.totalBytes > 0 ? Math.min(100, Math.round((item.downloadedBytes / item.totalBytes) * 100)) : 0;
            const isDownloading = item.status === "DOWNLOADING";
            return (
              <motion.div layout key={item.id} className={`aurora-glass-card space-y-2.5 rounded-[26px] p-4 ${isDownloading ? "aurora-gemini-glow" : ""}`}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[11px] font-extrabold">{item.fileName}</p>
                    <p className="mt-0.5 flex flex-wrap items-center gap-1.5 font-mono-aurora text-[10px] opacity-70">
                      <span>{item.siteName}</span>
                      <span>•</span>
                      <span className="text-sky-400">{item.maxConnections} {lang === "ar" ? "اتصال" : "segments"}</span>
                    </p>
                  </div>
                  {isDownloading ? (
                    <div className="text-end">
                      <p className="font-mono-aurora text-xs font-bold text-sky-400">{formatHumanBinary(item.speedBps)}/s</p>
                    </div>
                  ) : item.status === "COMPLETED" ? (
                    <span className="flex items-center gap-1 rounded-full bg-emerald-500/20 px-2.5 py-1 text-[10px] font-bold text-emerald-300">
                      <CheckCircle2 className="h-3 w-3" />
                      {lang === "ar" ? "مكتمل" : "Done"}
                    </span>
                  ) : (
                    <span className="rounded-full bg-amber-500/20 px-2.5 py-1 text-[10px] font-bold text-amber-300">
                      {lang === "ar" ? "متوقف" : "Paused"}
                    </span>
                  )}
                </div>
                <AuroraProgressGlowBar progress={pct / 100} />
                {isDownloading && item.speedHistory.length >= 2 && (
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[9px] opacity-75">
                      <span className="font-mono-aurora text-emerald-300">
                        <Zap className="inline h-3 w-3" />{" "}
                        {item.workStealing ? "Work-Stealing" : "FileChannel write"}
                      </span>
                      <span className="font-mono-aurora">{pct}%</span>
                    </div>
                    <div className="grid grid-cols-16 gap-0.5">
                      {Array.from({ length: 16 }).map((_, i) => (
                        <div
                          key={i}
                          className={`h-1.5 rounded-full ${i / 16 < pct / 100 ? "aurora-gradient-bg" : "bg-white/12"}`}
                        />
                      ))}
                    </div>
                    <AuroraSpeedSparkline samples={item.speedHistory} startColor={dynamicAccent || palette.start} endColor={palette.end} height={28} />
                  </div>
                )}
                <div className="flex items-center justify-between font-mono-aurora text-[10px] opacity-75">
                  <span>
                    {formatHumanBinary(item.downloadedBytes)} / {item.sizePrecision === "APPROXIMATE" ? "≈ " : ""}
                    {formatHumanBinary(item.totalBytes)}
                  </span>
                  <span>{pct}%</span>
                </div>
                <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5">
                  <div className="flex items-center gap-1.5">
                    {item.status !== "COMPLETED" ? (
                      <button
                        type="button"
                        onClick={() => toggleDlPause(item.id)}
                        className={`flex items-center gap-1 rounded-[14px] px-3 py-1.5 text-[11px] font-bold ${
                          isDownloading ? "bg-white/12" : "aurora-gradient-bg text-white"
                        }`}
                      >
                        {isDownloading ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                        <span>{isDownloading ? (lang === "ar" ? "إيقاف" : "Pause") : lang === "ar" ? "استكمال" : "Resume"}</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={sendToCompressor}
                        className="flex items-center gap-1 rounded-[14px] bg-emerald-500/20 px-3 py-1.5 text-[11px] font-bold text-emerald-300"
                      >
                        <Wand2 className="h-3.5 w-3.5" />
                        <span>{lang === "ar" ? "تصغير" : "Compress"}</span>
                      </button>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    <button onClick={() => reorderDl(item.id, 1)} className="flex h-7 w-7 items-center justify-center rounded-full bg-white/8 hover:bg-white/15">
                      <ArrowUp className="h-3.5 w-3.5" />
                    </button>
                    <button onClick={() => reorderDl(item.id, -1)} className="flex h-7 w-7 items-center justify-center rounded-full bg-white/8 hover:bg-white/15">
                      <ArrowDown className="h-3.5 w-3.5" />
                    </button>
                    <button onClick={() => deleteDl(item.id)} className="flex h-7 w-7 items-center justify-center rounded-full bg-rose-500/15 text-rose-300 hover:bg-rose-500/25">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    );
  }

  function DonYtPanel() {
    const [localTab, setLocalTab] = useState<DonYtTab>(donTab);
    useEffect(() => {
      if (activeVideo) return;
    }, [activeVideo]);
    const tabs: Array<{ k: DonYtTab; ar: string; en: string; icon: React.ComponentType<{ className?: string }> }> = [
      { k: "HOME", ar: "الرئيسية", en: "Home", icon: Home },
      { k: "SHORTS", ar: "Shorts", en: "Shorts", icon: Video },
      { k: "SUBS", ar: "اشتراكات", en: "Subs", icon: Bell },
      { k: "LIBRARY", ar: "ملفي", en: "You", icon: User },
      { k: "PLAYER", ar: "المشغل", en: "Player", icon: Play },
    ];
    return (
      <div className="space-y-3 px-3 pt-3">
        {/* DON Top Search */}
        <AuroraGlassSurface padding="10px" shape="rounded-[24px]" className="space-y-2.5">
          <div className="flex items-center gap-2">
            <h2 className="aurora-gradient-text text-base font-extrabold">𝒥𝒪 YouTube</h2>
          </div>
          <div className="relative">
            <Search className="absolute top-2.5 start-3 h-3.5 w-3.5 opacity-55" />
            <input
              dir="ltr"
              value={donQuery}
              onChange={(e) => setDonQuery(e.target.value)}
              placeholder={lang === "ar" ? "بحث في 𝒥𝒪 DON..." : "Search 𝒥𝒪 DON..."}
              className={`w-full rounded-[18px] py-2 pe-3 ps-9 text-[11px] outline-none ${
                darkMode ? "bg-black/35 text-white placeholder:text-slate-400" : "bg-white/80 text-slate-900"
              }`}
            />
          </div>
          {donSuggestions.length > 0 && donQuery && (
            <div className="space-y-0.5">
              {donSuggestions.slice(0, 5).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setDonQuery(s)}
                  className="flex w-full items-center gap-2 rounded-[12px] px-2 py-1.5 text-start text-[10.5px] hover:bg-white/10"
                >
                  <Search className="h-3 w-3 opacity-60" />
                  <span className="truncate">{s}</span>
                </button>
              ))}
            </div>
          )}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {tabs.map((t) => {
              const Icon = t.icon;
              const active = localTab === t.k;
              return (
                <button
                  key={t.k}
                  type="button"
                  onClick={() => setLocalTab(t.k)}
                  className={`flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1.5 text-[10px] font-bold ${
                    active ? "aurora-gradient-bg text-white" : "bg-white/8"
                  }`}
                >
                  <Icon className="h-3 w-3" />
                  <span>{lang === "ar" ? t.ar : t.en}</span>
                </button>
              );
            })}
          </div>
        </AuroraGlassSurface>

        {localTab === "HOME" && <DonHome videos={donSearchResults ?? donHome} onOpen={(v) => setActiveVideo(v)} />}
        {localTab === "SHORTS" && <DonShortsGrid onOpen={(v) => setActiveVideo(v)} />}
        {localTab === "SUBS" && <DonSubsPanel onOpen={(v) => setActiveVideo(v)} onToggleFollow={toggleFollowChannel} />}
        {localTab === "LIBRARY" && <DonLocalPanel />}
        {localTab === "PLAYER" && (
          <DonPlayerPreviewOnly onOpen={() => setActiveVideo(donHome[0])} />
        )}
      </div>
    );
  }

  function DonHome({ videos, onOpen }: { videos: DonVideo[]; onOpen: (v: DonVideo) => void }) {
    return (
      <div className="space-y-3">
        {videos.map((v) => (
          <DonVideoCard key={v.id} video={v} onOpen={() => onOpen(v)} />
        ))}
      </div>
    );
  }
  function DonVideoCard({ video, onOpen }: { video: DonVideo; onOpen: () => void }) {
    return (
      <div className="space-y-2 px-1">
        <button type="button" onClick={onOpen} className="relative block w-full overflow-hidden rounded-[22px]">
          <img src={video.thumbnailUrl} alt={video.title} className="aspect-video w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <span className="absolute bottom-2 end-2 rounded-md bg-black/80 px-1.5 py-0.5 font-mono-aurora text-[9px] font-bold text-white">
            {video.isLive ? "LIVE" : formatDuration(video.durationSeconds)}
          </span>
        </button>
        <div className="flex items-start gap-2 px-0.5">
          <div
            className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[10px] font-extrabold text-white"
            style={{ background: video.channelAvatarGradient }}
          >
            {video.channelName.slice(0, 2).toUpperCase()}
          </div>
          <div className="min-w-0 flex-1">
            <p className="line-clamp-2 text-[11.5px] font-extrabold leading-snug">{video.title}</p>
            <p className="mt-0.5 text-[10px] opacity-70">
              {video.channelName} • {video.viewsFormatted} views • {video.publishedRelative}
            </p>
            <div className="mt-1 flex gap-1.5">
              <button
                type="button"
                onClick={() => {
                  const fmt: MediaFormat = {
                    id: "don-" + video.id,
                    category: "VIDEO",
                    title: video.title,
                    qualityLabel: video.isShort ? "1080p Short" : "1080p",
                    extension: "MP4",
                    codec: "H.264 + AAC",
                    fps: 60,
                    size: {
                      bytes: Math.round((video.durationSeconds || 300) * 420_000),
                      precision: "APPROXIMATE",
                      source: "yt-dlp approx",
                    },
                  };
                  startDownload(fmt, video.title);
                }}
                className="aurora-gradient-bg flex items-center gap-1 rounded-[12px] px-2 py-1 text-[10px] font-bold text-white"
              >
                <Download className="h-3 w-3" />
                <span>{lang === "ar" ? "تحميل" : "Download"}</span>
              </button>
              <button
                type="button"
                onClick={onOpen}
                className="flex items-center gap-1 rounded-[12px] bg-white/10 px-2 py-1 text-[10px] font-bold"
              >
                <Play className="h-3 w-3" />
                <span>{lang === "ar" ? "تشغيل" : "Play"}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
  function DonShortsGrid({ onOpen }: { onOpen: (v: DonVideo) => void }) {
    const shorts = donShorts.filter((v) => v.isShort);
    return (
      <div className="grid grid-cols-2 gap-2 px-0.5">
        {shorts.map((v) => (
          <button
            key={v.id}
            type="button"
            onClick={() => onOpen(v)}
            className="group relative overflow-hidden rounded-[22px]"
          >
            <img src={v.thumbnailUrl} alt={v.title} className="aspect-[9/16] w-full object-cover transition-transform duration-500 group-hover:scale-105" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent" />
            <div className="absolute inset-x-2 bottom-2">
              <p className="line-clamp-2 text-[10px] font-bold text-white">{v.title}</p>
              <p className="font-mono-aurora text-[9px] text-white/70">{v.viewsFormatted}</p>
            </div>
          </button>
        ))}
      </div>
    );
  }
  function DonSubsPanel({ onOpen, onToggleFollow }: { onOpen: (v: DonVideo) => void; onToggleFollow: (id: string) => void }) {
    return (
      <div className="space-y-3">
        <div className="no-scrollbar flex gap-3 overflow-x-auto px-0.5">
          {donChannels.map((ch) => (
            <button
              key={ch.id}
              type="button"
              onClick={() => onToggleFollow(ch.id)}
              className="shrink-0 text-center"
            >
              <div
                className="flex h-14 w-14 items-center justify-center rounded-full text-[12px] font-extrabold text-white ring-2"
                style={{
                  background: ch.avatarGradient,
                  borderColor: ch.followed ? palette.start : "transparent",
                  boxShadow: ch.followed ? "0 0 18px rgba(66,133,244,0.45)" : undefined,
                }}
              >
                {ch.name.slice(0, 2).toUpperCase()}
              </div>
              <p className="mt-1 max-w-[64px] truncate text-[9.5px] font-bold">{ch.name}</p>
              <p className="font-mono-aurora text-[9px] opacity-65">{ch.subsCount}</p>
            </button>
          ))}
        </div>
        {donSubFeed.length === 0 ? (
          <AuroraGlassSurface padding="16px" className="text-center">
            <Plus className="mx-auto mb-1 h-6 w-6 opacity-70" />
            <p className="text-[11px] opacity-75">
              {lang === "ar" ? "تابع قنوات محليًا من الأعلى لتظهر هنا" : "Follow channels locally above to populate this feed"}
            </p>
          </AuroraGlassSurface>
        ) : (
          <div className="space-y-3">
            {donSubFeed.map((v) => (
              <DonVideoCard key={v.id} video={v} onOpen={() => onOpen(v)} />
            ))}
          </div>
        )}
      </div>
    );
  }
  function DonLocalPanel() {
    return (
      <div className="space-y-3">
        <AuroraGlassSurface padding="16px" className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="aurora-gradient-bg flex h-14 w-14 items-center justify-center rounded-full text-white">
              <Fingerprint className="h-6 w-6" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-extrabold">{donProfile.displayName}</p>
              <p className="text-[10px] opacity-70">{donProfile.bio}</p>
              <div className="mt-1 flex gap-2 font-mono-aurora text-[9.5px]">
                <span className="rounded-full bg-white/10 px-2 py-0.5">{donProfile.followingCount} following</span>
                <span className="rounded-full bg-white/10 px-2 py-0.5">{donProfile.totalWatched} watched</span>
                <span className="rounded-full bg-white/10 px-2 py-0.5">{donProfile.totalDownloads} downloads</span>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <button className="aurora-glass-card flex-1 rounded-[14px] py-2 text-[11px] font-bold">
              {lang === "ar" ? "تصدير JSON" : "Export JSON"}
            </button>
            <button className="aurora-gradient-bg flex-1 rounded-[14px] py-2 text-[11px] font-bold text-white">
              {lang === "ar" ? "استيراد" : "Import"}
            </button>
          </div>
        </AuroraGlassSurface>
        <AuroraGlassSurface padding="12px" className="space-y-1.5">
          <p className="text-[11px] font-extrabold">{lang === "ar" ? "سجل المشاهدات" : "Watch History"}</p>
          {donHistory.map((h) => (
            <div key={h} className="flex items-center gap-2 rounded-[12px] bg-white/5 px-2 py-1.5">
              <Sliders className="h-3 w-3 opacity-60" />
              <span className="truncate text-[10.5px]">{h}</span>
            </div>
          ))}
        </AuroraGlassSurface>
      </div>
    );
  }
  function DonPlayerPreviewOnly({ onOpen }: { onOpen: () => void }) {
    return (
      <AuroraGlassSurface padding="18px" className="space-y-3 text-center">
        <Play className="mx-auto h-10 w-10 opacity-80" />
        <p className="text-[11px] opacity-80">
          {lang === "ar"
            ? "افتح أي فيديو لاستخدام المشغل المحلي الفاخر (مؤقت نوم، تكرار، قص بصري يدوي، تشغيل كصوت، نغمة رنين...)"
            : "Open any video for the premium local player (sleep timer, repeat, manual trim handles, audio-only, ringtone, etc.)"}
        </p>
        <button
          type="button"
          onClick={onOpen}
          className="aurora-gradient-bg w-full rounded-[18px] py-2.5 text-[11px] font-bold text-white"
        >
          {lang === "ar" ? "تشغيل عينة" : "Open Sample"}
        </button>
      </AuroraGlassSurface>
    );
  }

  function BrowserPanel() {
    return (
      <div className="flex h-full flex-col gap-3 px-4 pt-4">
        <AuroraGlassSurface padding="10px" shape="rounded-[24px]" className="space-y-2.5">
          <div className="flex items-center gap-2">
            <input
              dir="ltr"
              value={browserUrl}
              onChange={(e) => setBrowserUrl(e.target.value)}
              className={`font-mono-aurora flex-1 rounded-[14px] px-3 py-2 text-[10.5px] outline-none ${
                darkMode ? "bg-black/35 text-white" : "bg-white/80 text-slate-900"
              }`}
            />
            <button className="flex h-8 w-8 items-center justify-center rounded-full bg-white/10">
              <RefreshCw className="h-3.5 w-3.5" />
            </button>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-1.5 text-[10px]">
            <div className="flex items-center gap-1">
              <button className="rounded-full bg-white/8 p-1.5">→</button>
              <button className="rounded-full bg-white/8 p-1.5">←</button>
              <button
                onClick={() => setDesktopMode((v) => !v)}
                className={`rounded-full px-2 py-1 font-semibold ${desktopMode ? "bg-sky-500/25 text-sky-300" : "bg-white/8 opacity-75"}`}
              >
                {desktopMode ? "Desktop" : "Mobile"}
              </button>
              <button
                onClick={() => setPrivateMode((v) => !v)}
                className={`rounded-full px-2 py-1 font-semibold ${privateMode ? "bg-violet-500/25 text-violet-300" : "bg-white/8 opacity-75"}`}
              >
                {lang === "ar" ? "خاص" : "Private"}
              </button>
            </div>
            <button
              onClick={() => setBlockedCount((c) => c + 3)}
              className={`flex items-center gap-1 rounded-full px-2 py-1 font-bold ${
                adBlockEnabled ? "bg-emerald-500/20 text-emerald-300" : "bg-rose-500/20 text-rose-300"
              }`}
            >
              <ShieldCheck className="h-3 w-3" />
              <span>{blockedCount}</span>
            </button>
          </div>
        </AuroraGlassSurface>

        <div className="flex items-center justify-between rounded-[18px] bg-black/30 px-3 py-2 text-[10.5px]">
          <div className="flex items-center gap-2">
            <Lock className="h-3.5 w-3.5 text-amber-400" />
            <span className="font-bold">
              {cfSynced ? (lang === "ar" ? "cf_clearance متزامن مع CookieJar" : "cf_clearance synced to CookieJar") : "Solving JS Challenge..."}
            </span>
          </div>
          <button onClick={() => setCfSynced((v) => !v)} className="rounded-full bg-emerald-500/20 px-2 py-0.5 font-bold text-emerald-300">
            {cfSynced ? "OK" : "Retry"}
          </button>
        </div>

        <AuroraGlassSurface padding="0" shape="rounded-[26px]" className="relative flex-1 overflow-hidden">
          <div className="relative">
            <img src="/images/aurora-thumb-yt.png" alt="WebView" className="h-40 w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent" />
            <span className="absolute bottom-2 end-2 flex items-center gap-1 rounded-full bg-black/75 px-2 py-0.5 font-mono-aurora text-[9px] text-emerald-300 backdrop-blur-md">
              <Radar className="h-3 w-3 animate-pulse" />
              HLS .m3u8 intercepted
            </span>
          </div>
          <div className="space-y-2 p-3 text-[10.5px]">
            <div className="rounded-[14px] border border-dashed border-emerald-400/30 bg-emerald-500/10 p-2 text-emerald-300">
              {adBlockEnabled
                ? lang === "ar"
                  ? "تم إخفاء زر تحميل وهمي + 4 Popunders عبر Cosmetic Filtering"
                  : "Stripped 1 fake download overlay + 4 popunders via Cosmetic Filters"
                : lang === "ar"
                ? "أنت تمكنت من رؤية عناصر Ads Overlays لأن AdBlock متوقف"
                : "AdBlock disabled — fake overlays visible"}
            </div>
          </div>
          <button
            type="button"
            onClick={() => setSniffedOpen(true)}
            className="aurora-gradient-bg aurora-gemini-glow absolute bottom-4 end-4 flex items-center gap-2 rounded-full px-4 py-2.5 text-[10px] font-extrabold text-white shadow-xl"
          >
            <Download className="h-3.5 w-3.5" />
            {lang === "ar" ? "ملفات مصطادة" : "Sniffed"}
            <span className="font-mono-aurora flex h-4 min-w-[16px] items-center justify-center rounded-full bg-white/25 px-1 text-[10px]">{sniffedResources.length}</span>
          </button>
        </AuroraGlassSurface>
      </div>
    );
  }

  function ToolsPanel() {
    return toolsSubTab === "compressor" ? <CompressorPanel /> : <ConverterPanel />;
  }
  function CompressorPanel() {
    const [mode, setMode] = useState<"lossless" | "transparent">("transparent");
    const [sliderPos, setSliderPos] = useState(52);
    const origBytes = 148_372_910;
    const outBytes = mode === "lossless" ? 124_633_244 : 84_572_558;
    const saved = origBytes - outBytes;
    const pct = ((saved / origBytes) * 100).toFixed(1);
    return (
      <div className="space-y-3 px-4 pt-4">
        <AuroraGlassSurface padding="10px" shape="rounded-[24px]" className="grid grid-cols-2 gap-1.5 p-1.5">
          <button onClick={() => setToolsSubTab("compressor")} className={`rounded-[18px] py-2 text-[11px] font-bold ${toolsSubTab === "compressor" ? "aurora-gradient-bg text-white" : "opacity-70"}`}>
            {lang === "ar" ? "التصغير الذكي" : "Smart Compressor"}
          </button>
          <button onClick={() => setToolsSubTab("converter")} className={`rounded-[18px] py-2 text-[11px] font-bold ${toolsSubTab === "converter" ? "aurora-gradient-bg text-white" : "opacity-70"}`}>
            {lang === "ar" ? "المحوّل" : "Converter"}
          </button>
        </AuroraGlassSurface>
        <AuroraGlassSurface padding="16px" className="space-y-3">
          <p className="text-[11px] font-bold">
            {lang === "ar" ? "ملف مختار للتصغير" : "Selected File"}
          </p>
          <p className="font-mono-aurora truncate text-[10px] opacity-70">Iceland_Aurora_Borealis_1080p60_HDR.mp4</p>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setMode("lossless")}
              className={`rounded-[20px] border p-3 text-start transition ${
                mode === "lossless" ? "border-emerald-400/60 bg-emerald-500/20" : "border-white/10 bg-white/5 opacity-75"
              }`}
            >
              <p className="text-xs font-extrabold">🟢 {lang === "ar" ? "Lossless" : "Lossless"}</p>
              <p className="mt-0.5 text-[10px] opacity-75">mozjpeg / oxipng / zopfli / FLAC</p>
            </button>
            <button
              onClick={() => setMode("transparent")}
              className={`rounded-[20px] border p-3 text-start transition ${
                mode === "transparent" ? "border-amber-400/60 bg-amber-500/20" : "border-white/10 bg-white/5 opacity-75"
              }`}
            >
              <p className="text-xs font-extrabold">🟡 {lang === "ar" ? "شفاف بصريًا" : "Transparent"}</p>
              <p className="mt-0.5 text-[10px] opacity-75">HEVC/AV1 • SSIM 98.4%</p>
            </button>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[10px] opacity-75">
              <span>{lang === "ar" ? "Before / After سلايدر" : "Before / After Slider"}</span>
              <span className="font-mono-aurora">{sliderPos}%</span>
            </div>
            <div className="relative h-40 overflow-hidden rounded-[22px] border border-white/15 select-none">
              <img src="/images/aurora-thumb-yt.png" alt="after" className="absolute inset-0 h-full w-full object-cover" />
              <div className="absolute inset-y-0 start-0 overflow-hidden" style={{ width: `${sliderPos}%` }}>
                <img src="/images/aurora-thumb-yt.png" alt="before" className="h-full w-[360px] max-w-none object-cover brightness-110 contrast-105" />
              </div>
              <div className="pointer-events-none absolute inset-y-0 w-0.5 bg-white shadow-[0_0_12px_#fff]" style={{ insetInlineStart: `${sliderPos}%` }} />
              <span className="absolute start-2.5 top-2.5 rounded-full bg-black/70 px-2 py-0.5 font-mono-aurora text-[9px] font-bold text-white">
                BEFORE • {formatHumanBinary(origBytes)}
              </span>
              <span className="absolute end-2.5 top-2.5 rounded-full bg-emerald-600/90 px-2 py-0.5 font-mono-aurora text-[9px] font-bold text-white">
                AFTER • {formatHumanBinary(outBytes)}
              </span>
              <input
                type="range"
                min={8}
                max={92}
                value={sliderPos}
                onChange={(e) => setSliderPos(Number(e.target.value))}
                aria-label="Before / After slider"
                className="absolute inset-0 h-full w-full cursor-ew-resize opacity-0"
              />
            </div>
          </div>
          <div className="rounded-[20px] border border-emerald-400/30 bg-emerald-500/12 p-3">
            <div className="flex items-center justify-between text-xs font-extrabold text-emerald-300">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4" /> {lang === "ar" ? `توفير ${pct}%` : `Saved ${pct}%`}
              </span>
              <span className="font-mono-aurora">-{formatHumanBinary(saved)}</span>
            </div>
            <p className="font-mono-aurora mt-1 text-[10px] opacity-80">
              {new Intl.NumberFormat("en-US").format(origBytes)} B → {new Intl.NumberFormat("en-US").format(outBytes)} B
            </p>
          </div>
          <button className="aurora-gradient-bg w-full rounded-[20px] py-3 text-xs font-bold text-white">
            {lang === "ar" ? "ضغط كملف جديد" : "Compress (New File)"}
          </button>
        </AuroraGlassSurface>
      </div>
    );
  }
  function ConverterPanel() {
    const [target, setTarget] = useState("OPUS");
    const [bitrate, setBitrate] = useState(256);
    const [streamCopy, setStreamCopy] = useState(true);
    const [converting, setConverting] = useState(false);
    const [msg, setMsg] = useState<string | null>(null);
    return (
      <div className="space-y-3 px-4 pt-4">
        <AuroraGlassSurface padding="16px" className="space-y-4">
          <p className="text-xs font-extrabold">
            {lang === "ar" ? "استخراج وتحويل الصيغ" : "Format Extraction & Conversion"}
          </p>
          {[
            { labelAr: "صوت (Stream Copy)", labelEn: "Audio", items: ["MP3", "M4A", "OPUS", "FLAC", "WAV"] },
            { labelAr: "فيديو + GIF", labelEn: "Video", items: ["MP4", "MKV", "WEBM", "MOV", "GIF"] },
            { labelAr: "صور", labelEn: "Images", items: ["JPG", "PNG", "WEBP", "AVIF"] },
          ].map((g) => (
            <div key={g.labelEn} className="space-y-2">
              <p className="text-[11px] font-bold opacity-80">{lang === "ar" ? g.labelAr : g.labelEn}</p>
              <div className="flex flex-wrap gap-1.5">
                {g.items.map((fmt) => (
                  <button
                    key={fmt}
                    onClick={() => setTarget(fmt)}
                    className={`rounded-full px-3 py-1.5 font-mono-aurora text-[10px] font-bold ${
                      target === fmt ? "aurora-gradient-bg text-white" : darkMode ? "bg-white/10 text-slate-300" : "bg-slate-200 text-slate-700"
                    }`}
                  >
                    {fmt}
                  </button>
                ))}
              </div>
            </div>
          ))}
          <div className="flex items-center justify-between rounded-[18px] bg-white/5 px-3 py-2.5 text-[11px]">
            <span>{lang === "ar" ? "Stream Copy (بدون إعادة ترميز)" : "Stream Copy"}</span>
            <button
              onClick={() => setStreamCopy((s) => !s)}
              className={`rounded-full px-3 py-1 text-[10px] font-bold ${streamCopy ? "bg-emerald-500/25 text-emerald-300" : "bg-white/10 opacity-70"}`}
            >
              {streamCopy ? "ON" : "OFF"}
            </button>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between font-mono-aurora text-[10px] opacity-75">
              <span>Bitrate</span>
              <span>{bitrate} kbps</span>
            </div>
            <input type="range" min={96} max={512} step={32} value={bitrate} onChange={(e) => setBitrate(Number(e.target.value))} className="w-full accent-violet-400" />
          </div>
          {msg && (
            <div className="flex items-center gap-2 rounded-[16px] bg-emerald-500/15 px-3 py-2 text-[11px] text-emerald-300">
              <Check className="h-4 w-4" />
              <span>{msg}</span>
            </div>
          )}
          <button
            type="button"
            onClick={() => {
              setConverting(true);
              setMsg(null);
              setTimeout(() => {
                setConverting(false);
                setMsg(
                  lang === "ar"
                    ? `تم التحويل إلى ${target} (${bitrate} kbps) بنجاح عبر FFmpeg`
                    : `Converted to ${target} (${bitrate} kbps) via FFmpeg`
                );
              }, 800);
            }}
            className="aurora-gradient-bg w-full rounded-[20px] py-3 text-[11px] font-bold text-white"
          >
            {converting ? (lang === "ar" ? "جارٍ المعالجة..." : "Processing...") : lang === "ar" ? `تحويل إلى ${target}` : `Convert to ${target}`}
          </button>
        </AuroraGlassSurface>
      </div>
    );
  }

  function LibraryPanel() {
    return (
      <div className="space-y-3 px-4 pt-4">
        <div>
          <h1 className="aurora-gradient-text text-xl font-extrabold">
            {lang === "ar" ? "المكتبة والمشغل المحلي" : "Local Library & Player"}
          </h1>
          <p className="text-[11px] opacity-70">
            {lang === "ar"
              ? "مشغل 𝒥𝒪 DON المحلي الفاخر مع مؤقت النوم، القص اليدوي، نغمة الرنين، والمؤثرات البصرية"
              : "Premium local player with sleep timer, manual trim, ringtone, and visual effects"}
          </p>
        </div>
        <div className="space-y-2.5">
          {downloads.filter((d) => d.status === "COMPLETED").map((d) => (
            <AuroraGlassSurface key={d.id} padding="12px" className="space-y-2">
              <div className="flex items-center gap-3">
                <div className="h-14 w-14 overflow-hidden rounded-[16px] bg-white/10">
                  {d.thumbnailUrl ? (
                    <img src={d.thumbnailUrl} alt={d.fileName} className="h-full w-full object-cover" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center">
                      {d.category === "AUDIO" ? <Music2 className="h-6 w-6 opacity-70" /> : <Film className="h-6 w-6 opacity-70" />}
                    </div>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[11px] font-extrabold">{d.fileName}</p>
                  <p className="font-mono-aurora text-[10px] opacity-70">
                    {d.category} • {formatHumanBinary(d.totalBytes)}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() =>
                    setActiveVideo({
                      id: d.id,
                      title: d.fileName,
                      channelName: "𝒥𝒪 Library",
                      channelHandle: "@library",
                      channelAvatarGradient: `linear-gradient(135deg,${palette.start},${palette.mid})`,
                      thumbnailUrl: d.thumbnailUrl || "/images/aurora-thumb-audio.png",
                      durationSeconds: Math.round(d.totalBytes / 420_000),
                      viewsFormatted: "—",
                      publishedRelative: "—",
                      verified: true,
                      isShort: false,
                    })
                  }
                  className="aurora-gradient-bg flex flex-1 items-center justify-center gap-1 rounded-[14px] py-2 text-[10px] font-bold text-white"
                >
                  <Play className="h-3 w-3" />
                  {lang === "ar" ? "تشغيل بالمشغل" : "Play in Player"}
                </button>
                <button className="aurora-glass-card rounded-[14px] px-3 py-2 text-[10px] font-bold">
                  {lang === "ar" ? "قص" : "Trim"}
                </button>
              </div>
            </AuroraGlassSurface>
          ))}
        </div>
      </div>
    );
  }

  function SettingsPanel() {
    if (settingsScreen === "themes") return <ThemesPanel onBack={() => setSettingsScreen("main")} />;
    return (
      <div className="space-y-3 px-4 pt-4">
        <h1 className="aurora-gradient-text text-xl font-extrabold">
          {lang === "ar" ? "الإعدادات" : "Settings"}
        </h1>
        <AuroraGlassSurface padding="14px" className="space-y-2.5">
          <button
            type="button"
            onClick={() => setSettingsScreen("themes")}
            className="flex w-full items-center justify-between rounded-[18px] bg-white/5 px-3 py-2.5 text-[11px] font-bold"
          >
            <span>{lang === "ar" ? "الثيمات (6 مع معاينات)" : "Themes (6 with previews)"}</span>
            <span className="font-mono-aurora opacity-70">{theme}</span>
          </button>
          <Toggle label={lang === "ar" ? "وضع AMOLED داكن" : "AMOLED Dark"} value={amoled} onChange={setAmoled} />
          <Toggle label={lang === "ar" ? "تلوين ديناميكي من الغلاف" : "Dynamic Cover Tint"} value={dynamicTint} onChange={setDynamicTint} />
          <Toggle label={lang === "ar" ? "اكتشاف الحافظة" : "Clipboard Detect"} value={clipboardDetect} onChange={setClipboardDetect} />
          <Toggle label={lang === "ar" ? "DNS-over-HTTPS" : "DNS-over-HTTPS"} value={dohEnabled} onChange={setDohEnabled} />
          <Toggle label={lang === "ar" ? "حجب الإعلانات" : "AdBlock Engine"} value={adBlockEnabled} onChange={setAdBlockEnabled} />
          <Toggle
            label={lang === "ar" ? "افتراضي: صوت فقط" : "Default: Audio Only"}
            value={audioOnlyDefault}
            onChange={setAudioOnlyDefault}
          />
          <div className="space-y-1 pt-1">
            <div className="flex justify-between font-mono-aurora text-[10px] opacity-75">
              <span>{lang === "ar" ? "الاتصالات الافتراضية" : "Default Segments"}</span>
              <span>{defaultSegments}</span>
            </div>
            <input
              type="range"
              min={8}
              max={32}
              step={4}
              value={defaultSegments}
              onChange={(e) => setDefaultSegments(Number(e.target.value))}
              className="w-full accent-sky-400"
            />
          </div>
        </AuroraGlassSurface>
        <AuroraGlassSurface padding="14px" className="space-y-2">
          <p className="text-xs font-extrabold">{lang === "ar" ? "الخصوصية" : "Privacy & Legal"}</p>
          <div className="flex items-start gap-2 rounded-[16px] bg-black/25 p-2.5 text-[10.5px] leading-relaxed text-emerald-200">
            <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
            <span>
              {lang === "ar"
                ? "Offline-first بدون أي Firebase أو تتبع. المسؤولية على المستخدم في احترام حقوق النشر. لا يتجاوز DRM أو Paywalls."
                : "100% Offline-first with zero Firebase/tracking. Users are responsible for copyright. DRM and paywalls are never bypassed."}
            </span>
          </div>
          <button
            type="button"
            onClick={() => setOnboardingOpen(true)}
            className="aurora-glass-card w-full rounded-[16px] py-2 text-[11px] font-bold"
          >
            {lang === "ar" ? "إعادة عرض المقدمة" : "Replay Onboarding"}
          </button>
        </AuroraGlassSurface>
      </div>
    );
  }
  function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
    return (
      <button
        type="button"
        onClick={() => onChange(!value)}
        className="flex w-full items-center justify-between rounded-[18px] px-3 py-2 text-[11px] font-bold hover:bg-white/5"
      >
        <span>{label}</span>
        <span
          className={`relative inline-flex h-5 w-10 items-center rounded-full transition ${
            value ? "aurora-gradient-bg" : darkMode ? "bg-white/15" : "bg-slate-300"
          }`}
        >
          <motion.span
            animate={{ x: value ? 18 : 2 }}
            transition={{ type: "spring", stiffness: 500, damping: 30 }}
            className="inline-block h-4 w-4 rounded-full bg-white shadow"
          />
        </span>
      </button>
    );
  }

  function ThemesPanel({ onBack }: { onBack: () => void }) {
    return (
      <div className="space-y-3 px-4 pt-4">
        <div className="flex items-center justify-between">
          <h1 className="aurora-gradient-text text-lg font-extrabold">
            {lang === "ar" ? "ثيمات 𝒥𝒪 DON الستة" : "All 6 𝒥𝒪 DON Themes"}
          </h1>
          <button type="button" onClick={onBack} className="aurora-glass-card rounded-full px-3 py-1.5 text-[10px] font-bold">
            {lang === "ar" ? "رجوع" : "Back"}
          </button>
        </div>
        <div className="space-y-3">
          {DON_THEMES.map((t) => {
            const active = t.key === theme;
            return (
              <button
                key={t.key}
                type="button"
                onClick={() => setTheme(t.key)}
                className={`aurora-glass-card w-full rounded-[24px] p-2 text-start transition ${
                  active ? "aurora-gemini-glow" : ""
                }`}
                style={active ? { borderColor: t.start } : undefined}
              >
                <div className="flex gap-3">
                  <img
                    src={t.previewImage}
                    alt={t.nameEn}
                    className="h-24 w-32 shrink-0 rounded-[18px] object-cover"
                  />
                  <div className="min-w-0 flex-1 space-y-1.5 py-1">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-extrabold">
                        {lang === "ar" ? t.nameAr : t.nameEn}
                      </p>
                      {active && (
                        <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[9px] font-bold text-emerald-300">
                          ACTIVE
                        </span>
                      )}
                    </div>
                    <div className="h-3 w-full rounded-full" style={{ background: `linear-gradient(120deg, ${t.start}, ${t.mid}, ${t.end})` }} />
                    <p className="text-[10px] leading-snug opacity-75">
                      {lang === "ar" ? t.descriptionAr : t.descriptionEn}
                    </p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Premium 𝒥𝒪 DON Player Modal
  // ──────────────────────────────────────────────────────────────────────────
  function PremiumPlayerModal() {
    if (!activeVideo) return null;
    return (
      <div className="absolute inset-0 z-50 flex flex-col justify-between bg-black/95 p-3 text-white backdrop-blur-xl">
        <div className="flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => setActiveVideo(null)}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10"
          >
            <X className="h-4 w-4" />
          </button>
          <div className="min-w-0 flex-1 text-center">
            <p className="truncate text-[11px] font-extrabold">{activeVideo.title}</p>
            <p className="font-mono-aurora text-[9px] text-sky-300">𝒥𝒪 DON Local Player • Media3 ExoPlayer</p>
          </div>
          <button
            type="button"
            onClick={() => setPip((v) => !v)}
            className={`flex items-center gap-1 rounded-full px-2.5 py-1.5 text-[10px] font-bold ${pip ? "aurora-gradient-bg text-white" : "bg-white/10 text-slate-200"}`}
          >
            <PictureInPicture2 className="h-3 w-3" />
            PiP
          </button>
        </div>

        <div className="space-y-3">
          <div className={`overflow-hidden rounded-[26px] border border-white/10 transition-all ${pip ? "h-40" : "h-56"}`}>
            <img
              src={activeVideo.thumbnailUrl}
              alt={activeVideo.title}
              className="h-full w-full object-cover"
            />
            {subtitlesOn && !audioOnly && (
              <div className="mx-3 -mt-10 rounded-xl bg-black/75 px-3 py-1.5 text-center text-[10px] backdrop-blur-md">
                {lang === "ar"
                  ? "ترجمة عربية مضمّنة • Media3 SubtitleView"
                  : "Arabic subtitles embedded • Media3 SubtitleView"}
              </div>
            )}
          </div>

          {/* Draggable visual trimmer + waveform visualizer */}
          <AuroraGlassSurface padding="12px" shape="rounded-[20px]" className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-[11px] font-extrabold">
                {trimEditing ? (lang === "ar" ? "قص يدوي مرئي" : "Visual Manual Trim") : lang === "ar" ? "المخطط الموجي" : "Waveform"}
              </p>
              <button
                type="button"
                onClick={() => setTrimEditing((v) => !v)}
                className={`rounded-full px-2.5 py-0.5 text-[9px] font-bold ${trimEditing ? "aurora-gradient-bg text-white" : "bg-white/10"}`}
              >
                {trimEditing ? (lang === "ar" ? "تم" : "Done") : lang === "ar" ? "قص" : "Trim"}
              </button>
            </div>
            <div
              className="relative h-16 rounded-[14px] bg-black/40"
              onPointerDown={(e) => {
                if (!trimEditing) return;
                const target = e.currentTarget;
                const rect = target.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const frac = Math.max(0, Math.min(1, x / rect.width));
                if (x < rect.width / 2) setTrimStart(frac);
                else setTrimEnd(frac);
              }}
            >
              <svg viewBox="0 0 200 64" className="h-full w-full" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="wave" x1="0" x2="1">
                    <stop offset="0%" stopColor={palette.start} />
                    <stop offset="100%" stopColor={palette.end} />
                  </linearGradient>
                </defs>
                <path
                  d="M0 32 Q 10 4 20 32 T 40 32 T 60 12 T 80 32 T 100 20 T 120 32 T 140 10 T 160 32 T 180 18 T 200 32 V64 H0 Z"
                  fill="url(#wave)"
                  opacity="0.85"
                />
                <line x1={trimStart * 200} y1="0" x2={trimStart * 200} y2="64" stroke="white" strokeWidth="2" />
                <line x1={trimEnd * 200} y1="0" x2={trimEnd * 200} y2="64" stroke="white" strokeWidth="2" />
              </svg>
              <div
                className="pointer-events-none absolute inset-y-0 w-2.5 rounded-full bg-white shadow"
                style={{ insetInlineStart: `calc(${trimStart * 100}% - 5px)` }}
              />
              <div
                className="pointer-events-none absolute inset-y-0 w-2.5 rounded-full bg-white shadow"
                style={{ insetInlineStart: `calc(${trimEnd * 100}% - 5px)` }}
              />
            </div>
            <div className="flex justify-between font-mono-aurora text-[9px] opacity-80">
              <span className="text-sky-400">{formatDuration(Math.round(trimStart * (activeVideo.durationSeconds || 300)))}</span>
              <span className="font-bold text-white">
                {formatDuration(Math.round((trimEnd - trimStart) * (activeVideo.durationSeconds || 300)))}
              </span>
              <span className="text-rose-300">{formatDuration(Math.round(trimEnd * (activeVideo.durationSeconds || 300)))}</span>
            </div>
          </AuroraGlassSurface>

          {/* Playback controls */}
          <AuroraGlassSurface padding="12px" shape="rounded-[20px]" className="space-y-2.5">
            <div className="flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => setRepeatMode((m) => {
                  const modes: DonRepeatMode[] = ["OFF", "ONE", "ALL", "SHUFFLE"];
                  return modes[(modes.indexOf(m) + 1) % modes.length];
                })}
                className={`flex h-9 w-9 items-center justify-center rounded-full ${
                  repeatMode !== "OFF" ? "aurora-gradient-bg text-white" : "bg-white/10"
                }`}
                title="Repeat mode"
              >
                {repeatMode === "OFF" && <Repeat className="h-4 w-4 opacity-80" />}
                {repeatMode === "ONE" && <Repeat1 className="h-4 w-4" />}
                {repeatMode === "ALL" && <Repeat className="h-4 w-4" />}
                {repeatMode === "SHUFFLE" && <Shuffle className="h-4 w-4" />}
              </button>
              <button className="flex h-12 w-12 items-center justify-center rounded-full bg-white/10">
                <Play className="h-5 w-5 fill-white" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setAudioOnly((v) => !v);
                  showToast(audioOnly ? (lang === "ar" ? "وضع الفيديو" : "Video mode") : lang === "ar" ? "تشغيل كصوت (خلفي)" : "Audio-only (background)");
                }}
                className={`flex h-9 w-9 items-center justify-center rounded-full ${
                  audioOnly ? "aurora-gradient-bg text-white" : "bg-white/10"
                }`}
                title="Audio only / background music"
              >
                <Music2 className="h-4 w-4" />
              </button>
            </div>

            <div className="grid grid-cols-4 gap-1.5">
              {[0.5, 1, 1.5, 2].map((r) => (
                <button
                  key={r}
                  onClick={() => setPlaybackSpeed(r)}
                  className={`rounded-full py-1 font-mono-aurora text-[10px] font-bold ${
                    playbackSpeed === r ? "aurora-gradient-bg text-white" : "bg-white/10"
                  }`}
                >
                  {r}x
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <Volume2 className="h-3.5 w-3.5 opacity-70" />
              <input
                type="range"
                min={0}
                max={100}
                value={volume}
                onChange={(e) => setVolume(Number(e.target.value))}
                className="w-full accent-sky-400"
              />
              <span className="font-mono-aurora text-[9px] opacity-70">{volume}</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setSubtitlesOn((v) => !v)}
                className={`flex flex-1 items-center justify-center gap-1 rounded-full py-1.5 text-[10px] font-bold ${
                  subtitlesOn ? "aurora-gradient-bg text-white" : "bg-white/10"
                }`}
              >
                <Subtitles className="h-3 w-3" />
                CC {subtitlesOn ? "ON" : "OFF"}
              </button>
              <button
                type="button"
                onClick={() => {
                  const next = sleepMinutes === null ? 30 : sleepMinutes === 30 ? 60 : sleepMinutes === 60 ? 90 : null;
                  setSleepMinutes(next);
                  showToast(next ? `${lang === "ar" ? "مؤقت نوم" : "Sleep timer"} ${next}m` : lang === "ar" ? "تم إلغاء مؤقت النوم" : "Sleep timer off");
                }}
                className={`flex flex-1 items-center justify-center gap-1 rounded-full py-1.5 text-[10px] font-bold ${
                  sleepMinutes ? "bg-violet-500/25 text-violet-300" : "bg-white/10"
                }`}
              >
                <BedDouble className="h-3 w-3" />
                {sleepMinutes ? `${sleepMinutes}m` : lang === "ar" ? "مؤقت نوم" : "Sleep"}
              </button>
              <button
                type="button"
                onClick={() => {
                  setRingtoneSet(true);
                  showToast(lang === "ar" ? "تم التعيين كنغمة رنين (يتطلب صلاحية WRITE_SETTINGS)" : "Set as ringtone (WRITE_SETTINGS permission)");
                }}
                className={`flex flex-1 items-center justify-center gap-1 rounded-full py-1.5 text-[10px] font-bold ${
                  ringtoneSet ? "bg-emerald-500/25 text-emerald-300" : "bg-white/10"
                }`}
              >
                <Bell className="h-3 w-3" />
                {lang === "ar" ? "نغمة" : "Ringtone"}
              </button>
            </div>
          </AuroraGlassSurface>
        </div>
      </div>
    );
  }
}
