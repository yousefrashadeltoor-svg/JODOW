import { useEffect, useState } from "react";
import { Dock, type DockRoute } from "@/components/Dock";
import { AuroraBackground, Glass } from "@/components/ui";
import { PlayerProvider, usePlayer } from "@/components/Player";
import { applyTheme, themeById, THEMES } from "@/lib/theme";
import { useStore, store, exportState, importState, downloadBlob, addLocalMedia } from "@/lib/store";
import { HomeScreen } from "@/screens/Home";
import { JODONScreen } from "@/screens/JODON";
import { DownloadsScreen } from "@/screens/Downloads";
import { BrowserScreen } from "@/screens/Browser";
import { LibraryScreen } from "@/screens/Library";
import { MusicScreen } from "@/screens/Music";
import { ToolsScreen } from "@/screens/Tools";
import { ConverterScreen } from "@/screens/Converter";
import { CompressorScreen } from "@/screens/Compressor";
import { SettingsScreen } from "@/screens/Settings";
import { OnboardingScreen } from "@/screens/Onboarding";
import { Icon } from "@/lib/icons";

const ONBOARD_KEY = "jodon.onboarded.v2";

export default function App() {
  return (
    <PlayerProvider>
      <Shell />
    </PlayerProvider>
  );
}

function Shell() {
  const s = useStore();
  const player = usePlayer();
  const [route, setRoute] = useState<DockRoute>("home");
  const [sub, setSub] = useState<"converter" | "compressor" | "browser" | null>(null);
  const [onboarding, setOnboarding] = useState(() => localStorage.getItem(ONBOARD_KEY) !== "1");
  const [online, setOnline] = useState(navigator.onLine);
  const [showAllThemes, setShowAllThemes] = useState(false);
  const theme = themeById(s.settings.themeId);
  const lang = s.settings.lang;

  useEffect(() => {
    applyTheme(theme);
    document.documentElement.dataset.reduced = String(s.settings.reducedMotion || !s.settings.animations);
  }, [theme, s.settings.reducedMotion, s.settings.animations]);

  useEffect(() => {
    // Real haptic feedback on every tap when enabled.
    const haptic = () => {
      if (s.settings.haptics && navigator.vibrate) navigator.vibrate(8);
    };
    document.addEventListener("pointerdown", haptic);
    return () => document.removeEventListener("pointerdown", haptic);
  }, [s.settings.haptics]);

  useEffect(() => {
    const on = () => setOnline(true), off = () => setOnline(false);
    window.addEventListener("online", on); window.addEventListener("offline", off);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);

  const go = (r: DockRoute) => { setSub(null); setRoute(r); };

  let screen: React.ReactNode;
  if (sub === "converter") screen = <ConverterScreen onToast={player.toast} />;
  else if (sub === "compressor") screen = <CompressorScreen onToast={player.toast} />;
  else if (sub === "browser") screen = <BrowserScreen onToast={player.toast} />;
  else switch (route) {
    case "home": screen = <HomeScreen onToast={player.toast} onGoBrowser={() => setSub("browser")}
      onGoDownloads={() => go("downloads")} onGoJodon={() => go("jodon")} />; break;
    case "jodon": screen = <JODONScreen onToast={player.toast} />; break;
    case "downloads": screen = <DownloadsScreen onToast={player.toast} />; break;
    case "music": screen = <MusicScreen onToast={player.toast} />; break;
    case "library": screen = <LibraryScreen onToast={player.toast} />; break;
    case "tools": screen = <ToolsScreen onToast={player.toast}
      onConverter={() => setSub("converter")} onCompressor={() => setSub("compressor")} />; break;
    case "settings": screen = <SettingsScreen onToast={player.toast} />; break;
    default: screen = null;
  }

  const activeDock: DockRoute = sub ? (sub === "browser" ? "home" : "tools") : route;

  return (
    <div dir={lang === "ar" ? "rtl" : "ltr"}
      className="relative flex h-full w-full items-center justify-center gap-8 overflow-hidden bg-[#05070c] p-4 lg:p-8">
      <AuroraBackground photo={theme.photo} mesh={s.settings.meshBackground} />

      {/* ------------------------------- desktop side panel --------------- */}
      <aside className="relative z-10 hidden w-[330px] shrink-0 lg:block">
        <div className="flex items-center gap-2">
          <span className="grad grid h-10 w-10 place-items-center rounded-[14px] text-white">
            <Icon name="bolt" size={20} />
          </span>
          <div className="flex-1">
            <h1 className="grad-text text-[19px] font-extrabold tracking-tight">𝒥𝒪 DON</h1>
            <p className="text-[10px] t-muted">تطبيق محلي كامل · Offline-first</p>
          </div>
          <button onClick={() => store.update((st) => ({ ...st, settings: { ...st.settings, lang: lang === "ar" ? "en" : "ar" } }))}
            className="press glass-soft glass-border rounded-full px-3 py-1.5 text-[10px] t-text">
            {lang === "ar" ? "EN" : "ع"}
          </button>
        </div>

        <Glass className="mt-4 overflow-hidden rounded-[var(--card-radius)]">
          <div className="relative h-32 bg-cover bg-center" style={{ backgroundImage: `url(${theme.photo})` }}>
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 to-transparent" />
            <div className="absolute bottom-2 start-3">
              <p className="text-[13px] font-bold text-white">الثيم: {theme.name}</p>
              <p className="text-[9.5px] text-white/70">{theme.motion.duration}ms · {theme.optics.blur}px blur · {theme.geometry.radius}px radius</p>
            </div>
          </div>
          <div className="p-3">
            <div className="no-scrollbar flex gap-1.5 overflow-x-auto">
              {THEMES.map((t) => (
                <button key={t.id} onClick={() => store.update((st) => ({ ...st, settings: { ...st.settings, themeId: t.id } }))}
                  title={t.name}
                  className={`press h-9 w-9 shrink-0 overflow-hidden rounded-full bg-cover bg-center ${t.id === theme.id ? "ring-2 ring-white" : "ring-1 ring-white/20"}`}
                  style={{ backgroundImage: `url(${t.photo})` }} />
              ))}
            </div>
            <button onClick={() => setShowAllThemes(!showAllThemes)} className="mt-2 text-[10px] t-a1">
              {showAllThemes ? "إخفاء تفاصيل الثيم" : "كل الثيمات (١٢) ←"}
            </button>
            {showAllThemes && (
              <div className="mt-2 grid grid-cols-2 gap-1.5">
                {THEMES.map((t) => (
                  <button key={t.id} onClick={() => store.update((st) => ({ ...st, settings: { ...st.settings, themeId: t.id } }))}
                    className="press flex items-center gap-1.5 rounded-full bg-white/6 px-2 py-1.5 text-[9px] t-muted">
                    <span className="h-3 w-3 rounded-full" style={{ background: t.colors.a1 }} />{t.name}
                  </button>
                ))}
              </div>
            )}
          </div>
        </Glass>

        <Glass className="mt-3 rounded-[var(--card-radius)] p-4">
          <p className="text-[11.5px] font-semibold t-text">حالة الجهاز</p>
          <div className="mt-2 space-y-1.5 text-[10.5px]">
            <Line label="الاتصال" value={online ? "متصل" : "بدون اتصال"} ok={online} />
            <Line label="التخزين" value="محلي على الجهاز (JSON + ملفات)" ok />
            <Line label="خادم / قاعدة بيانات" value="لا يوجد" ok />
            <Line label="فيديوهات" value={String(s.videos.length)} />
            <Line label="ملفات صوتية" value={String(s.tracks.length)} />
            <Line label="تحميلات" value={String(s.downloads.length)} />
            <Line label="متابعات" value={String(s.subscriptions.length)} />
          </div>
        </Glass>

        <Glass className="mt-3 rounded-[var(--card-radius)] p-4">
          <p className="text-[11.5px] font-semibold t-text">ملفاتك</p>
          <p className="mt-1 text-[10px] leading-5 t-muted">
            استورد ملفات الفيديو والصوت لتُحفظ فعليًا في التخزين المحلي. المشغّل يقرأ الملفات الحقيقية،
            والقص يصدّر WAV حقيقيًا، والضغط يقيس البايتات قبل/بعد بصدق.
          </p>
          <label className="grad-l press mt-3 inline-flex cursor-pointer items-center gap-2 rounded-full px-4 py-2 text-[10.5px] font-semibold text-white">
            <Icon name="upload" size={14} /> استيراد ملفات
            <input type="file" multiple accept="video/*,audio/*" className="hidden" onChange={async (e) => {
              if (!e.target.files) return;
              const r = await addLocalMedia(e.target.files);
              player.toast(`استُورد ${r.videos} فيديو و ${r.tracks} صوت فعليًا`);
              e.target.value = "";
            }} />
          </label>
        </Glass>

        <div className="mt-3 flex gap-2">
          <button onClick={async () => downloadBlob(await exportState(false), "JODON-backup.json")}
            className="press glass-soft glass-border flex-1 rounded-full py-2 text-[10px] t-text">تصدير</button>
          <label className="press glass-soft glass-border flex-1 cursor-pointer rounded-full py-2 text-center text-[10px] t-text">
            استيراد
            <input type="file" accept="application/json,.json" className="hidden" onChange={async (e) => {
              const f = e.target.files?.[0]; if (!f) return;
              player.toast((await importState(f)).message); e.target.value = "";
            }} />
          </label>
        </div>

        <p className="mt-3 px-1 text-[9.5px] leading-4 t-warn">
          المسؤولية على المستخدم في احترام حقوق النشر — لا تجاوز DRM ولا اشتراكات مدفوعة.
        </p>
      </aside>

      {/* --------------------------------- device -------------------------- */}
      <div className="relative z-10">
        <div className="relative h-[844px] w-[390px] overflow-hidden rounded-[46px] border border-white/12 bg-[var(--bg)] shadow-[0_50px_120px_-30px_rgba(0,0,0,0.9)]">
          <div className="absolute left-1/2 top-2 z-50 h-6 w-28 -translate-x-1/2 rounded-full bg-black/80" />
          <AuroraBackground photo={theme.photo} mesh={s.settings.meshBackground} />
          <div className="relative z-10 h-full overflow-hidden">
            {onboarding ? (
              <OnboardingScreen onDone={() => { localStorage.setItem(ONBOARD_KEY, "1"); setOnboarding(false); }} />
            ) : (
              <>
                {(sub || (route !== "home" && route !== "jodon")) && (
                  <div className="absolute end-3 top-12 z-20">
                    <button onClick={() => { if (sub) setSub(null); else go("home"); }}
                      className="press glass-soft glass-border grid h-9 w-9 place-items-center rounded-full t-text">
                      <Icon name="close" size={15} />
                    </button>
                  </div>
                )}
                {screen}
                <Dock active={activeDock} onSelect={go} lang={lang} />
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Line({ label, value, ok }: { label: string; value: string; ok?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="t-muted">{label}</span>
      <span className={ok ? "t-ok" : "t-text"}>{value}</span>
    </div>
  );
}
