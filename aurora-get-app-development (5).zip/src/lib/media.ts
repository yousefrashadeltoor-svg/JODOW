/**
 * Real client-side audio engine: decoding, waveform analysis, filtering,
 * visualisation and actual WAV export of a user-selected range.
 */
let ctx: AudioContext | null = null;
export function audioContext(): AudioContext {
  if (!ctx) ctx = new AudioContext();
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

export async function decode(blob: Blob): Promise<AudioBuffer> {
  const ac = audioContext();
  const bytes = await blob.arrayBuffer();
  return await ac.decodeAudioData(bytes);
}

/** Extracts real amplitude peaks from the decoded buffer for the visual trimmer. */
export function peaks(buffer: AudioBuffer, count = 220): number[] {
  const data = buffer.getChannelData(0);
  const block = Math.floor(data.length / count);
  const out: number[] = [];
  for (let i = 0; i < count; i++) {
    let max = 0;
    const start = i * block;
    for (let j = 0; j < block; j += Math.max(1, Math.floor(block / 64))) {
      const v = Math.abs(data[start + j] || 0);
      if (v > max) max = v;
    }
    out.push(max);
  }
  const top = Math.max(...out, 0.001);
  return out.map((v) => v / top);
}

/** Encodes a real PCM slice as a playable WAV file. */
export function encodeWav(buffer: AudioBuffer, fromSec: number, toSec: number): Blob {
  const ac = audioContext();
  const sr = buffer.sampleRate;
  const start = Math.max(0, Math.floor(fromSec * sr));
  const end = Math.min(buffer.length, Math.floor(toSec * sr));
  const len = Math.max(1, end - start);
  const channels = Math.min(2, buffer.numberOfChannels);
  const bytesPerSample = 2;
  const dataSize = len * channels * bytesPerSample;
  const out = new ArrayBuffer(44 + dataSize);
  const view = new DataView(out);
  const w = (off: number, s: string) => { for (let i = 0; i < s.length; i++) view.setUint8(off + i, s.charCodeAt(i)); };
  w(0, "RIFF"); view.setUint32(4, 36 + dataSize, true); w(8, "WAVE");
  w(12, "fmt "); view.setUint32(16, 16, true); view.setUint16(20, 1, true);
  view.setUint16(22, channels, true); view.setUint32(24, sr, true);
  view.setUint32(28, sr * channels * bytesPerSample, true);
  view.setUint16(32, channels * bytesPerSample, true); view.setUint16(34, 16, true);
  w(36, "data"); view.setUint32(40, dataSize, true);
  const chans = Array.from({ length: channels }, (_, c) => buffer.getChannelData(c));
  let off = 44;
  for (let i = 0; i < len; i++) {
    for (let c = 0; c < channels; c++) {
      const v = Math.max(-1, Math.min(1, chans[c][start + i] || 0));
      view.setInt16(off, v < 0 ? v * 0x8000 : v * 0x7fff, true);
      off += 2;
    }
  }
  void ac;
  return new Blob([out], { type: "audio/wav" });
}

/** A tiny 3-band EQ graph attached to a real media element. */
export interface AudioGraph {
  bass: BiquadFilterNode;
  mid: BiquadFilterNode;
  treble: BiquadFilterNode;
  analyser: AnalyserNode;
  gain: GainNode;
  source: MediaElementAudioSourceNode;
  disconnect: () => void;
}

const graphs = new WeakMap<HTMLMediaElement, AudioGraph>();
export function attachGraph(el: HTMLMediaElement): AudioGraph {
  const existing = graphs.get(el);
  if (existing) return existing;
  const ac = audioContext();
  const source = ac.createMediaElementSource(el);
  const bass = ac.createBiquadFilter(); bass.type = "lowshelf"; bass.frequency.value = 180;
  const mid = ac.createBiquadFilter(); mid.type = "peaking"; mid.frequency.value = 1000; mid.Q.value = 0.8;
  const treble = ac.createBiquadFilter(); treble.type = "highshelf"; treble.frequency.value = 4200;
  const gain = ac.createGain();
  const analyser = ac.createAnalyser(); analyser.fftSize = 128; analyser.smoothingTimeConstant = 0.78;
  source.connect(bass); bass.connect(mid); mid.connect(treble);
  treble.connect(gain); gain.connect(analyser); analyser.connect(ac.destination);
  const graph = { bass, mid, treble, analyser, gain, source, disconnect: () => {
    source.disconnect(); bass.disconnect(); mid.disconnect(); treble.disconnect(); gain.disconnect(); analyser.disconnect();
  } };
  graphs.set(el, graph);
  return graph;
}

export function setEq(graph: AudioGraph, bass: number, mid: number, treble: number) {
  graph.bass.gain.value = bass;
  graph.mid.gain.value = mid;
  graph.treble.gain.value = treble;
}

export function formatTime(sec: number): string {
  if (!Number.isFinite(sec) || sec < 0) return "0:00";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`
    : `${m}:${String(s).padStart(2, "0")}`;
}

/** Real resampling + channel folding, then PCM WAV encoding (genuine re-encode). */
export function encodeWavResampled(buffer: AudioBuffer, targetRate: number, mono: boolean, fromSec = 0, toSec = Infinity): Blob {
  const sr = Math.max(8000, Math.min(48000, targetRate));
  const start = Math.max(0, Math.floor(fromSec * buffer.sampleRate));
  const end = Math.min(buffer.length, Number.isFinite(toSec) ? Math.floor(toSec * buffer.sampleRate) : buffer.length);
  const len = Math.max(1, Math.floor((end - start) * sr / buffer.sampleRate));
  const channels = mono ? 1 : Math.min(2, buffer.numberOfChannels);
  const dataSize = len * channels * 2;
  const out = new ArrayBuffer(44 + dataSize);
  const v = new DataView(out);
  const w = (o: number, s: string) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  w(0, "RIFF"); v.setUint32(4, 36 + dataSize, true); w(8, "WAVE"); w(12, "fmt ");
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, channels, true);
  v.setUint32(24, sr, true); v.setUint32(28, sr * channels * 2, true);
  v.setUint16(32, channels * 2, true); v.setUint16(34, 16, true);
  w(36, "data"); v.setUint32(40, dataSize, true);
  const chans = Array.from({ length: buffer.numberOfChannels }, (_, c) => buffer.getChannelData(c));
  let off = 44;
  for (let i = 0; i < len; i++) {
    const src = start + Math.floor(i * buffer.sampleRate / sr);
    for (let c = 0; c < channels; c++) {
      const sample = mono
        ? chans.reduce((acc, ch) => acc + (ch[src] || 0), 0) / chans.length
        : (chans[c]?.[src] || 0);
      const clipped = Math.max(-1, Math.min(1, sample));
      v.setInt16(off, clipped < 0 ? clipped * 0x8000 : clipped * 0x7fff, true);
      off += 2;
    }
  }
  return new Blob([out], { type: "audio/wav" });
}
