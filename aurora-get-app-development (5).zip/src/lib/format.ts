const UNITS = ["B", "KiB", "MiB", "GiB", "TiB"];

export function bytes(value: number | null | undefined): string {
  if (value === null || value === undefined || value < 0) return "—";
  if (value < 1024) return `${value} B`;
  let size = value;
  let index = 0;
  while (size >= 1024 && index < UNITS.length - 1) {
    size /= 1024;
    index++;
  }
  const digits = size >= 100 ? 0 : size >= 10 ? 1 : 2;
  return `${size.toFixed(digits)} ${UNITS[index]}`;
}

export const approxBytes = (value: number | null | undefined) =>
  value == null ? "—" : `≈ ${bytes(value)}`;

export function exactBytes(value: number): string {
  return `${value.toLocaleString("en-US")} bytes (${bytes(value)})`;
}

export function duration(seconds: number | null | undefined): string {
  if (!seconds || seconds <= 0) return "0:00";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function speed(value: number): string {
  if (value <= 0) return "—";
  const mb = value / (1024 * 1024);
  return mb >= 1 ? `${mb.toFixed(2)} MB/s` : `${(value / 1024).toFixed(0)} KB/s`;
}

export function eta(seconds: number | null): string {
  if (seconds == null || seconds <= 0) return "—";
  if (seconds >= 3600)
    return `${Math.floor(seconds / 3600)}h ${String(Math.floor((seconds % 3600) / 60)).padStart(2, "0")}m`;
  return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(Math.floor(seconds % 60)).padStart(2, "0")}`;
}
