import type { ReactNode, SVGProps } from "react";

/**
 * Aurora Get's own icon set — custom stroke glyphs, no icon library.
 * Mirrors the hand drawn ImageVector set of the Android app.
 */
const paths: Record<string, ReactNode> = {
  home: <path d="M3.5 11.2 12 3.8l8.5 7.4V20a.8.8 0 0 1-.8.8h-4.9v-5.9H9.2v5.9H4.3a.8.8 0 0 1-.8-.8Z" />,
  downloads: (
    <>
      <path d="M12 3.4v10.2" />
      <path d="m8.2 10.2 3.8 3.9 3.8-3.9" />
      <path d="M4.2 18.4h15.6" />
    </>
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="8.6" />
      <path d="M3.4 12h17.2" />
      <path d="M12 3.4c2.3 2.4 3.5 5.4 3.5 8.6S14.3 18.2 12 20.6c-2.3-2.4-3.5-5.4-3.5-8.6S9.7 5.8 12 3.4Z" />
    </>
  ),
  converter: (
    <>
      <path d="M4 6.6h9.6" />
      <path d="m11 4 3 2.6-3 2.6" />
      <path d="M20 17.4H10.4" />
      <path d="m13 14.8-3 2.6 3 2.6" />
    </>
  ),
  compressor: (
    <>
      <path d="M9 4.2h6M12 4.2v3.4" />
      <path d="M9 19.8h6M12 19.8v-3.4" />
      <path d="M4.4 10.4h5.2M9.6 8.8l-2.6 2.8 2.6 2.8" />
      <path d="M19.6 10.4h-5.2M14.4 8.8l2.6 2.8-2.6 2.8" />
    </>
  ),
  library: (
    <>
      <path d="M4 4.4h5.4v15.2H4z" />
      <path d="M10.8 4.4h5.4v15.2h-5.4z" />
      <path d="M17.6 5.6l3 .8-3.4 13.4-3-.8z" />
    </>
  ),
  settings: (
    <>
      <path d="M4 6.2h16M4 12h16M4 17.8h16" />
      <circle cx="9.4" cy="6.2" r="2.2" />
      <circle cx="15.2" cy="12" r="2.2" />
      <circle cx="8.2" cy="17.8" r="2.2" />
    </>
  ),
  audio: (
    <>
      <path d="M9.6 17.4V5.2l8-1.6v11.4" />
      <circle cx="7.4" cy="17.6" r="2.6" />
      <circle cx="15.4" cy="15.6" r="2.6" />
    </>
  ),
  image: (
    <>
      <rect x="3.4" y="4.8" width="17.2" height="14.4" rx="3" />
      <circle cx="8.6" cy="9.8" r="1.7" />
      <path d="m4.6 17 4.8-5.2 3.6 4 2.6-2.6 4.4 4.4" />
    </>
  ),
  video: (
    <>
      <rect x="2.8" y="5.8" width="12.6" height="12.4" rx="3" />
      <path d="m15.4 10.4 5.2-2.8v8.8l-5.2-2.8z" />
    </>
  ),
  file: (
    <>
      <path d="M6 3.6h7.4l5 5v11.8H6z" />
      <path d="M13.4 3.6v5h5" />
    </>
  ),
  play: <path d="M7.6 4.8 19 12 7.6 19.2z" />,
  pause: <path d="M9 4.8v14.4M15 4.8v14.4" />,
  close: <path d="m5.6 5.6 12.8 12.8M18.4 5.6 5.6 18.4" />,
  check: <path d="m4.6 12.6 4.6 4.6 10.2-10.4" />,
  search: (
    <>
      <circle cx="11" cy="11" r="6.4" />
      <path d="m15.8 15.8 4 4" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="8.6" />
      <path d="M12 7v5.4l3.4 2" />
    </>
  ),
  shield: (
    <>
      <path d="M12 3.2 19.6 6v6.2c0 4-3.2 7-7.6 8.6-4.4-1.6-7.6-4.6-7.6-8.6V6z" />
      <path d="m9 12 2.2 2.2L15.4 10" />
    </>
  ),
  link: (
    <>
      <path d="M9.8 14.2 14.2 9.8" />
      <path d="M7.6 13.4 5.8 15.2a3.4 3.4 0 0 0 4.8 4.8l1.8-1.8" />
      <path d="M16.4 10.6l1.8-1.8a3.4 3.4 0 1 0-4.8-4.8l-1.8 1.8" />
    </>
  ),
  refresh: (
    <>
      <path d="M20 12a8 8 0 1 1-2.6-5.9" />
      <path d="M20 4.4V9h-4.6" />
    </>
  ),
  share: (
    <>
      <circle cx="17.6" cy="5.8" r="2.6" />
      <circle cx="6.4" cy="12" r="2.6" />
      <circle cx="17.6" cy="18.2" r="2.6" />
      <path d="m8.7 10.8 6.6-3.6M8.7 13.2l6.6 3.6" />
    </>
  ),
  copy: (
    <>
      <rect x="8.6" y="3.6" width="11.8" height="12" rx="2.6" />
      <path d="M15.4 19.4H5.8a2.2 2.2 0 0 1-2.2-2.2V7.6" />
    </>
  ),
  trash: (
    <>
      <path d="M4.4 6.6h15.2" />
      <path d="M6.4 6.6 7.4 20h9.2l1-13.4" />
      <path d="M9.6 6.4V4.2h4.8v2.2" />
    </>
  ),
  folder: <path d="M3.4 6.4h5.6l2 2.4h9.6v10.4H3.4z" />,
  grid: (
    <>
      <rect x="4" y="4" width="7" height="7" rx="2.2" />
      <rect x="13" y="4" width="7" height="7" rx="2.2" />
      <rect x="4" y="13" width="7" height="7" rx="2.2" />
      <rect x="13" y="13" width="7" height="7" rx="2.2" />
    </>
  ),
  list: <path d="M4 6.4h3M9.6 6.4h10.4M4 12h3M9.6 12h10.4M4 17.6h3M9.6 17.6h10.4" />,
  spark: <path d="M12 3.2 13.8 10 20.6 12 13.8 14 12 20.8 10.2 14 3.4 12l6.8-2z" />,
  warning: (
    <>
      <path d="M12 3.6 21.4 20H2.6z" />
      <path d="M12 9.6v4.6M12 17.2h.01" />
    </>
  ),
  bolt: <path d="M13.6 2.4 5.8 13.8h5.6l-.8 7.8 7.8-11.4h-5.6z" />,
  forward: <path d="m9.6 4.8 7.8 7.2-7.8 7.2z" />,
  back: <path d="M14.4 4.8 6.6 12l7.8 7.2z" />,
  more: (
    <>
      <circle cx="12" cy="5.4" r="1.7" />
      <circle cx="12" cy="12" r="1.7" />
      <circle cx="12" cy="18.6" r="1.7" />
    </>
  ),
  block: (
    <>
      <circle cx="12" cy="12" r="8.4" />
      <path d="m6.2 6.2 11.6 11.6" />
    </>
  ),
  eye: (
    <>
      <path d="M2.6 12S6 5.8 12 5.8 21.4 12 21.4 12 18 18.2 12 18.2 2.6 12 2.6 12Z" />
      <circle cx="12" cy="12" r="3" />
    </>
  ),
  info: (
    <>
      <circle cx="12" cy="12" r="8.6" />
      <path d="M12 11v5.4M12 7.8h.01" />
    </>
  ),
  speed: (
    <>
      <path d="M3.6 17.6a8.6 8.6 0 1 1 16.8 0" />
      <path d="m12 13 3.6-4.2" />
    </>
  ),
  calendar: (
    <>
      <rect x="3.8" y="5.4" width="16.4" height="14.8" rx="3" />
      <path d="M3.8 10h16.4M8.4 3.4v3.6M15.6 3.4v3.6" />
    </>
  ),
  compress: <path d="M9.6 3.4v4.2H5.4M14.4 3.4v4.2h4.2M9.6 20.6v-4.2H5.4M14.4 20.6v-4.2h4.2" />,
  download: (
    <>
      <path d="M12 3.6v10.6" />
      <path d="m8.4 10.6 3.6 3.6 3.6-3.6" />
      <path d="M4.4 18.6h15.2" />
    </>
  ),
  lock: (
    <>
      <rect x="4.8" y="10.4" width="14.4" height="10" rx="3" />
      <path d="M8.2 10.4V7.6a3.8 3.8 0 0 1 7.6 0v2.8" />
    </>
  ),
  upload: (
    <>
      <path d="M12 20.4V9.8" />
      <path d="m8.4 13.4 3.6-3.6 3.6 3.6" />
      <path d="M4.4 5.4h15.2" />
    </>
  ),
  youtube: (
    <>
      <rect x="2.4" y="5.6" width="19.2" height="12.8" rx="4" />
      <path d="M10.2 9.2 15.4 12l-5.2 2.8z" />
    </>
  ),
  shorts: (
    <>
      <path d="M8.4 3.2c0 3.6-3.4 3.6-3.4 8.8s3.4 5.2 3.4 8.8" />
      <path d="M15.6 3.2c0 3.6 3.4 3.6 3.4 8.8s-3.4 5.2-3.4 8.8" />
      <path d="M10.2 9.4 15 12l-4.8 2.6z" />
    </>
  ),
  bell: (
    <>
      <path d="M6.4 16.8h11.2l-1.2-2V10a4.4 4.4 0 0 0-8.8 0v4.8z" />
      <path d="M10 19.4a2 2 0 0 0 4 0" />
    </>
  ),
  heart: <path d="M12 20s-7.4-4.4-7.4-9.2A4.2 4.2 0 0 1 12 8a4.2 4.2 0 0 1 7.4 2.8C19.4 15.6 12 20 12 20Z" />,
  thumb: (
    <>
      <path d="M7 10.4 11 3.6a2 2 0 0 1 2 2v4.2h5.4a2 2 0 0 1 2 2.4l-1.2 6a2 2 0 0 1-2 1.6H7z" />
      <path d="M3.4 10.6h3.4v8.8H3.4z" />
    </>
  ),
  history: (
    <>
      <path d="M3.6 12a8.4 8.4 0 1 0 2.6-6" />
      <path d="M3.6 4.4V9h4.6M12 7.4V12l3 1.8" />
    </>
  ),
  filter: <path d="M3.6 5.4h16.8l-6.6 7.4v5.4l-3.6 1.8v-7.2z" />,
  music: (
    <>
      <path d="M9.4 17.6V4.8l9.2-2v12.2" />
      <circle cx="6.8" cy="17.8" r="2.8" />
      <circle cx="16" cy="15" r="2.8" />
    </>
  ),
  stop: <rect x="5.4" y="5.4" width="13.2" height="13.2" rx="2.4" />,
  calendar2: (
    <>
      <rect x="3.8" y="5.4" width="16.4" height="14.8" rx="3" />
      <path d="M8 3.4v3.6M16 3.4v3.6M8 13h3" />
    </>
  ),
};

export type IconName = keyof typeof paths;

export function Icon({
  name,
  size = 20,
  className,
  strokeWidth = 1.8,
  ...rest
}: { name: IconName; size?: number; className?: string; strokeWidth?: number } & SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      {...rest}
    >
      {paths[name]}
    </svg>
  );
}
