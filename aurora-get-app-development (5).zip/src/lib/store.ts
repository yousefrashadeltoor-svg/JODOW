/**
 * 𝒥𝒪 DON — real, on-device persistence.
 *
 * There is NO backend, NO server and NO SQL database.
 *  • metadata / settings / profile  → localStorage (JSON)
 *  • real media blobs               → browser-owned IndexedDB object store
 *  • export / import                → a real JSON file on the user's device
 *
 * Everything works with the network unplugged.
 */
import { useSyncExternalStore } from "react";

export type MediaKind = "VIDEO" | "AUDIO" | "IMAGE" | "FILE";

export interface VideoItem {
  id: string;
  title: string;
  channel: string;
  channelId: string;
  url: string;              // real link (user supplied or extracted)
  thumbnail: string;        // real local blob URL / data URL / empty
  duration: number;
  views: number;
  published: number;
  description: string;
  tags: string[];
  kind: "video" | "short";
  localFileId?: string;     // real file stored locally
  sizeBytes?: number;
  addedAt: number;
}

export interface TrackItem {
  id: string;
  title: string;
  artist: string;
  album: string;
  fileId: string;           // real file in IndexedDB
  duration: number;
  cover: string;
  sizeBytes: number;
  addedAt: number;
}

export interface DownloadItem {
  id: string;
  title: string;
  url: string;
  kind: MediaKind;
  quality: string;
  size: number;             // real bytes
  savedBytes: number;
  status: "running" | "queued" | "paused" | "completed" | "failed";
  createdAt: number;
  localFileId?: string;
  segments: number;
  speed: number;
}

export interface Profile {
  name: string;
  handle: string;
  bio: string;
  avatar: string;
  banner: string;
  createdAt: number;
}

export interface Settings {
  themeId: string;
  reducedMotion: boolean;
  animations: boolean;
  meshBackground: boolean;
  haptics: boolean;
  wifiOnly: boolean;
  maxConnections: number;
  autoplay: boolean;
  loopMode: "off" | "all" | "one" | "shuffle";
  sleepMinutes: number;
  volume: number;
  playbackRate: number;
  lang: "ar" | "en";
  layout: "grid" | "list";
}

export interface AppState {
  version: number;
  profile: Profile;
  subscriptions: string[];
  watchHistory: { videoId: string; at: number; seconds: number }[];
  likes: string[];
  watchLater: string[];
  searchHistory: string[];
  videos: VideoItem[];
  tracks: TrackItem[];
  downloads: DownloadItem[];
  playlists: { id: string; name: string; videoIds: string[] }[];
  browserLinks: { id: string; url: string; title: string; at: number }[];
  settings: Settings;
  stats: { bytesSaved: number; filesOpened: number; searches: number };
}

const KEY = "jodon.state.v1";
const DB = "jodon.files.v1";
const STORE = "blobs";

export const defaultState: AppState = {
  version: 1,
  profile: {
    name: "ضيف 𝒥𝒪 DON",
    handle: "@jodon_local",
    bio: "ملف شخصي محلي بالكامل — لا حساب، لا سحابة، لا تتبّع.",
    avatar: "",
    banner: "",
    createdAt: Date.now(),
  },
  subscriptions: [],
  watchHistory: [],
  likes: [],
  watchLater: [],
  searchHistory: [],
  videos: [],
  tracks: [],
  downloads: [],
  browserLinks: [],
  playlists: [
    { id: "pl-later", name: "شاهد لاحقًا", videoIds: [] },
    { id: "pl-fav", name: "المفضلة", videoIds: [] },
  ],
  settings: {
    themeId: "aurora",
    reducedMotion: false,
    animations: true,
    meshBackground: true,
    haptics: true,
    wifiOnly: false,
    maxConnections: 16,
    autoplay: false,
    loopMode: "off",
    sleepMinutes: 0,
    volume: 1,
    playbackRate: 1,
    lang: "ar",
    layout: "grid",
  },
  stats: { bytesSaved: 0, filesOpened: 0, searches: 0 },
};

function load(): AppState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return structuredClone(defaultState);
    const parsed = JSON.parse(raw) as AppState;
    return {
      ...structuredClone(defaultState),
      ...parsed,
      settings: { ...defaultState.settings, ...(parsed.settings ?? {}) },
      profile: { ...defaultState.profile, ...(parsed.profile ?? {}) },
      stats: { ...defaultState.stats, ...(parsed.stats ?? {}) },
    };
  } catch {
    return structuredClone(defaultState);
  }
}

let state: AppState = load();
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

function commit(next: AppState) {
  state = next;
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch (e) {
    console.warn("localStorage full", e);
  }
  emit();
}

export const store = {
  get: () => state,
  subscribe: (fn: () => void) => {
    listeners.add(fn);
    return () => listeners.delete(fn);
  },
  update: (fn: (s: AppState) => AppState) => commit(fn(state)),
  reset: () => commit(structuredClone(defaultState)),
  replace: (next: AppState) => commit(next),
};

export function useStore(): AppState {
  return useSyncExternalStore(store.subscribe, store.get, store.get);
}

/* -------------------------------------------------------------- real files */

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function putFile(id: string, blob: Blob): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(blob, id);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error); };
  });
}

export async function getFile(id: string): Promise<Blob | null> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readonly");
    const req = tx.objectStore(STORE).get(id);
    req.onsuccess = () => { db.close(); resolve((req.result as Blob) ?? null); };
    req.onerror = () => { db.close(); reject(req.error); };
  });
}

export async function deleteFile(id: string): Promise<void> {
  const db = await openDb();
  return new Promise((resolve) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = () => { db.close(); resolve(); };
  });
}

/** A real object URL bound to a real locally stored file. */
const urlCache = new Map<string, string>();
export async function fileUrl(id: string): Promise<string> {
  const cached = urlCache.get(id);
  if (cached) return cached;
  const blob = await getFile(id);
  if (!blob) return "";
  const url = URL.createObjectURL(blob);
  urlCache.set(id, url);
  return url;
}

export async function readAsDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result));
    fr.onerror = () => reject(fr.error);
    fr.readAsDataURL(blob);
  });
}

/* ------------------------------------------------------- export / import */

export async function exportState(includeFiles: boolean): Promise<Blob> {
  const files: Record<string, string> = {};
  if (includeFiles) {
    const ids = [
      ...state.tracks.map((t) => t.fileId),
      ...state.videos.map((v) => v.localFileId).filter(Boolean) as string[],
    ];
    for (const id of new Set(ids)) {
      const blob = await getFile(id);
      if (blob && blob.size <= 12 * 1024 * 1024) files[id] = await readAsDataUrl(blob);
    }
  }
  const payload = { format: "JODON-BACKUP", exportedAt: Date.now(), state, files };
  return new Blob([JSON.stringify(payload)], { type: "application/json" });
}

export function downloadBlob(blob: Blob, filename: string) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

export async function importState(file: File): Promise<{ ok: boolean; message: string }> {
  try {
    const text = await file.text();
    const payload = JSON.parse(text);
    if (payload.format !== "JODON-BACKUP" || !payload.state) {
      return { ok: false, message: "صيغة الملف غير مدعومة" };
    }
    const incoming = payload.state as AppState;
    store.replace({
      ...structuredClone(defaultState),
      ...incoming,
      settings: { ...defaultState.settings, ...(incoming.settings ?? {}) },
      profile: { ...defaultState.profile, ...(incoming.profile ?? {}) },
    });
    const files: Record<string, string> = payload.files ?? {};
    let restored = 0;
    for (const [id, dataUrl] of Object.entries(files)) {
      const res = await fetch(dataUrl);
      const blob = await res.blob();
      await putFile(id, blob);
      restored++;
    }
    return { ok: true, message: `تم الاستيراد — ${restored} ملف مستعاد` };
  } catch (e) {
    return { ok: false, message: `تعذّر الاستيراد: ${(e as Error).message}` };
  }
}

/* ------------------------------------------------------------- helpers */

export const uid = () =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;

export async function addLocalMedia(files: FileList | File[]): Promise<{ videos: number; tracks: number }> {
  const list = Array.from(files);
  let videos = 0;
  let tracks = 0;
  for (const file of list) {
    const id = uid();
    const isVideo = file.type.startsWith("video/") || /\.(mp4|mkv|webm|mov|m4v|avi)$/i.test(file.name);
    const isAudio = file.type.startsWith("audio/") || /\.(mp3|m4a|aac|opus|ogg|wav|flac)$/i.test(file.name);
    if (!isVideo && !isAudio) continue;
    await putFile(id, file);
    const objectUrl = URL.createObjectURL(file);
    const duration = await probeDuration(objectUrl, isVideo);
    const title = file.name.replace(/\.[^.]+$/, "");
    if (isVideo) {
      const isShort = duration > 0 && duration <= 60;
      store.update((s) => ({
        ...s,
        videos: [
          {
            id,
            title,
            channel: s.profile.name,
            channelId: "local",
            url: `jodon://local/${id}`,
            thumbnail: "",
            duration,
            views: 0,
            published: file.lastModified || Date.now(),
            description: "ملف محلي على جهازك — يعمل دون اتصال.",
            tags: ["محلي", isShort ? "شورتس" : "فيديو"],
            kind: isShort ? "short" : "video",
            localFileId: id,
            sizeBytes: file.size,
            addedAt: Date.now(),
          },
          ...s.videos,
        ],
      }));
      videos++;
    } else {
      store.update((s) => ({
        ...s,
        tracks: [
          {
            id,
            title,
            artist: "ملف محلي",
            album: "𝒥𝒪 DON",
            fileId: id,
            duration,
            cover: "",
            sizeBytes: file.size,
            addedAt: Date.now(),
          },
          ...s.tracks,
        ],
      }));
      tracks++;
    }
  }
  return { videos, tracks };
}

function probeDuration(url: string, video: boolean): Promise<number> {
  return new Promise((resolve) => {
    const el = document.createElement(video ? "video" : "audio");
    el.preload = "metadata";
    el.src = url;
    const done = (v: number) => {
      el.removeAttribute("src");
      el.load();
      resolve(Number.isFinite(v) ? v : 0);
    };
    el.onloadedmetadata = () => done(el.duration);
    el.onerror = () => done(0);
    window.setTimeout(() => done(0), 3500);
  });
}

/** Generates a real thumbnail frame from a locally stored video. */
export async function videoThumbnail(fileId: string): Promise<string> {
  const blob = await getFile(fileId);
  if (!blob) return "";
  const url = URL.createObjectURL(blob);
  try {
    const video = document.createElement("video");
    video.preload = "metadata";
    video.muted = true;
    video.src = url;
    await new Promise<void>((resolve, reject) => {
      video.onloadeddata = () => resolve();
      video.onerror = () => reject(new Error("decode"));
      window.setTimeout(() => resolve(), 3000);
    });
    video.currentTime = Math.min(1, Math.max(0, (video.duration || 2) / 4));
    await new Promise<void>((r) => { video.onseeked = () => r(); window.setTimeout(r, 1200); });
    const c = document.createElement("canvas");
    c.width = 320; c.height = 180;
    const ctx = c.getContext("2d");
    ctx?.drawImage(video, 0, 0, c.width, c.height);
    return c.toDataURL("image/jpeg", 0.72);
  } catch {
    return "";
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** Real clipboard copy with a fallback for non-secure contexts. */
export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch { /* fall through */ }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}
