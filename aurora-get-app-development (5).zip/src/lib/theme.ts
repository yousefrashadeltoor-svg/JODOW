import { THEME_PHOTOS } from "@/lib/themePhotos";

/**
 * 𝒥𝒪 DON — full theme engine.
 * Every theme controls colors, glass optics, geometry, motion physics and the mesh
 * background. Nothing is hard-coded in a screen: screens read CSS variables only.
 */
export interface ThemeTokens {
  id: string;
  name: string;
  nameEn: string;
  description: string;
  photo: string;
  dark: boolean;
  colors: {
    bg: string;
    bgAlt: string;
    surface: string;
    text: string;
    muted: string;
    a1: string;
    a2: string;
    a3: string;
    success: string;
    warning: string;
    error: string;
    glassTint: string;
    glassStroke: string;
    scrim: string;
  };
  optics: {
    blur: number;
    tintAlpha: number;
    borderWidth: number;
    shadow: number;
    glowStrength: number;
    noise: number;
  };
  geometry: {
    radius: number;
    cardRadius: number;
    squircle: number;
  };
  motion: {
    springStiffness: number;
    springDamping: number;
    duration: number;
    glowSpin: number;
    meshDrift: number;
    stagger: number;
    shimmer: number;
    scalePress: number;
  };
  font: string;
}

const FONT = '"Plus Jakarta Sans","IBM Plex Sans Arabic","Segoe UI",system-ui,sans-serif';

export const THEMES: ThemeTokens[] = [
  {
    id: "aurora",
    name: "أورورا",
    nameEn: "Aurora",
    description: "أزرق ← بنفسجي ← وردي على AMOLED عميق",
    photo: THEME_PHOTOS["aurora"],
    dark: true,
    colors: {
      bg: "#0B0D12", bgAlt: "#11141C", surface: "#161A24",
      text: "#ECF1FF", muted: "#9AA3B8",
      a1: "#4285F4", a2: "#9B72CB", a3: "#D96570",
      success: "#3ED598", warning: "#F5B94B", error: "#F0656B",
      glassTint: "255,255,255", glassStroke: "255,255,255", scrim: "5,7,16",
    },
    optics: { blur: 22, tintAlpha: 0.085, borderWidth: 1, shadow: 0.72, glowStrength: 0.55, noise: 0.035 },
    geometry: { radius: 30, cardRadius: 22, squircle: 4.2 },
    motion: { springStiffness: 420, springDamping: 0.78, duration: 480, glowSpin: 3.6, meshDrift: 18, stagger: 60, shimmer: 1250, scalePress: 0.965 },
    font: FONT,
  },
  {
    id: "ocean",
    name: "المحيط",
    nameEn: "Ocean",
    description: "أزرق عميق، سماوي، فيروزي — هدوء مائي",
    photo: THEME_PHOTOS["ocean"],
    dark: true,
    colors: {
      bg: "#060E18", bgAlt: "#0C1626", surface: "#112236",
      text: "#EAF7FF", muted: "#8BA9C0",
      a1: "#3B82F6", a2: "#06B6D4", a3: "#67E8F9",
      success: "#34D399", warning: "#FBBF24", error: "#FB7185",
      glassTint: "180,230,255", glassStroke: "160,220,255", scrim: "3,10,20",
    },
    optics: { blur: 28, tintAlpha: 0.075, borderWidth: 1.1, shadow: 0.7, glowStrength: 0.42, noise: 0.028 },
    geometry: { radius: 34, cardRadius: 26, squircle: 4.8 },
    motion: { springStiffness: 320, springDamping: 0.86, duration: 620, glowSpin: 5.2, meshDrift: 26, stagger: 76, shimmer: 1600, scalePress: 0.975 },
    font: FONT,
  },
  {
    id: "sunset",
    name: "الغروب",
    nameEn: "Sunset",
    description: "برتقالي، وردي، قرمزي — دفء سينمائي",
    photo: THEME_PHOTOS["sunset"],
    dark: true,
    colors: {
      bg: "#14090C", bgAlt: "#1F1014", surface: "#2A151A",
      text: "#FFF1EC", muted: "#C6A29C",
      a1: "#F97316", a2: "#EC4899", a3: "#F43F5E",
      success: "#4ADE80", warning: "#FBBF24", error: "#FB7185",
      glassTint: "255,210,190", glassStroke: "255,190,170", scrim: "18,5,8",
    },
    optics: { blur: 20, tintAlpha: 0.1, borderWidth: 1, shadow: 0.8, glowStrength: 0.68, noise: 0.045 },
    geometry: { radius: 26, cardRadius: 20, squircle: 3.8 },
    motion: { springStiffness: 520, springDamping: 0.72, duration: 380, glowSpin: 2.8, meshDrift: 14, stagger: 46, shimmer: 980, scalePress: 0.95 },
    font: FONT,
  },
  {
    id: "emerald",
    name: "زمرد",
    nameEn: "Emerald",
    description: "أخضر غابي، ياقوتي، ليموني — طبيعة نقية",
    photo: THEME_PHOTOS["emerald"],
    dark: true,
    colors: {
      bg: "#04120D", bgAlt: "#0A1C16", surface: "#0E2A20",
      text: "#E9FFF3", muted: "#8FB9A4",
      a1: "#10B981", a2: "#34D399", a3: "#A3E635",
      success: "#4ADE80", warning: "#FACC15", error: "#F87171",
      glassTint: "200,255,225", glassStroke: "180,255,215", scrim: "2,12,8",
    },
    optics: { blur: 24, tintAlpha: 0.08, borderWidth: 1, shadow: 0.68, glowStrength: 0.45, noise: 0.04 },
    geometry: { radius: 32, cardRadius: 24, squircle: 4.6 },
    motion: { springStiffness: 360, springDamping: 0.9, duration: 560, glowSpin: 4.4, meshDrift: 22, stagger: 68, shimmer: 1400, scalePress: 0.978 },
    font: FONT,
  },
  {
    id: "mono",
    name: "مونو",
    nameEn: "Mono",
    description: "جرافيت، فضي، فحمي — فخامة هادئة",
    photo: THEME_PHOTOS["mono"],
    dark: true,
    colors: {
      bg: "#0C0D10", bgAlt: "#14161B", surface: "#1C1F25",
      text: "#F2F3F6", muted: "#9398A3",
      a1: "#B8BECC", a2: "#8E95A3", a3: "#D7DBE3",
      success: "#A7D7B4", warning: "#D9C08A", error: "#D99A9A",
      glassTint: "255,255,255", glassStroke: "220,225,235", scrim: "6,7,9",
    },
    optics: { blur: 16, tintAlpha: 0.065, borderWidth: 0.8, shadow: 0.6, glowStrength: 0.22, noise: 0.06 },
    geometry: { radius: 18, cardRadius: 14, squircle: 3.2 },
    motion: { springStiffness: 620, springDamping: 0.95, duration: 300, glowSpin: 8, meshDrift: 40, stagger: 34, shimmer: 1800, scalePress: 0.985 },
    font: FONT,
  },
  {
    id: "neon",
    name: "نيون",
    nameEn: "Neon",
    description: "سماوي، بنفسجي، فوشيا — طاقة ليلية",
    photo: THEME_PHOTOS["neon"],
    dark: true,
    colors: {
      bg: "#08060F", bgAlt: "#100C1C", surface: "#171029",
      text: "#F5EEFF", muted: "#A79BC4",
      a1: "#22D3EE", a2: "#A855F7", a3: "#F0ABFC",
      success: "#4ADE80", warning: "#FBBF24", error: "#FB7185",
      glassTint: "225,200,255", glassStroke: "235,190,255", scrim: "6,3,14",
    },
    optics: { blur: 30, tintAlpha: 0.095, borderWidth: 1.3, shadow: 0.85, glowStrength: 0.9, noise: 0.03 },
    geometry: { radius: 38, cardRadius: 28, squircle: 5.4 },
    motion: { springStiffness: 720, springDamping: 0.62, duration: 340, glowSpin: 2.2, meshDrift: 11, stagger: 38, shimmer: 760, scalePress: 0.94 },
    font: FONT,
  },
];

export const LIGHT_THEMES: ThemeTokens[] = THEMES.map((t) => ({
  ...t,
  id: `${t.id}-light`,
  name: `${t.name} · فاتح`,
  nameEn: `${t.nameEn} Light`,
  dark: false,
  colors: {
    ...t.colors,
    bg: "#F3F5FA", bgAlt: "#FFFFFF", surface: "#FFFFFF",
    text: "#10131A", muted: "#5A6478",
    glassTint: "255,255,255", glassStroke: "20,30,50", scrim: "20,25,40",
  },
  optics: { ...t.optics, tintAlpha: 0.62 },
}));

export const ALL_THEMES = [...THEMES, ...LIGHT_THEMES];

export function themeById(id: string): ThemeTokens {
  return ALL_THEMES.find((t) => t.id === id) ?? THEMES[0];
}

/** Applies a theme to the document root. Every screen reads these variables. */
export function applyTheme(t: ThemeTokens) {
  const r = document.documentElement;
  const c = t.colors;
  const set = (k: string, v: string | number) => r.style.setProperty(k, String(v));
  set("--bg", c.bg);
  set("--bg-alt", c.bgAlt);
  set("--surface", c.surface);
  set("--text", c.text);
  set("--muted", c.muted);
  set("--a1", c.a1);
  set("--a2", c.a2);
  set("--a3", c.a3);
  set("--success", c.success);
  set("--warning", c.warning);
  set("--error", c.error);
  set("--glass-rgb", c.glassTint);
  set("--stroke-rgb", c.glassStroke);
  set("--scrim-rgb", c.scrim);
  set("--tint-alpha", t.optics.tintAlpha);
  set("--blur", `${t.optics.blur}px`);
  set("--border-w", `${t.optics.borderWidth}px`);
  set("--shadow", t.optics.shadow);
  set("--glow", t.optics.glowStrength);
  set("--noise", t.optics.noise);
  set("--radius", `${t.geometry.radius}px`);
  set("--card-radius", `${t.geometry.cardRadius}px`);
  set("--squircle", t.geometry.squircle);
  set("--dur", `${t.motion.duration}ms`);
  set("--stagger", `${t.motion.stagger}ms`);
  set("--glow-spin", `${t.motion.glowSpin}s`);
  set("--mesh-drift", `${t.motion.meshDrift}s`);
  set("--shimmer", `${t.motion.shimmer}ms`);
  set("--press", t.motion.scalePress);
  set("--font", t.font);
  set("--spring", `cubic-bezier(.22, ${Math.min(1, 1.4 - t.motion.springDamping * 0.55)}, .36, 1)`);
  r.style.colorScheme = t.dark ? "dark" : "light";
  r.dataset.theme = t.id;
}
