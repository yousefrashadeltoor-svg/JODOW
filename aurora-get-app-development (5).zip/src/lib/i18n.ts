export type Lang = "ar" | "en";

export const dict = {
  ar: {
    home: "الرئيسية",
    downloads: "التحميلات",
    browser: "المتصفح",
    jodon: "𝒥𝒪 DON",
    music: "الموسيقى",
    tools: "الأدوات",
    library: "المكتبة",
    settings: "الإعدادات",
    preview: "معاينة واجهة التطبيق — Android / Jetpack Compose",
    live: "معاينة حيّة لكل الشاشات",
    liveHint:
      "هذه واجهة الويب مطابقة للتصميم الزجاجي (Aurora Glass) الخاص بتطبيق الأندرويد: بلَور حقيقي، حدود Superellipse، Mesh Gradient متحرك، وتوهج بأسلوب Gemini.",
    modules: "الوحدات (Modules)",
    whatWorks: "ما الذي يعمل فعليًا؟",
    legal:
      "المسؤولية على المستخدم في احترام حقوق النشر — لا تجاوز DRM ولا اشتراكات مدفوعة.",
  },
  en: {
    home: "Home",
    downloads: "Downloads",
    browser: "Browser",
    jodon: "𝒥𝒪 DON",
    music: "Music",
    tools: "Tools",
    library: "Library",
    settings: "Settings",
    preview: "App UI preview — Android / Jetpack Compose",
    live: "Live preview of every screen",
    liveHint:
      "This web preview mirrors the Aurora Glass design system of the Android app: real blur, superellipse edges, animated mesh gradient and Gemini-style glow.",
    modules: "Modules",
    whatWorks: "What actually works?",
    legal:
      "The user is responsible for respecting copyright — no DRM bypass, no paywall circumvention.",
  },
} as const;

export const features = {
  ar: [
    "تحليل خماسي المراحل مع بثّ النتائج فور وصولها",
    "تحميل مجزّأ حتى 32 اتصالًا مع Work-Stealing",
    "استكمال بعد الإيقاف/الإغلاق/إعادة التشغيل",
    "حجم حقيقي مؤكّد أو تقريبي بعلامة ≈",
    "متصفح داخلي + اصطاد ملفات + حجب إعلانات",
    "ضغط Lossless وTransparent مع مقارنة قبل/بعد",
  ],
  en: [
    "Five parallel analysis stages streaming results instantly",
    "Segmented download up to 32 connections with work-stealing",
    "Resume after pause / app kill / device reboot",
    "Confirmed real size, or approximated with the ≈ sign",
    "Internal browser + media sniffer + ad blocking",
    "Lossless & transparent compression with before/after compare",
  ],
};
