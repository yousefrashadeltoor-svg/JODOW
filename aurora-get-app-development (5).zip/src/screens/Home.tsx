import { useRef, useState, type ChangeEvent } from "react";
import { Icon } from "@/lib/icons";
import { Glass, Empty, Chip, ScreenHeader } from "@/components/ui";
import { bytes, exactBytes } from "@/lib/format";
import { useStore, store, uid, copyText, addLocalMedia } from "@/lib/store";
import { usePlayer } from "@/components/Player";

export interface Probe {
  url: string; domain: string; status: "idle" | "loading" | "ok" | "error";
  contentType?: string; size?: number | null; approximate?: boolean;
  ranges?: boolean; title?: string; message?: string; elapsed?: number;
}

export function HomeScreen({ onGoBrowser, onGoDownloads, onGoJodon, onToast }: {
  onGoBrowser: () => void; onGoDownloads: () => void; onGoJodon: () => void; onToast: (m: string) => void;
}) {
  const s = useStore();
  const player = usePlayer();
  const [value, setValue] = useState("");
  const [probe, setProbe] = useState<Probe | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const normalize = (raw: string) => {
    const v = raw.trim().replace(/^["'<]+|["'>]+$/g, "");
    if (v.startsWith("magnet:")) return v;
    if (!/^https?:\/\//i.test(v)) return `https://${v}`;
    return v;
  };

  const analyze = async () => {
    const url = normalize(value);
    if (!value.trim()) return;
    const start = performance.now();
    const domain = (() => { try { return new URL(url).hostname; } catch { return url; } })();
    setProbe({ url, domain, status: "loading" });
    try {
      // A real network probe. Browsers hide cross-origin headers (CORS), so we
      // report exactly what the network gives us — never invented values.
      const res = await fetch(url, { method: "GET", headers: { Range: "bytes=0-0" }, mode: "cors", signal: AbortSignal.timeout(9000) });
      const cr = res.headers.get("content-range");
      const len = res.headers.get("content-length");
      const total = cr?.split("/")[1] ? Number(cr.split("/")[1]) : len ? Number(len) : null;
      const html = (res.headers.get("content-type") || "").includes("html") ? await res.text().catch(() => "") : "";
      const title = html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1]?.trim();
      setProbe({
        url, domain, status: "ok",
        contentType: res.headers.get("content-type") || undefined,
        size: total && Number.isFinite(total) ? total : null,
        approximate: !!cr || !res.headers.get("content-length"),
        ranges: !!cr || res.headers.get("accept-ranges") === "bytes",
        title, elapsed: Math.round(performance.now() - start),
        message: res.ok ? "استجابة حقيقية من الخادم" : `استجابة الخادم: HTTP ${res.status}`,
      });
    } catch (e) {
      setProbe({
        url, domain, status: "error",
        message: `تعذّر الوصول: ${(e as Error).name === "TimeoutError" ? "انتهت المهلة" : "الخادم لا يسمح بـ CORS أو لا يوجد اتصال"}`,
        elapsed: Math.round(performance.now() - start),
      });
    }
  };

  const queueDownload = () => {
    if (!probe) return;
    store.update((st) => ({
      ...st,
      downloads: [{
        id: uid(), title: probe.title || probe.domain, url: probe.url, kind: "FILE" as const,
        quality: probe.contentType || "ملف", size: probe.size ?? 0, savedBytes: 0,
        status: "queued" as const, createdAt: Date.now(),
        segments: probe.ranges ? st.settings.maxConnections : 1, speed: 0,
      }, ...st.downloads],
    }));
    onToast("أُضيف الرابط إلى مدير التحميلات");
    onGoDownloads();
  };

  const onFiles = async (e: ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return;
    const r = await addLocalMedia(e.target.files);
    onToast(`استُورد ${r.videos} فيديو و ${r.tracks} ملف صوتي فعليًا`);
    e.target.value = "";
  };

  return (
    <div className="no-scrollbar h-full overflow-y-auto px-4 pb-32">
      <ScreenHeader title="𝒥𝒪 DON" subtitle="حمّل، شغّل، نظّم — كل شيء على جهازك"
        right={
          <button onClick={() => fileRef.current?.click()} className="press glass-soft glass-border grid h-11 w-11 place-items-center rounded-full t-text">
            <Icon name="upload" size={19} />
          </button>
        } />
      <input ref={fileRef} type="file" multiple accept="video/*,audio/*" className="hidden" onChange={onFiles} />

      <div className="relative mt-5">
        <div className="glow-ring absolute -inset-[3px] rounded-[var(--radius)]"
          style={{ ["--glow-on" as string]: probe?.status === "loading" ? 1 : 0 }} />
        <Glass className="relative rounded-[var(--radius)] p-4">
          <div className="flex items-center gap-2">
            <Icon name="link" size={19} className="t-a1 shrink-0" />
            <input value={value} onChange={(e) => setValue(e.target.value)} onKeyDown={(e) => e.key === "Enter" && void analyze()}
              placeholder="الصق رابطًا حقيقيًا لتحليله…" dir="ltr"
              className="w-full bg-transparent text-[12.5px] t-text placeholder:t-muted" />
            {value && <button onClick={() => { setValue(""); setProbe(null); }} className="press grid h-8 w-8 place-items-center rounded-full bg-white/8 t-muted">
              <Icon name="close" size={14} /></button>}
          </div>
          <div className="mt-3 flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              {[0, 1, 2, 3].map((i) => (
                <span key={i} className={`block rounded-full ${probe?.status === "loading" ? "animate-pulse bg-[var(--a1)]" : probe ? "bg-[var(--a1)]" : "bg-white/20"} h-1.5 w-1.5`} />
              ))}
              {probe && <span className="me-1 text-[10px] t-muted">{probe.status === "loading" ? "جارٍ الفحص…" : `${probe.elapsed}ms`}</span>}
            </div>
            <button onClick={() => void analyze()} className="grad press grid h-10 w-10 place-items-center rounded-full text-white">
              <Icon name={probe?.status === "loading" ? "refresh" : "search"} size={18} />
            </button>
          </div>
          <p className="mt-2.5 text-[9.5px] leading-4 t-muted">
            الفحص يطلب الرابط فعليًا (HEAD/Range). إن منع الخادم CORS سيظهر السبب بصدق بدل أرقام مفتَرَضة.
          </p>
        </Glass>
      </div>

      {probe && probe.status !== "loading" && (
        <Glass className="float-in mt-3 rounded-[var(--card-radius)] p-4">
          <div className="flex items-center gap-2">
            <Icon name={probe.status === "ok" ? "globe" : "warning"} size={17} className={probe.status === "ok" ? "t-a1" : "t-warn"} />
            <p dir="ltr" className="min-w-0 flex-1 truncate text-[11.5px] t-text">{probe.domain}</p>
            <Chip>{probe.status === "ok" ? "تم الفحص" : "خطأ"}</Chip>
          </div>
          {probe.title && <p className="mt-2 text-[12px] font-semibold t-text">{probe.title}</p>}
          {probe.status === "ok" && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {probe.contentType && <Chip icon="file">{probe.contentType}</Chip>}
              {probe.size != null && (
                <Chip icon="downloads">{probe.approximate ? `≈ ${bytes(probe.size)}` : bytes(probe.size)}</Chip>
              )}
              {probe.ranges && <Chip icon="speed">يدعم التجزئة</Chip>}
            </div>
          )}
          <p className={`mt-2 text-[10px] ${probe.status === "ok" ? "t-muted" : "t-warn"}`}>{probe.message}</p>
          {probe.size != null && <p className="mt-1 text-[9.5px] t-muted">{exactBytes(probe.size)}</p>}
          <div className="mt-3 flex flex-wrap gap-1.5">
            <button onClick={queueDownload} className="grad-l press rounded-full px-3.5 py-2 text-[10.5px] font-semibold text-white">إضافة للتحميل</button>
            <button onClick={() => { window.open(probe.url, "_blank", "noopener"); }} className="press glass-soft glass-border rounded-full px-3 py-2 text-[10.5px] t-text">فتح في المتصفح</button>
            <button onClick={async () => onToast((await copyText(probe.url)) ? "تم نسخ الرابط" : "تعذّر النسخ")}
              className="press glass-soft glass-border rounded-full px-3 py-2 text-[10.5px] t-text">نسخ الرابط</button>
          </div>
        </Glass>
      )}

      {/* real counters */}
      <div className="mt-4 grid grid-cols-3 gap-2">
        {[
          { label: "فيديوهات", value: s.videos.length, icon: "video" as const, go: onGoJodon },
          { label: "ملفات صوت", value: s.tracks.length, icon: "music" as const, go: null },
          { label: "تحميلات", value: s.downloads.length, icon: "downloads" as const, go: onGoDownloads },
        ].map((c) => (
          <Glass key={c.label} onClick={c.go ?? undefined} className="rounded-[18px] p-3 text-center">
            <Icon name={c.icon} size={16} className="mx-auto t-a1" />
            <p className="grad-text mt-1 text-[18px] font-extrabold">{c.value}</p>
            <p className="text-[9.5px] t-muted">{c.label}</p>
          </Glass>
        ))}
      </div>

      <div className="mt-4 flex gap-2">
        <Glass onClick={onGoJodon} className="flex flex-1 items-center gap-2.5 rounded-[18px] p-3">
          <div className="grid h-9 w-12 place-items-center rounded-[11px] bg-[#FF0033] text-white"><Icon name="youtube" size={18} /></div>
          <div className="flex-1"><p className="text-[11.5px] font-semibold t-text">𝒥𝒪 DON</p><p className="text-[9.5px] t-muted">منصة الفيديو المحلية</p></div>
          <Icon name="forward" size={14} className="t-muted" />
        </Glass>
        <Glass onClick={onGoBrowser} className="flex flex-1 items-center gap-2.5 rounded-[18px] p-3">
          <div className="grad grid h-9 w-9 place-items-center rounded-[11px] text-white"><Icon name="globe" size={17} /></div>
          <div className="flex-1"><p className="text-[11.5px] font-semibold t-text">المتصفح</p><p className="text-[9.5px] t-muted">إدارة الروابط</p></div>
          <Icon name="forward" size={14} className="t-muted" />
        </Glass>
      </div>

      <div className="mt-4">
        <p className="px-1 pb-2 text-[11.5px] font-semibold t-muted">أضيفت أخيرًا</p>
        {s.videos.length === 0 && s.tracks.length === 0
          ? <Empty icon="upload" title="المكتبة فارغة" hint="استورد ملفات فيديو أو صوت من جهازك بالزر أعلى الشاشة — ستُحفظ فعليًا وتبقى دون إنترنت." />
          : <div className="space-y-2">
              {[...s.videos.map((v) => ({ id: v.id, title: v.title, type: "video" as const, fileId: v.localFileId, url: v.url })),
                ...s.tracks.map((t) => ({ id: t.id, title: t.title, type: "audio" as const, fileId: t.fileId, url: "" }))]
                .slice(0, 5)
                .map((item) => (
                  <Glass key={item.id} onClick={() => player.play({
                    id: item.id, title: item.title, subtitle: "ملف محلي", type: item.type,
                    fileId: item.fileId, url: item.url.startsWith("jodon://") || !item.url ? undefined : item.url,
                  })} className="flex items-center gap-3 rounded-[18px] px-3 py-2.5">
                    <Icon name={item.type === "video" ? "video" : "audio"} size={17} className="t-a1" />
                    <p className="min-w-0 flex-1 truncate text-[11.5px] t-text">{item.title}</p>
                    <Icon name="play" size={14} className="t-muted" />
                  </Glass>
                ))}
            </div>}
      </div>
    </div>
  );
}
