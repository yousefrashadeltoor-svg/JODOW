import { useMemo, useState } from "react";
import { Icon } from "@/lib/icons";
import { bytes } from "@/lib/format";
import { Glass, GlassPill, Empty, ScreenHeader, Tag } from "@/components/ui";
import { useStore, getFile, downloadBlob } from "@/lib/store";
import { formatTime } from "@/lib/media";
import { usePlayer } from "@/components/Player";

export function MusicScreen({ onToast }: { onToast: (m: string) => void }) {
  const s = useStore();
  const player = usePlayer();
  const [view, setView] = useState<"songs" | "albums" | "artists">("songs");
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<string | null>(null);

  const albums = useMemo(() => Array.from(new Set(s.tracks.map((t) => t.album))), [s.tracks]);
  const artists = useMemo(() => Array.from(new Set(s.tracks.map((t) => t.artist))), [s.tracks]);
  const tracks = s.tracks.filter((t) => t.title.toLowerCase().includes(q.toLowerCase()));

  const playAll = () => {
    if (!tracks.length) { onToast("لا ملفات صوتية بعد"); return; }
    const first = tracks[0];
    player.play({ id: first.id, title: first.title, subtitle: `${first.artist} · ${first.album}`, type: "audio", fileId: first.fileId });
  };

  return (
    <div className="no-scrollbar h-full overflow-y-auto px-4 pb-32">
      <ScreenHeader title="الموسيقى" subtitle={`${s.tracks.length} مقطع · ${albums.length} ألبوم`}
        right={<button onClick={playAll} className="grad press grid h-11 w-11 place-items-center rounded-full text-white"><Icon name="play" size={19} /></button>} />

      <div className="mt-3 flex gap-1.5">
        {([["songs", "الأغاني"], ["albums", "الألبومات"], ["artists", "الفنانون"]] as const).map(([id, label]) => (
          <button key={id} onClick={() => { setView(id); setSelected(null); }}>
            <GlassPill className="px-3.5 py-2"><span className={`text-[11px] font-semibold ${view === id ? "t-text" : "t-muted"}`}>{label}</span></GlassPill>
          </button>
        ))}
      </div>

      {view === "songs" && (
        <>
          <Glass className="mt-3 flex items-center gap-2 rounded-full px-3 py-2">
            <Icon name="search" size={15} className="t-muted" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث عن أغنية…"
              className="min-w-0 flex-1 bg-transparent text-[11.5px] t-text placeholder:t-muted" />
          </Glass>
          {tracks.length === 0
            ? <Empty icon="music" title="لا أغاني" hint="استورد ملفات MP3 / WAV / FLAC من الرئيسية. المشغل يعمل محليًا بالكامل مع EQ ومؤقت نوم وتكرار." />
            : <div className="mt-3 space-y-2">
                {tracks.map((t, i) => (
                  <Glass key={t.id} className="flex items-center gap-3 rounded-[18px] px-3 py-2.5">
                    <div className="grad grid h-11 w-11 place-items-center rounded-[13px] text-white"><Icon name="music" size={19} /></div>
                    <button onClick={() => player.play({ id: t.id, title: t.title, subtitle: `${t.artist} · ${t.album}`, type: "audio", fileId: t.fileId })}
                      className="press min-w-0 flex-1 text-start">
                      <p className="truncate text-[11.5px] font-semibold t-text">{t.title}</p>
                      <p className="truncate text-[9.5px] t-muted">{t.artist} · {t.album} · {formatTime(t.duration)}</p>
                    </button>
                    <span className="text-[9.5px] t-muted">{String(i + 1).padStart(2, "0")}</span>
                    <button onClick={async () => { const b = await getFile(t.fileId); if (b) downloadBlob(b, t.title); }}
                      className="press grid h-8 w-8 place-items-center rounded-full bg-white/8 t-text"><Icon name="download" size={14} /></button>
                  </Glass>
                ))}
              </div>}
        </>
      )}

      {view === "albums" && (
        <div className="mt-3 grid grid-cols-2 gap-2.5">
          {albums.length === 0 && <div className="col-span-2"><Empty icon="library" title="لا ألبومات" hint="تُنشأ الألبومات تلقائيًا من ملفاتك الصوتية." /></div>}
          {albums.map((a) => (
            <Glass key={a} onClick={() => setSelected(a)} className="overflow-hidden rounded-[var(--card-radius)]">
              <div className="grad grid h-28 place-items-center text-white"><Icon name="music" size={30} /></div>
              <div className="p-3"><p className="truncate text-[11.5px] font-semibold t-text">{a}</p>
                <p className="text-[9.5px] t-muted">{s.tracks.filter((t) => t.album === a).length} أغنية</p></div>
            </Glass>
          ))}
        </div>
      )}

      {view === "artists" && (
        <div className="mt-3 space-y-2">
          {artists.length === 0 && <Empty icon="audio" title="لا فنانين" hint="تظهر أسماء الفنانين من بيانات ملفاتك الفعلية." />}
          {artists.map((a) => (
            <Glass key={a} className="flex items-center gap-3 rounded-[18px] p-3">
              <div className="grad grid h-11 w-11 place-items-center rounded-full text-white">{a.slice(0, 1)}</div>
              <div className="flex-1"><p className="text-[11.5px] font-semibold t-text">{a}</p>
                <p className="text-[9.5px] t-muted">{s.tracks.filter((t) => t.artist === a).length} مقطع</p></div>
              <Tag>{bytes(s.tracks.filter((t) => t.artist === a).reduce((n, t) => n + t.sizeBytes, 0))}</Tag>
            </Glass>
          ))}
        </div>
      )}

      {selected && (
        <div className="mt-3">
          <p className="px-1 pb-2 text-[11px] t-muted">{selected}</p>
          {s.tracks.filter((t) => t.album === selected).map((t) => (
            <Glass key={t.id} onClick={() => player.play({ id: t.id, title: t.title, subtitle: t.artist, type: "audio", fileId: t.fileId })}
              className="mb-2 flex items-center gap-3 rounded-[16px] px-3 py-2.5">
              <Icon name="play" size={15} className="t-a1" />
              <p className="flex-1 truncate text-[11px] t-text">{t.title}</p>
              <span className="text-[9.5px] t-muted">{formatTime(t.duration)}</span>
            </Glass>
          ))}
        </div>
      )}
    </div>
  );
}
