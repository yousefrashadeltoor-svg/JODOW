import { useRef, useState, type ChangeEvent } from "react";
import { Icon, type IconName } from "@/lib/icons";
import { Glass, ScreenHeader } from "@/components/ui";
import { useStore, store, addLocalMedia, getFile } from "@/lib/store";
import { bytes } from "@/lib/format";
import { usePlayer } from "@/components/Player";

export function ToolsScreen({ onConverter, onCompressor, onToast }: {
  onConverter: () => void; onCompressor: () => void; onToast: (m: string) => void;
}) {
  const s = useStore();
  const player = usePlayer();
  const fileRef = useRef<HTMLInputElement>(null);
  const [bench, setBench] = useState<{ ms: number; mb: number; rate: string } | null>(null);

  const speedTest = async () => {
    // A real measurement: decode/scan an actual local file and time the I/O.
    const track = s.tracks[0] ?? null;
    const video = s.videos.find((v) => v.localFileId) ?? null;
    const id = track?.fileId ?? video?.localFileId;
    if (!id) { onToast("استورد ملفًا أولًا لقياس السرعة فعليًا"); return; }
    const blob = await getFile(id);
    if (!blob) { onToast("الملف غير موجود"); return; }
    const t0 = performance.now();
    const copy = await blob.arrayBuffer();
    const ms = performance.now() - t0;
    const mb = copy.byteLength / (1024 * 1024);
    setBench({ ms, mb, rate: ms > 0 ? `${((mb / (ms / 1000)) * 8).toFixed(0)} MB/s` : "—" });
    store.update((st) => ({ ...st, settings: { ...st.settings, maxConnections: mb > 50 ? 32 : mb > 10 ? 16 : 8 } }));
    onToast("تم القياس واقتراح عدد الاتصالات");
  };

  const items: { icon: IconName; title: string; sub: string; go: () => void }[] = [
    { icon: "converter", title: "المحوّل", sub: "تحويل صوتي حقيقي (PCM / إعادة أخذ العينات)", go: onConverter },
    { icon: "compressor", title: "تصغير الحجم", sub: "Lossless وشفاف — مع رفض الناتج الأكبر", go: onCompressor },
    { icon: "speed", title: "اختبار السرعة", sub: "قياس قراءة ملفك الفعلي واقتراح الاتصالات", go: () => void speedTest() },
    { icon: "compress", title: "القص المرئي", sub: "اسحب على الشكل الموجي وصدّر WAV", go: () => {
      const t = s.tracks[0];
      if (!t) { onToast("استورد ملفًا صوتيًا أولًا"); return; }
      void player.play({ id: t.id, title: t.title, subtitle: t.artist, type: "audio", fileId: t.fileId });
      onToast("افتح «قص مرئي» من المشغل");
    } },
    { icon: "upload", title: "استيراد ملفات", sub: "فيديو وصوت من جهازك → تخزين محلي", go: () => fileRef.current?.click() },
    { icon: "shield", title: "الخصوصية", sub: "لا خادم · لا قاعدة بيانات · لا تتبّع", go: () => onToast("كل البيانات على جهازك فقط") },
  ];

  return (
    <div className="no-scrollbar h-full overflow-y-auto px-4 pb-32">
      <ScreenHeader title="الأدوات" subtitle="كل أداة تنفّذ عملية حقيقية على جهازك" />
      <input ref={fileRef} type="file" multiple accept="video/*,audio/*" className="hidden" onChange={async (e: ChangeEvent<HTMLInputElement>) => {
        if (!e.target.files) return;
        const r = await addLocalMedia(e.target.files);
        onToast(`استُورد ${r.videos} فيديو و ${r.tracks} صوت فعليًا`);
        e.target.value = "";
      }} />
      <div className="mt-3 space-y-2">
        {items.map((t) => (
          <Glass key={t.title} onClick={t.go} className="flex items-center gap-3 rounded-[var(--card-radius)] p-3.5">
            <div className="grad grid h-11 w-11 place-items-center rounded-[15px] text-white"><Icon name={t.icon} size={19} /></div>
            <div className="flex-1"><p className="text-[12px] font-semibold t-text">{t.title}</p><p className="text-[9.5px] t-muted">{t.sub}</p></div>
            <Icon name="forward" size={15} className="t-muted" />
          </Glass>
        ))}
      </div>
      {bench && (
        <Glass className="float-in mt-3 rounded-[18px] p-3">
          <p className="text-[11px] font-semibold t-text">نتيجة القياس الفعلي</p>
          <p className="mt-1 text-[10px] t-muted">{bytes(bench.mb * 1024 * 1024)} قُرئت في {bench.ms.toFixed(1)}ms · {bench.rate}</p>
          <p className="mt-1 text-[10px] t-muted">اقتراح الاتصالات: {s.settings.maxConnections}</p>
        </Glass>
      )}
    </div>
  );
}
