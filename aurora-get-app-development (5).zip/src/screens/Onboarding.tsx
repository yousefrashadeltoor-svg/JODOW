import { Icon, type IconName } from "@/lib/icons";
import { Glass } from "@/components/ui";

export function OnboardingScreen({ onDone }: { onDone: () => void }) {
  const features: { icon: IconName; title: string; subtitle: string }[] = [
    { icon: "youtube", title: "𝒥𝒪 DON", subtitle: "منصة فيديو محلية كاملة — بلا WebView ولا حساب رسمي" },
    { icon: "downloads", title: "تحميل ومشغّل حقيقي", subtitle: "ملفاتك تُشغّل فعليًا مع EQ، مؤقت نوم، تكرار وقص مرئي" },
    { icon: "shield", title: "خصوصية مطلقة", subtitle: "لا خادم، لا قاعدة بيانات، لا تتبّع — بياناتك على جهازك" },
  ];
  return (
    <div className="no-scrollbar relative grid h-full place-items-center overflow-y-auto px-6 py-10">
      <div className="pointer-events-none absolute left-1/2 top-16 h-52 w-52 -translate-x-1/2 rounded-full grad orb blur-2xl opacity-60" />
      <div className="relative w-full">
        <div className="flex flex-col items-center">
          <Icon name="bolt" size={38} className="t-a1" />
          <h1 className="grad-text mt-3 text-[29px] font-extrabold tracking-tight">𝒥𝒪 DON</h1>
          <p className="mt-1 text-[11.5px] t-muted">منصّتك المحلية للفيديو والصوت والتحميل</p>
        </div>
        <Glass className="mt-7 rounded-[var(--radius)] p-4">
          <div className="space-y-3.5">
            {features.map((f) => (
              <div key={f.title} className="flex items-center gap-3">
                <div className="grad grid h-10 w-10 place-items-center rounded-[14px] text-white"><Icon name={f.icon} size={18} /></div>
                <div><p className="text-[12px] font-semibold t-text">{f.title}</p>
                  <p className="text-[9.5px] leading-4 t-muted">{f.subtitle}</p></div>
              </div>
            ))}
          </div>
        </Glass>
        <button onClick={onDone} className="grad-l press mt-6 w-full rounded-full py-4 text-[13px] font-bold text-white">لنبدأ</button>
        <p className="mt-3 text-center text-[9.5px] t-muted">المسؤولية على المستخدم في احترام حقوق النشر</p>
      </div>
    </div>
  );
}
