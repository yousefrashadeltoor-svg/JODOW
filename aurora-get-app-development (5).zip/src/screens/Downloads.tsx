import { useMemo, useState } from "react";
import { Icon } from "@/lib/icons";
import { bytes, speed as fmtSpeed } from "@/lib/format";
import { Glass, GlassPill, ProgressBar, ProgressRing, Empty, ScreenHeader, Chip } from "@/components/ui";
import { useStore, store, getFile, downloadBlob, copyText, type DownloadItem } from "@/lib/store";
import { usePlayer } from "@/components/Player";

const tabs = ["الكل", "جارٍ", "في الانتظار", "مكتمل", "فاشل"] as const;

export function DownloadsScreen({ onToast }: { onToast: (m: string) => void }) {
  const s = useStore();
  const player = usePlayer();
  const [tab, setTab] = useState<(typeof tabs)[number]>("الكل");

  const items = useMemo(() => s.downloads.filter((d) => {
    if (tab === "الكل") return true;
    if (tab === "جارٍ") return d.status === "running";
    if (tab === "في الانتظار") return d.status === "queued" || d.status === "paused";
    if (tab === "مكتمل") return d.status === "completed";
    return d.status === "failed";
  }), [s.downloads, tab]);

  const totalBytes = s.downloads.reduce((a, d) => a + d.savedBytes, 0);

  return (
    <div className="no-scrollbar h-full overflow-y-auto px-4 pb-32">
      <ScreenHeader title="المدير" subtitle={`${s.downloads.length} عنصر · ${bytes(totalBytes)} محفوظ فعليًا`} />
      <div className="no-scrollbar mt-3 flex gap-1.5 overflow-x-auto pb-1">
        {tabs.map((t) => (
          <button key={t} onClick={() => setTab(t)}>
            <GlassPill className="px-3.5 py-2">
              <span className={`text-[11px] font-semibold ${tab === t ? "t-text" : "t-muted"}`}>{t}</span>
            </GlassPill>
          </button>
        ))}
      </div>

      {items.length === 0
        ? <Empty icon="downloads" title="لا توجد تحميلات" hint="أضف رابطًا من الرئيسية أو حمّل فيديو من 𝒥𝒪 DON — ستظهر هنا بسجل حقيقي." />
        : <div className="mt-3 space-y-2.5">{items.map((d) => (
            <Row key={d.id} d={d} onToast={onToast} onPlay={() => {
              if (d.localFileId) player.play({ id: d.id, title: d.title, subtitle: d.quality, type: "video", fileId: d.localFileId });
              else onToast("هذا العنصر رابط فقط — افتحه من المتصفح");
            }} />
          ))}</div>}
    </div>
  );
}

function Row({ d, onToast, onPlay }: { d: DownloadItem; onToast: (m: string) => void; onPlay: () => void }) {
  const progress = d.size ? d.savedBytes / d.size : 0;
  const change = (patch: Partial<DownloadItem>) => store.update((st) => ({
    ...st, downloads: st.downloads.map((x) => x.id === d.id ? { ...x, ...patch } : x),
  }));

  return (
    <Glass className="float-in rounded-[var(--card-radius)] p-3.5">
      <div className="flex items-center gap-3">
        <div className="grad grid h-11 w-11 place-items-center rounded-[15px] text-white">
          <Icon name={d.kind === "AUDIO" ? "audio" : d.kind === "IMAGE" ? "image" : d.kind === "VIDEO" ? "video" : "file"} size={19} />
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[12px] font-semibold t-text">{d.title}</p>
          <p className="truncate text-[10px] t-muted">
            {bytes(d.savedBytes)} / {bytes(d.size)} · {d.quality} · {d.segments} اتصال
          </p>
        </div>
        <Chip active={d.status === "completed"}>{
          { running: "جارٍ", queued: "انتظار", paused: "متوقف", completed: "مكتمل", failed: "فشل" }[d.status]
        }</Chip>
      </div>

      {d.status !== "completed" && <div className="mt-3"><ProgressBar value={progress} indeterminate={d.status === "running" && !d.size} /></div>}
      {d.status === "running" && (
        <div className="mt-2.5 flex items-center gap-3">
          <ProgressRing value={progress} />
          <span className="text-[10px] t-muted">{fmtSpeed(d.speed)} · {Math.round(progress * 100)}%</span>
        </div>
      )}

      <div className="no-scrollbar mt-3 flex gap-1.5 overflow-x-auto">
        <Mini icon={d.status === "paused" ? "play" : "pause"} label={d.status === "paused" ? "استكمال" : "إيقاف"}
          onClick={() => change({ status: d.status === "paused" ? "running" : "paused" })} />
        <Mini icon="refresh" label="إعادة" onClick={() => change({ status: "queued", savedBytes: 0 })} />
        <Mini icon="copy" label="نسخ الرابط" onClick={async () => onToast((await copyText(d.url)) ? "تم نسخ الرابط" : "تعذّر النسخ")} />
        <Mini icon="play" label="فتح" onClick={onPlay} />
        <Mini icon="download" label="حفظ الملف" onClick={async () => {
          if (!d.localFileId) { window.open(d.url, "_blank", "noopener"); onToast("فُتح الرابط لتنزيله"); return; }
          const blob = await getFile(d.localFileId);
          if (blob) { downloadBlob(blob, d.title); onToast(`تم حفظ ${bytes(blob.size)}`); }
        }} />
        <Mini icon="share" label="مشاركة" onClick={() => {
          if (navigator.share) void navigator.share({ title: d.title, url: d.url }).catch(() => {});
          else void copyText(d.url);
        }} />
        <Mini icon="trash" label="حذف" onClick={() => store.update((st) => ({ ...st, downloads: st.downloads.filter((x) => x.id !== d.id) }))} />
      </div>
    </Glass>
  );
}

function Mini({ icon, label, onClick }: { icon: Parameters<typeof Icon>[0]["name"]; label: string; onClick: () => void }) {
  return (
    <button onClick={onClick}>
      <GlassPill className="px-2.5 py-1.5">
        <span className="inline-flex items-center gap-1.5 whitespace-nowrap text-[10px] t-muted">
          <Icon name={icon} size={12} />{label}
        </span>
      </GlassPill>
    </button>
  );
}
