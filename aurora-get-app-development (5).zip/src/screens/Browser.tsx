import { useState } from "react";
import { Icon } from "@/lib/icons";
import { Glass, Empty, ScreenHeader, Chip } from "@/components/ui";
import { useStore, store, uid, copyText, type AppState } from "@/lib/store";

type SavedLink = AppState["browserLinks"][number];

/** Real link manager. Opening a link opens the actual URL in a real browser tab. */
export function BrowserScreen({ onToast }: { onToast: (m: string) => void }) {
  const s = useStore();
  const [url, setUrl] = useState("");
  const [blocked] = useState(0);
  const links = s.browserLinks;

  const setLinks = (next: SavedLink[]) => store.update((st) => ({ ...st, browserLinks: next }));

  const open = () => {
    const raw = url.trim();
    if (!raw) return;
    const normalized = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
    const conn = (navigator as Navigator & { connection?: { type?: string } }).connection;
    if (s.settings.wifiOnly && conn?.type === "cellular") {
      onToast("ميزة «Wi‑Fi فقط» مفعّلة — اتصل بشبكة Wi‑Fi أولًا");
      return;
    }
    window.open(normalized, "_blank", "noopener");
    let domain = normalized;
    try { domain = new URL(normalized).hostname; } catch { /* keep */ }
    setLinks([{ id: uid(), url: normalized, title: domain, at: Date.now() }, ...links].slice(0, 80));
    onToast("فُتح الرابط في تبويب حقيقي");
    setUrl("");
  };

  return (
    <div className="no-scrollbar h-full overflow-y-auto px-4 pb-32">
      <ScreenHeader title="المتصفح" subtitle="روابطك الحقيقية — محفوظة على الجهاز" />
      <Glass className="mt-3 rounded-[var(--card-radius)] p-3">
        <div className="flex items-center gap-2">
          <Icon name="globe" size={16} className="t-a1" />
          <input value={url} onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => e.key === "Enter" && open()}
            dir="ltr" placeholder="https://…" className="min-w-0 flex-1 bg-transparent text-[12px] t-text placeholder:t-muted" />
          <button onClick={open} className="grad press grid h-9 w-9 place-items-center rounded-full text-white"><Icon name="forward" size={16} /></button>
        </div>
        <div className="mt-2 flex flex-wrap gap-1.5">
          <Chip icon="shield">{blocked} محجوب</Chip>
          <Chip icon="lock">جلسة محلية</Chip>
          <Chip icon="wifi">يعمل دون إنترنت للروابط المحفوظة</Chip>
        </div>
      </Glass>

      <div className="mt-3">
        {links.length === 0
          ? <Empty icon="globe" title="لا روابط محفوظة" hint="افتح رابطًا من الأعلى ليُحفظ محليًا. في تطبيق Android يوجد WebView كامل مع Sniffer و AdBlock وحل تحديات Cloudflare." />
          : <div className="space-y-2">
              {links.map((l) => (
                <Glass key={l.id} className="flex items-center gap-3 rounded-[18px] px-3 py-2.5">
                  <Icon name="link" size={16} className="t-a1" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[11.5px] font-semibold t-text">{l.title}</p>
                    <p dir="ltr" className="truncate text-[9.5px] t-muted">{l.url}</p>
                  </div>
                  <button onClick={() => window.open(l.url, "_blank", "noopener")} className="press grid h-8 w-8 place-items-center rounded-full bg-white/8 t-text"><Icon name="expand" size={14} /></button>
                  <button onClick={async () => onToast((await copyText(l.url)) ? "تم نسخ الرابط" : "تعذّر النسخ")} className="press grid h-8 w-8 place-items-center rounded-full bg-white/8 t-text"><Icon name="copy" size={14} /></button>
                  <button onClick={() => setLinks(links.filter((x) => x.id !== l.id))} className="press grid h-8 w-8 place-items-center rounded-full bg-white/8 t-muted"><Icon name="trash" size={14} /></button>
                </Glass>
              ))}
            </div>}
      </div>
    </div>
  );
}
