import { useRef, useState, type ChangeEvent } from "react";
import { Icon } from "@/lib/icons";
import { bytes, exactBytes } from "@/lib/format";
import { Glass, GlassPill, Empty, ScreenHeader, Tag, ProgressBar } from "@/components/ui";
import { useStore, store, getFile, putFile, downloadBlob, uid } from "@/lib/store";
import { decode, encodeWav, encodeWavResampled } from "@/lib/media";

interface Result { before: number; after: number; name: string; blob: Blob | null; note: string }

export function CompressorScreen({ onToast }: { onToast: (m: string) => void }) {
  const s = useStore();
  const [mode, setMode] = useState<"lossless" | "transparent">("lossless");
  const [fileId, setFileId] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const imageRef = useRef<HTMLInputElement>(null);
  const [image, setImage] = useState<File | null>(null);

  const sources = s.tracks.map((t) => ({ id: t.fileId, name: t.title, size: t.sizeBytes, type: "audio" as const }));

  const runAudio = async () => {
    const track = s.tracks.find((t) => t.fileId === fileId);
    if (!track) { onToast("اختر ملفًا صوتيًا أولًا"); return; }
    setBusy(true); setResult(null);
    try {
      const blob = await getFile(track.fileId);
      if (!blob) throw new Error("الملف غير موجود على الجهاز");
      const buf = await decode(blob);
      const out = mode === "lossless"
        ? encodeWav(buf, 0, buf.duration)                    // bit-exact PCM re-package
        : encodeWavResampled(buf, 22050, true);             // genuinely smaller, transparent
      const improved = out.size < blob.size;
      setResult({
        before: blob.size, after: out.size, name: track.title,
        blob: improved ? out : null,
        note: improved
          ? `وفّر ${bytes(blob.size - out.size)} فعليًا`
          : "الناتج ليس أصغر من الأصل — لن نعرضه كتحسين (الملف الأصلي محفوظ كما هو).",
      });
      if (improved) {
        store.update((st) => ({ ...st, stats: { ...st.stats, bytesSaved: st.stats.bytesSaved + (blob.size - out.size) } }));
      }
    } catch (e) { setResult({ before: 0, after: 0, name: "", blob: null, note: `تعذّر الضغط: ${(e as Error).message}` }); }
    finally { setBusy(false); }
  };

  const runImage = async () => {
    if (!image) return;
    setBusy(true); setResult(null);
    try {
      const bitmap = await createImageBitmap(image);
      const canvas = document.createElement("canvas");
      const scale = mode === "transparent" ? 0.85 : 1;
      canvas.width = Math.round(bitmap.width * scale);
      canvas.height = Math.round(bitmap.height * scale);
      canvas.getContext("2d")?.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      const mime = mode === "transparent" ? "image/webp" : "image/png";
      const quality = mode === "transparent" ? 0.86 : undefined;
      const out: Blob | null = await new Promise((resolve) => canvas.toBlob(resolve, mime, quality));
      if (!out) throw new Error("تعذّر ترميز الصورة");
      const improved = out.size < image.size;
      setResult({ before: image.size, after: out.size, name: image.name, blob: improved ? out : null,
        note: improved ? `وفّر ${bytes(image.size - out.size)} فعليًا` : "الناتج ليس أصغر — لن نستبدل الأصل." });
    } catch (e) { setResult({ before: 0, after: 0, name: "", blob: null, note: `تعذّر الضغط: ${(e as Error).message}` }); }
    finally { setBusy(false); }
  };

  const saveResult = async () => {
    if (!result?.blob) { onToast("لا يوجد ناتج أصغر لحفظه"); return; }
    const id = uid();
    await putFile(id, result.blob);
    const isAudio = result.blob.type.startsWith("audio/");
    if (isAudio) store.update((st) => ({ ...st, tracks: [{ id, title: `${result.name} · مضغوط`, artist: "𝒥𝒪 DON", album: "المعالجة المحلية",
      fileId: id, duration: 0, cover: "", sizeBytes: result.blob!.size, addedAt: Date.now() }, ...st.tracks] }));
    downloadBlob(result.blob, `${result.name}-compressed.${isAudio ? "wav" : "webp"}`);
    onToast("حُفظ ملف جديد — الأصل لم يتغيّر");
  };

  return (
    <div className="no-scrollbar h-full overflow-y-auto px-4 pb-32">
      <ScreenHeader title="التصغير" subtitle="ضغط حقيقي على جهازك — بلا خادم" />
      <div className="mt-3 flex gap-1.5">
        {([["lossless", "بدون أي فقد"], ["transparent", "شفاف بصريًا"]] as const).map(([id, label]) => (
          <button key={id} onClick={() => { setMode(id); setResult(null); }}>
            <GlassPill className="px-3.5 py-2"><span className={`text-[11px] font-semibold ${mode === id ? "t-text" : "t-muted"}`}>{label}</span></GlassPill>
          </button>
        ))}
      </div>
      <p className="mt-2 px-1 text-[10px] t-muted">
        {mode === "lossless" ? "إعادة حزم PCM بدون تغيير أي عينة — أو PNG بلا فقد." : "إعادة ترميز فعلية 22kHz mono / WebP 86% — مع رفض الناتج إن لم يكن أصغر."}
      </p>

      <p className="mt-4 px-1 pb-2 text-[11px] font-semibold t-muted">الملفات الصوتية</p>
      {sources.length === 0
        ? <Empty icon="audio" title="لا ملفات صوتية" hint="استورد MP3/WAV من الرئيسية ليظهر هنا." />
        : <div className="space-y-2">{sources.slice(0, 6).map((src) => (
            <Glass key={src.id} onClick={() => { setFileId(src.id); setImage(null); }}
              className={`flex items-center gap-3 rounded-[18px] px-3 py-2.5 ${fileId === src.id ? "ring-a1" : ""}`}>
              <Icon name="audio" size={16} className="t-a1" />
              <p className="min-w-0 flex-1 truncate text-[11.5px] t-text">{src.name}</p>
              <span className="text-[9.5px] t-muted">{bytes(src.size)}</span>
            </Glass>
          ))}</div>}

      <div className="mt-3">
        <button onClick={() => imageRef.current?.click()} className="press glass-soft glass-border w-full rounded-[18px] px-3 py-3 text-[11px] t-text">
          {image ? `صورة مختارة: ${image.name} (${bytes(image.size)})` : "اختيار صورة لضغطها فعليًا"}
        </button>
        <input ref={imageRef} type="file" accept="image/*" className="hidden" onChange={(e: ChangeEvent<HTMLInputElement>) => {
          setImage(e.target.files?.[0] ?? null); setFileId(""); setResult(null);
        }} />
      </div>

      <button onClick={() => void (image ? runImage() : runAudio())} disabled={busy}
        className="grad-l press mt-4 w-full rounded-full py-3 text-[12px] font-bold text-white">
        {busy ? "جارٍ المعالجة الفعلية…" : "ابدأ الضغط"}
      </button>
      {busy && <div className="mt-2"><ProgressBar value={0.5} indeterminate /></div>}

      {result && (
        <Glass className="float-in mt-3 rounded-[var(--card-radius)] p-4">
          <div className="flex items-center gap-2">
            <p className="min-w-0 flex-1 truncate text-[12px] font-semibold t-text">{result.name || "نتيجة"}</p>
            {result.blob && <Tag tone="ok"><Icon name="spark" size={11} />وفّر {bytes(result.before - result.after)}</Tag>}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2 text-[10.5px]">
            <div><p className="t-muted">قبل</p><p className="t-text">{exactBytes(result.before)}</p></div>
            <div><p className="t-muted">بعد</p><p className="t-text">{exactBytes(result.after)}</p></div>
          </div>
          <p className={`mt-2 text-[10.5px] leading-5 ${result.blob ? "t-ok" : "t-warn"}`}>{result.note}</p>
          {result.blob && (
            <div className="mt-3 flex gap-1.5">
              <button onClick={() => void saveResult()} className="grad-l press rounded-full px-3.5 py-2 text-[10.5px] font-semibold text-white">حفظ ملف جديد</button>
              <button onClick={() => result.blob && downloadBlob(result.blob, `${result.name}-compressed`)}
                className="press glass-soft glass-border rounded-full px-3 py-2 text-[10.5px] t-text">تنزيل فقط</button>
            </div>
          )}
        </Glass>
      )}
      <p className="mt-3 px-1 text-[9.5px] leading-4 t-muted">الأصل لا يُستبدل أبدًا. الناتج ملف جديد، وإن لم يصغُر فعليًا يقول التطبيق ذلك بصدق.</p>
    </div>
  );
}
