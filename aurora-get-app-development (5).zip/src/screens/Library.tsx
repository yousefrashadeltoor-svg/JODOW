import { useMemo, useState } from "react";
import { Icon } from "@/lib/icons";
import { bytes } from "@/lib/format";
import { Glass, GlassPill, Empty, ScreenHeader, Tag } from "@/components/ui";
import { useStore, store, deleteFile, getFile, downloadBlob } from "@/lib/store";
import { formatTime } from "@/lib/media";
import { usePlayer } from "@/components/Player";

export function LibraryScreen({ onToast }: { onToast: (m: string) => void }) {
  const s = useStore();
  const player = usePlayer();
  const [layout, setLayout] = useState(s.settings.layout);
  const [filter, setFilter] = useState("الكل");
  const [q, setQ] = useState("");

  const items = useMemo(() => {
    const all = [
      ...s.videos.map((v) => ({ id: v.id, fileId: v.localFileId ?? "", title: v.title, kind: "VIDEO" as const,
        size: v.sizeBytes ?? 0, duration: v.duration, cover: v.thumbnail, at: v.addedAt })),
      ...s.tracks.map((t) => ({ id: t.id, fileId: t.fileId, title: t.title, kind: "AUDIO" as const,
        size: t.sizeBytes, duration: t.duration, cover: t.cover, at: t.addedAt })),
    ];
    return all.filter((i) => (filter === "الكل" || (filter === "فيديو" ? i.kind === "VIDEO" : i.kind === "AUDIO"))
      && i.title.toLowerCase().includes(q.toLowerCase()));
  }, [s.videos, s.tracks, filter, q]);

  const remove = async (id: string, fileId: string, kind: string) => {
    if (fileId) await deleteFile(fileId);
    store.update((st) => ({
      ...st,
      videos: kind === "VIDEO" ? st.videos.filter((v) => v.id !== id) : st.videos,
      tracks: kind === "AUDIO" ? st.tracks.filter((t) => t.id !== id) : st.tracks,
    }));
    onToast("حُذف الملف من جهازك");
  };

  return (
    <div className="no-scrollbar h-full overflow-y-auto px-4 pb-32">
      <ScreenHeader title="المكتبة" subtitle={`${items.length} ملف فعلي على الجهاز`}
        right={<button onClick={() => setLayout(layout === "grid" ? "list" : "grid")}
          className="press glass-soft glass-border grid h-11 w-11 place-items-center rounded-full t-text">
          <Icon name={layout === "grid" ? "list" : "grid"} size={19} /></button>} />

      <Glass className="mt-3 flex items-center gap-2 rounded-full px-3 py-2">
        <Icon name="search" size={15} className="t-muted" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث في ملفاتك…"
          className="min-w-0 flex-1 bg-transparent text-[11.5px] t-text placeholder:t-muted" />
      </Glass>

      <div className="mt-2 flex gap-1.5">
        {["الكل", "فيديو", "صوت"].map((f) => (
          <button key={f} onClick={() => setFilter(f)}>
            <GlassPill className="px-3.5 py-2"><span className={`text-[11px] font-semibold ${filter === f ? "t-text" : "t-muted"}`}>{f}</span></GlassPill>
          </button>
        ))}
      </div>

      {items.length === 0
        ? <Empty icon="library" title="المكتبة فارغة" hint="استورد ملفاتك من الرئيسية أو من 𝒥𝒪 DON — تُحفظ في التخزين المحلي للجهاز وتعمل دون إنترنت." />
        : layout === "grid"
          ? <div className="mt-3 grid grid-cols-2 gap-2.5">
              {items.map((item) => (
                <Glass key={item.id} className="overflow-hidden rounded-[var(--card-radius)]">
                  <div onClick={() => player.play({ id: item.id, title: item.title, subtitle: "ملف محلي",
                    type: item.kind === "VIDEO" ? "video" : "audio", fileId: item.fileId })}
                    className="press relative grid h-28 place-items-center bg-black/25"
                    style={item.cover ? { backgroundImage: `url(${item.cover})`, backgroundSize: "cover" } : undefined}>
                    <div className="grad grid h-11 w-11 place-items-center rounded-full text-white">
                      <Icon name={item.kind === "VIDEO" ? "video" : "audio"} size={19} />
                    </div>
                    <span className="absolute bottom-1.5 end-1.5"><Tag>{formatTime(item.duration)}</Tag></span>
                  </div>
                  <div className="p-2.5">
                    <p className="truncate text-[11px] font-semibold t-text">{item.title}</p>
                    <div className="mt-1 flex items-center justify-between">
                      <span className="text-[9.5px] t-muted">{bytes(item.size)}</span>
                      <button onClick={() => void remove(item.id, item.fileId, item.kind)} className="press t-muted"><Icon name="trash" size={13} /></button>
                    </div>
                  </div>
                </Glass>
              ))}
            </div>
          : <div className="mt-3 space-y-2">
              {items.map((item) => (
                <Glass key={item.id} className="flex items-center gap-3 rounded-[18px] px-3 py-2.5">
                  <Icon name={item.kind === "VIDEO" ? "video" : "audio"} size={17} className="t-a1" />
                  <div onClick={() => player.play({ id: item.id, title: item.title, subtitle: "ملف محلي",
                    type: item.kind === "VIDEO" ? "video" : "audio", fileId: item.fileId })}
                    className="press min-w-0 flex-1">
                    <p className="truncate text-[11.5px] font-semibold t-text">{item.title}</p>
                    <p className="text-[9.5px] t-muted">{bytes(item.size)} · {formatTime(item.duration)}</p>
                  </div>
                  <button onClick={async () => { const b = await getFile(item.fileId); if (b) downloadBlob(b, item.title); }}
                    className="press grid h-8 w-8 place-items-center rounded-full bg-white/8 t-text"><Icon name="download" size={14} /></button>
                  <button onClick={() => void remove(item.id, item.fileId, item.kind)} className="press grid h-8 w-8 place-items-center rounded-full bg-white/8 t-muted"><Icon name="trash" size={14} /></button>
                </Glass>
              ))}
            </div>}
    </div>
  );
}
