import { useState } from "react";
import { Icon } from "@/lib/icons";
import { bytes } from "@/lib/format";
import { Glass, GlassPill, Empty, ScreenHeader, ProgressBar, Tag } from "@/components/ui";
import { useStore, store, getFile, putFile, downloadBlob, uid } from "@/lib/store";
import { decode, encodeWav, encodeWavResampled, formatTime } from "@/lib/media";

const TARGETS = [
  { id: "wav44", label: "WAV 44.1kHz", rate: 44100, mono: false, note: "جودة استوديو — بلا فقد" },
  { id: "wav32", label: "WAV 32kHz", rate: 32000, mono: false, note: "استريو متوازن" },
  { id: "wav22m", label: "WAV 22kHz Mono", rate: 22050, mono: true, note: "أصغر حجمًا — شفاف سمعيًا" },
  { id: "wav16m", label: "WAV 16kHz Mono", rate: 16000, mono: true, note: "مناسب للكلام والنغمة" },
  { id: "copy", label: "نسخ PCM الأصلي", rate: 0, mono: false, note: "إعادة حزم بلا أي تغيير" },
];

export function ConverterScreen({ onToast }: { onToast: (m: string) => void }) {
  const s = useStore();
  const [fileId, setFileId] = useState("");
  const [target, setTarget] = useState(TARGETS[0].id);
  const [busy, setBusy] = useState(false);
  const [log, setLog] = useState<string[]>([]);

  const convert = async () => {
    const track = s.tracks.find((t) => t.fileId === fileId);
    const t = TARGETS.find((x) => x.id === target)!;
    if (!track) { onToast("اختر ملفًا أولًا"); return; }
    setBusy(true); setLog(["فك ترميز الملف فعليًا…"]);
    try {
      const blob = await getFile(track.fileId);
      if (!blob) throw new Error("الملف غير موجود");
      const buf = await decode(blob);
      setLog((l) => [...l, `تم الفك: ${buf.sampleRate}Hz · ${buf.numberOfChannels} قناة · ${formatTime(buf.duration)}`]);
      const out = t.id === "copy" ? encodeWav(buf, 0, buf.duration) : encodeWavResampled(buf, t.rate, t.mono);
      setLog((l) => [...l, `تم الترميز: ${t.label} · ${bytes(out.size)}`, "حفظ الناتج كملف جديد…"]);
      const id = uid();
      await putFile(id, out);
      store.update((st) => ({ ...st, tracks: [{ id, title: `${track.title} · ${t.label}`, artist: track.artist,
        album: "تحويلات 𝒥𝒪 DON", fileId: id, duration: buf.duration, cover: "", sizeBytes: out.size,
        addedAt: Date.now() }, ...st.tracks] }));
      downloadBlob(out, `${track.title}-${t.id}.wav`);
      setLog((l) => [...l, "اكتمل — الأصل لم يتغيّر."]);
      onToast("تم التحويل الفعلي وحفظ الملف");
    } catch (e) { setLog((l) => [...l, `خطأ: ${(e as Error).message}`]); }
    finally { setBusy(false); }
  };

  return (
    <div className="no-scrollbar h-full overflow-y-auto px-4 pb-32">
      <ScreenHeader title="المحوّل" subtitle="تحويل صوتي حقيقي عبر Web Audio" />
      <p className="mt-3 px-1 pb-2 text-[11px] font-semibold t-muted">الملف المصدر</p>
      {s.tracks.length === 0
        ? <Empty icon="audio" title="لا ملفات للتحويل" hint="استورد ملفًا صوتيًا من الرئيسية أولًا." />
        : <div className="space-y-2">{s.tracks.slice(0, 6).map((t) => (
            <Glass key={t.id} onClick={() => setFileId(t.fileId)}
              className={`flex items-center gap-3 rounded-[18px] px-3 py-2.5 ${fileId === t.fileId ? "ring-a1" : ""}`}>
              <Icon name="audio" size={16} className="t-a1" />
              <div className="min-w-0 flex-1"><p className="truncate text-[11.5px] t-text">{t.title}</p>
                <p className="text-[9.5px] t-muted">{bytes(t.sizeBytes)} · {formatTime(t.duration)}</p></div>
            </Glass>
          ))}</div>}

      <p className="mt-4 px-1 pb-2 text-[11px] font-semibold t-muted">الصيغة الهدف</p>
      <div className="flex flex-wrap gap-1.5">
        {TARGETS.map((t) => (
          <button key={t.id} onClick={() => setTarget(t.id)}>
            <GlassPill className="px-3 py-1.5"><span className={`text-[10.5px] font-semibold ${target === t.id ? "t-text" : "t-muted"}`}>{t.label}</span></GlassPill>
          </button>
        ))}
      </div>
      <p className="mt-2 px-1 text-[10px] t-muted">{TARGETS.find((t) => t.id === target)?.note}</p>

      <button onClick={() => void convert()} disabled={busy}
        className="grad-l press mt-4 w-full rounded-full py-3 text-[12px] font-bold text-white">
        {busy ? "جارٍ التحويل…" : "ابدأ التحويل"}
      </button>
      {busy && <div className="mt-2"><ProgressBar value={0.6} indeterminate /></div>}

      {log.length > 0 && (
        <Glass className="mt-3 rounded-[18px] p-3">
          <p className="mb-2 text-[11px] font-semibold t-text">سجل العملية</p>
          {log.map((line, i) => <p key={i} className="text-[10px] leading-5 t-muted">• {line}</p>)}
          {log.at(-1)?.startsWith("اكتمل") && <div className="mt-2"><Tag tone="ok">تم بنجاح</Tag></div>}
        </Glass>
      )}
    </div>
  );
}
