import { useRef, useState, type ChangeEvent } from "react";
import { Icon } from "@/lib/icons";
import { Glass, GlassPill, ScreenHeader, Toggle, SectionTitle, Tag, Chip } from "@/components/ui";
import { ALL_THEMES, themeById } from "@/lib/theme";
import { useStore, store, exportState, importState, downloadBlob } from "@/lib/store";
import { bytes } from "@/lib/format";

export function SettingsScreen({ onToast }: { onToast: (m: string) => void }) {
  const s = useStore();
  const active = themeById(s.settings.themeId);
  const importRef = useRef<HTMLInputElement>(null);
  const [showLight, setShowLight] = useState(false);
  const themes = ALL_THEMES.filter((t) => t.dark === !showLight);

  const set = <K extends keyof typeof s.settings>(key: K, value: (typeof s.settings)[K]) =>
    store.update((st) => ({ ...st, settings: { ...st.settings, [key]: value } }));

  const doExport = async (withFiles: boolean) => {
    const blob = await exportState(withFiles);
    downloadBlob(blob, `JODON-backup-${new Date().toISOString().slice(0, 10)}.json`);
    onToast(`تم التصدير (${bytes(blob.size)})`);
  };

  return (
    <div className="no-scrollbar h-full overflow-y-auto px-4 pb-32">
      <ScreenHeader title="الإعدادات" subtitle={`الثيم النشط: ${active.name}`} />

      <div className="mt-3">
        <div className="flex items-center justify-between px-1 pb-2">
          <SectionTitle>الثيمات · صور واقعية</SectionTitle>
          <button onClick={() => setShowLight(!showLight)}>
            <Chip active={showLight}>{showLight ? "فاتح" : "داكن"}</Chip>
          </button>
        </div>

        <Glass className="mb-3 overflow-hidden rounded-[var(--card-radius)] p-3">
          <div className="relative h-28 overflow-hidden rounded-[16px] bg-cover bg-center"
            style={{ backgroundImage: `url(${active.photo})` }}>
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
            <div className="absolute bottom-2 start-3">
              <p className="text-[13px] font-bold text-white">{active.name}</p>
              <p className="text-[9.5px] text-white/75">{active.description}</p>
            </div>
            <span className="absolute end-2 top-2"><Tag tone="ok">مفعّل</Tag></span>
          </div>
          <div className="mt-2 flex items-center gap-1.5">
            {[active.colors.a1, active.colors.a2, active.colors.a3, active.colors.bg, active.colors.text].map((c, i) => (
              <span key={i} className="h-5 flex-1 rounded-full ring-1 ring-white/15" style={{ background: c }} />
            ))}
          </div>
          <p className="mt-2 text-[9.5px] t-muted">
            يتحكّم الثيم في: الألوان، البلَور، الحدود، الانحناء، سرعة الأنيميشن، نوابض Spring، التوهج، وحركة الخلفية.
          </p>
        </Glass>

        <div className="no-scrollbar flex gap-2.5 overflow-x-auto pb-2">
          {themes.map((t) => (
            <button key={t.id} onClick={() => { set("themeId", t.id); onToast(`تم تطبيق ثيم ${t.name}`); }}
              className={`press relative h-[132px] w-[106px] shrink-0 overflow-hidden rounded-[18px] bg-cover bg-center ${t.id === active.id ? "ring-2 ring-[var(--a1)]" : "ring-1 ring-white/12"}`}
              style={{ backgroundImage: `url(${t.photo})` }}>
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/10 to-transparent" />
              <div className="absolute bottom-0 start-0 end-0 p-2 text-start">
                <p className="truncate text-[10.5px] font-bold text-white">{t.name}</p>
                <div className="mt-1 flex gap-0.5">
                  {[t.colors.a1, t.colors.a2, t.colors.a3].map((c, i) => (
                    <span key={i} className="h-1.5 flex-1 rounded-full" style={{ background: c }} />
                  ))}
                </div>
                <p className="mt-1 text-[8.5px] text-white/70">{t.motion.duration}ms · {t.optics.blur}px blur</p>
              </div>
              {t.id === active.id && <span className="absolute end-1.5 top-1.5 grid h-5 w-5 place-items-center rounded-full bg-white text-black"><Icon name="check" size={12} /></span>}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4">
        <SectionTitle>الحركة والتصميم</SectionTitle>
        <Glass className="space-y-3 rounded-[var(--card-radius)] p-4">
          {([
            ["animations", "الأنيميشنات", s.settings.animations],
            ["reducedMotion", "تقليل الحركة", s.settings.reducedMotion],
            ["meshBackground", "خلفية Mesh متحركة", s.settings.meshBackground],
            ["haptics", "الاستجابة اللمسية", s.settings.haptics],
          ] as const).map(([key, label, value]) => (
            <div key={key} className="flex items-center justify-between">
              <p className="text-[12px] t-text">{label}</p>
              <Toggle value={value} onChange={(v) => set(key, v)} />
            </div>
          ))}
          <div className="border-t border-white/10 pt-3">
            <div className="flex items-center justify-between">
              <p className="text-[12px] t-text">مدة الانتقالات</p><span className="text-[10px] t-muted">{active.motion.duration}ms</span>
            </div>
            <p className="mt-1 text-[9.5px] t-muted">مشتقة من ثيم {active.name} — غيّر الثيم لتغيير فيزياء الحركة كاملة.</p>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-[12px] t-text">اللغة</p>
            <div className="flex gap-1.5">
              {(["ar", "en"] as const).map((l) => (
                <button key={l} onClick={() => set("lang", l)}>
                  <GlassPill className="px-3 py-1.5"><span className={`text-[10px] ${s.settings.lang === l ? "t-text" : "t-muted"}`}>{l === "ar" ? "العربية" : "English"}</span></GlassPill>
                </button>
              ))}
            </div>
          </div>
        </Glass>
      </div>

      <div className="mt-4">
        <SectionTitle>التحميل والمشغّل</SectionTitle>
        <Glass className="space-y-3 rounded-[var(--card-radius)] p-4">
          <div className="flex items-center justify-between"><p className="text-[12px] t-text">الحد الأقصى للاتصالات</p><span className="text-[10px] t-muted">{s.settings.maxConnections}</span></div>
          <div className="flex gap-1.5">
            {[8, 16, 24, 32].map((c) => (
              <button key={c} onClick={() => set("maxConnections", c)}>
                <GlassPill className="px-3 py-1.5"><span className={`text-[10.5px] font-semibold ${s.settings.maxConnections === c ? "t-text" : "t-muted"}`}>{c}</span></GlassPill>
              </button>
            ))}
          </div>
          {([["wifiOnly", "Wi‑Fi فقط"], ["autoplay", "تشغيل تلقائي"]] as const).map(([key, label]) => (
            <div key={key} className="flex items-center justify-between"><p className="text-[12px] t-text">{label}</p>
              <Toggle value={s.settings[key]} onChange={(v) => set(key, v)} /></div>
          ))}
          <div className="flex items-center justify-between">
            <p className="text-[12px] t-text">تكرار المشغّل</p>
            <div className="flex gap-1">
              {(["off", "all", "one", "shuffle"] as const).map((m) => (
                <button key={m} onClick={() => set("loopMode", m)}>
                  <GlassPill className="px-2 py-1"><span className={`text-[9.5px] ${s.settings.loopMode === m ? "t-text" : "t-muted"}`}>
                    {{ off: "بلا", all: "الكل", one: "واحد", shuffle: "عشوائي" }[m]}</span></GlassPill>
                </button>
              ))}
            </div>
          </div>
        </Glass>
      </div>

      <div className="mt-4">
        <SectionTitle>النسخ الاحتياطي</SectionTitle>
        <Glass className="rounded-[var(--card-radius)] p-4">
          <p className="mb-3 text-[10px] leading-5 t-muted">ملف JSON حقيقي على جهازك — يتضمن الملف الشخصي، المتابعات، السجل، الإعجابات، الإعدادات واختياريًا الوسائط نفسها.</p>
          <div className="flex flex-wrap gap-1.5">
            <button onClick={() => void doExport(false)} className="grad-l press rounded-full px-3.5 py-2 text-[10.5px] font-semibold text-white">تصدير</button>
            <button onClick={() => void doExport(true)} className="press glass-soft glass-border rounded-full px-3 py-2 text-[10.5px] t-text">تصدير + الملفات</button>
            <button onClick={() => importRef.current?.click()} className="press glass-soft glass-border rounded-full px-3 py-2 text-[10.5px] t-text">استيراد</button>
            <button onClick={() => { store.reset(); onToast("تمت إعادة الضبط"); }} className="press glass-soft glass-border rounded-full px-3 py-2 text-[10.5px] t-err">إعادة ضبط</button>
          </div>
          <input ref={importRef} type="file" accept="application/json,.json" className="hidden" onChange={async (e: ChangeEvent<HTMLInputElement>) => {
            const f = e.target.files?.[0]; if (!f) return;
            const r = await importState(f); onToast(r.message); e.target.value = "";
          }} />
        </Glass>
      </div>

      <div className="mt-4">
        <SectionTitle>إحصاءات جهازك</SectionTitle>
        <Glass className="rounded-[var(--card-radius)] p-4">
          <div className="grid grid-cols-2 gap-2 text-[10.5px]">
            {[["ملفات الفيديو", s.videos.length], ["الملفات الصوتية", s.tracks.length],
              ["التحميلات", s.downloads.length], ["عمليات البحث", s.stats.searches],
              ["مرات التشغيل", s.stats.filesOpened], ["التوفير بالضغط", bytes(s.stats.bytesSaved)]].map(([k, v]) => (
              <div key={k as string} className="flex items-center justify-between rounded-full bg-white/5 px-3 py-2">
                <span className="t-muted">{k as string}</span><span className="t-text">{String(v)}</span>
              </div>
            ))}
          </div>
        </Glass>
      </div>

      <div className="mt-4">
        <SectionTitle>عن 𝒥𝒪 DON</SectionTitle>
        <Glass className="rounded-[var(--card-radius)] p-4">
          <div className="flex items-center justify-between"><p className="text-[12px] t-text">الإصدار</p><p className="text-[10px] t-muted">1.0.0 · Offline-first</p></div>
          <p className="mt-3 text-[10px] leading-5 t-warn">المسؤولية على المستخدم في احترام حقوق النشر. لا يتجاوز التطبيق DRM أو الاشتراكات المدفوعة، ولا يجمع أي بيانات تحليلية.</p>
          <p className="mt-2 text-[10px] leading-5 t-muted">لا يوجد خادم، لا توجد قاعدة بيانات SQL، ولا أي واجهة خلفية. كل شيء يعمل على جهازك، ويحتاج الإنترنت فقط عند التحميل أو فتح الروابط الخارجية.</p>
        </Glass>
      </div>
    </div>
  );
}
