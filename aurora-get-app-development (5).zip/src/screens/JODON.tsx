import { useEffect, useMemo, useRef, useState, type ChangeEvent } from "react";
import { Icon, type IconName } from "@/lib/icons";
import { Glass, GlassPill, GlassSheet, Empty, Chip, Tag } from "@/components/ui";
import { usePlayer } from "@/components/Player";
import {
  useStore, store, uid, copyText, getFile, downloadBlob,
  exportState, importState, addLocalMedia, videoThumbnail,
  type VideoItem,
} from "@/lib/store";
import { formatTime } from "@/lib/media";
import { bytes } from "@/lib/format";

type Tab = "home" | "shorts" | "subs" | "search" | "account";

export function JODONScreen({ onToast }: { onToast: (m: string) => void }) {
  const s = useStore();
  const player = usePlayer();
  const [tab, setTab] = useState<Tab>("home");
  const [addOpen, setAddOpen] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  const onFiles = async (e: ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return;
    const res = await addLocalMedia(e.target.files);
    onToast(`تمت إضافة ${res.videos} فيديو و ${res.tracks} مقطع صوتي إلى جهازك`);
    // Generate real thumbnails for the newly added videos.
    const fresh = store.get().videos.filter((v) => v.localFileId && !v.thumbnail).slice(0, 12);
    for (const v of fresh) {
      if (!v.localFileId) continue;
      const thumb = await videoThumbnail(v.localFileId);
      if (thumb) store.update((st) => ({
        ...st,
        videos: st.videos.map((x) => x.id === v.id ? { ...x, thumbnail: thumb } : x),
      }));
    }
    e.target.value = "";
  };

  return (
    <div className="relative h-full">
      <div className="no-scrollbar h-full overflow-y-auto pb-32">
        {/* ---------------------------- brand bar ---------------------------- */}
        <div className="flex items-center gap-2.5 px-4 pt-6">
          <YouTubeLogo />
          <div className="min-w-0 flex-1">
            <p className="grad-text truncate text-[17px] font-extrabold tracking-tight">𝒥𝒪 DON</p>
            <p className="text-[9px] t-muted">منصة الفيديو المحلية — بلا حساب، بلا سحابة</p>
          </div>
          <button onClick={() => fileInput.current?.click()} title="استيراد ملفات محلية"
            className="press glass-soft glass-border grid h-9 w-9 place-items-center rounded-full t-text">
            <Icon name="upload" size={17} />
          </button>
          <button onClick={() => setAddOpen(true)} title="إضافة رابط فيديو"
            className="press glass-soft glass-border grid h-9 w-9 place-items-center rounded-full t-text">
            <Icon name="link" size={17} />
          </button>
          <input ref={fileInput} type="file" multiple accept="video/*,audio/*" className="hidden" onChange={onFiles} />
        </div>

        {/* ------------------------------ tabs -------------------------------- */}
        <div className="no-scrollbar mt-3 flex gap-1.5 overflow-x-auto px-4 pb-1">
          {([
            ["home", "الرئيسية", "home"], ["shorts", "شورتس", "shorts"],
            ["subs", "الاشتراكات", "bell"], ["search", "البحث", "search"],
            ["account", "حسابي", "library"],
          ] as [Tab, string, IconName][]).map(([id, label, icon]) => (
            <button key={id} onClick={() => setTab(id)}>
              <GlassPill className="px-3 py-2">
                <span className={`inline-flex items-center gap-1.5 text-[11px] font-semibold ${tab === id ? "t-text" : "t-muted"}`}>
                  <Icon name={icon} size={13} />{label}
                </span>
              </GlassPill>
            </button>
          ))}
        </div>

        <div className="px-4">
          {tab === "home" && <Feed key="home" videos={s.videos} onPlay={player.play} onToast={onToast} mode="all" />}
          {tab === "shorts" && <Shorts videos={s.videos.filter((v) => v.kind === "short")} onPlay={player.play} onToast={onToast} />}
          {tab === "subs" && <Subscriptions onPlay={player.play} onToast={onToast} />}
          {tab === "search" && <Search videos={s.videos} onPlay={player.play} onToast={onToast} />}
          {tab === "account" && <Account onToast={onToast} onPlay={player.play} />}
        </div>
      </div>

      <AddLinkSheet open={addOpen} onClose={() => setAddOpen(false)} onToast={onToast} />
    </div>
  );
}

function YouTubeLogo() {
  return (
    <div className="grid h-9 w-[52px] place-items-center rounded-[12px] bg-[#FF0033] shadow-[0_8px_20px_-8px_rgba(255,0,51,.8)]">
      <svg width="28" height="20" viewBox="0 0 28 20">
        <path d="M2 3.2h24a2 2 0 0 1 2 2v9.6a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V5.2a2 2 0 0 1 2-2Z" fill="#fff" opacity=".16" />
        <path d="M11.4 5.8 19 10l-7.6 4.2Z" fill="#fff" />
      </svg>
    </div>
  );
}

/* ------------------------------------------------------------------ feed */

function score(v: VideoItem, s: ReturnType<typeof store.get>) {
  const views = s.watchHistory.filter((h) => h.videoId === v.id).length;
  const liked = s.likes.includes(v.id) ? 4 : 0;
  const subscribed = s.subscriptions.includes(v.channelId) ? 6 : 0;
  const tagHits = v.tags.reduce((acc, t) => acc + (s.searchHistory.some((q) => q.includes(t)) ? 2 : 0), 0);
  const recency = Math.max(0, 3 - (Date.now() - v.addedAt) / 86_400_000);
  const shortBoost = v.kind === "short" ? 1 : 0;
  return views * 3 + liked + subscribed + tagHits + recency + shortBoost;
}

function Feed({ videos, onPlay, onToast, mode, channelId }: {
  videos: VideoItem[]; onPlay: (p: Parameters<ReturnType<typeof usePlayer>["play"]>[0]) => void;
  onToast: (m: string) => void; mode: "all" | "subs"; channelId?: string;
}) {
  const s = useStore();
  const [page, setPage] = useState(1);
  const [filter, setFilter] = useState("الكل");
  const sentinel = useRef<HTMLDivElement>(null);

  const ranked = useMemo(() => {
    let list = mode === "subs"
      ? videos.filter((v) => s.subscriptions.includes(v.channelId))
      : channelId ? videos.filter((v) => v.channelId === channelId) : [...videos];
    list = list.filter((v) => v.kind === "video");
    list = list.filter((v) => whenFilter(v, filter, s));
    return list.sort((a, b) => score(b, s) - score(a, s));
  }, [videos, mode, channelId, s, filter]);

  // Real infinite feed: pages are re-ranked from the on-device library by behaviour.
  const visible = useMemo(() => {
    if (!ranked.length) return [];
    const out: VideoItem[] = [];
    for (let p = 0; p < page; p++) {
      const rotated = ranked.map((_, i) => ranked[(i + p * 3) % ranked.length]);
      out.push(...rotated.map((v, i) => ({ ...v, id: `${v.id}::p${p}::${i}` })));
    }
    return out;
  }, [ranked, page]);

  useEffect(() => {
    const node = sentinel.current;
    if (!node || !ranked.length) return;
    const io = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) setPage((p) => Math.min(p + 1, 40));
    }, { rootMargin: "220px" });
    io.observe(node);
    return () => io.disconnect();
  }, [ranked.length]);

  if (!ranked.length) {
    return (
      <div className="mt-3">
        <Empty icon="youtube" title="لا توجد فيديوهات بعد"
          hint="استورد ملفات الفيديو من جهازك أو أضف رابطًا حقيقيًا من زر الأعلى. كل المحتوى يعمل دون إنترنت." />
        <Glass className="rounded-[20px] p-4">
          <p className="text-[11px] leading-5 t-muted">
            الاقتراحات تُبنى فعليًا من: سجل مشاهدتك، إعجاباتك، القنوات التي تتابعها، وعمليات البحث
            السابقة — كلها محفوظة على الجهاز فقط.
          </p>
        </Glass>
      </div>
    );
  }

  return (
    <div className="mt-3 space-y-3">
      <div className="no-scrollbar flex gap-1.5 overflow-x-auto pb-1">
        {["الكل", "موسيقى", "محلي", "شورتس", "تقنية", "طويل", "قصير", "مفضل"].map((f) => (
          <Chip key={f} active={filter === f} onClick={() => { setFilter(f); setPage(1); }}>{f}</Chip>
        ))}
      </div>
      {visible.map((v, i) => (
        <div key={v.id} className="float-in" style={{ animationDelay: `${Math.min(i, 8) * 55}ms` }}>
          <VideoCard video={v} onPlay={onPlay} onToast={onToast} />
        </div>
      ))}
      <div ref={sentinel} className="grid place-items-center py-4">
        <div className="shimmer h-2 w-24 rounded-full" />
        <p className="mt-2 text-[10px] t-muted">اقتراحات بلا نهاية • مرتّبة حسب تصفّحك</p>
      </div>
    </div>
  );
}

function VideoCard({ video, onPlay, onToast, compact = false }: {
  video: VideoItem; onPlay: (p: Parameters<ReturnType<typeof usePlayer>["play"]>[0]) => void;
  onToast: (m: string) => void; compact?: boolean;
}) {
  const s = useStore();
  const realId = video.id.split("::")[0];
  const liked = s.likes.includes(realId);
  const later = s.watchLater.includes(realId);
  const subscribed = s.subscriptions.includes(video.channelId);

  const playNow = () => {
    store.update((st) => ({
      ...st,
      watchHistory: [{ videoId: realId, at: Date.now(), seconds: video.duration }, ...st.watchHistory].slice(0, 300),
    }));
    onPlay({
      id: realId, title: video.title, subtitle: `${video.channel} · ${formatTime(video.duration)}`,
      type: "video", fileId: video.localFileId, url: video.url.startsWith("jodon://") ? undefined : video.url,
      cover: video.thumbnail,
    });
  };

  const toggle = (key: "likes" | "watchLater") => store.update((st) => ({
    ...st, [key]: st[key].includes(realId) ? st[key].filter((x) => x !== realId) : [...st[key], realId],
  }));

  const download = async () => {
    if (video.localFileId) {
      const blob = await getFile(video.localFileId);
      if (!blob) { onToast("الملف غير موجود على الجهاز"); return; }
      downloadBlob(blob, `${video.title.replace(/[^\w\u0600-\u06FF -]/g, "_")}.${blob.type.split("/")[1] || "mp4"}`);
      store.update((st) => ({
        ...st,
        downloads: [{
          id: uid(), title: video.title, url: video.url, kind: "VIDEO" as const,
          quality: "الملف الأصلي", size: blob.size, savedBytes: blob.size,
          status: "completed" as const, createdAt: Date.now(), localFileId: video.localFileId,
          segments: 1, speed: 0,
        }, ...st.downloads],
      }));
      onToast(`تم حفظ ${bytes(blob.size)} على جهازك`);
    } else {
      const a = document.createElement("a");
      a.href = video.url; a.target = "_blank"; a.rel = "noopener";
      a.download = video.title; a.click();
      store.update((st) => ({
        ...st,
        downloads: [{
          id: uid(), title: video.title, url: video.url, kind: "VIDEO" as const,
          quality: "رابط مباشر", size: video.sizeBytes ?? 0, savedBytes: 0,
          status: "queued" as const, createdAt: Date.now(), segments: 16, speed: 0,
        }, ...st.downloads],
      }));
      onToast("أُضيف التحميل إلى المدير — افتح الرابط لإتمامه");
    }
  };

  const copy = async () => onToast((await copyText(video.url.startsWith("jodon://") ? `𝒥𝒪 DON • ${video.title}` : video.url)) ? "تم نسخ رابط الفيديو" : "تعذّر النسخ");
  const subscribe = () => {
    store.update((st) => ({
      ...st,
      subscriptions: subscribed ? st.subscriptions.filter((x) => x !== video.channelId) : [...st.subscriptions, video.channelId],
    }));
    onToast(subscribed ? "تم إلغاء المتابعة" : `تمت متابعة ${video.channel}`);
  };

  return (
    <Glass className="overflow-hidden rounded-[var(--card-radius)]">
      <div onClick={playNow}
        className="press relative grid h-[164px] place-items-center overflow-hidden bg-black/40"
        style={video.thumbnail ? { backgroundImage: `url(${video.thumbnail})`, backgroundSize: "cover", backgroundPosition: "center" } : undefined}>
        {!video.thumbnail && <div className="grad grid h-14 w-14 place-items-center rounded-full text-white/90"><Icon name="play" size={24} /></div>}
        {video.thumbnail && <div className="grid h-12 w-12 place-items-center rounded-full bg-black/45 text-white backdrop-blur"><Icon name="play" size={21} /></div>}
        <span className="absolute bottom-2 end-2 rounded-md bg-black/75 px-1.5 py-0.5 text-[10px] text-white">
          {formatTime(video.duration)}
        </span>
        {video.kind === "short" && <span className="absolute start-2 top-2"><Tag>شورتس</Tag></span>}
      </div>

      <div className="p-3">
        <p className="line-clamp-2 text-[12.5px] font-semibold leading-5 t-text">{video.title}</p>
        <div className="mt-1 flex items-center gap-1.5">
          <div className="grad grid h-6 w-6 place-items-center rounded-full text-[9px] font-bold text-white">
            {video.channel.slice(0, 1)}
          </div>
          <p className="min-w-0 flex-1 truncate text-[10.5px] t-muted">
            {video.channel} · {video.views.toLocaleString("ar-EG")} مشاهدة · {new Date(video.published).toLocaleDateString("ar-EG")}
          </p>
          <button onClick={subscribe} className="press rounded-full border border-white/12 px-2 py-1 text-[9.5px] t-text">
            {subscribed ? "✓ متبوع" : "متابعة"}
          </button>
        </div>

        {!compact && (
          <div className="no-scrollbar mt-2.5 flex gap-1.5 overflow-x-auto">
            <Action icon="download" label="تحميل" onClick={download} primary />
            <Action icon="copy" label="نسخ الرابط" onClick={copy} />
            <Action icon="thumb" label={liked ? "أُعجب ✓" : "إعجاب"} onClick={() => toggle("likes")} active={liked} />
            <Action icon="clock" label={later ? "لاحقًا ✓" : "لاحقًا"} onClick={() => toggle("watchLater")} active={later} />
            <Action icon="share" label="مشاركة" onClick={() => {
              if (navigator.share) void navigator.share({ title: video.title, url: video.url });
              else void copy();
            }} />
            <Action icon="play" label="تشغيل" onClick={playNow} />
          </div>
        )}
      </div>
    </Glass>
  );
}

function Action({ icon, label, onClick, primary, active }: {
  icon: IconName; label: string; onClick: () => void; primary?: boolean; active?: boolean;
}) {
  return (
    <button onClick={onClick}>
      <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1.5 text-[10px] ${primary ? "grad-l text-white" : "glass-soft glass-border"} ${active ? "t-text" : primary ? "" : "t-muted"}`}>
        <Icon name={icon} size={12} />{label}
      </span>
    </button>
  );
}

/** Real, data-driven filter predicates (no decorative chips). */
function whenFilter(v: VideoItem, f: string, s: ReturnType<typeof store.get>): boolean {
  const id = v.id.split("::")[0];
  return ({
    "الكل": true,
    "موسيقى": v.tags.some((t) => /موسيق|music|audio|أغني/i.test(t)),
    "محلي": !!v.localFileId,
    "شورتس": v.kind === "short",
    "تقنية": v.tags.some((t) => /تقني|tech|شرح/i.test(t)),
    "طويل": v.duration > 600,
    "قصير": v.duration > 0 && v.duration <= 600,
    "مفضل": s.likes.includes(id),
  } as Record<string, boolean>)[f] ?? true
}

/* ---------------------------------------------------------------- shorts */

function Shorts({ videos, onPlay, onToast }: {
  videos: VideoItem[]; onPlay: (p: Parameters<ReturnType<typeof usePlayer>["play"]>[0]) => void; onToast: (m: string) => void;
}) {
  if (!videos.length) return <Empty icon="shorts" title="لا توجد شورتس" hint="أضف فيديو قصيرًا (٦٠ ثانية أو أقل) من جهازك ليظهر هنا تلقائيًا." />;
  return (
    <div className="mt-3 space-y-3">
      {videos.map((v) => (
        <div key={v.id} className="relative h-[360px] overflow-hidden rounded-[var(--card-radius)] bg-black ring-1 ring-white/10"
          style={v.thumbnail ? { backgroundImage: `url(${v.thumbnail})`, backgroundSize: "cover" } : undefined}>
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/20" />
          <button onClick={() => onPlay({ id: v.id, title: v.title, subtitle: v.channel, type: "video",
            fileId: v.localFileId, url: v.url.startsWith("jodon://") ? undefined : v.url })}
            className="absolute inset-0 grid place-items-center">
            <span className="grad grid h-16 w-16 place-items-center rounded-full text-white"><Icon name="play" size={26} /></span>
          </button>
          <div className="absolute bottom-0 start-0 end-0 p-4">
            <p className="text-[13px] font-bold text-white">{v.title}</p>
            <p className="text-[10.5px] text-white/70">{v.channel} · {formatTime(v.duration)}</p>
            <div className="mt-2 flex gap-2">
              <button onClick={async () => { await copyText(v.url); onToast("تم نسخ رابط الشورت"); }}
                className="press glass-soft glass-border rounded-full px-3 py-1.5 text-[10px] text-white">نسخ الرابط</button>
              <button onClick={async () => {
                if (!v.localFileId) { onToast("هذا الشورت رابط خارجي"); return; }
                const b = await getFile(v.localFileId);
                if (b) { downloadBlob(b, `${v.title}.mp4`); onToast("تم حفظ الشورت"); }
              }} className="grad-l press rounded-full px-3 py-1.5 text-[10px] font-semibold text-white">تحميل</button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ----------------------------------------------------------- subs + search */

function Subscriptions({ onPlay, onToast }: {
  onPlay: (p: Parameters<ReturnType<typeof usePlayer>["play"]>[0]) => void; onToast: (m: string) => void;
}) {
  const s = useStore();
  if (!s.subscriptions.length) return <Empty icon="bell" title="لا تتابع أحدًا بعد" hint="اضغط «متابعة» تحت أي فيديو لتظهر قناته هنا. المتابعة محلية بالكامل." />;
  return (
    <div className="mt-3 space-y-3">
      {s.subscriptions.map((ch) => (
        <Glass key={ch} className="flex items-center gap-3 rounded-[18px] p-3">
          <div className="grad grid h-10 w-10 place-items-center rounded-full text-white">
            {ch.slice(0, 1).toUpperCase()}
          </div>
          <div className="flex-1">
            <p className="text-[12px] font-semibold t-text">{ch}</p>
            <p className="text-[10px] t-muted">{s.videos.filter((v) => v.channelId === ch).length} فيديو</p>
          </div>
          <button onClick={() => store.update((st) => ({ ...st, subscriptions: st.subscriptions.filter((x) => x !== ch) }))}
            className="press rounded-full border border-white/12 px-3 py-1.5 text-[10px] t-muted">إلغاء</button>
        </Glass>
      ))}
      <Feed videos={s.videos} onPlay={onPlay} onToast={onToast} mode="subs" />
    </div>
  );
}

function Search({ videos, onPlay, onToast }: {
  videos: VideoItem[]; onPlay: (p: Parameters<ReturnType<typeof usePlayer>["play"]>[0]) => void; onToast: (m: string) => void;
}) {
  const s = useStore();
  const [q, setQ] = useState("");
  const [searched, setSearched] = useState("");

  const suggestions = useMemo(() => {
    if (!q.trim()) return s.searchHistory.slice(0, 6);
    const pool = new Set<string>();
    videos.forEach((v) => {
      pool.add(v.title); v.tags.forEach((t) => pool.add(t)); pool.add(v.channel);
    });
    return [...pool].filter((p) => p.toLowerCase().includes(q.trim().toLowerCase())).slice(0, 8);
  }, [q, videos, s.searchHistory]);

  const results = useMemo(() => {
    const needle = searched.trim().toLowerCase();
    if (!needle) return [];
    return videos.map((v) => {
      const hay = `${v.title} ${v.channel} ${v.description} ${v.tags.join(" ")}`.toLowerCase();
      const words = needle.split(/\s+/).filter(Boolean);
      let scoreValue = 0;
      words.forEach((w) => {
        if (v.title.toLowerCase().includes(w)) scoreValue += 5;
        if (v.channel.toLowerCase().includes(w)) scoreValue += 3;
        if (v.tags.some((t) => t.toLowerCase().includes(w))) scoreValue += 2;
        if (hay.includes(w)) scoreValue += 1;
      });
      return { v, scoreValue };
    }).filter((x) => x.scoreValue > 0).sort((a, b) => b.scoreValue - a.scoreValue).map((x) => x.v);
  }, [searched, videos]);

  const submit = (value: string) => {
    const v = value.trim();
    if (!v) return;
    setQ(v); setSearched(v);
    store.update((st) => ({
      ...st,
      searchHistory: [v, ...st.searchHistory.filter((x) => x !== v)].slice(0, 20),
      stats: { ...st.stats, searches: st.stats.searches + 1 },
    }));
  };

  return (
    <div className="mt-3">
      <Glass className="flex items-center gap-2 rounded-full px-3 py-2">
        <Icon name="search" size={16} className="t-muted" />
        <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit(q)}
          placeholder="ابحث في مكتبتك…" className="min-w-0 flex-1 bg-transparent text-[12px] t-text placeholder:t-muted" />
        <button onClick={() => submit(q)} className="grad-l press rounded-full px-3 py-1.5 text-[10px] font-semibold text-white">بحث</button>
      </Glass>

      {suggestions.length > 0 && (
        <div className="mt-3">
          <p className="px-1 pb-2 text-[11px] t-muted">{q ? "اقتراحات البحث" : "عمليات البحث الأخيرة"}</p>
          <div className="space-y-1">
            {suggestions.map((sg) => (
              <button key={sg} onClick={() => submit(sg)} className="flex w-full items-center gap-2 rounded-full px-2 py-2 text-end">
                <Icon name="history" size={13} className="t-muted" />
                <span className="flex-1 truncate text-[11.5px] t-text">{sg}</span>
                <Icon name="forward" size={12} className="t-muted" />
              </button>
            ))}
          </div>
        </div>
      )}

      {searched && (
        <div className="mt-3">
          <p className="px-1 pb-2 text-[11px] t-muted">{results.length} نتيجة دقيقة لـ «{searched}»</p>
          {results.length === 0
            ? <Empty icon="search" title="لا نتائج" hint="جرّب كلمة أخرى أو أضف فيديوهات إلى مكتبتك." />
            : <div className="space-y-3">{results.map((v) => <VideoCard key={v.id} video={v} onPlay={onPlay} onToast={onToast} compact />)}</div>}
        </div>
      )}
    </div>
  );
}

/* --------------------------------------------------------------- account */

function Account({ onToast, onPlay }: {
  onToast: (m: string) => void; onPlay: (p: Parameters<ReturnType<typeof usePlayer>["play"]>[0]) => void;
}) {
  const s = useStore();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(s.profile.name);
  const [bio, setBio] = useState(s.profile.bio);
  const [handle, setHandle] = useState(s.profile.handle);
  const importRef = useRef<HTMLInputElement>(null);
  const avatarRef = useRef<HTMLInputElement>(null);
  const bannerRef = useRef<HTMLInputElement>(null);

  const pickImage = async (e: ChangeEvent<HTMLInputElement>, key: "avatar" | "banner") => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fr = new FileReader();
    fr.onload = () => store.update((st) => ({ ...st, profile: { ...st.profile, [key]: String(fr.result) } }));
    fr.readAsDataURL(file);
    e.target.value = "";
  };

  const doExport = async (withFiles: boolean) => {
    const blob = await exportState(withFiles);
    downloadBlob(blob, `JODON-backup-${new Date().toISOString().slice(0, 10)}.json`);
    onToast(`تم تصدير نسخة احتياطية (${bytes(blob.size)})`);
  };

  const doImport = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const res = await importState(file);
    onToast(res.message);
    e.target.value = "";
  };

  return (
    <div className="mt-3 space-y-3">
      <Glass className="overflow-hidden rounded-[var(--card-radius)]">
        <div onClick={() => bannerRef.current?.click()}
          className="press h-24 bg-cover bg-center"
          style={{ background: s.profile.banner ? `url(${s.profile.banner}) center/cover` : "linear-gradient(120deg,var(--a1),var(--a2),var(--a3))" }} />
        <div className="flex items-center gap-3 px-3 pb-3 -mt-7">
          <button onClick={() => avatarRef.current?.click()} className="press grad grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-full text-xl font-bold text-white ring-4 ring-[var(--bg)]">
            {s.profile.avatar ? <img src={s.profile.avatar} alt="" className="h-full w-full object-cover" /> : s.profile.name.slice(0, 1)}
          </button>
          <div className="min-w-0 flex-1 pt-7">
            <p className="truncate text-[13px] font-bold t-text">{s.profile.name}</p>
            <p dir="ltr" className="truncate text-[10px] t-muted">{s.profile.handle}</p>
          </div>
          <button onClick={() => setEditing(!editing)} className="press glass-soft glass-border rounded-full px-3 py-1.5 text-[10px] t-text">تعديل</button>
        </div>
        <p className="px-3 pb-3 text-[10.5px] leading-5 t-muted">{s.profile.bio}</p>
      </Glass>
      <input ref={avatarRef} type="file" accept="image/*" className="hidden" onChange={(e) => void pickImage(e, "avatar")} />
      <input ref={bannerRef} type="file" accept="image/*" className="hidden" onChange={(e) => void pickImage(e, "banner")} />
      <input ref={importRef} type="file" accept="application/json,.json" className="hidden" onChange={(e) => void doImport(e)} />

      {editing && (
        <Glass className="float-in space-y-2 rounded-[18px] p-3">
          {[["الاسم", name, setName], ["المعرّف", handle, setHandle], ["نبذة", bio, setBio]].map(([label, value, setter]) => (
            <div key={label as string}>
              <p className="mb-1 text-[10px] t-muted">{label as string}</p>
              <input value={value as string} onChange={(e) => (setter as (v: string) => void)(e.target.value)}
                className="w-full rounded-full bg-black/20 px-3 py-2 text-[11.5px] t-text ring-1 ring-white/10" />
            </div>
          ))}
          <button onClick={() => {
            store.update((st) => ({ ...st, profile: { ...st.profile, name, handle, bio } }));
            setEditing(false); onToast("تم حفظ الملف الشخصي محليًا");
          }} className="grad-l press w-full rounded-full py-2.5 text-[11px] font-semibold text-white">حفظ</button>
        </Glass>
      )}

      <div className="grid grid-cols-3 gap-2">
        {[
          ["فيديو", s.videos.length], ["متابَعون", s.subscriptions.length],
          ["إعجابات", s.likes.length], ["مشاهدة", s.watchHistory.length],
          ["قوائم", s.playlists.length], ["بحث", s.stats.searches],
        ].map(([label, value]) => (
          <Glass key={label as string} className="rounded-[16px] p-2.5 text-center">
            <p className="grad-text text-[18px] font-extrabold">{value as number}</p>
            <p className="text-[9.5px] t-muted">{label as string}</p>
          </Glass>
        ))}
      </div>

      <Glass className="rounded-[18px] p-3">
        <p className="mb-2 text-[11.5px] font-semibold t-text">الملف الشخصي المحلي</p>
        <p className="mb-3 text-[10px] leading-5 t-muted">لا حساب رسمي، لا خادم، لا تتبّع. بياناتك قابلة للتصدير والاستيراد كملف JSON حقيقي.</p>
        <div className="flex flex-wrap gap-1.5">
          <button onClick={() => void doExport(false)} className="grad-l press rounded-full px-3 py-2 text-[10.5px] font-semibold text-white">تصدير البيانات</button>
          <button onClick={() => void doExport(true)} className="press glass-soft glass-border rounded-full px-3 py-2 text-[10.5px] t-text">تصدير + الملفات</button>
          <button onClick={() => importRef.current?.click()} className="press glass-soft glass-border rounded-full px-3 py-2 text-[10.5px] t-text">استيراد</button>
        </div>
      </Glass>

      <Glass className="rounded-[18px] p-3">
        <p className="mb-2 text-[11.5px] font-semibold t-text">قوائمي</p>
        {s.playlists.map((pl) => (
          <div key={pl.id} className="mb-1.5 flex items-center gap-2">
            <Icon name="library" size={14} className="t-a1" />
            <p className="flex-1 text-[11px] t-text">{pl.name}</p>
            <span className="text-[10px] t-muted">{(pl.id === "pl-later" ? s.watchLater : pl.id === "pl-fav" ? s.likes : pl.videoIds).length}</span>
          </div>
        ))}
      </Glass>

      <Glass className="rounded-[18px] p-3">
        <p className="mb-2 text-[11.5px] font-semibold t-text">سجل المشاهدة</p>
        {s.watchHistory.length === 0 && <p className="text-[10px] t-muted">لم تشاهد شيئًا بعد.</p>}
        {s.watchHistory.slice(0, 8).map((h, i) => {
          const v = s.videos.find((x) => x.id === h.videoId);
          if (!v) return null;
          return (
            <button key={`${h.videoId}-${i}`} onClick={() => onPlay({ id: v.id, title: v.title, subtitle: v.channel,
              type: "video", fileId: v.localFileId, url: v.url.startsWith("jodon://") ? undefined : v.url })}
              className="press mb-1.5 flex w-full items-center gap-2 text-end">
              <Icon name="history" size={13} className="t-muted" />
              <span className="flex-1 truncate text-[10.5px] t-text">{v.title}</span>
              <span className="text-[9.5px] t-muted">{new Date(h.at).toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}</span>
            </button>
          );
        })}
        {s.watchHistory.length > 0 && (
          <button onClick={() => { store.update((st) => ({ ...st, watchHistory: [] })); onToast("تم مسح السجل"); }}
            className="press mt-1 rounded-full border border-white/12 px-3 py-1.5 text-[10px] t-muted">مسح السجل</button>
        )}
      </Glass>
    </div>
  );
}

/* ------------------------------------------------------------- add link */

function AddLinkSheet({ open, onClose, onToast }: { open: boolean; onClose: () => void; onToast: (m: string) => void }) {
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [channel, setChannel] = useState("");
  const [tags, setTags] = useState("");
  const [short, setShort] = useState(false);
  const s = useStore();

  const add = () => {
    if (!url.trim() || !title.trim()) { onToast("أدخل الرابط والعنوان"); return; }
    const id = uid();
    let domain = "مصدر خارجي";
    try { domain = new URL(url).hostname.replace("www.", ""); } catch { /* keep fallback */ }
    store.update((st) => ({
      ...st,
      videos: [{
        id, title: title.trim(), channel: channel.trim() || domain, channelId: channel.trim() || domain,
        url: url.trim(), thumbnail: "", duration: 0, views: 0, published: Date.now(),
        description: "رابط أضافه المستخدم — يُحمّل بمحرك 𝒥𝒪 DON عند الاتصال.",
        tags: tags.split(/[,،\s]+/).filter(Boolean), kind: short ? "short" : "video",
        sizeBytes: 0, addedAt: Date.now(),
      }, ...st.videos],
    }));
    setUrl(""); setTitle(""); setChannel(""); setTags(""); setShort(false);
    onClose(); onToast("أُضيف الفيديو إلى مكتبتك المحلية");
  };

  return (
    <GlassSheet open={open} title="إضافة فيديو حقيقي" onClose={onClose}>
      <Glass className="space-y-2 rounded-[18px] p-3">
        <p className="text-[10px] leading-5 t-muted">أضف رابطًا فعليًا أو ملفًا محليًا. لا تُعرض أي بيانات وهمية — كل بطاقة تمثّل مصدرًا أدخلته بنفسك.</p>
        {[["الرابط", url, setUrl], ["العنوان", title, setTitle], ["القناة", channel, setChannel], ["وسوم (بفاصلة)", tags, setTags]].map(([label, value, setter]) => (
          <input key={label as string} value={value as string} onChange={(e) => (setter as (v: string) => void)(e.target.value)}
            placeholder={label as string} dir={label === "الرابط" ? "ltr" : undefined}
            className="w-full rounded-full bg-black/20 px-3 py-2 text-[11.5px] t-text ring-1 ring-white/10 placeholder:t-muted" />
        ))}
        <button onClick={() => setShort(!short)} className="press glass-soft glass-border rounded-full px-3 py-1.5 text-[10.5px] t-text">
          {short ? "✓ شورتس" : "فيديو طويل"}
        </button>
        <button onClick={add} className="grad-l press w-full rounded-full py-2.5 text-[11.5px] font-semibold text-white">إضافة إلى المكتبة</button>
        <p className="text-[9.5px] t-muted">{s.videos.length} عنصر في مكتبتك الآن</p>
      </Glass>
    </GlassSheet>
  );
}
