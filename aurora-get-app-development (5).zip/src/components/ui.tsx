import type { ReactNode } from "react";
import { Icon, type IconName } from "@/lib/icons";

export function Glass({
  children, className = "", soft = false, onClick, style,
}: {
  children: ReactNode; className?: string; soft?: boolean;
  onClick?: () => void; style?: React.CSSProperties;
}) {
  return (
    <div onClick={onClick} style={style}
      className={`${soft ? "glass-soft" : "glass"} glass-border ${onClick ? "press cursor-pointer" : ""} ${className}`}>
      {children}
    </div>
  );
}

export function GlassPill({ children, className = "", onClick }: {
  children: ReactNode; className?: string; onClick?: () => void;
}) {
  return (
    <div onClick={onClick}
      className={`glass-soft glass-border inline-flex items-center !rounded-full ${onClick ? "press cursor-pointer" : ""} ${className}`}>
      {children}
    </div>
  );
}

export function AuroraBackground({ photo, mesh = true }: { photo?: string; mesh?: boolean }) {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {photo && (
        <div className="absolute inset-0 bg-cover bg-center opacity-[0.14]" style={{ backgroundImage: `url(${photo})` }} />
      )}
      {mesh && <div className="mesh">
        <span className="b1" /><span className="b2" /><span className="b3" />
      </div>}
      <div className="absolute inset-0"
        style={{ background: "radial-gradient(120% 80% at 50% -10%, transparent 35%, rgba(var(--scrim-rgb),.88) 100%)" }} />
      <div className="absolute inset-0 opacity-[var(--noise)] mix-blend-overlay"
        style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3'/%3E%3C/filter%3E%3Crect width='120' height='120' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E\")" }} />
    </div>
  );
}

export function AuroraButton({ label, onClick, icon, variant = "primary", className = "" }: {
  label: string; onClick?: () => void; icon?: IconName;
  variant?: "primary" | "secondary" | "ghost"; className?: string;
}) {
  const styles = variant === "primary" ? "grad-l text-white" : "glass-soft glass-border t-text";
  return (
    <button onClick={onClick}
      className={`press inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-[13px] font-semibold ${styles} ${className}`}>
      {icon && <Icon name={icon} size={17} />}{label}
    </button>
  );
}

export function IconTile({ icon, size = 42 }: { icon: IconName; size?: number }) {
  return (
    <div className="grad grid place-items-center rounded-[16px] text-white"
      style={{ width: size, height: size }}>
      <Icon name={icon} size={Math.round(size * 0.46)} />
    </div>
  );
}

export function Chip({ children, icon, onClick, active = false }: {
  children: ReactNode; icon?: IconName; onClick?: () => void; active?: boolean;
}) {
  return (
    <GlassPill onClick={onClick} className="px-2.5 py-1.5">
      <span className={`inline-flex items-center gap-1.5 text-[11px] ${active ? "t-text" : "t-muted"}`}>
        {icon && <Icon name={icon} size={13} />}{children}
      </span>
    </GlassPill>
  );
}

export function Tag({ children, tone = "default" }: {
  children: ReactNode; tone?: "default" | "warn" | "ok" | "err";
}) {
  const tones = {
    default: "border-white/12 bg-white/8 t-text",
    warn: "border-amber-300/25 bg-amber-400/15", ok: "border-emerald-300/25 bg-emerald-400/15",
    err: "border-rose-300/25 bg-rose-400/15",
  };
  return <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10.5px] ${tones[tone]}`}>{children}</span>;
}

export function ProgressBar({ value, indeterminate = false }: { value: number; indeterminate?: boolean }) {
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
      <div className={`grad-l h-full rounded-full ${indeterminate ? "w-1/3 animate-pulse" : ""}`}
        style={indeterminate ? undefined : { width: `${Math.max(2, Math.min(100, value * 100))}%` }} />
    </div>
  );
}

export function ProgressRing({ value, size = 34 }: { value: number; size?: number }) {
  const r = (size - 5) / 2, c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(255,255,255,.14)" strokeWidth={3.5} fill="none" />
      <defs><linearGradient id="rg" x1="0" x2="1"><stop offset="0%" stopColor="var(--a1)" /><stop offset="50%" stopColor="var(--a2)" /><stop offset="100%" stopColor="var(--a3)" /></linearGradient></defs>
      <circle cx={size / 2} cy={size / 2} r={r} stroke="url(#rg)" strokeWidth={3.5} strokeLinecap="round"
        fill="none" strokeDasharray={c} strokeDashoffset={c - c * Math.max(0, Math.min(1, value))} />
    </svg>
  );
}

export function Sparkline({ samples, width = 120, height = 28 }: { samples: number[]; width?: number; height?: number }) {
  if (!samples.length) return null;
  const max = Math.max(...samples, 1), step = width / Math.max(1, samples.length - 1);
  const path = samples.map((v, i) => `${i ? "L" : "M"}${(i * step).toFixed(1)},${(height - (v / max) * height).toFixed(1)}`).join(" ");
  return (
    <svg width={width} height={height}>
      <defs><linearGradient id="sg" x1="0" x2="1"><stop offset="0%" stopColor="var(--a1)" /><stop offset="100%" stopColor="var(--a3)" /></linearGradient></defs>
      <path d={path} fill="none" stroke="url(#sg)" strokeWidth={2} strokeLinecap="round" />
    </svg>
  );
}

export function GlassSheet({ open, title, onClose, children }: {
  open: boolean; title?: string; onClose: () => void; children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="absolute inset-0 z-40 flex flex-col justify-end">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" onClick={onClose}
        style={{ animation: "floatIn .25s ease-out both" }} />
      <div className="glass glass-border relative max-h-[76%] w-full overflow-hidden rounded-t-[var(--radius)] px-4 pb-7 pt-3"
        style={{ animation: "floatIn var(--dur) var(--spring) both" }}>
        <div className="mx-auto mb-3 h-1.5 w-11 rounded-full bg-white/25" />
        {title && <h3 className="px-2 pb-3 text-[15px] font-semibold t-text">{title}</h3>}
        <div className="no-scrollbar max-h-[58vh] space-y-2 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

export function SectionTitle({ children }: { children: ReactNode }) {
  return <h2 className="px-1 pb-2 text-[12px] font-semibold tracking-wide t-muted">{children}</h2>;
}

export function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!value)}
      className={`press rounded-full px-3.5 py-1.5 text-[11px] font-semibold ${value ? "grad-l text-white" : "bg-white/10 t-muted"}`}>
      {value ? "مفعّل" : "معطّل"}
    </button>
  );
}

export function Empty({ icon, title, hint }: { icon: IconName; title: string; hint: string }) {
  return (
    <div className="grid place-items-center px-6 py-20 text-center">
      <Icon name={icon} size={42} className="t-muted opacity-50" />
      <p className="mt-3 text-[14px] font-semibold t-text">{title}</p>
      <p className="mt-1 text-[11px] leading-5 t-muted">{hint}</p>
    </div>
  );
}

export function ScreenHeader({ title, subtitle, right }: { title: string; subtitle?: string; right?: ReactNode }) {
  return (
    <header className="flex items-center gap-3 pt-6">
      <div className="flex-1 min-w-0">
        <h1 className="grad-text text-[25px] font-extrabold tracking-tight">{title}</h1>
        {subtitle && <p className="mt-0.5 text-[11px] t-muted">{subtitle}</p>}
      </div>
      {right}
    </header>
  );
}
