import { Icon, type IconName } from "@/lib/icons";
import { dict, type Lang } from "@/lib/i18n";

export type DockRoute = "home" | "jodon" | "downloads" | "music" | "library" | "tools" | "settings";

const items: { route: DockRoute; icon: IconName }[] = [
  { route: "home", icon: "home" },
  { route: "jodon", icon: "youtube" },
  { route: "downloads", icon: "downloads" },
  { route: "music", icon: "music" },
  { route: "library", icon: "library" },
  { route: "tools", icon: "converter" },
  { route: "settings", icon: "settings" },
];

export const dockLabels: Record<DockRoute, { ar: string; en: string }> = {
  home: { ar: "الرئيسية", en: "Home" },
  jodon: { ar: "𝒥𝒪 DON", en: "𝒥𝒪 DON" },
  downloads: { ar: "التحميلات", en: "Files" },
  music: { ar: "الموسيقى", en: "Music" },
  library: { ar: "المكتبة", en: "Library" },
  tools: { ar: "الأدوات", en: "Tools" },
  settings: { ar: "الإعدادات", en: "Settings" },
};

export function Dock({ active, onSelect, lang = "ar" }: {
  active: DockRoute; onSelect: (r: DockRoute) => void; lang?: Lang;
}) {
  const index = items.findIndex((i) => i.route === active);
  const width = 100 / items.length;
  void dict;
  return (
    <div className="glass glass-border absolute bottom-4 start-3 end-3 z-30 h-[68px] rounded-full px-1.5">
      <div className="relative flex h-full items-center">
        <div className="dock-indicator grad absolute top-1/2 h-[44px] rounded-full"
          style={{ width: `${width - 1.2}%`, right: `${(items.length - 1 - index) * width}%`, transform: "translateY(-50%)" }} />
        {items.map((item) => {
          const selected = item.route === active;
          return (
            <button key={item.route} onClick={() => onSelect(item.route)}
              className="press relative z-10 flex flex-col items-center gap-0.5"
              style={{ width: `${width}%` }}>
              <Icon name={item.icon} size={19} className={selected ? "text-white" : "t-muted"} />
              <span className={`text-[8.5px] ${selected ? "text-white" : "t-muted"}`}>
                {dockLabels[item.route][lang]}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
