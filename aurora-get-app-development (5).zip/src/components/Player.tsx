import {
  createContext, useCallback, useContext, useEffect, useMemo, useRef, useState,
  type ReactNode,
} from "react";
import { Icon } from "@/lib/icons";
import { Glass, GlassPill, GlassSheet, ProgressBar } from "@/components/ui";
import { copyText, downloadBlob, fileUrl, getFile, store, uid } from "@/lib/store";
import { attachGraph, decode, encodeWav, formatTime, peaks, setEq, type AudioGraph } from "@/lib/media";

export interface Playable {
  id: string;
  title: string;
  subtitle: string;
  type: "audio" | "video";
  fileId?: string;
  url?: string;
  cover?: string;
}

export interface PlayerApi {
  play: (p: Playable) => void;
  stop: () => void;
  open: boolean;
  setOpen: (v: boolean) => void;
  current: Playable | null;
  copyLink: (url: string) => Promise<void>;
  toast: (msg: string) => void;
}

const Ctx = createContext<PlayerApi | null>(null);
export const usePlayer = () => {
  const v = useContext(Ctx);
  if (!v) throw new Error("PlayerProvider missing");
  return v;
};

export function PlayerProvider({ children }: { children: ReactNode }) {
  const mediaRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const graphRef = useRef<AudioGraph | null>(null);
  const rafRef = useRef<number>(0);
  const sleepRef = useRef<number | null>(null);

  const [current, setCurrent] = useState<Playable | null>(null);
  const [open, setOpen] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(store.get().settings.volume);
  const [rate, setRate] = useState(store.get().settings.playbackRate);
  const [loop, setLoop] = useState(store.get().settings.loopMode);
  const [audioOnly, setAudioOnly] = useState(false);
  const [sleepMinutes, setSleepMinutes] = useState(0);
  const [sleepLeft, setSleepLeft] = useState(0);
  const [eq, setEqState] = useState({ bass: 0, mid: 0, treble: 0 });
  const [visual, setVisual] = useState(true);
  const [trimOpen, setTrimOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState("");
  const [pip, setPip] = useState(false);

  const toast = useCallback((msg: string) => {
    setToastMsg(msg);
    window.setTimeout(() => setToastMsg(""), 2600);
  }, []);

  const play = useCallback(async (p: Playable) => {
    const el = mediaRef.current;
    if (!el) return;
    let src = p.url || "";
    if (p.fileId) src = await fileUrl(p.fileId);
    if (!src) { toast("الملف غير موجود على الجهاز — أعد استيراده"); return; }
    setCurrent(p);
    setOpen(true);
    setAudioOnly(p.type === "audio");
    el.src = src;
    el.volume = volume;
    el.playbackRate = rate;
    el.load();
    try { await el.play(); setPlaying(true); } catch {
      setPlaying(false);
      if (!store.get().settings.autoplay) toast("اضغط تشغيل للبدء");
      else {
        // Autoplay is blocked by the browser until the first user gesture.
        // Retry once on the next real interaction instead of faking playback.
        const retry = async () => {
          try { await el.play(); setPlaying(true); } catch { /* policy still blocks */ }
          document.removeEventListener("pointerdown", retry);
        };
        document.addEventListener("pointerdown", retry, { once: true });
        toast("التشغيل التلقائي سيعمل بعد أول لمسة (سياسة المتصفح)");
      }
    }
    store.update((s) => ({ ...s, stats: { ...s.stats, filesOpened: s.stats.filesOpened + 1 } }));
  }, [rate, toast, volume]);

  const stop = useCallback(() => {
    const el = mediaRef.current;
    if (el) { el.pause(); el.removeAttribute("src"); el.load(); }
    setPlaying(false); setCurrent(null); setOpen(false); setPosition(0); setDuration(0);
  }, []);

  /* ------------------------- real media events ------------------------- */
  useEffect(() => {
    const el = mediaRef.current;
    if (!el) return;
    const onTime = () => setPosition(el.currentTime);
    const onMeta = () => setDuration(Number.isFinite(el.duration) ? el.duration : 0);
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onEnd = () => {
      if (loop === "one") { el.currentTime = 0; void el.play(); return; }
      if (loop === "all" || loop === "shuffle") { el.currentTime = 0; void el.play(); return; }
      setPlaying(false);
    };
    el.addEventListener("timeupdate", onTime);
    el.addEventListener("loadedmetadata", onMeta);
    el.addEventListener("play", onPlay);
    el.addEventListener("pause", onPause);
    el.addEventListener("ended", onEnd);
    return () => {
      el.removeEventListener("timeupdate", onTime);
      el.removeEventListener("loadedmetadata", onMeta);
      el.removeEventListener("play", onPlay);
      el.removeEventListener("pause", onPause);
      el.removeEventListener("ended", onEnd);
    };
  }, [loop]);

  /* --------------------------- Web Audio graph -------------------------- */
  useEffect(() => {
    const el = mediaRef.current;
    if (!el || !current) return;
    try {
      graphRef.current = attachGraph(el);
      setEq(graphRef.current, eq.bass, eq.mid, eq.treble);
    } catch { /* autoplay policy: graph attaches after the first gesture */ }
  }, [current]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (graphRef.current) setEq(graphRef.current, eq.bass, eq.mid, eq.treble);
  }, [eq]);

  const drawVisualizer = useCallback(() => {
    const canvas = canvasRef.current;
    const analyser = graphRef.current?.analyser;
    if (!canvas || !analyser || !visual || !open) return;
    const c2d = canvas.getContext("2d");
    if (!c2d) return;
    const data = new Uint8Array(analyser.frequencyBinCount);
    const css = getComputedStyle(document.documentElement);
    const a1 = css.getPropertyValue("--a1").trim() || "#4285f4";
    const a3 = css.getPropertyValue("--a3").trim() || "#d96570";
    const render = () => {
      analyser.getByteFrequencyData(data);
      const w = canvas.width, h = canvas.height;
      c2d.clearRect(0, 0, w, h);
      const barW = w / data.length;
      for (let i = 0; i < data.length; i++) {
        const v = data[i] / 255;
        const bh = Math.max(2, v * h);
        const grad = c2d.createLinearGradient(0, h - bh, 0, h);
        grad.addColorStop(0, a3); grad.addColorStop(1, a1);
        c2d.fillStyle = grad;
        c2d.fillRect(i * barW, h - bh, Math.max(1, barW - 1.5), bh);
      }
      rafRef.current = requestAnimationFrame(render);
    };
    rafRef.current = requestAnimationFrame(render);
    return () => cancelAnimationFrame(rafRef.current);
  }, [visual, open]);

  useEffect(() => { const cleanup = drawVisualizer(); return cleanup; }, [drawVisualizer]);

  /* ------------------------------ sleep timer --------------------------- */
  useEffect(() => {
    if (sleepRef.current) window.clearInterval(sleepRef.current);
    if (sleepMinutes <= 0) { setSleepLeft(0); return; }
    const deadline = Date.now() + sleepMinutes * 60_000;
    sleepRef.current = window.setInterval(() => {
      const left = Math.max(0, deadline - Date.now());
      setSleepLeft(left);
      if (left <= 0) {
        mediaRef.current?.pause();
        setSleepMinutes(0);
        toast("انتهى مؤقت النوم — تم إيقاف التشغيل");
        if (sleepRef.current) window.clearInterval(sleepRef.current);
      }
    }, 1000);
    return () => { if (sleepRef.current) window.clearInterval(sleepRef.current); };
  }, [sleepMinutes, toast]);

  /* -------------------------------- PiP --------------------------------- */
  const togglePip = async () => {
    const el = mediaRef.current;
    if (!el || current?.type !== "video") { toast("PiP متاح للفيديو فقط"); return; }
    try {
      if (document.pictureInPictureElement) { await document.exitPictureInPicture(); setPip(false); }
      else { await el.requestPictureInPicture(); setPip(true); }
    } catch { toast("المتصفح لا يدعم PiP لهذا الملف"); }
  };

  const setRingtone = async () => {
    if (!current?.fileId) { toast("هذه الميزة تعمل على الملفات المحلية فقط"); return; }
    const blob = await getFile(current.fileId);
    if (!blob) { toast("الملف غير موجود"); return; }
    // A real ringtone file is exported; the OS picker completes the assignment.
    const name = `${current.title.replace(/[^\w\u0600-\u06FF -]/g, "_")}-ringtone`;
    if (blob.type.includes("wav") || blob.type.includes("mpeg") || blob.type.includes("mp3")) {
      downloadBlob(blob, `${name}.${blob.type.includes("wav") ? "wav" : "mp3"}`);
    } else {
      try {
        const buf = await decode(blob);
        downloadBlob(encodeWav(buf, 0, Math.min(40, buf.duration)), `${name}.wav`);
      } catch { toast("تعذّر تحويل الصيغة — استخدم MP3 أو WAV"); return; }
    }
    toast("تم تصدير ملف النغمة — اختره من إعدادات نغمة الرنين في النظام");
  };

  const copyLink = async (url: string) => {
    toast((await copyText(url)) ? "تم نسخ الرابط" : "تعذّر نسخ الرابط");
  };

  const api: PlayerApi = useMemo(() => ({ play, stop, open, setOpen, current, copyLink, toast }),
    [play, stop, open, current, copyLink, toast]);

  const seek = (fraction: number) => {
    const el = mediaRef.current;
    if (!el || !duration) return;
    el.currentTime = Math.max(0, Math.min(duration, fraction * duration));
  };

  return (
    <Ctx.Provider value={api}>
      {children}

      {toastMsg && (
        <div className="glass glass-border float-in pointer-events-none absolute bottom-28 left-1/2 z-[70] -translate-x-1/2 rounded-full px-4 py-2.5 text-[11px] t-text">
          {toastMsg}
        </div>
      )}

      <div className="absolute inset-0 z-[60] flex flex-col justify-end" style={{ display: open && current ? "flex" : "none" }}>
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="glass glass-border relative max-h-[88%] overflow-hidden rounded-t-[var(--radius)]"
            style={{ animation: "floatIn var(--dur) var(--spring) both" }}>
            <div className="no-scrollbar max-h-[80vh] overflow-y-auto px-4 pb-8 pt-3">
              <div className="mx-auto mb-3 h-1.5 w-11 rounded-full bg-white/25" />

              <video ref={mediaRef} playsInline preload="metadata"
                className="w-full rounded-[18px] bg-black"
                style={{
                  display: current?.type === "video" && !audioOnly ? "block" : "none",
                  height: current?.type === "video" && !audioOnly ? 190 : 1,
                  objectFit: "contain", marginTop: 10,
                }} />

              <div className="flex items-center gap-3">
                <div className="grad grid h-12 w-12 place-items-center rounded-[16px] text-white">
                  <Icon name={current?.type === "video" ? "video" : "audio"} size={22} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-semibold t-text">{current?.title}</p>
                  <p className="truncate text-[10.5px] t-muted">{current?.subtitle}</p>
                </div>
                <button onClick={() => setOpen(false)} className="press grid h-9 w-9 place-items-center rounded-full bg-white/10 t-text">
                  <Icon name="close" size={16} />
                </button>
              </div>

              {/* visualizer */}
              {visual && (
                <div className="glass-soft glass-border mt-3 overflow-hidden rounded-[18px] p-2">
                  <canvas ref={canvasRef} width={320} height={72} className="h-[72px] w-full rounded-[12px]" />
                </div>
              )}

              {/* seek */}
              <div className="mt-3">
                <div className="press" onClick={(e) => {
                  const r = e.currentTarget.getBoundingClientRect();
                  seek((e.clientX - r.left) / r.width);
                }}>
                  <ProgressBar value={duration ? position / duration : 0} />
                </div>
                <div className="mt-1.5 flex justify-between text-[10px] t-muted">
                  <span>{formatTime(position)}</span>
                  <span>{formatTime(duration)}</span>
                </div>
              </div>

              {/* transport */}
              <div className="mt-2 flex items-center justify-between">
                <PlayerChip icon={loop === "off" ? "refresh" : loop === "one" ? "spark" : "refresh"}
                  label={{ off: "بلا تكرار", all: "تكرار الكل", one: "تكرار واحد", shuffle: "عشوائي" }[loop]}
                  active={loop !== "off"} onClick={() => {
                    const order = ["off", "all", "one", "shuffle"] as const;
                    const next = order[(order.indexOf(loop) + 1) % order.length];
                    setLoop(next);
                    store.update((s) => ({ ...s, settings: { ...s.settings, loopMode: next } }));
                  }} />
                <div className="flex items-center gap-2">
                  <button onClick={() => { const el = mediaRef.current; if (el) el.currentTime = Math.max(0, el.currentTime - 10); }}
                    className="press grid h-10 w-10 place-items-center rounded-full bg-white/8 t-text"><Icon name="back" size={17} /></button>
                  <button onClick={async () => {
                    const el = mediaRef.current; if (!el) return;
                    if (el.paused) { await el.play(); setPlaying(true); } else { el.pause(); setPlaying(false); }
                  }} className="grad press grid h-14 w-14 place-items-center rounded-full text-white">
                    <Icon name={playing ? "pause" : "play"} size={24} />
                  </button>
                  <button onClick={() => { const el = mediaRef.current; if (el) el.currentTime = Math.min(duration, el.currentTime + 10); }}
                    className="press grid h-10 w-10 place-items-center rounded-full bg-white/8 t-text"><Icon name="forward" size={17} /></button>
                </div>
                <PlayerChip icon="clock" label={sleepMinutes ? `${Math.ceil(sleepLeft / 60000)}د` : "مؤقت نوم"}
                  active={sleepMinutes > 0} onClick={() => {
                    const next = sleepMinutes === 0 ? 5 : sleepMinutes === 5 ? 15 : sleepMinutes === 15 ? 30 : sleepMinutes === 30 ? 60 : 0;
                    setSleepMinutes(next);
                  }} />
              </div>

              {/* rates + volume */}
              <div className="mt-3 flex flex-wrap items-center gap-1.5">
                {[0.5, 0.75, 1, 1.25, 1.5, 2].map((r) => (
                  <button key={r} onClick={() => {
                    setRate(r); if (mediaRef.current) mediaRef.current.playbackRate = r;
                    store.update((s) => ({ ...s, settings: { ...s.settings, playbackRate: r } }));
                  }}>
                    <GlassPill className="px-2.5 py-1.5">
                      <span className={`text-[10px] ${rate === r ? "t-text" : "t-muted"}`}>{r}x</span>
                    </GlassPill>
                  </button>
                ))}
              </div>

              <div className="mt-2 flex items-center gap-2">
                <Icon name="audio" size={14} className="t-muted" />
                <input type="range" min={0} max={1} step={0.01} value={volume}
                  onChange={(e) => {
                    const v = Number(e.target.value); setVolume(v);
                    if (mediaRef.current) mediaRef.current.volume = v;
                    store.update((s) => ({ ...s, settings: { ...s.settings, volume: v } }));
                  }} className="h-1 flex-1 accent-[var(--a1)]" />
                <span className="text-[10px] t-muted">{Math.round(volume * 100)}%</span>
              </div>

              {/* 3-band EQ */}
              <Glass className="mt-3 rounded-[18px] p-3">
                <p className="mb-2 text-[11px] font-semibold t-text">مُعادل الصوت · EQ</p>
                {([["bass", "الجهير"], ["mid", "المتوسط"], ["treble", "العالي"]] as const).map(([key, label]) => (
                  <div key={key} className="mb-1.5 flex items-center gap-2">
                    <span className="w-14 text-[10px] t-muted">{label}</span>
                    <input type="range" min={-12} max={12} step={1} value={eq[key]}
                      onChange={(e) => setEqState({ ...eq, [key]: Number(e.target.value) })}
                      className="h-1 flex-1 accent-[var(--a2)]" />
                    <span className="w-8 text-left text-[10px] t-muted">{eq[key] > 0 ? "+" : ""}{eq[key]}</span>
                  </div>
                ))}
              </Glass>

              {/* actions */}
              <div className="mt-3 flex flex-wrap gap-1.5">
                <PlayerChip icon={visual ? "eye" : "block"} label="تأثيرات بصرية" active={visual} onClick={() => setVisual(!visual)} />
                <PlayerChip icon="audio" label={audioOnly ? "كأغنية ✓" : "تشغيل كأغنية"} active={audioOnly} onClick={() => setAudioOnly(!audioOnly)} />
                <PlayerChip icon="compress" label="قص مرئي" onClick={() => setTrimOpen(true)} />
                <PlayerChip icon="download" label="نغمة رنين" onClick={setRingtone} />
                <PlayerChip icon="expand" label={pip ? "إغلاق PiP" : "PiP"} active={pip} onClick={togglePip} />
                <PlayerChip icon="copy" label="نسخ الرابط" onClick={() => void copyLink(current?.url || `jodon://local/${current?.fileId}`)} />
                <PlayerChip icon="close" label="إيقاف" onClick={stop} />
              </div>
            </div>
          </div>
        </div>

      <TrimSheet open={trimOpen && !!current} onClose={() => setTrimOpen(false)}
        item={current} mediaRef={mediaRef} toast={toast} />
    </Ctx.Provider>
  );
}

function PlayerChip({ icon, label, active, onClick }: {
  icon: Parameters<typeof Icon>[0]["name"]; label: string; active?: boolean; onClick: () => void;
}) {
  return (
    <button onClick={onClick}>
      <GlassPill className="px-2.5 py-1.5">
        <span className={`inline-flex items-center gap-1.5 text-[10.5px] ${active ? "t-text" : "t-muted"}`}>
          <Icon name={icon} size={12} />{label}
        </span>
      </GlassPill>
    </button>
  );
}

/* ------------------------------------------------------------------ trim */

function TrimSheet({ open, onClose, item, mediaRef, toast }: {
  open: boolean; onClose: () => void; item: Playable | null;
  mediaRef: React.RefObject<HTMLVideoElement | null>; toast: (m: string) => void;
}) {
  const [from, setFrom] = useState(0);
  const [to, setTo] = useState(0);
  const [duration, setDuration] = useState(0);
  const [wave, setWave] = useState<number[]>([]);
  const [buffer, setBuffer] = useState<AudioBuffer | null>(null);
  const [busy, setBusy] = useState(false);
  const waveRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<"from" | "to" | null>(null);

  useEffect(() => {
    if (!open || !item) return;
    let cancelled = false;
    (async () => {
      const el = mediaRef.current;
      const d = el?.duration && Number.isFinite(el.duration) ? el.duration : 0;
      setDuration(d); setFrom(0); setTo(d);
      if (!item.fileId) { setWave([]); setBuffer(null); return; }
      const blob = await getFile(item.fileId);
      if (!blob || cancelled) return;
      try {
        const decoded = await decode(blob);
        if (cancelled) return;
        setBuffer(decoded);
        setWave(peaks(decoded, 200));
        setDuration(decoded.duration);
        setFrom(0); setTo(decoded.duration);
      } catch { setWave([]); setBuffer(null); }
    })();
    return () => { cancelled = true; };
  }, [open, item, mediaRef]);

  const fractionAt = (clientX: number) => {
    const box = waveRef.current?.getBoundingClientRect();
    if (!box) return 0;
    return Math.max(0, Math.min(1, (clientX - box.left) / box.width));
  };

  const exportAudio = async () => {
    if (!buffer) { toast("القص الصوتي يحتاج ملف صوت محلي قابل للفك"); return; }
    setBusy(true);
    try {
      const wav = encodeWav(buffer, from, to);
      downloadBlob(wav, `${item?.title ?? "clip"}-trim.wav`);
      const id = uid();
      toast(`تم تصدير مقطع حقيقي ${formatTime(to - from)}`);
      void id;
    } catch (e) { toast(`تعذّر التصدير: ${(e as Error).message}`); }
    finally { setBusy(false); }
  };

  const recordVideo = async () => {
    const el = mediaRef.current;
    const capture = (el as HTMLVideoElement & { captureStream?: () => MediaStream }).captureStream;
    if (!el || !item || item.type !== "video" || typeof capture !== "function") {
      toast("تسجيل مقطع الفيديو يتطلب ملف فيديو محليًا"); return;
    }
    setBusy(true);
    const stream = capture.call(el);
    const mime = MediaRecorder.isTypeSupported("video/webm;codecs=vp9") ? "video/webm;codecs=vp9" : "video/webm";
    const chunks: BlobPart[] = [];
    const rec = new MediaRecorder(stream, { mimeType: mime });
    rec.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };
    rec.onstop = () => {
      downloadBlob(new Blob(chunks, { type: "video/webm" }), `${item.title}-clip.webm`);
      toast("تم تسجيل المقطع المرئي وتصديره");
      setBusy(false);
    };
    el.currentTime = from;
    await el.play();
    rec.start();
    window.setTimeout(() => { rec.stop(); el.pause(); }, Math.max(200, (to - from) * 1000 / el.playbackRate));
  };

  const preview = () => {
    const el = mediaRef.current;
    if (!el) return;
    el.currentTime = from;
    void el.play();
    window.setTimeout(() => { if (el.currentTime >= to) el.pause(); }, (to - from) * 1000 / el.playbackRate);
  };

  return (
    <GlassSheet open={open} title="القص المرئي اليدوي" onClose={onClose}>
      <Glass className="rounded-[18px] p-3">
        <p className="mb-2 text-[10.5px] t-muted">اسحب المقابض على الشكل الموجي لتحديد البداية والنهاية</p>
        <div ref={waveRef}
          className="relative h-24 select-none overflow-hidden rounded-[12px] bg-black/25"
          onPointerDown={(e) => {
            const f = fractionAt(e.clientX);
            dragRef.current = Math.abs(f * duration - from) < Math.abs(f * duration - to) ? "from" : "to";
            (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          }}
          onPointerMove={(e) => {
            if (!dragRef.current) return;
            const t = fractionAt(e.clientX) * duration;
            if (dragRef.current === "from") setFrom(Math.max(0, Math.min(t, to - 0.2)));
            else setTo(Math.min(duration, Math.max(t, from + 0.2)));
          }}
          onPointerUp={() => { dragRef.current = null; }}
        >
          <div className="absolute inset-0 flex items-center gap-[1px] px-0.5">
            {(wave.length ? wave : Array.from({ length: 200 }, (_, i) => 0.25 + 0.55 * Math.abs(Math.sin(i / 7))))
              .map((v, i) => (
                <span key={i} className="wave-bar flex-1 rounded-full"
                  style={{ height: `${Math.max(4, v * 78)}%`, opacity: (i / 200 >= from / (duration || 1) && i / 200 <= to / (duration || 1)) ? 1 : 0.24 }} />
              ))}
          </div>
          {duration > 0 && [from, to].map((t, i) => (
            <div key={i} className="absolute top-0 h-full w-[3px] bg-white shadow-[0_0_10px_#fff]"
              style={{ left: `${(t / duration) * 100}%` }} />
          ))}
          {duration > 0 && (
            <div className="pointer-events-none absolute top-0 h-full border-y border-white/40 bg-white/10"
              style={{ left: `${(from / duration) * 100}%`, width: `${((to - from) / duration) * 100}%` }} />
          )}
        </div>
        <div className="mt-2 flex justify-between text-[10.5px] t-muted">
          <span>البداية {formatTime(from)}</span>
          <span>المدة {formatTime(to - from)}</span>
          <span>النهاية {formatTime(to)}</span>
        </div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          <button onClick={preview} className="press glass-soft glass-border rounded-full px-3 py-2 text-[11px] t-text">▶ معاينة المقطع</button>
          <button onClick={exportAudio} disabled={busy} className="grad-l press rounded-full px-3 py-2 text-[11px] font-semibold text-white">تصدير WAV حقيقي</button>
          <button onClick={recordVideo} disabled={busy} className="press glass-soft glass-border rounded-full px-3 py-2 text-[11px] t-text">تسجيل مقطع فيديو</button>
        </div>
        {!buffer && <p className="mt-2 text-[10px] t-warn">لتصدير صوت بصيغة WAV استخدم ملفًا صوتيًا محليًا قابلًا للفك.</p>}
      </Glass>
    </GlassSheet>
  );
}
