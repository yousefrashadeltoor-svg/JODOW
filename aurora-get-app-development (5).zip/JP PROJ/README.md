<div dir="rtl">

# 𝒥𝒪 DON — تطبيق أندرويد كامل

تطبيق أندرويد أصلي (Kotlin + Jetpack Compose **بدون Material إطلاقًا**) لتحميل الفيديو والصوت والصور
والملفات من آلاف المواقع، بمحرّك تحميل مجزّأ فائق السرعة، وتصميم زجاجي (Glassmorphism) على طراز مساعد Gemini.

> ⚖️ **حدود قانونية**: لا يتجاوز التطبيق حماية DRM (Widevine / FairPlay / PlayReady) ولا الاشتراكات المدفوعة.
> المسؤولية على المستخدم في احترام حقوق النشر.

---

## 1) الشرح المعماري

### مخطط الوحدات (Modules)

```
:app  ───────────────► نقطة الدخول: MainActivity, Navigation, Onboarding, Widget, Tile, Shortcuts
 │
 ├── :core:common       أدوات مشتركة (Format, MediaKind, FileNames, AuroraResult, DI qualifiers)
 ├── :core:designsystem نظام التصميم الزجاجي الكامل (Theme, Colors, Typography, Squircle, Glass, Dock, AGSL)
 ├── :core:network      OkHttp + Cronet(HTTP/3) + DNS Cache + CookieJar مشفّر + AdBlock + SizeResolver
 ├── :core:database     تخزين JSON ذرّي محلي: downloads, segments, profile, videos, subscriptions (بلا SQL)
 │
 ├── :engine:downloader المحرك المجزّأ + Queue + Foreground Service + WorkManager
 ├── :engine:extractors yt-dlp wrapper + Native Extractors + LinkResolver
 ├── :engine:media      FFmpeg wrapper + HLS/DASH size collector
 │
 ├── :feature:analyzer  خط التحليل المتوازي (5 مراحل) + بطاقة المعلومات
 ├── :feature:home      حقل اللصق الزجاجي + الأزرار الأربعة الذكية
 ├── :feature:downloads مدير التحميلات بالتبويبات والطابور
 ├── :feature:browser   WebView + Media Sniffer + AdBlock + Cloudflare
 ├── :feature:converter التحويل لاستخراج عدة صيغ
 ├── :feature:compressor تصغير الحجم (Lossless / Transparent)
 ├── :feature:player    مشغل Media3 مدمج
 ├── :feature:files     مكتبة الملفات
 └── :feature:settings  المظهر (١٢ ثيم بصور واقعية)/الشبكة/التحميل/الخصوصية/التحديثات
 └── :feature:jodon  منصة الفيديو المحلية 𝒥𝒪 DON — ليست WebView، ملف شخصي محلي كامل
```

### تدفق البيانات (Data flow)

```
Paste / Share / Intent
        │
        ▼
ClipboardWatcher ──► HomeViewModel (MVI: HomeIntent → HomeUiState)
        │
        ▼
AnalyzerEngine.analyze()  ──► Flow<AnalysisSnapshot>   (5 مراحل متوازية)
   │ Stage 0 (<50ms)   : تطبيع الرابط + الدومين + الشعار من الكاش
   │ Stage 1 (<300ms)  : HEAD/Range + Content-Type + الحجم الحقيقي + OpenGraph
   │ Stage 2 (<1.5s)   : Native Extractors (YouTube, TikTok, Instagram, …)
   │ Stage 3 (≤4s)     : yt-dlp الكامل (كل الصيغ + الترجمات + الأغلفة)
   │ Stage 4 (خلفية)   : Jsoup + Regex fallback
        │
        ▼
AnalysisResult  ──►  Info Card + الأزرار الأربعة (فقط عند وجود محتوى فعلي)
        │
        ▼
JodonDao (JSON) ──► 𝒥𝒪 DON: الرئيسية/شورتس/المتابعات/البحث/حسابي
        │
        ▼
DownloadManager.enqueue() ──► Room ──► DownloadForegroundService
                                        │
                                        ▼
                          SegmentedDownloader (8..32 اتصالًا + Work-Stealing)
                                        │
                     ┌──────────────────┴──────────────────┐
                     ▼                                     ▼
              FileChannel.write @ offset            FFmpeg (دمج/تحويل/ضغط)
```

### قرارات جوهرية

| الموضوع | القرار |
|---|---|
| التحليل | 5 مراحل متوازية، كل مرحلة تبثّ نتيجتها فورًا عبر Flow (لا حجب للواجهة) |
| الحجم الحقيقي | HEAD → Range `bytes=0-0` (Content-Range) → Range متعدد → `filesize` من yt-dlp → `≈` كحل أخير |
| التمييز | المؤكد بلا `≈`، التقريبي دائمًا مع `≈` — لا يُخلطان |
| التحميل | تقسيم إلى chunks (1–16 MiB) + 32 عاملًا + سرقة العمل (Work-Stealing) + كتابة مباشرة بمُoffsets |
| الاستكمال | كل chunk يُحفظ في Room → استكمال بعد الإيقاف/انقطاع الشبكة/إغلاق التطبيق/إعادة التشغيل |
| الأمان | `network_security_config` صارم، الكوكيز في EncryptedSharedPreferences، لا تحليلات ولا تتبّع |
| التصميم | Compose foundation/ui فقط: Squircle، Blur حقيقي عبر Haze، Mesh Gradient عبر AGSL |

</div>
