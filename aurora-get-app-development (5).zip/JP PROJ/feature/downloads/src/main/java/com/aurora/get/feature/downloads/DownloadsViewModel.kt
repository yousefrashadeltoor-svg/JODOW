package com.aurora.get.feature.downloads

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.core.database.DownloadDao
import com.aurora.get.core.database.DownloadEntity
import com.aurora.get.core.network.AuroraCookieJar
import com.aurora.get.engine.downloader.DownloadManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class DownloadTab(val title: String) {
    ALL("الكل"),
    RUNNING("جارٍ"),
    QUEUED("في الانتظار"),
    COMPLETED("مكتمل"),
    FAILED("فاشل")
}

data class DownloadsUiState(
    val tab: DownloadTab = DownloadTab.ALL,
    val items: List<DownloadEntity> = emptyList(),
    val selectedId: String? = null
)

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    private val downloadDao: DownloadDao,
    private val downloadManager: DownloadManager
) : ViewModel() {

    private val tab = MutableStateFlow(DownloadTab.ALL)

    val state: StateFlow<DownloadsUiState> = combine(
        downloadDao.observeAll(),
        tab
    ) { all, current ->
        val filtered = when (current) {
            DownloadTab.ALL -> all
            DownloadTab.RUNNING -> all.filter { it.status == "RUNNING" }
            DownloadTab.QUEUED -> all.filter { it.status == "QUEUED" || it.status == "PAUSED" }
            DownloadTab.COMPLETED -> all.filter { it.status == "COMPLETED" }
            DownloadTab.FAILED -> all.filter { it.status == "FAILED" }
        }
        DownloadsUiState(tab = current, items = filtered)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DownloadsUiState())

    fun selectTab(value: DownloadTab) {
        tab.value = value
    }

    fun pause(id: String) = viewModelScope.launch { downloadManager.pause(id) }
    fun resume(id: String) = viewModelScope.launch { downloadManager.resume(id) }
    fun cancel(id: String) = viewModelScope.launch { downloadManager.cancel(id) }
    fun retry(id: String) = viewModelScope.launch { downloadManager.retry(id) }
    fun delete(id: String, deleteFile: Boolean) = viewModelScope.launch { downloadManager.delete(id, deleteFile) }

    /** Reorders the queue by swapping the priorities of two entries. */
    fun move(from: Int, to: Int) = viewModelScope.launch {
        val items = state.value.items
        if (from !in items.indices || to !in items.indices) return@launch
        val moved = items[from]
        val swapped = items[to]
        downloadManager.setPriority(moved.id, swapped.priority)
        downloadManager.setPriority(swapped.id, moved.priority)
    }

    fun selectedId(): String? = state.value.selectedId
}
