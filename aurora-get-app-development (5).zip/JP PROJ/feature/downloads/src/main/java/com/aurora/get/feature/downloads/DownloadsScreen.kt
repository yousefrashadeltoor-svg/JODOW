package com.aurora.get.feature.downloads

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aurora.get.core.common.Format
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.database.DownloadEntity
import com.aurora.get.core.designsystem.components.AuroraIcon
import com.aurora.get.core.designsystem.components.AuroraIconButton
import com.aurora.get.core.designsystem.components.AuroraProgressBar
import com.aurora.get.core.designsystem.components.AuroraProgressRing
import com.aurora.get.core.designsystem.components.AuroraSparkline
import com.aurora.get.core.designsystem.components.AuroraText
import com.aurora.get.core.designsystem.components.GlassPill
import com.aurora.get.core.designsystem.components.GlassSurface
import com.aurora.get.core.designsystem.icons.AuroraIcons
import com.aurora.get.core.designsystem.shaders.AuroraMeshBackground
import com.aurora.get.core.designsystem.theme.AuroraTheme
import java.io.File

/**
 * The download manager: tabs, live progress, sparkline, and every action.
 */
@Composable
fun DownloadsScreen(
    state: DownloadsUiState,
    onTab: (DownloadTab) -> Unit,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onCancel: (String) -> Unit,
    onRetry: (String) -> Unit,
    onDelete: (String, Boolean) -> Unit,
    onMove: (Int, Int) -> Unit,
    onOpen: (DownloadEntity) -> Unit,
    onShare: (DownloadEntity) -> Unit,
    onCompress: (DownloadEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors

    Box(modifier.fillMaxSize()) {
        AuroraMeshBackground(Modifier.matchParentSize(), intensity = 0.6f)

        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(52.dp))
            AuroraText(
                text = "المدير",
                style = AuroraTheme.typography.headline,
                color = colors.onBackground
            )
            AuroraText(
                text = "${state.items.size} عنصر في القائمة",
                style = AuroraTheme.typography.caption,
                color = colors.onBackgroundMuted
            )

            Spacer(Modifier.height(14.dp))

            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DownloadTab.entries.forEach { tab ->
                    TabPill(
                        title = tab.title,
                        selected = tab == state.tab,
                        onClick = { onTab(tab) }
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            if (state.items.isEmpty()) {
                EmptyState()
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(state.items) { index, item ->
                        DownloadRow(
                            item = item,
                            onPause = { onPause(item.id) },
                            onResume = { onResume(item.id) },
                            onCancel = { onCancel(item.id) },
                            onRetry = { onRetry(item.id) },
                            onDelete = { deleteFile -> onDelete(item.id, deleteFile) },
                            onOpen = { onOpen(item) },
                            onShare = { onShare(item) },
                            onCompress = { onCompress(item) },
                            onDrag = { delta ->
                                if (delta != 0) {
                                    val target = (index + delta).coerceIn(0, state.items.lastIndex)
                                    onMove(index, target)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TabPill(title: String, selected: Boolean, onClick: () -> Unit) {
    val colors = AuroraTheme.colors
    GlassPill {
        Box(
            Modifier
                .background(
                    if (selected) Brush.linearGradient(colors.accentSweep) else Color.Transparent
                )
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            AuroraText(
                text = title,
                style = AuroraTheme.typography.label,
                color = if (selected) Color.White else colors.onBackgroundMuted
            )
        }
    }
}

@Composable
private fun EmptyState() {
    val colors = AuroraTheme.colors
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        AuroraIcon(AuroraIcons.Downloads, null, Modifier.size(48.dp), colors.onBackgroundMuted.copy(alpha = 0.6f))
        Spacer(Modifier.height(12.dp))
        AuroraText("لا توجد تحميلات بعد", style = AuroraTheme.typography.title, color = colors.onBackground)
        AuroraText(
            "الصق رابطًا في الرئيسية لبدء التحميل",
            style = AuroraTheme.typography.caption,
            color = colors.onBackgroundMuted
        )
    }
}

@Composable
private fun DownloadRow(
    item: DownloadEntity,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    onDelete: (Boolean) -> Unit,
    onOpen: () -> Unit,
    onShare: () -> Unit,
    onCompress: () -> Unit,
    onDrag: (Int) -> Unit
) {
    val colors = AuroraTheme.colors
    var dragOffset by remember { mutableStateOf(0) }
    val progress = if ((item.totalBytes ?: 0) > 0) {
        item.downloadedBytes.toFloat() / item.totalBytes
    } else 0f

    GlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .pointerInput(item.id) {
                detectDragGesturesAfterLongPress(
                    onDrag = { _, dragAmount ->
                        dragOffset += dragAmount.y.toInt()
                        if (kotlin.math.abs(dragOffset) > 46) {
                            onDrag(if (dragOffset > 0) 1 else -1)
                            dragOffset = 0
                        }
                    }
                )
            },
        shape = AuroraTheme.shapes.large,
        elevation = 12.dp
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(AuroraTheme.shapes.medium)
                        .background(Brush.linearGradient(colors.accentSweep)),
                    contentAlignment = Alignment.Center
                ) {
                    AuroraIcon(
                        imageVector = when (item.kind) {
                            MediaKind.VIDEO.name -> AuroraIcons.Video
                            MediaKind.AUDIO.name -> AuroraIcons.Audio
                            MediaKind.IMAGE.name -> AuroraIcons.Image
                            else -> AuroraIcons.File
                        },
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                        tint = Color.White
                    )
                }
                Column(Modifier.weight(1f)) {
                    AuroraText(
                        text = item.title,
                        style = AuroraTheme.typography.label,
                        color = colors.onBackground,
                        maxLines = 1
                    )
                    AuroraText(
                        text = "${Format.bytes(item.downloadedBytes)}" +
                            (item.totalBytes?.let { " / ${Format.bytes(it)}" } ?: "") +
                            (item.quality?.let { " • $it" } ?: ""),
                        style = AuroraTheme.typography.caption,
                        color = colors.onBackgroundMuted,
                        maxLines = 1
                    )
                }
                when (item.status) {
                    "RUNNING" -> AuroraIconButton(onClick = onPause, size = 38.dp) {
                        AuroraIcon(AuroraIcons.Pause, "إيقاف", Modifier.size(16.dp), colors.onBackground)
                    }

                    "PAUSED", "QUEUED" -> AuroraIconButton(onClick = onResume, size = 38.dp) {
                        AuroraIcon(AuroraIcons.Play, "استكمال", Modifier.size(16.dp), colors.onBackground)
                    }

                    "FAILED" -> AuroraIconButton(onClick = onRetry, size = 38.dp) {
                        AuroraIcon(AuroraIcons.Refresh, "إعادة", Modifier.size(16.dp), colors.error)
                    }

                    else -> AuroraIconButton(onClick = onOpen, size = 38.dp) {
                        AuroraIcon(AuroraIcons.Play, "فتح", Modifier.size(16.dp), colors.onBackground)
                    }
                }
            }

            if (item.status == "RUNNING") {
                AuroraProgressBar(progress = progress, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AuroraProgressRing(progress = progress, size = 34.dp, strokeWidth = 3.dp)
                    AuroraSparkline(
                        samples = List(24) { index ->
                            val base = progress * 100
                            (base * (0.6f + 0.4f * kotlin.math.sin(index.toFloat()))).coerceAtLeast(1f)
                        },
                        modifier = Modifier.size(width = 120.dp, height = 30.dp)
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ActionChip(AuroraIcons.Share, "مشاركة", onShare)
                ActionChip(AuroraIcons.Compressor, "تصغير", onCompress)
                ActionChip(AuroraIcons.Folder, "فتح المجلد") {
                    onOpen()
                }
                ActionChip(AuroraIcons.Copy, "نسخ الرابط") { }
                ActionChip(AuroraIcons.Trash, "حذف") { onDelete(true) }
                ActionChip(AuroraIcons.Close, "إلغاء", onCancel)
            }
        }
    }
}

@Composable
private fun ActionChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    val colors = AuroraTheme.colors
    GlassPill {
        Row(
            Modifier
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            AuroraIcon(icon, null, Modifier.size(13.dp), colors.onBackgroundMuted)
            AuroraText(label, style = AuroraTheme.typography.caption, color = colors.onBackgroundMuted, maxLines = 1)
        }
    }
}
