package com.aurora.get.feature.jodon

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import com.aurora.get.core.common.Format
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.designsystem.components.AuroraButton
import com.aurora.get.core.designsystem.components.AuroraIcon
import com.aurora.get.core.designsystem.components.AuroraIconButton
import com.aurora.get.core.designsystem.components.AuroraShimmer
import com.aurora.get.core.designsystem.components.AuroraText
import com.aurora.get.core.designsystem.components.GlassBottomSheet
import com.aurora.get.core.designsystem.components.GlassPill
import com.aurora.get.core.designsystem.components.GlassSurface
import com.aurora.get.core.designsystem.icons.AuroraIcons
import com.aurora.get.core.designsystem.theme.AuroraTheme
import com.aurora.get.engine.extractors.youtube.YtFormat
import com.aurora.get.engine.extractors.youtube.YtStream
import com.aurora.get.engine.extractors.youtube.YtVideo
import kotlinx.coroutines.flow.snapshotFlow
import kotlinx.coroutines.launch

/**
 * 𝒥𝒪 DON — the real YouTube experience, native and account free.
 *
 * No WebView and no official API: the content is read straight from youtube.com by the
 * extractor, exactly like NewPipe. Everything renders offline; only the content itself
 * needs a connection.
 */
@Composable
fun JodonScreen(
    viewModel: JodonViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var addOpen by remember { mutableStateOf(false) }

    val importMedia = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        val name = runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(cursor.getColumnIndexOrThrow("_display_name")) else null
            }
        }.getOrNull()
        viewModel.importLocalFile(uri, name)
    }
    val exportDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            val payload = viewModel.export()
            runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(payload.toByteArray()) } }
            viewModel.notify("تم تصدير نسخة احتياطية حقيقية")
        }
    }
    val importDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            val payload = runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText()
            }.getOrNull().orEmpty()
            viewModel.notify(if (viewModel.import(payload)) "تم الاستيراد" else "تعذّر الاستيراد")
        }
    }

    Box(modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // ------------------------------------------------ brand bar
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                YouTubeLogo()
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    AuroraText("𝒥𝒪 DON", style = typography.title)
                    AuroraText(
                        if (state.online) "يقرأ youtube.com مباشرة · بلا حساب"
                        else "بلا اتصال — مكتبتك المحلية متاحة",
                        style = typography.caption,
                        color = colors.onBackgroundMuted
                    )
                }
                AuroraIconButton(onClick = { importMedia.launch(arrayOf("video/*", "audio/*")) }, size = 36.dp) {
                    AuroraIcon(AuroraIcons.Download, null, Modifier.size(16.dp), colors.onBackground)
                }
                AuroraIconButton(onClick = { addOpen = true }, size = 36.dp) {
                    AuroraIcon(AuroraIcons.Link, null, Modifier.size(16.dp), colors.onBackground)
                }
            }

            // ------------------------------------------------ tabs
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                listOf(
                    JodonTab.HOME to "الرئيسية",
                    JodonTab.TRENDING to "الرائج",
                    JodonTab.SHORTS to "شورتس",
                    JodonTab.SUBS to "المتابعات",
                    JodonTab.SEARCH to "البحث",
                    JodonTab.ACCOUNT to "حسابي"
                ).forEach { (tab, label) ->
                    TabPill(label, state.tab == tab) { viewModel.setTab(tab) }
                }
            }

            Spacer(Modifier.height(10.dp))

            when (state.tab) {
                JodonTab.HOME, JodonTab.TRENDING -> VideoFeed(state, viewModel, state.feed)
                JodonTab.SHORTS -> VideoFeed(state, viewModel, state.shorts)
                JodonTab.SUBS -> SubsFeed(state, viewModel)
                JodonTab.SEARCH -> SearchFeed(state, viewModel)
                JodonTab.ACCOUNT -> AccountFeed(
                    state, viewModel,
                    onExport = { exportDoc.launch("JODON-backup.json") },
                    onImport = { importDoc.launch(arrayOf("application/json")) }
                )
            }
        }

        if (state.detail != null || state.detailLoading) {
            StreamSheet(state, viewModel)
        }

        state.message?.let { message ->
            GlassPill(Modifier.align(Alignment.BottomCenter).padding(bottom = 104.dp)) {
                AuroraText(
                    message,
                    style = typography.caption,
                    color = colors.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
                )
            }
            LaunchedEffect(message) {
                kotlinx.coroutines.delay(2400)
                viewModel.clearMessage()
            }
        }
    }

    AddLinkSheet(addOpen, { addOpen = false }) { url, title ->
        viewModel.addLink(url, title)
    }
}

/* ------------------------------------------------------------------ chrome */

@Composable
private fun YouTubeLogo() {
    Box(
        Modifier.size(width = 50.dp, height = 33.dp).clip(AuroraTheme.shapes.small).background(Color(0xFFFF0033)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(width = 22.dp, height = 15.dp)) {
            val path = Path().apply {
                moveTo(size.width * 0.34f, size.height * 0.12f)
                lineTo(size.width * 0.88f, size.height * 0.5f)
                lineTo(size.width * 0.34f, size.height * 0.88f)
                close()
            }
            drawPath(path, Color.White)
        }
    }
}

@Composable
private fun TabPill(label: String, active: Boolean, onClick: () -> Unit) {
    val colors = AuroraTheme.colors
    GlassPill {
        Box(
            Modifier
                .background(if (active) Brush.linearGradient(colors.accentSweep) else Color.Transparent)
                .clip(AuroraTheme.shapes.pill)
                .clickable(onClick = onClick)
                .padding(horizontal = 11.dp, vertical = 7.dp)
        ) {
            AuroraText(
                label,
                style = AuroraTheme.typography.caption,
                color = if (active) Color.White else colors.onBackgroundMuted
            )
        }
    }
}

/* -------------------------------------------------------------------- feed */

@Composable
private fun VideoFeed(state: JodonUiState, viewModel: JodonViewModel, items: List<YtFeedItem>) {
    val listState = rememberLazyListState()

    LaunchedEffect(listState, items.size) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .collect { last -> if (last >= items.size - 3) viewModel.loadMore() }
    }

    if (items.isEmpty()) {
        if (state.loading) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                repeat(4) { AuroraShimmer(Modifier.fillMaxWidth().height(180.dp)) }
            }
        } else {
            EmptyBlock(
                "لا محتوى",
                "اضغط «الرائج» أو ابحث. المحتوى يُقرأ من youtube.com فعليًا عبر NewPipe Extractor — بلا حساب وبلا مفتاح API."
            )
        }
        return
    }

    LazyColumn(
        state = listState,
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(items, key = { it.video.url + it.local }) { item ->
            VideoCard(item.video, item.local, viewModel)
        }
        item {
            if (state.loading) AuroraShimmer(Modifier.fillMaxWidth().height(90.dp))
            Spacer(Modifier.height(110.dp))
        }
    }
}

@Composable
private fun VideoCard(video: YtVideo, local: Boolean, viewModel: JodonViewModel) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    val state by viewModel.state.collectAsStateWithLifecycle()
    val subscribed = video.channelUrl in state.subscriptions
    val liked = video.url in state.likes

    GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.large, elevation = 10.dp) {
        Column {
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(AuroraTheme.shapes.large)
                    .background(Brush.linearGradient(colors.accentSweep))
                    .clickable { viewModel.openVideo(video) },
                contentAlignment = Alignment.Center
            ) {
                if (video.thumbnail != null) {
                    AsyncImage(
                        model = video.thumbnail,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Box(
                    Modifier.size(48.dp).clip(AuroraTheme.shapes.pill).background(Color.Black.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    AuroraIcon(AuroraIcons.Play, null, Modifier.size(22.dp), Color.White)
                }
                if (video.isLive) {
                    GlassPill(Modifier.align(Alignment.TopStart).padding(7.dp)) {
                        AuroraText("مباشر", style = typography.caption, color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                    }
                } else if (video.durationSec > 0) {
                    GlassPill(Modifier.align(Alignment.BottomEnd).padding(7.dp)) {
                        AuroraText(Format.duration(video.durationSec), style = typography.caption,
                            color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                    }
                }
                if (local) {
                    GlassPill(Modifier.align(Alignment.TopEnd).padding(7.dp)) {
                        AuroraText("محلي", style = typography.caption, color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                    }
                }
            }

            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AuroraText(video.title, style = typography.label, color = colors.onBackground, maxLines = 2)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(26.dp).clip(AuroraTheme.shapes.pill)
                            .background(Brush.linearGradient(colors.accentSweep)),
                        contentAlignment = Alignment.Center
                    ) {
                        AuroraText(video.channelName.take(1).ifBlank { "؟" },
                            style = typography.caption, color = Color.White)
                    }
                    Column(Modifier.weight(1f).padding(start = 8.dp)) {
                        AuroraText(video.channelName, style = typography.caption,
                            color = colors.onBackground, maxLines = 1)
                        AuroraText(
                            buildString {
                                if (video.viewCount >= 0) append("${video.viewCount} مشاهدة")
                                if (video.uploadDate != null) {
                                    if (isNotEmpty()) append(" · ")
                                    append(video.uploadDate)
                                }
                                if (isEmpty()) append(video.channelUrl.substringAfterLast('/').take(18))
                            },
                            style = typography.caption,
                            color = colors.onBackgroundMuted,
                            maxLines = 1
                        )
                    }
                    if (video.channelUrl.isNotBlank()) {
                        AuroraText(
                            if (subscribed) "✓ متبوع" else "متابعة",
                            style = typography.caption,
                            color = if (subscribed) colors.success else colors.onBackground,
                            modifier = Modifier.clickable { viewModel.toggleSubscription(video.channelUrl) }
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ActionChip("تحميل", AuroraIcons.Download) { viewModel.openVideo(video) }
                    ActionChip("نسخ الرابط", AuroraIcons.Copy) { viewModel.copyLink(video) }
                    ActionChip(if (liked) "أُعجب ✓" else "إعجاب", AuroraIcons.Sparkle) { viewModel.toggleLike(video.url) }
                    ActionChip("لاحقًا", AuroraIcons.Clock) { viewModel.toggleWatchLater(video.url) }
                    ActionChip("مشاركة", AuroraIcons.Share) { viewModel.share(video) }
                }
            }
        }
    }
}

@Composable
private fun ActionChip(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    val colors = AuroraTheme.colors
    GlassPill {
        Row(
            Modifier.clickable(onClick = onClick).padding(horizontal = 9.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AuroraIcon(icon, null, Modifier.size(12.dp), colors.onBackgroundMuted)
            AuroraText(label, style = AuroraTheme.typography.caption,
                color = colors.onBackgroundMuted, modifier = Modifier.padding(start = 4.dp))
        }
    }
}

/* ------------------------------------------------------------------- subs */

@Composable
private fun SubsFeed(state: JodonUiState, viewModel: JodonViewModel) {
    val colors = AuroraTheme.colors
    if (state.subscriptions.isEmpty()) {
        EmptyBlock("لا تتابع أحدًا", "اضغط «متابعة» تحت أي فيديو لتظهر قنواته هنا — محليًا بالكامل.")
        return
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(state.subscriptions) { channel ->
            GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.medium, elevation = 6.dp) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    AuroraText(channel.substringAfterLast('/').take(26), style = AuroraTheme.typography.label,
                        color = colors.onBackground, modifier = Modifier.weight(1f), maxLines = 1)
                    AuroraText("إلغاء", style = AuroraTheme.typography.caption, color = colors.error,
                        modifier = Modifier.clickable { viewModel.toggleSubscription(channel) })
                }
            }
        }
        if (state.loading) {
            item { AuroraShimmer(Modifier.fillMaxWidth().height(160.dp)) }
        }
        items(state.subsFeed, key = { it.video.url }) { item ->
            VideoCard(item.video, item.local, viewModel)
        }
        item { Spacer(Modifier.height(110.dp)) }
    }
}

/* ------------------------------------------------------------------ search */

@Composable
private fun SearchFeed(state: JodonUiState, viewModel: JodonViewModel) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    var query by remember { mutableStateOf(state.query) }

    Column(Modifier.fillMaxSize()) {
        GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.pill, elevation = 10.dp) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                AuroraIcon(AuroraIcons.Search, null, Modifier.size(16.dp), colors.onBackgroundMuted)
                BasicTextField(
                    value = query,
                    onValueChange = {
                        query = it
                        viewModel.onQueryChange(it)
                    },
                    textStyle = typography.bodySmall.copy(color = colors.onBackground),
                    cursorBrush = SolidColor(colors.primary),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { viewModel.search(query) }),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                AuroraText("بحث", style = typography.label, color = colors.onBackground,
                    modifier = Modifier.clickable { viewModel.search(query) })
            }
        }

        if (state.suggestions.isNotEmpty()) {
            Column(Modifier.padding(top = 8.dp)) {
                state.suggestions.take(6).forEach { suggestion ->
                    Row(
                        Modifier.fillMaxWidth().clickable { query = suggestion; viewModel.search(suggestion) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AuroraIcon(AuroraIcons.Search, null, Modifier.size(13.dp), colors.onBackgroundMuted)
                        AuroraText(suggestion, style = typography.bodySmall, color = colors.onBackground,
                            modifier = Modifier.padding(start = 8.dp), maxLines = 1)
                    }
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        if (state.loading) {
            AuroraShimmer(Modifier.fillMaxWidth().height(160.dp))
        } else if (state.results.isEmpty()) {
            EmptyBlock("لا نتائج", "اكتب كلمة واضغط بحث — النتائج حقيقية من youtube.com.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(state.results, key = { it.video.url }) { item ->
                    VideoCard(item.video, item.local, viewModel)
                }
                item {
                    if (state.loading) AuroraShimmer(Modifier.fillMaxWidth().height(90.dp))
                    Spacer(Modifier.height(110.dp))
                }
            }
        }
    }
}

/* ----------------------------------------------------------------- stream */

@Composable
private fun StreamSheet(state: JodonUiState, viewModel: JodonViewModel) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    val stream = state.detail

    GlassBottomSheet(
        visible = true,
        onDismiss = { viewModel.closeDetail() },
        title = stream?.video?.title ?: "جارٍ تحليل الفيديو…"
    ) {
        if (stream == null) {
            repeat(3) { AuroraShimmer(Modifier.fillMaxWidth().height(60.dp)) }
            return@GlassBottomSheet
        }

        if (stream.video.thumbnail != null) {
            AsyncImage(
                model = stream.video.thumbnail,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(150.dp).clip(AuroraTheme.shapes.large)
            )
        }

        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ActionChip("نسخ الرابط", AuroraIcons.Copy) { viewModel.copyLink(stream.video) }
            ActionChip("متابعة", AuroraIcons.Sparkle) { viewModel.toggleSubscription(stream.video.channelUrl) }
            ActionChip("لاحقًا", AuroraIcons.Clock) { viewModel.toggleWatchLater(stream.video.url) }
            ActionChip("مشاركة", AuroraIcons.Share) { viewModel.share(stream.video) }
        }

        AuroraText(
            "${stream.video.channelName} · ${stream.video.viewCount} مشاهدة · ${Format.duration(stream.video.durationSec)}",
            style = typography.caption, color = colors.onBackgroundMuted, maxLines = 1
        )

        val video = stream.formats.filter { it.kind == MediaKind.VIDEO }
        val audio = stream.formats.filter { it.kind == MediaKind.AUDIO }
        val other = stream.formats.filter { it.kind != MediaKind.VIDEO && it.kind != MediaKind.AUDIO }

        if (video.isNotEmpty()) {
            SectionLabel("الفيديو — كل الجودات")
            video.forEach { format -> FormatRow(format, stream, viewModel) }
        }
        if (audio.isNotEmpty()) {
            SectionLabel("الصوت — كل الصيغ")
            audio.forEach { format -> FormatRow(format, stream, viewModel) }
        }
        if (other.isNotEmpty()) {
            SectionLabel("ملفات أخرى")
            other.forEach { format -> FormatRow(format, stream, viewModel) }
        }

        if (stream.subtitles.isNotEmpty()) {
            SectionLabel("الترجمات (${stream.subtitles.size})")
            stream.subtitles.take(6).forEach { sub ->
                GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.medium, elevation = 5.dp) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        AuroraText(sub.language, style = typography.caption, color = colors.onBackground,
                            modifier = Modifier.weight(1f))
                        AuroraText(if (sub.autoGenerated) "تلقائية" else "رسمية",
                            style = typography.caption, color = colors.onBackgroundMuted)
                    }
                }
            }
        }

        if (stream.related.isNotEmpty()) {
            SectionLabel("مقترحات")
            stream.related.take(8).forEach { related ->
                GlassSurface(
                    Modifier.fillMaxWidth().clickable { viewModel.openVideo(related) },
                    shape = AuroraTheme.shapes.medium, elevation = 5.dp
                ) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        AuroraIcon(AuroraIcons.Play, null, Modifier.size(15.dp), colors.primary)
                        Column(Modifier.weight(1f).padding(start = 8.dp)) {
                            AuroraText(related.title, style = typography.caption,
                                color = colors.onBackground, maxLines = 1)
                            AuroraText("${related.channelName} · ${Format.duration(related.durationSec)}",
                                style = typography.caption, color = colors.onBackgroundMuted, maxLines = 1)
                        }
                    }
                }
            }
        }

        if (stream.description.isNotBlank()) {
            SectionLabel("الوصف")
            AuroraText(stream.description.take(600), style = typography.caption,
                color = colors.onBackgroundMuted)
        }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
private fun SectionLabel(text: String) {
    AuroraText(
        text,
        style = AuroraTheme.typography.caption,
        color = AuroraTheme.colors.onBackgroundMuted,
        modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
    )
}

/**
 * One real format row. YouTube never publishes file sizes for its streams, so the size
 * shown here is always a bitrate-derived estimate and is marked with ≈.
 */
@Composable
private fun FormatRow(format: YtFormat, stream: YtStream, viewModel: JodonViewModel) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography

    GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.medium, elevation = 6.dp) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            AuroraIcon(
                if (format.kind == MediaKind.AUDIO) AuroraIcons.Audio else AuroraIcons.Video,
                null, Modifier.size(17.dp), colors.primary
            )
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                AuroraText(
                    "${format.quality} · ${format.ext.uppercase()}",
                    style = typography.label, color = colors.onBackground, maxLines = 1
                )
                AuroraText(
                    buildList {
                        if (format.videoOnly) add("فيديو بلا صوت")
                        if (format.bitrateKbps > 0) add("${format.bitrateKbps} kbps")
                        if (format.width != null && format.height != null) add("${format.width}×${format.height}")
                        add(format.delivery)
                        format.mime?.let { add(it) }
                    }.joinToString(" · "),
                    style = typography.caption, color = colors.onBackgroundMuted, maxLines = 1
                )
                if (format.sizeBytes != null) {
                    AuroraText(Format.approxBytes(format.sizeBytes), style = typography.caption,
                        color = colors.onBackgroundMuted)
                }
            }
            AuroraIconButton(
                onClick = { viewModel.download(format, stream) },
                contentDescription = "تحميل", size = 36.dp
            ) {
                AuroraIcon(AuroraIcons.Download, null, Modifier.size(15.dp), colors.onBackground)
            }
        }
    }
}

/* ---------------------------------------------------------------- account */

@Composable
private fun AccountFeed(
    state: JodonUiState,
    viewModel: JodonViewModel,
    onExport: () -> Unit,
    onImport: () -> Unit
) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    var editing by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(state.profile.name) }
    var handle by remember { mutableStateOf(state.profile.handle) }
    var bio by remember { mutableStateOf(state.profile.bio) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.large, elevation = 12.dp) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(52.dp).clip(AuroraTheme.shapes.pill)
                            .background(Brush.linearGradient(colors.accentSweep)),
                        contentAlignment = Alignment.Center
                    ) {
                        AuroraText(state.profile.name.take(1), style = typography.title, color = Color.White)
                    }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        AuroraText(state.profile.name, style = typography.title, color = colors.onBackground)
                        AuroraText(state.profile.handle, style = typography.caption, color = colors.onBackgroundMuted)
                    }
                    AuroraText("تعديل", style = typography.caption, color = colors.primary,
                        modifier = Modifier.clickable { editing = !editing })
                }
                Spacer(Modifier.height(10.dp))
                AuroraText(state.profile.bio, style = typography.caption, color = colors.onBackgroundMuted)
            }
        }

        if (editing) {
            GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.medium, elevation = 6.dp) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        Triple("الاسم", name) { v: String -> name = v },
                        Triple("المعرّف", handle) { v: String -> handle = v },
                        Triple("نبذة", bio) { v: String -> bio = v }
                    ).forEach { (label, value, setter) ->
                        AuroraText(label, style = typography.caption, color = colors.onBackgroundMuted)
                        BasicTextField(
                            value = value,
                            onValueChange = setter,
                            textStyle = typography.bodySmall.copy(color = colors.onBackground),
                            cursorBrush = SolidColor(colors.primary),
                            modifier = Modifier.fillMaxWidth()
                                .background(colors.glassTint, AuroraTheme.shapes.small)
                                .padding(10.dp)
                        )
                    }
                    AuroraButton("حفظ", onClick = {
                        viewModel.updateProfile(name, handle, bio)
                        editing = false
                    })
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                "متابعات" to state.subscriptions.size,
                "إعجابات" to state.likes.size,
                "لاحقًا" to state.watchLater.size,
                "مشاهدة" to state.watchHistory.size
            ).forEach { (label, count) ->
                GlassSurface(Modifier.weight(1f), shape = AuroraTheme.shapes.medium, elevation = 6.dp) {
                    Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        AuroraText("$count", style = typography.title, color = colors.primary)
                        AuroraText(label, style = typography.caption, color = colors.onBackgroundMuted)
                    }
                }
            }
        }

        GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.medium, elevation = 8.dp) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AuroraText("الملف الشخصي المحلي", style = typography.label, color = colors.onBackground)
                AuroraText("لا حساب رسمي ولا خادم. صدّر بياناتك كملف JSON حقيقي أو استعدها.",
                    style = typography.caption, color = colors.onBackgroundMuted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AuroraButton("تصدير", onClick = onExport)
                    AuroraButton("استيراد", onClick = onImport,
                        style = com.aurora.get.core.designsystem.components.AuroraButtonStyle.Secondary)
                }
            }
        }
        Spacer(Modifier.height(110.dp))
    }
}

/* ------------------------------------------------------------------ misc */

@Composable
private fun EmptyBlock(title: String, hint: String) {
    val colors = AuroraTheme.colors
    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AuroraIcon(AuroraIcons.Video, null, Modifier.size(40.dp), colors.onBackgroundMuted.copy(alpha = 0.5f))
        Spacer(Modifier.height(12.dp))
        AuroraText(title, style = AuroraTheme.typography.title, color = colors.onBackground)
        Spacer(Modifier.height(6.dp))
        AuroraText(hint, style = AuroraTheme.typography.caption, color = colors.onBackgroundMuted)
    }
}

@Composable
private fun AddLinkSheet(
    open: Boolean,
    onClose: () -> Unit,
    onAdd: (String, String) -> Unit
) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    var url by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }

    GlassBottomSheet(visible = open, onDismiss = onClose, title = "إضافة رابط") {
        GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.medium, elevation = 6.dp) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "الرابط" to { v: String -> url = v },
                    "العنوان" to { v: String -> title = v }
                ).forEach { (label, setter) ->
                    AuroraText(label, style = typography.caption, color = colors.onBackgroundMuted)
                    BasicTextField(
                        value = if (label == "الرابط") url else title,
                        onValueChange = setter,
                        textStyle = typography.bodySmall.copy(color = colors.onBackground),
                        cursorBrush = SolidColor(colors.primary),
                        modifier = Modifier.fillMaxWidth()
                            .background(colors.glassTint, AuroraTheme.shapes.small)
                            .padding(10.dp)
                    )
                }
                AuroraButton("إضافة", onClick = {
                    onAdd(url, title)
                    url = ""; title = ""
                    onClose()
                })
            }
        }
    }
}
