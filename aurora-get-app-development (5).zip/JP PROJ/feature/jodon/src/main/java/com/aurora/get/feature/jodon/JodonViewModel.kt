package com.aurora.get.feature.jodon

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.core.common.FileNames
import com.aurora.get.core.common.Format
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.database.AuroraDatabase
import com.aurora.get.core.database.LocalProfile
import com.aurora.get.core.database.VideoEntity
import com.aurora.get.engine.downloader.DownloadForegroundService
import com.aurora.get.engine.downloader.DownloadManager
import com.aurora.get.engine.downloader.DownloadRequest
import com.aurora.get.engine.extractors.youtube.YoutubeCore
import com.aurora.get.engine.extractors.youtube.YtFormat
import com.aurora.get.engine.extractors.youtube.YtStream
import com.aurora.get.engine.extractors.youtube.YtVideo
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID
import javax.inject.Inject

enum class JodonTab { HOME, TRENDING, SHORTS, SUBS, SEARCH, ACCOUNT }

/** Everything the real YouTube page exposes, plus the user's local library. */
data class YtFeedItem(val video: YtVideo, val local: Boolean)

data class JodonUiState(
    val tab: JodonTab = JodonTab.HOME,
    val loading: Boolean = false,
    val online: Boolean = true,
    val feed: List<YtFeedItem> = emptyList(),
    val trending: List<YtFeedItem> = emptyList(),
    val shorts: List<YtFeedItem> = emptyList(),
    val subscriptions: List<String> = emptyList(),
    val subsFeed: List<YtFeedItem> = emptyList(),
    val suggestions: List<String> = emptyList(),
    val results: List<YtFeedItem> = emptyList(),
    val query: String = "",
    val pageToken: Any? = null,
    val detail: YtStream? = null,
    val detailLoading: Boolean = false,
    val profile: LocalProfile = LocalProfile(),
    val likes: List<String> = emptyList(),
    val watchLater: List<String> = emptyList(),
    val watchHistory: List<String> = emptyList(),
    val message: String? = null
)

/**
 * 𝒥𝒪 DON — the local video platform backed by the real YouTube extractor.
 *
 * Browsing happens through NewPipe Extractor (same technique as NewPipe): **no API key,
 * no WebView**. The account is a purely local profile — subscriptions, likes and history
 * live in the app-private JSON document and never leave the device.
 */
@HiltViewModel
class JodonViewModel @Inject constructor(
    application: Application,
    private val db: AuroraDatabase,
    private val youtube: YoutubeCore,
    private val downloadManager: DownloadManager
) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(JodonUiState())
    val state: StateFlow<JodonUiState> = _state.asStateFlow()

    private var searchJob: Job? = null
    private var suggestJob: Job? = null

    init {
        viewModelScope.launch {
            val snap = db.snapshot()
            _state.value = _state.value.copy(
                profile = snap.profile,
                subscriptions = snap.subscriptions,
                likes = snap.likes,
                watchLater = snap.watchLater,
                watchHistory = snap.watchHistory
            )
        }
        observeConnectivity()
        refreshHome()
    }

    /** Real connectivity awareness: the shell always renders, only content needs the net. */
    private fun observeConnectivity() {
        val context = getApplication<Application>()
        val manager = context.getSystemService(android.content.Context.CONNECTIVITY_SERVICE)
            as? android.net.ConnectivityManager ?: return
        val callback = object : android.net.ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: android.net.Network) {
                _state.value = _state.value.copy(online = true)
            }
            override fun onLost(network: android.net.Network) {
                _state.value = _state.value.copy(online = false)
            }
        }
        runCatching {
            manager.registerDefaultNetworkCallback(callback)
            _state.value = _state.value.copy(online = manager.activeNetwork != null)
        }
    }

    /* ------------------------------------------------------------------ tabs */

    fun setTab(tab: JodonTab) {
        _state.value = _state.value.copy(tab = tab)
        when (tab) {
            JodonTab.HOME -> refreshHome()
            JodonTab.TRENDING -> loadTrending()
            JodonTab.SHORTS -> loadShorts()
            JodonTab.SUBS -> loadSubs()
            else -> Unit
        }
    }

    /* ------------------------------------------------------------------ feed */

    fun refreshHome() {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true)
            val page = runCatching { youtube.trending() }.getOrNull()
            val items = page?.items.orEmpty()
            _state.value = _state.value.copy(
                loading = false,
                feed = items.map { YtFeedItem(it, false) },
                pageToken = page?.nextToken
            )
        }
    }

    fun loadTrending() = refreshHome()

    fun loadShorts() {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true)
            val page = runCatching { youtube.trending() }.getOrNull()
            val items = page?.items.orEmpty()
            val shorts = items.filter { it.durationSec in 1..60 || it.isLive }
            _state.value = _state.value.copy(
                loading = false,
                shorts = (shorts + items.filter { it.durationSec in 61..180 }).distinctBy { it.url }
                    .map { YtFeedItem(it, false) }
            )
        }
    }

    fun loadSubs() {
        viewModelScope.launch {
            val subs = db.snapshot().subscriptions
            _state.value = _state.value.copy(loading = true, subscriptions = subs)
            if (subs.isEmpty()) {
                _state.value = _state.value.copy(loading = false, subsFeed = emptyList())
                return@launch
            }
            val collected = ArrayList<YtFeedItem>()
            subs.forEach { channelUrl ->
                runCatching { youtube.channel(channelUrl) }.getOrNull()?.let { channel ->
                    collected += channel.videos.map { YtFeedItem(it, false) }
                }
            }
            _state.value = _state.value.copy(
                loading = false,
                subsFeed = collected.distinctBy { it.video.url }
            )
        }
    }

    /** Endless feed: keeps requesting real search/trending continuation pages. */
    fun loadMore() {
        val token = _state.value.pageToken ?: return
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true)
            val searching = _state.value.query.isNotBlank() && _state.value.tab == JodonTab.SEARCH
            val page = runCatching {
                if (searching) youtube.search(_state.value.query, token) else youtube.trendingMore(token)
            }.getOrNull()
            val more = page?.items.orEmpty().map { YtFeedItem(it, false) }
            _state.value = _state.value.copy(
                loading = false,
                feed = if (searching) _state.value.feed else _state.value.feed + more,
                results = if (searching) _state.value.results + more else _state.value.results,
                pageToken = page?.nextToken
            )
        }
    }

    /* --------------------------------------------------------------- search */

    fun onQueryChange(value: String) {
        _state.value = _state.value.copy(query = value)
        suggestJob?.cancel()
        suggestJob = viewModelScope.launch {
            kotlinx.coroutines.delay(180)
            val suggestions = runCatching { youtube.suggest(value) }.getOrDefault(emptyList())
            _state.value = _state.value.copy(suggestions = suggestions)
        }
    }

    fun search(query: String) {
        val q = query.trim()
        if (q.isBlank()) return
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            _state.value = _state.value.copy(tab = JodonTab.SEARCH, loading = true, query = q)
            db.jodonDao.recordSearch(q)
            val page = runCatching { youtube.search(q) }.getOrNull()
            _state.value = _state.value.copy(
                loading = false,
                results = page?.items.orEmpty().map { YtFeedItem(it, false) },
                pageToken = page?.nextToken
            )
        }
    }

    /* --------------------------------------------------------------- detail */

    fun openVideo(video: YtVideo) {
        viewModelScope.launch {
            _state.value = _state.value.copy(detailLoading = true)
            db.jodonDao.recordWatch(video.url)
            val stream = runCatching { youtube.stream(video.url) }.getOrNull()
            _state.value = _state.value.copy(
                detailLoading = false,
                detail = stream,
                message = if (stream == null) "تعذّر جلب معلومات الفيديو" else null
            )
        }
    }

    fun closeDetail() {
        _state.value = _state.value.copy(detail = null)
    }

    /* ------------------------------------------------------------- actions */

    fun download(format: YtFormat, stream: YtStream?) {
        viewModelScope.launch {
            val title = stream?.video?.title ?: format.quality
            val ext = format.ext.ifBlank { "mp4" }
            val kind = if (format.kind == MediaKind.AUDIO) MediaKind.AUDIO else MediaKind.VIDEO
            val request = DownloadRequest(
                id = UUID.randomUUID().toString(),
                url = format.url,
                title = title,
                fileName = FileNames.sanitize(title) + ".$ext",
                destinationDir = downloadManager.destinationDirFor(kind),
                kind = kind,
                mimeType = format.mime,
                quality = format.quality,
                width = format.width,
                height = format.height,
                totalBytes = format.sizeBytes,
                thumbnailUrl = stream?.video?.thumbnail,
                sourceId = stream?.video?.url,
                referer = "https://www.youtube.com/"
            )
            val id = downloadManager.enqueue(request)
            if (id != null) {
                DownloadForegroundService.start(getApplication())
                notify("بدأ التحميل: ${format.quality}")
            } else {
                notify("هذا الملف موجود مسبقًا في قائمة التحميل")
            }
        }
    }

    fun toggleSubscription(channelUrl: String) = viewModelScope.launch {
        db.jodonDao.toggleSubscription(channelUrl)
        val now = db.snapshot().subscriptions
        _state.value = _state.value.copy(
            subscriptions = now,
            message = if (channelUrl in now) "تمت المتابعة" else "تم إلغاء المتابعة"
        )
    }

    fun toggleLike(url: String) = viewModelScope.launch {
        db.jodonDao.toggleLike(url)
        _state.value = _state.value.copy(likes = db.snapshot().likes)
    }

    fun toggleWatchLater(url: String) = viewModelScope.launch {
        db.jodonDao.toggleWatchLater(url)
        _state.value = _state.value.copy(watchLater = db.snapshot().watchLater)
    }

    fun copyLink(video: YtVideo) {
        val context = getApplication<Application>()
        val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("𝒥𝒪 DON link", video.url))
        notify("تم نسخ رابط الفيديو")
    }

    fun share(video: YtVideo) {
        val context = getApplication<Application>()
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, video.url)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(Intent.createChooser(intent, "مشاركة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    fun updateProfile(name: String, handle: String, bio: String) = viewModelScope.launch {
        db.jodonDao.setProfile(db.snapshot().profile.copy(name = name, handle = handle, bio = bio))
        _state.value = _state.value.copy(profile = db.snapshot().profile, message = "تم حفظ الملف الشخصي محليًا")
    }

    fun addLink(url: String, title: String) {
        if (url.isBlank() || title.isBlank()) return
        viewModelScope.launch {
            db.jodonDao.addVideo(
                VideoEntity(
                    id = UUID.randomUUID().toString(),
                    title = title,
                    channel = "رابط مضاف",
                    channelId = "local",
                    url = url,
                    description = "أضافه المستخدم — يُحمّل عند الاتصال."
                )
            )
            notify("أُضيف إلى مكتبتك المحلية")
        }
    }

    fun importLocalFile(sourceUri: android.net.Uri, displayName: String?) {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            val dir = File(context.filesDir, "jodon/media").apply { mkdirs() }
            val name = FileNames.sanitize(displayName ?: "clip_${System.currentTimeMillis()}.mp4")
            val target = File(dir, name)
            runCatching {
                context.contentResolver.openInputStream(sourceUri)?.use { input ->
                    target.outputStream().use { output -> input.copyTo(output, 256 * 1024) }
                }
            }
            db.jodonDao.addVideo(
                VideoEntity(
                    id = UUID.randomUUID().toString(),
                    title = FileNames.toTitle(name),
                    channel = db.snapshot().profile.name,
                    channelId = "local",
                    url = target.toURI().toString(),
                    localPath = target.absolutePath,
                    sizeBytes = target.length()
                )
            )
            notify("استُورد ${Format.bytes(target.length())}")
        }
    }

    suspend fun export(): String = db.export()
    suspend fun import(payload: String): Boolean = db.import(payload)

    fun notify(message: String) {
        _state.value = _state.value.copy(message = message)
    }

    fun clearMessage() {
        _state.value = _state.value.copy(message = null)
    }
}
