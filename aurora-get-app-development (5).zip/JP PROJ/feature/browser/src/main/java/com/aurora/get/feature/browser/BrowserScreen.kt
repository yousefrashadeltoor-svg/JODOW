package com.aurora.get.feature.browser

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.aurora.get.core.common.Format
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.designsystem.components.AuroraIcon
import com.aurora.get.core.designsystem.components.AuroraIconButton
import com.aurora.get.core.designsystem.components.AuroraText
import com.aurora.get.core.designsystem.components.GlassBottomSheet
import com.aurora.get.core.designsystem.components.GlassPill
import com.aurora.get.core.designsystem.components.GlassSurface
import com.aurora.get.core.designsystem.icons.AuroraIcons
import com.aurora.get.core.designsystem.theme.AuroraTheme

/**
 * The internal browser with the media sniffer, the ad blocker and the Cloudflare
 * challenge handling.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(
    state: BrowserUiState,
    viewModel: BrowserViewModel,
    onDownload: (SniffedMedia) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    val context = LocalContext.current
    val webView = remember { WebView(context) }

    DisposableEffect(Unit) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = com.aurora.get.core.network.NetworkModule.USER_AGENT
        }
        webView.addJavascriptInterface(viewModel.sniffer, "AuroraSniffer")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val url = request.url.toString()
                val type = request.resourceType
                val blocked = viewModel.isBlocked(url, type, request.requestHeaders["Referer"])
                if (blocked) {
                    viewModel.onBlocked(viewModel.blockedTotal() + 1)
                    return WebResourceResponse(
                        "text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0))
                    )
                }
                viewModel.sniffer.onRequest(url, null, request.requestHeaders["Referer"])
                return null
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                viewModel.onLoadStarted()
                viewModel.onChallenge(isChallenge(url))
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                viewModel.onLoadFinished(url.orEmpty(), view?.title)
                viewModel.onSniffed(viewModel.sniffer.items)
                viewModel.onChallenge(isChallenge(view?.title))
                // Hand the session cookies over to the download engine.
                val cookieHeader = CookieManager.getInstance().getCookie(url.orEmpty())
                viewModel.transferCookies(url.orEmpty(), cookieHeader)
                view?.evaluateJavascript(viewModel.sniffer.injectionScript, null)
                val css = viewModel.cosmeticCss(hostOf(url.orEmpty()))
                if (css.isNotBlank()) {
                    view?.evaluateJavascript(css, null)
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: android.webkit.WebResourceError?
            ) {
                if (request?.isForMainFrame == true) viewModel.onLoadFinished(request.url.toString(), null)
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            viewModel.sniffer.report(url, mimeType, kindOfMime(mimeType))
            viewModel.onSniffed(viewModel.sniffer.items)
        }

        onDispose {
            webView.removeJavascriptInterface("AuroraSniffer")
            webView.destroy()
        }
    }

    // Load the requested URL when it changes.
    DisposableEffect(state.currentTabId, state.urlInput) {
        val tab = state.currentTab
        if (tab != null && tab.url.isBlank() && state.urlInput.startsWith("http")) {
            webView.loadUrl(state.urlInput)
        }
        onDispose { }
    }

    Box(modifier.fillMaxSize().background(colors.background)) {
        AndroidView(
            factory = { webView },
            modifier = Modifier.fillMaxSize()
        )

        // ---------- top glass bar ----------
        Column(Modifier.fillMaxWidth().padding(top = 44.dp, start = 14.dp, end = 14.dp)) {
            GlassSurface(
                modifier = Modifier.fillMaxWidth(),
                shape = AuroraTheme.shapes.large,
                elevation = 16.dp
            ) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        AuroraIconButton(
                            onClick = { if (webView.canGoBack()) webView.goBack() },
                            size = 38.dp
                        ) {
                            AuroraIcon(AuroraIcons.Back, "رجوع", Modifier.size(17.dp), colors.onBackground)
                        }
                        AuroraIconButton(
                            onClick = { if (webView.canGoForward()) webView.goForward() },
                            size = 38.dp
                        ) {
                            AuroraIcon(AuroraIcons.Forward, "تقدّم", Modifier.size(17.dp), colors.onBackground)
                        }
                        AuroraIconButton(onClick = { webView.reload() }, size = 38.dp) {
                            AuroraIcon(AuroraIcons.Refresh, "تحديث", Modifier.size(17.dp), colors.onBackground)
                        }
                        BasicTextField(
                            value = state.urlInput,
                            onValueChange = viewModel::onUrlChanged,
                            textStyle = typography.bodySmall.copy(color = colors.onBackground),
                            cursorBrush = SolidColor(colors.primary),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = ImeAction.Go),
                            keyboardActions = androidx.compose.foundation.text.KeyboardActions(onGo = {
                                webView.loadUrl(state.urlInput)
                            }),
                            modifier = Modifier.weight(1f),
                            decorationBox = { inner ->
                                if (state.urlInput.isBlank()) {
                                    AuroraText(
                                        "ابحث أو ألصق رابطًا",
                                        style = typography.bodySmall,
                                        color = colors.onBackgroundMuted
                                    )
                                }
                                inner()
                            }
                        )
                        AuroraIconButton(onClick = viewModel::toggleDesktopMode, size = 38.dp) {
                            AuroraIcon(
                                AuroraIcons.Globe, "وضع سطح المكتب",
                                Modifier.size(17.dp),
                                if (state.desktopMode) colors.primary else colors.onBackgroundMuted
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        GlassPill {
                            Row(
                                Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                AuroraIcon(AuroraIcons.Shield, null, Modifier.size(12.dp), colors.success)
                                AuroraText(
                                    "${state.blockedTotal} محجوب",
                                    style = typography.caption,
                                    color = colors.onBackgroundMuted
                                )
                            }
                        }
                        GlassPill {
                            Row(
                                Modifier
                                    .clickable { viewModel.toggleWhitelist(hostOf(state.urlInput)) }
                                    .padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                AuroraIcon(AuroraIcons.Lock, null, Modifier.size(12.dp), colors.onBackgroundMuted)
                                AuroraText(
                                    "استثناء الموقع",
                                    style = typography.caption,
                                    color = colors.onBackgroundMuted
                                )
                            }
                        }
                        if (state.tabCount() > 1) {
                            GlassPill {
                                AuroraText(
                                    "${state.tabCount()} تبويب",
                                    style = typography.caption,
                                    color = colors.onBackgroundMuted,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // ---------- cloudflare / challenge overlay ----------
        if (state.challengeActive) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(colors.scrim),
                contentAlignment = Alignment.Center
            ) {
                GlassSurface(
                    modifier = Modifier.padding(32.dp),
                    shape = AuroraTheme.shapes.large,
                    elevation = 24.dp
                ) {
                    Column(
                        Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AuroraIcon(AuroraIcons.Shield, null, Modifier.size(34.dp), colors.primary)
                        AuroraText(
                            "تحدّي حماية الموقع",
                            style = typography.title,
                            color = colors.onBackground
                        )
                        AuroraText(
                            "يتم التحقق داخل المتصفح الفعلي… ستُنقل ملفات تعريف الارتباط تلقائيًا إلى محرّك التحميل.",
                            style = typography.caption,
                            color = colors.onBackgroundMuted
                        )
                    }
                }
            }
        }

        // ---------- the sniffer FAB ----------
        if (state.sniffed.isNotEmpty()) {
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 20.dp, bottom = 130.dp)
            ) {
                GlassSurface(
                    modifier = Modifier.clickable { viewModel.openSheet(true) },
                    shape = AuroraTheme.shapes.pill,
                    elevation = 24.dp
                ) {
                    Row(
                        Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AuroraIcon(AuroraIcons.Download, null, Modifier.size(18.dp), colors.onBackground)
                        AuroraText(
                            "${state.sniffed.size} ملف",
                            style = typography.label,
                            color = colors.onBackground
                        )
                    }
                }
            }
        }
    }

    // ---------- the sniffed files sheet ----------
    GlassBottomSheet(
        visible = state.sheetOpen,
        onDismiss = { viewModel.openSheet(false) },
        title = "الملفات المكتشفة"
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            state.sniffed.forEach { media ->
                GlassSurface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = AuroraTheme.shapes.medium,
                    elevation = 6.dp
                ) {
                    Row(
                        Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AuroraIcon(
                            imageVector = when (media.kind) {
                                MediaKind.VIDEO -> AuroraIcons.Video
                                MediaKind.AUDIO -> AuroraIcons.Audio
                                MediaKind.IMAGE -> AuroraIcons.Image
                                else -> AuroraIcons.File
                            },
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = colors.primary
                        )
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            AuroraText(
                                text = media.url.substringAfterLast('/').take(46),
                                style = typography.label,
                                color = colors.onBackground,
                                maxLines = 1
                            )
                            AuroraText(
                                text = media.mimeType ?: media.kind.name,
                                style = typography.caption,
                                color = colors.onBackgroundMuted,
                                maxLines = 1
                            )
                        }
                        AuroraIconButton(onClick = { onDownload(media) }, size = 38.dp) {
                            AuroraIcon(AuroraIcons.Download, "تحميل", Modifier.size(16.dp), colors.onBackground)
                        }
                    }
                }
            }
        }
    }
}

private fun isChallenge(title: String?): Boolean {
    val value = title?.lowercase() ?: return false
    return value.contains("just a moment") ||
        value.contains("checking your browser") ||
        value.contains("attention required") ||
        value.contains("verify you are human")
}

private fun hostOf(url: String): String = url.substringAfter("://", url).substringBefore('/').lowercase()

private fun kindOfMime(mime: String?): String {
    val value = mime?.lowercase() ?: return ""
    return when {
        value.startsWith("video/") -> "video"
        value.startsWith("audio/") -> "audio"
        value.startsWith("image/") -> "image"
        else -> ""
    }
}
