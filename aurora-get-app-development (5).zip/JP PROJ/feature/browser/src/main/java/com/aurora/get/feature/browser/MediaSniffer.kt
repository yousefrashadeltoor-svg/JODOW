package com.aurora.get.feature.browser

import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.common.FileNames
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.network.RemoteSizeResolver
import java.util.concurrent.CopyOnWriteArrayList

/**
 * A media resource discovered inside the internal browser.
 */
data class SniffedMedia(
    val url: String,
    val mimeType: String?,
    val kind: MediaKind,
    val sizeBytes: Long? = null,
    val sizeConfidence: RemoteSizeResolver.Confidence = RemoteSizeResolver.Confidence.UNKNOWN,
    val referer: String? = null,
    val source: String = "request"
)

/**
 * The media sniffer.
 *
 * It works on three levels at the same time:
 *  1. `shouldInterceptRequest` — every network request of the page
 *  2. `DownloadListener` — direct downloads
 *  3. injected JavaScript — fetch / XHR / MediaSource / blob / &lt;video&gt; / &lt;audio&gt;
 */
class MediaSniffer {

    private val detected = CopyOnWriteArrayList<SniffedMedia>()
    private val seen = HashSet<String>()

    val items: List<SniffedMedia> get() = detected.toList()

    fun reset() {
        detected.clear()
        seen.clear()
    }

    /** Called from the WebView request interceptor. */
    fun onRequest(url: String, mimeType: String?, referer: String?): Boolean {
        if (!isInteresting(url, mimeType)) return false
        add(SniffedMedia(url, mimeType, kindOf(url, mimeType), referer = referer, source = "request"))
        return false
    }

    /** Called from the injected JavaScript bridge. */
    @JavascriptInterface
    fun report(url: String, mimeType: String?, kind: String?) {
        if (url.isBlank()) return
        val mediaKind = when (kind) {
            "video" -> MediaKind.VIDEO
            "audio" -> MediaKind.AUDIO
            "image" -> MediaKind.IMAGE
            else -> kindOf(url, mimeType)
        }
        add(SniffedMedia(url, mimeType, mediaKind, source = "script"))
    }

    private fun add(item: SniffedMedia) {
        if (!seen.add(item.url)) return
        detected += item
        AuroraLog.d(TAG, "sniffed ${item.kind} $item")
    }

    fun isInteresting(url: String, mimeType: String?): Boolean {
        val lower = url.lowercase()
        if (mimeType != null) {
            if (mimeType.startsWith("video/") || mimeType.startsWith("audio/") || mimeType.startsWith("image/")) return true
        }
        if (lower.contains(".m3u8") || lower.contains(".mpd")) return true
        val ext = FileNames.extensionOf(lower) ?: return false
        return ext in INTERESTING_EXTENSIONS
    }

    fun kindOf(url: String, mimeType: String?): MediaKind {
        val lower = url.lowercase()
        if (lower.contains(".m3u8") || lower.contains(".mpd")) return MediaKind.VIDEO
        val fromMime = MediaKind.fromMime(mimeType)
        if (fromMime != MediaKind.UNKNOWN) return fromMime
        return MediaKind.fromExtension(FileNames.extensionOf(lower))
    }

    /**
     * The JavaScript that hooks `fetch`, `XMLHttpRequest`, `MediaSource`, `blob:` and the
     * `&lt;video&gt;` / `&lt;audio&gt;` elements.
     */
    val injectionScript: String = """
        (function() {
            if (window.__auroraSniffer) { return; }
            window.__auroraSniffer = true;
            function report(url, mime, kind) {
                try {
                    if (!url) return;
                    if (url.indexOf('blob:') === 0) { kind = kind || 'video'; }
                    window.AuroraSniffer.report(String(url), mime || '', kind || '');
                } catch (e) {}
            }
            var nativeFetch = window.fetch;
            window.fetch = function(input, init) {
                try {
                    var u = (typeof input === 'string') ? input : (input && input.url) || '';
                    var mime = (init && init.headers && (init.headers['Content-Type'] || init.headers.get && init.headers.get('Content-Type'))) || '';
                    report(u, mime, '');
                } catch (e) {}
                return nativeFetch.apply(this, arguments);
            };
            var open = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function(method, url) {
                try { report(url, '', ''); } catch (e) {}
                return open.apply(this, arguments);
            };
            var addSource = HTMLMediaElement.prototype.addSourceBuffer;
            if (addSource) {
                HTMLMediaElement.prototype.addSourceBuffer = function(type) {
                    try { report(location.href, type, 'video'); } catch (e) {}
                    return addSource.apply(this, arguments);
                };
            }
            if (window.MediaSource && MediaSource.prototype.addSourceBuffer) {
                var mss = MediaSource.prototype.addSourceBuffer;
                MediaSource.prototype.addSourceBuffer = function(type) {
                    try { report(location.href, type, 'video'); } catch (e) {}
                    return mss.apply(this, arguments);
                };
            }
            try {
                var observer = new MutationObserver(function() {
                    var nodes = document.querySelectorAll('video, audio');
                    for (var i = 0; i < nodes.length; i++) {
                        var node = nodes[i];
                        if (node.currentSrc) { report(node.currentSrc, node.type || '', node.tagName.toLowerCase()); }
                        var sources = node.querySelectorAll('source');
                        for (var j = 0; j < sources.length; j++) {
                            if (sources[j].src) { report(sources[j].src, sources[j].type || '', node.tagName.toLowerCase()); }
                        }
                    }
                });
                observer.observe(document.documentElement, { childList: true, subtree: true });
            } catch (e) {}
        })();
    """.trimIndent()

    companion object {
        private const val TAG = "MediaSniffer"

        val INTERESTING_EXTENSIONS = setOf(
            "mp4", "mkv", "webm", "mov", "avi", "flv", "m4v", "3gp",
            "mp3", "m4a", "aac", "opus", "ogg", "wav", "flac",
            "jpg", "jpeg", "png", "webp", "avif", "gif",
            "m3u8", "mpd", "zip", "rar", "7z", "pdf", "apk", "ts"
        )
    }
}
