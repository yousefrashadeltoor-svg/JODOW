package com.aurora.get.feature.browser

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.network.AuroraCookieJar
import com.aurora.get.core.network.adblock.AdBlockRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.Cookie
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import java.util.UUID
import javax.inject.Inject

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "صفحة جديدة",
    val url: String = ""
)

data class BrowserUiState(
    val tabs: List<BrowserTab> = listOf(BrowserTab()),
    val currentTabId: String = "",
    val urlInput: String = "",
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val loading: Boolean = false,
    val sniffed: List<SniffedMedia> = emptyList(),
    val blockedCount: Int = 0,
    val desktopMode: Boolean = false,
    val incognito: Boolean = false,
    val sheetOpen: Boolean = false,
    val challengeActive: Boolean = false,
    val whitelistedDomains: Set<String> = emptySet()
) {
    val currentTab: BrowserTab? get() = tabs.firstOrNull { it.id == currentTabId }
    val blockedTotal: Int get() = blockedCount
    fun tabCount(): Int = tabs.size
}

@HiltViewModel
class BrowserViewModel @Inject constructor(
    private val adBlockRepository: AdBlockRepository,
    private val cookieJar: AuroraCookieJar
) : ViewModel() {

    private val _state = MutableStateFlow(
        BrowserUiState(currentTabId = UUID.randomUUID().toString())
    )
    val state: StateFlow<BrowserUiState> = _state.asStateFlow()

    val sniffer = MediaSniffer()

    init {
        viewModelScope.launch {
            adBlockRepository.ensureLoaded()
            _state.update { it.copy(blockedCount = adBlockRepository.blockedCount.toInt()) }
        }
    }

    fun onUrlChanged(value: String) = _state.update { it.copy(urlInput = value) }

    fun onLoadStarted() = _state.update { it.copy(loading = true) }

    fun onLoadFinished(url: String, title: String?) {
        _state.update { current ->
            current.copy(
                loading = false,
                urlInput = url,
                tabs = current.tabs.map {
                    if (it.id == current.currentTabId) it.copy(url = url, title = title ?: it.title) else it
                }
            )
        }
    }

    fun onBlocked(count: Int) = _state.update { it.copy(blockedCount = count) }

    fun onChallenge(active: Boolean) = _state.update { it.copy(challengeActive = active) }

    fun onSniffed(items: List<SniffedMedia>) = _state.update { it.copy(sniffed = items) }

    fun newTab() {
        val tab = BrowserTab()
        _state.update { it.copy(tabs = it.tabs + tab, currentTabId = tab.id, urlInput = "") }
    }

    fun closeTab(id: String) {
        _state.update { current ->
            val remaining = current.tabs.filterNot { it.id == id }
            val tabs = remaining.ifEmpty { listOf(BrowserTab()) }
            current.copy(
                tabs = tabs,
                currentTabId = if (current.currentTabId == id) tabs.first().id else current.currentTabId
            )
        }
    }

    fun selectTab(id: String) = _state.update { it.copy(currentTabId = id) }

    fun toggleDesktopMode() = _state.update { it.copy(desktopMode = !it.desktopMode) }

    fun toggleIncognito() = _state.update { it.copy(incognito = !it.incognito) }

    fun openSheet(open: Boolean) = _state.update { it.copy(sheetOpen = open) }

    fun toggleWhitelist(domain: String) {
        if (domain in adBlockRepository.whitelistedDomains()) {
            adBlockRepository.removeWhitelist(domain)
        } else {
            adBlockRepository.whitelist(domain)
        }
        _state.update { it.copy(whitelistedDomains = adBlockRepository.whitelistedDomains()) }
    }

    /** Moves the cookies of the internal browser into the OkHttp/Cronet cookie jar. */
    fun transferCookies(url: String, cookieHeader: String?) {
        val parsed = url.toHttpUrlOrNull() ?: return
        val raw = cookieHeader ?: return
        val cookies = raw.split(';').mapNotNull { part ->
            val value = part.trim()
            if (value.isEmpty()) return@mapNotNull null
            val name = value.substringBefore('=')
            val cookieValue = value.substringAfter('=', "")
            Cookie.parse(parsed, "$name=$cookieValue")
        }
        if (cookies.isNotEmpty()) {
            cookieJar.saveFromResponse(parsed, cookies)
            AuroraLog.d("BrowserVM", "transferred ${cookies.size} cookies to the download client")
        }
    }

    fun isBlocked(url: String, type: String, documentDomain: String?): Boolean =
        adBlockRepository.shouldBlock(url, type, documentDomain)

    fun cosmeticCss(domain: String): String = adBlockRepository.cosmeticCss(domain)

    fun blockedTotal(): Int = adBlockRepository.blockedCount.toInt()
}
