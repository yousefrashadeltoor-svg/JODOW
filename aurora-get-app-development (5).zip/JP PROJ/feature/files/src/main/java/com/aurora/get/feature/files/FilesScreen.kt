package com.aurora.get.feature.files

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.aurora.get.core.common.Format
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.database.DownloadEntity
import com.aurora.get.core.designsystem.components.AuroraIcon
import com.aurora.get.core.designsystem.components.AuroraIconButton
import com.aurora.get.core.designsystem.components.AuroraText
import com.aurora.get.core.designsystem.components.GlassPill
import com.aurora.get.core.designsystem.components.GlassSurface
import com.aurora.get.core.designsystem.icons.AuroraIcons
import com.aurora.get.core.designsystem.shaders.AuroraMeshBackground
import com.aurora.get.core.designsystem.theme.AuroraTheme
import com.aurora.get.feature.player.PlayerScreen
import java.io.File

/**
 * The library of the downloaded files with a grid / list layout and the built-in player.
 */
@Composable
fun FilesScreen(
    state: FilesUiState,
    onLayout: (LibraryLayout) -> Unit,
    onFilter: (MediaKind?) -> Unit,
    onPlay: (DownloadEntity) -> Unit,
    onClosePlayer: () -> Unit,
    onDelete: (DownloadEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors

    Box(modifier.fillMaxSize()) {
        AuroraMeshBackground(Modifier.matchParentSize(), intensity = 0.6f)
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(52.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    AuroraText("المكتبة", style = AuroraTheme.typography.headline, color = colors.onBackground)
                    AuroraText(
                        "${state.items.size} ملف",
                        style = AuroraTheme.typography.caption,
                        color = colors.onBackgroundMuted
                    )
                }
                AuroraIconButton(onClick = {
                    onLayout(if (state.layout == LibraryLayout.GRID) LibraryLayout.LIST else LibraryLayout.GRID)
                }) {
                    AuroraIcon(
                        if (state.layout == LibraryLayout.GRID) AuroraIcons.List else AuroraIcons.Grid,
                        "التخطيط",
                        Modifier.size(19.dp),
                        colors.onBackground
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterPill("الكل", state.kindFilter == null) { onFilter(null) }
                FilterPill("فيديو", state.kindFilter == MediaKind.VIDEO) { onFilter(MediaKind.VIDEO) }
                FilterPill("صوت", state.kindFilter == MediaKind.AUDIO) { onFilter(MediaKind.AUDIO) }
                FilterPill("صور", state.kindFilter == MediaKind.IMAGE) { onFilter(MediaKind.IMAGE) }
            }

            Spacer(Modifier.height(14.dp))

            if (state.layout == LibraryLayout.GRID) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(state.items) { item ->
                        GridCard(item, onClick = { onPlay(item) })
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.items) { item ->
                        ListCard(item, onClick = { onPlay(item) }, onDelete = { onDelete(item) })
                    }
                }
            }
            Spacer(Modifier.height(120.dp))
        }
    }

    // ---- the built-in player ----
    state.playing?.let { item ->
        val file = File(item.destinationDir, item.fileName)
        PlayerScreen(
            mediaUrl = file.toURI().toString(),
            title = item.title,
            onClose = onClosePlayer,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun FilterPill(label: String, selected: Boolean, onClick: () -> Unit) {
    val colors = AuroraTheme.colors
    GlassPill {
        Box(
            Modifier
                .background(if (selected) Brush.linearGradient(colors.accentSweep) else Color.Transparent)
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            AuroraText(
                label,
                style = AuroraTheme.typography.label,
                color = if (selected) Color.White else colors.onBackgroundMuted
            )
        }
    }
}

@Composable
private fun GridCard(item: DownloadEntity, onClick: () -> Unit) {
    val colors = AuroraTheme.colors
    GlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = AuroraTheme.shapes.large,
        elevation = 10.dp
    ) {
        Column {
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.35f)
                    .clip(AuroraTheme.shapes.large)
                    .background(Brush.linearGradient(colors.accentSweep)),
                contentAlignment = Alignment.Center
            ) {
                item.thumbnailUrl?.let { url ->
                    AsyncImage(
                        model = url,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                AuroraIcon(
                    when (item.kind) {
                        MediaKind.VIDEO.name -> AuroraIcons.Video
                        MediaKind.AUDIO.name -> AuroraIcons.Audio
                        MediaKind.IMAGE.name -> AuroraIcons.Image
                        else -> AuroraIcons.File
                    },
                    null,
                    Modifier.size(30.dp),
                    Color.White.copy(alpha = 0.92f)
                )
            }
            Column(Modifier.padding(12.dp)) {
                AuroraText(
                    item.title,
                    style = AuroraTheme.typography.label,
                    color = colors.onBackground,
                    maxLines = 1
                )
                AuroraText(
                    Format.bytes(item.totalBytes ?: 0),
                    style = AuroraTheme.typography.caption,
                    color = colors.onBackgroundMuted
                )
            }
        }
    }
}

@Composable
private fun ListCard(item: DownloadEntity, onClick: () -> Unit, onDelete: () -> Unit) {
    val colors = AuroraTheme.colors
    GlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = AuroraTheme.shapes.medium,
        elevation = 6.dp
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AuroraIcon(AuroraIcons.File, null, Modifier.size(18.dp), colors.primary)
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                AuroraText(
                    item.title,
                    style = AuroraTheme.typography.label,
                    color = colors.onBackground,
                    maxLines = 1
                )
                AuroraText(
                    Format.bytes(item.totalBytes ?: 0),
                    style = AuroraTheme.typography.caption,
                    color = colors.onBackgroundMuted
                )
            }
            AuroraIconButton(onClick = onDelete, size = 34.dp) {
                AuroraIcon(AuroraIcons.Trash, "حذف", Modifier.size(15.dp), colors.onBackgroundMuted)
            }
        }
    }
}
