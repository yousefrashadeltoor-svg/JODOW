package com.aurora.get.feature.files

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.database.DownloadDao
import com.aurora.get.core.database.DownloadEntity
import com.aurora.get.engine.downloader.DownloadManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class LibraryLayout { GRID, LIST }

data class FilesUiState(
    val items: List<DownloadEntity> = emptyList(),
    val layout: LibraryLayout = LibraryLayout.GRID,
    val kindFilter: MediaKind? = null,
    val playing: DownloadEntity? = null
)

@HiltViewModel
class FilesViewModel @Inject constructor(
    private val downloadDao: DownloadDao,
    private val downloadManager: DownloadManager
) : ViewModel() {

    private val _state = MutableStateFlow(FilesUiState())
    val state: StateFlow<FilesUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            downloadDao.observeAll().collect { list ->
                _state.update { current ->
                    val filtered = current.kindFilter?.let { kind ->
                        list.filter { it.kind == kind.name }
                    } ?: list
                    current.copy(items = filtered)
                }
            }
        }
    }

    fun setLayout(layout: LibraryLayout) = _state.update { it.copy(layout = layout) }

    fun setFilter(kind: MediaKind?) = _state.update { it.copy(kindFilter = kind) }

    fun play(item: DownloadEntity) = _state.update { it.copy(playing = item) }

    fun closePlayer() = _state.update { it.copy(playing = null) }

    fun delete(item: DownloadEntity) = viewModelScope.launch { downloadManager.delete(item.id, true) }
}
