package com.aurora.get.feature.analyzer

import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.network.RemoteSizeResolver
import com.aurora.get.engine.extractors.MediaFormat
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AnalysisMergeTest {

    private fun format(kind: MediaKind, id: String) = MediaFormat(
        id = id,
        kind = kind,
        ext = "mp4",
        url = "https://example.dev/$id",
        sizeBytes = 1000,
        sizeConfidence = RemoteSizeResolver.Confidence.CONFIRMED
    )

    @Test
    fun `snapshots are merged progressively`() {
        var result = AnalysisResult()
        result = result.mergedWith(
            AnalysisSnapshot(stage = AnalysisStage.STAGE_0, site = SiteInfo(url = "https://a.dev", domain = "a.dev"))
        )
        assertEquals("a.dev", result.site.domain)
        assertTrue(AnalysisStage.STAGE_0 in result.completedStages)

        result = result.mergedWith(
            AnalysisSnapshot(
                stage = AnalysisStage.STAGE_3,
                site = SiteInfo(title = "Title"),
                formats = listOf(format(MediaKind.VIDEO, "v1"))
            )
        )
        assertEquals("Title", result.site.title)
        assertEquals(1, result.videoFormats.size)
        assertTrue(result.hasVideo)
        assertFalse(result.hasAudio)
    }

    @Test
    fun `duplicate formats are removed`() {
        var result = AnalysisResult()
        result = result.mergedWith(AnalysisSnapshot(formats = listOf(format(MediaKind.VIDEO, "v1"))))
        result = result.mergedWith(AnalysisSnapshot(formats = listOf(format(MediaKind.VIDEO, "v1"))))
        assertEquals(1, result.formats.size)
    }

    @Test
    fun `the four smart buttons depend on real content`() {
        val empty = AnalysisResult()
        assertFalse(empty.hasVideo)
        assertFalse(empty.hasAudio)
        assertFalse(empty.hasImages)
        assertFalse(empty.hasFiles)

        val withFiles = empty.mergedWith(
            AnalysisSnapshot(formats = listOf(format(MediaKind.FILE, "f1")))
        )
        assertTrue(withFiles.hasFiles)
        assertFalse(withFiles.hasVideo)
    }

    @Test
    fun `the confirmed size is never downgraded to an approximation`() {
        var result = AnalysisResult()
        result = result.mergedWith(
            AnalysisSnapshot(
                site = SiteInfo(
                    sizeBytes = 500,
                    sizeConfidence = RemoteSizeResolver.Confidence.CONFIRMED
                )
            )
        )
        result = result.mergedWith(
            AnalysisSnapshot(
                site = SiteInfo(
                    sizeBytes = 400,
                    sizeConfidence = RemoteSizeResolver.Confidence.APPROXIMATE
                )
            )
        )
        assertEquals(400L, result.site.sizeBytes)
        assertEquals(RemoteSizeResolver.Confidence.APPROXIMATE, result.site.sizeConfidence)
    }
}
