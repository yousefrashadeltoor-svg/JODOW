package com.aurora.get.feature.analyzer

import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.common.FileNames
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.network.AuroraDns
import com.aurora.get.core.network.RemoteSizeResolver
import com.aurora.get.engine.extractors.ExtractedPage
import com.aurora.get.engine.extractors.LinkResolver
import com.aurora.get.engine.extractors.MediaFormat
import com.aurora.get.engine.extractors.NativeExtractors
import com.aurora.get.engine.extractors.YoutubeDLEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The link analysis pipeline.
 *
 * The five stages run **in parallel** and every stage publishes its result as soon as
 * it is ready, so the UI can fill itself progressively:
 *
 *  | Stage | Target | Output                                     |
 *  |-------|--------|--------------------------------------------|
 *  |   0   | < 50ms | normalised url, domain, cached logo         |
 *  |   1   | < 300ms| content type, real size, OpenGraph data     |
 *  |   2   | < 1.5s | native (fast path) extractors               |
 *  |   3   | < 4s   | full yt-dlp extraction                      |
 *  |   4   | bg     | fallback: jsoup + regex + web view sniffing  |
 */
@Singleton
class AnalyzerEngine @Inject constructor(
    private val linkResolver: LinkResolver,
    private val nativeExtractors: NativeExtractors,
    private val ytDlp: YoutubeDLEngine,
    private val sizeResolver: RemoteSizeResolver,
    private val faviconRepository: FaviconRepository,
    private val dns: AuroraDns,
    private val client: OkHttpClient
) {

    /**
     * Analyses [rawUrl]. The flow never blocks: it emits a snapshot per finished stage.
     * Cancelling the collection cancels every running stage.
     */
    fun analyze(rawUrl: String): Flow<AnalysisSnapshot> = channelFlow {
        val normalized = linkResolver.normalize(rawUrl)
        if (normalized.isBlank()) {
            send(AnalysisSnapshot(stage = AnalysisStage.STAGE_0, finished = true, error = "رابط غير صالح"))
            return@channelFlow
        }

        val domain = linkResolver.domainOf(normalized)

        // ---------------- Stage 0: immediate -------------------------------------
        send(
            AnalysisSnapshot(
                stage = AnalysisStage.STAGE_0,
                site = SiteInfo(url = normalized, domain = domain)
            )
        )
        // Preconnect: resolve the DNS entry before the first real request.
        launch(Dispatchers.IO) { runCatching { dns.prime(domain) } }
        launch(Dispatchers.IO) {
            val logo = faviconRepository.resolve(domain)
            send(
                AnalysisSnapshot(
                    stage = AnalysisStage.STAGE_0,
                    site = SiteInfo(url = normalized, domain = domain, faviconUrl = logo, logoUrl = logo)
                )
            )
        }

        val isMagnet = linkResolver.isMagnet(normalized)
        if (isMagnet) {
            send(
                AnalysisSnapshot(
                    stage = AnalysisStage.STAGE_1,
                    site = SiteInfo(
                        url = normalized,
                        domain = domain,
                        contentType = ContentType.FILE,
                        title = "Magnet link"
                    ),
                    finished = true
                )
            )
            return@channelFlow
        }

        // ---------------- Stage 1: quick probe ----------------------------------
        launch(Dispatchers.IO) {
            try {
                val probe = sizeResolver.resolve(normalized)
                val type = MediaKind.fromMime(probe.contentType)
                send(
                    AnalysisSnapshot(
                        stage = AnalysisStage.STAGE_1,
                        site = SiteInfo(
                            url = probe.finalUrl ?: normalized,
                            domain = domain,
                            contentType = when (type) {
                                MediaKind.VIDEO -> ContentType.VIDEO
                                MediaKind.AUDIO -> ContentType.AUDIO
                                MediaKind.IMAGE -> ContentType.IMAGE
                                MediaKind.ARCHIVE -> ContentType.ARCHIVE
                                MediaKind.DOCUMENT -> ContentType.DOCUMENT
                                MediaKind.APK -> ContentType.APK
                                MediaKind.FILE -> ContentType.FILE
                                else -> ContentType.PAGE
                            },
                            mimeType = probe.contentType,
                            sizeBytes = probe.bytes,
                            sizeConfidence = probe.confidence,
                            acceptsRanges = probe.acceptsRanges
                        )
                    )
                )
            } catch (t: Throwable) {
                AuroraLog.w(TAG, "stage 1 failed: ${t.message}")
            }
        }

        // ---------------- Stage 1b: OpenGraph -----------------------------------
        launch(Dispatchers.IO) {
            val html = fetchHtml(normalized)
            if (html.isNullOrBlank()) return@launch
            val document = Jsoup.parse(html)
            val ogTitle = document.selectFirst("meta[property=og:title]")?.attr("content")
                ?: document.title().takeIf { it.isNotBlank() }
            val ogImage = document.selectFirst("meta[property=og:image]")?.attr("content")
            val ogSite = document.selectFirst("meta[property=og:site_name]")?.attr("content")
            val ogDescription = document.selectFirst("meta[property=og:description]")?.attr("content")
            val logo = runCatching { faviconRepository.logoFromPage(html, domain) }.getOrNull()
            send(
                AnalysisSnapshot(
                    stage = AnalysisStage.STAGE_1,
                    site = SiteInfo(
                        url = normalized,
                        domain = domain,
                        title = ogTitle,
                        thumbnailUrl = ogImage,
                        siteName = ogSite,
                        description = ogDescription,
                        logoUrl = logo
                    )
                )
            )
        }

        // ---------------- Stage 2: native fast path -----------------------------
        launch(Dispatchers.IO) {
            val page = nativeExtractors.extract(normalized)
            if (page != null && page.formats.isNotEmpty()) {
                send(
                    AnalysisSnapshot(
                        stage = AnalysisStage.STAGE_2,
                        site = SiteInfo(
                            url = page.url,
                            domain = domain,
                            title = page.title,
                            thumbnailUrl = page.thumbnailUrl,
                            description = page.description,
                            uploader = page.uploader,
                            durationSeconds = page.durationSeconds,
                            uploadDate = page.uploadDate
                        ),
                        formats = page.formats
                    )
                )
            }
        }

        // ---------------- Stage 3: full yt-dlp extraction ------------------------
        launch(Dispatchers.IO) {
            val page = ytDlp.extract(normalized)
            if (page.formats.isNotEmpty() || page.error == null) {
                send(
                    AnalysisSnapshot(
                        stage = AnalysisStage.STAGE_3,
                        site = SiteInfo(
                            url = page.url,
                            domain = domain,
                            title = page.title,
                            thumbnailUrl = page.thumbnailUrl,
                            description = page.description,
                            uploader = page.uploader,
                            durationSeconds = page.durationSeconds,
                            uploadDate = page.uploadDate
                        ),
                        formats = page.formats,
                        subtitles = page.subtitles,
                        error = page.error
                    )
                )
            }
        }

        // ---------------- Stage 4: background fallback --------------------------
        launch(Dispatchers.IO) {
            val page = fallbackExtraction(normalized, domain)
            if (page.formats.isNotEmpty()) {
                send(
                    AnalysisSnapshot(
                        stage = AnalysisStage.STAGE_4,
                        site = SiteInfo(
                            url = page.url,
                            domain = domain,
                            title = page.title,
                            thumbnailUrl = page.thumbnailUrl
                        ),
                        formats = page.formats
                    )
                )
            }
        }
    }

    /** Stage 4 — a jsoup + regex based last resort. */
    private suspend fun fallbackExtraction(url: String, domain: String): ExtractedPage {
        val html = fetchHtml(url) ?: return ExtractedPage(url = url)
        val parsed = nativeExtractors.parseHtml(url, html)
        val extra = mutableListOf<MediaFormat>()
        Regex("https?://[^\"'\\s]+?\\.(mp4|m4a|mp3|webm|mkv|m3u8|mpd)(\\?[^\"'\\s]*)?", RegexOption.IGNORE_CASE)
            .findAll(html)
            .map { it.groupValues[0] }
            .distinct()
            .take(12)
            .forEach { mediaUrl ->
                extra += MediaFormat(
                    id = "regex-${extra.size}",
                    kind = when (FileNames.extensionOf(mediaUrl)) {
                        "mp4", "webm", "mkv" -> MediaKind.VIDEO
                        "m4a", "mp3" -> MediaKind.AUDIO
                        else -> MediaKind.FILE
                    },
                    ext = FileNames.extensionOf(mediaUrl).orEmpty(),
                    url = mediaUrl,
                    protocol = if (mediaUrl.contains(".m3u8")) "m3u8"
                    else if (mediaUrl.contains(".mpd")) "dash" else "https"
                )
            }
        return parsed.copy(formats = parsed.formats + extra)
    }

    /** Downloads at most 512 KB of the page to extract the OpenGraph tags. */
    private suspend fun fetchHtml(url: String): String? = withContextSafe {
        runCatching {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/131.0.0.0 Mobile Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml")
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val contentType = response.header("Content-Type").orEmpty()
                if (!contentType.contains("html", ignoreCase = true)) return null
                val source = response.body?.source() ?: return null
                source.request(512 * 1024).string()
            }
        }.getOrNull()
    }

    private suspend fun <T> withContextSafe(block: suspend () -> T): T =
        kotlinx.coroutines.withContext(Dispatchers.IO) { block() }

    companion object {
        private const val TAG = "AnalyzerEngine"
    }
}
