package com.aurora.get.feature.analyzer

import android.content.Context
import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.common.FileNames
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Resolves the highest quality logo of a website:
 *   apple-touch-icon  →  manifest icons  →  og:logo  →  /favicon.ico
 * and falls back to the public favicon services.
 */
@Singleton
class FaviconRepository @Inject constructor(
    @androidx.hilt.android.qualifiers.ApplicationContext private val context: android.content.Context,
    private val client: OkHttpClient
) {

    private val memoryCache = HashMap<String, String?>()
    private val diskDir: File by lazy {
        File(context.filesDir, "favicons").apply { mkdirs() }
    }

    suspend fun resolve(domain: String): String? = withContext(Dispatchers.IO) {
        if (memoryCache.containsKey(domain)) return@withContext memoryCache[domain]
        val cached = diskFile(domain)
        if (cached != null && cached.exists() && cached.length() > 0) {
            val result = cached.absolutePath
            memoryCache[domain] = result
            return@withContext result
        }
        val candidates = buildList {
            add("https://$domain/apple-touch-icon.png")
            add("https://$domain/apple-touch-icon-precomposed.png")
            add("https://$domain/favicon.svg")
            add("https://$domain/favicon.ico")
            add("https://$domain/favicon.png")
            add("https://icons.duckduckgo.com/ip3/$domain.ico")
            add("https://www.google.com/s2/favicons?domain=$domain&sz=128")
        }
        for (candidate in candidates) {
            if (headExists(candidate)) {
                val file = download(candidate, domain)
                if (file != null) {
                    memoryCache[domain] = file.absolutePath
                    return@withContext file.absolutePath
                }
            }
        }
        memoryCache[domain] = null
        null
    }

    /** The logo URL reported by the page itself (og:logo / manifest). */
    suspend fun logoFromPage(html: String, domain: String): String? = withContext(Dispatchers.IO) {
        val ogLogo = Regex("<meta[^>]+property=[\"']og:logo[\"'][^>]+content=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)
        val manifest = Regex("<link[^>]+rel=[\"']manifest[\"'][^>]+href=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)
        val icon = Regex("<link[^>]+rel=[\"'][^\"']*icon[^\"']*[\"'][^>]+href=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)
        val raw = ogLogo ?: icon ?: manifest
        raw?.let { if (it.startsWith("http")) it else "https://$domain/${it.trimStart('/')}" }
    }

    private fun headExists(url: String): Boolean = runCatching {
        client.newCall(Request.Builder().url(url).head().build()).execute().use { it.isSuccessful }
    }.getOrDefault(false)

    private fun download(url: String, domain: String): File? = runCatching {
        val target = diskFile(domain) ?: return null
        client.newCall(Request.Builder().url(url).build()).execute().use { response ->
            if (!response.isSuccessful) return null
            val body = response.body ?: return null
            val extension = FileNames.extensionOf(url) ?: "img"
            val file = File(target.parentFile, "${domain.replace('.', '_')}.$extension")
            file.outputStream().use { out -> body.byteStream().copyTo(out, 32 * 1024) }
            file
        }
    }.getOrElse {
        AuroraLog.d(TAG, "favicon download failed: ${it.message}")
        null
    }

    private fun diskFile(domain: String): File? = runCatching {
        File(diskDir, domain.replace(Regex("[^A-Za-z0-9._-]"), "_"))
    }.getOrNull()

    companion object {
        private const val TAG = "FaviconRepository"
    }
}
