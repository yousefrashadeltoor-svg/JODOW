package com.aurora.get.feature.analyzer

import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.network.RemoteSizeResolver
import com.aurora.get.engine.extractors.MediaFormat
import com.aurora.get.engine.extractors.SubtitleTrack

/** The four parallel stages of the analysis pipeline. */
enum class AnalysisStage(val order: Int, val label: String) {
    STAGE_0(0, "تهيئة"),
    STAGE_1(1, "فحص سريع"),
    STAGE_2(2, "استخراج سريع"),
    STAGE_3(3, "تحليل كامل"),
    STAGE_4(4, "فحص احتياطي");

    companion object {
        val ordered = entries.sortedBy { it.order }
    }
}

/** The kind of the analysed content — drives the primary badge. */
enum class ContentType {
    VIDEO, AUDIO, IMAGE, FILE, ARCHIVE, DOCUMENT, APK, PAGE, UNKNOWN
}

/** Everything that is known about the analysed page. */
data class SiteInfo(
    val url: String = "",
    val domain: String = "",
    val siteName: String? = null,
    val faviconUrl: String? = null,
    val logoUrl: String? = null,
    val title: String? = null,
    val thumbnailUrl: String? = null,
    val description: String? = null,
    val contentType: ContentType = ContentType.UNKNOWN,
    val mimeType: String? = null,
    val sizeBytes: Long? = null,
    val sizeConfidence: RemoteSizeResolver.Confidence = RemoteSizeResolver.Confidence.UNKNOWN,
    val durationSeconds: Long? = null,
    val uploader: String? = null,
    val uploadDate: String? = null,
    val acceptsRanges: Boolean = false
)

/** A partial result of one stage. The UI merges them progressively. */
data class AnalysisSnapshot(
    val stage: AnalysisStage,
    val site: SiteInfo = SiteInfo(),
    val formats: List<MediaFormat> = emptyList(),
    val subtitles: List<SubtitleTrack> = emptyList(),
    val finished: Boolean = false,
    val error: String? = null
)

/** The final, merged result. */
data class AnalysisResult(
    val site: SiteInfo = SiteInfo(),
    val formats: List<MediaFormat> = emptyList(),
    val subtitles: List<SubtitleTrack> = emptyList(),
    val completedStages: Set<AnalysisStage> = emptySet(),
    val errors: List<String> = emptyList()
) {
    val videoFormats: List<MediaFormat> get() = formats.filter { it.kind == MediaKind.VIDEO }
    val audioFormats: List<MediaFormat> get() = formats.filter { it.kind == MediaKind.AUDIO }
    val imageFormats: List<MediaFormat> get() = formats.filter { it.kind == MediaKind.IMAGE }
    val fileFormats: List<MediaFormat> get() = formats.filter {
        it.kind == MediaKind.FILE || it.kind == MediaKind.ARCHIVE ||
            it.kind == MediaKind.DOCUMENT || it.kind == MediaKind.APK
    }

    /** The four smart buttons only exist when there is real content behind them. */
    val hasVideo: Boolean get() = videoFormats.isNotEmpty()
    val hasAudio: Boolean get() = audioFormats.isNotEmpty()
    val hasImages: Boolean get() = imageFormats.isNotEmpty()
    val hasFiles: Boolean get() = fileFormats.isNotEmpty() || subtitles.isNotEmpty()

    fun mergedWith(snapshot: AnalysisSnapshot): AnalysisResult {
        val mergedFormats = (formats + snapshot.formats)
            .distinctBy { formatKey(it) }
            .sortedWith(compareByDescending<MediaFormat> { it.height ?: 0 }.thenByDescending { it.bitrateKbps ?: 0 })
        return copy(
            site = mergeSite(site, snapshot.site),
            formats = mergedFormats,
            subtitles = (subtitles + snapshot.subtitles).distinctBy { it.url },
            completedStages = completedStages + snapshot.stage,
            errors = if (snapshot.error != null) errors + snapshot.error!! else errors
        )
    }

    private fun mergeSite(current: SiteInfo, update: SiteInfo): SiteInfo = current.copy(
        url = update.url.ifBlank { current.url },
        domain = update.domain.ifBlank { current.domain },
        siteName = update.siteName ?: current.siteName,
        faviconUrl = update.faviconUrl ?: current.faviconUrl,
        logoUrl = update.logoUrl ?: current.logoUrl,
        title = update.title ?: current.title,
        thumbnailUrl = update.thumbnailUrl ?: current.thumbnailUrl,
        description = update.description ?: current.description,
        contentType = if (update.contentType != ContentType.UNKNOWN) update.contentType else current.contentType,
        mimeType = update.mimeType ?: current.mimeType,
        sizeBytes = update.sizeBytes ?: current.sizeBytes,
        sizeConfidence = if (update.sizeBytes != null) update.sizeConfidence else current.sizeConfidence,
        durationSeconds = update.durationSeconds ?: current.durationSeconds,
        uploader = update.uploader ?: current.uploader,
        uploadDate = update.uploadDate ?: current.uploadDate,
        acceptsRanges = current.acceptsRanges || update.acceptsRanges
    )

    companion object {
        private fun formatKey(format: MediaFormat): String =
            "${format.kind}|${format.quality}|${format.ext}|${format.videoCodec}|${format.audioCodec}|${format.sizeBytes ?: format.url}"
    }
}
