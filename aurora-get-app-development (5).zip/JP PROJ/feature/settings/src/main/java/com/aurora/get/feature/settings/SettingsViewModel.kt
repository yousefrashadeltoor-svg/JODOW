package com.aurora.get.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.core.designsystem.theme.AuroraThemeId
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val settings: AuroraSettings = AuroraSettings(),
    val ytdlpStatus: String = "غير معروف",
    val adblockStatus: String = "غير معروف",
    val updating: Boolean = false
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repository: SettingsRepository
) : ViewModel() {

    private val extra = MutableStateFlow(SettingsUiState())

    val state: StateFlow<SettingsUiState> = kotlinx.coroutines.flow.combine(
        repository.settings,
        extra
    ) { settings, extraState ->
        extraState.copy(settings = settings)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState())

    fun setTheme(theme: AuroraThemeId) = viewModelScope.launch { repository.setTheme(theme) }
    fun setDarkMode(value: Boolean) = viewModelScope.launch { repository.setDarkMode(value) }
    fun setConnections(value: Int) = viewModelScope.launch { repository.setConnections(value) }
    fun setHttp3(value: Boolean) = viewModelScope.launch { repository.setHttp3(value) }
    fun setDnsOverHttps(value: Boolean) = viewModelScope.launch { repository.setDnsOverHttps(value) }
    fun setWifiOnly(value: Boolean) = viewModelScope.launch { repository.setWifiOnly(value) }
    fun setChargingOnly(value: Boolean) = viewModelScope.launch { repository.setChargingOnly(value) }
    fun setAutoOrganize(value: Boolean) = viewModelScope.launch { repository.setAutoOrganize(value) }
    fun setAdBlock(value: Boolean) = viewModelScope.launch { repository.setAdBlock(value) }
    fun setScheduled(value: Boolean) = viewModelScope.launch { repository.setScheduled(value) }
    fun setBatteryGuard(value: Boolean) = viewModelScope.launch { repository.setBatteryGuard(value) }

    fun setStatus(ytdlp: String? = null, adblock: String? = null, updating: Boolean? = null) {
        extra.value = extra.value.copy(
            ytdlpStatus = ytdlp ?: extra.value.ytdlpStatus,
            adblockStatus = adblock ?: extra.value.adblockStatus,
            updating = updating ?: extra.value.updating
        )
    }
}
