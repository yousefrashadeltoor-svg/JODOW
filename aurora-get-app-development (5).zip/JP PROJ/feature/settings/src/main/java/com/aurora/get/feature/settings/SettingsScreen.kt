package com.aurora.get.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.aurora.get.core.designsystem.components.AuroraIcon
import com.aurora.get.core.designsystem.components.AuroraText
import com.aurora.get.core.designsystem.components.GlassPill
import com.aurora.get.core.designsystem.components.GlassSurface
import com.aurora.get.core.designsystem.icons.AuroraIcons
import com.aurora.get.core.designsystem.shaders.AuroraMeshBackground
import com.aurora.get.core.designsystem.theme.AuroraTheme
import com.aurora.get.core.designsystem.theme.AuroraThemeId
import com.aurora.get.core.designsystem.theme.ThemeAssets
import coil3.compose.AsyncImage

/**
 * The settings screen: appearance, network, downloads, privacy and updates.
 */
@Composable
fun SettingsScreen(
    state: SettingsUiState,
    onTheme: (AuroraThemeId) -> Unit,
    onDarkMode: (Boolean) -> Unit,
    onConnections: (Int) -> Unit,
    onHttp3: (Boolean) -> Unit,
    onDns: (Boolean) -> Unit,
    onWifiOnly: (Boolean) -> Unit,
    onChargingOnly: (Boolean) -> Unit,
    onAutoOrganize: (Boolean) -> Unit,
    onAdBlock: (Boolean) -> Unit,
    onScheduled: (Boolean) -> Unit,
    onBatteryGuard: (Boolean) -> Unit,
    onUpdateYtdlp: () -> Unit,
    onUpdateAdBlock: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors

    Box(modifier.fillMaxSize()) {
        AuroraMeshBackground(Modifier.matchParentSize(), intensity = 0.5f)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
        ) {
            Spacer(Modifier.height(52.dp))
            AuroraText("الإعدادات", style = AuroraTheme.typography.headline, color = colors.onBackground)
            Spacer(Modifier.height(16.dp))

            SectionTitle("المظهر")
            GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.large, elevation = 10.dp) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeAssets.all.chunked(3).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                row.forEach { theme ->
                                    ThemePhotoCard(
                                        theme = theme,
                                        selected = state.settings.themeId == theme,
                                        onClick = { onTheme(theme) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                    ToggleRow("الوضع الداكن", state.settings.darkMode, onDarkMode)
                }
            }

            Spacer(Modifier.height(16.dp))
            SectionTitle("الشبكة")
            GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.large, elevation = 10.dp) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextRow("عدد الاتصالات المتوازية", "${state.settings.maxConnections}")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(8, 16, 24, 32).forEach { value ->
                            GlassPill {
                                Box(
                                    Modifier
                                        .background(
                                            if (state.settings.maxConnections == value)
                                                Brush.linearGradient(colors.accentSweep) else Color.Transparent
                                        )
                                        .clickable { onConnections(value) }
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    AuroraText(
                                        "$value",
                                        style = AuroraTheme.typography.label,
                                        color = if (state.settings.maxConnections == value) Color.White
                                        else colors.onBackgroundMuted
                                    )
                                }
                            }
                        }
                    }
                    ToggleRow("HTTP/3 عبر QUIC", state.settings.http3, onHttp3)
                    ToggleRow("DNS عبر HTTPS", state.settings.dnsOverHttps, onDns)
                }
            }

            Spacer(Modifier.height(16.dp))
            SectionTitle("التحميل")
            GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.large, elevation = 10.dp) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ToggleRow("شبكة Wi‑Fi فقط", state.settings.wifiOnly, onWifiOnly)
                    ToggleRow("الشحن فقط", state.settings.chargingOnly, onChargingOnly)
                    ToggleRow("إيقاف عند ضعف البطارية", state.settings.onBatteryLowPause, onBatteryGuard)
                    ToggleRow("تنظيم المجلدات تلقائيًا", state.settings.autoOrganize, onAutoOrganize)
                    ToggleRow("جدولة التحميل", state.settings.scheduledDownloads, onScheduled)
                }
            }

            Spacer(Modifier.height(16.dp))
            SectionTitle("الخصوصية والحجب")
            GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.large, elevation = 10.dp) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ToggleRow("حجب الإعلانات", state.settings.adBlockEnabled, onAdBlock)
                    TextRow("عدد العناصر المحجوبة", state.adblockStatus)
                    ActionRow("تحديث قوائم الحجب", onUpdateAdBlock, state.updating)
                }
            }

            Spacer(Modifier.height(16.dp))
            SectionTitle("التحديثات")
            GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.large, elevation = 10.dp) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextRow("محرك yt-dlp", state.ytdlpStatus)
                    ActionRow("تحديث yt-dlp الآن", onUpdateYtdlp, state.updating)
                }
            }

            Spacer(Modifier.height(16.dp))
            SectionTitle("عن التطبيق")
            GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.large, elevation = 10.dp) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextRow("الإصدار", "1.0.0")
                    AuroraText(
                        "المسؤولية على المستخدم في احترام حقوق النشر. التطبيق لا يتجاوز حماية DRM ولا الاشتراكات المدفوعة، ولا يجمع أي بيانات تحليلية.",
                        style = AuroraTheme.typography.caption,
                        color = colors.warning
                    )
                    AuroraText(
                        "يعمل بالكامل دون اتصال — كل البيانات تبقى على جهازك.",
                        style = AuroraTheme.typography.caption,
                        color = colors.onBackgroundMuted
                    )
                }
            }
            Spacer(Modifier.height(140.dp))
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    AuroraText(
        title,
        style = AuroraTheme.typography.label,
        color = AuroraTheme.colors.onBackgroundMuted,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun ToggleRow(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
    val colors = AuroraTheme.colors
    Row(verticalAlignment = Alignment.CenterVertically) {
        AuroraText(title, style = AuroraTheme.typography.body, color = colors.onBackground, modifier = Modifier.weight(1f))
        GlassPill {
            Box(
                Modifier
                    .background(
                        if (value) Brush.linearGradient(colors.accentSweep)
                        else Brush.linearGradient(listOf(colors.onBackgroundMuted.copy(alpha = 0.22f), colors.onBackgroundMuted.copy(alpha = 0.22f)))
                    )
                    .clickable { onChange(!value) }
                    .padding(horizontal = 16.dp, vertical = 7.dp)
            ) {
                AuroraText(
                    if (value) "مفعّل" else "معطّل",
                    style = AuroraTheme.typography.caption,
                    color = if (value) Color.White else colors.onBackgroundMuted
                )
            }
        }
    }
}

@Composable
private fun TextRow(title: String, value: String) {
    val colors = AuroraTheme.colors
    Row(verticalAlignment = Alignment.CenterVertically) {
        AuroraText(title, style = AuroraTheme.typography.body, color = colors.onBackground, modifier = Modifier.weight(1f))
        AuroraText(value, style = AuroraTheme.typography.caption, color = colors.onBackgroundMuted)
    }
}

@Composable
private fun ActionRow(title: String, onClick: () -> Unit, busy: Boolean) {
    val colors = AuroraTheme.colors
    GlassPill {
        Row(
            Modifier
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AuroraIcon(AuroraIcons.Refresh, null, Modifier.size(14.dp), colors.primary)
            AuroraText(
                if (busy) "جارٍ التحديث…" else title,
                style = AuroraTheme.typography.label,
                color = colors.onBackground
            )
        }
    }
}

@Composable
private fun ThemeSwatch(theme: AuroraThemeId, selected: Boolean, onClick: () -> Unit) {
    val colors = AuroraTheme.colors
    val palette = com.aurora.get.core.designsystem.theme.AuroraPalettes.of(theme, true)
    Box(
        Modifier
            .size(46.dp)
            .clip(AuroraTheme.shapes.medium)
            .background(Brush.linearGradient(palette.accentSweep))
            .clickable(onClick = onClick)
    ) {
        if (selected) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(AuroraTheme.shapes.medium)
                    .background(Color.White.copy(alpha = 0.18f))
            )
            AuroraIcon(
                AuroraIcons.Check,
                null,
                Modifier
                    .align(Alignment.Center)
                    .size(18.dp),
                Color.White
            )
        }
    }
}


/** A real photographic theme preview, loaded from bundled assets (fully offline). */
@Composable
private fun ThemePhotoCard(
    theme: AuroraThemeId,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    Box(
        modifier
            .height(76.dp)
            .clip(AuroraTheme.shapes.medium)
            .background(Color.Black)
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = ThemeAssets.uriFor(theme),
            contentDescription = theme.displayName,
            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.82f))
                    )
                )
        )
        AuroraText(
            theme.displayName,
            style = AuroraTheme.typography.caption,
            color = Color.White,
            maxLines = 1,
            modifier = Modifier.align(Alignment.BottomStart).padding(8.dp)
        )
        if (selected) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(colors.primary.copy(alpha = 0.28f))
                    .border(2.dp, Color.White, AuroraTheme.shapes.medium)
            )
            com.aurora.get.core.designsystem.components.AuroraIcon(
                com.aurora.get.core.designsystem.icons.AuroraIcons.Check,
                null,
                Modifier.align(Alignment.Center).size(22.dp),
                Color.White
            )
        }
    }
}
