package com.aurora.get.feature.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.aurora.get.core.designsystem.theme.AuroraThemeId
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.auroraDataStore: DataStore<Preferences> by preferencesDataStore(name = "aurora_settings")

data class AuroraSettings(
    val themeId: AuroraThemeId = AuroraThemeId.AURORA,
    val darkMode: Boolean = true,
    val maxConnections: Int = 16,
    val http3: Boolean = true,
    val dnsOverHttps: Boolean = false,
    val wifiOnly: Boolean = false,
    val chargingOnly: Boolean = false,
    val autoOrganize: Boolean = true,
    val adBlockEnabled: Boolean = true,
    val scheduledDownloads: Boolean = false,
    val onBatteryLowPause: Boolean = true
)

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private object Keys {
        val THEME = stringPreferencesKey("theme")
        val DARK = booleanPreferencesKey("dark_mode")
        val CONNECTIONS = intPreferencesKey("max_connections")
        val HTTP3 = booleanPreferencesKey("http3")
        val DOH = booleanPreferencesKey("dns_over_https")
        val WIFI_ONLY = booleanPreferencesKey("wifi_only")
        val CHARGING_ONLY = booleanPreferencesKey("charging_only")
        val AUTO_ORGANIZE = booleanPreferencesKey("auto_organize")
        val ADBLOCK = booleanPreferencesKey("adblock_enabled")
        val SCHEDULED = booleanPreferencesKey("scheduled_downloads")
        val BATTERY_GUARD = booleanPreferencesKey("battery_guard")
    }

    val settings: Flow<AuroraSettings> = context.auroraDataStore.data.map { prefs ->
        AuroraSettings(
            themeId = AuroraThemeId.fromKey(prefs[Keys.THEME]),
            darkMode = prefs[Keys.DARK] ?: true,
            maxConnections = (prefs[Keys.CONNECTIONS] ?: 16).coerceIn(1, 32),
            http3 = prefs[Keys.HTTP3] ?: true,
            dnsOverHttps = prefs[Keys.DOH] ?: false,
            wifiOnly = prefs[Keys.WIFI_ONLY] ?: false,
            chargingOnly = prefs[Keys.CHARGING_ONLY] ?: false,
            autoOrganize = prefs[Keys.AUTO_ORGANIZE] ?: true,
            adBlockEnabled = prefs[Keys.ADBLOCK] ?: true,
            scheduledDownloads = prefs[Keys.SCHEDULED] ?: false,
            onBatteryLowPause = prefs[Keys.BATTERY_GUARD] ?: true
        )
    }

    suspend fun setTheme(theme: AuroraThemeId) = context.auroraDataStore.edit { it[Keys.THEME] = theme.storageKey }
    suspend fun setDarkMode(value: Boolean) = context.auroraDataStore.edit { it[Keys.DARK] = value }
    suspend fun setConnections(value: Int) =
        context.auroraDataStore.edit { it[Keys.CONNECTIONS] = value.coerceIn(1, 32) }
    suspend fun setHttp3(value: Boolean) = context.auroraDataStore.edit { it[Keys.HTTP3] = value }
    suspend fun setDnsOverHttps(value: Boolean) = context.auroraDataStore.edit { it[Keys.DOH] = value }
    suspend fun setWifiOnly(value: Boolean) = context.auroraDataStore.edit { it[Keys.WIFI_ONLY] = value }
    suspend fun setChargingOnly(value: Boolean) = context.auroraDataStore.edit { it[Keys.CHARGING_ONLY] = value }
    suspend fun setAutoOrganize(value: Boolean) = context.auroraDataStore.edit { it[Keys.AUTO_ORGANIZE] = value }
    suspend fun setAdBlock(value: Boolean) = context.auroraDataStore.edit { it[Keys.ADBLOCK] = value }
    suspend fun setScheduled(value: Boolean) = context.auroraDataStore.edit { it[Keys.SCHEDULED] = value }
    suspend fun setBatteryGuard(value: Boolean) = context.auroraDataStore.edit { it[Keys.BATTERY_GUARD] = value }
}
