package com.aurora.get.feature.player

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.exoplayer.ExoPlayer
import com.aurora.get.core.common.Format
import com.aurora.get.core.designsystem.components.AuroraText
import com.aurora.get.core.designsystem.components.GlassPill
import com.aurora.get.core.designsystem.components.GlassSurface
import com.aurora.get.core.designsystem.theme.AuroraTheme
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class AdvancedPlayerViewModel @Inject constructor(
    private val controller: LocalPlayerController
) : ViewModel() {

    val repeat = controller.repeat
    val sleepLeft = controller.sleepLeft
    val waveform = controller.waveform
    val audioOnly = controller.audioOnly

    private val _status = MutableStateFlow<String?>(null)
    val status: StateFlow<String?> = _status.asStateFlow()

    fun attach(player: ExoPlayer) = controller.attach(player)
    fun detach() = controller.detach()
    fun cycleRepeat() = controller.cycleRepeat()
    fun sleep(minutes: Int) = if (minutes == 0) controller.cancelSleepTimer() else controller.startSleepTimer(minutes)
    fun toggleAudioOnly() = controller.setAudioOnly(!controller.audioOnly.value)

    fun ringtone(source: File, title: String) {
        _status.value = if (controller.setAsRingtone(source, title)) {
            "تم تعيين النغمة فعليًا"
        } else {
            "امنح إذن تعديل إعدادات النظام ثم أعد المحاولة"
        }
    }

    fun trim(source: File, start: Double, end: Double, output: File) {
        viewModelScope.launch {
            val result = controller.trim(source, start, end, output)
            _status.value = if (result.success) {
                "تم قص ${Format.duration((end - start).toLong())} وحفظه كملف جديد"
            } else {
                result.errorLine ?: "تعذّر القص"
            }
        }
    }

    fun clearStatus() { _status.value = null }
}

/** Compact advanced transport row, inserted into the player screen. */
@Composable
fun AdvancedControls(
    viewModel: AdvancedPlayerViewModel,
    player: ExoPlayer,
    mediaUrl: String,
    title: String,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    val repeat by viewModel.repeat.collectAsStateWithLifecycle()
    val sleep by viewModel.sleepLeft.collectAsStateWithLifecycle()
    val audioOnly by viewModel.audioOnly.collectAsStateWithLifecycle()
    val status by viewModel.status.collectAsStateWithLifecycle()
    var trimOpen by remember { mutableStateOf(false) }

    LaunchedEffect(player) { viewModel.attach(player) }
    DisposableEffect(Unit) { onDispose { viewModel.detach() } }

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ControlChip(
                when (repeat) {
                    RepeatMode.OFF -> "بلا تكرار"
                    RepeatMode.ALL -> "تكرار الكل"
                    RepeatMode.ONE -> "تكرار واحد"
                    RepeatMode.SHUFFLE -> "عشوائي"
                }, repeat != RepeatMode.OFF
            ) { viewModel.cycleRepeat() }

            var sleepStep by remember { mutableStateOf(0) }
            ControlChip(
                if (sleep > 0) "نوم ${Format.duration(sleep / 1000)}" else "مؤقت نوم", sleep > 0
            ) {
                val minutes = when (sleepStep) {
                    0 -> 5; 1 -> 15; 2 -> 30; 3 -> 60; else -> 0
                }
                viewModel.sleep(minutes)
                sleepStep = (sleepStep + 1) % 5
            }

            ControlChip("كأغنية", audioOnly) { viewModel.toggleAudioOnly() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ControlChip("قص مرئي", false) { trimOpen = true }
            ControlChip("نغمة رنين", false) {
                val source = runCatching {
                    if (mediaUrl.startsWith("file:")) File(Uri.parse(mediaUrl).path.orEmpty())
                    else File(Uri.parse(mediaUrl).path.orEmpty())
                }.getOrNull()
                if (source != null && source.exists()) viewModel.ringtone(source, title)
            }
            ControlChip("0.5x / 1x / 2x", false) {
                player.setPlaybackSpeed(if (player.playbackParameters.speed >= 2f) 0.5f else player.playbackParameters.speed + 0.5f)
            }
        }

        VisualizerCanvas(viewModel)

        status?.let {
            GlassPill {
                AuroraText(it, style = typography.caption, color = colors.success,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
            }
            LaunchedEffect(it) {
                kotlinx.coroutines.delay(2600)
                viewModel.clearStatus()
            }
        }
    }

    if (trimOpen) {
        VisualTrimSheet(
            mediaUrl = mediaUrl,
            durationSeconds = player.duration.takeIf { it > 0 }?.div(1000.0) ?: 60.0,
            waveform = viewModel.waveform.collectAsStateWithLifecycle().value,
            onClose = { trimOpen = false },
            onTrim = { start, end ->
                val source = runCatching { File(Uri.parse(mediaUrl).path.orEmpty()) }.getOrNull()
                if (source != null && source.exists()) {
                    val output = File(source.parentFile, "${source.nameWithoutExtension}-trim${if (source.extension.isBlank()) ".mp4" else ".${source.extension}"}")
                    viewModel.trim(source, start, end, output)
                }
            }
        )
    }
}

@Composable
private fun ControlChip(label: String, active: Boolean, onClick: () -> Unit) {
    val colors = AuroraTheme.colors
    GlassPill {
        Box(
            Modifier
                .background(if (active) Brush.linearGradient(colors.accentSweep) else Color.Transparent)
                .clip(AuroraTheme.shapes.pill)
                .clickable(onClick = onClick)
                .padding(horizontal = 11.dp, vertical = 7.dp)
        ) {
            AuroraText(label, style = AuroraTheme.typography.caption,
                color = if (active) Color.White else colors.onBackgroundMuted)
        }
    }
}

/** Real waveform from android.media.audiofx.Visualizer. */
@Composable
private fun VisualizerCanvas(viewModel: AdvancedPlayerViewModel) {
    val wave by viewModel.waveform.collectAsStateWithLifecycle()
    val colors = AuroraTheme.colors
    GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.medium, elevation = 6.dp) {
        Canvas(Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 10.dp)) {
            val points = if (wave.isEmpty()) {
                ByteArray(64) { i -> (kotlin.math.sin(i / 5.0) * 40).toInt().toByte() }
            } else wave
            val path = Path()
            val step = size.width / points.size
            points.forEachIndexed { index, value ->
                val x = index * step
                val y = size.height / 2 + (value / 128f) * (size.height / 2)
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(
                path = path,
                brush = Brush.horizontalGradient(colors.accentSweep),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
            )
        }
    }
}

/**
 * Hand-driven, visual trimming: two draggable handles over the real waveform.
 * No numeric text fields — the user drags the actual range.
 */
@Composable
private fun VisualTrimSheet(
    mediaUrl: String,
    durationSeconds: Double,
    waveform: ByteArray,
    onClose: () -> Unit,
    onTrim: (Double, Double) -> Unit
) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    var startFraction by remember { mutableFloatStateOf(0.1f) }
    var endFraction by remember { mutableFloatStateOf(0.85f) }
    var dragTarget by remember { mutableStateOf(0) }
    var widthPx by remember { mutableFloatStateOf(1f) }

    com.aurora.get.core.designsystem.components.GlassBottomSheet(
        visible = true, onDismiss = onClose, title = "القص المرئي اليدوي"
    ) {
        GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.medium, elevation = 6.dp) {
            Column(Modifier.padding(14.dp)) {
                AuroraText("اسحب المقبضين لتحديد المقطع", style = typography.caption,
                    color = colors.onBackgroundMuted)
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(90.dp)
                        .background(colors.backgroundAlt, AuroraTheme.shapes.small)
                        .pointerInput(Unit) {
                            widthPx = size.width.toFloat()
                            detectHorizontalDragGestures(
                                onDragStart = { x ->
                                    dragTarget = if (kotlin.math.abs(x - startFraction * widthPx) <
                                        kotlin.math.abs(x - endFraction * widthPx)) 1 else 2
                                },
                                onDragEnd = { dragTarget = 0 },
                                onHorizontalDrag = { _, delta ->
                                    val f = delta / widthPx
                                    if (dragTarget == 1) {
                                        startFraction = (startFraction + f).coerceIn(0f, endFraction - 0.03f)
                                    } else if (dragTarget == 2) {
                                        endFraction = (endFraction + f).coerceIn(startFraction + 0.03f, 1f)
                                    }
                                }
                            )
                        }
                ) {
                    Canvas(Modifier.fillMaxWidth().height(90.dp)) {
                        val points = waveform.takeIf { it.isNotEmpty() }
                            ?: ByteArray(120) { i -> (kotlin.math.sin(i / 7.0) * 60).toInt().toByte() }
                        val step = size.width / points.size
                        points.forEachIndexed { index, value ->
                            val x = index * step
                            val h = kotlin.math.abs(value / 128f) * size.height * 0.8f
                            val inRange = index.toFloat() / points.size in startFraction..endFraction
                            drawLine(
                                color = if (inRange) colors.primary else colors.onBackgroundMuted.copy(alpha = 0.28f),
                                start = Offset(x, size.height / 2 - h / 2),
                                end = Offset(x, size.height / 2 + h / 2),
                                strokeWidth = 2.dp.toPx()
                            )
                        }
                        drawLine(Color.White, Offset(startFraction * size.width, 0f),
                            Offset(startFraction * size.width, size.height), strokeWidth = 3.dp.toPx())
                        drawLine(Color.White, Offset(endFraction * size.width, 0f),
                            Offset(endFraction * size.width, size.height), strokeWidth = 3.dp.toPx())
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row {
                    BasicText(
                        text = "${Format.duration((startFraction * durationSeconds).toLong())} → ${Format.duration((endFraction * durationSeconds).toLong())}",
                        style = typography.label.copy(color = colors.onBackground)
                    )
                }
                Spacer(Modifier.height(12.dp))
                com.aurora.get.core.designsystem.components.AuroraButton(
                    text = "قص وحفظ ملف جديد",
                    onClick = {
                        onTrim(startFraction * durationSeconds, endFraction * durationSeconds)
                        onClose()
                    }
                )
                AuroraText("المصدر: $mediaUrl", style = typography.caption,
                    color = colors.onBackgroundMuted, maxLines = 1,
                    modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}
