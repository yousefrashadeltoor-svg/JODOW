package com.aurora.get.feature.player

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.CountDownTimer
import android.provider.MediaStore
import android.provider.Settings
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.aurora.get.core.common.AuroraLog
import com.aurora.get.engine.media.FfmpegEngine
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

enum class RepeatMode { OFF, ALL, ONE, SHUFFLE }

/**
 * Real player services: sleep timer, repeat, hardware visualiser, ringtone
 * assignment, audio-only mode and real FFmpeg trimming.
 */
@Singleton
class LocalPlayerController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val ffmpeg: FfmpegEngine
) {
    private var player: ExoPlayer? = null
    private var visualizer: Visualizer? = null
    private var sleepTimer: CountDownTimer? = null

    private val _repeat = MutableStateFlow(RepeatMode.OFF)
    val repeat: StateFlow<RepeatMode> = _repeat.asStateFlow()

    private val _sleepLeft = MutableStateFlow(0L)
    val sleepLeft: StateFlow<Long> = _sleepLeft.asStateFlow()

    private val _waveform = MutableStateFlow(ByteArray(0))
    val waveform: StateFlow<ByteArray> = _waveform.asStateFlow()

    private val _audioOnly = MutableStateFlow(false)
    val audioOnly: StateFlow<Boolean> = _audioOnly.asStateFlow()

    fun attach(player: ExoPlayer) {
        this.player = player
        applyRepeat()
        startVisualizer(player.audioSessionId)
    }

    fun detach() {
        sleepTimer?.cancel()
        sleepTimer = null
        runCatching { visualizer?.release() }
        visualizer = null
        player = null
    }

    // ------------------------------------------------------------- repeat ---
    fun setRepeat(mode: RepeatMode) {
        _repeat.value = mode
        applyRepeat()
    }

    fun cycleRepeat() {
        val next = RepeatMode.entries[(_repeat.value.ordinal + 1) % RepeatMode.entries.size]
        setRepeat(next)
    }

    private fun applyRepeat() {
        val p = player ?: return
        p.repeatMode = when (_repeat.value) {
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
            RepeatMode.SHUFFLE -> Player.REPEAT_MODE_ALL
        }
        p.shuffleModeEnabled = _repeat.value == RepeatMode.SHUFFLE
    }

    // -------------------------------------------------------- sleep timer ---
    fun startSleepTimer(minutes: Int) {
        sleepTimer?.cancel()
        val millis = minutes * 60_000L
        sleepTimer = object : CountDownTimer(millis, 1000) {
            override fun onTick(remaining: Long) { _sleepLeft.value = remaining }
            override fun onFinish() {
                _sleepLeft.value = 0
                player?.pause()
                AuroraLog.i(TAG, "sleep timer stopped playback")
            }
        }.start()
    }

    fun cancelSleepTimer() {
        sleepTimer?.cancel()
        sleepTimer = null
        _sleepLeft.value = 0
    }

    // ---------------------------------------------------------- visualizer ---
    private fun startVisualizer(sessionId: Int) {
        if (sessionId == 0) return
        runCatching {
            visualizer?.release()
            visualizer = Visualizer(sessionId).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(256)
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                        if (waveform != null) _waveform.value = waveform.copyOf()
                    }
                    override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) = Unit
                }, Visualizer.getMaxCaptureRate() / 2, true, false)
                enabled = true
            }
        }.onFailure { AuroraLog.w(TAG, "visualiser unavailable: ${it.message}") }
    }

    fun setAudioOnly(value: Boolean) { _audioOnly.value = value }

    // ------------------------------------------------------- ringtone (real) ---
    /**
     * Writes a real ringtone into MediaStore and sets it as the device default.
     * Requires ACTION_MANAGE_WRITE_SETTINGS — the caller must request it first.
     */
    fun setAsRingtone(source: File, title: String): Boolean {
        if (!source.exists()) return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.System.canWrite(context)) {
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                data = android.net.Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return false
        }
        return runCatching {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.TITLE, title)
                put(MediaStore.MediaColumns.DISPLAY_NAME, "$title.mp3")
                put(MediaStore.MediaColumns.MIME_TYPE, "audio/mpeg")
                put(MediaStore.Audio.Media.IS_RINGTONE, true)
                put(MediaStore.Audio.Media.IS_NOTIFICATION, false)
                put(MediaStore.Audio.Media.IS_ALARM, false)
                put(MediaStore.Audio.Media.IS_MUSIC, true)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Ringtones/𝒥𝒪 DON")
                }
            }
            val uri = context.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: return false
            context.contentResolver.openOutputStream(uri)?.use { out ->
                source.inputStream().use { input -> input.copyTo(out, 128 * 1024) }
            }
            RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_RINGTONE, uri)
            true
        }.getOrElse {
            AuroraLog.w(TAG, "ringtone assignment failed: ${it.message}")
            false
        }
    }

    // ------------------------------------------------------------- trimming ---
    /** Real FFmpeg trim of a user-selected range (no re-encode when possible). */
    suspend fun trim(source: File, startSeconds: Double, endSeconds: Double, output: File): FfmpegEngine.Result =
        ffmpeg.trim(source, output, startSeconds, endSeconds - startSeconds)

    /** Extracts the audio of a video to a real standalone audio file. */
    suspend fun extractAudio(source: File, output: File) = ffmpeg.extractAudio(source, output, "copy")

    companion object {
        private const val TAG = "LocalPlayerController"
    }
}
