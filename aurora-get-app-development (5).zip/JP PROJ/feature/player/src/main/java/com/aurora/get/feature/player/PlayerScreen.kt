package com.aurora.get.feature.player

import android.app.PictureInPictureParams
import android.content.Context
import android.os.Build
import android.view.LayoutInflater
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.aurora.get.core.designsystem.components.AuroraIcon
import com.aurora.get.core.designsystem.components.AuroraIconButton
import com.aurora.get.core.designsystem.components.AuroraText
import com.aurora.get.core.designsystem.components.GlassPill
import com.aurora.get.core.designsystem.components.GlassSurface
import com.aurora.get.core.designsystem.icons.AuroraIcons
import com.aurora.get.core.designsystem.theme.AuroraTheme

/**
 * The built-in media player (Media3 / ExoPlayer) with the Aurora glass controls.
 */
@Composable
fun PlayerScreen(
    mediaUrl: String,
    title: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(false) }
    var position by remember { mutableFloatStateOf(0f) }
    var duration by remember { mutableFloatStateOf(0f) }
    var speed by remember { mutableStateOf(1f) }
    var showControls by remember { mutableStateOf(true) }

    val advanced = hiltViewModel<AdvancedPlayerViewModel>()
    val player = remember(mediaUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(mediaUrl))
            prepare()
            playWhenReady = false
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(value: Boolean) {
                isPlaying = value
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    Box(modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                LayoutInflater.from(ctx).inflate(
                    com.aurora.get.feature.player.R.layout.aurora_player_view,
                    null
                ) as android.view.View
            },
            update = { view ->
                (view as androidx.media3.ui.PlayerView).player = player
            },
            modifier = Modifier.fillMaxSize()
        )

        // ---- top bar ----
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 44.dp, start = 14.dp, end = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AuroraIconButton(onClick = onClose) {
                AuroraIcon(AuroraIcons.Close, "إغلاق", Modifier.size(18.dp), colors.onBackground)
            }
            AuroraText(
                text = title,
                style = AuroraTheme.typography.label,
                color = Color.White,
                modifier = Modifier.weight(1f).padding(start = 10.dp),
                maxLines = 1
            )
            AuroraIconButton(onClick = { enterPip(context) }) {
                AuroraIcon(AuroraIcons.Expand, "صورة داخل صورة", Modifier.size(18.dp), colors.onBackground)
            }
        }

        AdvancedControls(
            viewModel = advanced,
            player = player,
            mediaUrl = mediaUrl,
            title = title,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 100.dp, start = 14.dp, end = 14.dp)
        )

        // ---- bottom controls ----
        if (showControls) {
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(bottom = 34.dp, start = 14.dp, end = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GlassSurface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = AuroraTheme.shapes.large,
                    elevation = 18.dp
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AuroraSeekBar(
                            progress = if (duration > 0) position / duration else 0f,
                            onProgress = {
                                position = it * duration
                                if (duration > 0) player.seekTo((it * duration).toLong())
                            }
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AuroraIconButton(
                                onClick = {
                                    if (player.isPlaying) player.pause() else player.play()
                                },
                                size = 44.dp
                            ) {
                                AuroraIcon(
                                    if (isPlaying) AuroraIcons.Pause else AuroraIcons.Play,
                                    "تشغيل/إيقاف",
                                    Modifier.size(20.dp),
                                    colors.onBackground
                                )
                            }
                            GlassPill {
                                AuroraText(
                                    text = "${speed}x",
                                    style = AuroraTheme.typography.caption,
                                    color = colors.onBackground,
                                    modifier = Modifier
                                        .clickable {
                                            speed = when (speed) {
                                                1f -> 1.25f
                                                1.25f -> 1.5f
                                                1.5f -> 2f
                                                else -> 1f
                                            }
                                            player.setPlaybackSpeed(speed)
                                        }
                                        .padding(horizontal = 12.dp, vertical = 7.dp)
                                )
                            }
                            Spacer(Modifier.weight(1f))
                            AuroraText(
                                text = "${formatTime(player.currentPosition)} / ${formatTime(player.duration)}",
                                style = AuroraTheme.typography.caption,
                                color = colors.onBackgroundMuted
                            )
                        }
                    }
                }
            }
        }
    }

    // keep the slider in sync with the player
    DisposableEffect(player) {
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val runnable = object : Runnable {
            override fun run() {
                if (player.duration > 0) {
                    duration = player.duration.toFloat()
                    position = player.currentPosition.toFloat()
                }
                handler.postDelayed(this, 500)
            }
        }
        handler.post(runnable)
        onDispose { handler.removeCallbacks(runnable) }
    }
}

private fun formatTime(milliseconds: Long): String {
    if (milliseconds <= 0) return "0:00"
    val total = milliseconds / 1000
    val m = total / 60
    val s = total % 60
    return "%d:%02d".format(m, s)
}

private fun enterPip(context: Context) {
    val activity = context as? android.app.Activity ?: return
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    runCatching {
        val params = PictureInPictureParams.Builder()
            .setAspectRatio(android.util.Rational(16, 9))
            .build()
        activity.enterPictureInPictureMode(params)
    }
}

/** A fully custom seek bar — no Material `Slider` anywhere. */
@Composable
fun AuroraSeekBar(
    progress: Float,
    onProgress: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    Box(
        modifier
            .fillMaxWidth()
            .height(26.dp)
            .clickable { }
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(5.dp)
                .align(Alignment.CenterStart)
                .clip(AuroraTheme.shapes.pill)
                .background(colors.onBackgroundMuted.copy(alpha = 0.28f))
        )
        Box(
            Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .height(5.dp)
                .align(Alignment.CenterStart)
                .clip(AuroraTheme.shapes.pill)
                .background(Brush.horizontalGradient(colors.accentSweep))
        )
        Box(
            Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .height(14.dp)
                .align(Alignment.CenterStart),
            contentAlignment = Alignment.CenterStart
        ) {
            Box(
                Modifier
                    .size(14.dp)
                    .clip(AuroraTheme.shapes.pill)
                    .background(Color.White)
            )
        }
    }
}
