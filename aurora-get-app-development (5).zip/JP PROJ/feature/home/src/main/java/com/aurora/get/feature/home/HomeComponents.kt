package com.aurora.get.feature.home

import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.aurora.get.core.common.Format
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.database.DownloadEntity
import com.aurora.get.core.designsystem.components.AuroraIcon
import com.aurora.get.core.designsystem.components.AuroraIconButton
import com.aurora.get.core.designsystem.components.AuroraProgressBar
import com.aurora.get.core.designsystem.components.AuroraShimmer
import com.aurora.get.core.designsystem.components.AuroraText
import com.aurora.get.core.designsystem.components.GlassPill
import com.aurora.get.core.designsystem.components.GlassSurface
import com.aurora.get.core.designsystem.components.StreamingText
import com.aurora.get.core.designsystem.icons.AuroraIcons
import com.aurora.get.core.designsystem.theme.AuroraTheme
import com.aurora.get.core.network.RemoteSizeResolver
import com.aurora.get.engine.extractors.MediaFormat

/**
 * The information card. Every field fades in as soon as the matching stage delivers it.
 */
@Composable
fun AnalysisInfoCard(
    state: HomeUiState,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    val site = state.result.site

    GlassSurface(modifier = modifier.fillMaxWidth(), shape = AuroraTheme.shapes.extraLarge, elevation = 20.dp) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            // ---- site header -------------------------------------------------
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(AuroraTheme.shapes.medium)
                        .background(colors.backgroundAlt)
                        .border(1.dp, colors.glassStroke, AuroraTheme.shapes.medium),
                    contentAlignment = Alignment.Center
                ) {
                    if (site.faviconUrl != null) {
                        AsyncImage(
                            model = site.faviconUrl,
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.size(26.dp)
                        )
                    } else {
                        AuroraIcon(
                            imageVector = AuroraIcons.Globe,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp),
                            tint = colors.onBackgroundMuted
                        )
                    }
                }
                Column(Modifier.padding(start = 12.dp).weight(1f)) {
                    AuroraText(
                        text = site.siteName ?: site.domain,
                        style = typography.label,
                        color = colors.onBackground,
                        maxLines = 1
                    )
                    AuroraText(
                        text = site.domain,
                        style = typography.caption,
                        color = colors.onBackgroundMuted,
                        maxLines = 1
                    )
                }
                ContentTypeBadge(site.contentType)
            }

            // ---- title -------------------------------------------------------
            if (site.title != null) {
                StreamingText(
                    text = site.title,
                    style = typography.title,
                    modifier = Modifier.fillMaxWidth()
                )
            } else if (state.isAnalyzing) {
                AuroraShimmer(Modifier.fillMaxWidth().height(22.dp))
            }

            // ---- thumbnail ---------------------------------------------------
            if (site.thumbnailUrl != null) {
                AsyncImage(
                    model = site.thumbnailUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(168.dp)
                        .clip(AuroraTheme.shapes.large)
                )
            }

            // ---- meta row ----------------------------------------------------
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (site.durationSeconds != null) {
                    MetaChip(AuroraIcons.Clock, Format.duration(site.durationSeconds))
                }
                if (site.uploader != null) {
                    MetaChip(AuroraIcons.Shield, site.uploader)
                }
                if (site.sizeBytes != null) {
                    SizeChip(site.sizeBytes, site.sizeConfidence)
                }
            }
        }
    }
}

@Composable
private fun ContentTypeBadge(type: com.aurora.get.feature.analyzer.ContentType) {
    val colors = AuroraTheme.colors
    val label = when (type) {
        com.aurora.get.feature.analyzer.ContentType.VIDEO -> "فيديو"
        com.aurora.get.feature.analyzer.ContentType.AUDIO -> "صوت"
        com.aurora.get.feature.analyzer.ContentType.IMAGE -> "صورة"
        com.aurora.get.feature.analyzer.ContentType.FILE -> "ملف"
        com.aurora.get.feature.analyzer.ContentType.ARCHIVE -> "أرشيف"
        com.aurora.get.feature.analyzer.ContentType.DOCUMENT -> "مستند"
        com.aurora.get.feature.analyzer.ContentType.APK -> "تطبيق"
        com.aurora.get.feature.analyzer.ContentType.PAGE -> "صفحة"
        com.aurora.get.feature.analyzer.ContentType.UNKNOWN -> "غير معروف"
    }
    GlassPill {
        AuroraText(
            text = label,
            style = AuroraTheme.typography.caption,
            color = colors.onBackground,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun MetaChip(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    val colors = AuroraTheme.colors
    GlassPill {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AuroraIcon(icon, null, Modifier.size(13.dp), colors.onBackgroundMuted)
            AuroraText(label, style = AuroraTheme.typography.caption, color = colors.onBackgroundMuted, maxLines = 1)
        }
    }
}

/**
 * The size chip. A confirmed size is shown as is, an approximated one always carries
 * the `≈` sign — the two are never mixed.
 */
@Composable
fun SizeChip(sizeBytes: Long?, confidence: RemoteSizeResolver.Confidence) {
    val colors = AuroraTheme.colors
    val context = LocalContext.current
    val text = when {
        sizeBytes == null -> "غير معروف"
        confidence == RemoteSizeResolver.Confidence.CONFIRMED -> Format.bytes(sizeBytes)
        else -> Format.approxBytes(sizeBytes)
    }
    GlassPill {
        Row(
            Modifier
                .combinedClickable(
                    onClick = {},
                    onLongClick = {
                        sizeBytes?.let { Toast.makeText(context, Format.exactBytes(it), Toast.LENGTH_SHORT).show() }
                    }
                )
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AuroraIcon(AuroraIcons.Download, null, Modifier.size(13.dp), colors.onBackgroundMuted)
            AuroraText(text, style = AuroraTheme.typography.caption, color = colors.onBackgroundMuted, maxLines = 1)
        }
    }
}

/**
 * The four smart buttons. A button is only rendered when there is real content of
 * that type — an empty button never appears.
 */
@Composable
fun SmartButtonsRow(
    state: HomeUiState,
    onIntent: (HomeIntent) -> Unit,
    modifier: Modifier = Modifier
) {
    val result = state.result
    val entries = buildList {
        if (result.hasAudio) add(Triple(ContentKind.AUDIO, AuroraIcons.Audio, result.audioFormats.size))
        if (result.hasImages) add(Triple(ContentKind.IMAGE, AuroraIcons.Image, result.imageFormats.size))
        if (result.hasVideo) add(Triple(ContentKind.VIDEO, AuroraIcons.Video, result.videoFormats.size))
        if (result.hasFiles) add(Triple(ContentKind.FILE, AuroraIcons.File, result.fileFormats.size + result.subtitles.size))
    }
    if (entries.isEmpty()) return

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        entries.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                row.forEach { (kind, icon, count) ->
                    SmartButton(
                        kind = kind,
                        icon = icon,
                        count = count,
                        onClick = { onIntent(HomeIntent.OpenSheet(kind)) },
                        modifier = Modifier.weight(1f)
                    )
                }
                if (row.size == 1) Box(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun SmartButton(
    kind: ContentKind,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    count: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    val scale by animateFloatAsState(1f, label = "smartButton")

    GlassSurface(
        modifier = modifier
            .clickable(onClick = onClick)
            .height(72.dp),
        shape = AuroraTheme.shapes.large,
        tint = colors.glassTint,
        elevation = 12.dp
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                Modifier
                    .size(38.dp)
                    .clip(AuroraTheme.shapes.medium)
                    .background(Brush.linearGradient(colors.accentSweep)),
                contentAlignment = Alignment.Center
            ) {
                AuroraIcon(icon, null, Modifier.size(20.dp), Color.White)
            }
            Column(Modifier.weight(1f)) {
                AuroraText(kind.title, style = AuroraTheme.typography.label, color = colors.onBackground)
                AuroraText(
                    text = "$count عنصر",
                    style = AuroraTheme.typography.caption,
                    color = colors.onBackgroundMuted
                )
            }
        }
    }
}

/** The list of the available formats inside the glass bottom sheet. */
@Composable
fun FormatList(
    formats: List<MediaFormat>,
    onDownload: (MediaFormat) -> Unit,
    onConvert: (MediaFormat) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        formats.forEach { format ->
            FormatRow(format, onDownload, onConvert)
        }
    }
}

@Composable
private fun FormatRow(
    format: MediaFormat,
    onDownload: (MediaFormat) -> Unit,
    onConvert: (MediaFormat) -> Unit
) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography

    GlassSurface(
        modifier = Modifier.fillMaxWidth(),
        shape = AuroraTheme.shapes.medium,
        elevation = 6.dp
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                AuroraText(
                    text = format.quality ?: format.ext.uppercase(),
                    style = typography.label,
                    color = colors.onBackground,
                    maxLines = 1
                )
                val details = buildList {
                    format.ext.takeIf { it.isNotBlank() }?.let { add(it.uppercase()) }
                    format.videoCodec?.let { add("V: $it") }
                    format.audioCodec?.let { add("A: $it") }
                    format.fps?.let { add("${it}fps") }
                    format.bitrateKbps?.let { add("${it}kbps") }
                    format.resolution?.let { add(it) }
                }.joinToString(" • ")
                AuroraText(
                    text = details,
                    style = typography.caption,
                    color = colors.onBackgroundMuted,
                    maxLines = 1
                )
                if (format.sizeBytes != null) {
                    val confidence = format.sizeConfidence
                    AuroraText(
                        text = if (confidence == RemoteSizeResolver.Confidence.CONFIRMED) {
                            Format.bytes(format.sizeBytes)
                        } else {
                            Format.approxBytes(format.sizeBytes)
                        },
                        style = typography.caption,
                        color = colors.onBackgroundMuted
                    )
                }
            }
            AuroraIconButton(onClick = { onConvert(format) }, contentDescription = "تحويل") {
                AuroraIcon(AuroraIcons.Converter, null, Modifier.size(18.dp), colors.onBackgroundMuted)
            }
            AuroraIconButton(onClick = { onDownload(format) }, contentDescription = "تحميل") {
                AuroraIcon(AuroraIcons.Download, null, Modifier.size(18.dp), colors.onBackground)
            }
        }
    }
}

/** The list of the latest downloads. */
@Composable
fun RecentDownloads(
    downloads: List<DownloadEntity>,
    modifier: Modifier = Modifier
) {
    if (downloads.isEmpty()) return
    val colors = AuroraTheme.colors
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        AuroraText(
            text = "آخر التحميلات",
            style = AuroraTheme.typography.label,
            color = colors.onBackgroundMuted
        )
        downloads.forEach { download ->
            GlassSurface(
                modifier = Modifier.fillMaxWidth(),
                shape = AuroraTheme.shapes.medium,
                elevation = 6.dp
            ) {
                Row(
                    Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AuroraIcon(
                        imageVector = when (download.kind) {
                            MediaKind.VIDEO.name -> AuroraIcons.Video
                            MediaKind.AUDIO.name -> AuroraIcons.Audio
                            MediaKind.IMAGE.name -> AuroraIcons.Image
                            else -> AuroraIcons.File
                        },
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                        tint = colors.primary
                    )
                    Column(Modifier.weight(1f)) {
                        AuroraText(
                            text = download.title,
                            style = AuroraTheme.typography.label,
                            color = colors.onBackground,
                            maxLines = 1
                        )
                        AuroraText(
                            text = Format.bytes(download.downloadedBytes) +
                                (download.totalBytes?.let { " / ${Format.bytes(it)}" } ?: ""),
                            style = AuroraTheme.typography.caption,
                            color = colors.onBackgroundMuted
                        )
                    }
                    if (download.status == "RUNNING") {
                        AuroraProgressBar(
                            progress = if ((download.totalBytes ?: 0) > 0) {
                                download.downloadedBytes.toFloat() / download.totalBytes
                            } else 0f,
                            modifier = Modifier.width(96.dp)
                        )
                    }
                }
            }
        }
    }
}
