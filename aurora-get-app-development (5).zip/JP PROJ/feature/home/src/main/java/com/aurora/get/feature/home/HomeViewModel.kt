package com.aurora.get.feature.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.database.DownloadDao
import com.aurora.get.core.database.DownloadEntity
import com.aurora.get.engine.downloader.DownloadManager
import com.aurora.get.engine.downloader.DownloadForegroundService
import com.aurora.get.engine.downloader.DownloadRequest
import com.aurora.get.engine.extractors.MediaFormat
import com.aurora.get.feature.analyzer.AnalysisResult
import com.aurora.get.feature.analyzer.AnalysisStage
import com.aurora.get.feature.analyzer.AnalyzerEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/** The four smart buttons. */
enum class ContentKind(val title: String) {
    AUDIO("صوت"),
    IMAGE("صور"),
    VIDEO("فيديو"),
    FILE("ملفات")
}

/** MVI intents. */
sealed interface HomeIntent {
    data class InputChanged(val value: String) : HomeIntent
    data object Analyze : HomeIntent
    data object Clear : HomeIntent
    data class OpenSheet(val kind: ContentKind) : HomeIntent
    data object DismissSheet : HomeIntent
    data class DownloadFormat(val format: MediaFormat) : HomeIntent
    data class DismissClipboardChip : HomeIntent
}

data class HomeUiState(
    val input: String = "",
    val isAnalyzing: Boolean = false,
    val result: AnalysisResult = AnalysisResult(),
    val completedStages: Set<AnalysisStage> = emptySet(),
    val openSheet: ContentKind? = null,
    val clipboardLink: String? = null,
    val error: String? = null,
    val recentDownloads: List<DownloadEntity> = emptyList(),
    val queuedMessage: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    application: Application,
    private val analyzerEngine: AnalyzerEngine,
    private val downloadManager: DownloadManager,
    private val downloadDao: DownloadDao,
    private val clipboardWatcher: ClipboardWatcher
) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    private var analysisJob: Job? = null
    private var debounceJob: Job? = null

    init {
        viewModelScope.launch {
            downloadDao.observeAll().collectLatest { list ->
                _state.update { it.copy(recentDownloads = list.take(6)) }
            }
        }
        viewModelScope.launch {
            clipboardWatcher.detectedLinks().collectLatest { link ->
                if (link != null && link != _state.value.input) {
                    _state.update { it.copy(clipboardLink = link) }
                }
            }
        }
    }

    fun onIntent(intent: HomeIntent) {
        when (intent) {
            is HomeIntent.InputChanged -> {
                _state.update { it.copy(input = intent.value, error = null) }
                scheduleAnalysis(intent.value)
            }

            HomeIntent.Analyze -> startAnalysis(_state.value.input)
            HomeIntent.Clear -> {
                analysisJob?.cancel()
                _state.update {
                    it.copy(input = "", result = AnalysisResult(), completedStages = emptySet(), error = null)
                }
            }

            is HomeIntent.OpenSheet -> _state.update { it.copy(openSheet = intent.kind) }
            HomeIntent.DismissSheet -> _state.update { it.copy(openSheet = null) }
            HomeIntent.DismissClipboardChip -> _state.update { it.copy(clipboardLink = null) }

            is HomeIntent.DownloadFormat -> {
                val format = intent.format
                val result = _state.value.result
                viewModelScope.launch {
                    val title = result.site.title ?: format.quality ?: "Aurora Download"
                    val ext = format.ext.ifBlank { "bin" }
                    val fileName = buildFileName(title, ext)
                    val request = DownloadRequest(
                        id = DownloadManager.newId(),
                        url = format.url,
                        title = title,
                        fileName = fileName,
                        destinationDir = downloadManager.destinationDirFor(format.kind),
                        kind = format.kind,
                        totalBytes = format.sizeBytes,
                        mimeType = null,
                        quality = format.quality,
                        codec = format.videoCodec ?: format.audioCodec,
                        width = format.width,
                        height = format.height,
                        fps = format.fps,
                        thumbnailUrl = result.site.thumbnailUrl
                    )
                    val id = downloadManager.enqueue(request)
                    _state.update {
                        it.copy(
                            queuedMessage = if (id != null) "تمت الإضافة إلى قائمة التحميل" else "هذا الملف موجود مسبقًا"
                        )
                    }
                    if (id != null) {
                        DownloadForegroundService.start(getApplication())
                    }
                }
            }
        }
    }

    private fun scheduleAnalysis(value: String) {
        debounceJob?.cancel()
        if (value.isBlank()) return
        debounceJob = viewModelScope.launch {
            delay(150) // debounce as required by the spec
            startAnalysis(value)
        }
    }

    private fun startAnalysis(url: String) {
        if (url.isBlank()) return
        analysisJob?.cancel()
        _state.update {
            it.copy(
                isAnalyzing = true,
                completedStages = emptySet(),
                result = AnalysisResult(),
                error = null
            )
        }
        analysisJob = viewModelScope.launch {
            analyzerEngine.analyze(url).collectLatest { snapshot ->
                _state.update { current ->
                    val merged = current.result.mergedWith(snapshot)
                    current.copy(
                        result = merged,
                        completedStages = current.completedStages + snapshot.stage,
                        isAnalyzing = current.completedStages.size < AnalysisStage.ordered.size - 1,
                        error = snapshot.error
                    )
                }
            }
            _state.update { it.copy(isAnalyzing = false) }
        }
    }

    private fun buildFileName(title: String, extension: String): String {
        val safe = com.aurora.get.core.common.FileNames.sanitize(title)
        return "$safe.$extension"
    }

