package com.aurora.get.feature.home

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.aurora.get.core.designsystem.components.AuroraIcon
import com.aurora.get.core.designsystem.components.AuroraIconButton
import com.aurora.get.core.designsystem.components.AuroraText
import com.aurora.get.core.designsystem.components.GlassBottomSheet
import com.aurora.get.core.designsystem.components.GlassPill
import com.aurora.get.core.designsystem.components.GlassSurface
import com.aurora.get.core.designsystem.icons.AuroraIcons
import com.aurora.get.core.designsystem.shaders.AuroraMeshBackground
import com.aurora.get.core.designsystem.theme.AuroraTheme
import com.aurora.get.feature.analyzer.AnalysisStage
import com.aurora.get.engine.extractors.MediaFormat

/**
 * The Home screen: a giant glowing glass paste field, the analysis card and the four
 * smart buttons.
 */
@Composable
fun HomeScreen(
    state: HomeUiState,
    onIntent: (HomeIntent) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenBrowser: () -> Unit,
    onConvert: (MediaFormat) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    val context = LocalContext.current
    var showClipboardChip by remember(state.clipboardLink) { mutableStateOf(state.clipboardLink != null) }

    LaunchedEffect(state.queuedMessage) {
        if (state.queuedMessage != null) {
            kotlinx.coroutines.delay(2600)
            onIntent(HomeIntent.DismissClipboardChip)
        }
    }

    Box(modifier.fillMaxSize()) {
        AuroraMeshBackground(Modifier.matchParentSize())

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
        ) {
            Spacer(Modifier.height(52.dp))

            // ---------- header ----------
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    AuroraText(
                        text = "𝒥𝒪 DON",
                        style = typography.headline,
                        color = colors.onBackground
                    )
                    AuroraText(
                        text = "حمّل من آلاف المواقع بسرعة البرق",
                        style = typography.caption,
                        color = colors.onBackgroundMuted
                    )
                }
                AuroraIconButton(onClick = onOpenBrowser) {
                    AuroraIcon(AuroraIcons.Browser, "المتصفح الداخلي", Modifier.size(20.dp), colors.onBackground)
                }
                AuroraIconButton(onClick = onOpenSettings) {
                    AuroraIcon(AuroraIcons.Settings, "الإعدادات", Modifier.size(20.dp), colors.onBackground)
                }
            }

            Spacer(Modifier.height(22.dp))

            // ---------- paste field ----------
            PasteField(state = state, onIntent = onIntent)

            // ---------- detected link chip ----------
            if (showClipboardChip && state.clipboardLink != null) {
                Spacer(Modifier.height(10.dp))
                GlassPill(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AuroraIcon(AuroraIcons.Link, null, Modifier.size(16.dp), colors.primary)
                        AuroraText(
                            text = "رابط مكتشف",
                            style = typography.caption,
                            color = colors.onBackground
                        )
                        AuroraText(
                            text = state.clipboardLink.take(38),
                            style = typography.caption,
                            color = colors.onBackgroundMuted,
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )
                        AuroraIconButton(
                            onClick = {
                                onIntent(HomeIntent.InputChanged(state.clipboardLink!!))
                                showClipboardChip = false
                            },
                            size = 30.dp
                        ) {
                            AuroraIcon(AuroraIcons.Check, null, Modifier.size(14.dp), colors.onBackground)
                        }
                        AuroraIconButton(
                            onClick = {
                                showClipboardChip = false
                                onIntent(HomeIntent.DismissClipboardChip)
                            },
                            size = 30.dp
                        ) {
                            AuroraIcon(AuroraIcons.Close, null, Modifier.size(14.dp), colors.onBackgroundMuted)
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))

            // ---------- analysis ----------
            if (state.result.site.url.isNotBlank() || state.isAnalyzing) {
                AnalysisInfoCard(state = state)
                Spacer(Modifier.height(14.dp))
                SmartButtonsRow(state = state, onIntent = onIntent)
            }

            Spacer(Modifier.height(18.dp))
            RecentDownloads(state.recentDownloads)

            Spacer(Modifier.height(140.dp))
        }
    }

    // ---------- the glass sheet with the formats ----------
    val sheetKind = state.openSheet
    GlassBottomSheet(
        visible = sheetKind != null,
        onDismiss = { onIntent(HomeIntent.DismissSheet) },
        title = sheetKind?.title
    ) {
        if (sheetKind != null) {
            val formats = when (sheetKind) {
                ContentKind.AUDIO -> state.result.audioFormats
                ContentKind.VIDEO -> state.result.videoFormats
                ContentKind.IMAGE -> state.result.imageFormats
                ContentKind.FILE -> state.result.fileFormats
            }
            FormatList(
                formats = formats,
                onDownload = { onIntent(HomeIntent.DownloadFormat(it)) },
                onConvert = { format ->
                    onIntent(HomeIntent.DismissSheet)
                    onConvert(format)
                }
            )
        }
    }
}

/**
 * The giant glowing glass field. While the analysis runs a rotating Gemini style
 * glow sweeps around it; it calms down as soon as the result is ready.
 */
@Composable
private fun PasteField(
    state: HomeUiState,
    onIntent: (HomeIntent) -> Unit
) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    val keyboard = LocalSoftwareKeyboardController.current
    val glow by animateFloatAsState(
        targetValue = if (state.isAnalyzing) 1f else 0f,
        animationSpec = tween(520),
        label = "pasteGlow"
    )

    Box {
        if (glow > 0.01f) {
            Box(
                Modifier
                    .matchParentSize()
                    .clip(AuroraTheme.shapes.extraLarge)
                    .background(
                        Brush.linearGradient(
                            colors.accentSweep.map { it.copy(alpha = 0.34f * glow) }
                        )
                    )
                    .border(1.5.dp, Brush.linearGradient(colors.accentSweep), AuroraTheme.shapes.extraLarge)
            )
        }

        GlassSurface(
            modifier = Modifier.fillMaxWidth(),
            shape = AuroraTheme.shapes.extraLarge,
            elevation = 24.dp,
            borderBrush = Brush.linearGradient(
                colors.accentSweep.map { it.copy(alpha = 0.35f + 0.45f * glow) } +
                    listOf(Color.White.copy(alpha = 0.18f))
            )
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AuroraIcon(AuroraIcons.Link, null, Modifier.size(20.dp), colors.primary)
                    BasicTextField(
                        value = state.input,
                        onValueChange = { onIntent(HomeIntent.InputChanged(it)) },
                        textStyle = typography.body.copy(color = colors.onBackground),
                        cursorBrush = SolidColor(colors.primary),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = {
                            keyboard?.hide()
                            onIntent(HomeIntent.Analyze)
                        }),
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        decorationBox = { inner ->
                            if (state.input.isEmpty()) {
                                AuroraText(
                                    text = "الصق أو شارك الرابط هنا…",
                                    style = typography.body,
                                    color = colors.onBackgroundMuted
                                )
                            }
                            inner()
                        }
                    )
                    if (state.input.isNotEmpty()) {
                        AuroraIconButton(
                            onClick = { onIntent(HomeIntent.Clear) },
                            size = 36.dp
                        ) {
                            AuroraIcon(AuroraIcons.Close, "مسح", Modifier.size(16.dp), colors.onBackgroundMuted)
                        }
                    }
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StageIndicator(state.completedStages, state.isAnalyzing)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AuroraIconButton(onClick = {
                            keyboard?.hide()
                            onIntent(HomeIntent.Analyze)
                        }, size = 40.dp) {
                            AuroraIcon(AuroraIcons.Search, "تحليل", Modifier.size(18.dp), colors.onBackground)
                        }
                    }
                }
            }
        }
    }
}

/** The little stage chips that show which analysis stage already finished. */
@Composable
private fun StageIndicator(stages: Set<AnalysisStage>, analyzing: Boolean) {
    val colors = AuroraTheme.colors
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        AnalysisStage.ordered.forEach { stage ->
            val done = stage in stages
            Box(
                Modifier
                    .size(if (done) 8.dp else 6.dp)
                    .clip(AuroraTheme.shapes.pill)
                    .background(
                        if (done) colors.primary else colors.onBackgroundMuted.copy(alpha = 0.28f)
                    )
            )
        }
        if (analyzing) {
            AuroraText(
                text = "جارٍ التحليل…",
                style = AuroraTheme.typography.caption,
                color = colors.onBackgroundMuted,
                modifier = Modifier.padding(start = 4.dp)
            )
        }
    }
}
