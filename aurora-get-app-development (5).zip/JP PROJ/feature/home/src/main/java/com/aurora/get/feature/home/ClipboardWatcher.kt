package com.aurora.get.feature.home

import android.content.ClipboardManager
import android.content.Context
import com.aurora.get.core.common.AuroraLog
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Watches the clipboard for links.
 *
 * The watcher is **quiet**: it only publishes a floating chip ("رابط مكتشف"), it never
 * blocks the user or hijacks the paste action.
 */
@Singleton
class ClipboardWatcher @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val clipboard: ClipboardManager? =
        context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager

    private val _detected = MutableSharedFlow<String?>(
        replay = 0,
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    val detectedLinks: Flow<String?> = _detected.asSharedFlow()

    /** Reads the clipboard once and publishes it when it contains a link. */
    fun poll() {
        val manager = clipboard ?: return
        val text = runCatching {
            manager.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()
        }.getOrNull() ?: return
        if (looksLikeLink(text)) {
            AuroraLog.d(TAG, "clipboard link detected")
            _detected.tryEmit(text.trim())
        }
    }

    fun clear() {
        runCatching { clipboard?.clearPrimaryClip() }
        _detected.tryEmit(null)
    }

    private fun looksLikeLink(text: String): Boolean {
        val value = text.trim()
        if (value.length < 8 || value.contains(' ')) return false
        return value.startsWith("http://") ||
            value.startsWith("https://") ||
            value.startsWith("magnet:") ||
            Regex("^[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}(/.*)?$").matches(value)
    }

    companion object {
        private const val TAG = "ClipboardWatcher"
    }
}
