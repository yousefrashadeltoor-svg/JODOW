package com.aurora.get.feature.compressor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.aurora.get.core.common.Format
import com.aurora.get.core.designsystem.components.AuroraIcon
import com.aurora.get.core.designsystem.components.AuroraIconButton
import com.aurora.get.core.designsystem.components.AuroraProgressBar
import com.aurora.get.core.designsystem.components.AuroraText
import com.aurora.get.core.designsystem.components.GlassPill
import com.aurora.get.core.designsystem.components.GlassSurface
import com.aurora.get.core.designsystem.icons.AuroraIcons
import com.aurora.get.core.designsystem.shaders.AuroraMeshBackground
import com.aurora.get.core.designsystem.theme.AuroraTheme
import java.io.File

/**
 * The smart compressor with the two modes and the before / after comparison.
 */
@Composable
fun CompressorScreen(
    state: CompressorUiState,
    onSelect: (com.aurora.get.core.database.DownloadEntity) -> Unit,
    onMode: (CompressionMode) -> Unit,
    onRun: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors

    Box(modifier.fillMaxSize()) {
        AuroraMeshBackground(Modifier.matchParentSize(), intensity = 0.6f)
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(52.dp))
            AuroraText("تصغير الحجم", style = AuroraTheme.typography.headline, color = colors.onBackground)
            AuroraText(
                "ضغط ذكي مع الحفاظ على الجودة",
                style = AuroraTheme.typography.caption,
                color = colors.onBackgroundMuted
            )

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CompressionMode.entries.forEach { mode ->
                    ModePill(
                        mode = mode,
                        selected = state.mode == mode,
                        onClick = { onMode(mode) }
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            AuroraText(
                state.mode.description,
                style = AuroraTheme.typography.caption,
                color = colors.onBackgroundMuted
            )

            Spacer(Modifier.height(14.dp))
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(state.files) { file ->
                    val selected = file.id == state.selected?.id
                    GlassSurface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(file) },
                        shape = AuroraTheme.shapes.medium,
                        elevation = 6.dp,
                        tint = if (selected) colors.primary.copy(alpha = 0.18f) else colors.glassTint
                    ) {
                        Row(
                            Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AuroraIcon(AuroraIcons.File, null, Modifier.size(18.dp), colors.primary)
                            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                AuroraText(
                                    file.fileName,
                                    style = AuroraTheme.typography.label,
                                    color = colors.onBackground,
                                    maxLines = 1
                                )
                                AuroraText(
                                    Format.bytes(file.totalBytes ?: 0),
                                    style = AuroraTheme.typography.caption,
                                    color = colors.onBackgroundMuted
                                )
                            }
                        }
                    }
                }
            }

            if (state.running) {
                Spacer(Modifier.height(10.dp))
                AuroraProgressBar(0f, Modifier.fillMaxWidth(), indeterminate = true)
            }

            state.result?.let { result ->
                Spacer(Modifier.height(12.dp))
                ComparisonCard(result)
            }

            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                AuroraText(
                    "لن يتم استبدال الأصل — يُنشأ ملف جديد",
                    style = AuroraTheme.typography.caption,
                    color = colors.onBackgroundMuted,
                    modifier = Modifier.weight(1f)
                )
                AuroraIconButton(onClick = onRun, size = 46.dp) {
                    AuroraIcon(AuroraIcons.Compressor, "ابدأ الضغط", Modifier.size(20.dp), colors.onBackground)
                }
            }
            Spacer(Modifier.height(120.dp))
        }
    }
}

@Composable
private fun ModePill(mode: CompressionMode, selected: Boolean, onClick: () -> Unit) {
    val colors = AuroraTheme.colors
    GlassPill {
        Box(
            Modifier
                .background(if (selected) Brush.linearGradient(colors.accentSweep) else Color.Transparent)
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            AuroraText(
                mode.title,
                style = AuroraTheme.typography.label,
                color = if (selected) Color.White else colors.onBackgroundMuted
            )
        }
    }
}

@Composable
private fun ComparisonCard(result: CompressionResult) {
    val colors = AuroraTheme.colors
    GlassSurface(
        modifier = Modifier.fillMaxWidth(),
        shape = AuroraTheme.shapes.large,
        elevation = 14.dp
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AuroraText(
                    result.sourceName,
                    style = AuroraTheme.typography.label,
                    color = colors.onBackground,
                    modifier = Modifier.weight(1f),
                    maxLines = 1
                )
                if (result.improved) {
                    GlassPill {
                        Row(
                            Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AuroraIcon(AuroraIcons.Sparkle, null, Modifier.size(12.dp), colors.success)
                            AuroraText(
                                "وفّر ${Format.bytes(result.savedBytes)} (${result.savedPercent}%)",
                                style = AuroraTheme.typography.caption,
                                color = colors.success
                            )
                        }
                    }
                }
            }

            // Before / after preview for images.
            result.outputPath?.let { path ->
                val isImage = path.substringAfterLast('.', "").lowercase() in setOf("jpg", "jpeg", "png", "webp")
                if (isImage) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PreviewTile("قبل", result.sourceName, Modifier.weight(1f))
                        PreviewTile("بعد", path, Modifier.weight(1f))
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f)) {
                    AuroraText("قبل", style = AuroraTheme.typography.caption, color = colors.onBackgroundMuted)
                    AuroraText(
                        Format.exactBytes(result.beforeBytes),
                        style = AuroraTheme.typography.bodySmall,
                        color = colors.onBackground
                    )
                }
                Column(Modifier.weight(1f)) {
                    AuroraText("بعد", style = AuroraTheme.typography.caption, color = colors.onBackgroundMuted)
                    AuroraText(
                        Format.exactBytes(result.afterBytes),
                        style = AuroraTheme.typography.bodySmall,
                        color = colors.onBackground
                    )
                }
            }

            if (!result.improved && result.error == null) {
                AuroraText(
                    "الملف الناتج ليس أصغر — لن نعرضه كتحسين.",
                    style = AuroraTheme.typography.caption,
                    color = colors.warning
                )
            }
            result.error?.let {
                AuroraText(it, style = AuroraTheme.typography.caption, color = colors.error)
            }
        }
    }
}

@Composable
private fun PreviewTile(label: String, path: String, modifier: Modifier = Modifier) {
    val colors = AuroraTheme.colors
    Column(modifier) {
        AuroraText(label, style = AuroraTheme.typography.caption, color = colors.onBackgroundMuted)
        AsyncImage(
            model = File(path),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .clip(AuroraTheme.shapes.medium)
        )
    }
}
