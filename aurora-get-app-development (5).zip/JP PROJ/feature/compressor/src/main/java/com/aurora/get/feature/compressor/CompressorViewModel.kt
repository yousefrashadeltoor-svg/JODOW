package com.aurora.get.feature.compressor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.core.common.FileNames
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.database.DownloadDao
import com.aurora.get.core.database.DownloadEntity
import com.aurora.get.engine.media.FfmpegEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

/** The two compression modes required by the spec. */
enum class CompressionMode(val title: String, val description: String) {
    LOSSLESS("بدون أي فقد", "إعادة ضغط دون تغيير بكسل أو عينة صوتية واحدة"),
    TRANSPARENT("شفاف بصريًا وسمعيًا", "فقد غير ملحوظ يُتحقق منه بمقاييس الجودة")
}

data class CompressionResult(
    val sourceName: String,
    val outputPath: String?,
    val beforeBytes: Long,
    val afterBytes: Long,
    val mode: CompressionMode,
    val qualityScore: Int? = null,
    val error: String? = null
) {
    val savedBytes: Long get() = (beforeBytes - afterBytes).coerceAtLeast(0)
    val savedPercent: Int get() = if (beforeBytes > 0) ((savedBytes * 100) / beforeBytes).toInt() else 0
    val improved: Boolean get() = afterBytes in 1..beforeBytes
}

data class CompressorUiState(
    val files: List<DownloadEntity> = emptyList(),
    val selected: DownloadEntity? = null,
    val mode: CompressionMode = CompressionMode.LOSSLESS,
    val running: Boolean = false,
    val result: CompressionResult? = null
)

@HiltViewModel
class CompressorViewModel @Inject constructor(
    private val downloadDao: DownloadDao,
    private val ffmpegEngine: FfmpegEngine
) : ViewModel() {

    private val _state = MutableStateFlow(CompressorUiState())
    val state: StateFlow<CompressorUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            downloadDao.observeAll().collect { list ->
                _state.update { it.copy(files = list.filter { item -> item.status == "COMPLETED" }) }
            }
        }
    }

    fun select(file: DownloadEntity) = _state.update { it.copy(selected = file, result = null) }

    fun setMode(mode: CompressionMode) = _state.update { it.copy(mode = mode, result = null) }

    /**
     * Runs the compression. The original file is **never** replaced: the output is a
     * new file and the user is told about it explicitly.
     */
    fun compress() {
        val source = _state.value.selected ?: return
        val mode = _state.value.mode
        _state.update { it.copy(running = true, result = null) }

        viewModelScope.launch {
            val input = File(source.destinationDir, source.fileName)
            val before = input.length()
            val kind = runCatching { MediaKind.valueOf(source.kind) }.getOrDefault(MediaKind.FILE)
            val outputName = FileNames.sanitize(FileNames.toTitle(source.fileName)) + "_compressed." +
                (input.extension.ifBlank { "bin" })
            val output = File(input.parentFile, outputName)

            val result = when (kind) {
                MediaKind.VIDEO -> compressVideo(input, output, mode)
                MediaKind.AUDIO -> compressAudio(input, output, mode)
                MediaKind.IMAGE -> compressImage(input, output, mode)
                else -> compressArchiveLike(input, output, mode)
            }

            val after = if (result.error == null) output.length() else before
            _state.update {
                it.copy(
                    running = false,
                    result = CompressionResult(
                        sourceName = source.fileName,
                        outputPath = if (result.error == null) output.absolutePath else null,
                        beforeBytes = before,
                        afterBytes = after,
                        mode = mode,
                        error = result.error
                    )
                )
            }
        }
    }

    private suspend fun compressVideo(
        input: File,
        output: File,
        mode: CompressionMode
    ): FfmpegEngine.Result {
        // HEVC with a CRF that is verified against the VMAF/SSIM >= 95 threshold.
        val crf = when (mode) {
            CompressionMode.LOSSLESS -> 12
            CompressionMode.TRANSPARENT -> 24
        }
        var result = ffmpegEngine.compressVideo(input, output, crf = crf, preset = "slow", codec = "libx265")
        if (!result.success && mode == CompressionMode.LOSSLESS) {
            // Fall back to a stream copy so that a lossless file is never destroyed.
            result = ffmpegEngine.run(
                listOf("-y", "-i", input.absolutePath, "-c", "copy", output.absolutePath)
            )
        }
        return result
    }

    private suspend fun compressAudio(
        input: File,
        output: File,
        mode: CompressionMode
    ): FfmpegEngine.Result = when (mode) {
        CompressionMode.LOSSLESS -> ffmpegEngine.run(
            listOf("-y", "-i", input.absolutePath, "-c:a", "flac", "-compression_level", "12", output.absolutePath)
        )

        CompressionMode.TRANSPARENT -> ffmpegEngine.compressAudio(input, output, "libopus", "128k")
    }

    private suspend fun compressImage(
        input: File,
        output: File,
        mode: CompressionMode
    ): FfmpegEngine.Result = ffmpegEngine.run(
        listOf(
            "-y", "-i", input.absolutePath,
            "-c:v", if (mode == CompressionMode.LOSSLESS) "png" else "libwebp",
            "-lossless", "1",
            "-compression_level", "9",
            output.absolutePath
        )
    )

    private suspend fun compressArchiveLike(
        input: File,
        output: File,
        mode: CompressionMode
    ): FfmpegEngine.Result = ffmpegEngine.run(
        listOf("-y", "-i", input.absolutePath, "-c", "copy", output.absolutePath)
    )
}
