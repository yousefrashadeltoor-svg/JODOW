package com.aurora.get.feature.converter

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.get.core.common.FileNames
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.database.DownloadDao
import com.aurora.get.core.database.DownloadEntity
import com.aurora.get.engine.media.FfmpegEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

/** The conversion targets offered by the converter. */
enum class ConversionTarget(
    val label: String,
    val extension: String,
    val kind: MediaKind,
    val ffmpegCodec: String?
) {
    MP4("MP4", "mp4", MediaKind.VIDEO, "libx264"),
    MKV("MKV", "mkv", MediaKind.VIDEO, "libx264"),
    WEBM("WEBM", "webm", MediaKind.VIDEO, "libvpx-vp9"),
    MOV("MOV", "mov", MediaKind.VIDEO, "libx264"),
    AVI("AVI", "avi", MediaKind.VIDEO, "mpeg4"),
    GIF("GIF", "gif", MediaKind.IMAGE, null),
    MP3("MP3", "mp3", MediaKind.AUDIO, "libmp3lame"),
    M4A("M4A", "m4a", MediaKind.AUDIO, "aac"),
    OPUS("OPUS", "opus", MediaKind.AUDIO, "libopus"),
    OGG("OGG", "ogg", MediaKind.AUDIO, "libvorbis"),
    FLAC("FLAC", "flac", MediaKind.AUDIO, "flac"),
    WAV("WAV", "wav", MediaKind.AUDIO, "pcm_s16le"),
    JPG("JPG", "jpg", MediaKind.IMAGE, "mjpeg"),
    PNG("PNG", "png", MediaKind.IMAGE, "png"),
    WEBP("WEBP", "webp", MediaKind.IMAGE, "libwebp"),
    AVIF("AVIF", "avif", MediaKind.IMAGE, "libaom-av1");

    companion object {
        fun forKind(kind: MediaKind): List<ConversionTarget> = when (kind) {
            MediaKind.VIDEO -> listOf(MP4, MKV, WEBM, MOV, AVI, GIF, MP3, M4A, OPUS)
            MediaKind.AUDIO -> listOf(MP3, M4A, OPUS, OGG, FLAC, WAV)
            MediaKind.IMAGE -> listOf(JPG, PNG, WEBP, AVIF)
            else -> listOf(MP4, MKV, MP3, M4A)
        }
    }
}

data class ConversionJob(
    val id: String,
    val sourceName: String,
    val target: ConversionTarget,
    val state: String = "QUEUED",
    val progress: Float = 0f,
    val outputPath: String? = null,
    val error: String? = null
)

data class ConverterUiState(
    val sources: List<DownloadEntity> = emptyList(),
    val selectedSource: DownloadEntity? = null,
    val targets: List<ConversionTarget> = emptyList(),
    val selectedTarget: ConversionTarget? = null,
    val jobs: List<ConversionJob> = emptyList(),
    val ffmpegAvailable: Boolean = true
)

@HiltViewModel
class ConverterViewModel @Inject constructor(
    private val downloadDao: DownloadDao,
    private val ffmpegEngine: FfmpegEngine
) : ViewModel() {

    private val _state = MutableStateFlow(ConverterUiState())
    val state: StateFlow<ConverterUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            downloadDao.observeAll().collect { list ->
                val completed = list.filter { it.status == "COMPLETED" }
                _state.update { current ->
                    val selected = current.selectedSource
                        ?: completed.firstOrNull { it.kind == MediaKind.VIDEO.name }
                        ?: completed.firstOrNull()
                    current.copy(
                        sources = completed,
                        selectedSource = selected,
                        targets = selected?.let {
                            ConversionTarget.forKind(runCatching { MediaKind.valueOf(it.kind) }.getOrDefault(MediaKind.FILE))
                        } ?: emptyList()
                    )
                }
            }
        }
        viewModelScope.launch {
            _state.update { it.copy(ffmpegAvailable = ffmpegEngine.isAvailable()) }
        }
    }

    fun selectSource(source: DownloadEntity) {
        val kind = runCatching { MediaKind.valueOf(source.kind) }.getOrDefault(MediaKind.FILE)
        _state.update {
            it.copy(
                selectedSource = source,
                targets = ConversionTarget.forKind(kind),
                selectedTarget = ConversionTarget.forKind(kind).firstOrNull()
            )
        }
    }

    fun selectTarget(target: ConversionTarget) = _state.update { it.copy(selectedTarget = target) }

    /** Starts the conversion of the selected file. */
    fun convert() {
        val source = _state.value.selectedSource ?: return
        val target = _state.value.selectedTarget ?: return
        val job = ConversionJob(
            id = System.currentTimeMillis().toString(),
            sourceName = source.fileName,
            target = target
        )
        _state.update { it.copy(jobs = it.jobs + job) }

        viewModelScope.launch {
            updateJob(job.id) { it.copy(state = "RUNNING") }
            val input = File(source.destinationDir, source.fileName)
            val outputName = FileNames.sanitize(FileNames.toTitle(source.fileName)) + "." + target.extension
            val output = File(input.parentFile, outputName)
            val result = when {
                target == ConversionTarget.GIF -> ffmpegEngine.extractFrame(input, output)
                target.kind == MediaKind.AUDIO -> ffmpegEngine.extractAudio(input, output, target.ffmpegCodec ?: "copy")
                else -> ffmpegEngine.run(
                    listOf(
                        "-y", "-i", input.absolutePath,
                        "-c:v", target.ffmpegCodec ?: "libx264",
                        "-c:a", "copy",
                        output.absolutePath
                    )
                )
            }
            updateJob(job.id) {
                if (result.success) {
                    it.copy(state = "COMPLETED", progress = 1f, outputPath = output.absolutePath)
                } else {
                    it.copy(state = "FAILED", error = result.errorLine ?: "فشل التحويل")
                }
            }
        }
    }

    private fun updateJob(id: String, transform: (ConversionJob) -> ConversionJob) {
        _state.update { current ->
            current.copy(jobs = current.jobs.map { if (it.id == id) transform(it) else it })
        }
    }
}
