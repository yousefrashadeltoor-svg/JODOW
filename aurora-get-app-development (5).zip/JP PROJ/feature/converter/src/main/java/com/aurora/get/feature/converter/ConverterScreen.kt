package com.aurora.get.feature.converter

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.aurora.get.core.common.Format
import com.aurora.get.core.designsystem.components.AuroraIcon
import com.aurora.get.core.designsystem.components.AuroraIconButton
import com.aurora.get.core.designsystem.components.AuroraProgressBar
import com.aurora.get.core.designsystem.components.AuroraText
import com.aurora.get.core.designsystem.components.GlassPill
import com.aurora.get.core.designsystem.components.GlassSurface
import com.aurora.get.core.designsystem.icons.AuroraIcons
import com.aurora.get.core.designsystem.shaders.AuroraMeshBackground
import com.aurora.get.core.designsystem.theme.AuroraTheme
import java.io.File

/**
 * The converter: pick a downloaded file, pick a target format, run the batch.
 */
@Composable
fun ConverterScreen(
    state: ConverterUiState,
    onSelectSource: (com.aurora.get.core.database.DownloadEntity) -> Unit,
    onSelectTarget: (ConversionTarget) -> Unit,
    onConvert: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors

    Box(modifier.fillMaxSize()) {
        AuroraMeshBackground(Modifier.matchParentSize(), intensity = 0.6f)
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(52.dp))
            AuroraText("المحوّل", style = AuroraTheme.typography.headline, color = colors.onBackground)
            AuroraText(
                "استخرج عدة صيغ وجودات في عملية واحدة",
                style = AuroraTheme.typography.caption,
                color = colors.onBackgroundMuted
            )

            if (!state.ffmpegAvailable) {
                Spacer(Modifier.height(10.dp))
                GlassPill {
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AuroraIcon(AuroraIcons.Warning, null, Modifier.size(13.dp), colors.warning)
                        AuroraText(
                            "محرّك FFmpeg غير متوفر في هذه النسخة",
                            style = AuroraTheme.typography.caption,
                            color = colors.onBackgroundMuted
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            AuroraText("الملف المصدر", style = AuroraTheme.typography.label, color = colors.onBackgroundMuted)
            Spacer(Modifier.height(8.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(state.sources) { source ->
                    val selected = source.id == state.selectedSource?.id
                    GlassSurface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectSource(source) },
                        shape = AuroraTheme.shapes.medium,
                        elevation = 6.dp,
                        tint = if (selected) colors.primary.copy(alpha = 0.18f) else colors.glassTint
                    ) {
                        Row(
                            Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AuroraIcon(AuroraIcons.File, null, Modifier.size(18.dp), colors.primary)
                            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                AuroraText(
                                    source.fileName,
                                    style = AuroraTheme.typography.label,
                                    color = colors.onBackground,
                                    maxLines = 1
                                )
                                AuroraText(
                                    Format.bytes(source.totalBytes ?: 0),
                                    style = AuroraTheme.typography.caption,
                                    color = colors.onBackgroundMuted
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            AuroraText("الصيغة الهدف", style = AuroraTheme.typography.label, color = colors.onBackgroundMuted)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                state.targets.take(5).forEach { target ->
                    TargetPill(
                        label = target.label,
                        selected = target == state.selectedTarget,
                        onClick = { onSelectTarget(target) }
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                AuroraText(
                    "دفعة التحويل",
                    style = AuroraTheme.typography.label,
                    color = colors.onBackgroundMuted,
                    modifier = Modifier.weight(1f)
                )
                AuroraIconButton(onClick = onConvert, size = 46.dp) {
                    AuroraIcon(AuroraIcons.Converter, "ابدأ", Modifier.size(20.dp), colors.onBackground)
                }
            }

            state.jobs.forEach { job ->
                Spacer(Modifier.height(8.dp))
                GlassSurface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = AuroraTheme.shapes.medium,
                    elevation = 6.dp
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AuroraText(
                                "${job.sourceName} → ${job.target.label}",
                                style = AuroraTheme.typography.label,
                                color = colors.onBackground,
                                modifier = Modifier.weight(1f),
                                maxLines = 1
                            )
                            AuroraText(
                                job.state,
                                style = AuroraTheme.typography.caption,
                                color = if (job.state == "COMPLETED") colors.success else colors.onBackgroundMuted
                            )
                        }
                        if (job.state == "RUNNING") {
                            Spacer(Modifier.height(8.dp))
                            AuroraProgressBar(job.progress, Modifier.fillMaxWidth(), indeterminate = true)
                        }
                        job.error?.let {
                            Spacer(Modifier.height(4.dp))
                            AuroraText(it, style = AuroraTheme.typography.caption, color = colors.error)
                        }
                    }
                }
            }
            Spacer(Modifier.height(120.dp))
        }
    }
}

@Composable
private fun TargetPill(label: String, selected: Boolean, onClick: () -> Unit) {
    val colors = AuroraTheme.colors
    GlassPill {
        Box(
            Modifier
                .background(if (selected) Brush.linearGradient(colors.accentSweep) else Color.Transparent)
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            AuroraText(
                label,
                style = AuroraTheme.typography.label,
                color = if (selected) Color.White else colors.onBackgroundMuted
            )
        }
    }
}
