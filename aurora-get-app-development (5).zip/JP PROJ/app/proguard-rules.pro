# ---------------------------------------------------------------------------
# Aurora Get - ProGuard / R8 rules
# NOTE: No Material Components are on the classpath by design.
# ---------------------------------------------------------------------------

# Keep Compose runtime metadata
-keepclassmembers class androidx.compose.runtime.** { *; }

# --- Kotlinx Serialization -------------------------------------------------
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.aurora.get.**$$serializer { *; }
-keepclassmembers class com.aurora.get.** { *** Companion; }
-keepclasseswithmembers class com.aurora.get.** { kotlinx.serialization.KSerializer serializer(...); }

# --- Room -------------------------------------------------------------------
-keep class * extends androidx.room.RoomDatabase { <init>(); }
-dontwarn androidx.room.paging.**

# --- Hilt / Dagger ----------------------------------------------------------
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager$FragmentContextWrapper
-keepclasseswithmembers class * { @dagger.hilt.android.AndroidEntryPoint *; }

# --- yt-dlp / FFmpeg / aria2c (JNI + native extractors) ---------------------
-keep class com.github.youtubedl.** { *; }
-keep class org.youtubedl.** { *; }
-dontwarn com.github.youtubedl.**
-dontwarn org.youtubedl.**
-keep class com.arthenica.** { *; }
-dontwarn com.arthenica.**
-keep class io.github.junkfood02.** { *; }
-dontwarn io.github.junkfood02.**
# Native extractors bundled with yt-dlp are resolved reflectively.
-keep class com.github.youtubedl.extractor.** { *; }
-dontwarn com.github.youtubedl.extractor.**

# --- NewPipe Extractor (YouTube browsing, no API key) -----------------------
-keep class org.schabi.newpipe.** { *; }
-dontwarn org.schabi.newpipe.**
-keep class org.mozilla.javascript.** { *; }
-keep class org.mozilla.classfile.ClassFileWriter
-dontwarn org.mozilla.javascript.tools.**
-dontwarn org.brotli.**

# --- OkHttp / Cronet --------------------------------------------------------
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.chromium.net.**
-keep class org.chromium.net.** { *; }

# --- Media3 -----------------------------------------------------------------
-dontwarn androidx.media3.**

# --- Lottie ----------------------------------------------------------------
-keep class com.airbnb.lottie.** { *; }
-dontwarn com.airbnb.lottie.**

# --- adblock-rust JNI ------------------------------------------------------
-keep class com.aurora.get.core.network.adblock.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
-keep class * implements com.aurora.get.core.network.adblock.NativeAdBlock { *; }

# --- WorkManager ------------------------------------------------------------
-keep class * extends androidx.work.Worker
-keep class * extends androidx.work.ListenableWorker { <init>(...); }

# --- Tink (security-crypto) ------------------------------------------------
-keep class com.google.crypto.tink.** { *; }
-dontwarn com.google.crypto.tink.**

# --- Coroutines -------------------------------------------------------------
-dontwarn kotlinx.coroutines.**
