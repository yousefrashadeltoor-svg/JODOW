package com.aurora.get

import android.app.Application
import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.network.adblock.AdBlockRepository
import com.github.youtubedl.YoutubeDL
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Aurora Get — offline first, no analytics, no tracking.
 */
@HiltAndroidApp
class AuroraApplication : Application() {

    @Inject lateinit var adBlockRepository: AdBlockRepository

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        } else {
            Timber.plant(Timber.ReleaseTree())
        }
        // The yt-dlp binary must be initialised before the first extraction.
        runCatching { YoutubeDL.getInstance().init(this) }
            .onFailure { AuroraLog.w(TAG, "yt-dlp init deferred: ${it.message}") }

        AuroraShortcuts.install(this)

        scope.launch {
            runCatching { adBlockRepository.ensureLoaded() }
                .onFailure { AuroraLog.w(TAG, "adblock lists unavailable: ${it.message}") }
        }
    }

    companion object {
        private const val TAG = "AuroraApplication"
    }
}
