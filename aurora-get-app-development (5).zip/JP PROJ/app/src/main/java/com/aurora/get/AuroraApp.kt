package com.aurora.get

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aurora.get.core.designsystem.components.AuroraDock
import com.aurora.get.core.designsystem.components.AuroraDockItem
import com.aurora.get.core.designsystem.components.AuroraIcon
import com.aurora.get.core.designsystem.icons.AuroraIcons
import com.aurora.get.core.designsystem.theme.AuroraTheme
import com.aurora.get.core.designsystem.theme.AuroraThemeId
import com.aurora.get.feature.browser.BrowserScreen
import com.aurora.get.feature.browser.BrowserViewModel
import com.aurora.get.feature.compressor.CompressorScreen
import com.aurora.get.feature.compressor.CompressorViewModel
import com.aurora.get.feature.converter.ConverterScreen
import com.aurora.get.feature.converter.ConverterViewModel
import com.aurora.get.feature.downloads.DownloadsScreen
import com.aurora.get.feature.downloads.DownloadsViewModel
import com.aurora.get.feature.files.FilesScreen
import com.aurora.get.feature.files.FilesViewModel
import com.aurora.get.feature.home.HomeIntent
import com.aurora.get.feature.home.HomeScreen
import com.aurora.get.feature.home.HomeViewModel
import com.aurora.get.onboarding.OnboardingScreen
import com.aurora.get.feature.settings.SettingsScreen
import com.aurora.get.feature.settings.SettingsViewModel
import com.aurora.get.feature.jodon.JodonScreen
import com.aurora.get.feature.jodon.JodonViewModel
import com.aurora.get.feature.player.PlayerScreen
import androidx.hilt.navigation.compose.hiltViewModel

/**
 * The application shell: the floating glass dock + the navigation graph.
 */
@Composable
fun AuroraApp(
    themeId: AuroraThemeId,
    darkMode: Boolean,
    onThemeChanged: (AuroraThemeId) -> Unit,
    onDarkModeChanged: (Boolean) -> Unit,
    sharedText: String? = null
) {
    val navController = rememberNavController()
    var onboardingDone by remember { mutableStateOf(true) }
    var currentRoute by remember { mutableStateOf(Routes.HOME) }

    val colors = AuroraTheme.colors

    val dockItems = remember(colors) {
        listOf(
            AuroraDockItem("𝒥𝒪 DON") { AuroraIcon(AuroraIcons.Video, null, Modifier, AuroraTheme.colors.onBackground) },
            AuroraDockItem("الرئيسية") { AuroraIcon(AuroraIcons.Home, null, Modifier, AuroraTheme.colors.onBackground) },
            AuroraDockItem("التحميلات") { AuroraIcon(AuroraIcons.Downloads, null, Modifier, AuroraTheme.colors.onBackground) },
            AuroraDockItem("المتصفح") { AuroraIcon(AuroraIcons.Browser, null, Modifier, AuroraTheme.colors.onBackground) },
            AuroraDockItem("الأدوات") { AuroraIcon(AuroraIcons.Converter, null, Modifier, AuroraTheme.colors.onBackground) },
            AuroraDockItem("المكتبة") { AuroraIcon(AuroraIcons.Library, null, Modifier, AuroraTheme.colors.onBackground) },
            AuroraDockItem("الإعدادات") { AuroraIcon(AuroraIcons.Settings, null, Modifier, AuroraTheme.colors.onBackground) }
        )
    }

    Box(Modifier.fillMaxSize()) {
        NavHost(
            navController = navController,
            startDestination = if (onboardingDone) Routes.HOME else Routes.ONBOARDING,
            modifier = Modifier.fillMaxSize()
        ) {
            composable(Routes.ONBOARDING) {
                OnboardingScreen(
                    onDone = {
                        onboardingDone = true
                        navController.navigate(Routes.HOME) {
                            popUpTo(Routes.ONBOARDING) { inclusive = true }
                        }
                    }
                )
            }

            composable(Routes.HOME) {
                val viewModel: HomeViewModel = hiltViewModel()
                val state by viewModel.state.collectAsStateWithLifecycle()
                LaunchedEffect(sharedText) {
                    if (!sharedText.isNullOrBlank()) {
                        viewModel.onIntent(HomeIntent.InputChanged(sharedText))
                        viewModel.onIntent(HomeIntent.Analyze)
                    }
                }
                HomeScreen(
                    state = state,
                    onIntent = viewModel::onIntent,
                    onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                    onOpenBrowser = { navController.navigate(Routes.BROWSER) },
                    onConvert = { navController.navigate(Routes.CONVERTER) }
                )
            }

            composable(Routes.JODON) {
                val viewModel: JodonViewModel = hiltViewModel()
                val state by viewModel.state.collectAsStateWithLifecycle()
                JodonScreen(viewModel = viewModel)
            }

            composable(Routes.PLAYER) {
                val previous = navController.previousBackStackEntry?.savedStateHandle
                val url = previous?.get<String>("player_url").orEmpty()
                val title = previous?.get<String>("player_title").orEmpty()
                PlayerScreen(mediaUrl = url, title = title, onClose = { navController.popBackStack() })
            }

            composable(Routes.DOWNLOADS) {
                val viewModel: DownloadsViewModel = hiltViewModel()
                val state by viewModel.state.collectAsStateWithLifecycle()
                DownloadsScreen(
                    state = state,
                    onTab = viewModel::selectTab,
                    onPause = viewModel::pause,
                    onResume = viewModel::resume,
                    onCancel = viewModel::cancel,
                    onRetry = viewModel::retry,
                    onDelete = { id, deleteFile -> viewModel.delete(id, deleteFile) },
                    onMove = { from, to -> viewModel.move(from, to) },
                    onOpen = { },
                    onShare = { },
                    onCompress = { navController.navigate(Routes.COMPRESSOR) }
                )
            }

            composable(Routes.BROWSER) {
                val viewModel: BrowserViewModel = hiltViewModel()
                val state by viewModel.state.collectAsStateWithLifecycle()
                BrowserScreen(
                    state = state,
                    viewModel = viewModel,
                    onDownload = { }
                )
            }

            composable(Routes.TOOLS) {
                ToolsScreen(
                    onConverter = { navController.navigate(Routes.CONVERTER) },
                    onCompressor = { navController.navigate(Routes.COMPRESSOR) }
                )
            }

            composable(Routes.CONVERTER) {
                val viewModel: ConverterViewModel = hiltViewModel()
                val state by viewModel.state.collectAsStateWithLifecycle()
                ConverterScreen(
                    state = state,
                    onSelectSource = viewModel::selectSource,
                    onSelectTarget = viewModel::selectTarget,
                    onConvert = viewModel::convert
                )
            }

            composable(Routes.COMPRESSOR) {
                val viewModel: CompressorViewModel = hiltViewModel()
                val state by viewModel.state.collectAsStateWithLifecycle()
                CompressorScreen(
                    state = state,
                    onSelect = viewModel::select,
                    onMode = viewModel::setMode,
                    onRun = viewModel::compress
                )
            }

            composable(Routes.LIBRARY) {
                val viewModel: FilesViewModel = hiltViewModel()
                val state by viewModel.state.collectAsStateWithLifecycle()
                FilesScreen(
                    state = state,
                    onLayout = viewModel::setLayout,
                    onFilter = viewModel::setFilter,
                    onPlay = viewModel::play,
                    onClosePlayer = viewModel::closePlayer,
                    onDelete = viewModel::delete
                )
            }

            composable(Routes.SETTINGS) {
                val viewModel: SettingsViewModel = hiltViewModel()
                val state by viewModel.state.collectAsStateWithLifecycle()
                SettingsScreen(
                    state = state,
                    onTheme = onThemeChanged,
                    onDarkMode = onDarkModeChanged,
                    onConnections = viewModel::setConnections,
                    onHttp3 = viewModel::setHttp3,
                    onDns = viewModel::setDnsOverHttps,
                    onWifiOnly = viewModel::setWifiOnly,
                    onChargingOnly = viewModel::setChargingOnly,
                    onAutoOrganize = viewModel::setAutoOrganize,
                    onAdBlock = viewModel::setAdBlock,
                    onScheduled = viewModel::setScheduled,
                    onBatteryGuard = viewModel::setBatteryGuard,
                    onUpdateYtdlp = { viewModel.setStatus(ytdlp = "جارٍ التحديث…", updating = true) },
                    onUpdateAdBlock = { viewModel.setStatus(adblock = "جارٍ التحديث…", updating = true) }
                )
            }
        }

        // ---------- the floating dock ----------
        val selectedIndex = dockItems.indexOfFirst {
            when (it.label) {
                "الرئيسية" -> currentRoute == Routes.HOME
                "التحميلات" -> currentRoute == Routes.DOWNLOADS
                "المتصفح" -> currentRoute == Routes.BROWSER
                "الأدوات" -> currentRoute == Routes.TOOLS
                "المكتبة" -> currentRoute == Routes.LIBRARY
                "𝒥𝒪 DON" -> currentRoute == Routes.JODON
                else -> currentRoute == Routes.SETTINGS
            }
        }.coerceAtLeast(0)

        AuroraDock(
            items = dockItems,
            selectedIndex = selectedIndex,
            onSelect = { index ->
                val route = when (index) {
                    0 -> Routes.JODON
                    1 -> Routes.HOME
                    2 -> Routes.DOWNLOADS
                    3 -> Routes.BROWSER
                    4 -> Routes.TOOLS
                    5 -> Routes.LIBRARY
                    else -> Routes.SETTINGS
                }
                currentRoute = route
                navController.navigate(route) {
                    popUpTo(Routes.HOME) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 18.dp, vertical = 22.dp)
        )
    }
}

object Routes {
    const val ONBOARDING = "onboarding"
    const val JODON = "jodon"
    const val PLAYER = "player"
    const val HOME = "home"
    const val DOWNLOADS = "downloads"
    const val BROWSER = "browser"
    const val TOOLS = "tools"
    const val CONVERTER = "converter"
    const val COMPRESSOR = "compressor"
    const val LIBRARY = "library"
    const val SETTINGS = "settings"
}
