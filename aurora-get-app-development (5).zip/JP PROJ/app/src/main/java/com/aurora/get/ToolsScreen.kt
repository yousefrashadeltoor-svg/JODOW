package com.aurora.get

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.aurora.get.core.designsystem.components.AuroraIcon
import com.aurora.get.core.designsystem.components.AuroraText
import com.aurora.get.core.designsystem.components.GlassSurface
import com.aurora.get.core.designsystem.icons.AuroraIcons
import com.aurora.get.core.designsystem.shaders.AuroraMeshBackground
import com.aurora.get.core.designsystem.theme.AuroraTheme

/** The tools hub: converter + compressor. */
@Composable
fun ToolsScreen(
    onConverter: () -> Unit,
    onCompressor: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    Box(modifier.fillMaxSize()) {
        AuroraMeshBackground(Modifier.matchParentSize(), intensity = 0.6f)
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp)
        ) {
            Spacer(Modifier.height(52.dp))
            AuroraText("الأدوات", style = AuroraTheme.typography.headline, color = colors.onBackground)
            Spacer(Modifier.height(16.dp))
            ToolCard(
                icon = AuroraIcons.Converter,
                title = "المحوّل",
                subtitle = "استخرج عدة صيغ وجودات في عملية واحدة",
                onClick = onConverter
            )
            Spacer(Modifier.height(12.dp))
            ToolCard(
                icon = AuroraIcons.Compressor,
                title = "تصغير الحجم",
                subtitle = "ضغط بدون فقد أو شفاف مع مقارنة قبل/بعد",
                onClick = onCompressor
            )
            Spacer(Modifier.height(140.dp))
        }
    }
}

@Composable
private fun ToolCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    val colors = AuroraTheme.colors
    GlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = AuroraTheme.shapes.large,
        elevation = 12.dp
    ) {
        Row(
            Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(46.dp)
                    .clip(AuroraTheme.shapes.medium)
                    .background(Brush.linearGradient(colors.accentSweep)),
                contentAlignment = Alignment.Center
            ) {
                AuroraIcon(icon, null, Modifier.size(22.dp), Color.White)
            }
            Column(Modifier.padding(start = 14.dp)) {
                AuroraText(title, style = AuroraTheme.typography.title, color = colors.onBackground)
                AuroraText(subtitle, style = AuroraTheme.typography.caption, color = colors.onBackgroundMuted)
            }
        }
    }
}
