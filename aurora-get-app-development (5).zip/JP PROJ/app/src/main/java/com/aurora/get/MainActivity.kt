package com.aurora.get

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.aurora.get.core.designsystem.components.AuroraGlassRoot
import com.aurora.get.core.designsystem.theme.AuroraTheme
import com.aurora.get.core.designsystem.theme.AuroraThemeId
import com.aurora.get.feature.settings.SettingsRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var settingsRepository: SettingsRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        var keepSplash = true
        splash.setKeepOnScreenCondition { keepSplash }

        val initial = runBlocking { settingsRepository.settings.first() }
        keepSplash = false

        setContent {
            var themeId by mutableStateOf(initial.themeId)
            var darkMode by mutableStateOf(initial.darkMode)
            AuroraTheme(
                themeId = themeId,
                dark = darkMode,
                layoutDirection = androidx.compose.ui.unit.LayoutDirection.Rtl
            ) {
                AuroraGlassRoot {
                    AuroraApp(
                        themeId = themeId,
                        darkMode = darkMode,
                        onThemeChanged = { id ->
                            themeId = id
                            settingsRepository.setTheme(id)
                        },
                        onDarkModeChanged = { value ->
                            darkMode = value
                            settingsRepository.setDarkMode(value)
                        },
                        sharedText = intent?.getStringExtra(android.content.Intent.EXTRA_TEXT)
                    )
                }
            }
        }
    }
}
