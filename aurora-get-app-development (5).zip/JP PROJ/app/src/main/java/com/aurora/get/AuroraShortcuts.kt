package com.aurora.get

import android.content.Context
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.aurora.get.R

/**
 * The launcher shortcuts: paste & analyse, internal browser, downloads, compressor.
 */
object AuroraShortcuts {

    fun install(context: Context) {
        val shortcuts = listOf(
            ShortcutInfoCompat.Builder(context, "paste")
                .setShortLabel(context.getString(R.string.shortcut_paste))
                .setLongLabel(context.getString(R.string.shortcut_paste))
                .setIcon(IconCompat.createWithResource(context, R.drawable.ic_widget_logo))
                .setIntent(
                    Intent(context, MainActivity::class.java).apply {
                        action = Intent.ACTION_VIEW
                        putExtra("route", "home")
                        putExtra("focus", "paste")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                )
                .build(),
            ShortcutInfoCompat.Builder(context, "browser")
                .setShortLabel(context.getString(R.string.shortcut_browser))
                .setLongLabel(context.getString(R.string.shortcut_browser))
                .setIcon(IconCompat.createWithResource(context, R.drawable.ic_widget_logo))
                .setIntent(
                    Intent(context, MainActivity::class.java).apply {
                        action = Intent.ACTION_VIEW
                        putExtra("route", "browser")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                )
                .build(),
            ShortcutInfoCompat.Builder(context, "downloads")
                .setShortLabel(context.getString(R.string.shortcut_downloads))
                .setLongLabel(context.getString(R.string.shortcut_downloads))
                .setIcon(IconCompat.createWithResource(context, R.drawable.ic_widget_logo))
                .setIntent(
                    Intent(context, MainActivity::class.java).apply {
                        action = Intent.ACTION_VIEW
                        putExtra("route", "downloads")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                )
                .build(),
            ShortcutInfoCompat.Builder(context, "compressor")
                .setShortLabel(context.getString(R.string.shortcut_compressor))
                .setLongLabel(context.getString(R.string.shortcut_compressor))
                .setIcon(IconCompat.createWithResource(context, R.drawable.ic_widget_logo))
                .setIntent(
                    Intent(context, MainActivity::class.java).apply {
                        action = Intent.ACTION_VIEW
                        putExtra("route", "compressor")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                )
                .build()
        )
        runCatching { ShortcutManagerCompat.setDynamicShortcuts(context, shortcuts) }
    }
}
