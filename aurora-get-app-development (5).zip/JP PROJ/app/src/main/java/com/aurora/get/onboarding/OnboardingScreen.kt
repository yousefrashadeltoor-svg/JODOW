package com.aurora.get.onboarding

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.aurora.get.core.designsystem.components.AuroraIcon
import com.aurora.get.core.designsystem.components.AuroraOrb
import com.aurora.get.core.designsystem.components.AuroraText
import com.aurora.get.core.designsystem.components.GlassSurface
import com.aurora.get.core.designsystem.icons.AuroraIcons
import com.aurora.get.core.designsystem.shaders.AuroraMeshBackground
import com.aurora.get.core.designsystem.theme.AuroraTheme

/**
 * A short, glowing onboarding.
 */
@Composable
fun OnboardingScreen(
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    val transition = rememberInfiniteTransition(label = "onboarding")
    val pulse by transition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Reverse),
        label = "onboardingPulse"
    )

    Box(modifier.fillMaxSize()) {
        AuroraMeshBackground(Modifier.matchParentSize())
        AuroraOrb(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 90.dp)
                .scale(pulse),
            radius = 130.dp
        )

        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AuroraIcon(AuroraIcons.Bolt, null, Modifier.size(44.dp), colors.primary)
            Spacer(Modifier.height(14.dp))
            AuroraText(
                "𝒥𝒪 DON",
                style = AuroraTheme.typography.display,
                color = colors.onBackground
            )
            AuroraText(
                "حمّل من أكثر من 1800 موقع بسرعة البرق",
                style = AuroraTheme.typography.body,
                color = colors.onBackgroundMuted
            )
            Spacer(Modifier.height(28.dp))

            GlassSurface(Modifier.fillMaxWidth(), shape = AuroraTheme.shapes.large, elevation = 16.dp) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    FeatureRow(AuroraIcons.Downloads, "محرك تحميل مجزّأ", "حتى 32 اتصالًا متوازيًا مع استكمال بعد الإيقاف")
                    FeatureRow(AuroraIcons.Browser, "متصفح داخلي", "اصطاد الملفات من الصفحات التي لا يمكن تحليلها")
                    FeatureRow(AuroraIcons.Shield, "خصوصية كاملة", "لا تحليلات ولا تتبّع — كل شيء على جهازك")
                }
            }

            Spacer(Modifier.height(26.dp))
            Box(
                Modifier
                    .clip(AuroraTheme.shapes.pill)
                    .background(Brush.linearGradient(colors.accentSweep))
                    .clickable(onClick = onDone)
                    .padding(horizontal = 42.dp, vertical = 16.dp)
            ) {
                AuroraText(
                    "لنبدأ",
                    style = AuroraTheme.typography.label,
                    color = Color.White
                )
            }
            Spacer(Modifier.height(20.dp))
            AuroraText(
                "المسؤولية على المستخدم في احترام حقوق النشر",
                style = AuroraTheme.typography.caption,
                color = colors.onBackgroundMuted
            )
        }
    }
}

@Composable
private fun FeatureRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String
) {
    val colors = AuroraTheme.colors
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(38.dp)
                .clip(AuroraTheme.shapes.medium)
                .background(Brush.linearGradient(colors.accentSweep)),
            contentAlignment = Alignment.Center
        ) {
            AuroraIcon(icon, null, Modifier.size(18.dp), Color.White)
        }
        Column(Modifier.padding(start = 12.dp)) {
            AuroraText(title, style = AuroraTheme.typography.label, color = colors.onBackground)
            AuroraText(subtitle, style = AuroraTheme.typography.caption, color = colors.onBackgroundMuted)
        }
    }
}
