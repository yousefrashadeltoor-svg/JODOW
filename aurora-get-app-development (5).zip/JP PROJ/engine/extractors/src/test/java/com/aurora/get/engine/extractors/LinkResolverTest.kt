package com.aurora.get.engine.extractors

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LinkResolverTest {

    private val resolver = LinkResolver(object : okhttp3.OkHttpClient() {})

    @Test
    fun `normalisation adds the missing scheme`() {
        assertEquals("https://example.dev/video", resolver.normalize("example.dev/video"))
        assertEquals("https://www.example.dev", resolver.normalize("www.example.dev"))
        assertEquals("https://example.dev", resolver.normalize("  https://example.dev  "))
    }

    @Test
    fun `magnet links are preserved`() {
        assertTrue(resolver.isMagnet(resolver.normalize("magnet:?xt=urn:btih:abcdef")))
    }

    @Test
    fun `direct media is detected by extension`() {
        assertTrue(resolver.isDirectMedia("https://cdn.dev/file.mp4"))
        assertTrue(resolver.isDirectMedia("https://cdn.dev/file.zip"))
        assertFalse(resolver.isDirectMedia("https://example.dev/watch"))
    }

    @Test
    fun `hls and dash manifests are detected`() {
        assertTrue(resolver.isHls("https://cdn.dev/master.m3u8"))
        assertTrue(resolver.isDash("https://cdn.dev/manifest.mpd"))
    }

    @Test
    fun `the domain is extracted without the path`() {
        assertEquals("example.dev", resolver.domainOf("https://example.dev/a/b?c=d"))
    }
}
