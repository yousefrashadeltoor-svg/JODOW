package com.aurora.get.engine.extractors

import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.network.RemoteSizeResolver

/**
 * One downloadable format extracted from a page.
 */
data class MediaFormat(
    val id: String,
    val kind: MediaKind,
    val ext: String,
    val url: String,
    val quality: String? = null,
    val resolution: String? = null,
    val width: Int? = null,
    val height: Int? = null,
    val fps: Int? = null,
    val videoCodec: String? = null,
    val audioCodec: String? = null,
    val bitrateKbps: Long? = null,
    val audioBitrateKbps: Long? = null,
    val sizeBytes: Long? = null,
    val sizeConfidence: RemoteSizeResolver.Confidence = RemoteSizeResolver.Confidence.UNKNOWN,
    val protocol: String? = null,
    val note: String? = null,
    val language: String? = null
) {
    val hasVideo: Boolean get() = videoCodec != null && videoCodec != "none"
    val hasAudio: Boolean get() = audioCodec != null && audioCodec != "none"
    val isMuxed: Boolean get() = hasVideo && hasAudio
}

/** The result of an extraction. */
data class ExtractedPage(
    val url: String,
    val title: String? = null,
    val uploader: String? = null,
    val durationSeconds: Long? = null,
    val thumbnailUrl: String? = null,
    val description: String? = null,
    val uploadDate: String? = null,
    val extractor: String? = null,
    val formats: List<MediaFormat> = emptyList(),
    val subtitles: List<SubtitleTrack> = emptyList(),
    val error: String? = null
) {
    val byKind: Map<MediaKind, List<MediaFormat>> get() = formats.groupBy { it.kind }
}

data class SubtitleTrack(
    val language: String,
    val label: String,
    val url: String,
    val ext: String = "vtt"
)
