package com.aurora.get.engine.extractors.youtube

import com.aurora.get.core.common.AuroraLog
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import java.io.IOException

/**
 * OkHttp transport for NewPipe Extractor.
 *
 * This is the *only* place where the extractor talks to the network: it mirrors the
 * behaviour of NewPipe's own `DownloaderImpl` but shares 𝒥𝒪 DON's client (cookies,
 * DNS cache, HTTP/2, Cronet/QUIC when available).
 *
 * VERIFY: `org.schabi.newpipe.extractor.downloader.Response` exposes the
 * `(responseBody, responseHeaders, responseCode)` constructor in 0.24.x. If the version
 * you use reorders these parameters, adjust this single call site.
 */
class NewPipeDownloader(private val client: OkHttpClient) : Downloader {

    @Throws(IOException::class)
    override fun execute(request: Request): Response {
        val url = request.url()
        val builder = okhttp3.Request.Builder().url(url)

        request.headers().forEach { (name, values) ->
            values?.forEach { value -> if (value != null) builder.addHeader(name, value) }
        }

        val payload = request.dataToSend()
        val body = if (payload != null && payload.isNotEmpty()) {
            payload.toRequestBody(request.sendContentType()?.toMediaTypeOrNull())
        } else {
            null
        }
        builder.method(request.httpMethod(), body)

        client.newCall(builder.build()).execute().use { raw ->
            val headers = ArrayList<String>()
            for (name in raw.headers.names()) {
                for (value in raw.headers.values(name)) {
                    headers.add("$name: $value")
                }
            }
            val bodyText = raw.body?.string() ?: ""
            return Response(bodyText, headers, raw.code)
        }
    }

    override fun shutdown() {
        runCatching { client.dispatcher.executorService.shutdown() }
            .onFailure { AuroraLog.w(TAG, "client shutdown failed: ${it.message}") }
    }

    private companion object {
        const val TAG = "NewPipeDownloader"
    }
}
