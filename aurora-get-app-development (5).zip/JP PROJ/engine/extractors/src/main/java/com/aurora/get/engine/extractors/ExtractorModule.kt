package com.aurora.get.engine.extractors

import com.aurora.get.core.common.LinkRefresher
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Implements the [LinkRefresher] contract used by the download engine to renew
 * expired links (HTTP 403 / 410) automatically.
 */
@Singleton
class YtDlpLinkRefresher @Inject constructor(
    private val engine: YoutubeDLEngine
) : LinkRefresher {
    override suspend fun refresh(url: String): String? {
        val page = engine.extract(url)
        return page.formats
            .firstOrNull { it.sizeBytes != null }
            ?.url
            ?: page.formats.firstOrNull()?.url
    }
}

@Module
@InstallIn(SingletonComponent::class)
abstract class ExtractorModule {
    @Binds
    @Singleton
    abstract fun bindLinkRefresher(impl: YtDlpLinkRefresher): LinkRefresher
}
