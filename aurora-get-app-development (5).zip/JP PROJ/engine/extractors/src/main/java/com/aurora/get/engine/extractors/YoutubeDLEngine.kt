package com.aurora.get.engine.extractors

import android.content.Context
import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.network.RemoteSizeResolver
import com.github.youtubedl.YoutubeDL
import com.github.youtubedl.YoutubeDLRequest
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Thin wrapper around `yt-dlp` (yausername/youtubedl-android).
 *
 * It powers **Stage 3** of the analysis pipeline: the complete list of formats,
 * qualities, subtitles and thumbnails for the 1800+ supported websites.
 *
 * VERIFY: the exact `YoutubeDLRequest` builder API of `io.github.junkfood02.youtubedl-android:0.18.1`
 * must be confirmed against the library sources before shipping — the request/response
 * objects are used through their documented builder + `data` payload only.
 */
@Singleton
class YoutubeDLEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {

    @Volatile
    private var initialized = false

    private fun ensureInitialized() {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            runCatching {
                YoutubeDL.getInstance().init(context)
                initialized = true
            }.onFailure { AuroraLog.e(TAG, "yt-dlp init failed: ${it.message}", it) }
        }
    }

    /** Updates the embedded yt-dlp binary (called from the settings screen). */
    suspend fun update(): Boolean = withContext(Dispatchers.IO) {
        ensureInitialized()
        runCatching {
            YoutubeDL.getInstance().updateYoutubeDL(context)
            true
        }.getOrElse {
            AuroraLog.w(TAG, "yt-dlp update failed: ${it.message}")
            false
        }
    }

    /** Extracts every available format without downloading anything. */
    suspend fun extract(url: String, cookies: String? = null, useAria2c: Boolean = false): ExtractedPage =
        withContext(Dispatchers.IO) {
            ensureInitialized()
            val builder = YoutubeDLRequest.Builder(url)
                .setOption("quiet", true)
                .setOption("no_warnings", true)
                .setOption("noplaylist", false)
                .setOption("ignoreerrors", true)
                .setOption("skip_download", true)
                .setOption("dump_single_json", true)
            if (useAria2c) {
                builder.setOption("external_downloader", "aria2c")
                builder.setOption("external_downloader_args", "-x16 -s16 -k1M")
            }
            if (!cookies.isNullOrBlank()) {
                val cookieFile = File(context.cacheDir, "yt-dlp-cookies.txt")
                runCatching { cookieFile.writeText(cookies) }
                builder.setOption("cookies", cookieFile.absolutePath)
            }

            runCatching {
                val response = YoutubeDL.getInstance().execute(builder.build())
                val payload = response.data.toString()
                parsePayload(url, JSONObject(payload))
            }.getOrElse {
                AuroraLog.w(TAG, "extract failed for $url: ${it.message}")
                ExtractedPage(url = url, error = it.message ?: "فشل الاستخراج")
            }
        }

    /** Parses the `dump_single_json` payload of yt-dlp. */
    fun parsePayload(url: String, json: JSONObject): ExtractedPage {
        val formats = mutableListOf<MediaFormat>()
        val formatsJson: JSONArray? = json.optJSONArray("formats")
        if (formatsJson != null) {
            for (i in 0 until formatsJson.length()) {
                val item = formatsJson.optJSONObject(i) ?: continue
                val format = parseFormat(item) ?: continue
                formats += format
            }
        }
        // The top level fields describe the "best" single file format.
        val direct = parseFormat(json)
        if (direct != null) formats += direct

        val subtitles = mutableListOf<SubtitleTrack>()
        json.optJSONObject("subtitles")?.let { subs ->
            subs.keys().forEach { language ->
                val tracks = subs.optJSONArray(language) ?: return@forEach
                for (i in 0 until tracks.length()) {
                    val track = tracks.optJSONObject(i) ?: continue
                    val trackUrl = track.optString("url")
                    if (trackUrl.isNullOrBlank()) continue
                    subtitles += SubtitleTrack(
                        language = language,
                        label = language,
                        url = trackUrl,
                        ext = track.optString("ext", "vtt")
                    )
                }
            }
        }
        json.optJSONObject("automatic_captions")?.let { subs ->
            subs.keys().take(6).forEach { language ->
                val tracks = subs.optJSONArray(language) ?: return@forEach
                for (i in 0 until tracks.length()) {
                    val track = tracks.optJSONObject(i) ?: continue
                    val trackUrl = track.optString("url")
                    if (trackUrl.isNullOrBlank()) continue
                    subtitles += SubtitleTrack(
                        language = language,
                        label = "$language (auto)",
                        url = trackUrl,
                        ext = track.optString("ext", "vtt")
                    )
                }
            }
        }

        return ExtractedPage(
            url = url,
            title = json.optString("title").takeIf { it.isNotBlank() },
            uploader = json.optString("uploader").takeIf { it.isNotBlank() }
                ?: json.optString("channel").takeIf { it.isNotBlank() },
            durationSeconds = json.optDouble("duration", 0.0).takeIf { it > 0 }?.toLong(),
            thumbnailUrl = json.optString("thumbnail").takeIf { it.isNotBlank() },
            description = json.optString("description").takeIf { it.isNotBlank() },
            uploadDate = json.optString("upload_date").takeIf { it.isNotBlank() },
            extractor = json.optString("extractor_key").takeIf { it.isNotBlank() },
            formats = formats.distinctBy { it.id },
            subtitles = subtitles
        )
    }

    private fun parseFormat(item: JSONObject): MediaFormat? {
        val url = item.optString("url")
        if (url.isNullOrBlank()) return null
        val ext = item.optString("ext", "")
        val vcodec = item.optString("vcodec").takeIf { it.isNotBlank() && it != "none" }
        val acodec = item.optString("acodec").takeIf { it.isNotBlank() && it != "none" }
        val height = item.optInt("height", 0).takeIf { it > 0 }
        val width = item.optInt("width", 0).takeIf { it > 0 }
        val fps = item.optDouble("fps", 0.0).takeIf { it > 0 }?.toInt()
        val tbr = item.optDouble("tbr", 0.0).takeIf { it > 0 }?.toLong()
        val abr = item.optDouble("abr", 0.0).takeIf { it > 0 }?.toLong()
        val size = item.optLong("filesize", -1).takeIf { it > 0 }
        val approx = item.optLong("filesize_approx", -1).takeIf { it > 0 }

        val kind = when {
            vcodec != null && acodec != null -> MediaKind.VIDEO
            vcodec != null -> MediaKind.VIDEO
            acodec != null -> MediaKind.AUDIO
            ext in listOf("jpg", "jpeg", "png", "webp") -> MediaKind.IMAGE
            ext == "json" || ext == "srt" || ext == "vtt" -> MediaKind.FILE
            else -> MediaKind.FILE
        }

        val sizeBytes = size ?: approx
        val confidence = when {
            size != null -> RemoteSizeResolver.Confidence.CONFIRMED
            approx != null -> RemoteSizeResolver.Confidence.APPROXIMATE
            else -> RemoteSizeResolver.Confidence.UNKNOWN
        }

        return MediaFormat(
            id = item.optString("format_id").takeIf { it.isNotBlank() } ?: url,
            kind = kind,
            ext = ext,
            url = url,
            quality = item.optString("format_note").takeIf { it.isNotBlank() }
                ?: height?.let { "${it}p" },
            resolution = if (width != null && height != null) "${width}x${height}" else null,
            width = width,
            height = height,
            fps = fps,
            videoCodec = vcodec,
            audioCodec = acodec,
            bitrateKbps = tbr,
            audioBitrateKbps = abr,
            sizeBytes = sizeBytes,
            sizeConfidence = confidence,
            protocol = item.optString("protocol").takeIf { it.isNotBlank() },
            note = item.optString("format_note").takeIf { it.isNotBlank() },
            language = item.optString("language").takeIf { it.isNotBlank() }
        )
    }

    companion object {
        private const val TAG = "YoutubeDLEngine"
    }
}
