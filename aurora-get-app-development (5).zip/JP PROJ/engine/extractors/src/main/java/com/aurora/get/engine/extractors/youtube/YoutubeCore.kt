package com.aurora.get.engine.extractors.youtube

import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.common.MediaKind
import okhttp3.OkHttpClient
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.services.ServiceList
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.SubtitlesStream
import org.schabi.newpipe.extractor.stream.VideoStream
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The real YouTube engine of 𝒥𝒪 DON.
 *
 * It browses and parses youtube.com exactly the way NewPipe does:
 * **no API key, no WebView, no scraping hacks** — the extractor reads the very same
 * player/next documents the site serves, so the experience matches the official app
 * while staying fully independent of any account.
 *
 * Every value here comes from the real page. When YouTube does not publish a number,
 * the field is `null` instead of being invented.
 */
@Singleton
class YoutubeCore @Inject constructor(
    private val client: OkHttpClient
) {

    private val initialized = AtomicBoolean(false)
    private val service get() = ServiceList.YouTube

    /** Must be called before the first extraction. */
    fun init() {
        if (initialized.getAndSet(true)) return
        runCatching {
            NewPipe.init(NewPipeDownloader(client), Localization.DEFAULT, ContentCountry.DEFAULT)
        }.onFailure {
            initialized.set(false)
            AuroraLog.e(TAG, "NewPipe init failed: ${it.message}", it)
        }
    }

    /* ------------------------------------------------------ search / suggest */

    /** Real "as you type" suggestions served by youtube.com. */
    suspend fun suggest(query: String): List<String> = withIo {
        init()
        runCatching { service.suggestionExtractor.suggestionList(query) }
            .getOrElse {
                AuroraLog.w(TAG, "suggest failed: ${it.message}")
                emptyList()
            }
    }

    /** Real search with pagination. `nextToken` comes from the previous [YtPage]. */
    suspend fun search(query: String, nextToken: Any? = null): YtPage = withIo {
        init()
        runCatching {
            val extractor = service.getSearchExtractor(query)
            extractor.fetchPage()
            if (nextToken == null) {
                mapPage(extractor.initialPage)
            } else {
                val continuation = extractor.getNextPage(nextToken as org.schabi.newpipe.extractor.Page)
                mapPage(continuation)
            }
        }.getOrElse {
            AuroraLog.w(TAG, "search failed: ${it.message}")
            YtPage(emptyList(), null)
        }
    }

    /** Real trending feed — the same kiosk the official app calls "المحتوى الرائج". */
    suspend fun trending(): YtPage = withIo {
        init()
        runCatching {
            val kiosks = service.kioskList
            val kiosk = runCatching { kiosks.getKioskById("Trending") }
                .getOrElse { kiosks.defaultKiosk }
            kiosk.fetchPage()
            mapPage(kiosk.initialPage)
        }.getOrElse {
            AuroraLog.w(TAG, "trending failed: ${it.message}")
            YtPage(emptyList(), null)
        }
    }

    /** Continuation page of the trending kiosk — real endless browsing. */
    suspend fun trendingMore(nextToken: Any): YtPage = withIo {
        init()
        runCatching {
            val kiosks = service.kioskList
            val kiosk = runCatching { kiosks.getKioskById("Trending") }
                .getOrElse { kiosks.defaultKiosk }
            mapPage(kiosk.getNextPage(nextToken as org.schabi.newpipe.extractor.Page))
        }.getOrElse {
            AuroraLog.w(TAG, "trending continuation failed: ${it.message}")
            YtPage(emptyList(), null)
        }
    }

    /* --------------------------------------------------------------- stream */

    /** Full real stream info: every video/audio quality, subtitles and related items. */
    suspend fun stream(url: String): YtStream = withIo {
        init()
        val extractor = service.getStreamExtractor(url)
        extractor.fetchPage()

        val video = YtVideo(
            id = extractor.id.orEmpty(),
            url = extractor.originalUrl.ifBlank { url },
            title = extractor.name.orEmpty(),
            thumbnail = thumb(extractor),
            channelName = extractor.uploaderName.orEmpty(),
            channelUrl = extractor.uploaderUrl.orEmpty(),
            durationSec = extractor.length,
            viewCount = extractor.viewCount,
            uploadDate = runCatching { extractor.textualUploadDate }.getOrNull(),
            isLive = runCatching { extractor.isLive }.getOrDefault(false)
        )

        val formats = ArrayList<YtFormat>()
        runCatching { extractor.videoStreams }.getOrElse { emptyList<VideoStream>() }
            .forEach { formats += videoFormat(it) }
        runCatching { extractor.videoOnlyStreams }.getOrElse { emptyList<VideoStream>() }
            .forEach { formats += videoFormat(it) }
        runCatching { extractor.audioStreams }.getOrElse { emptyList<AudioStream>() }
            .forEach { formats += audioFormat(it, video.durationSec) }

        val subtitles = runCatching { extractor.subtitles }.getOrElse { emptyList<SubtitlesStream>() }
            .map {
                YtSubtitle(
                    language = it.languageTag.orEmpty(),
                    url = it.url.orEmpty(),
                    autoGenerated = runCatching { it.isAutoGenerated }.getOrDefault(false)
                )
            }

        val related = runCatching { extractor.relatedItems }
            .getOrDefault(emptyList())
            .mapNotNull { item -> runCatching { mapVideoItem(item) }.getOrNull() }

        val description = runCatching { extractor.description.content.orEmpty() }.getOrDefault("")

        YtStream(
            video = video,
            description = description,
            likeCount = extractor.likeCount,
            formats = formats,
            subtitles = subtitles,
            related = related
        )
    }

    /** Real channel page (videos tab). */
    suspend fun channel(url: String): YtChannel = withIo {
        init()
        val extractor = service.getChannelExtractor(url)
        extractor.fetchPage()
        YtChannel(
            name = extractor.name.orEmpty(),
            url = extractor.originalUrl.ifBlank { url },
            avatar = thumb(extractor),
            subscriberCount = runCatching { extractor.subscriberCount }.getOrDefault(-1L),
            description = runCatching { extractor.description.orEmpty() }.getOrDefault(""),
            videos = runCatching { extractor.initialPage.items }
                .getOrDefault(emptyList())
                .mapNotNull { item -> runCatching { mapVideoItem(item) }.getOrNull() }
        )
    }

    /* -------------------------------------------------------------- private */

    private fun videoFormat(stream: VideoStream): YtFormat {
        val resolution = runCatching { stream.resolution }.getOrDefault("")
        val itag = runCatching { stream.itagItem?.id }.getOrNull()
        val bitrate = runCatching { stream.bitrate }.getOrDefault(-1L)
        return YtFormat(
            id = "v${itag ?: stream.hashCode()}",
            url = stream.url.orEmpty(),
            kind = MediaKind.VIDEO,
            quality = runCatching { stream.videoQuality }.getOrDefault(resolution).ifBlank { resolution },
            ext = runCatching { stream.format?.suffix }.getOrDefault("mp4"),
            mime = runCatching { stream.content }.getOrNull(),
            bitrateKbps = if (bitrate > 0) bitrate / 1024 else -1,
            videoOnly = stream.isVideoOnly,
            width = resolution.substringBefore('x').toIntOrNull(),
            height = resolution.substringAfter('x').toIntOrNull(),
            fps = null,
            sizeBytes = sizeFromBitrate(bitrate, 0),
            sizeApproximate = true,
            delivery = runCatching { stream.deliveryMethod.name }.getOrDefault("PROGRESSIVE")
        )
    }

    private fun audioFormat(stream: AudioStream, durationSec: Long): YtFormat {
        val bitrate = runCatching { stream.averageBitrate }.getOrDefault(-1L)
        return YtFormat(
            id = "a${stream.hashCode()}",
            url = stream.url.orEmpty(),
            kind = MediaKind.AUDIO,
            quality = runCatching { stream.audioTrackName }.getOrDefault("")
                .ifBlank { if (bitrate > 0) "${bitrate / 1024}kbps" else "صوت" },
            ext = runCatching { stream.format?.suffix }.getOrDefault("m4a"),
            mime = runCatching { stream.content }.getOrNull(),
            bitrateKbps = if (bitrate > 0) bitrate / 1024 else -1,
            videoOnly = false,
            width = null,
            height = null,
            fps = null,
            sizeBytes = sizeFromBitrate(bitrate, durationSec),
            sizeApproximate = true,
            delivery = runCatching { stream.deliveryMethod.name }.getOrDefault("PROGRESSIVE")
        )
    }

    /**
     * YouTube never publishes Content-Length for its streams, so the only honest
     * answer is a bitrate-derived estimate — and it is always flagged approximate.
     */
    private fun sizeFromBitrate(bitrateBps: Long, durationSec: Long): Long? {
        if (bitrateBps <= 0 || durationSec <= 0) return null
        return (bitrateBps * durationSec) / 8
    }

    private fun mapPage(page: org.schabi.newpipe.extractor.InfoItemsPage<out org.schabi.newpipe.extractor.InfoItem>?): YtPage {
        if (page == null) return YtPage(emptyList(), null)
        val items = page.items.mapNotNull { item -> runCatching { mapVideoItem(item) }.getOrNull() }
        return YtPage(items, page.nextPage)
    }

    private fun mapVideoItem(item: org.schabi.newpipe.extractor.InfoItem): YtVideo {
        val streamItem = item as? org.schabi.newpipe.extractor.stream.StreamInfoItem
        return YtVideo(
            id = item.url.substringAfter("v=").substringBefore("&").ifBlank { item.url },
            url = item.url.orEmpty(),
            title = item.name.orEmpty(),
            thumbnail = thumb(item),
            channelName = runCatching { streamItem?.uploaderName }.getOrNull().orEmpty(),
            channelUrl = runCatching { streamItem?.uploaderUrl }.getOrNull().orEmpty(),
            durationSec = runCatching { streamItem?.duration ?: -1L }.getOrDefault(-1L),
            viewCount = runCatching { streamItem?.viewCount ?: -1L }.getOrDefault(-1L),
            uploadDate = runCatching { streamItem?.textualUploadDate }.getOrNull(),
            isLive = item.streamType?.name?.contains("LIVE") == true
        )
    }

    /**
     * Thumbnail resolution is version sensitive in the extractor
     * (`getThumbnailUrl()` vs `getThumbnails()`), so it is resolved reflectively and
     * therefore compiles and runs against every release.
     */
    private fun thumb(obj: Any?): String? {
        if (obj == null) return null
        runCatching {
            val direct = obj.javaClass.methods.firstOrNull { it.name == "getThumbnailUrl" && it.parameterCount == 0 }
            (direct?.invoke(obj) as? String)?.let { if (it.isNotBlank()) return it }
        }
        runCatching {
            val list = obj.javaClass.methods.firstOrNull { it.name == "getThumbnails" && it.parameterCount == 0 }
            val images = list?.invoke(obj) as? List<*>
            val first = images?.lastOrNull() ?: images?.firstOrNull() ?: return@runCatching
            first.javaClass.methods.firstOrNull { it.name == "getUrl" && it.parameterCount == 0 }
                ?.invoke(first)?.let { return it as? String }
        }
        return null
    }

    private suspend fun <T> withIo(block: suspend () -> T): T =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { block() }

    private companion object {
        const val TAG = "YoutubeCore"
    }
}
