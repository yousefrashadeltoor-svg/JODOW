package com.aurora.get.engine.extractors

import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.common.FileNames
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.network.RemoteSizeResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Fast path extractors (Stage 2 of the pipeline).
 *
 * They only need one HTTP request + a lightweight HTML parse, which is why they can
 * answer in well under 1.5 s for the most popular websites — long before the full
 * yt-dlp extraction (Stage 3) finishes.
 */
@Singleton
class NativeExtractors @Inject constructor(
    private val client: OkHttpClient
) {

    suspend fun extract(url: String): ExtractedPage? = withContext(Dispatchers.IO) {
        val domain = url.substringAfter("://", "").substringBefore('/').lowercase()
        if (domain in DIRECT_ONLY_DOMAINS) return@withContext null

        runCatching {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/131.0.0.0 Mobile Safari/537.36")
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use null
                val body = response.body?.string().orEmpty()
                val contentType = response.header("Content-Type").orEmpty()
                val finalUrl = response.request.url.toString()

                // Direct media link? then it is not a page at all.
                if (contentType.startsWith("video/") || contentType.startsWith("audio/") ||
                    contentType.startsWith("image/") || isDirectExtension(finalUrl)
                ) {
                    return@use ExtractedPage(
                        url = finalUrl,
                        title = FileNames.toTitle(finalUrl.substringAfterLast('/')),
                        formats = listOf(
                            MediaFormat(
                                id = "direct",
                                kind = MediaKind.fromMime(contentType),
                                ext = FileNames.extensionOf(finalUrl).orEmpty(),
                                url = finalUrl,
                                sizeBytes = response.header("Content-Length")?.toLongOrNull(),
                                sizeConfidence = if (response.header("Content-Length") != null)
                                    RemoteSizeResolver.Confidence.CONFIRMED else RemoteSizeResolver.Confidence.UNKNOWN
                            )
                        )
                    )
                }

                parseHtml(url, body)
            }
        }.getOrElse {
            AuroraLog.w(TAG, "native extract failed for $url: ${it.message}")
            null
        }
    }

    /** Parses OpenGraph / Twitter cards / JSON-LD out of an HTML document. */
    fun parseHtml(url: String, html: String): ExtractedPage {
        val document = Jsoup.parse(html)
        val title = document.selectFirst("meta[property=og:title]")?.attr("content")?.takeIf { it.isNotBlank() }
            ?: document.title().takeIf { it.isNotBlank() }
        val description = document.selectFirst("meta[property=og:description]")?.attr("content")
        val image = document.selectFirst("meta[property=og:image]")?.attr("content")
            ?: document.selectFirst("meta[name=twitter:image]")?.attr("content")
        val siteName = document.selectFirst("meta[property=og:site_name]")?.attr("content")

        val formats = mutableListOf<MediaFormat>()

        document.select("meta[property=og:video]").forEach { element ->
            val videoUrl = element.attr("content")
            if (videoUrl.isBlank()) return@forEach
            formats += MediaFormat(
                id = "og-video-${formats.size}",
                kind = MediaKind.VIDEO,
                ext = FileNames.extensionOf(videoUrl).orEmpty().ifEmpty { "mp4" },
                url = videoUrl,
                quality = element.attr("video:width").takeIf { it.isNotBlank() }?.let { "${it}px" },
                width = element.attr("video:width").toIntOrNull(),
                height = element.attr("video:height").toIntOrNull(),
                protocol = "https"
            )
        }

        document.select("meta[property=og:audio]").forEach { element ->
            val audioUrl = element.attr("content")
            if (audioUrl.isBlank()) return@forEach
            formats += MediaFormat(
                id = "og-audio-${formats.size}",
                kind = MediaKind.AUDIO,
                ext = FileNames.extensionOf(audioUrl).orEmpty().ifEmpty { "m4a" },
                url = audioUrl,
                protocol = "https"
            )
        }

        // JSON-LD VideoObject — used by many blogs and CMS.
        document.select("script[type=application/ld+json]").forEach { script ->
            val raw = script.data()
            if (!raw.contains("VideoObject")) return@forEach
            runCatching {
                val contentUrl = Regex("\"contentUrl\"\\s*:\\s*\"([^\"]+)\"").find(raw)?.groupValues?.get(1)
                val embed = Regex("\"embedUrl\"\\s*:\\s*\"([^\"]+)\"").find(raw)?.groupValues?.get(1)
                val duration = Regex("\"duration\"\\s*:\\s*\"?([^\",}]+)").find(raw)?.groupValues?.get(1)
                val name = Regex("\"name\"\\s*:\\s*\"([^\"]+)\"").find(raw)?.groupValues?.get(1)
                val target = contentUrl ?: embed
                if (!target.isNullOrBlank()) {
                    formats += MediaFormat(
                        id = "ld-video-${formats.size}",
                        kind = MediaKind.VIDEO,
                        ext = FileNames.extensionOf(target).orEmpty().ifEmpty { "mp4" },
                        url = target,
                        quality = name,
                        note = duration
                    )
                }
            }
        }

        // <video>/<source> tags.
        document.select("video source[src], video[src], source[src]").forEach { element ->
            val src = element.attr("src")
            if (src.isBlank() || formats.any { it.url == src }) return@forEach
            val type = element.attr("type")
            formats += MediaFormat(
                id = "tag-${formats.size}",
                kind = MediaKind.fromMime(type),
                ext = FileNames.extensionOf(src).orEmpty(),
                url = src,
                protocol = "https"
            )
        }

        return ExtractedPage(
            url = url,
            title = title,
            uploader = siteName,
            thumbnailUrl = image,
            description = description,
            formats = formats
        )
    }

    private fun isDirectExtension(url: String): Boolean {
        val ext = FileNames.extensionOf(url) ?: return false
        return ext in MEDIA_EXTENSIONS
    }

    companion object {
        private const val TAG = "NativeExtractors"

        val MEDIA_EXTENSIONS = setOf(
            "mp4", "mkv", "webm", "mov", "avi", "flv", "m4v", "3gp",
            "mp3", "m4a", "aac", "opus", "ogg", "wav", "flac", "weba",
            "jpg", "jpeg", "png", "webp", "avif", "gif",
            "zip", "rar", "7z", "tar", "gz", "iso", "pdf", "epub", "apk", "csv", "json"
        )

        /** Domains that are handled by yt-dlp only. */
        val DIRECT_ONLY_DOMAINS = setOf(
            "youtube.com", "youtu.be", "tiktok.com", "instagram.com", "facebook.com",
            "fb.watch", "twitter.com", "x.com", "reddit.com", "pinterest.com",
            "vimeo.com", "soundcloud.com", "twitch.tv", "dailymotion.com",
            "bilibili.com", "nicovideo.jp", "vk.com", "rumble.com", "odysee.com"
        )

        /** Sites that are known to need the internal browser (Cloudflare & co). */
        val NEEDS_BROWSER = setOf(
            "facebook.com", "instagram.com", "tiktok.com", "x.com", "twitter.com",
            "douyin.com", "snapchat.com", "linkedin.com"
        )
    }
}
