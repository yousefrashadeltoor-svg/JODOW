package com.aurora.get.engine.extractors

import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.common.FileNames
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Normalises and resolves links before the analysis starts:
 *  * trims and cleans the user input
 *  * adds the missing scheme
 *  * resolves short links by following the redirects
 *  * detects direct media, HLS and DASH links
 */
@Singleton
class LinkResolver @Inject constructor(
    private val client: OkHttpClient
) {

    data class Resolved(
        val original: String,
        val url: String,
        val domain: String,
        val isDirect: Boolean,
        val isMagnet: Boolean,
        val isHls: Boolean,
        val isDash: Boolean,
        val extension: String?
    )

    /** Stage 0: pure string work, no network. */
    fun normalize(raw: String): String {
        var value = raw.trim()
        if (value.isEmpty()) return value
        value = value.replace(Regex("^[\"'<]+|[\"'>]+$"), "")
        if (value.startsWith("www.", ignoreCase = true) && !value.contains("://")) {
            value = "https://$value"
        } else if (!value.contains("://") && !value.startsWith("magnet:")) {
            value = "https://$value"
        }
        return value
    }

    fun domainOf(url: String): String =
        url.substringAfter("://", url).substringBefore('/').substringBefore('?').lowercase()

    fun isMagnet(url: String): Boolean = url.startsWith("magnet:", ignoreCase = true)

    fun isDirectMedia(url: String): Boolean {
        val ext = FileNames.extensionOf(url)?.lowercase() ?: return false
        return ext in NativeExtractors.MEDIA_EXTENSIONS
    }

    fun isHls(url: String): Boolean = url.contains(".m3u8", ignoreCase = true)

    fun isDash(url: String): Boolean = url.contains(".mpd", ignoreCase = true)

    /** Follows the redirects of a short link and returns the final destination. */
    suspend fun resolveRedirects(url: String): String = withContext(Dispatchers.IO) {
        runCatching {
            val request = Request.Builder().url(url).head().build()
            client.newCall(request).execute().use { response ->
                response.request.url.toString()
            }
        }.getOrElse {
            AuroraLog.d(TAG, "redirect resolution failed for $url: ${it.message}")
            url
        }
    }

    suspend fun resolve(raw: String): Resolved {
        val normalized = normalize(raw)
        val domain = domainOf(normalized)
        if (isMagnet(normalized)) {
            return Resolved(raw, normalized, domain, false, true, false, false, null)
        }
        val resolvedUrl = if (domain in SHORTENERS) resolveRedirects(normalized) else normalized
        return Resolved(
            original = raw,
            url = resolvedUrl,
            domain = domainOf(resolvedUrl),
            isDirect = isDirectMedia(resolvedUrl),
            isMagnet = false,
            isHls = isHls(resolvedUrl),
            isDash = isDash(resolvedUrl),
            extension = FileNames.extensionOf(resolvedUrl)
        )
    }

    companion object {
        private const val TAG = "LinkResolver"

        val SHORTENERS = setOf(
            "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly",
            "rebrand.ly", "cutt.ly", "shorturl.at", "rb.gy", "lnkd.in", "youtu.be",
            "amzn.to", "fb.me", "wa.me", "chat.whatsapp.com", "t.me"
        )
    }
}
