package com.aurora.get.engine.media

import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.network.RemoteSizeResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Computes the **real** size of an HLS / DASH stream by summing the sizes of all the
 * segments (plus the initialisation segment) using parallel HEAD requests.
 */
@Singleton
class StreamSizeCollector @Inject constructor(
    private val client: OkHttpClient
) {

    data class StreamSize(
        val bytes: Long,
        val segmentCount: Int,
        val confirmed: Boolean
    )

    suspend fun collect(masterUrl: String, headers: Map<String, String> = emptyMap()): StreamSize? =
        withContext(Dispatchers.IO) {
            val playlist = fetchText(masterUrl, headers) ?: return@withContext null
            if (playlist.contains("#EXT-X-STREAM-INF")) {
                // A master playlist: use the highest bandwidth variant.
                val variant = parseHighestVariant(playlist, masterUrl) ?: return@withContext null
                return@withContext collect(variant, headers)
            }
            val segmentUrls = parseSegments(playlist, masterUrl)
            if (segmentUrls.isEmpty()) return@withContext null
            val sizes = fetchSizes(segmentUrls, headers)
            val total = sizes.sum()
            val confirmed = sizes.all { it != null }
            StreamSize(total, segmentUrls.size, confirmed)
        }

    private fun parseSegments(playlist: String, baseUrl: String): List<String> =
        playlist.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .map { resolve(baseUrl, it) }
            .toList()

    private fun parseHighestVariant(playlist: String, baseUrl: String): String? {
        var bestBandwidth = -1L
        var bestUrl: String? = null
        val lines = playlist.lines()
        lines.forEachIndexed { index, line ->
            if (!line.startsWith("#EXT-X-STREAM-INF")) return@forEachIndexed
            val bandwidth = Regex("BANDWIDTH=(\\d+)").find(line)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            val next = lines.getOrNull(index + 1)?.trim()
            if (!next.isNullOrBlank() && !next.startsWith("#") && bandwidth > bestBandwidth) {
                bestBandwidth = bandwidth
                bestUrl = resolve(baseUrl, next)
            }
        }
        return bestUrl
    }

    private suspend fun fetchSizes(urls: List<String>, headers: Map<String, String>): List<Long?> =
        coroutineScope {
            val gate = Semaphore(32)
            urls.map { url ->
                async(Dispatchers.IO) {
                    gate.withPermit { headSize(url, headers) }
                }
            }.awaitAll()
        }

    private fun headSize(url: String, headers: Map<String, String>): Long? = runCatching {
        val builder = Request.Builder().url(url).head()
        headers.forEach { (k, v) -> builder.header(k, v) }
        client.newCall(builder.build()).execute().use { response ->
            response.header("Content-Length")?.toLongOrNull()
        }
    }.getOrElse {
        AuroraLog.d(TAG, "head failed for $url: ${it.message}")
        null
    }

    private fun fetchText(url: String, headers: Map<String, String>): String? = runCatching {
        val builder = Request.Builder().url(url)
        headers.forEach { (k, v) -> builder.header(k, v) }
        client.newCall(builder.build()).execute().use { response ->
            response.body?.string()
        }
    }.getOrNull()

    private fun resolve(base: String, relative: String): String {
        if (relative.startsWith("http", ignoreCase = true)) return relative
        val baseUri = java.net.URI(base)
        return baseUri.resolve(relative).toString()
    }

    companion object {
        private const val TAG = "StreamSizeCollector"

        /** Parses a DASH manifest and sums the sizes of every segment. */
        fun parseDashSegments(mpd: String): List<String> {
            val segments = mutableListOf<String>()
            Regex("<SegmentTemplate[^>]*media=\"([^\"]+)\"[^>]*/?>").findAll(mpd).forEach { match ->
                val media = match.groupValues[1]
                if (media.isNotBlank()) segments += media
            }
            Regex("<SegmentList[^>]*>").findAll(mpd).forEach { match ->
                Regex("<SegmentURL\\s+media=\"([^\"]+)\"").findAll(match.value).forEach { inner ->
                    segments += inner.groupValues[1]
                }
            }
            Regex("<Initialization\\s+sourceURL=\"([^\"]+)\"").findAll(mpd).forEach { match ->
                segments += match.groupValues[1]
            }
            return segments
        }
    }
}
