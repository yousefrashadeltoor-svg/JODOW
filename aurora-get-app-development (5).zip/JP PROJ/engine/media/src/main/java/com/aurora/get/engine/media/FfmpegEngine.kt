package com.aurora.get.engine.media

import android.content.Context
import com.aurora.get.core.common.AuroraLog
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.concurrent.thread

/**
 * FFmpeg wrapper used for merging, converting, compressing and tagging.
 * Every operation runs in a background thread and returns a structured result.
 */
@Singleton
class FfmpegEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val locator: FfmpegLocator
) {

    data class Result(
        val success: Boolean,
        val exitCode: Int = -1,
        val output: String = "",
        val outputFile: File? = null
    ) {
        val errorLine: String?
            get() = output.lineSequence()
                .firstOrNull { it.contains("Error", ignoreCase = true) || it.contains("Invalid", ignoreCase = true) }
                ?.trim()
    }

    suspend fun isAvailable(): Boolean = locator.isAvailable()

    /** Runs a raw ffmpeg command. */
    suspend fun run(args: List<String>): Result = withContext(Dispatchers.IO) {
        val binary = locator.locate()
        if (binary == null) {
            return@withContext Result(false, output = "FFmpeg binary not found")
        }
        val command = binary + args
        AuroraLog.d(TAG, "ffmpeg ${args.joinToString(" ")}")
        var output = StringBuilder()
        var exitCode = -1
        val process = runCatching {
            ProcessBuilder(command).redirectErrorStream(true).start()
        }.getOrElse {
            return@withContext Result(false, output = it.message ?: "cannot start ffmpeg")
        }
        val reader = thread(start = true, isDaemon = true) {
            process.inputStream.bufferedReader().use { lines ->
                lines.forEach { line ->
                    output.append(line).append('\n')
                    if (output.length > 64_000) output.setLength(0)
                }
            }
        }
        exitCode = process.waitFor()
        reader.join(2_000)
        Result(exitCode == 0, exitCode, output.toString())
    }

    /** Extracts the audio track without re-encoding (stream copy) when possible. */
    suspend fun extractAudio(input: File, output: File, codec: String = "copy"): Result {
        output.parentFile?.mkdirs()
        val args = mutableListOf("-y", "-i", input.absolutePath, "-vn")
        when (codec) {
            "copy" -> args += listOf("-c:a", "copy")
            "mp3" -> args += listOf("-c:a", "libmp3lame", "-b:a", "192k")
            "aac" -> args += listOf("-c:a", "aac", "-b:a", "192k")
            "opus" -> args += listOf("-c:a", "libopus", "-b:a", "160k")
            "flac" -> args += listOf("-c:a", "flac")
            else -> args += listOf("-c:a", codec)
        }
        args += output.absolutePath
        val result = run(args)
        return result.copy(outputFile = if (result.success) output else null)
    }

    /** Merges a DASH video-only file with the best audio track (no re-encoding). */
    suspend fun mergeVideoAndAudio(video: File, audio: File, output: File): Result {
        output.parentFile?.mkdirs()
        val args = listOf(
            "-y", "-i", video.absolutePath, "-i", audio.absolutePath,
            "-map", "0:v:0", "-map", "1:a:0", "-c", "copy",
            "-movflags", "+faststart", output.absolutePath
        )
        val result = run(args)
        return result.copy(outputFile = if (result.success) output else null)
    }

    /** Re-encodes a video with a quality driven CRF (used by the compressor). */
    suspend fun compressVideo(
        input: File,
        output: File,
        crf: Int = 28,
        preset: String = "slow",
        codec: String = "libx265"
    ): Result {
        output.parentFile?.mkdirs()
        val args = listOf(
            "-y", "-i", input.absolutePath,
            "-c:v", codec, "-crf", crf.toString(), "-preset", preset,
            "-tag:v", "hvc1", "-c:a", "copy",
            "-movflags", "+faststart", output.absolutePath
        )
        val result = run(args)
        return result.copy(outputFile = if (result.success) output else null)
    }

    /** Re-encodes an audio file to a transparent codec. */
    suspend fun compressAudio(input: File, output: File, codec: String = "libopus", bitrate: String = "128k"): Result {
        output.parentFile?.mkdirs()
        val args = listOf(
            "-y", "-i", input.absolutePath,
            "-c:a", codec, "-b:a", bitrate, "-vbr", "on",
            output.absolutePath
        )
        val result = run(args)
        return result.copy(outputFile = if (result.success) output else null)
    }

    /** Writes the metadata (title / artist / album / artwork) into the file. */
    suspend fun embedMetadata(
        input: File,
        output: File,
        title: String? = null,
        artist: String? = null,
        album: String? = null,
        artwork: File? = null
    ): Result {
        output.parentFile?.mkdirs()
        val args = mutableListOf("-y", "-i", input.absolutePath)
        artwork?.let { args += listOf("-i", it.absolutePath) }
        args += listOf("-c", "copy")
        title?.let { args += listOf("-metadata", "title=$it") }
        artist?.let { args += listOf("-metadata", "artist=$it") }
        album?.let { args += listOf("-metadata", "album=$it") }
        if (artwork != null) {
            args += listOf("-map", "0", "-map", "1", "-c:v", "mjpeg", "-disposition:v", "attached_pic")
        }
        args += output.absolutePath
        val result = run(args)
        return result.copy(outputFile = if (result.success) output else null)
    }

    /** Extracts a single frame as a JPEG (used for the thumbnails). */
    suspend fun extractFrame(input: File, output: File, atSeconds: Double = 1.0): Result {
        output.parentFile?.mkdirs()
        val args = listOf(
            "-y", "-ss", atSeconds.toString(), "-i", input.absolutePath,
            "-frames:v", "1", "-q:v", "3", output.absolutePath
        )
        val result = run(args)
        return result.copy(outputFile = if (result.success) output else null)
    }

    /** Trims a video or an audio file. */
    suspend fun trim(input: File, output: File, start: Double, duration: Double): Result {
        output.parentFile?.mkdirs()
        val args = listOf(
            "-y", "-ss", start.toString(), "-i", input.absolutePath,
            "-t", duration.toString(), "-c", "copy", output.absolutePath
        )
        val result = run(args)
        return result.copy(outputFile = if (result.success) output else null)
    }

    companion object {
        private const val TAG = "FfmpegEngine"
    }
}
