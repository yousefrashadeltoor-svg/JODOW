package com.aurora.get.engine.media

import android.content.Context
import com.aurora.get.core.common.AuroraLog
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Locates the FFmpeg binary that ships inside the `youtubedl-android` AAR.
 *
 * The library extracts the binary into the application private storage. The lookup is
 * done **by reflection** on purpose: the exact class that exposes the binary changed
 * between the releases of `youtubedl-android`, and reflection keeps Aurora Get working
 * with every version instead of failing to compile against one of them.
 *
 * VERIFY: `com.github.youtubedl.FFmpegProbe` is the class used by `youtubedl-android`
 * to expose the FFmpeg command. If the class name changes, only this file has to be
 * updated — the reflection falls back to the file system lookup automatically.
 */
@Singleton
class FfmpegLocator @Inject constructor(
    @ApplicationContext private val context: Context
) {

    @Volatile
    private var cached: List<String>? = null

    fun locate(): List<String>? {
        cached?.let { return it }
        val command = findViaReflection() ?: findOnDisk()
        cached = command
        return command
    }

    private fun findViaReflection(): List<String>? = runCatching {
        val probeClass = Class.forName("com.github.youtubedl.FFmpegProbe")
        val instance = probeClass.getField("INSTANCE").get(null)
        val method = probeClass.methods.firstOrNull { m ->
            m.parameterCount == 0 && (
                m.name == "getCommand" || m.name == "getFFmpegCommand" || m.name == "getCommandPath"
                )
        }
        val result = method?.invoke(instance)
        when (result) {
            is List<*> -> result.filterIsInstance<String>().ifEmpty { null }
            is String -> listOf(result)
            else -> null
        }
    }.getOrElse {
        AuroraLog.d(TAG, "FFmpegProbe not available: ${it.message}")
        null
    }

    private fun findOnDisk(): List<String>? {
        val candidates = buildList {
            add(File(context.filesDir, "ffmpeg"))
            add(File(context.filesDir, "ffmpeg.bin"))
            add(File(context.noBackupFilesDir, "ffmpeg"))
            add(File(context.cacheDir, "ffmpeg"))
            add(File(context.applicationInfo.nativeLibraryDir, "ffmpeg"))
        }
        val found = candidates.firstOrNull { it.exists() && it.canExecute() }
        if (found != null) return listOf(found.absolutePath)

        // Last resort: a system wide installation (rare on Android, useful on emulators).
        val systemPaths = listOf("/system/bin/ffmpeg", "/system/xbin/ffmpeg", "/usr/bin/ffmpeg")
        val system = systemPaths.firstOrNull { File(it).exists() }
        return system?.let { listOf(it) }
    }

    fun isAvailable(): Boolean = locate() != null

    companion object {
        private const val TAG = "FfmpegLocator"
    }
}
