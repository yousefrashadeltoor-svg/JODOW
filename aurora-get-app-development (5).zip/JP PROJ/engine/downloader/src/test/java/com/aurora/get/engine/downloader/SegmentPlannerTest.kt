package com.aurora.get.engine.downloader

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SegmentPlannerTest {

    @Test
    fun `single connection yields one chunk`() {
        val chunks = SegmentPlanner.plan(5_000_000, 1)
        assertEquals(1, chunks.size)
        assertEquals(0L, chunks[0].start)
        assertEquals(4_999_999L, chunks[0].end)
    }

    @Test
    fun `chunks cover the whole file without gaps`() {
        val total = 100_000_000L
        val chunks = SegmentPlanner.plan(total, 16)
        assertTrue(chunks.size > 1)
        var expectedStart = 0L
        chunks.forEachIndexed { index, chunk ->
            assertEquals(expectedStart, chunk.start)
            assertEquals(index, chunk.index)
            expectedStart = chunk.end + 1
        }
        assertEquals(total, expectedStart)
    }

    @Test
    fun `unknown size produces one open ended chunk`() {
        val chunks = SegmentPlanner.plan(null, 16)
        assertEquals(1, chunks.size)
        assertEquals(Long.MAX_VALUE - 1, chunks[0].end)
    }

    @Test
    fun `chunk size never goes below the minimum`() {
        val chunks = SegmentPlanner.plan(2_000_000L, 32)
        chunks.forEach { assertTrue(it.size >= SegmentPlanner.MIN_CHUNK_BYTES) }
    }

    @Test
    fun `adaptive connections respect the payload size`() {
        assertEquals(1, SegmentPlanner.adaptiveConnections(512, 16))
        assertEquals(16, SegmentPlanner.adaptiveConnections(500_000_000, 16))
        assertEquals(8, SegmentPlanner.adaptiveConnections(null, 16))
        assertTrue(SegmentPlanner.adaptiveConnections(1_000_000_000, 64) <= 32)
    }

    @Test
    fun `splitting a chunk halves the remaining bytes`() {
        val chunk = Chunk(0, 0, 10_000_000)
        val split = SegmentPlanner.split(chunk, alreadyDownloaded = 0)
        assertNotNull(split)
        val (head, tail) = split!!
        assertEquals(chunk.start, head.start)
        assertEquals(tail.start - 1, head.end)
        assertEquals(chunk.end, tail.end)
    }

    @Test
    fun `a nearly finished chunk cannot be split`() {
        val chunk = Chunk(0, 0, 1024)
        assertNull(SegmentPlanner.split(chunk, alreadyDownloaded = 0))
    }
}
