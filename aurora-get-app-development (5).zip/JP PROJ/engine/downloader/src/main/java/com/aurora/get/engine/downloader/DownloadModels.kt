package com.aurora.get.engine.downloader

import com.aurora.get.core.common.MediaKind
import java.io.File

/** Everything the engine needs in order to fetch one file. */
data class DownloadRequest(
    val id: String,
    val url: String,
    val title: String,
    val fileName: String,
    val destinationDir: File,
    val kind: MediaKind,
    val headers: Map<String, String> = emptyMap(),
    val referer: String? = null,
    val userAgent: String? = null,
    val totalBytes: Long? = null,
    val mimeType: String? = null,
    val quality: String? = null,
    val codec: String? = null,
    val width: Int? = null,
    val height: Int? = null,
    val fps: Int? = null,
    val thumbnailUrl: String? = null,
    val priority: Int = 0,
    val sourceId: String? = null,
    val playlistItemId: String? = null
)

/** One chunk of the file. Chunks are the unit of parallelism *and* of resume. */
data class Chunk(
    val index: Int,
    val start: Long,
    val end: Long
) {
    val size: Long get() = end - start + 1
    val lastByte: Long get() = end
}

/** Live progress emitted by the engine. */
data class DownloadProgress(
    val id: String,
    val downloadedBytes: Long,
    val totalBytes: Long?,
    val bytesPerSecond: Double,
    val activeConnections: Int,
    val samples: List<Float> = emptyList(),
    val etaSeconds: Long? = null
)

/** Terminal states of a download. */
enum class DownloadStatus {
    QUEUED,
    RUNNING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

sealed interface DownloadOutcome {
    data class Completed(val file: File, val bytes: Long) : DownloadOutcome
    data class Paused(val downloadedBytes: Long) : DownloadOutcome
    data class Failed(val reason: String, val cause: Throwable? = null) : DownloadOutcome
    data class Cancelled(val downloadedBytes: Long) : DownloadOutcome
}

/** Thrown when the remote file changed between the pause and the resume. */
class RemoteFileChangedException(val remoteEtag: String?) :
    RuntimeException("الملف البعيد تغيّر منذ آخر استكمال")
