package com.aurora.get.engine.downloader

import kotlin.math.max
import kotlin.math.min

/**
 * Splits a file into chunks for the parallel downloader.
 *
 * The number of connections adapts to the file size: small files are never split
 * into more than a handful of chunks, huge files get small chunks so that the
 * work-stealing stays effective.
 */
object SegmentPlanner {

    const val MIN_CHUNK_BYTES = 1L * 1024 * 1024   // 1 MiB
    const val MAX_CHUNK_BYTES = 16L * 1024 * 1024  // 16 MiB

    /**
     * @param totalBytes the real size of the file, or null when it is unknown.
     * @param requestedConnections the user configured maximum (8..32).
     */
    fun plan(totalBytes: Long?, requestedConnections: Int): List<Chunk> {
        val connections = requestedConnections.coerceIn(1, 32)
        if (totalBytes == null || totalBytes <= 0L) {
            // Unknown length: a single open ended chunk.
            return listOf(Chunk(0, 0, Long.MAX_VALUE - 1))
        }
        if (connections == 1 || totalBytes <= MIN_CHUNK_BYTES) {
            return listOf(Chunk(0, 0, totalBytes - 1))
        }
        val targetChunk = (totalBytes / connections).coerceIn(MIN_CHUNK_BYTES, MAX_CHUNK_BYTES)
        val chunks = mutableListOf<Chunk>()
        var index = 0
        var start = 0L
        while (start < totalBytes) {
            val end = min(start + targetChunk - 1, totalBytes - 1)
            chunks += Chunk(index++, start, end)
            start = end + 1
        }
        return chunks
    }

    /** The number of connections that should be used for a given payload. */
    fun adaptiveConnections(totalBytes: Long?, requested: Int): Int {
        val limit = requested.coerceIn(1, 32)
        if (totalBytes == null || totalBytes <= 0) return min(limit, 8)
        val bySize = (totalBytes / MIN_CHUNK_BYTES).toInt()
        return max(1, min(limit, bySize))
    }

    /**
     * Splits a chunk in half — used by the work-stealing scheduler when a slow chunk
     * is the only remaining work.
     */
    fun split(chunk: Chunk, alreadyDownloaded: Long): Pair<Chunk, Chunk>? {
        val remaining = chunk.end - (chunk.start + alreadyDownloaded) + 1
        if (remaining <= MIN_CHUNK_BYTES) return null
        val half = remaining / 2
        val boundary = chunk.start + alreadyDownloaded + half - 1
        val head = chunk.copy(end = boundary)
        val tail = chunk.copy(start = boundary + 1)
        return head to tail
    }
}
