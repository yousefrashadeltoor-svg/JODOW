package com.aurora.get.engine.downloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.common.Format
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Rich download notifications (progress + pause / resume / cancel actions).
 */
@Singleton
class DownloadNotifications @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val manager = NotificationManagerCompat.from(context)

    fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "𝒥𝒪 DON Downloads",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Download progress and controls"
            setShowBadge(false)
            enableVibration(false)
        }
        val system = context.getSystemService(NotificationManager::class.java)
        system?.createNotificationChannel(channel)
    }

    fun buildProgress(
        id: String,
        title: String,
        progress: Int,
        total: Long?,
        state: DownloadStatus,
        indeterminate: Boolean = false
    ): Notification {
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOnlyAlertOnce(true)
            .setOngoing(state == DownloadStatus.RUNNING)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setProgress(100, progress, indeterminate)

        if (total != null && total > 0) {
            builder.setContentText("${Format.bytes(total * progress / 100)} / ${Format.bytes(total)}")
        } else {
            builder.setContentText("جارٍ التحميل…")
        }

        val openIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
        if (openIntent != null) {
            builder.setContentIntent(
                PendingIntent.getActivity(context, id.hashCode(), openIntent, pendingIntentFlags())
            )
        }

        when (state) {
            DownloadStatus.RUNNING -> {
                builder.addAction(0, "إيقاف", serviceIntent(id, DownloadForegroundService.ACTION_PAUSE))
                builder.addAction(0, "إلغاء", serviceIntent(id, DownloadForegroundService.ACTION_CANCEL))
            }

            DownloadStatus.PAUSED, DownloadStatus.QUEUED -> {
                builder.addAction(0, "استكمال", serviceIntent(id, DownloadForegroundService.ACTION_RESUME))
                builder.addAction(0, "إلغاء", serviceIntent(id, DownloadForegroundService.ACTION_CANCEL))
            }

            else -> Unit
        }
        return builder.build()
    }

    fun notify(notification: Notification, id: Int) {
        runCatching { manager.notify(id, notification) }
            .onFailure { AuroraLog.w(TAG, "notification failed: ${it.message}") }
    }

    fun cancel(id: Int) {
        runCatching { manager.cancel(id) }
    }

    private fun serviceIntent(id: String, action: String): PendingIntent {
        val intent = Intent(context, DownloadForegroundService::class.java).apply {
            this.action = action
            putExtra(DownloadForegroundService.EXTRA_ID, id)
        }
        return PendingIntent.getService(context, (id + action).hashCode(), intent, pendingIntentFlags())
    }

    private fun pendingIntentFlags(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

    companion object {
        const val CHANNEL_ID = "aurora_downloads"
        private const val TAG = "DownloadNotifications"

        fun notificationId(downloadId: String): Int = downloadId.hashCode()
    }
}
