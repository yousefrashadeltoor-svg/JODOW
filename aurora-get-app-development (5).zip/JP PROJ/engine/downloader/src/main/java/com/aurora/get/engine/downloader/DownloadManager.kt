package com.aurora.get.engine.downloader

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.aurora.get.core.common.ApplicationScope
import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.common.FileNames
import com.aurora.get.core.common.LinkRefresher
import com.aurora.get.core.common.MediaKind
import com.aurora.get.core.database.DownloadDao
import com.aurora.get.core.database.DownloadEntity
import com.aurora.get.core.database.HistoryDao
import com.aurora.get.core.database.HistoryEntity
import com.aurora.get.core.database.SegmentDao
import com.aurora.get.core.network.RemoteSizeResolver
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Owns the whole download lifecycle: queueing, priorities, pause/resume, retry,
 * duplicate detection, MediaStore publishing and the history.
 */
@Singleton
class DownloadManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val downloadDao: DownloadDao,
    private val segmentDao: SegmentDao,
    private val historyDao: HistoryDao,
    private val downloader: SegmentedDownloader,
    private val sizeResolver: RemoteSizeResolver,
    private val refresher: LinkRefresher,
    @ApplicationScope private val scope: CoroutineScope
) {

    private val runMutex = Mutex()
    private val activeJobs = mutableMapOf<String, kotlinx.coroutines.Job>()

    val downloads: Flow<List<DownloadEntity>> = downloadDao.observeAll()

    fun observeByStatus(status: String): Flow<List<DownloadEntity>> = downloadDao.observeByStatus(status)

    /** Queues a new download. Duplicate URLs are rejected. */
    suspend fun enqueue(request: DownloadRequest): String? {
        val existing = downloadDao.countByUrl(request.url)
        if (existing > 0) {
            AuroraLog.i(TAG, "duplicate download skipped: ${request.url}")
            return null
        }
        val dir = destinationDirFor(request.kind)
        val fileName = FileNames.uniqueFileName(dir, request.fileName)
        val entity = DownloadEntity(
            id = request.id,
            url = request.url,
            title = request.title,
            fileName = fileName,
            mimeType = request.mimeType,
            kind = request.kind.name,
            quality = request.quality,
            codec = request.codec,
            width = request.width,
            height = request.height,
            fps = request.fps,
            totalBytes = request.totalBytes,
            status = DownloadStatus.QUEUED.name,
            destinationDir = dir.absolutePath,
            referer = request.referer,
            userAgent = request.userAgent,
            headersJson = request.headers.entries.joinToString("\n") { "${it.key}: ${it.value}" },
            thumbnailUrl = request.thumbnailUrl,
            priority = request.priority,
            sourceId = request.sourceId,
            playlistItemId = request.playlistItemId
        )
        downloadDao.upsert(entity)
        return entity.id
    }

    suspend fun pause(id: String) {
        activeJobs[id]?.cancel()
        activeJobs.remove(id)
        downloadDao.setStatus(id, DownloadStatus.PAUSED.name)
    }

    suspend fun resume(id: String) {
        downloadDao.setStatus(id, DownloadStatus.QUEUED.name)
        scope.launch { runDownload(id) }
    }

    suspend fun cancel(id: String) {
        activeJobs[id]?.cancel()
        activeJobs.remove(id)
        downloadDao.setStatus(id, DownloadStatus.CANCELLED.name)
    }

    suspend fun retry(id: String) {
        downloadDao.setStatus(id, DownloadStatus.QUEUED.name)
        scope.launch { runDownload(id) }
    }

    suspend fun delete(id: String, deleteFile: Boolean) {
        activeJobs[id]?.cancel()
        activeJobs.remove(id)
        val entity = downloadDao.findById(id)
        if (deleteFile && entity != null) {
            runCatching { File(entity.destinationDir, entity.fileName).delete() }
        }
        segmentDao.clear(id)
        downloadDao.delete(id)
    }

    suspend fun setPriority(id: String, priority: Int) = downloadDao.setPriority(id, priority)

    /** Downloads one entry. Safe to call from the service, a worker or the UI. */
    suspend fun runDownload(id: String): Boolean = runMutex.withLock {
        val entity = downloadDao.findById(id) ?: return@withLock false
        if (entity.status == DownloadStatus.COMPLETED.name) return@withLock true

        val dir = File(entity.destinationDir)
        dir.mkdirs()
        val file = File(dir, entity.fileName)

        var url = entity.url
        var totalBytes = entity.totalBytes
        var supportsRanges = true
        var etag = entity.etag
        var lastModified = entity.lastModified

        // Resolve the real size + range support when it is not known yet.
        if (totalBytes == null || etag == null) {
            val probe = sizeResolver.resolve(url, parseHeaders(entity.headersJson))
            totalBytes = probe.bytes
            supportsRanges = probe.acceptsRanges
            etag = probe.etag
            lastModified = probe.lastModified
            downloadDao.setTotalBytes(id, probe.bytes)
        }

        val request = DownloadRequest(
            id = entity.id,
            url = url,
            title = entity.title,
            fileName = entity.fileName,
            destinationDir = dir,
            kind = runCatching { MediaKind.valueOf(entity.kind) }.getOrDefault(MediaKind.UNKNOWN),
            headers = parseHeaders(entity.headersJson),
            referer = entity.referer,
            userAgent = entity.userAgent,
            totalBytes = totalBytes,
            mimeType = entity.mimeType,
            quality = entity.quality,
            codec = entity.codec,
            width = entity.width,
            height = entity.height,
            fps = entity.fps,
            thumbnailUrl = entity.thumbnailUrl,
            priority = entity.priority,
            sourceId = entity.sourceId,
            playlistItemId = entity.playlistItemId
        )

        downloadDao.setStatus(id, DownloadStatus.RUNNING.name)
        var lastPersist = 0L
        val outcome = downloader.download(
            request = request,
            file = file,
            totalBytes = totalBytes,
            supportsRanges = supportsRanges,
            etag = etag,
            lastModified = lastModified,
            scope = scope
        ) { progress ->
            val now = System.currentTimeMillis()
            if (now - lastPersist > 800) {
                lastPersist = now
                downloadDao.setProgress(id, progress.downloadedBytes)
            }
        }

        when (outcome) {
            is DownloadOutcome.Completed -> {
                downloadDao.setProgress(id, outcome.bytes)
                downloadDao.setStatus(id, DownloadStatus.COMPLETED.name)
                publishToMediaStore(entity, file)
                historyDao.insert(
                    HistoryEntity(
                        id = entity.id,
                        url = entity.url,
                        title = entity.title,
                        kind = entity.kind,
                        timestamp = System.currentTimeMillis()
                    )
                )
                true
            }

            is DownloadOutcome.Paused -> {
                downloadDao.setStatus(id, DownloadStatus.PAUSED.name)
                false
            }

            is DownloadOutcome.Cancelled -> {
                downloadDao.setStatus(id, DownloadStatus.CANCELLED.name)
                false
            }

            is DownloadOutcome.Failed -> {
                // The link may have expired: renew it once before giving up.
                val refreshed = if (isExpiryError(outcome.reason)) {
                    runCatching { refresher.refresh(url) }.getOrNull()
                } else null
                if (refreshed != null && refreshed != url) {
                    AuroraLog.i(TAG, "renewed expired url for $id")
                    downloadDao.upsert(entity.copy(url = refreshed, totalBytes = null))
                    runDownload(id)
                } else {
                    downloadDao.setStatus(id, DownloadStatus.FAILED.name)
                    downloadDao.upsert(entity.copy(error = outcome.reason, totalBytes = totalBytes))
                    false
                }
            }
        }
    }

    private fun isExpiryError(reason: String): Boolean =
        reason.contains("403") || reason.contains("410") || reason.contains("expired")

    fun parseHeaders(raw: String?): Map<String, String> {
        if (raw.isNullOrBlank()) return emptyMap()
        return raw.lineSequence().mapNotNull { line ->
            val idx = line.indexOf(':')
            if (idx <= 0) null else line.substring(0, idx).trim() to line.substring(idx + 1).trim()
        }.toMap()
    }

    /** Where a file of the given kind is stored (app specific dir + MediaStore copy). */
    fun destinationDirFor(kind: MediaKind): File {
        val root = context.getExternalFilesDir(null) ?: context.filesDir
        val sub = when (kind) {
            MediaKind.VIDEO -> "Video"
            MediaKind.AUDIO -> "Audio"
            MediaKind.IMAGE -> "Images"
            MediaKind.ARCHIVE -> "Archives"
            MediaKind.DOCUMENT -> "Documents"
            MediaKind.APK -> "Apps"
            else -> "Files"
        }
        val dir = File(root, sub)
        dir.mkdirs()
        return dir
    }

    /** Makes the downloaded file visible in the gallery / music players. */
    private fun publishToMediaStore(entity: DownloadEntity, file: File) {
        runCatching {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, entity.fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, entity.mimeType ?: guessMime(entity.fileName))
                put(MediaStore.MediaColumns.SIZE, file.length())
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Aurora Get/${entity.kind}")
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                } else {
                    put(MediaStore.MediaColumns.DATA, file.absolutePath)
                }
            }
            val collection = when (entity.kind) {
                MediaKind.VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                MediaKind.AUDIO -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                MediaKind.IMAGE -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                else -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Files.getContentUri("external")
                }
            }
            val uri = context.contentResolver.insert(collection, values) ?: return
            context.contentResolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { input -> input.copyTo(out, 128 * 1024) }
            }
        }.onFailure { AuroraLog.w(TAG, "MediaStore publish failed: ${it.message}") }
    }

    private fun guessMime(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "mp4" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "opus" -> "audio/opus"
        "flac" -> "audio/flac"
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "avif" -> "image/avif"
        "zip" -> "application/zip"
        "pdf" -> "application/pdf"
        "apk" -> "application/vnd.android.package-archive"
        else -> "application/octet-stream"
    }

    companion object {
        private const val TAG = "DownloadManager"

        fun newId(): String = UUID.randomUUID().toString()
    }
}
