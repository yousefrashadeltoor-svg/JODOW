package com.aurora.get.engine.downloader

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.common.ApplicationScope
import com.aurora.get.core.database.DownloadDao
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Foreground service (type `dataSync`) that keeps the download queue alive and shows
 * the rich progress notifications.
 */
@AndroidEntryPoint
class DownloadForegroundService : Service() {

    @Inject lateinit var manager: DownloadManager
    @Inject lateinit var notifications: DownloadNotifications
    @Inject lateinit var downloadDao: DownloadDao
    @Inject @ApplicationScope lateinit var scope: CoroutineScope

    private var observerJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        notifications.ensureChannel()
        startForegroundCompat()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        when (intent?.action) {
            ACTION_PAUSE -> intent.getStringExtra(EXTRA_ID)?.let { scope.launch { manager.pause(it) } }
            ACTION_RESUME -> intent.getStringExtra(EXTRA_ID)?.let { scope.launch { manager.resume(it) } }
            ACTION_CANCEL -> intent.getStringExtra(EXTRA_ID)?.let { scope.launch { manager.cancel(it) } }
            else -> scope.launch { pumpQueue() }
        }
        return START_STICKY
    }

    /** Starts the queued downloads and keeps the notification up to date. */
    private suspend fun pumpQueue() {
        val queued = downloadDao.activeDownloads()
        queued.filter { it.status != DownloadStatus.RUNNING.name }
            .sortedBy { it.priority }
            .forEach { entity ->
                scope.launch { manager.runDownload(entity.id) }
            }
        observerJob?.cancel()
        observerJob = scope.launch {
            downloadDao.observeAll().collectLatest { list ->
                val active = list.firstOrNull { it.status == DownloadStatus.RUNNING.name }
                    ?: list.firstOrNull { it.status == DownloadStatus.QUEUED.name }
                if (active == null) {
                    stopForegroundCompat()
                    stopSelf()
                } else {
                    val total = active.totalBytes
                    val progress = if (total != null && total > 0) {
                        ((active.downloadedBytes * 100) / total).toInt().coerceIn(0, 100)
                    } else 0
                    notifications.notify(
                        notifications.buildProgress(
                            id = active.id,
                            title = active.title,
                            progress = progress,
                            total = total,
                            state = DownloadStatus.valueOf(active.status)
                        ),
                        DownloadNotifications.notificationId(active.id)
                    )
                }
            }
        }
    }

    private fun startForegroundCompat() {
        val notification = notifications.buildProgress(
            id = "service",
            title = "𝒥𝒪 DON",
            progress = 0,
            total = null,
            state = DownloadStatus.RUNNING,
            indeterminate = true
        )
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        }.onFailure { AuroraLog.w(TAG, "startForeground failed: ${it.message}") }
    }

    private fun stopForegroundCompat() {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        }
    }

    override fun onDestroy() {
        observerJob?.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "DownloadService"
        private const val NOTIFICATION_ID = 4711

        const val ACTION_PAUSE = "com.aurora.get.action.PAUSE"
        const val ACTION_RESUME = "com.aurora.get.action.RESUME"
        const val ACTION_CANCEL = "com.aurora.get.action.CANCEL"
        const val EXTRA_ID = "download_id"

        fun start(context: android.content.Context) {
            val intent = Intent(context, DownloadForegroundService::class.java)
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }.onFailure { AuroraLog.w(TAG, "cannot start service: ${it.message}") }
        }

        fun stop(context: android.content.Context) {
            runCatching { context.stopService(Intent(context, DownloadForegroundService::class.java)) }
        }
    }
}
