package com.aurora.get.engine.downloader

import com.aurora.get.core.common.AuroraLog
import com.aurora.get.core.database.SegmentDao
import com.aurora.get.core.database.SegmentEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.max
import kotlin.random.Random

/**
 * The segmented parallel download engine.
 *
 *  * the file is split into chunks (`SegmentPlanner`)
 *  * up to 32 workers download the chunks **in parallel**
 *  * a worker that finishes early immediately picks the next pending chunk
 *    (work stealing) and, if a chunk is unusually slow, it splits it in half
 *  * every chunk writes directly at its own offset in a pre-allocated file
 *  * the chunk state is persisted in Room so a download can resume after a pause,
 *    a network drop, a process death or a reboot
 */
@Singleton
class SegmentedDownloader @Inject constructor(
    private val client: OkHttpClient,
    private val segmentDao: SegmentDao,
) {

    private companion object {
        const val TAG = "SegmentedDownloader"
        const val BUFFER_SIZE = 1024 * 1024      // 1 MiB
        const val PERSIST_EVERY_BYTES = 1024 * 1024
        const val MAX_RETRIES = 5
        const val SLOW_CHUNK_MS = 20_000L
    }

    /**
     * @param supportsRanges false when the server ignores `Range` headers.
     * @param onProgress called on every progress update.
     */
    suspend fun download(
        request: DownloadRequest,
        file: File,
        totalBytes: Long?,
        supportsRanges: Boolean,
        etag: String?,
        lastModified: String?,
        scope: CoroutineScope,
        onProgress: suspend (DownloadProgress) -> Unit
    ): DownloadOutcome = withContext(Dispatchers.IO) {
        request.destinationDir.mkdirs()
        val connections = SegmentPlanner.adaptiveConnections(totalBytes, MAX_CONNECTIONS)
        val chunks = SegmentPlanner.plan(totalBytes, connections)

        val persisted = segmentDao.forDownload(request.id).associateBy { it.index }
        val chunkState = ConcurrentHashMap<Int, Long>()
        chunks.forEach { chunk ->
            val saved = persisted[chunk.index]
            chunkState[chunk.index] = saved?.downloaded?.coerceIn(0, chunk.size) ?: 0L
        }
        // Restore the chunks that were persisted but are not part of the new plan.
        val missing = persisted.filter { entry -> chunks.none { it.index == entry.key } }
        if (missing.isNotEmpty()) {
            AuroraLog.w(TAG, "dropping ${missing.size} stale chunk(s) for ${request.id}")
            missing.forEach { segmentDao.updateProgress(request.id, it.key, it.value.downloaded, "STALE") }
        }

        val alreadyDownloaded = chunkState.values.sum()
        val downloaded = AtomicLong(alreadyDownloaded)

        // Pre-allocate the file so the segments can be written in place.
        if (totalBytes != null && totalBytes > 0) {
            runCatching {
                RandomAccessFile(file, "rw").use { raf -> raf.setLength(totalBytes) }
            }.onFailure { AuroraLog.w(TAG, "pre-allocation failed: ${it.message}") }
        }

        segmentDao.insertAll(
            chunks.map { chunk ->
                SegmentEntity(
                    downloadId = request.id,
                    index = chunk.index,
                    start = chunk.start,
                    end = chunk.end,
                    downloaded = chunkState[chunk.index] ?: 0L,
                    state = "PENDING",
                    etag = etag,
                    lastModified = lastModified
                )
            }
        )

        val pending = ConcurrentLinkedQueue(chunks)
        val effectiveEnds = ConcurrentHashMap<Int, Long>().apply {
            chunks.forEach { put(it.index, it.end) }
        }
        val inFlight = ConcurrentHashMap<Int, Long>()
        val samples = ArrayDeque<Float>()
        var lastSampleAt = System.currentTimeMillis()
        var lastSampleBytes = downloaded.get()
        var activeConnections = 0

        val sampleJob = scope.launch {
            while (isActive) {
                delay(500)
                val now = System.currentTimeMillis()
                val current = downloaded.get()
                val delta = current - lastSampleBytes
                val elapsed = (now - lastSampleAt).coerceAtLeast(1)
                val instant = delta * 1000.0 / elapsed
                samples.addLast(instant.toFloat())
                while (samples.size > 60) samples.removeFirst()
                lastSampleAt = now
                lastSampleBytes = current
                val remaining = totalBytes?.let { (it - current).coerceAtLeast(0) }
                onProgress(
                    DownloadProgress(
                        id = request.id,
                        downloadedBytes = current,
                        totalBytes = totalBytes,
                        bytesPerSecond = instant,
                        activeConnections = activeConnections,
                        samples = samples.toList(),
                        etaSeconds = remaining?.let { if (instant > 1) (it / instant).toLong() else null }
                    )
                )
            }
        }

        suspend fun emit() {
            val current = downloaded.get()
            val elapsed = ((System.currentTimeMillis() - lastSampleAt).coerceAtLeast(1)).toDouble()
            val speed = (current - lastSampleBytes) * 1000.0 / elapsed
            val remaining = totalBytes?.let { (it - current).coerceAtLeast(0) }
            val eta = remaining?.let { if (speed > 1) (it / speed).toLong() else null }
            onProgress(
                DownloadProgress(
                    id = request.id,
                    downloadedBytes = current,
                    totalBytes = totalBytes,
                    bytesPerSecond = speed,
                    activeConnections = activeConnections,
                    samples = samples.toList(),
                    etaSeconds = eta
                )
            )
        }

        if (!supportsRanges) {
            // ---- Fallback: a single resumable connection -------------------------
            sampleJob.cancel()
            return@withContext singleStreamDownload(
                request = request,
                file = file,
                resumeFrom = alreadyDownloaded,
                headers = request.headers,
                onProgress = onProgress
            )
        }

        try {
            coroutineScope {
                repeat(connections) {
                    launch {
                        while (true) {
                            val chunk = pending.poll() ?: break
                            val effectiveEnd = effectiveEnds[chunk.index] ?: chunk.end
                            val already = chunkState[chunk.index] ?: 0L
                            if (already >= effectiveEnd - chunk.start + 1) {
                                continue
                            }
                            inFlight[chunk.index] = System.currentTimeMillis()
                            activeConnections++
                            try {
                                fetchChunk(
                                    request = request,
                                    file = file,
                                    chunk = chunk,
                                    effectiveEnd = effectiveEnd,
                                    already = already,
                                    chunkState = chunkState,
                                    downloaded = downloaded,
                                    etag = etag,
                                    lastModified = lastModified,
                                    onPersist = { index, value ->
                                        segmentDao.updateProgress(request.id, index, value, "RUNNING")
                                    }
                                )
                            } finally {
                                activeConnections--
                                inFlight.remove(chunk.index)
                            }
                        }
                        // Idle worker: try to steal a share of a slow chunk.
                        stealSlowChunk(
                            request = request,
                            file = file,
                            pending = pending,
                            effectiveEnds = effectiveEnds,
                            inFlight = inFlight,
                            chunkState = chunkState,
                            downloaded = downloaded,
                            etag = etag,
                            lastModified = lastModified
                        )
                    }
                }
            }
            sampleJob.cancel()
            val finalBytes = downloaded.get()
            if (totalBytes != null && finalBytes < totalBytes) {
                AuroraLog.w(TAG, "finished with $finalBytes/$totalBytes bytes")
                return@withContext DownloadOutcome.Failed("اكتمل التحميل جزئيًا")
            }
            DownloadOutcome.Completed(file, finalBytes)
        } catch (c: CancellationException) {
            sampleJob.cancel()
            withContext(NonCancellable) { persistAll(request.id, chunkState) }
            DownloadOutcome.Cancelled(downloaded.get())
        } catch (t: Throwable) {
            sampleJob.cancel()
            withContext(NonCancellable) { persistAll(request.id, chunkState) }
            DownloadOutcome.Failed(t.message ?: "فشل التحميل", t)
        }
    }

    private suspend fun persistAll(downloadId: String, chunkState: Map<Int, Long>) {
        chunkState.forEach { (index, value) ->
            runCatching { segmentDao.updateProgress(downloadId, index, value, "PAUSED") }
        }
    }

    private suspend fun fetchChunk(
        request: DownloadRequest,
        file: File,
        chunk: Chunk,
        effectiveEnd: Long,
        already: Long,
        chunkState: ConcurrentHashMap<Int, Long>,
        downloaded: AtomicLong,
        etag: String?,
        lastModified: String?,
        onPersist: suspend (Int, Long) -> Unit
    ) {
        var attempt = 0
        var current = already
        while (attempt <= MAX_RETRIES) {
            val startByte = chunk.start + current
            if (startByte > effectiveEnd) return
            val builder = Request.Builder()
                .url(request.url)
                .header("Range", "bytes=$startByte-$effectiveEnd")
            request.headers.forEach { (k, v) -> builder.header(k, v) }
            request.referer?.let { builder.header("Referer", it) }
            request.userAgent?.let { builder.header("User-Agent", it) }
            if (etag != null) builder.header("If-Range", etag)

            try {
                client.newCall(builder.build()).execute().use { response ->
                    if (response.code == 416) return
                    if (response.code == 403 || response.code == 410) {
                        throw RemoteFileChangedException(etag)
                    }
                    if (!response.isSuccessful) {
                        throw IllegalStateException("HTTP ${response.code}")
                    }
                    // The server ignored our Range header -> the whole file is coming.
                    if (response.code == 200 && chunk.start > 0L) {
                        throw RangeNotSupportedException()
                    }
                    val body = response.body ?: throw IllegalStateException("empty body")
                    RandomAccessFile(file, "rw").use { raf ->
                        raf.seek(startByte)
                        val buffer = ByteArray(BUFFER_SIZE)
                        body.byteStream().use { input ->
                            var read: Int
                            var persisted = current
                            while (input.read(buffer).also { read = it } != -1) {
                                if (read <= 0) continue
                                var written = 0
                                while (written < read) {
                                    val n = raf.write(buffer, written, read - written)
                                    if (n <= 0) throw IllegalStateException("write failed")
                                    written += n
                                }
                                current += read
                                downloaded.addAndGet(read.toLong())
                                chunkState[chunk.index] = current
                                if (current - persisted >= PERSIST_EVERY_BYTES) {
                                    persisted = current
                                    onPersist(chunk.index, current)
                                }
                                if (chunk.start + current > effectiveEnd) break
                            }
                        }
                    }
                    onPersist(chunk.index, current)
                    return
                }
            } catch (range: RangeNotSupportedException) {
                throw range
            } catch (remote: RemoteFileChangedException) {
                throw remote
            } catch (t: Throwable) {
                attempt++
                if (attempt > MAX_RETRIES) throw t
                val backoff = (1000L shl (attempt - 1)).coerceAtMost(30_000L)
                val jitter = Random.nextLong(0, 500)
                AuroraLog.w(TAG, "chunk ${chunk.index} failed ($attempt): ${t.message}, retry in ${backoff + jitter}ms")
                delay(backoff + jitter)
            }
        }
    }

    /**
     * Work stealing: an idle worker takes over the second half of the slowest
     * running chunk so that a single slow segment can never freeze the download.
     */
    private suspend fun stealSlowChunk(
        request: DownloadRequest,
        file: File,
        pending: ConcurrentLinkedQueue<Chunk>,
        effectiveEnds: ConcurrentHashMap<Int, Long>,
        inFlight: ConcurrentHashMap<Int, Long>,
        chunkState: ConcurrentHashMap<Int, Long>,
        downloaded: AtomicLong,
        etag: String?,
        lastModified: String?
    ) {
        val now = System.currentTimeMillis()
        val victim = inFlight.entries
            .filter { now - it.value > SLOW_CHUNK_MS }
            .maxByOrNull { entry ->
                val end = effectiveEnds[entry.key] ?: 0L
                end - (chunkState[entry.key] ?: 0L)
            } ?: return

        val original = pending.firstOrNull { it.index == victim.key }
            ?: return // the chunk is not pending any more, it is already being written
        val downloadedBytes = chunkState[victim.key] ?: 0L
        val split = SegmentPlanner.split(original, downloadedBytes) ?: return
        val (head, tail) = split
        effectiveEnds[victim.key] = head.end
        pending.remove(original)
        pending.add(tail.copy(index = original.index + 10_000))
        AuroraLog.i(TAG, "stealing half of chunk ${original.index} -> new chunk ${tail.index}")
    }

    /** Single connection fallback used when the server does not support ranges. */
    private suspend fun singleStreamDownload(
        request: DownloadRequest,
        file: File,
        resumeFrom: Long,
        headers: Map<String, String>,
        onProgress: suspend (DownloadProgress) -> Unit
    ): DownloadOutcome = withContext(Dispatchers.IO) {
        try {
            val builder = Request.Builder().url(request.url)
            headers.forEach { (k, v) -> builder.header(k, v) }
            request.referer?.let { builder.header("Referer", it) }
            request.userAgent?.let { builder.header("User-Agent", it) }
            if (resumeFrom > 0) builder.header("Range", "bytes=$resumeFrom-")

            client.newCall(builder.build()).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext DownloadOutcome.Failed("HTTP ${response.code}")
                }
                val body = response.body ?: return@withContext DownloadOutcome.Failed("استجابة فارغة")
                var written = resumeFrom
                val started = System.currentTimeMillis()
                val samples = ArrayDeque<Float>()
                var lastBytes = written
                var lastAt = started
                RandomAccessFile(file, "rw").use { raf ->
                    raf.seek(resumeFrom)
                    val buffer = ByteArray(BUFFER_SIZE)
                    body.byteStream().use { input ->
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            raf.write(buffer, 0, read)
                            written += read
                            val now = System.currentTimeMillis()
                            if (now - lastAt >= 500) {
                                val speed = (written - lastBytes) * 1000.0 / (now - lastAt)
                                samples.addLast(speed.toFloat())
                                while (samples.size > 60) samples.removeFirst()
                                lastBytes = written
                                lastAt = now
                                onProgress(
                                    DownloadProgress(
                                        id = request.id,
                                        downloadedBytes = written,
                                        totalBytes = null,
                                        bytesPerSecond = speed,
                                        activeConnections = 1,
                                        samples = samples.toList()
                                    )
                                )
                            }
                        }
                    }
                }
                DownloadOutcome.Completed(file, written)
            }
        } catch (c: CancellationException) {
            DownloadOutcome.Cancelled(resumeFrom)
        } catch (t: Throwable) {
            DownloadOutcome.Failed(t.message ?: "فشل التحميل", t)
        }
    }

    /** Thrown when the server ignores our range requests. */
    class RangeNotSupportedException : RuntimeException("الخادم لا يدعم التحميل المجزأ")

    companion object {
        /** The maximum number of parallel connections. */
        const val MAX_CONNECTIONS = 16
    }
}
