package com.aurora.get.engine.downloader

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.aurora.get.core.common.AuroraLog
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

/**
 * Runs a single download inside WorkManager — used for scheduled downloads and for
 * the "continue after reboot" flow.
 */
@HiltWorker
class DownloadWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val manager: DownloadManager,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val id = inputData.getString(KEY_ID) ?: return Result.failure()
        val success = manager.runDownload(id)
        return if (success) Result.success(workDataOf(KEY_ID to id)) else Result.retry()
    }

    companion object {
        const val KEY_ID = "download_id"
    }
}

/**
 * Restarts every interrupted download after a reboot or an app update.
 */
@HiltWorker
class ResumeDownloadsWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val manager: DownloadManager,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        DownloadForegroundService.start(applicationContext)
        return Result.success()
    }
}

/**
 * Restarts the download queue after a reboot or an app update.
 */
class BootCompletedReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: android.content.Context, intent: android.content.Intent) {
        if (intent.action != android.content.Intent.ACTION_BOOT_COMPLETED &&
            intent.action != android.content.Intent.ACTION_MY_PACKAGE_REPLACED
        ) return
        AuroraLog.i("BootReceiver", "restarting the download queue")
        DownloadForegroundService.start(context)
    }
}
