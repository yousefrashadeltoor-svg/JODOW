package com.aurora.get.core.database

import android.content.Context
import androidx.work.WorkManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AuroraDatabase = AuroraDatabase(context)

    @Provides
    fun provideDownloadDao(db: AuroraDatabase): DownloadDao = db.downloadDao

    @Provides
    fun provideSegmentDao(db: AuroraDatabase): SegmentDao = db.segmentDao

    @Provides
    fun provideAnalysisCacheDao(db: AuroraDatabase): AnalysisCacheDao = db.analysisCacheDao

    @Provides
    fun provideHistoryDao(db: AuroraDatabase): HistoryDao = db.historyDao

    @Provides
    fun provideJodonDao(db: AuroraDatabase): JodonDao = db.jodonDao

    @Provides
    @Singleton
    fun provideWorkManager(@ApplicationContext context: Context): WorkManager = WorkManager.getInstance(context)
}
