package com.aurora.get.core.database

import kotlinx.serialization.Serializable

@Serializable
data class DownloadEntity(
    val id: String,
    val url: String,
    val title: String,
    val fileName: String,
    val mimeType: String? = null,
    val kind: String,
    val quality: String? = null,
    val codec: String? = null,
    val width: Int? = null,
    val height: Int? = null,
    val fps: Int? = null,
    val totalBytes: Long? = null,
    val downloadedBytes: Long = 0L,
    val status: String = "QUEUED",
    val error: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val destinationDir: String,
    val etag: String? = null,
    val lastModified: String? = null,
    val referer: String? = null,
    val userAgent: String? = null,
    val headersJson: String? = null,
    val thumbnailUrl: String? = null,
    val totalSegments: Int = 1,
    val priority: Int = 0,
    val sourceId: String? = null,
    val playlistItemId: String? = null
)

@Serializable
data class SegmentEntity(
    val downloadId: String,
    val index: Int,
    val start: Long,
    val end: Long,
    val downloaded: Long = 0L,
    val state: String = "PENDING",
    val etag: String? = null,
    val lastModified: String? = null
)

@Serializable
data class AnalysisCacheEntity(
    val urlHash: String,
    val url: String,
    val payload: String,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long
)

@Serializable
data class HistoryEntity(
    val id: String,
    val url: String,
    val title: String,
    val kind: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
data class LocalProfile(
    val name: String = "ضيف 𝒥𝒪 DON",
    val handle: String = "@jodon_local",
    val bio: String = "ملف شخصي محلي بالكامل — لا حساب، لا سحابة، لا تتبّع.",
    val avatarPath: String? = null,
    val bannerPath: String? = null
)

@Serializable
data class VideoEntity(
    val id: String,
    val title: String,
    val channel: String,
    val channelId: String,
    val url: String,
    val thumbnailPath: String? = null,
    val duration: Long = 0L,
    val views: Long = 0L,
    val published: Long = System.currentTimeMillis(),
    val description: String = "",
    val tags: List<String> = emptyList(),
    val short: Boolean = false,
    val localPath: String? = null,
    val sizeBytes: Long = 0L,
    val addedAt: Long = System.currentTimeMillis()
)

@Serializable
data class AuroraState(
    val downloads: List<DownloadEntity> = emptyList(),
    val segments: List<SegmentEntity> = emptyList(),
    val analysisCache: List<AnalysisCacheEntity> = emptyList(),
    val history: List<HistoryEntity> = emptyList(),
    val profile: LocalProfile = LocalProfile(),
    val videos: List<VideoEntity> = emptyList(),
    val subscriptions: List<String> = emptyList(),
    val likes: List<String> = emptyList(),
    val watchLater: List<String> = emptyList(),
    val watchHistory: List<String> = emptyList(),
    val searchHistory: List<String> = emptyList()
)
