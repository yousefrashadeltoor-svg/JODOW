package com.aurora.get.core.database

import android.content.Context
import com.aurora.get.core.common.AuroraLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The entire persistence layer of 𝒥𝒪 DON.
 *
 * A single atomic JSON document in app-private storage — no SQL, no Room, no server.
 * Writes are serialized by a [Mutex] and the whole document is replaced atomically
 * (write to a temp file, then rename) so a crash can never corrupt the state.
 */
@Singleton
class AuroraDatabase @Inject constructor(
    private val context: Context
) {
    private val json = Json { prettyPrint = false; ignoreUnknownKeys = true; encodeDefaults = true }
    private val mutex = Mutex()
    private val file: File get() = File(context.filesDir, "jodon-state.json")

    private val _state = MutableStateFlow(load())
    val state: StateFlow<AuroraState> = _state.asStateFlow()

    val downloadDao = DownloadDao(this)
    val segmentDao = SegmentDao(this)
    val analysisCacheDao = AnalysisCacheDao(this)
    val historyDao = HistoryDao(this)
    val jodonDao = JodonDao(this)

    private fun load(): AuroraState = runCatching {
        if (!file.exists()) return AuroraState()
        json.decodeFromString<AuroraState>(file.readText())
    }.getOrElse {
        AuroraLog.w(TAG, "state restore failed, starting clean: ${it.message}")
        AuroraState()
    }

    private suspend fun persist(next: AuroraState) = withContext(Dispatchers.IO) {
        val tmp = File(context.filesDir, "jodon-state.tmp")
        runCatching {
            tmp.writeText(json.encodeToString(AuroraState.serializer(), next))
            if (!tmp.renameTo(file)) {
                file.writeText(tmp.readText())
                tmp.delete()
            }
        }.onFailure { AuroraLog.e(TAG, "state write failed: ${it.message}", it) }
    }

    suspend fun mutate(transform: (AuroraState) -> AuroraState) {
        mutex.withLock {
            val next = transform(_state.value)
            _state.value = next
            persist(next)
        }
    }

    fun snapshot(): AuroraState = _state.value

    /** Full, real on-device export. */
    suspend fun export(): String = mutex.withLock { json.encodeToString(AuroraState.serializer(), _state.value) }

    /** Full, real on-device import. */
    suspend fun import(payload: String): Boolean = runCatching {
        val parsed = json.decodeFromString<AuroraState>(payload)
        mutate { parsed }
        true
    }.getOrElse {
        AuroraLog.w(TAG, "import failed: ${it.message}")
        false
    }

    companion object {
        private const val TAG = "AuroraDatabase"
        const val NAME = "jodon-state.json"
    }
}

class DownloadDao(private val db: AuroraDatabase) {
    fun observeAll(): Flow<List<DownloadEntity>> = db.state.map { it.downloads.sortedWith(compareBy({ it.priority }, { it.createdAt })) }
    fun observeByStatus(status: String): Flow<List<DownloadEntity>> = db.state.map { it.downloads.filter { d -> d.status == status } }
    suspend fun findById(id: String): DownloadEntity? = db.snapshot().downloads.firstOrNull { it.id == id }
    suspend fun activeDownloads(): List<DownloadEntity> = db.snapshot().downloads.filter {
        it.status == "QUEUED" || it.status == "RUNNING" || it.status == "PAUSED"
    }.sortedBy { it.priority }
    suspend fun countByUrl(url: String): Int = db.snapshot().downloads.count { it.url == url && it.status != "FAILED" }

    suspend fun upsert(download: DownloadEntity) = db.mutate { state ->
        state.copy(downloads = state.downloads.filterNot { it.id == download.id } + download)
    }

    suspend fun update(download: DownloadEntity) = upsert(download)

    suspend fun delete(id: String) = db.mutate { state ->
        state.copy(downloads = state.downloads.filterNot { it.id == id }, segments = state.segments.filterNot { it.downloadId == id })
    }

    suspend fun setStatus(id: String, status: String, now: Long = System.currentTimeMillis()) = db.mutate { state ->
        state.copy(downloads = state.downloads.map { if (it.id == id) it.copy(status = status, updatedAt = now) else it })
    }

    suspend fun setProgress(id: String, bytes: Long, now: Long = System.currentTimeMillis()) = db.mutate { state ->
        state.copy(downloads = state.downloads.map { if (it.id == id) it.copy(downloadedBytes = bytes, updatedAt = now) else it })
    }

    suspend fun setPriority(id: String, priority: Int) = db.mutate { state ->
        state.copy(downloads = state.downloads.map { if (it.id == id) it.copy(priority = priority) else it })
    }

    suspend fun setTotalBytes(id: String, total: Long?) = db.mutate { state ->
        state.copy(downloads = state.downloads.map { if (it.id == id) it.copy(totalBytes = total) else it })
    }
}

class SegmentDao(private val db: AuroraDatabase) {
    suspend fun forDownload(downloadId: String): List<SegmentEntity> =
        db.snapshot().segments.filter { it.downloadId == downloadId }.sortedBy { it.index }

    fun observeForDownload(downloadId: String): Flow<List<SegmentEntity>> =
        db.state.map { it.segments.filter { s -> s.downloadId == downloadId }.sortedBy { s -> s.index } }

    suspend fun insertAll(segments: List<SegmentEntity>) = db.mutate { state ->
        state.copy(segments = state.segments.filterNot { s -> s.downloadId == segments.firstOrNull()?.downloadId } + segments)
    }

    suspend fun updateProgress(downloadId: String, index: Int, downloaded: Long, state: String) = db.mutate { snapshot ->
        snapshot.copy(segments = snapshot.segments.map {
            if (it.downloadId == downloadId && it.index == index) it.copy(downloaded = downloaded, state = state) else it
        })
    }

    suspend fun clear(downloadId: String) = db.mutate { state ->
        state.copy(segments = state.segments.filterNot { it.downloadId == downloadId })
    }
}

class AnalysisCacheDao(private val db: AuroraDatabase) {
    suspend fun get(hash: String, now: Long = System.currentTimeMillis()): AnalysisCacheEntity? =
        db.snapshot().analysisCache.firstOrNull { it.urlHash == hash && it.expiresAt > now }

    suspend fun put(entity: AnalysisCacheEntity) = db.mutate { state ->
        state.copy(analysisCache = state.analysisCache.filterNot { it.urlHash == entity.urlHash } + entity)
    }

    suspend fun purgeExpired(now: Long = System.currentTimeMillis()) = db.mutate { state ->
        state.copy(analysisCache = state.analysisCache.filter { it.expiresAt > now })
    }
}

class HistoryDao(private val db: AuroraDatabase) {
    fun observeRecent(limit: Int = 30): Flow<List<HistoryEntity>> =
        db.state.map { it.history.sortedByDescending { h -> h.timestamp }.take(limit) }

    suspend fun insert(entity: HistoryEntity) = db.mutate { state ->
        state.copy(history = (listOf(entity) + state.history).take(500))
    }

    suspend fun clear() = db.mutate { it.copy(history = emptyList()) }
}

/** JO DON local platform persistence. */
class JodonDao(private val db: AuroraDatabase) {
    fun observeVideos(): Flow<List<VideoEntity>> = db.state.map { it.videos.sortedByDescending { v -> v.addedAt } }
    fun observeProfile(): Flow<LocalProfile> = db.state.map { it.profile }
    fun observeSubscriptions(): Flow<List<String>> = db.state.map { it.subscriptions }
    fun observeWatchHistory(): Flow<List<String>> = db.state.map { it.watchHistory }
    fun observeSearchHistory(): Flow<List<String>> = db.state.map { it.searchHistory }
    fun observeLikes(): Flow<List<String>> = db.state.map { it.likes }
    fun observeWatchLater(): Flow<List<String>> = db.state.map { it.watchLater }

    suspend fun addVideo(video: VideoEntity) = db.mutate { state ->
        state.copy(videos = state.videos.filterNot { it.id == video.id } + video)
    }

    suspend fun removeVideo(id: String) = db.mutate { state ->
        state.copy(videos = state.videos.filterNot { it.id == id })
    }

    suspend fun setProfile(profile: LocalProfile) = db.mutate { it.copy(profile = profile) }

    suspend fun toggleSubscription(channelId: String) = db.mutate { state ->
        state.copy(subscriptions = if (channelId in state.subscriptions) state.subscriptions - channelId else state.subscriptions + channelId)
    }

    suspend fun toggleLike(id: String) = db.mutate { state ->
        state.copy(likes = if (id in state.likes) state.likes - id else state.likes + id)
    }

    suspend fun toggleWatchLater(id: String) = db.mutate { state ->
        state.copy(watchLater = if (id in state.watchLater) state.watchLater - id else state.watchLater + id)
    }

    suspend fun recordWatch(id: String) = db.mutate { state ->
        state.copy(watchHistory = (listOf(id) + state.watchHistory.filterNot { it == id }).take(300))
    }

    suspend fun recordSearch(query: String) = db.mutate { state ->
        state.copy(searchHistory = (listOf(query) + state.searchHistory.filterNot { it == query }).take(30))
    }
}
