package com.aurora.get.core.designsystem.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.boundsInParent
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.unit.dp
import com.aurora.get.core.designsystem.motion.AuroraMotion
import com.aurora.get.core.designsystem.theme.AuroraTheme
import kotlin.math.floor

/** One entry of the floating dock. */
data class AuroraDockItem(
    val label: String,
    val icon: @Composable () -> Unit
)

/**
 * The floating glass dock with a morphing indicator (not a Material navigation bar).
 */
@Composable
fun AuroraDock(
    items: List<AuroraDockItem>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    val haptics = LocalHapticFeedback.current
    val bounds = remember { mutableStateMapOf<Int, Rect>() }
    val animatedIndex by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = AuroraMotion.bouncy,
        label = "dockIndicator"
    )

    GlassSurface(
        modifier = modifier.fillMaxWidth(),
        shape = AuroraTheme.shapes.pill,
        elevation = 22.dp,
        borderWidth = 1.dp
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(74.dp)
                .drawBehind {
                    if (bounds.isEmpty()) return@drawBehind
                    val maxIndex = bounds.keys.maxOrNull() ?: return@drawBehind
                    val low = floor(animatedIndex).toInt().coerceIn(0, maxIndex)
                    val high = (low + 1).coerceAtMost(maxIndex)
                    val from = bounds[low] ?: return@drawBehind
                    val to = bounds[high] ?: from
                    val f = (animatedIndex - low).coerceIn(0f, 1f)
                    val left = from.left + (to.left - from.left) * f
                    val right = from.right + (to.right - from.right) * f
                    val top = from.top + (to.top - from.top) * f
                    val bottom = from.bottom + (to.bottom - from.bottom) * f
                    val rect = Rect(left, top, right, bottom)
                    drawRoundRect(
                        brush = Brush.linearGradient(colors.accentSweep),
                        topLeft = Offset(rect.left, rect.top),
                        size = Size(rect.width, rect.height),
                        cornerRadius = CornerRadius(rect.height / 2f, rect.height / 2f)
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                items.forEachIndexed { index, item ->
                    val selected = index == selectedIndex
                    val interactionSource = remember { MutableInteractionSource() }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                        modifier = Modifier
                            .onGloballyPositioned { bounds[index] = it.boundsInParent() }
                            .clickable(
                                interactionSource = interactionSource,
                                indication = null
                            ) {
                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onSelect(index)
                            }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
                            item.icon()
                        }
                        BasicText(
                            text = item.label,
                            style = typography.caption.copy(
                                color = if (selected) Color.White else colors.onBackgroundMuted,
                                fontSize = typography.caption.fontSize * 0.92f
                            )
                        )
                    }
                }
            }
        }
    }
}
