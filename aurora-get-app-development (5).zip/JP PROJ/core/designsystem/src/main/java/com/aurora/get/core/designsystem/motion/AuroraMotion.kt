package com.aurora.get.core.designsystem.motion

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring
import androidx.compose.ui.unit.IntOffset

/**
 * Every motion in Aurora Get is spring based. The few tweens that exist are limited to
 * non-interactive transitions (progress fades).
 */
object AuroraMotion {

    /** Fast, slightly under-damped: used for press feedback and badges. */
    val snappy: SpringSpec<Float> = spring(dampingRatio = 0.72f, stiffness = 900f)

    /** The signature Gemini-like soft spring. */
    val gentle: SpringSpec<Float> = spring(dampingRatio = 0.86f, stiffness = 280f)

    /** For sheets and big surfaces. */
    val smooth: SpringSpec<Float> = spring(dampingRatio = 0.94f, stiffness = 190f)

    /** Slight overshoot for playful elements (orbs, dock indicator). */
    val bouncy: SpringSpec<Float> = spring(dampingRatio = 0.58f, stiffness = 460f)

    val snappyOffset: SpringSpec<IntOffset> = spring(dampingRatio = 0.8f, stiffness = 700f)
    val gentleOffset: SpringSpec<IntOffset> = spring(dampingRatio = 0.9f, stiffness = 260f)

    /** The only easing used in the system — for pure opacity fades. */
    val fade: Easing = CubicBezierEasing(0.2f, 0f, 0f, 1f)

    /** Stagger delay helper for list entrances. */
    fun stagger(index: Int, step: Int = 42): Long = (index.coerceAtMost(12) * step).toLong()
}
