package com.aurora.get.core.designsystem.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

/**
 * Superellipse (squircle) shape — the softest possible corner language used everywhere
 * in Aurora Get. `n = 4.2` gives the signature "squircle" silhouette.
 */
class SquircleShape(
    private val exponent: Double = 4.2,
    private val steps: Int = 64
) : Shape {

    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: Density
    ): Outline = Outline.Generic(buildPath(size))

    private fun buildPath(size: Size): Path {
        val w = size.width
        val h = size.height
        val a = w / 2.0
        val b = h / 2.0
        val path = Path()
        for (i in 0..steps) {
            val t = (i.toDouble() / steps) * 2.0 * Math.PI
            val cos = Math.cos(t)
            val sin = Math.sin(t)
            val x = a * Math.signum(cos) * Math.pow(Math.abs(cos), 2.0 / exponent)
            val y = b * Math.signum(sin) * Math.pow(Math.abs(sin), 2.0 / exponent)
            val px = (x + a).toFloat()
            val py = (y + b).toFloat()
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        return path
    }
}

@Immutable
data class AuroraShapes(
    val extraSmall: Shape,
    val small: Shape,
    val medium: Shape,
    val large: Shape,
    val extraLarge: Shape,
    val pill: Shape,
    val sheet: Shape
) {
    companion object {
        val Default = AuroraShapes(
            extraSmall = SquircleShape(exponent = 4.2, steps = 32),
            small = SquircleShape(exponent = 4.2, steps = 40),
            medium = SquircleShape(exponent = 4.2, steps = 48),
            large = SquircleShape(exponent = 4.2, steps = 64),
            extraLarge = SquircleShape(exponent = 4.2, steps = 72),
            pill = SquircleShape(exponent = 4.2, steps = 48),
            sheet = SquircleShape(exponent = 4.2, steps = 72)
        )
    }
}

/** Soft multi-layer shadow used by every glass surface. */
fun DrawScope.auroraShadow(
    shape: Shape,
    elevation: Dp,
    color: androidx.compose.ui.graphics.Color
) {
    drawShadow(elevation = elevation, shape = shape, ambientColor = color, spotColor = color)
}
