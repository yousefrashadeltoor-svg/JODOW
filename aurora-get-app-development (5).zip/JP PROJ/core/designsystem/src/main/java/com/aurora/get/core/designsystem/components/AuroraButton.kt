package com.aurora.get.core.designsystem.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aurora.get.core.designsystem.motion.AuroraMotion
import com.aurora.get.core.designsystem.theme.AuroraTheme

enum class AuroraButtonStyle { Primary, Secondary, Ghost, Danger }

/**
 * Aurora's own button. It is **not** a Material button: press feedback is a spring
 * scale plus a custom radial glow (there is no Material ripple anywhere in the app).
 */
@Composable
fun AuroraButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: AuroraButtonStyle = AuroraButtonStyle.Primary,
    icon: (@Composable () -> Unit)? = null,
    enabled: Boolean = true,
    minHeight: Dp = 52.dp,
    shape: Shape? = null
) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    val resolvedShape = shape ?: AuroraTheme.shapes.pill
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val haptics = LocalHapticFeedback.current

    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.965f else 1f,
        animationSpec = AuroraMotion.snappy,
        label = "buttonScale"
    )
    val glow by animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = AuroraMotion.snappy,
        label = "buttonGlow"
    )

    val containerBrush = when (style) {
        AuroraButtonStyle.Primary -> Brush.linearGradient(colors.accentSweep)
        AuroraButtonStyle.Secondary -> Brush.linearGradient(
            listOf(colors.primary.copy(alpha = 0.22f), colors.secondary.copy(alpha = 0.18f))
        )
        AuroraButtonStyle.Ghost -> Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
        AuroraButtonStyle.Danger -> Brush.linearGradient(listOf(colors.error, colors.error.copy(alpha = 0.75f)))
    }
    val contentColor = when (style) {
        AuroraButtonStyle.Primary -> Color.White
        AuroraButtonStyle.Danger -> Color.White
        else -> colors.onBackground
    }
    val animatedContent by animateColorAsState(
        targetValue = if (enabled) contentColor else colors.onBackgroundMuted.copy(alpha = 0.5f),
        label = "buttonContent"
    )

    Box(
        modifier = modifier
            .scale(scale)
            .defaultMinSize(minHeight = minHeight)
            .clip(resolvedShape)
            .background(containerBrush)
            .then(
                when (style) {
                    AuroraButtonStyle.Ghost -> Modifier.border(1.dp, Brush.linearGradient(colors.accentSweep), resolvedShape)
                    AuroraButtonStyle.Secondary -> Modifier.border(1.dp, colors.glassStroke, resolvedShape)
                    else -> Modifier
                }
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled
            ) {
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        if (glow > 0f) {
            Box(
                Modifier
                    .matchParentSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color.White.copy(alpha = 0.22f * glow), Color.Transparent),
                            radius = 420f
                        )
                    )
            )
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp)
        ) {
            if (icon != null) {
                Box(Modifier.size(20.dp), contentAlignment = Alignment.Center) { icon() }
            }
            BasicText(
                text = text,
                style = typography.label.copy(
                    color = animatedContent,
                    fontSize = typography.label.fontSize * 1.06f,
                    textAlign = TextAlign.Center
                )
            )
        }
    }
}

/** A circular glass icon button with spring press feedback. */
@Composable
fun AuroraIconButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    contentDescription: String? = null,
    size: Dp = 44.dp,
    tint: Color? = null,
    enabled: Boolean = true,
    content: @Composable () -> Unit
) {
    val colors = AuroraTheme.colors
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val haptics = LocalHapticFeedback.current
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.88f else 1f,
        animationSpec = AuroraMotion.snappy,
        label = "iconButtonScale"
    )

    Box(
        modifier = modifier
            .size(size)
            .scale(scale)
            .clip(AuroraTheme.shapes.pill)
            .background(tint ?: colors.glassTint)
            .border(1.dp, colors.glassStroke, AuroraTheme.shapes.pill)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled
            ) {
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}
