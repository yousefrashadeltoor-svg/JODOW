package com.aurora.get.core.designsystem.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.unit.dp
import com.aurora.get.core.designsystem.motion.AuroraMotion
import com.aurora.get.core.designsystem.theme.AuroraTheme

/** A circular progress indicator with the Aurora sweep gradient. */
@Composable
fun AuroraProgressRing(
    progress: Float,
    modifier: Modifier = Modifier,
    size: Dp = 56.dp,
    strokeWidth: Dp = 5.dp,
    trackAlpha: Float = 0.14f
) {
    val colors = AuroraTheme.colors
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = AuroraMotion.gentle,
        label = "ringProgress"
    )
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round)
            val inset = strokeWidth.toPx() / 2f
            drawArc(
                color = colors.onBackground.copy(alpha = trackAlpha),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(this.size.width - inset * 2, this.size.height - inset * 2),
                style = stroke
            )
            if (animated > 0f) {
                drawArc(
                    brush = Brush.sweepGradient(colors.accentSweep + colors.accentSweep.first()),
                    startAngle = -90f,
                    sweepAngle = 360f * animated,
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = Size(this.size.width - inset * 2, this.size.height - inset * 2),
                    style = stroke
                )
            }
        }
    }
}

/** A thin horizontal progress bar with a moving highlight. */
@Composable
fun AuroraProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    height: Dp = 8.dp,
    indeterminate: Boolean = false
) {
    val colors = AuroraTheme.colors
    val transition = rememberInfiniteTransition(label = "progressBar")
    val shift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
        label = "progressShift"
    )
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = AuroraMotion.gentle,
        label = "progressBarValue"
    )
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(AuroraTheme.shapes.pill)
            .background(colors.onBackground.copy(alpha = 0.12f))
    ) {
        val fraction = if (indeterminate) shift else animated
        Box(
            Modifier
                .fillMaxWidth(fraction.coerceIn(0.02f, 1f))
                .fillMaxHeight()
                .clip(AuroraTheme.shapes.pill)
                .background(Brush.linearGradient(colors.accentSweep))
        )
    }
}

/** A live speed graph (sparkline). */
@Composable
fun AuroraSparkline(
    samples: List<Float>,
    modifier: Modifier = Modifier,
    lineColor: Color? = null
) {
    val colors = AuroraTheme.colors
    val stroke = lineColor ?: colors.primary
    Canvas(modifier) {
        if (samples.size < 2) return@Canvas
        val max = samples.maxOrNull()?.takeIf { it > 0f } ?: 1f
        val stepX = size.width / (samples.size - 1)
        val path = androidx.compose.ui.graphics.Path()
        samples.forEachIndexed { index, value ->
            val x = index * stepX
            val y = size.height - (value / max) * size.height
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
            path = path,
            brush = Brush.horizontalGradient(listOf(stroke, colors.tertiary)),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}

/** Skeleton placeholder with the unified Aurora shimmer. */
@Composable
fun AuroraShimmer(
    modifier: Modifier = Modifier,
    shape: androidx.compose.ui.graphics.Shape? = null,
    active: Boolean = true
) {
    val colors = AuroraTheme.colors
    val transition = rememberInfiniteTransition(label = "shimmer")
    val shift by transition.animateFloat(
        initialValue = -1.6f,
        targetValue = 1.6f,
        animationSpec = infiniteRepeatable(tween(1250, easing = LinearEasing), RepeatMode.Reverse),
        label = "shimmerShift"
    )
    val resolved = shape ?: AuroraTheme.shapes.medium
    Box(
        modifier
            .clip(resolved)
            .background(colors.onBackground.copy(alpha = 0.08f))
    ) {
        if (active) {
            Box(
                Modifier
                    .fillMaxSize()
                    .offset { IntOffset((shift * 520f).roundToInt(), 0) }
                    .fillMaxWidth(0.42f)
                    .fillMaxHeight()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color.Transparent,
                                colors.onBackground.copy(alpha = 0.12f),
                                Color.Transparent
                            )
                        )
                    )
            )
        }
    }
}

/** A soft, pulsing orb used for the empty state. */
@Composable
fun AuroraOrb(
    modifier: Modifier = Modifier,
    colors: List<Color>? = null,
    radius: Dp = 120.dp
) {
    val palette = colors ?: AuroraTheme.colors.accentSweep
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 0.86f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(3400, easing = LinearEasing), RepeatMode.Reverse),
        label = "orbPulse"
    )
    Canvas(modifier.size(radius * 2)) {
        drawCircle(
            brush = Brush.radialGradient(
                colors = palette.map { it.copy(alpha = 0.55f) } + listOf(Color.Transparent),
                center = Offset(size.width / 2f, size.height / 2f),
                radius = size.minDimension / 2f
            ),
            radius = size.minDimension / 2f * pulse
        )
    }
}
