package com.aurora.get.core.designsystem.shaders

import android.graphics.RuntimeShader
import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import com.aurora.get.core.designsystem.theme.AuroraTheme

/**
 * The animated mesh gradient of Aurora Get.
 *
 * On Android 13+ it is rendered by an AGSL shader (real per-pixel animated blobs).
 * On older devices the very same look is approximated with layered radial gradients.
 */
private const val AGSL_SOURCE = """
uniform shader composable;
uniform float2 resolution;
uniform float time;
uniform float4 colorA;
uniform float4 colorB;
uniform float4 colorC;

float blob(float2 p, float2 c, float r) {
    float d = length(p - c);
    return smoothstep(r, 0.0, d);
}

half4 main(float2 coord) {
    float2 p = coord / max(resolution, float2(1.0));
    float t = time * 0.12;

    float2 c1 = float2(0.22 + 0.10 * sin(t), 0.78 + 0.08 * cos(t * 1.3));
    float2 c2 = float2(0.76 + 0.09 * cos(t * 0.9), 0.28 + 0.10 * sin(t * 1.1));
    float2 c3 = float2(0.50 + 0.08 * sin(t * 1.7), 0.54 + 0.09 * cos(t * 0.7));

    float b1 = blob(p, c1, 0.70);
    float b2 = blob(p, c2, 0.64);
    float b3 = blob(p, c3, 0.56);

    float3 col = colorA.rgb * b1 + colorB.rgb * b2 + colorC.rgb * b3;
    float total = max(0.001, b1 + b2 + b3);
    col = col / total;

    float vignette = 1.0 - 0.38 * length(p - float2(0.5));
    return half4(half3(col * vignette), 1.0);
}
"""

@Composable
fun AuroraMeshBackground(
    modifier: Modifier = Modifier,
    colors: List<Color>? = null,
    intensity: Float = 1f
) {
    val palette = (colors ?: AuroraTheme.colors.accentSweep).take(3)
    val density = LocalDensity.current

    val transition = rememberInfiniteTransition(label = "meshGradient")
    val time by transition.animateFloat(
        initialValue = 0f,
        targetValue = 60f,
        animationSpec = infiniteRepeatable(tween(60000, easing = LinearEasing), RepeatMode.Restart),
        label = "meshTime"
    )

    val runtimeShader = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            runCatching { RuntimeShader(AGSL_SOURCE) }.getOrNull()
        } else null
    }

    val fallbackBrush = remember(palette) {
        Brush.radialGradient(
            colors = palette.map { it.copy(alpha = 0.42f * intensity) } + listOf(Color.Transparent),
            radius = 1400f
        )
    }

    BoxWithConstraints(modifier.fillMaxSize()) {
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }

        LaunchedEffect(runtimeShader, palette) {
            val shader = runtimeShader ?: return@LaunchedEffect
            shader.setColorUniform("colorA", palette[0].toArgb())
            shader.setColorUniform("colorB", palette[1].toArgb())
            shader.setColorUniform("colorC", palette[2].toArgb())
        }

        LaunchedEffect(runtimeShader, time, widthPx, heightPx) {
            val shader = runtimeShader ?: return@LaunchedEffect
            shader.setFloatUniform("time", time)
            shader.setFloatUniform("resolution", widthPx, heightPx)
        }

        val brush: Brush = remember(runtimeShader) {
            if (runtimeShader != null) ShaderBrush(runtimeShader) else fallbackBrush
        }

        Box(Modifier.fillMaxSize().background(brush))
    }
}
