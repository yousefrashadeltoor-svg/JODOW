package com.aurora.get.core.designsystem.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.aurora.get.core.designsystem.motion.AuroraMotion
import com.aurora.get.core.designsystem.theme.AuroraTheme

/**
 * Aurora's own glass bottom sheet.
 * It is implemented from scratch (no Material `ModalBottomSheet`): a scrim that fades,
 * a sheet that springs in, and a physical drag-to-dismiss gesture.
 */
@Composable
fun GlassBottomSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    title: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = AuroraTheme.colors
    val typography = AuroraTheme.typography
    var dragOffset by remember { mutableFloatStateOf(0f) }

    val sheetProgress by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = AuroraMotion.smooth,
        label = "sheetProgress"
    )
    val scrimAlpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = AuroraMotion.fade,
        label = "sheetScrim"
    )

    LaunchedEffect(visible) { if (visible) dragOffset = 0f }

    Box(modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(colors.scrim.copy(alpha = scrimAlpha))
                .pointerInput(visible) {
                    if (visible) detectTapGestures { onDismiss() }
                }
        )

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .alpha(sheetProgress)
                .pointerInput(visible) {
                    if (visible) {
                        detectVerticalDragGestures(
                            onDragEnd = {
                                if (dragOffset > 140f) onDismiss() else dragOffset = 0f
                            },
                            onVerticalDrag = { _, delta ->
                                dragOffset = (dragOffset + delta).coerceAtLeast(0f)
                            }
                        )
                    }
                }
        ) {
            GlassSurface(
                modifier = Modifier.fillMaxWidth(),
                shape = AuroraTheme.shapes.extraLarge,
                elevation = 26.dp
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp, bottom = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier
                            .size(width = 42.dp, height = 5.dp)
                            .clip(CircleShape)
                            .background(colors.onBackgroundMuted.copy(alpha = 0.5f))
                    )
                    if (title != null) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 22.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            BasicText(text = title, style = typography.title)
                        }
                    }
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) { content() }
                }
            }
        }
    }
}
