package com.aurora.get.core.designsystem.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color

/**
 * The Aurora palette family. Every theme is a set of three accent colours that are
 * mixed into the Gemini-like blue → violet → rose sweep gradient.
 */
enum class AuroraThemeId(val storageKey: String, val displayName: String, val photo: String) {
    AURORA("aurora", "Aurora", "themes/aurora.jpg"),
    OCEAN("ocean", "Ocean", "themes/ocean.jpg"),
    SUNSET("sunset", "Sunset", "themes/sunset.jpg"),
    EMERALD("emerald", "Emerald", "themes/emerald.jpg"),
    MONO("mono", "Mono", "themes/mono.jpg"),
    NEON("neon", "Neon", "themes/neon.jpg"),
    AURORA_LIGHT("aurora-light", "Aurora · Light", "themes/aurora.jpg"),
    OCEAN_LIGHT("ocean-light", "Ocean · Light", "themes/ocean.jpg"),
    SUNSET_LIGHT("sunset-light", "Sunset · Light", "themes/sunset.jpg"),
    EMERALD_LIGHT("emerald-light", "Emerald · Light", "themes/emerald.jpg"),
    MONO_LIGHT("mono-light", "Mono · Light", "themes/mono.jpg"),
    NEON_LIGHT("neon-light", "Neon · Light", "themes/neon.jpg");

    companion object {
        fun fromKey(key: String?): AuroraThemeId =
            entries.firstOrNull { it.storageKey == key } ?: AURORA
    }
}

@Immutable
data class AuroraColors(
    val background: Color,
    val backgroundAlt: Color,
    val onBackground: Color,
    val onBackgroundMuted: Color,
    val primary: Color,
    val secondary: Color,
    val tertiary: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
    val glassTint: Color,
    val glassStroke: Color,
    val scrim: Color,
    val isDark: Boolean
) {
    /** The Gemini style sweep used for glows, gradients and active states. */
    val accentSweep: List<Color> get() = listOf(primary, secondary, tertiary)

    val accentGradient: androidx.compose.ui.graphics.Brush
        get() = androidx.compose.ui.graphics.Brush.linearGradient(accentSweep)
}

object AuroraPalettes {

    // Gemini reference colours: #4285F4 blue, #9B72CB violet, #D96570 rose, #0B0D12 deep dark.
    private val AuroraDark = AuroraColors(
        background = Color(0xFF0B0D12),
        backgroundAlt = Color(0xFF11141C),
        onBackground = Color(0xFFECF1FF),
        onBackgroundMuted = Color(0xFF9AA3B8),
        primary = Color(0xFF4285F4),
        secondary = Color(0xFF9B72CB),
        tertiary = Color(0xFFD96570),
        success = Color(0xFF3ED598),
        warning = Color(0xFFF5B94B),
        error = Color(0xFFF0656B),
        glassTint = Color(0x14FFFFFF),
        glassStroke = Color(0x22FFFFFF),
        scrim = Color(0x99050710),
        isDark = true
    )

    private val AuroraLight = AuroraColors(
        background = Color(0xFFEFF2F9),
        backgroundAlt = Color(0xFFFFFFFF),
        onBackground = Color(0xFF0B0D12),
        onBackgroundMuted = Color(0xFF5A6478),
        primary = Color(0xFF2A6DE0),
        secondary = Color(0xFF7B54B4),
        tertiary = Color(0xFFC25560),
        success = Color(0xFF1F9D6B),
        warning = Color(0xFFB4781A),
        error = Color(0xFFD14349),
        glassTint = Color(0x66FFFFFF),
        glassStroke = Color(0x22000000),
        scrim = Color(0x66050710),
        isDark = false
    )

    private fun dark(
        background: Color,
        backgroundAlt: Color,
        primary: Color,
        secondary: Color,
        tertiary: Color
    ) = AuroraDark.copy(
        background = background,
        backgroundAlt = backgroundAlt,
        primary = primary,
        secondary = secondary,
        tertiary = tertiary
    )

    private fun light(
        background: Color,
        backgroundAlt: Color,
        primary: Color,
        secondary: Color,
        tertiary: Color
    ) = AuroraLight.copy(
        background = background,
        backgroundAlt = backgroundAlt,
        primary = primary,
        secondary = secondary,
        tertiary = tertiary
    )

    fun of(id: AuroraThemeId, dark: Boolean): AuroraColors = when (id) {
        AuroraThemeId.AURORA, AuroraThemeId.AURORA_LIGHT -> if (dark && id != AuroraThemeId.AURORA_LIGHT) AuroraDark else AuroraLight
        AuroraThemeId.OCEAN, AuroraThemeId.OCEAN_LIGHT -> if (dark && id != AuroraThemeId.OCEAN_LIGHT)
            dark(Color(0xFF060E18), Color(0xFF0C1626), Color(0xFF3B82F6), Color(0xFF06B6D4), Color(0xFF67E8F9))
        else
            light(Color(0xFFEDF4FA), Color(0xFFFFFFFF), Color(0xFF2563EB), Color(0xFF0891B2), Color(0xFF0E7490))

        AuroraThemeId.SUNSET, AuroraThemeId.SUNSET_LIGHT -> if (dark && id != AuroraThemeId.SUNSET_LIGHT)
            dark(Color(0xFF14090C), Color(0xFF1F1014), Color(0xFFF97316), Color(0xFFEC4899), Color(0xFFF43F5E))
        else
            light(Color(0xFFFDF2F0), Color(0xFFFFFFFF), Color(0xFFEA580C), Color(0xFFDB2777), Color(0xFFE11D48))

        AuroraThemeId.EMERALD, AuroraThemeId.EMERALD_LIGHT -> if (dark && id != AuroraThemeId.EMERALD_LIGHT)
            dark(Color(0xFF04120D), Color(0xFF0A1C16), Color(0xFF10B981), Color(0xFF34D399), Color(0xFFA3E635))
        else
            light(Color(0xFFEFF8F3), Color(0xFFFFFFFF), Color(0xFF059669), Color(0xFF0D9488), Color(0xFF4D7C0F))

        AuroraThemeId.MONO, AuroraThemeId.MONO_LIGHT -> if (dark && id != AuroraThemeId.MONO_LIGHT)
            dark(Color(0xFF0C0D10), Color(0xFF14161B), Color(0xFFB8BECC), Color(0xFF8E95A3), Color(0xFFD7DBE3))
        else
            light(Color(0xFFF2F3F6), Color(0xFFFFFFFF), Color(0xFF3B4048), Color(0xFF5F6672), Color(0xFF878E9B))

        AuroraThemeId.NEON, AuroraThemeId.NEON_LIGHT -> if (dark && id != AuroraThemeId.NEON_LIGHT)
            dark(Color(0xFF08060F), Color(0xFF100C1C), Color(0xFF22D3EE), Color(0xFFA855F7), Color(0xFFF0ABFC))
        else
            light(Color(0xFFF2EEFC), Color(0xFFFFFFFF), Color(0xFF0891B2), Color(0xFF7C3AED), Color(0xFFA21CAF))
    }
}

/** Real photographic previews shipped in app assets — work fully offline. */
object ThemeAssets {
    fun uriFor(id: AuroraThemeId): String = "file:///android_asset/${id.photo}"

    val all: List<AuroraThemeId> = AuroraThemeId.entries
}
