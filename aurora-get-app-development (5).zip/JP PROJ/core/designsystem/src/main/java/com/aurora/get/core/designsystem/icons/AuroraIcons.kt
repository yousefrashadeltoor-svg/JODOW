package com.aurora.get.core.designsystem.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.unit.dp

/**
 * Aurora Get ships its **own** icon set — no Material Icons anywhere.
 * Every glyph is drawn by hand as an [ImageVector] with a soft duotone silhouette.
 */
object AuroraIcons {

    // --- helpers -----------------------------------------------------------
    private fun icon(name: String, block: PathBuilder.() -> Unit): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(fill = SolidColor(Color.Black)) { block() }
        }.build()

    private fun PathBuilder.circle(cx: Float, cy: Float, r: Float) {
        arcTo(Rect(cx - r, cy - r, cx + r, cy + r), 0f, 360f, false)
    }

    private fun PathBuilder.roundedBox(l: Float, t: Float, r: Float, b: Float, radius: Float) {
        addRoundRect(RoundRect(l, t, r, b, CornerRadius(radius, radius)))
    }

    // --- navigation --------------------------------------------------------
    val Home: ImageVector by lazy {
        icon("Home") {
            moveTo(3f, 11.2f)
            lineTo(12f, 3.5f)
            lineTo(21f, 11.2f)
            lineTo(21f, 20f)
            lineTo(14.4f, 20f)
            lineTo(14.4f, 14f)
            lineTo(9.6f, 14f)
            lineTo(9.6f, 20f)
            lineTo(3f, 20f)
            close()
        }
    }

    val Downloads: ImageVector by lazy {
        icon("Downloads") {
            moveTo(11f, 3f)
            lineTo(13f, 3f)
            lineTo(13f, 12.4f)
            lineTo(17.2f, 8.4f)
            lineTo(18.8f, 10f)
            lineTo(12f, 17f)
            lineTo(5.2f, 10f)
            lineTo(6.8f, 8.4f)
            lineTo(11f, 12.4f)
            close()
            roundedBox(4f, 18.6f, 20f, 21f, 1.2f)
        }
    }

    val Browser: ImageVector by lazy {
        icon("Browser") {
            circle(12f, 12f, 9f)
            roundedBox(10.6f, 2.4f, 13.4f, 21.6f, 1.4f)
            roundedBox(2.4f, 10.6f, 21.6f, 13.4f, 1.4f)
        }
    }

    val Converter: ImageVector by lazy {
        icon("Converter") {
            roundedBox(3f, 5f, 16f, 8.4f, 1.7f)
            moveTo(14f, 6.6f)
            lineTo(18.6f, 6.6f)
            lineTo(18.6f, 11.2f)
            lineTo(20.4f, 9.4f)
            lineTo(21.8f, 10.8f)
            lineTo(16.8f, 15.8f)
            lineTo(11.8f, 10.8f)
            lineTo(13.2f, 9.4f)
            lineTo(13.2f, 8.4f)
            lineTo(14f, 8.4f)
            close()
            roundedBox(8f, 15.6f, 21f, 19f, 1.7f)
        }
    }

    val Compressor: ImageVector by lazy {
        icon("Compressor") {
            moveTo(9f, 3f)
            lineTo(15f, 3f)
            lineTo(15f, 6f)
            lineTo(9f, 6f)
            close()
            moveTo(9f, 18f)
            lineTo(15f, 18f)
            lineTo(15f, 21f)
            lineTo(9f, 21f)
            close()
            moveTo(4f, 10f)
            lineTo(10f, 10f)
            lineTo(10f, 13f)
            lineTo(4f, 13f)
            close()
            moveTo(14f, 10f)
            lineTo(20f, 10f)
            lineTo(20f, 13f)
            lineTo(14f, 13f)
            close()
            roundedBox(11f, 8f, 13f, 16f, 1f)
        }
    }

    val Library: ImageVector by lazy {
        icon("Library") {
            roundedBox(3f, 4f, 9f, 20f, 1.6f)
            roundedBox(11f, 4f, 17f, 20f, 1.6f)
            moveTo(19f, 5f)
            lineTo(21.6f, 5f)
            lineTo(21.6f, 19f)
            lineTo(19f, 19f)
            close()
        }
    }

    val Settings: ImageVector by lazy {
        icon("Settings") {
            roundedBox(3f, 5f, 21f, 7.4f, 1.2f)
            roundedBox(3f, 10.8f, 21f, 13.2f, 1.2f)
            roundedBox(3f, 16.6f, 21f, 19f, 1.2f)
            circle(9f, 6.2f, 2.6f)
            circle(15f, 12f, 2.6f)
            circle(7.5f, 17.8f, 2.6f)
        }
    }

    // --- media kinds -------------------------------------------------------
    val Audio: ImageVector by lazy {
        icon("Audio") {
            circle(7.5f, 17f, 3.6f)
            roundedBox(10.2f, 3.4f, 12.4f, 17.6f, 1.1f)
            moveTo(11.3f, 3.4f)
            lineTo(19.4f, 6f)
            lineTo(19.4f, 9.4f)
            lineTo(11.3f, 6.6f)
            close()
        }
    }

    val Image: ImageVector by lazy {
        icon("Image") {
            roundedBox(3f, 4.4f, 21f, 19.6f, 3f)
            circle(8.4f, 9.6f, 2.1f)
            moveTo(4.6f, 17.4f)
            lineTo(10f, 11.6f)
            lineTo(14.2f, 16f)
            lineTo(16.8f, 13.4f)
            lineTo(20.4f, 17.4f)
            close()
        }
    }

    val Video: ImageVector by lazy {
        icon("Video") {
            roundedBox(2.6f, 5.4f, 15.4f, 18.6f, 3.2f)
            moveTo(16.4f, 10f)
            lineTo(21.4f, 7.2f)
            lineTo(21.4f, 16.8f)
            lineTo(16.4f, 14f)
            close()
        }
    }

    val File: ImageVector by lazy {
        icon("File") {
            moveTo(5f, 3f)
            lineTo(14f, 3f)
            lineTo(19f, 8f)
            lineTo(19f, 21f)
            lineTo(5f, 21f)
            close()
            moveTo(14f, 3f)
            lineTo(14f, 8f)
            lineTo(19f, 8f)
            close()
        }
    }

    val Archive: ImageVector by lazy {
        icon("Archive") {
            roundedBox(3f, 4f, 21f, 8.6f, 1.4f)
            moveTo(4.6f, 9.4f)
            lineTo(19.4f, 9.4f)
            lineTo(18.4f, 20f)
            lineTo(5.6f, 20f)
            close()
            roundedBox(10.2f, 12.4f, 13.8f, 16.4f, 1f)
        }
    }

    // --- actions -----------------------------------------------------------
    val Play: ImageVector by lazy {
        icon("Play") {
            moveTo(7f, 4.4f)
            lineTo(19.6f, 12f)
            lineTo(7f, 19.6f)
            close()
        }
    }

    val Pause: ImageVector by lazy {
        icon("Pause") {
            roundedBox(6.4f, 4.4f, 10f, 19.6f, 1.6f)
            roundedBox(14f, 4.4f, 17.6f, 19.6f, 1.6f)
        }
    }

    val Stop: ImageVector by lazy {
        icon("Stop") {
            roundedBox(5.4f, 5.4f, 18.6f, 18.6f, 3f)
        }
    }

    val Close: ImageVector by lazy {
        icon("Close") {
            moveTo(5.6f, 4.2f)
            lineTo(7.4f, 4.2f)
            lineTo(12f, 9.4f)
            lineTo(16.6f, 4.2f)
            lineTo(18.4f, 6f)
            lineTo(13.6f, 11.4f)
            lineTo(18.4f, 16.8f)
            lineTo(16.6f, 18.6f)
            lineTo(12f, 13.4f)
            lineTo(7.4f, 18.6f)
            lineTo(5.6f, 16.8f)
            lineTo(10.4f, 11.4f)
            close()
        }
    }

    val Check: ImageVector by lazy {
        icon("Check") {
            moveTo(4f, 12.4f)
            lineTo(6f, 10.4f)
            lineTo(10f, 14.4f)
            lineTo(18.4f, 6f)
            lineTo(20.4f, 8f)
            lineTo(10f, 18.4f)
            close()
        }
    }

    val Download: ImageVector by lazy {
        icon("Download") {
            roundedBox(3.4f, 3.4f, 20.6f, 15.4f, 3f)
            moveTo(9f, 11f)
            lineTo(15f, 11f)
            lineTo(15f, 17f)
            lineTo(18f, 17f)
            lineTo(12f, 22f)
            lineTo(6f, 17f)
            lineTo(9f, 17f)
            close()
        }
    }

    val Share: ImageVector by lazy {
        icon("Share") {
            circle(18f, 5.6f, 2.8f)
            circle(6f, 12f, 2.8f)
            circle(18f, 18.4f, 2.8f)
            moveTo(8.2f, 10.8f)
            lineTo(15.8f, 6.8f)
            lineTo(15.8f, 8.6f)
            lineTo(9f, 12.8f)
            close()
            moveTo(8.2f, 13.2f)
            lineTo(9f, 13.2f)
            lineTo(15.8f, 17.2f)
            lineTo(15.8f, 15.4f)
            lineTo(18.4f, 15.4f)
            lineTo(18.4f, 8.4f)
            lineTo(15.8f, 8.4f)
            lineTo(15.8f, 6.6f)
            close()
        }
    }

    val Copy: ImageVector by lazy {
        icon("Copy") {
            roundedBox(8f, 3f, 21f, 16f, 2.4f)
            moveTo(16f, 19f)
            lineTo(5f, 19f)
            lineTo(3f, 21f)
            lineTo(3f, 8f)
            lineTo(5f, 8f)
            lineTo(5f, 19f)
            lineTo(16f, 19f)
            close()
        }
    }

    val Trash: ImageVector by lazy {
        icon("Trash") {
            roundedBox(3f, 6f, 21f, 8.4f, 1.2f)
            moveTo(5.6f, 9.2f)
            lineTo(6.6f, 21f)
            lineTo(17.4f, 21f)
            lineTo(18.4f, 9.2f)
            close()
            roundedBox(9f, 3f, 15f, 5.4f, 1.2f)
        }
    }

    val Search: ImageVector by lazy {
        icon("Search") {
            circle(10.6f, 10.6f, 6.8f)
            moveTo(15.6f, 15.6f)
            lineTo(21.4f, 21.4f)
            lineTo(19.4f, 23.4f)
            lineTo(13.6f, 17.6f)
            close()
        }
    }

    val Refresh: ImageVector by lazy {
        icon("Refresh") {
            moveTo(12f, 3.4f)
            arcTo(Rect(3.4f, 3.4f, 20.6f, 20.6f), -60f, 300f, false)
            moveTo(12f, 1.6f)
            lineTo(12f, 7.2f)
            lineTo(7.6f, 4.4f)
            close()
        }
    }

    val Link: ImageVector by lazy {
        icon("Link") {
            moveTo(9.6f, 14.4f)
            lineTo(14.4f, 9.6f)
            lineTo(16.4f, 11.6f)
            lineTo(11.6f, 16.4f)
            close()
            moveTo(7.4f, 13.4f)
            lineTo(5.4f, 15.4f)
            arcTo(Rect(3.4f, 9.4f, 13.4f, 19.4f), 180f, 180f, false)
            lineTo(7.4f, 13.4f)
            close()
            moveTo(16.6f, 10.6f)
            lineTo(18.6f, 8.6f)
            arcTo(Rect(10.6f, 4.6f, 20.6f, 14.6f), 0f, 180f, false)
            lineTo(16.6f, 10.6f)
            close()
        }
    }

    val Globe: ImageVector by lazy {
        icon("Globe") {
            circle(12f, 12f, 9.2f)
            roundedBox(10.8f, 3.2f, 13.2f, 20.8f, 1.2f)
            moveTo(3.2f, 9.6f)
            lineTo(20.8f, 9.6f)
            lineTo(20.8f, 12f)
            lineTo(3.2f, 12f)
            close()
            moveTo(3.2f, 14.4f)
            lineTo(20.8f, 14.4f)
            lineTo(20.8f, 16.8f)
            lineTo(3.2f, 16.8f)
            close()
        }
    }

    val Shield: ImageVector by lazy {
        icon("Shield") {
            moveTo(12f, 2.6f)
            lineTo(20f, 5.6f)
            lineTo(20f, 12f)
            arcTo(Rect(4f, 2.6f, 20f, 21.4f), 180f, 180f, false)
            lineTo(4f, 5.6f)
            close()
        }
    }

    val Bolt: ImageVector by lazy {
        icon("Bolt") {
            moveTo(13.4f, 2f)
            lineTo(5.6f, 13.6f)
            lineTo(11f, 13.6f)
            lineTo(10.6f, 22f)
            lineTo(18.4f, 10.4f)
            lineTo(13f, 10.4f)
            close()
        }
    }

    val Sparkle: ImageVector by lazy {
        icon("Sparkle") {
            moveTo(12f, 2f)
            lineTo(14.1f, 9.9f)
            lineTo(22f, 12f)
            lineTo(14.1f, 14.1f)
            lineTo(12f, 22f)
            lineTo(9.9f, 14.1f)
            lineTo(2f, 12f)
            lineTo(9.9f, 9.9f)
            close()
        }
    }

    val Grid: ImageVector by lazy {
        icon("Grid") {
            roundedBox(3.4f, 3.4f, 10.6f, 10.6f, 2.2f)
            roundedBox(13.4f, 3.4f, 20.6f, 10.6f, 2.2f)
            roundedBox(3.4f, 13.4f, 10.6f, 20.6f, 2.2f)
            roundedBox(13.4f, 13.4f, 20.6f, 20.6f, 2.2f)
        }
    }

    val List: ImageVector by lazy {
        icon("List") {
            roundedBox(3f, 5f, 7f, 7f, 1f)
            roundedBox(9f, 5f, 21f, 7f, 1f)
            roundedBox(3f, 11f, 7f, 13f, 1f)
            roundedBox(9f, 11f, 21f, 13f, 1f)
            roundedBox(3f, 17f, 7f, 19f, 1f)
            roundedBox(9f, 17f, 21f, 19f, 1f)
        }
    }

    val Lock: ImageVector by lazy {
        icon("Lock") {
            roundedBox(4.6f, 10.4f, 19.4f, 21f, 2.6f)
            moveTo(8f, 10.4f)
            lineTo(8f, 7.4f)
            arcTo(Rect(7f, 3f, 17f, 13f), 180f, 180f, false)
            lineTo(16f, 10.4f)
            close()
        }
    }

    val Info: ImageVector by lazy {
        icon("Info") {
            circle(12f, 12f, 9.2f)
            circle(12f, 7.6f, 1.5f)
            roundedBox(10.6f, 10.4f, 13.4f, 17.4f, 1.4f)
        }
    }

    val Warning: ImageVector by lazy {
        icon("Warning") {
            moveTo(12f, 2.6f)
            lineTo(22.4f, 20.6f)
            lineTo(1.6f, 20.6f)
            close()
            circle(12f, 15.4f, 1.5f)
            roundedBox(10.6f, 9.6f, 13.4f, 13.2f, 1.4f)
        }
    }

    val Clock: ImageVector by lazy {
        icon("Clock") {
            circle(12f, 12f, 9.2f)
            moveTo(11f, 6.4f)
            lineTo(13f, 6.4f)
            lineTo(13f, 12.6f)
            lineTo(17.4f, 15.2f)
            lineTo(16f, 17.2f)
            lineTo(11f, 14f)
            close()
        }
    }

    val Speed: ImageVector by lazy {
        icon("Speed") {
            moveTo(3f, 17f)
            arcTo(Rect(3f, 5f, 21f, 21f), 180f, 180f, false)
            close()
            roundedBox(11f, 8.6f, 13f, 16.4f, 1f)
            circle(12f, 16.6f, 2f)
        }
    }

    val Camera: ImageVector by lazy {
        icon("Camera") {
            roundedBox(2.6f, 6.4f, 21.4f, 19.4f, 3f)
            roundedBox(8f, 3.4f, 16f, 6.4f, 1.4f)
            circle(12f, 12.8f, 4.2f)
        }
    }

    val Expand: ImageVector by lazy {
        icon("Expand") {
            moveTo(3f, 9.6f)
            lineTo(3f, 3f)
            lineTo(9.6f, 3f)
            lineTo(9.6f, 5.4f)
            lineTo(5.4f, 5.4f)
            lineTo(5.4f, 9.6f)
            close()
            moveTo(14.4f, 3f)
            lineTo(21f, 3f)
            lineTo(21f, 9.6f)
            lineTo(18.6f, 9.6f)
            lineTo(18.6f, 5.4f)
            lineTo(14.4f, 5.4f)
            close()
            moveTo(21f, 14.4f)
            lineTo(21f, 21f)
            lineTo(14.4f, 21f)
            lineTo(14.4f, 18.6f)
            lineTo(18.6f, 18.6f)
            lineTo(18.6f, 14.4f)
            close()
            moveTo(9.6f, 21f)
            lineTo(3f, 21f)
            lineTo(3f, 14.4f)
            lineTo(5.4f, 14.4f)
            lineTo(5.4f, 18.6f)
            lineTo(9.6f, 18.6f)
            close()
        }
    }

    val Eye: ImageVector by lazy {
        icon("Eye") {
            moveTo(1.6f, 12f)
            arcTo(Rect(2.4f, 4.4f, 21.6f, 19.6f), 180f, 180f, false)
            arcTo(Rect(2.4f, 4.4f, 21.6f, 19.6f), 0f, 180f, false)
            close()
            circle(12f, 12f, 3.4f)
        }
    }

    val More: ImageVector by lazy {
        icon("More") {
            circle(12f, 4.6f, 2f)
            circle(12f, 12f, 2f)
            circle(12f, 19.4f, 2f)
        }
    }

    val Back: ImageVector by lazy {
        icon("Back") {
            moveTo(14.4f, 4.6f)
            lineTo(6.6f, 12f)
            lineTo(14.4f, 19.4f)
            lineTo(16.4f, 17.4f)
            lineTo(10.6f, 12f)
            lineTo(16.4f, 6.6f)
            close()
        }
    }

    val Forward: ImageVector by lazy {
        icon("Forward") {
            moveTo(9.6f, 4.6f)
            lineTo(17.4f, 12f)
            lineTo(9.6f, 19.4f)
            lineTo(7.6f, 17.4f)
            lineTo(13.4f, 12f)
            lineTo(7.6f, 6.6f)
            close()
        }
    }

    val Folder: ImageVector by lazy {
        icon("Folder") {
            moveTo(2.6f, 5.4f)
            lineTo(9.4f, 5.4f)
            lineTo(11.4f, 8f)
            lineTo(21.4f, 8f)
            lineTo(21.4f, 19.4f)
            lineTo(2.6f, 19.4f)
            close()
        }
    }
}
