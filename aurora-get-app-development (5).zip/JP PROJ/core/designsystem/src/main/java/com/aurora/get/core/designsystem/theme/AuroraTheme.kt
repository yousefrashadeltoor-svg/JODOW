package com.aurora.get.core.designsystem.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat

val LocalAuroraColors = staticCompositionLocalOf { AuroraPalettes.of(AuroraThemeId.AURORA, true) }
val LocalAuroraTypography = staticCompositionLocalOf { AuroraTypography.create(LocalContextHolder.context) }
val LocalAuroraShapes = staticCompositionLocalOf { AuroraShapes.Default }
val LocalAuroraThemeId = staticCompositionLocalOf { AuroraThemeId.AURORA }

/** Tiny holder so the static typography local can be created lazily with a Context. */
object LocalContextHolder {
    lateinit var context: android.content.Context
}

/**
 * The root theme of Aurora Get.
 * There is **no Material theme** involved — everything is composed from
 * `compose.foundation` + `compose.ui` only.
 */
@Composable
fun AuroraTheme(
    themeId: AuroraThemeId = AuroraThemeId.AURORA,
    dark: Boolean = isSystemInDarkTheme(),
    layoutDirection: LayoutDirection = LayoutDirection.Rtl,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    LocalContextHolder.context = context
    // A *_LIGHT theme always forces the light palette, regardless of the system setting.
    val resolvedDark = if (themeId.name.endsWith("_LIGHT")) false else dark
    val colors = AuroraPalettes.of(themeId, resolvedDark)
    val typography = AuroraTypography.create(context)
    val view = LocalView.current
    if (!view.isInEditMode) {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !dark
        }
    }
    CompositionLocalProvider(
        LocalAuroraColors provides colors,
        LocalAuroraTypography provides typography,
        LocalAuroraShapes provides AuroraShapes.Default,
        LocalAuroraThemeId provides themeId,
        LocalLayoutDirection provides layoutDirection
    ) {
        content()
    }
}

/** Convenience accessors. */
object AuroraTheme {
    val colors: AuroraColors
        @Composable @ReadOnlyComposable get() = LocalAuroraColors.current

    val typography: AuroraTypography
        @Composable @ReadOnlyComposable get() = LocalAuroraTypography.current

    val shapes: AuroraShapes
        @Composable @ReadOnlyComposable get() = LocalAuroraShapes.current

    val themeId: AuroraThemeId
        @Composable @ReadOnlyComposable get() = LocalAuroraThemeId.current

    val isDark: Boolean
        @Composable @ReadOnlyComposable get() = LocalAuroraColors.current.isDark
}
