package com.aurora.get.core.designsystem.theme

import android.content.Context
import androidx.compose.runtime.Immutable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Typography built on open-licence fonts only:
 *  - Latin  : Plus Jakarta Sans (or Outfit)  — SIL OFL
 *  - Arabic : IBM Plex Sans Arabic (or Readex Pro / Tajawal) — SIL OFL
 *
 * The font files are *optional* at build time: if the `.ttf` resources are not present the
 * family silently falls back to the platform font, so the app never breaks.
 *
 * VERIFY: drop `plus_jakarta_sans_regular.ttf`, `plus_jakarta_sans_bold.ttf`,
 * `ibm_plex_sans_arabic_regular.ttf` and `ibm_plex_sans_arabic_bold.ttf` into
 * `core/designsystem/src/main/res/font/` to activate them.
 */
@Immutable
data class AuroraTypography(
    val display: TextStyle,
    val headline: TextStyle,
    val title: TextStyle,
    val body: TextStyle,
    val bodySmall: TextStyle,
    val label: TextStyle,
    val caption: TextStyle,
    val mono: TextStyle
) {
    companion object {
        private val weights = listOf(
            FontWeight.Normal,
            FontWeight.Medium,
            FontWeight.SemiBold,
            FontWeight.Bold
        )

        private fun loadFont(context: Context, name: String, weight: FontWeight): Font? {
            val resId = context.resources.getIdentifier(name, "font", context.packageName)
            if (resId == 0) return null
            return runCatching { Font(resId, weight) }.getOrNull()
        }

        private fun buildFamily(context: Context, latin: String, arabic: String): FontFamily {
            val fonts = mutableListOf<Font>()
            weights.forEach { weight ->
                loadFont(context, latin, weight)?.let { fonts += it }
                loadFont(context, arabic, weight)?.let { fonts += it }
            }
            return if (fonts.isEmpty()) FontFamily.Default else FontFamily(fonts)
        }

        fun create(context: Context): AuroraTypography {
            val family = buildFamily(context, "plus_jakarta_sans", "ibm_plex_sans_arabic")
            val mono = FontFamily.Monospace
            return AuroraTypography(
                display = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 34.sp, lineHeight = 42.sp, letterSpacing = (-0.6).sp),
                headline = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 34.sp, letterSpacing = (-0.4).sp),
                title = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 19.sp, lineHeight = 26.sp),
                body = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 22.sp),
                bodySmall = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 19.sp),
                label = TextStyle(fontFamily = family, fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 18.sp, letterSpacing = 0.2.sp),
                caption = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 11.sp, lineHeight = 15.sp, letterSpacing = 0.3.sp),
                mono = TextStyle(fontFamily = mono, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 18.sp)
            )
        }
    }
}
