package com.aurora.get.core.designsystem.components

import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import com.aurora.get.core.designsystem.theme.AuroraTheme

/**
 * Streaming text reveal, Gemini style: the characters appear one by one and the
 * "youngest" ones are still slightly blurred.
 */
@Composable
fun StreamingText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle? = null,
    animate: Boolean = true
) {
    val resolved = style ?: AuroraTheme.typography.body
    val progress = remember { Animatable(if (animate) 1f else 1f) }

    LaunchedEffect(text, animate) {
        if (!animate) {
            progress.snapTo(1f)
            return@LaunchedEffect
        }
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = (text.length * 26).coerceIn(220, 1400))
        )
    }

    val revealed = (text.length * progress.value).toInt().coerceIn(0, text.length)
    val visible = text.take(revealed)
    val tail = text.drop(revealed)

    BasicText(
        text = visible + tail,
        style = resolved,
        modifier = modifier.then(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && tail.isNotEmpty()) {
                Modifier.graphicsLayer {
                    renderEffect = RenderEffect.createBlurEffect(1.4f, 1.4f, android.graphics.Shader.TileMode.CLAMP)
                }
            } else {
                Modifier
            }
        )
    )
}

/**
 * A title whose colour is a moving gradient, used for the main headings.
 */
@Composable
fun GradientTitle(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle? = null
) {
    val colors = AuroraTheme.colors
    val resolved = style ?: AuroraTheme.typography.headline
    BasicText(
        text = text,
        style = resolved.copy(
            brush = Brush.linearGradient(colors.accentSweep)
        ),
        modifier = modifier
    )
}

/**
 * The text primitive of Aurora Get. `BasicText` from `compose.foundation` is used
 * instead of the Material `Text` composable.
 */
@Composable
fun AuroraText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle? = null,
    color: Color? = null,
    maxLines: Int = Int.MAX_VALUE,
    textAlign: TextAlign? = null
) {
    val base = style ?: AuroraTheme.typography.body
    val resolved = base.copy(
        color = color ?: AuroraTheme.colors.onBackground,
        textAlign = textAlign ?: base.textAlign
    )
    BasicText(
        text = text,
        modifier = modifier,
        style = resolved,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis
    )
}

/** Draws one of the custom Aurora icons (no Material Icons anywhere). */
@Composable
fun AuroraIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = AuroraTheme.colors.onBackground
) {
    val painter = rememberVectorPainter(imageVector)
    androidx.compose.foundation.Image(
        painter = painter,
        contentDescription = contentDescription,
        colorFilter = ColorFilter.tint(tint),
        modifier = modifier
    )
}
