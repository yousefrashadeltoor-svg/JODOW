package com.aurora.get.core.designsystem.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aurora.get.core.designsystem.theme.AuroraTheme
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState

/**
 * The single ambient blur state of the app.
 *
 * Everything that wants to look "glassy" registers itself as a *source*
 * (the animated mesh background, the media covers, …) and every glass surface
 * renders the blurred result of those sources through [LocalHazeState].
 *
 * VERIFY: the Haze 1.x API surface used here is intentionally minimal
 * (`rememberHazeState`, `hazeSource`, `hazeEffect`) so that a version bump only
 * requires touching this file.
 */
val LocalHazeState = staticCompositionLocalOf<HazeState> {
    error("AuroraGlassRoot must wrap the whole application")
}

/** Wraps the application: registers the blur source and provides the ambient state. */
@Composable
fun AuroraGlassRoot(content: @Composable BoxScope.() -> Unit) {
    val hazeState = rememberHazeState()
    CompositionLocalProvider(LocalHazeState provides hazeState) {
        Box(Modifier.fillMaxSize().hazeSource(hazeState)) {
            content()
        }
    }
}

/**
 * The base glass surface: real background blur + translucent gradient tint +
 * 1dp specular gradient border + soft multi layer shadow.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape? = null,
    tint: Color? = null,
    borderBrush: Brush? = null,
    elevation: Dp = 16.dp,
    borderWidth: Dp = 1.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val colors = AuroraTheme.colors
    val resolvedShape = shape ?: AuroraTheme.shapes.large
    val hazeState = LocalHazeState.current
    val base = tint ?: colors.glassTint
    val specular = borderBrush ?: Brush.linearGradient(
        colors.accentSweep + listOf(Color.White.copy(alpha = if (colors.isDark) 0.45f else 0.8f))
    )

    Box(
        modifier = modifier
            .shadow(
                elevation = elevation,
                shape = resolvedShape,
                clip = false,
                ambientColor = colors.primary.copy(alpha = 0.18f),
                spotColor = colors.tertiary.copy(alpha = 0.14f)
            )
            .hazeEffect(hazeState)
            .clip(resolvedShape)
            .background(
                Brush.verticalGradient(
                    listOf(
                        base.copy(alpha = (base.alpha * 1.3f).coerceAtMost(0.95f)),
                        base.copy(alpha = (base.alpha * 0.55f).coerceAtLeast(0.02f))
                    )
                )
            )
            .border(width = borderWidth, brush = specular, shape = resolvedShape)
    ) {
        content()
    }
}

/** A glass card with padding, used across the whole app. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape? = null,
    tint: Color? = null,
    contentPadding: Dp = 16.dp,
    content: @Composable BoxScope.() -> Unit
) {
    GlassSurface(modifier = modifier, shape = shape, tint = tint) {
        Box(Modifier.padding(contentPadding)) { content() }
    }
}

/** A thin glass pill used for chips, badges and segmented controls. */
@Composable
fun GlassPill(
    modifier: Modifier = Modifier,
    tint: Color? = null,
    content: @Composable BoxScope.() -> Unit
) {
    GlassSurface(
        modifier = modifier,
        shape = AuroraTheme.shapes.pill,
        tint = tint,
        elevation = 6.dp,
        borderWidth = 0.8.dp
    ) { content() }
}

/**
 * Draws the Gemini-style rotating glow behind an element while it is processing.
 * The sweep gradient is drawn under the content, so the element stays readable.
 */
fun Modifier.auroraGlow(colors: List<Color>, strength: Float = 1f): Modifier =
    this.drawBehind {
        if (strength <= 0f) return@drawBehind
        val sweep = Brush.sweepGradient(colors = colors + colors.first())
        drawRect(brush = sweep, alpha = 0.28f * strength)
    }
