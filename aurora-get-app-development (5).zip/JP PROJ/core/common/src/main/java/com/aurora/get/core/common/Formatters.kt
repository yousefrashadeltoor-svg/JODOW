package com.aurora.get.core.common

import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Formatting helpers. Sizes always keep a distinction between a **confirmed**
 * byte count and an **approximated** one (prefixed with the ≈ sign).
 */
object Format {

    private val UNITS = arrayOf("B", "KiB", "MiB", "GiB", "TiB")

    /** Human readable size, e.g. `141.5 MiB`. */
    fun bytes(value: Long): String {
        if (value < 0) return "—"
        if (value < 1024) return "$value B"
        var index = 0
        var size = value.toDouble()
        while (size >= 1024 && index < UNITS.lastIndex) {
            size /= 1024.0
            index++
        }
        val pattern = if (size >= 100) "%.0f %s" else if (size >= 10) "%.1f %s" else "%.2f %s"
        return String.format(Locale.US, pattern, size, UNITS[index])
    }

    /** Approximated size, always marked with ≈. */
    fun approxBytes(value: Long): String = "≈ " + bytes(value)

    /** Exact byte count with thousand separators, e.g. `148,372,910 bytes (141.5 MiB)`. */
    fun exactBytes(value: Long): String {
        val grouped = String.format(Locale.US, "%,d", value)
        return "$grouped bytes (${bytes(value)})"
    }

    /** Transfer speed, e.g. `4.2 MB/s`. */
    fun speed(bytesPerSecond: Double): String {
        if (bytesPerSecond <= 0.0) return "—"
        val mb = bytesPerSecond / (1024.0 * 1024.0)
        return if (mb >= 1.0) String.format(Locale.US, "%.2f MB/s", mb)
        else String.format(Locale.US, "%.0f KB/s", bytesPerSecond / 1024.0)
    }

    /** Remaining time, e.g. `03:12` or `1h 04m`. */
    fun eta(seconds: Long): String {
        if (seconds <= 0) return "—"
        if (seconds >= 3600) {
            val h = seconds / 3600
            val m = (seconds % 3600) / 60
            return String.format(Locale.US, "%dh %02dm", h, m)
        }
        val m = seconds / 60
        val s = seconds % 60
        return String.format(Locale.US, "%02d:%02d", m, s)
    }

    /** Duration of a media file, e.g. `12:44` / `1:02:33`. */
    fun duration(seconds: Long): String {
        if (seconds <= 0) return "0:00"
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    fun percent(done: Long, total: Long): Float {
        if (total <= 0) return 0f
        return ((done.toDouble() / total.toDouble()) * 100.0).roundToInt().coerceIn(0, 100) / 100f
    }

    /** Round to a compact magnitude, used by the speedometer. */
    fun round(value: Double): Double {
        if (value == 0.0) return 0.0
        val exponent = ln(abs(value)) / ln(10.0)
        val magnitude = 10.0.pow(exponent.toInt())
        return (value / magnitude).roundToInt() * magnitude
    }
}
