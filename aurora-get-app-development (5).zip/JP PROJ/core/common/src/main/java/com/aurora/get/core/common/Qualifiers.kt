package com.aurora.get.core.common

import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class IoDispatcher

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class DefaultDispatcher

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class MainDispatcher

/** Application scoped coroutine scope (never cancelled). */
@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class ApplicationScope
