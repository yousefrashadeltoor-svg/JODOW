package com.aurora.get.core.common

import java.text.Normalizer
import java.util.Locale

object FileNames {

    /** Removes characters that are illegal on Android filesystems, keeping the extension. */
    fun sanitize(raw: String, fallback: String = "download"): String {
        var name = Normalizer.normalize(raw, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_")
            .replace(Regex("\\s+"), " ")
            .trim()
        name = name.trim('.', ' ')
        if (name.isEmpty()) name = fallback
        if (name.length > 120) {
            val dot = name.lastIndexOf('.')
            name = if (dot > 0) name.substring(0, 120) + name.substring(dot) else name.take(120)
        }
        return name
    }

    fun extensionOf(nameOrUrl: String): String? {
        val clean = nameOrUrl.substringBefore('?').substringBefore('#').substringAfterLast('/')
        val dot = clean.lastIndexOf('.')
        if (dot <= 0 || dot == clean.lastIndex) return null
        val ext = clean.substring(dot + 1)
        return if (ext.length in 1..5 && ext.all { it.isLetterOrDigit() }) ext.lowercase(Locale.US) else null
    }

    /** Builds a unique file name inside [folder] avoiding collisions. */
    fun uniqueFileName(folder: java.io.File, desired: String): String {
        val safe = sanitize(desired)
        if (!java.io.File(folder, safe).exists()) return safe
        val dot = safe.lastIndexOf('.')
        val base = if (dot > 0) safe.substring(0, dot) else safe
        val ext = if (dot > 0) safe.substring(dot) else ""
        var index = 1
        while (true) {
            val candidate = "$base($index)$ext"
            if (!java.io.File(folder, candidate).exists()) return candidate
            index++
        }
    }

    /** Title used for saved media metadata. */
    fun toTitle(raw: String): String = sanitize(raw).substringBeforeLast('.').trim()
}
