package com.aurora.get.core.common

import timber.log.Timber

object AuroraLog {
    fun d(tag: String, message: String) = Timber.tag(tag).d(message)
    fun i(tag: String, message: String) = Timber.tag(tag).i(message)
    fun w(tag: String, message: String, error: Throwable? = null) = Timber.tag(tag).w(error, message)
    fun e(tag: String, message: String, error: Throwable? = null) = Timber.tag(tag).e(error, message)
}
