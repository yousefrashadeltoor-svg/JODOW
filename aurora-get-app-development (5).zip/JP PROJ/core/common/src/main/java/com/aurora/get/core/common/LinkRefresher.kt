package com.aurora.get.core.common

/**
 * Re-extracts a fresh direct URL for a page URL.
 *
 * Implemented in `:engine:extractors` (yt-dlp / native extractors) and injected into the
 * download engine so that expired links (HTTP 403 / 410) can be renewed automatically.
 */
interface LinkRefresher {
    suspend fun refresh(url: String): String?
}
