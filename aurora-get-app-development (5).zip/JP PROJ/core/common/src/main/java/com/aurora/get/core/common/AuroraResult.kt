package com.aurora.get.core.common

/**
 * A tiny, dependency free result wrapper used across every layer.
 * The whole app is offline-first: there is no telemetry of any kind.
 */
sealed interface AuroraResult<out T> {
    data class Success<T>(val value: T) : AuroraResult<T>
    data class Failure(val error: AuroraError) : AuroraResult<Nothing>

    fun getOrNull(): T? = (this as? Success)?.value

    fun errorOrNull(): AuroraError? = (this as? Failure)?.error

    inline fun <R> map(transform: (T) -> R): AuroraResult<R> = when (this) {
        is Success -> Success(transform(value))
        is Failure -> this
    }

    inline fun onSuccess(action: (T) -> Unit): AuroraResult<T> {
        if (this is Success) action(value)
        return this
    }

    inline fun onFailure(action: (AuroraError) -> Unit): AuroraResult<T> {
        if (this is Failure) action(error)
        return this
    }
}

sealed class AuroraError(val message: String, val cause: Throwable? = null) {
    class Network(message: String, cause: Throwable? = null) : AuroraError(message, cause)
    class Timeout(message: String, cause: Throwable? = null) : AuroraError(message, cause)
    class Http(val code: Int, message: String = "HTTP $code") : AuroraError(message)
    class NotFound(message: String = "المحتوى غير موجود") : AuroraError(message)
    class Unsupported(message: String = "المحتوى غير مدعوم") : AuroraError(message)
    class Parse(message: String, cause: Throwable? = null) : AuroraError(message, cause)
    class Io(message: String, cause: Throwable? = null) : AuroraError(message, cause)
    class Permission(message: String) : AuroraError(message)
    class Cancelled(message: String = "تم الإلغاء") : AuroraError(message)
    class Unknown(message: String, cause: Throwable? = null) : AuroraError(message, cause)
}

inline fun <T> runCatchingAurora(block: () -> T): AuroraResult<T> = try {
    AuroraResult.Success(block())
} catch (c: kotlinx.coroutines.CancellationException) {
    throw c
} catch (t: Throwable) {
    AuroraResult.Failure(AuroraError.Unknown(t.message ?: "خطأ غير متوقع", t))
}
