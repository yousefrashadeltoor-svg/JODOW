package com.aurora.get.core.common

/** The content categories that drive the four smart buttons. */
enum class MediaKind {
    VIDEO,
    AUDIO,
    IMAGE,
    FILE,
    ARCHIVE,
    DOCUMENT,
    APK,
    UNKNOWN;

    companion object {
        private val ARCHIVE_EXT = setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso", "zst")
        private val DOC_EXT = setOf("pdf", "epub", "mobi", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md")
        private val VIDEO_EXT = setOf("mp4", "mkv", "webm", "mov", "avi", "flv", "ts", "m4v", "3gp", "mpd")
        private val AUDIO_EXT = setOf("mp3", "m4a", "aac", "opus", "ogg", "oga", "wav", "flac", "weba", "m3u8")
        private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "avif", "gif", "bmp", "heic", "heif", "svg")

        fun fromExtension(ext: String?): MediaKind {
            val e = ext?.lowercase()?.trim()?.removePrefix(".") ?: return UNKNOWN
            return when {
                e in VIDEO_EXT -> VIDEO
                e in AUDIO_EXT -> AUDIO
                e in IMAGE_EXT -> IMAGE
                e in ARCHIVE_EXT -> ARCHIVE
                e in DOC_EXT -> DOCUMENT
                e == "apk" -> APK
                else -> UNKNOWN
            }
        }

        fun fromMime(mime: String?): MediaKind {
            val m = mime?.lowercase() ?: return UNKNOWN
            return when {
                m.startsWith("video/") -> VIDEO
                m.startsWith("audio/") -> AUDIO
                m.startsWith("image/") -> IMAGE
                m.startsWith("text/") -> DOCUMENT
                m.contains("zip") || m.contains("compressed") || m.contains("tar") || m.contains("rar") -> ARCHIVE
                m.contains("pdf") || m.contains("officedocument") -> DOCUMENT
                m.contains("apk") || m.contains("vnd.android") -> APK
                else -> UNKNOWN
            }
        }
    }
}
