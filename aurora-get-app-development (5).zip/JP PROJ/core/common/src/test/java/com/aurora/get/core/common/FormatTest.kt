package com.aurora.get.core.common

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FormatTest {

    @Test
    fun `bytes are formatted with binary units`() {
        assertEquals("1 KiB", Format.bytes(1024))
        assertEquals("1.50 MiB", Format.bytes(1024 * 1024 * 3 / 2))
        assertEquals("1.41 MiB", Format.bytes(148372910))
        assertEquals("512 B", Format.bytes(512))
    }

    @Test
    fun `approximated sizes always carry the approx sign`() {
        assertTrue(Format.approxBytes(1024).startsWith("≈"))
        assertEquals("≈ 1.00 KiB", Format.approxBytes(1024))
    }

    @Test
    fun `exact bytes show the byte count and the human readable value`() {
        assertEquals("148,372,910 bytes (141.5 MiB)", Format.exactBytes(148372910))
    }

    @Test
    fun `eta is formatted as minutes and seconds`() {
        assertEquals("03:12", Format.eta(192))
        assertEquals("1h 01m", Format.eta(3660))
    }

    @Test
    fun `duration supports hours`() {
        assertEquals("12:44", Format.duration(764))
        assertEquals("1:01:01", Format.duration(3661))
    }

    @Test
    fun `percent is clamped`() {
        assertEquals(0.5f, Format.percent(50, 100))
        assertEquals(1f, Format.percent(200, 100))
    }
}

class MediaKindTest {

    @Test
    fun `extensions map to the right category`() {
        assertEquals(MediaKind.VIDEO, MediaKind.fromExtension("mp4"))
        assertEquals(MediaKind.AUDIO, MediaKind.fromExtension("m4a"))
        assertEquals(MediaKind.IMAGE, MediaKind.fromExtension("webp"))
        assertEquals(MediaKind.ARCHIVE, MediaKind.fromExtension("zip"))
        assertEquals(MediaKind.DOCUMENT, MediaKind.fromExtension("pdf"))
        assertEquals(MediaKind.APK, MediaKind.fromExtension("apk"))
    }

    @Test
    fun `mime types map to the right category`() {
        assertEquals(MediaKind.VIDEO, MediaKind.fromMime("video/mp4"))
        assertEquals(MediaKind.AUDIO, MediaKind.fromMime("audio/mpeg"))
        assertEquals(MediaKind.UNKNOWN, MediaKind.fromMime(null))
    }
}
