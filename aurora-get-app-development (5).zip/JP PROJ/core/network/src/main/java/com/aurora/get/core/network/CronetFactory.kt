package com.aurora.get.core.network

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import com.aurora.get.core.common.AuroraLog
import okhttp3.android.engine.AndroidEngine
import org.chromium.net.CronetEngine

/**
 * Optional Cronet (HTTP/3 + QUIC) engine.
 *
 * Cronet is not available on every device: when the native library is missing we simply
 * keep the OkHttp HTTP/2 stack, the app never crashes because of it.
 */
object CronetFactory {

    private const val TAG = "CronetFactory"

    @SuppressLint("UnsafeOptInUsageError")
    fun create(context: Context): AndroidEngine? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return null
        return runCatching {
            val engine = CronetEngine.Builder(context)
                .enableHttp2(true)
                .enableHttp3(true)
                .enableQuic(true)
                .enableBrotli(true)
                .setUserAgent(NetworkModule.USER_AGENT)
                .build()
            CronetEngine.Builder::class.java
            engine
        }.onFailure {
            AuroraLog.w(TAG, "Cronet unavailable, falling back to OkHttp: ${it.message}")
        }.getOrNull()
    }
}
