package com.aurora.get.core.network.adblock

import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

/**
 * Pure-Kotlin Adblock-Plus style engine.
 *
 * It is used as a guaranteed fallback: when the native `adblock-rust` JNI library is
 * bundled the [NativeAdBlock] implementation is preferred, but the app keeps working
 * (and keeps blocking ads) even when the native library is missing.
 */
class AdBlockEngine {

    private val rules = mutableListOf<AdBlockRule>()
    private val cosmeticSelectors = mutableListOf<Pair<String, String>>() // domain -> css
    private val exceptions = mutableSetOf<String>() // whitelisted sites
    private val counters = AtomicLong(0)

    @Volatile
    private var loadedRuleCount = 0

    val ruleCount: Int get() = loadedRuleCount
    val blockedCount: Long get() = counters.get()

    fun load(rules: List<AdBlockRule>, cosmetic: List<Pair<String, String>> = emptyList()) {
        this.rules.clear()
        this.rules.addAll(rules)
        this.cosmeticSelectors.clear()
        this.cosmeticSelectors.addAll(cosmetic)
        loadedRuleCount = rules.size
    }

    fun clear() {
        rules.clear()
        cosmeticSelectors.clear()
        loadedRuleCount = 0
        counters.set(0)
    }

    fun whitelist(domain: String) {
        exceptions.add(domain.lowercase(Locale.US))
    }

    fun removeWhitelist(domain: String) {
        exceptions.remove(domain.lowercase(Locale.US))
    }

    fun whitelistedDomains(): Set<String> = exceptions.toSet()

    /** Returns true when the request must be blocked. */
    fun shouldBlock(request: AdBlockRequest): Boolean {
        val host = request.url.host.lowercase(Locale.US)
        if (exceptions.contains(host) || exceptions.any { host == it || host.endsWith(".$it") }) return false
        for (rule in rules) {
            if (rule.isException) {
                if (matches(rule, request)) return false
            } else if (matches(rule, request)) {
                counters.incrementAndGet()
                return true
            }
        }
        return false
    }

    private fun matches(rule: AdBlockRule, request: AdBlockRequest): Boolean {
        if (rule.types.isNotEmpty() && request.type !in rule.types) return false
        if (rule.isThirdPartyOnly && !request.isThirdParty) return false
        if (rule.isFirstPartyOnly && request.isThirdParty) return false
        if (rule.includedDomains.isNotEmpty()) {
            val host = request.url.host.lowercase(Locale.US)
            val hit = rule.includedDomains.any { host == it || host.endsWith(".$it") }
            if (!hit) return false
        }
        if (rule.domainExceptions.isNotEmpty()) {
            val doc = request.documentDomain?.lowercase(Locale.US) ?: return false
            if (rule.domainExceptions.any { doc == it || doc.endsWith(".$it") }) return false
        }
        val url = request.url.toString()
        val regex = rule.regex
        if (regex != null) return regex.containsMatchIn(url)
        return plainMatch(rule.pattern, url, request.url.host.lowercase(Locale.US))
    }

    /** Implements the `||host^`, `|start`, `end|` and plain substring semantics. */
    private fun plainMatch(pattern: String, url: String, host: String): Boolean {
        var p = pattern
        var anchoredStart = false
        var anchoredEnd = false
        var domainAnchor = false

        if (p.startsWith("||")) {
            domainAnchor = true
            p = p.substring(2)
        } else if (p.startsWith("|")) {
            anchoredStart = true
            p = p.substring(1)
        }
        if (p.endsWith("|")) {
            anchoredEnd = true
            p = p.dropLast(1)
        }
        p = p.removeSuffix("^")

        if (domainAnchor) {
            val candidate = if (p.startsWith("/")) {
                url.substringAfter(host, "").ifEmpty { url }
            } else p
            return if (anchoredStart) url.startsWith(candidate)
            else if (anchoredEnd) url.endsWith(candidate)
            else url.contains(candidate)
        }
        if (anchoredStart) return url.startsWith(p)
        if (anchoredEnd) return url.endsWith(p)
        return url.contains(p)
    }

    /** CSS injected to hide the remaining cosmetic elements of a page. */
    fun cosmeticCssFor(domain: String): String {
        val host = domain.lowercase(Locale.US)
        val sb = StringBuilder()
        cosmeticSelectors.forEach { (scope, css) ->
            if (scope == "*" || host == scope || host.endsWith(".$scope")) {
                sb.append(css).append('\n')
            }
        }
        return sb.toString()
    }

    companion object {
        /**
         * Parses a raw filter list into rules.
         * Supported syntax: `||domain^`, `|http://`, `*`, `^`, `/regex/`, `@@` exceptions
         * and the `$option` list (document, script, image, media, xhr, third-party, domain=).
         */
        fun parseFilters(raw: String): Pair<List<AdBlockRule>, List<Pair<String, String>>> {
            val rules = mutableListOf<AdBlockRule>()
            val cosmetic = mutableListOf<Pair<String, String>>()
            raw.lineSequence().forEach { original ->
                val line = original.trim()
                if (line.isEmpty() || line.startsWith("!") || line.startsWith("[")) return@forEach
                if (line.startsWith("##") || line.startsWith("#@#")) {
                    val domain = if (line.contains("##")) {
                        line.substringBefore("##")
                    } else {
                        line.substringBefore("#@#")
                    }
                    val selector = if (line.contains("##")) {
                        line.substringAfter("##")
                    } else {
                        line.substringAfter("#@#")
                    }
                    val scope = domain.substringAfter("domain=").ifEmpty { "*" }
                    cosmetic += scope to selector
                    return@forEach
                }
                val isException = line.startsWith("@@")
                val body = if (isException) line.removePrefix("@@") else line
                val parts = body.split('$', limit = 2)
                val pattern = parts[0]
                val optionString = parts.getOrNull(1).orEmpty()
                val options = optionString.split(',').map { it.trim().lowercase(Locale.US) }.filter { it.isNotEmpty() }.toSet()
                val included = options.filter { it.startsWith("domain=") }
                    .flatMap { it.removePrefix("domain=").split('|') }.filter { it.isNotEmpty() }.toSet()
                val excluded = options.filter { it.startsWith("~domain=") }
                    .flatMap { it.removePrefix("~domain=").split('|') }.filter { it.isNotEmpty() }.toSet()
                val regex = if (pattern.startsWith("/") && pattern.endsWith("/") && pattern.length > 2) {
                    runCatching { Regex(pattern.substring(1, pattern.length - 1)) }.getOrNull()
                } else null
                rules += AdBlockRule(
                    pattern = pattern,
                    isException = isException,
                    regex = regex,
                    options = options,
                    domainExceptions = excluded,
                    includedDomains = included,
                    blockCosmetics = "generichide" in options,
                    raw = original
                )
            }
            return rules to cosmetic
        }
    }
}

/** A request that the engine can decide about. */
data class AdBlockRequest(
    val url: java.net.URL,
    val type: String,
    val documentDomain: String?
) {
    val isThirdParty: Boolean
        get() {
            val doc = documentDomain ?: return false
            val host = url.host.lowercase(Locale.US)
            return !(host == doc || host.endsWith(".$doc"))
        }
}
