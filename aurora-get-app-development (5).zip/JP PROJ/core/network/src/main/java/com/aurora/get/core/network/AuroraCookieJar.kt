package com.aurora.get.core.network

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl

/**
 * Cookie jar backed by EncryptedSharedPreferences.
 * Cookies are never written in clear text and never leave the device.
 */
class AuroraCookieJar(context: Context) : CookieJar {

    private val prefs = runCatching {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "aurora_cookies",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        ) as android.content.SharedPreferences
    }.getOrElse {
        context.getSharedPreferences("aurora_cookies_fallback", Context.MODE_PRIVATE)
    }

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        if (cookies.isEmpty()) return
        val existing = loadFor(url.host).associateBy { it.name }.toMutableMap()
        cookies.forEach { cookie ->
            if (cookie.expiresAt < System.currentTimeMillis()) existing.remove(cookie.name)
            else existing[cookie.name] = cookie
        }
        val host = url.host
        prefs.edit()
            .putString(host, existing.values.joinToString("\n") { it.toString() })
            .apply()
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        val host = url.host
        val raw = prefs.getString(host, null) ?: return emptyList()
        val cookies = raw.lineSequence().mapNotNull { line ->
            runCatching {
                Cookie.parse(url, line)
            }.getOrNull()
        }.filter { it.expiresAt > System.currentTimeMillis() }.toList()
        if (cookies.size != raw.lineSequence().count { it.isNotBlank() }) {
            prefs.edit().putString(host, cookies.joinToString("\n") { it.toString() }).apply()
        }
        return cookies
    }

    fun clear() = prefs.edit().clear().apply()

    fun hostKeys(): Set<String> = prefs.all.keys

    /** Raw cookie strings for a host — used to hand the session over to the WebView. */
    fun cookieHeaderFor(url: HttpUrl): String =
        loadForRequest(url).joinToString("; ") { "${it.name}=${it.value}" }
}
