package com.aurora.get.core.network

import okhttp3.Dns
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * In-memory DNS cache with a TTL. Pre-resolving a host (preconnect) is done by
 * calling [prime] as soon as the domain of a link is known.
 */
class AuroraDns(private val delegate: Dns = Dns.SYSTEM) : Dns {

    private val cache = ConcurrentHashMap<String, Entry>()

    data class Entry(val addresses: List<InetAddress>, val expiresAt: Long)

    override fun lookup(hostname: String): List<InetAddress> {
        val now = System.currentTimeMillis()
        cache[hostname]?.let { entry ->
            if (entry.expiresAt > now) return entry.addresses
        }
        val resolved = delegate.lookup(hostname)
        cache[hostname] = Entry(resolved, now + TimeUnit.MINUTES.toMillis(10))
        return resolved
    }

    /** Warms the cache so the first real request skips DNS entirely. */
    fun prime(hostname: String) {
        runCatching { lookup(hostname) }
    }

    fun clear() = cache.clear()
}
