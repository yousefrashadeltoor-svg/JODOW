package com.aurora.get.core.network

import android.content.Context
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    const val USER_AGENT = "Mozilla/5.0 (Linux; Android 13; AuroraGet/1.0) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

    @Provides
    @Singleton
    fun provideCookieJar(@ApplicationContext context: Context): AuroraCookieJar = AuroraCookieJar(context)

    @Provides
    @Singleton
    fun provideDns(): AuroraDns = AuroraDns()

    @Provides
    @Singleton
    fun provideConnectionPool(): ConnectionPool = ConnectionPool(24, 5, TimeUnit.MINUTES)

    /**
     * The shared client. HTTP/3 is enabled through Cronet when the device ships it,
     * otherwise OkHttp's HTTP/2 stack is used transparently.
     */
    @Provides
    @Singleton
    fun provideOkHttpClient(
        cookieJar: AuroraCookieJar,
        dns: AuroraDns,
        connectionPool: ConnectionPool,
        @ApplicationContext context: Context,
    ): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .cookieJar(cookieJar)
            .dns(dns)
            .connectionPool(connectionPool)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .callTimeout(0, TimeUnit.MILLISECONDS)
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header("User-Agent", USER_AGENT)
                    .header("Accept-Encoding", "gzip")
                    .build()
                chain.proceed(request)
            }
        CronetFactory.create(context)?.let { engine ->
            runCatching {
                builder.engine(engine)
            }
        }
        return builder.build()
    }

    /** A client used only for probing (HEAD / Range) — no cookie side effects. */
    @Provides
    @Singleton
    @Named("probe")
    fun provideProbeClient(cookieJar: AuroraCookieJar, dns: AuroraDns): OkHttpClient =
        OkHttpClient.Builder()
            .cookieJar(cookieJar)
            .dns(dns)
            .followRedirects(true)
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(12, TimeUnit.SECONDS)
            .build()
}
