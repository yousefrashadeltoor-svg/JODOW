package com.aurora.get.core.network.adblock

/**
 * A single parsed filter rule (Adblock Plus compatible subset).
 */
data class AdBlockRule(
    val pattern: String,
    val isException: Boolean,
    val regex: Regex?,
    val options: Set<String>,
    val domainExceptions: Set<String>,
    val includedDomains: Set<String>,
    val blockCosmetics: Boolean,
    val raw: String
) {
    val isThirdPartyOnly: Boolean get() = "third-party" in options
    val isFirstPartyOnly: Boolean get() = "first-party" in options
    val types: Set<String> get() = options.filter { it in RESOURCE_TYPES }
}

/** Rule data types, mirrors the Adblock Plus notation. */
object ResourceType {
    const val DOCUMENT = "document"
    const val SCRIPT = "script"
    const val IMAGE = "image"
    const val MEDIA = "media"
    const val XHR = "xhr"
    const val OTHER = "other"

    val RESOURCE_TYPES = setOf(DOCUMENT, SCRIPT, IMAGE, MEDIA, XHR, OTHER)
}
