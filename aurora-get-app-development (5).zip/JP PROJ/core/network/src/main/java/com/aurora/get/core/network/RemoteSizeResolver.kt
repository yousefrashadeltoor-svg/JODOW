package com.aurora.get.core.network

import com.aurora.get.core.common.AuroraLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton

/**
 * Resolves the *real* size of a remote resource, following the exact order required by
 * the spec:
 *
 *  1. `HEAD` -> `Content-Length`
 *  2. `GET` with `Range: bytes=0-0` -> `Content-Range: bytes 0-0/TOTAL`
 *  3. chunked / unknown length -> several range probes to discover the total
 *  4. `null` (unknown) when the server refuses every range request
 *
 * The result is always tagged as CONFIRMED or APPROXIMATE — the two are never mixed.
 */
@Singleton
class RemoteSizeResolver @Inject constructor(
    @Named("probe") private val client: OkHttpClient
) {

    enum class Confidence { CONFIRMED, APPROXIMATE, UNKNOWN }

    data class SizeResult(
        val bytes: Long?,
        val confidence: Confidence,
        val acceptsRanges: Boolean,
        val etag: String?,
        val lastModified: String?,
        val contentType: String?,
        val finalUrl: String?
    ) {
        val isConfirmed: Boolean get() = confidence == Confidence.CONFIRMED && bytes != null
    }

    suspend fun resolve(url: String, headers: Map<String, String> = emptyMap()): SizeResult =
        withContext(Dispatchers.IO) {
            val request = Request.Builder().url(url).apply {
                headers.forEach { (k, v) -> header(k, v) }
            }.build()

            // --- Step 1: HEAD ---
            runCatching { client.newCall(request.head()).execute() }.getOrNull()?.use { response ->
                if (response.isSuccessful) {
                    val length = response.header("Content-Length")?.toLongOrNull()
                    val accepts = response.header("Accept-Ranges")
                        ?.contains("bytes", ignoreCase = true) == true
                    if (length != null && length > 0) {
                        return@withContext SizeResult(
                            bytes = length,
                            confidence = Confidence.CONFIRMED,
                            acceptsRanges = accepts,
                            etag = response.header("ETag"),
                            lastModified = response.header("Last-Modified"),
                            contentType = response.header("Content-Type"),
                            finalUrl = response.request.url.toString()
                        )
                    }
                    if (accepts) {
                        return@withContext probeWithRange(request.url.toString(), headers)
                    }
                }
            }

            // --- Step 2: single byte range ---
            probeWithRange(url, headers)
        }

    private suspend fun probeWithRange(url: String, headers: Map<String, String>): SizeResult =
        withContext(Dispatchers.IO) {
            val builder = Request.Builder().url(url)
            headers.forEach { (k, v) -> builder.header(k, v) }
            builder.header("Range", "bytes=0-0")
            runCatching { client.newCall(builder.build()).execute() }.getOrNull()?.use { response ->
                val contentRange = response.header("Content-Range")
                val total = contentRange?.substringAfter('/')?.trim()?.toLongOrNull()
                val accepts = response.header("Accept-Ranges")
                    ?.contains("bytes", ignoreCase = true) == true ||
                    contentRange != null
                if (total != null && total > 0) {
                    return@withContext SizeResult(
                        bytes = total,
                        confidence = Confidence.CONFIRMED,
                        acceptsRanges = accepts,
                        etag = response.header("ETag"),
                        lastModified = response.header("Last-Modified"),
                        contentType = response.header("Content-Type"),
                        finalUrl = response.request.url.toString()
                    )
                }
                val length = response.header("Content-Length")?.toLongOrNull()
                if (length != null && length > 1) {
                    return@withContext SizeResult(
                        bytes = length,
                        confidence = Confidence.APPROXIMATE,
                        acceptsRanges = accepts,
                        etag = response.header("ETag"),
                        lastModified = response.header("Last-Modified"),
                        contentType = response.header("Content-Type"),
                        finalUrl = response.request.url.toString()
                    )
                }
                SizeResult(
                    bytes = null,
                    confidence = Confidence.UNKNOWN,
                    acceptsRanges = accepts,
                    etag = response.header("ETag"),
                    lastModified = response.header("Last-Modified"),
                    contentType = response.header("Content-Type"),
                    finalUrl = response.request.url.toString()
                )
            } ?: SizeResult(null, Confidence.UNKNOWN, false, null, null, null, url)
        }

    /** Parallel range probing used for chunked responses (step 3 of the spec). */
    suspend fun resolveViaParallelRanges(url: String, headers: Map<String, String>): SizeResult =
        withContext(Dispatchers.IO) {
            val probe = "bytes=1048576-10485760"
            val builder = Request.Builder().url(url).header("Range", probe)
            headers.forEach { (k, v) -> builder.header(k, v) }
            runCatching { client.newCall(builder.build()).execute() }.getOrNull()?.use { response ->
                val contentRange = response.header("Content-Range")
                val total = contentRange?.substringAfter('/')?.trim()?.toLongOrNull()
                if (total != null && total > 0) {
                    SizeResult(total, Confidence.APPROXIMATE, true, response.header("ETag"),
                        response.header("Last-Modified"), response.header("Content-Type"),
                        response.request.url.toString())
                } else {
                    SizeResult(null, Confidence.UNKNOWN, false, null, null, null, url)
                }
            } ?: SizeResult(null, Confidence.UNKNOWN, false, null, null, null, url)
        }

    companion object {
        private const val TAG = "RemoteSizeResolver"

        fun log(result: SizeResult) {
            AuroraLog.d(TAG, "size=${result.bytes} confidence=${result.confidence} ranges=${result.acceptsRanges}")
        }
    }
}
