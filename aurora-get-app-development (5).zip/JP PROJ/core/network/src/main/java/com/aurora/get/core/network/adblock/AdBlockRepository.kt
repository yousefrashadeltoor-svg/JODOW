package com.aurora.get.core.network.adblock

import android.content.Context
import com.aurora.get.core.common.AuroraLog
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Downloads and stores the EasyList / EasyPrivacy style filter lists and feeds them
 * into the blocking engine. Everything stays on device.
 */
@Singleton
class AdBlockRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val client: OkHttpClient,
) {

    private val engine = AdBlockEngine()
    private val native = RustAdBlock(context)

    private val filterFile: File
        get() = File(context.filesDir, "adblock/filters.txt")

    val blockedCount: Long get() = engine.blockedCount
    val ruleCount: Int get() = engine.ruleCount

    fun currentEngine(): AdBlockEngine = engine

    suspend fun ensureLoaded(): Boolean = withContext(Dispatchers.IO) {
        if (filterFile.exists() && filterFile.length() > 0) {
            applyFilterFile(filterFile.readText())
            true
        } else {
            update()
        }
    }

    suspend fun update(): Boolean = withContext(Dispatchers.IO) {
        val builder = StringBuilder()
        var anySucceeded = false
        for (source in SOURCES) {
            runCatching {
                val request = Request.Builder().url(source.url).build()
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        builder.append(response.body?.string().orEmpty()).append('\n')
                        anySucceeded = true
                    }
                }
            }.onFailure { AuroraLog.w(TAG, "list failed: ${source.name} ${it.message}") }
        }
        if (!anySucceeded) return@withContext false
        val payload = builder.toString()
        filterFile.parentFile?.mkdirs()
        filterFile.writeText(payload)
        applyFilterFile(payload)
        true
    }

    private fun applyFilterFile(payload: String) {
        val (rules, cosmetic) = AdBlockEngine.parseFilters(payload)
        engine.load(rules, cosmetic)
        native.load(payload)
    }

    fun shouldBlock(url: String, type: String, documentDomain: String?): Boolean {
        if (native.isAvailable()) return native.shouldBlock(url, type, documentDomain)
        val parsed = runCatching { java.net.URL(url) }.getOrNull() ?: return false
        return engine.shouldBlock(AdBlockRequest(parsed, type, documentDomain))
    }

    fun cosmeticCss(domain: String): String = engine.cosmeticCssFor(domain)

    fun whitelist(domain: String) = engine.whitelist(domain)
    fun removeWhitelist(domain: String) = engine.removeWhitelist(domain)
    fun whitelistedDomains(): Set<String> = engine.whitelistedDomains()

    data class Source(val name: String, val url: String)

    companion object {
        private const val TAG = "AdBlockRepository"

        val SOURCES = listOf(
            Source("EasyList", "https://easylist.to/easylist/easylist.txt"),
            Source("EasyPrivacy", "https://easylist.to/easylist/easyprivacy.txt"),
            Source("Fanboy Annoyance", "https://easylist.to/easylist/fanboy-annoyance.txt"),
            Source("Peter Lowe", "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=adblockplus&showintro=0&mimetype=plain")
        )
    }
}
