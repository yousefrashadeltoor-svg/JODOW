package com.aurora.get.core.network.adblock

import android.content.Context
import com.aurora.get.core.common.AuroraLog

/**
 * Bridge to the native `adblock-rust` engine (brave/adblock-rust compiled for Android via NDK).
 *
 * The native library is optional: [RustAdBlock] silently degrades to the pure Kotlin
 * [AdBlockEngine] when `libadblock.so` is not bundled, so the feature never breaks the app.
 */
interface NativeAdBlock {
    fun load(filters: String): Boolean
    fun shouldBlock(url: String, type: String, documentDomain: String?): Boolean
    fun isAvailable(): Boolean
}

class RustAdBlock(private val context: Context) : NativeAdBlock {

    private val fallback = AdBlockEngine()
    private var nativeLoaded = false

    init {
        nativeLoaded = runCatching {
            System.loadLibrary("adblock")
            true
        }.getOrElse {
            AuroraLog.i("NativeAdBlock", "adblock-rust native library not bundled, using Kotlin engine")
            false
        }
    }

    override fun isAvailable(): Boolean = nativeLoaded

    override fun load(filters: String): Boolean {
        if (!nativeLoaded) {
            val (rules, cosmetic) = AdBlockEngine.parseFilters(filters)
            fallback.load(rules, cosmetic)
            return true
        }
        return runCatching { nativeLoad(filters) }.getOrElse {
            AuroraLog.w("NativeAdBlock", "native load failed: ${it.message}")
            false
        }
    }

    override fun shouldBlock(url: String, type: String, documentDomain: String?): Boolean {
        if (nativeLoaded) {
            val blocked = runCatching { nativeShouldBlock(url, type, documentDomain) }.getOrDefault(false)
            if (blocked) return true
        }
        val parsed = runCatching { java.net.URL(url) }.getOrNull() ?: return false
        return fallback.shouldBlock(AdBlockRequest(parsed, type, documentDomain))
    }

    /** VERIFY: these JNI symbols must exist in the NDK-built `libadblock.so`. */
    private external fun nativeLoad(filters: String): Boolean
    private external fun nativeShouldBlock(url: String, type: String, documentDomain: String?): Boolean
}
