package com.aurora.get.core.network

import com.aurora.get.core.network.adblock.AdBlockRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AdBlockModule {
    @Provides
    @Singleton
    fun provideAdBlockRepository(
        @dagger.hilt.android.qualifiers.ApplicationContext context: android.content.Context,
        client: okhttp3.OkHttpClient,
    ): AdBlockRepository = AdBlockRepository(context, client)
}
