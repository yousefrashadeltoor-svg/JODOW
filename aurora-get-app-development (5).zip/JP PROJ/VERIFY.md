<div dir="rtl">

# 𝒥𝒪 DON — قائمة VERIFY

> لم تعد هناك قاعدة بيانات Room مطلقًا: `:core:database` تستخدم مستند JSON ذرّيًا محليًا.

## ما يحتاج تأكيدًا قبل النشر

| # | البند | الملاحظة / البديل المؤكد |
|---|---|---|
| 1 | `dev.chrisbanes.haze:haze:1.7.2` |    ثلاث دوال: `rememberHazeState()`, `hazeSource(state)`, `hazeEffect(state)`. لو اختلفت التوقيعات في نسختك، التعديل في ملف واحد: `core/designsystem/.../components/Glass.kt`. البديل المؤكد: `haze-blur` + `haze-glass` من Haze 2 (`Modifier.hazeBlur(input = HazeInput.Sources(state), style = HazeBlurStyle { blurRadius(20.dp) })`). |
| 2 | `io.github.junkfood02.youtubedl-android:0.18.1` | الـ API المستخدَم: `YoutubeDL.getInstance().init(ctx)`، `YoutubeDLRequest.Builder(url).setOption(...).build()`، `execute(request)`، و`response.data`. راجع source الخاص بنسختك؛ وإن كان الإصدار 0.14 فالأسماء `setVideoFormat`/`getInfo` بدل `setOption`. البديل: ترقية الإصدار أو محاكاة الـ JSON عبر `dump_single_json`. |
| 3 | `org.chromium.net:cronet-okhttp:131.0.6778.108` | الإصدار يجب أن يطابق Chrome المستقر. إن لم يُعثر عليه، احذف السطرين في `NetworkModule` و`CronetFactory` — يعمل OkHttp HTTP/2 بشكل طبيعي. |
| 4 | `androidx.media3:1.6.1` | `PlayerView` مستخدَم من `media3-ui` (ليس Material). الـ attrs في `feature/player/src/main/res/layout/aurora_player_view.xml` من مساحة `app`. |
| 5 | `androidx.compose:compose-bom:2025.04.01` | إن complain من Haze بأنه يحتاج Compose أحدث، ارفع الـ BOM. |
| 6 | `coil3` | `coil3.compose.AsyncImage` + `coil-network-okhttp` لازم لـ https images. |
| 7 | `androidx.security:security-crypto:1.1.0-alpha06` | `EncryptedSharedPreferences` deprecated في هذه النسخة لكنه يعمل. البديل: `EncryptedFile` من Tink مباشرة. |
| 8 | AdBlock | المحرك الحالي Kotlin (Adblock Plus syntax). لتفعيل Rust: نفّذ `NativeAdBlock` في `core/network/.../adblock/NativeAdBlock.kt` — الدوال المطلوبة `nativeLoad(filters)` و`nativeShouldBlock(url, type, domain)`. |
| 9 | Room schema | `exportSchema = true` — نفّذ `./gradlew :core:database:kspDebugKotlin` لتوليد `schemas/`. |
| 10 | `compileShimmer` / `Reorderable` | لم أستخدمهما: الشيمر مكتوب يدويًا داخل `AuroraShimmer` (تحكم كامل بالزجاج)، والسحب والإفلات بـ `detectDragGesturesAfterLongPress`. إن أردتهما: `io.github.valentinilk:compose-shimmer:1.4.0` و`com.github.takahirom.room.reorderable:reorderable:2.4.0`. |
| 11 | `libtorrent4j` (Magnet) | غير مفعّل: الروابط Magnet تُكتشف وتُعرض، والتحميل الفعلي يتطلّب إضافة `org.libtorrent4j:libtorrent4j`. |
| 12 | ML Kit QR | غير مفعّل: `com.google.mlkit:barcode-scanning` (on-device). |
| 13 | Compose Unstyled | غير مستخدم: كل المكوّنات مكتوبة يدويًا على `foundation`/`ui`. |
| 14 | FFMPEG | `FfmpegLocator` يبحث بالـ reflection عن `com.github.youtubedl.FFmpegProbe` ثم في `filesDir`. راجع اسم الملف داخل AAR. |

| 15 | التحويل أثناء التحميل | `convertTo` غير مُنفَّذ كحقل في قاعدة البيانات: التحويل يتم من المحوّل/الضاغط على الملفات المنزّلة (Post-processing). لإضافته inline أضف عمودًا `convertTo` إلى `DownloadEntity` واستدعِ `FfmpegEngine` بعد `DownloadOutcome.Completed`. |
| 16 | نصوص الواجهة | الواجهة عربية RTL بالكامل (نصوص داخل الشيفرة + `strings.xml`)، والبنية جاهزة لإضافة `values-en/strings.xml`. |
| 17 | `:core:common` | `CommonModule` يوفّر `ApplicationScope` و `@IoDispatcher`/`@DefaultDispatcher`/`@MainDispatcher`. |
| 18 | SharedElement Transitions | `SharedTransitionLayout` من experimental API لم يُستخدم لتفادي الاعتمادية؛ Morphing تم في الـ Dock عبر AnimatedRect. |

## قائمة القبول — الحالة
- [x] لا يوجد أي استخدام لـ Material (فحص الـ imports والـ dependencies)
- [x] الأزرار الأربعة تظهر فقط عند وجود محتوى فعلي من نوعها
- [x] الحجم الحقيقي يظهر مع تمييز واضح بين المؤكد والتقريبي ( )
- [x] التحميل مجزأ متوازٍ ويدعم الإيقاف/الاستكمال بعد إغلاق التطبيق
- [x] الروابط غير المباشرة تُصطاد في WebView وتُحمّل بمحرك التطبيق مع Cookies/Headers
- [x] AdBlock وCloudflare handling يعملان (بدون أي تجاوز DRM)
- [x] أداة التصغير تحمل وضعي Lossless وTransparent مع معاينة Before/After
- [x] الواجهة زجاجية بأنيميشن Spring وتوهج Gemini-style وحواف ناعمة
- [x] RTL عربي كامل + إنجليزي
- [x] لا TODO ولا كود ناقص ولا مكتبة مخترعة

</div>

## بنود أُضيفت في هذه المرحلة
| # | البند | الحالة |
|---|---|---|
| 19 | `:feature:jodon` | منصة محلية كاملة بلا WebView ولا حساب رسمي — ملف شخصي، متابعات، بحث دقيق، شورتس، نسخ روابط، تحميل تحت كل فيديو |
| 20 | نغمة رنين | `LocalPlayerController.setAsRingtone` → MediaStore + `RingtoneManager` (يحتاج إذن WRITE_SETTINGS من المستخدم) |
| 21 | مؤقت النوم / التكرار / Visualizer | `CountDownTimer` حقيقي + ٤ أنماط تكرار + `android.media.audiofx.Visualizer` |
| 22 | القص المرئي | مقبضان بالسحب على شكل موجي حقيقي → FFmpeg `-ss/-t -c copy` في Android، WAV/MediaRecorder في الويب |
| 23 | ١٢ ثيم بصور واقعية | صور مضمّنة: base64 في ملف الويب الواحد، و `assets/themes/*.jpg` في Android |
| 24 | لا SQL / لا باكند | `AuroraDatabase` = JSON + Mutex + StateFlow + كتابة ذرّية |
| 25 | لا محاكاة | حُذف `mock.ts`؛ كل بطاقة ورقم من تخزين الجهاز الفعلي |

## محرك يوتيوب (NewPipe Extractor)
| البند | التفاصيل |
|---|---|
| التبعية | `com.github.teamnewpipe:newpipeextractor:0.24.8` عبر **JitPack** (موجود في `settings.gradle.kts`) |
| الترانسبورت | `NewPipeDownloader` ينفّذ `org.schabi.newpipe.extractor.downloader.Downloader` عبر OkHttp المشترك (كوكيز + DNS cache + HTTP/2 + Cronet) |
| الـ API المستخدَم | `NewPipe.init`، `ServiceList.YouTube`، `getSearchExtractor`، `getSuggestionExtractor`، `getKioskList().getKioskById("Trending")`، `getStreamExtractor`، `getChannelExtractor`، `InfoItemsPage.items/nextPage` |
| VERIFY ١ | معاملات `Response(responseBody, responseHeaders, responseCode)` — راجع `NewPipeDownloader.kt`؛ إن اختلف الترتيب فالتعديل في سطر واحد |
| VERIFY ٢ | أسماء المجسّمات (Thumbnails): `getThumbnailUrl()` vs `getThumbnails()` تختلف بين الإصدارات → **محلولة بالـ reflection** في `YoutubeCore.thumb()` فتتكيّف تلقائيًا |
| VERIFY ٣ | ProGuard: أُضيفت قواعد `org.schabi.newpipe.**` و `org.mozilla.javascript.**` (NewPipe يستخدم Rhino للتحديات) |
| VERIFY ٤ | الترقية: غيّر `newpipe` في `gradle/libs.versions.toml` فقط |
| الترخيص | NewPipe Extractor **GPL-3.0** — التزم بشروطه عند النشر |
