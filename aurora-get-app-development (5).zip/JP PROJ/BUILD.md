<div dir="rtl">

## خطوات البناء والتشغيل

### المتطلبات
- Android Studio Koala أو أحدث (JDK 17)
- Android SDK 35 + Build-Tools 35
- جهاز/محاكي Android 7.0 (API 24) فأحدث

### 1) استنساخ المشروع وفتحه
```bash
cd "JP PROJ"
gradle wrapper --gradle-version 8.11.1   # يولّد gradle-wrapper.jar
```

### 2) إعدادات SDK
أنشئ `local.properties`:
```properties
sdk.dir=/path/to/Android/Sdk
```

### 3) البناء
```bash
./gradlew :app:assembleDebug          # نسخة التطوير
./gradlew :app:assembleRelease        # نسخة الإصدار (R8 + shrink)
./gradlew :app:installDebug           # التثبيت على الجهاز
```

### 4) الاختبارات
```bash
./gradlew test                        # Unit tests
./gradlew :app:connectedDebugAndroidTest   # Instrumentation tests
./gradlew lint                        # Android Lint
```

### 5) فحص عدم وجود Material / SQL
```bash
./gradlew :app:dependencies --configuration debugRuntimeClasspath | grep -i "material"
# يجب أن تكون النتيجة فارغة تمامًا
./gradlew :app:dependencies --configuration releaseRuntimeClasspath | grep -i "room"
# يجب أن تكون النتيجة فارغة — لا توجد قاعدة بيانات SQL إطلاقًا
```
أو من داخل Gradle:
```kotlin
// build.gradle.kts (مؤقت)
tasks.register("checkNoMaterial") {
    doLast {
        configurations.getByName("releaseRuntimeClasspath")
            .resolvedConfiguration.resolvedArtifacts
            .filter { it.moduleVersion.id.group.contains("com.google.android.material") }
            .forEach { error("Material found: ${it.moduleVersion.id}") }
    }
}
```

### 6) CI
```bash
# .github/workflows/android.yml
- uses: actions/checkout@v4
- uses: actions/setup-java@v4
  with: { distribution: temurin, java-version: 17 }
- uses: gradle/actions/setup-gradle@v4
- run: ./gradlew test lint assembleDebug
```

### ملاحظات مهمة
- **الأيقونات**: ملف `core/designsystem/src/main/res/font/` جاهز. ضع:
  `plus_jakarta_sans_regular.ttf`, `plus_jakarta_sans_bold.ttf`,
  `ibm_plex_sans_arabic_regular.ttf`, `ibm_plex_sans_arabic_bold.ttf`
  (رخصة SIL OFL) وسيتم استخدامهما تلقائيًا — بدونها يعمل التطبيق بخط النظام.
- **AdBlock Rust**: ضع `libadblock.so` (NDK, brave/adblock-rust) في `app/src/main/jniLibs/<abi>/`
  لتفعيل المحرك الأصلي؛ بدونه يعمل المحرك النقي بلغة Kotlin.
- **FFmpeg**: يأتي داخل AAR الخاص بـ youtubedl-android، ويبحث عنه `FfmpegLocator` تلقائيًا.

</div>
